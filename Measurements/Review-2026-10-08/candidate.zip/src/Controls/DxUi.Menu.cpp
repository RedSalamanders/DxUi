#include "DxUi.Internal.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <d2d1effects.h>
#include <exception>
#include <format>
#include <limits>
#include <mutex>
#include <new>
#include <shellscalingapi.h>
#include <system_error>
#include <utility>
#include <wil/win32_helpers.h>
#include <wincodec.h>
#include <windowsx.h>

#include "../Support/Diagnostics.h"
#include "../Support/LiveResourceCount.h"
#include "../Support/Utilities.h"
#include "../Support/WindowMessages.h"

#pragma comment(lib, "shcore.lib")

#ifndef CLSID_WICImagingFactory2
#define CLSID_WICImagingFactory2 CLSID_WICImagingFactory
#endif

#if DXUI_ENABLE_DIAGNOSTICS
#define DXUI_MENU_TRACE(...) Debug::Info(__VA_ARGS__)
#else
#define DXUI_MENU_TRACE(...) static_cast<void>(0)
#endif

// Native menu diagnostics use the same borrowed sink as the rest of DxUi; no file or environment configuration.
#define DXUI_MENU_SINK_DIAGNOSTICS 1
#define DXUI_MENU_DIAGNOSTICS_TRACE(...) WriteMenuDiagnosticsTrace(__VA_ARGS__)

namespace DxUi
{
namespace
{
// ---------------------------------------------------------------------------
// Menu layout constants (WinUI spec §3.2)
// ---------------------------------------------------------------------------

constexpr float kMenuCornerRadiusDip          = kPopupRoundSmallCornerRadiusDip;
constexpr float kMenuBorderDip                = 1.0f;
constexpr float kMenuPaddingTopDip            = 4.0f;
constexpr float kMenuPaddingBottomDip         = 4.0f;
constexpr float kMenuMinWidthDip              = 128.0f;
constexpr float kMenuMaxWidthDip              = 456.0f;
constexpr float kMenuShadowLeftDip            = 10.0f;
constexpr float kMenuShadowTopDip             = 8.0f;
constexpr float kMenuShadowRightDip           = 10.0f;
constexpr float kMenuShadowBottomDip          = 14.0f;
constexpr float kIconAreaWidthDip             = 28.0f;
constexpr float kTextLeftPaddingDip           = 36.0f;
constexpr float kTextToAccelGapDip            = 16.0f;
constexpr float kAccelRightPaddingDip         = 16.0f;
constexpr float kChevronRightPaddingDip       = 12.0f;
constexpr float kChevronAreaWidthDip          = 24.0f;
constexpr float kItemHoverRadiusDip           = 4.0f;
constexpr float kItemHoverInsetDip            = 4.0f;
constexpr float kIconSlotLeftInsetDip         = kMenuBorderDip + kItemHoverInsetDip + 2.0f;
constexpr float kIconSlotWidthDip             = kIconAreaWidthDip - kItemHoverInsetDip - 2.0f;
constexpr float kSeparatorHeightDip           = 9.0f; // 1px line + 4 DIP margin above/below
constexpr float kSeparatorMarginDip           = 4.0f;
constexpr float kSliderItemHeightDip          = 72.0f;
constexpr float kSliderTrackInsetDip          = 16.0f;
constexpr float kSliderTrackTopDip            = 50.0f;
constexpr float kSliderTrackHeightDip         = 2.0f;
constexpr float kSliderStopMinExtentDip       = 8.0f;
constexpr float kSliderStopMaxExtentDip       = 20.0f;
constexpr float kSliderStopCornerRadiusDip    = 2.0f;
constexpr uint64_t kSliderAnimationDurationMs = 160u;
constexpr float kSliderMenuMinWidthDip        = 260.0f;
constexpr float kSubmenuVerticalOffsetDip     = 4.0f;
constexpr float kCascadeHoverDelayMs          = 400;
constexpr float kTextMeasureWidthDip          = 1024.0f;
constexpr float kDescriptionPaddingDip        = 8.0f;
constexpr float kDescriptionGapDip            = 3.0f;
#if DXUI_MENU_SINK_DIAGNOSTICS
constexpr uint64_t kMenuLoopTraceRepeatFlushCount = 1024u;
#endif

constexpr wchar_t kChevronRightGlyph[]   = L"\uE76C";
constexpr wchar_t kCheckMarkGlyph[]      = L"\uE73E";
constexpr wchar_t kRadioBulletGlyph[]    = L"\uF137"; // Filled circle
constexpr GUID kMenuGaussianBlurEffectId = {0x1feb6d69, 0x2fe6, 0x4ac9, {0x8c, 0x58, 0x1d, 0x7f, 0x93, 0xe7, 0xa6, 0xa5}};

struct MenuController;
struct MenuPopup;

#if DXUI_MENU_SINK_DIAGNOSTICS || DXUI_ENABLE_DIAGNOSTICS
[[nodiscard]] const wchar_t* TraceMenuMessageName(UINT message) noexcept
{
    switch (message)
    {
        case WM_MOUSEMOVE: return L"WM_MOUSEMOVE";
        case WM_LBUTTONDOWN: return L"WM_LBUTTONDOWN";
        case WM_LBUTTONUP: return L"WM_LBUTTONUP";
        case WM_RBUTTONDOWN: return L"WM_RBUTTONDOWN";
        case WM_RBUTTONUP: return L"WM_RBUTTONUP";
        case WM_MBUTTONDOWN: return L"WM_MBUTTONDOWN";
        case WM_MBUTTONUP: return L"WM_MBUTTONUP";
        case WM_XBUTTONDOWN: return L"WM_XBUTTONDOWN";
        case WM_XBUTTONUP: return L"WM_XBUTTONUP";
        case WM_MOUSEWHEEL: return L"WM_MOUSEWHEEL";
        case WM_MOUSEHWHEEL: return L"WM_MOUSEHWHEEL";
        case WM_NCMOUSEMOVE: return L"WM_NCMOUSEMOVE";
        case WM_NCLBUTTONDOWN: return L"WM_NCLBUTTONDOWN";
        case WM_NCLBUTTONUP: return L"WM_NCLBUTTONUP";
        case WM_NCRBUTTONDOWN: return L"WM_NCRBUTTONDOWN";
        case WM_NCRBUTTONUP: return L"WM_NCRBUTTONUP";
        case WM_MOUSELEAVE: return L"WM_MOUSELEAVE";
        case WM_NCMOUSELEAVE: return L"WM_NCMOUSELEAVE";
        case WM_NULL: return L"WM_NULL";
        case WM_PAINT: return L"WM_PAINT";
        case WM_ERASEBKGND: return L"WM_ERASEBKGND";
        case WM_SETCURSOR: return L"WM_SETCURSOR";
        case WM_TIMER: return L"WM_TIMER";
        case WM_CAPTURECHANGED: return L"WM_CAPTURECHANGED";
        case WM_CANCELMODE: return L"WM_CANCELMODE";
        case WM_ACTIVATEAPP: return L"WM_ACTIVATEAPP";
        case WM_ACTIVATE: return L"WM_ACTIVATE";
        case WM_NCACTIVATE: return L"WM_NCACTIVATE";
        case WM_SETFOCUS: return L"WM_SETFOCUS";
        case WM_KILLFOCUS: return L"WM_KILLFOCUS";
        case WM_DESTROY: return L"WM_DESTROY";
        case WM_KEYDOWN: return L"WM_KEYDOWN";
        case WM_KEYUP: return L"WM_KEYUP";
        case WM_SYSKEYDOWN: return L"WM_SYSKEYDOWN";
        case WM_SYSKEYUP: return L"WM_SYSKEYUP";
        default: return L"message";
    }
}
#endif

[[nodiscard]] int TracePopupIndex(const MenuController& controller, const MenuPopup* popup) noexcept;

[[nodiscard]] uintptr_t TraceHwndValue(HWND hwnd) noexcept
{
    return reinterpret_cast<uintptr_t>(hwnd);
}

#if DXUI_MENU_SINK_DIAGNOSTICS
[[nodiscard]] const wchar_t* TraceBool(bool value) noexcept
{
    return value ? L"true" : L"false";
}
#endif

[[nodiscard]] bool IsMenuClientMouseMessage(UINT message) noexcept
{
    return message >= WM_MOUSEFIRST && message <= WM_MOUSELAST;
}

#if DXUI_MENU_SINK_DIAGNOSTICS
[[nodiscard]] bool IsMenuNonClientMouseMessage(UINT message) noexcept
{
    return message >= WM_NCMOUSEMOVE && message <= WM_NCXBUTTONDBLCLK;
}

[[nodiscard]] bool IsMenuKeyMessage(UINT message) noexcept
{
    return message >= WM_KEYFIRST && message <= WM_KEYLAST;
}

[[nodiscard]] bool IsMenuPriorityInputMessage(UINT message) noexcept
{
    return IsMenuClientMouseMessage(message) || IsMenuNonClientMouseMessage(message) || IsMenuKeyMessage(message);
}
#endif

[[nodiscard]] bool PeekMenuPriorityMessage(MSG& msg) noexcept
{
    if (PeekMessageW(&msg, nullptr, WM_MOUSEFIRST, WM_MOUSELAST, PM_REMOVE) != FALSE)
    {
        return true;
    }
    if (PeekMessageW(&msg, nullptr, WM_NCMOUSEMOVE, WM_NCXBUTTONDBLCLK, PM_REMOVE) != FALSE)
    {
        return true;
    }
    if (PeekMessageW(&msg, nullptr, WM_KEYFIRST, WM_KEYLAST, PM_REMOVE) != FALSE)
    {
        return true;
    }
    return false;
}

[[nodiscard]] bool ShouldTraceMenuLoopMessageImmediately(UINT message, bool popupMessage) noexcept
{
    // The menu-bar hover is a registered message, not a constant a case can name.
    if (popupMessage || IsMenuPriorityInputMessage(message) || WndMsg::ContextMenuRootHoverChanged().Matches(message))
    {
        return true;
    }

    switch (message)
    {
        case WM_TIMER:
        case WM_CAPTURECHANGED:
        case WM_CANCELMODE:
        case WM_ACTIVATEAPP:
        case WM_ACTIVATE:
        case WM_NCACTIVATE:
        case WM_SETFOCUS:
        case WM_KILLFOCUS:
        case WM_DESTROY: return true;
        default: return false;
    }
}

[[nodiscard]] bool IsMenuDiagnosticsTraceEnabled() noexcept
{
    return Diagnostics::sink != nullptr;
}
void WriteMenuDiagnosticsTraceLine(std::wstring_view eventName, std::wstring_view details) noexcept
{
    Debug::Info(L"{} {}", eventName, details);
}
template <typename... Args> void WriteMenuDiagnosticsTrace(std::wstring_view eventName, std::wformat_string<Args...> format, Args&&... args) noexcept
{
    if (! IsMenuDiagnosticsTraceEnabled())
        return;
    try
    {
        WriteMenuDiagnosticsTraceLine(eventName, std::format(format, std::forward<Args>(args)...));
    }
    catch (const std::exception&)
    { /* Optional diagnostics never change menu dispatch. */
    }
}

// ---------------------------------------------------------------------------
// Menu item visual style
// ---------------------------------------------------------------------------

struct MenuItemVisualStyle
{
    D2D1_COLOR_F background;
    D2D1_COLOR_F text;
    D2D1_COLOR_F accelText;
    D2D1_COLOR_F iconColor;
    D2D1_COLOR_F separatorColor;
    D2D1_COLOR_F hoverFill;
    D2D1_COLOR_F checkedFill;
    D2D1_COLOR_F checkColor;
    D2D1_COLOR_F chevronColor;
    D2D1_COLOR_F headerText;
    D2D1_COLOR_F borderColor;
};

struct MenuResolvedItemPaintStyle
{
    bool showHighlightFill     = false;
    bool usesRainbowHighlight  = false;
    D2D1_COLOR_F fill          = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F compositeFill = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F text          = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F accelText     = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F iconColor     = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F checkColor    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F chevronColor  = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct MenuSurfaceMaterialStyle
{
    D2D1_COLOR_F baseFill;
    D2D1_COLOR_F glazeTop;
    D2D1_COLOR_F glazeMid;
    D2D1_COLOR_F bottomShade;
    D2D1_COLOR_F outerBorder;
    D2D1_COLOR_F innerBorder;
    D2D1_COLOR_F topRim;
    float shadowInsetDip        = 3.0f;
    float shadowYOffsetDip      = 3.0f;
    float shadowSpreadDip       = 7.0f;
    float shadowOuterOpacity    = 0.18f;
    float shadowInnerOpacity    = 0.10f;
    float backdropOpacity       = 0.0f;
    float backdropBlurDip       = 0.0f;
    float backdropDetailOpacity = 0.0f;
};

struct MenuPopupShadowMargins
{
    float leftDip   = kMenuShadowLeftDip;
    float topDip    = kMenuShadowTopDip;
    float rightDip  = kMenuShadowRightDip;
    float bottomDip = kMenuShadowBottomDip;
};

struct ParsedMenuLabel
{
    std::wstring displayText;
    wchar_t mnemonic = L'\0';
};

struct DecodedMenuItemText
{
    std::wstring_view labelText;
    std::wstring_view acceleratorText;
};

struct MenuBackdropSnapshot
{
    WindowHostBitmapCapture capture;
    mutable wil::com_ptr<ID2D1Bitmap1> cachedBitmap;
    mutable wil::com_ptr<ID2D1Device> cachedDevice;
};

[[nodiscard]] std::wstring_view TrimMenuTextWhitespace(std::wstring_view text) noexcept
{
    size_t first = 0u;
    size_t last  = text.size();

    while (first < last && std::iswspace(static_cast<wint_t>(text[first])))
    {
        ++first;
    }

    while (last > first && std::iswspace(static_cast<wint_t>(text[last - 1u])))
    {
        --last;
    }

    return text.substr(first, last - first);
}

[[nodiscard]] DecodedMenuItemText DecodeMenuItemText(const MenuFlyoutItem& item) noexcept
{
    const std::wstring_view explicitAccelerator = TrimMenuTextWhitespace(item.acceleratorText);
    const std::wstring_view itemText            = item.text;
    std::wstring_view labelText                 = itemText;
    std::wstring_view embeddedAccelerator;

    if (const size_t tabPos = itemText.find(L'\t'); tabPos != std::wstring_view::npos)
    {
        labelText = itemText.substr(0u, tabPos);
        if (explicitAccelerator.empty() && (tabPos + 1u) < itemText.size())
        {
            embeddedAccelerator = itemText.substr(tabPos + 1u);
        }
    }

    return DecodedMenuItemText{
        .labelText       = TrimMenuTextWhitespace(labelText),
        .acceleratorText = explicitAccelerator.empty() ? TrimMenuTextWhitespace(embeddedAccelerator) : explicitAccelerator,
    };
}

[[nodiscard]] wchar_t NormalizeMenuMnemonicChar(wchar_t ch) noexcept
{
    return static_cast<wchar_t>(reinterpret_cast<UINT_PTR>(CharUpperW(reinterpret_cast<LPWSTR>(static_cast<UINT_PTR>(ch)))));
}

[[nodiscard]] ParsedMenuLabel ParseMenuLabel(std::wstring_view text) noexcept
{
    ParsedMenuLabel parsed{};
    parsed.displayText.reserve(text.size());

    for (size_t index = 0u; index < text.size(); ++index)
    {
        const wchar_t ch = text[index];
        if (ch == L'&')
        {
            if ((index + 1u) < text.size())
            {
                const wchar_t next = text[index + 1u];
                if (next == L'&')
                {
                    parsed.displayText.push_back(L'&');
                }
                else
                {
                    if (parsed.mnemonic == L'\0')
                    {
                        parsed.mnemonic = next;
                    }
                    parsed.displayText.push_back(next);
                }

                ++index;
                continue;
            }
        }

        parsed.displayText.push_back(ch);
    }

    return parsed;
}

[[nodiscard]] wchar_t ResolveMenuLabelMnemonic(const ParsedMenuLabel& label) noexcept
{
    if (label.mnemonic != L'\0')
    {
        return label.mnemonic;
    }

    for (const wchar_t ch : label.displayText)
    {
        if (! std::iswspace(static_cast<wint_t>(ch)))
        {
            return ch;
        }
    }

    return L'\0';
}

[[nodiscard]] D2D1_COLOR_F WithAlpha(const D2D1_COLOR_F& color, float alpha) noexcept
{
    return D2D1::ColorF(color.r, color.g, color.b, (std::clamp)(alpha, 0.0f, 1.0f));
}

[[nodiscard]] MenuResolvedItemPaintStyle ResolveMenuItemPaintStyle(
    const ThemePalette& theme, const MenuItemVisualStyle& style, const MenuFlyoutItem& item, std::wstring_view rainbowSeed, bool hovered) noexcept
{
    MenuResolvedItemPaintStyle resolved{
        .showHighlightFill    = false,
        .usesRainbowHighlight = false,
        .fill                 = style.hoverFill,
        .compositeFill        = style.background,
        .text                 = style.text,
        .accelText            = style.accelText,
        .iconColor            = style.iconColor,
        .checkColor           = style.checkColor,
        .chevronColor         = style.chevronColor,
    };

    if (! hovered || ! item.enabled)
    {
        return resolved;
    }

    resolved.showHighlightFill = true;
    if (theme.rainbowMode && ! theme.highContrast && ! rainbowSeed.empty())
    {
        resolved.usesRainbowHighlight = true;
        resolved.fill                 = RainbowMenuSelectionTint(rainbowSeed, theme.dark);
    }

    resolved.compositeFill                = CompositeOverBackground(resolved.fill, style.background);
    const D2D1_COLOR_F contrastForeground = ChooseContrastingTextColor(resolved.compositeFill);
    resolved.text                         = contrastForeground;
    resolved.accelText                    = contrastForeground;
    resolved.iconColor                    = contrastForeground;
    resolved.checkColor                   = contrastForeground;
    resolved.chevronColor                 = contrastForeground;
    return resolved;
}

[[nodiscard]] ID2D1Bitmap1* EnsureMenuBackdropBitmap(ControlHost& host, MenuBackdropSnapshot& snapshot) noexcept
{
    if (snapshot.capture.widthPx == 0u || snapshot.capture.heightPx == 0u || snapshot.capture.bgraPixels.empty())
    {
        return nullptr;
    }

    ID2D1DeviceContext* const d2dContext = host.GetDeviceContext();
    if (! d2dContext)
    {
        return nullptr;
    }

    wil::com_ptr<ID2D1Device> device;
    d2dContext->GetDevice(device.put());
    if (! device)
    {
        return nullptr;
    }

    if (snapshot.cachedBitmap && snapshot.cachedDevice && snapshot.cachedDevice.get() == device.get())
    {
        return snapshot.cachedBitmap.get();
    }

    const D2D1_BITMAP_PROPERTIES1 bitmapProperties = D2D1::BitmapProperties1(
        D2D1_BITMAP_OPTIONS_NONE, D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED), host.GetDpi(), host.GetDpi());

    wil::com_ptr<ID2D1Bitmap1> bitmap;
    const UINT32 pitch = static_cast<UINT32>(snapshot.capture.widthPx * 4u);
    const HRESULT hr   = d2dContext->CreateBitmap(
        D2D1::SizeU(snapshot.capture.widthPx, snapshot.capture.heightPx), snapshot.capture.bgraPixels.data(), pitch, &bitmapProperties, bitmap.put());
    if (FAILED(hr) || ! bitmap)
    {
        Debug::Warning(L"DxUi::Menu: failed to create popup backdrop bitmap: 0x{:08X}", hr);
        return nullptr;
    }

    snapshot.cachedDevice = std::move(device);
    snapshot.cachedBitmap = std::move(bitmap);
    return snapshot.cachedBitmap.get();
}

[[nodiscard]] MenuItemVisualStyle ResolveMenuVisualStyle(const ThemePalette& theme) noexcept
{
    const D2D1_COLOR_F highlightBase = ChooseContrastingTextColor(theme.overlayBackground);
    D2D1_COLOR_F hoverFill           = theme.headerHovered;
    D2D1_COLOR_F checkedFill         = theme.selectionInactiveFill;
    if (theme.rainbowMode && ! theme.highContrast)
    {
        switch (theme.overlayMaterial)
        {
            case OverlayMaterial::Acrylic:
                hoverFill   = D2D1::ColorF(theme.accentPressed.r, theme.accentPressed.g, theme.accentPressed.b, theme.dark ? 0.82f : 0.72f);
                checkedFill = D2D1::ColorF(theme.accentHover.r, theme.accentHover.g, theme.accentHover.b, theme.dark ? 0.58f : 0.46f);
                break;
            case OverlayMaterial::MicaAlt:
                hoverFill   = D2D1::ColorF(theme.accentPressed.r, theme.accentPressed.g, theme.accentPressed.b, theme.dark ? 0.74f : 0.66f);
                checkedFill = D2D1::ColorF(theme.accentHover.r, theme.accentHover.g, theme.accentHover.b, theme.dark ? 0.50f : 0.40f);
                break;
            case OverlayMaterial::Mica:
                hoverFill   = D2D1::ColorF(theme.accentHover.r, theme.accentHover.g, theme.accentHover.b, theme.dark ? 0.52f : 0.42f);
                checkedFill = D2D1::ColorF(theme.accentHover.r, theme.accentHover.g, theme.accentHover.b, theme.dark ? 0.36f : 0.30f);
                break;
            case OverlayMaterial::Solid:
            default:
                hoverFill   = D2D1::ColorF(theme.accentHover.r, theme.accentHover.g, theme.accentHover.b, theme.dark ? 0.36f : 0.28f);
                checkedFill = D2D1::ColorF(theme.accentHover.r, theme.accentHover.g, theme.accentHover.b, theme.dark ? 0.28f : 0.22f);
                break;
        }
    }
    else
    {
        switch (theme.overlayMaterial)
        {
            case OverlayMaterial::Mica:
                hoverFill = WithAlpha(BlendColor(theme.headerHovered, highlightBase, theme.dark ? 0.16f : 0.08f), theme.dark ? 0.30f : 0.24f);
                break;
            case OverlayMaterial::MicaAlt:
                hoverFill = WithAlpha(BlendColor(theme.headerHovered, theme.accent, theme.dark ? 0.18f : 0.10f), theme.dark ? 0.34f : 0.28f);
                break;
            case OverlayMaterial::Acrylic:
                hoverFill = WithAlpha(BlendColor(theme.headerHovered, theme.accent, theme.dark ? 0.26f : 0.14f), theme.dark ? 0.42f : 0.34f);
                break;
            case OverlayMaterial::Solid:
            default: hoverFill = BlendColor(theme.headerHovered, theme.overlayBackground, theme.dark ? 0.10f : 0.04f); break;
        }
    }

    return MenuItemVisualStyle{
        .background     = theme.overlayBackground,
        .text           = theme.text,
        .accelText      = theme.subduedText,
        .iconColor      = theme.text,
        .separatorColor = BlendColor(theme.overlayBackground, theme.overlayBorder, theme.dark ? 0.62f : 0.46f),
        .hoverFill      = hoverFill,
        .checkedFill    = checkedFill,
        .checkColor     = theme.rainbowMode && ! theme.highContrast ? theme.accentPressed : theme.accent,
        .chevronColor   = theme.subduedText,
        .headerText     = theme.subduedText,
        .borderColor    = theme.overlayBorder,
    };
}

[[nodiscard]] wil::com_ptr<ID2D1LinearGradientBrush> CreateVerticalGradientBrush(
    ID2D1DeviceContext* dc, const D2D1_RECT_F& rect, const D2D1_COLOR_F& topColor, const D2D1_COLOR_F& midColor, const D2D1_COLOR_F& bottomColor) noexcept
{
    if (! dc)
    {
        return {};
    }

    const D2D1_GRADIENT_STOP stops[3] = {
        D2D1::GradientStop(0.0f, topColor),
        D2D1::GradientStop(0.42f, midColor),
        D2D1::GradientStop(1.0f, bottomColor),
    };

    wil::com_ptr<ID2D1GradientStopCollection> stopCollection;
    if (FAILED(dc->CreateGradientStopCollection(stops, static_cast<UINT32>(std::size(stops)), stopCollection.put())))
    {
        return {};
    }

    wil::com_ptr<ID2D1LinearGradientBrush> brush;
    if (FAILED(dc->CreateLinearGradientBrush(
            D2D1::LinearGradientBrushProperties(D2D1::Point2F(rect.left, rect.top), D2D1::Point2F(rect.left, rect.bottom)), stopCollection.get(), brush.put())))
    {
        return {};
    }

    return brush;
}

[[nodiscard]] MenuSurfaceMaterialStyle ResolveMenuSurfaceMaterialStyle(const ThemePalette& theme, const MenuItemVisualStyle& itemStyle) noexcept
{
    const D2D1_COLOR_F highlightBase = ChooseContrastingTextColor(theme.overlayBackground);
    MenuSurfaceMaterialStyle material{
        .baseFill           = WithAlpha(itemStyle.background, 0.96f),
        .glazeTop           = WithAlpha(BlendColor(theme.overlayBackground, highlightBase, theme.dark ? 0.12f : 0.08f), theme.dark ? 0.10f : 0.08f),
        .glazeMid           = WithAlpha(BlendColor(theme.overlayBackground, theme.windowBackground, theme.dark ? 0.32f : 0.18f), theme.dark ? 0.05f : 0.035f),
        .bottomShade        = D2D1::ColorF(0.0f, 0.0f, 0.0f, theme.dark ? 0.10f : 0.06f),
        .outerBorder        = WithAlpha(itemStyle.borderColor, theme.dark ? 0.76f : 0.62f),
        .innerBorder        = WithAlpha(BlendColor(itemStyle.borderColor, highlightBase, theme.dark ? 0.20f : 0.12f), theme.dark ? 0.48f : 0.42f),
        .topRim             = WithAlpha(highlightBase, theme.dark ? 0.18f : 0.14f),
        .shadowInsetDip     = 3.0f,
        .shadowYOffsetDip   = 3.0f,
        .shadowSpreadDip    = 9.0f,
        .shadowOuterOpacity = theme.dark ? 0.20f : 0.12f,
        .shadowInnerOpacity = theme.dark ? 0.12f : 0.07f,
        .backdropOpacity    = 0.0f,
        .backdropBlurDip    = 0.0f,
    };

    switch (theme.overlayMaterial)
    {
        case OverlayMaterial::Mica:
            material.baseFill = WithAlpha(BlendColor(theme.overlayBackground, theme.surfaceBackground, theme.dark ? 0.18f : 0.10f), theme.dark ? 0.58f : 0.62f);
            material.glazeTop = WithAlpha(BlendColor(theme.overlayBackground, highlightBase, theme.dark ? 0.24f : 0.14f), theme.dark ? 0.14f : 0.10f);
            material.glazeMid = WithAlpha(BlendColor(material.baseFill, theme.windowBackground, theme.dark ? 0.46f : 0.24f), theme.dark ? 0.08f : 0.05f);
            material.bottomShade        = D2D1::ColorF(0.0f, 0.0f, 0.0f, theme.dark ? 0.12f : 0.07f);
            material.outerBorder        = WithAlpha(BlendColor(itemStyle.borderColor, highlightBase, theme.dark ? 0.10f : 0.04f), theme.dark ? 0.82f : 0.68f);
            material.innerBorder        = WithAlpha(BlendColor(itemStyle.borderColor, highlightBase, theme.dark ? 0.30f : 0.20f), theme.dark ? 0.60f : 0.52f);
            material.topRim             = WithAlpha(highlightBase, theme.dark ? 0.24f : 0.19f);
            material.shadowOuterOpacity = theme.dark ? 0.24f : 0.16f;
            material.shadowInnerOpacity = theme.dark ? 0.14f : 0.09f;
            material.backdropOpacity    = ResolveOverlayBackdropOpacity(theme);
            material.backdropBlurDip    = ResolveOverlayBackdropBlurDip(theme);
            break;
        case OverlayMaterial::MicaAlt:
            material.baseFill = WithAlpha(BlendColor(theme.overlayBackground, theme.headerBackground, theme.dark ? 0.24f : 0.14f), theme.dark ? 0.48f : 0.58f);
            material.glazeTop = WithAlpha(BlendColor(material.baseFill, theme.headerHovered, theme.dark ? 0.48f : 0.28f), theme.dark ? 0.16f : 0.12f);
            material.glazeMid = WithAlpha(BlendColor(theme.headerHovered, theme.accent, theme.dark ? 0.40f : 0.24f), theme.dark ? 0.12f : 0.08f);
            material.bottomShade        = D2D1::ColorF(0.0f, 0.0f, 0.0f, theme.dark ? 0.14f : 0.08f);
            material.outerBorder        = WithAlpha(BlendColor(itemStyle.borderColor, theme.accent, theme.dark ? 0.22f : 0.12f), theme.dark ? 0.88f : 0.74f);
            material.innerBorder        = WithAlpha(BlendColor(material.outerBorder, highlightBase, theme.dark ? 0.36f : 0.22f), theme.dark ? 0.66f : 0.56f);
            material.topRim             = WithAlpha(BlendColor(highlightBase, theme.accent, 0.20f), theme.dark ? 0.28f : 0.22f);
            material.shadowOuterOpacity = theme.dark ? 0.26f : 0.17f;
            material.shadowInnerOpacity = theme.dark ? 0.16f : 0.10f;
            material.backdropOpacity    = ResolveOverlayBackdropOpacity(theme);
            material.backdropBlurDip    = ResolveOverlayBackdropBlurDip(theme);
            break;
        case OverlayMaterial::Acrylic:
            material.baseFill    = WithAlpha(BlendColor(theme.overlayBackground, theme.headerHovered, theme.dark ? 0.14f : 0.10f), theme.dark ? 0.12f : 0.16f);
            material.glazeTop    = WithAlpha(BlendColor(material.baseFill, highlightBase, theme.dark ? 0.24f : 0.14f), theme.dark ? 0.08f : 0.06f);
            material.glazeMid    = WithAlpha(BlendColor(theme.accent, theme.headerHovered, theme.dark ? 0.18f : 0.10f), theme.dark ? 0.04f : 0.03f);
            material.bottomShade = D2D1::ColorF(0.0f, 0.0f, 0.0f, theme.dark ? 0.05f : 0.03f);
            material.outerBorder = WithAlpha(BlendColor(itemStyle.borderColor, theme.accent, theme.dark ? 0.24f : 0.14f), theme.dark ? 0.76f : 0.64f);
            material.innerBorder = WithAlpha(BlendColor(material.outerBorder, highlightBase, theme.dark ? 0.32f : 0.18f), theme.dark ? 0.58f : 0.48f);
            material.topRim      = WithAlpha(BlendColor(highlightBase, theme.accent, 0.18f), theme.dark ? 0.14f : 0.12f);
            material.shadowInsetDip     = 2.0f;
            material.shadowSpreadDip    = 10.0f;
            material.shadowOuterOpacity = theme.dark ? 0.30f : 0.20f;
            material.shadowInnerOpacity = theme.dark ? 0.20f : 0.13f;
            material.backdropOpacity    = ResolveOverlayBackdropOpacity(theme);
            material.backdropBlurDip    = ResolveOverlayBackdropBlurDip(theme);
            break;
        case OverlayMaterial::Solid:
        default: break;
    }

    return material;
}

void PaintMenuBackdropSurface(
    ControlHost& host, MenuBackdropSnapshot* snapshot, const D2D1_RECT_F& menuRect, float cornerRadiusDip, const MenuSurfaceMaterialStyle& material) noexcept
{
    if (! snapshot || material.backdropOpacity <= 0.0f || material.backdropBlurDip <= 0.0f)
    {
        return;
    }

    auto* const dc             = host.GetDeviceContext();
    ID2D1Bitmap1* const bitmap = EnsureMenuBackdropBitmap(host, *snapshot);
    if (! dc || ! bitmap)
    {
        return;
    }

    wil::com_ptr<ID2D1Factory> factory;
    dc->GetFactory(factory.put());

    wil::com_ptr<ID2D1RoundedRectangleGeometry> roundedGeometry;
    if (! factory || FAILED(factory->CreateRoundedRectangleGeometry(D2D1::RoundedRect(menuRect, cornerRadiusDip, cornerRadiusDip), roundedGeometry.put())) ||
        ! roundedGeometry)
    {
        return;
    }

    wil::com_ptr<ID2D1Effect> blurEffect;
    if (FAILED(dc->CreateEffect(kMenuGaussianBlurEffectId, blurEffect.put())) || ! blurEffect)
    {
        return;
    }

    blurEffect->SetInput(0u, bitmap);
    blurEffect->SetValue(D2D1_GAUSSIANBLUR_PROP_STANDARD_DEVIATION, material.backdropBlurDip);
    blurEffect->SetValue(D2D1_GAUSSIANBLUR_PROP_OPTIMIZATION, D2D1_GAUSSIANBLUR_OPTIMIZATION_BALANCED);
    blurEffect->SetValue(D2D1_GAUSSIANBLUR_PROP_BORDER_MODE, D2D1_BORDER_MODE_HARD);

    wil::com_ptr<ID2D1Layer> layer;
    if (FAILED(dc->CreateLayer(layer.put())) || ! layer)
    {
        return;
    }

    const D2D1_RECT_F sourceRect = D2D1::RectF(
        0.0f, 0.0f, host.PixelsToDip(static_cast<float>(snapshot->capture.widthPx)), host.PixelsToDip(static_cast<float>(snapshot->capture.heightPx)));

    const D2D1_LAYER_PARAMETERS1 layerParameters = D2D1::LayerParameters1(menuRect,
                                                                          roundedGeometry.get(),
                                                                          D2D1_ANTIALIAS_MODE_PER_PRIMITIVE,
                                                                          D2D1::Matrix3x2F::Identity(),
                                                                          (std::clamp)(material.backdropOpacity, 0.0f, 1.0f),
                                                                          nullptr,
                                                                          D2D1_LAYER_OPTIONS1_NONE);
    const D2D1_POINT_2F targetOffset             = D2D1::Point2F(menuRect.left, menuRect.top);
    dc->PushLayer(layerParameters, layer.get());
    dc->DrawImage(blurEffect.get(), &targetOffset, &sourceRect, D2D1_INTERPOLATION_MODE_LINEAR, D2D1_COMPOSITE_MODE_SOURCE_OVER);
    if (material.backdropDetailOpacity > 0.0f)
    {
        dc->DrawBitmap(bitmap, menuRect, (std::clamp)(material.backdropDetailOpacity, 0.0f, 1.0f), D2D1_INTERPOLATION_MODE_LINEAR);
    }
    dc->PopLayer();
}

void PaintMenuMaterialSurface(
    ControlHost& host, MenuBackdropSnapshot* snapshot, const D2D1_RECT_F& menuRect, float cornerRadiusDip, const MenuSurfaceMaterialStyle& material) noexcept
{
    auto* const dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    const D2D1_RECT_F shadowTargetRect   = InflateRect(menuRect, -material.shadowInsetDip, -material.shadowInsetDip);
    const D2D1_ROUNDED_RECT menuRounded  = D2D1::RoundedRect(menuRect, cornerRadiusDip, cornerRadiusDip);
    const D2D1_RECT_F innerRect          = InflateRect(menuRect, -1.0f, -1.0f);
    const D2D1_ROUNDED_RECT innerRounded = D2D1::RoundedRect(innerRect, (std::max)(0.0f, cornerRadiusDip - 1.0f), (std::max)(0.0f, cornerRadiusDip - 1.0f));

    DrawDropShadow(host,
                   shadowTargetRect,
                   (std::max)(0.0f, cornerRadiusDip - material.shadowInsetDip),
                   material.shadowYOffsetDip,
                   material.shadowSpreadDip,
                   material.shadowOuterOpacity,
                   material.shadowInnerOpacity);

    PaintMenuBackdropSurface(host, snapshot, menuRect, cornerRadiusDip, material);
    DrawRoundedRect(host, menuRect, material.baseFill, D2D1::ColorF(0, 0, 0, 0), cornerRadiusDip);

    if (wil::com_ptr<ID2D1LinearGradientBrush> glazeBrush = CreateVerticalGradientBrush(
            dc, menuRect, material.glazeTop, material.glazeMid, D2D1::ColorF(material.glazeMid.r, material.glazeMid.g, material.glazeMid.b, 0.0f)))
    {
        dc->FillRoundedRectangle(menuRounded, glazeBrush.get());
    }

    if (wil::com_ptr<ID2D1LinearGradientBrush> bottomShadeBrush =
            CreateVerticalGradientBrush(dc,
                                        menuRect,
                                        D2D1::ColorF(material.bottomShade.r, material.bottomShade.g, material.bottomShade.b, 0.0f),
                                        D2D1::ColorF(material.bottomShade.r, material.bottomShade.g, material.bottomShade.b, material.bottomShade.a * 0.35f),
                                        material.bottomShade))
    {
        dc->FillRoundedRectangle(menuRounded, bottomShadeBrush.get());
    }

    if (auto* const topRimBrush = host.GetSolidBrush(material.topRim))
    {
        const float rimY = menuRect.top + 1.0f;
        dc->DrawLine(
            D2D1::Point2F(menuRect.left + cornerRadiusDip - 1.0f, rimY), D2D1::Point2F(menuRect.right - cornerRadiusDip + 1.0f, rimY), topRimBrush, 1.0f);
    }

    if (auto* const outerBorderBrush = host.GetSolidBrush(material.outerBorder))
    {
        dc->DrawRoundedRectangle(menuRounded, outerBorderBrush, 1.0f);
    }
    if (auto* const innerBorderBrush = host.GetSolidBrush(material.innerBorder))
    {
        dc->DrawRoundedRectangle(innerRounded, innerBorderBrush, 1.0f);
    }
}

[[nodiscard]] IWICImagingFactory* GetMenuIconWicFactory() noexcept
{
    static wil::com_ptr<IWICImagingFactory> factory;
    if (factory)
    {
        return factory.get();
    }

    HRESULT hr = CoCreateInstance(CLSID_WICImagingFactory2, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(factory.put()));
    if (FAILED(hr))
    {
        hr = CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(factory.put()));
    }
    if (FAILED(hr))
    {
        Debug::Warning(L"DxUi::Menu: Failed to create WIC factory for popup icons: 0x{:08X}", hr);
        factory.reset();
        return nullptr;
    }

    return factory.get();
}

[[nodiscard]] ID2D1Bitmap1* EnsureMenuBitmapIconBitmap(ControlHost& host, const MenuFlyoutItem::BitmapIcon& icon) noexcept
{
    if (! icon.sourceBitmap)
    {
        return nullptr;
    }

    ID2D1DeviceContext* const d2dContext = host.GetDeviceContext();
    if (! d2dContext)
    {
        return nullptr;
    }

    wil::com_ptr<ID2D1Device> device;
    d2dContext->GetDevice(device.put());
    if (! device)
    {
        return nullptr;
    }

    if (icon.cachedBitmap && icon.cachedDevice && icon.cachedDevice.get() == device.get())
    {
        return icon.cachedBitmap.get();
    }

    IWICImagingFactory* const wicFactory = GetMenuIconWicFactory();
    if (! wicFactory)
    {
        return nullptr;
    }

    wil::com_ptr<IWICBitmap> wicBitmap;
    HRESULT hr = wicFactory->CreateBitmapFromHBITMAP(icon.sourceBitmap.get(), nullptr, WICBitmapUsePremultipliedAlpha, wicBitmap.put());
    if (FAILED(hr))
    {
        Debug::Warning(L"DxUi::Menu: Failed to create WIC bitmap from menu icon: 0x{:08X}", hr);
        return nullptr;
    }

    D2D1_BITMAP_PROPERTIES1 bitmapProperties = D2D1::BitmapProperties1(
        D2D1_BITMAP_OPTIONS_NONE, D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED), host.GetDpi(), host.GetDpi());

    wil::com_ptr<ID2D1Bitmap1> bitmap;
    hr = d2dContext->CreateBitmapFromWicBitmap(wicBitmap.get(), &bitmapProperties, bitmap.put());
    if (FAILED(hr))
    {
        Debug::Warning(L"DxUi::Menu: Failed to create D2D bitmap for menu icon: 0x{:08X}", hr);
        return nullptr;
    }

    icon.cachedDevice = std::move(device);
    icon.cachedBitmap = std::move(bitmap);
    return icon.cachedBitmap.get();
}

void DrawMenuBitmapIcon(ControlHost& host, const MenuFlyoutItem::BitmapIcon& icon, const D2D1_RECT_F& iconRectDip, float opacity) noexcept
{
    ID2D1Bitmap1* const bitmap = EnsureMenuBitmapIconBitmap(host, icon);
    if (! bitmap)
    {
        return;
    }

    const float sourceWidthDip  = icon.widthPx > 0u ? host.PixelsToDip(static_cast<float>(icon.widthPx)) : 16.0f;
    const float sourceHeightDip = icon.heightPx > 0u ? host.PixelsToDip(static_cast<float>(icon.heightPx)) : 16.0f;
    const float maxWidthDip     = (std::max)(0.0f, (iconRectDip.right - iconRectDip.left) - 4.0f);
    const float maxHeightDip    = (std::max)(0.0f, (iconRectDip.bottom - iconRectDip.top) - 4.0f);
    if (sourceWidthDip <= 0.0f || sourceHeightDip <= 0.0f || maxWidthDip <= 0.0f || maxHeightDip <= 0.0f)
    {
        return;
    }

    const float scale          = (std::min)(1.0f, (std::min)(maxWidthDip / sourceWidthDip, maxHeightDip / sourceHeightDip));
    const float drawWidthDip   = sourceWidthDip * scale;
    const float drawHeightDip  = sourceHeightDip * scale;
    const D2D1_RECT_F drawRect = D2D1::RectF(iconRectDip.left + (((iconRectDip.right - iconRectDip.left) - drawWidthDip) * 0.5f),
                                             iconRectDip.top + (((iconRectDip.bottom - iconRectDip.top) - drawHeightDip) * 0.5f),
                                             iconRectDip.left + (((iconRectDip.right - iconRectDip.left) - drawWidthDip) * 0.5f) + drawWidthDip,
                                             iconRectDip.top + (((iconRectDip.bottom - iconRectDip.top) - drawHeightDip) * 0.5f) + drawHeightDip);

    host.GetDeviceContext()->DrawBitmap(bitmap, drawRect, opacity, D2D1_INTERPOLATION_MODE_LINEAR);
}

[[nodiscard]] bool IsInvokableMenuItem(const MenuFlyoutItem& item) noexcept
{
    if (! item.enabled)
    {
        return false;
    }

    switch (item.kind)
    {
        case MenuItemKind::Separator:
        case MenuItemKind::Header:
        case MenuItemKind::Info: return false;
        case MenuItemKind::Slider:
            for (const auto& stop : item.sliderStops)
            {
                if (stop.commandId != 0)
                {
                    return true;
                }
            }
            return false;
        case MenuItemKind::Standard:
        case MenuItemKind::Toggle:
        case MenuItemKind::Radio: return ! item.children.empty() || item.commandId != 0;
    }

    return false;
}

[[nodiscard]] uint32_t ClampSliderValue(const MenuFlyoutItem& item) noexcept
{
    if (item.sliderStops.empty())
    {
        return 0u;
    }

    const uint32_t maxStop = static_cast<uint32_t>(item.sliderStops.size() - 1u);
    return (std::min)(item.sliderValue, maxStop);
}

[[nodiscard]] int GetSliderCommandId(const MenuFlyoutItem& item, uint32_t stopIndex) noexcept
{
    if (stopIndex >= item.sliderStops.size())
    {
        return 0;
    }
    return item.sliderStops[stopIndex].commandId;
}

[[nodiscard]] D2D1_RECT_F GetSliderTrackRect(const D2D1_RECT_F& itemRect) noexcept
{
    return D2D1::RectF(itemRect.left + kSliderTrackInsetDip,
                       itemRect.top + kSliderTrackTopDip,
                       itemRect.right - kSliderTrackInsetDip,
                       itemRect.top + kSliderTrackTopDip + kSliderTrackHeightDip);
}

[[nodiscard]] uint32_t HitTestSliderStop(const MenuFlyoutItem& item, const D2D1_RECT_F& itemRect, D2D1_POINT_2F pointDip) noexcept
{
    const size_t stopCount = item.sliderStops.size();
    if (stopCount <= 1u)
    {
        return 0u;
    }

    const D2D1_RECT_F trackRect = GetSliderTrackRect(itemRect);
    const float trackWidth      = (std::max)(1.0f, trackRect.right - trackRect.left);
    const float normalized      = std::clamp((pointDip.x - trackRect.left) / trackWidth, 0.0f, 1.0f);
    const float scaled          = normalized * static_cast<float>(stopCount - 1u);
    return static_cast<uint32_t>(std::lround(scaled));
}

struct MenuItemLayoutRects
{
    D2D1_RECT_F itemRectDip          = D2D1::RectF();
    D2D1_RECT_F iconRectDip          = D2D1::RectF();
    D2D1_RECT_F textRectDip          = D2D1::RectF();
    D2D1_RECT_F acceleratorRectDip   = D2D1::RectF();
    D2D1_RECT_F chevronRectDip       = D2D1::RectF();
    D2D1_RECT_F secondaryTextRectDip = D2D1::RectF();
};

[[nodiscard]] bool HasMenuDescription(const MenuFlyoutItem& item) noexcept
{
    return ! item.secondaryText.empty() &&
           (item.kind == MenuItemKind::Standard || item.kind == MenuItemKind::Toggle || item.kind == MenuItemKind::Radio || item.kind == MenuItemKind::Info);
}

// The size of one field of a described row, as its layout reports it.
struct MenuFieldMetrics
{
    float height     = 0.0f;
    UINT32 lineCount = 0u;
};

// A described row's two fields share one DirectWrite layout, because the shaping storage a layout keeps is mostly per layout
// (about 17 KB), not per character: its text is the label, an empty spacer paragraph and the description, and the description
// range carries the small text format's font. Two separate layouts drew the label at the row's text origin and the description
// kDescriptionGapDip below the label's height rounded up to whole DIPs; the spacer paragraph, whose font size
// MeasureMenuDescriptionRow calibrates, keeps exactly that distance. Only the layout's own line heights are summed, so the
// rounded heights equal those of two separate layouts.
struct MenuDescriptionLayout
{
    wil::com_ptr<IDWriteTextLayout> layout;
    DWRITE_TEXT_RANGE description{};   // The description's text positions.
    UINT32 spacerPosition = 0u;        // The spacer paragraph's newline: the first text position after the label's own newline.
    float spacerSizeDip   = 0.0f;      // The font size that gives the spacer paragraph its height.
    MenuFieldMetrics primaryMetrics;   // The label's lines (spacer and description excluded).
    MenuFieldMetrics secondaryMetrics; // The description's lines.
    float heightDip              = 0.0f;
    float textWidthDip           = 0.0f;
    ID2D1Brush* descriptionBrush = nullptr; // The brush bound as the description range's drawing effect. Identity only: the layout owns it.
};

[[nodiscard]] int RoundToIntSaturated(double value) noexcept
{
    if (value <= static_cast<double>((std::numeric_limits<int>::min)()))
    {
        return (std::numeric_limits<int>::min)();
    }
    if (value >= static_cast<double>((std::numeric_limits<int>::max)()))
    {
        return (std::numeric_limits<int>::max)();
    }
    return static_cast<int>(std::lround(value));
}

[[nodiscard]] LONG RoundToLongSaturated(double value) noexcept
{
    if (value <= static_cast<double>((std::numeric_limits<LONG>::min)()))
    {
        return (std::numeric_limits<LONG>::min)();
    }
    if (value >= static_cast<double>((std::numeric_limits<LONG>::max)()))
    {
        return (std::numeric_limits<LONG>::max)();
    }
    return static_cast<LONG>(std::lround(value));
}

[[nodiscard]] int DipExtentToPixels(float extentDip, UINT dpi) noexcept
{
    const double scaled = static_cast<double>(extentDip) * static_cast<double>(dpi) / 96.0;
    return (std::max)(1, RoundToIntSaturated(scaled));
}

// ---------------------------------------------------------------------------
// Menu popup window class
// ---------------------------------------------------------------------------

// The popups' private messages are registered by name: WndMsg::MenuPopup* (WindowMessages.h).
static constexpr wchar_t kMenuWindowClass[] = L"DxUi_ContextMenu";
struct MenuAccessibilityRequest
{
    HWND target;
    size_t index;
};

void PostMenuAccessibilityRequest(HWND target, WndMsg::RegisteredMessage message, size_t index) noexcept
{
    // The bounded existing registry drains payloads on WM_NCDESTROY; a queued
    // action cannot outlive its popup or be reinterpreted after HWND reuse.
    // Without its registered message the request is dropped, as a failed post drops it.
    if (! message)
        return;
    std::unique_ptr<MenuAccessibilityRequest> request(new (std::nothrow) MenuAccessibilityRequest{target, index});
    if (request)
        static_cast<void>(PostMessagePayload(target, message.value, 0, std::move(request)));
}
static std::atomic<bool> s_classRegistered = false;
#if DXUI_ENABLE_DIAGNOSTICS
static constexpr DWORD kMenuDebugStateDispatchTimeoutMs = 1000u;
// The other cross-thread probes, a software-rendered capture under AddressSanitizer among them, answer within a second: a popup
// thread that does not answer in three seconds is wedged or blocked, and its probe fails instead of holding the caller for good.
static constexpr DWORD kMenuDebugProbeTimeoutMs = 3000u;
#endif

struct MenuController; // forward
[[nodiscard]] bool ProcessMenuPopupMessage(MenuController& controller, HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
void FinalizeAsyncMenuController(MenuController& controller) noexcept;
void DestroyMenuPopupWindow(MenuPopup& popup) noexcept;
[[nodiscard]] UINT ResolveMenuPopupMessageDpi(HWND hwnd, UINT msg, WPARAM wp) noexcept;
void RelayoutMenuPopupForDpi(MenuPopup& popup, UINT dpi, const RECT* suggestedWindowRect) noexcept;
void SynchronizeMenuAccessibility(MenuPopup& popup) noexcept;
void ApplyMenuCursorAtPointer(MenuController& controller) noexcept;
void RestoreWindowCursorAfterMenu(const MenuController& controller) noexcept;
[[nodiscard]] bool ForwardSetCursorToThreadWindowAt(POINT screenPoint) noexcept;
void ShowArrowCursor() noexcept;

struct MenuPopup
{
    enum class ScrollbarHotPart : uint8_t
    {
        None,
        Track,
        Thumb,
    };

    enum class SubmenuHoverTimerKind : uint8_t
    {
        None,
        PendingOpen,
        PendingClose,
    };

    MenuPopup()                            = default;
    MenuPopup(const MenuPopup&)            = delete;
    MenuPopup& operator=(const MenuPopup&) = delete;
    MenuPopup(MenuPopup&&)                 = delete;
    MenuPopup& operator=(MenuPopup&&)      = delete;

    HWND hwnd = nullptr;
    ControlHost host;
    std::vector<MenuFlyoutItem> ownedItems;
    std::vector<float> itemOffsetsDip;
    std::vector<MenuDescriptionLayout> descriptionLayouts;
    // What DebugGetContextMenuResources reports for this popup while it lives: itself and the layouts its rows hold.
    Detail::LiveResourceCount livePopup{Detail::LiveResource::MenuPopup, 1u};
    Detail::LiveResourceCount liveRowLayouts;
    // The brush every described row's layout carries as the drawing effect of its description, so a row is one layout drawn by
    // one call: paint sets its color for each row just before that row's draw. It belongs to one Direct2D device, which it
    // keeps alive, so a new device gets a new brush and the layouts carry that one from their next draw.
    wil::com_ptr<ID2D1SolidColorBrush> descriptionBrush;
    wil::com_ptr<ID2D1Device> descriptionBrushDevice;
    uint64_t descriptionPreparationCount = 0;
    const MenuFlyoutItem* items          = nullptr;
    size_t itemCount                     = 0;
    MenuController* controller           = nullptr;
    std::optional<size_t> hoveredIndex;
    std::optional<size_t> keyboardIndex;
    std::optional<size_t> openedFromItemIndex;
    UINT dpi              = USER_DEFAULT_SCREEN_DPI;
    float menuWidthDip    = 0.0f;
    float menuHeightDip   = 0.0f;
    float windowWidthDip  = 0.0f;
    float windowHeightDip = 0.0f;
    RECT surfaceRectPx{};
    RECT windowRectPx{};
    float contentHeightDip          = 0.0f;
    float acceleratorColumnWidthDip = 0.0f;
    bool hasSubmenuItems            = false;
    MenuBackdropSnapshot backdropSnapshot;
    MenuPopupShadowMargins shadowMargins;
    bool usesSystemBackdrop           = false;
    bool usesAppBackdropBlur          = false;
    bool isSubmenu                    = false;
    bool mouseInsideMenu              = false;
    float scrollOffsetDip             = 0.0f;
    bool draggingScrollbarThumb       = false;
    float scrollbarDragOffsetDip      = 0.0f;
    ScrollbarHotPart scrollbarHotPart = ScrollbarHotPart::None;

    std::optional<size_t> draggingSliderItemIndex;
    std::optional<size_t> sliderAnimationItemIndex;
    float sliderAnimatedPosition         = 0.0f;
    float sliderAnimationStartPosition   = 0.0f;
    float sliderAnimationTargetPosition  = 0.0f;
    uint64_t sliderAnimationStartTickMs  = 0u;
    bool sliderAnimationActive           = false;
    bool sliderAnimationInitialized      = false;
    uint64_t sliderDragTargetChangeCount = 0u;
    size_t lastPaintedItemCount          = 0u;
    std::chrono::steady_clock::time_point sliderInteractionStartedAt{};

    UINT_PTR hoverTimerId                = 0;
    SubmenuHoverTimerKind hoverTimerKind = SubmenuHoverTimerKind::None;
    size_t hoverTimerItemIndex           = SIZE_MAX;

    [[nodiscard]] float DipToPixel(float dip) const noexcept
    {
        return dip * static_cast<float>(dpi) / 96.0f;
    }

    [[nodiscard]] float PixelToDip(float px) const noexcept
    {
        return DxUi::Detail::PixelToDip(px, static_cast<float>(dpi));
    }

    [[nodiscard]] bool IsNavigableItem(size_t index) const noexcept
    {
        if (index >= itemCount)
            return false;
        return items[index].enabled && items[index].kind != MenuItemKind::Separator && items[index].kind != MenuItemKind::Header &&
               items[index].kind != MenuItemKind::Info;
    }

    // Whole-pixel sizing can leave a popup's viewport up to half a device pixel shorter than
    // content that fits. That rounding slack is not useful scroll range and must not create a
    // scrollbar lane or fractional scroll offset.
    [[nodiscard]] bool ContentOverflowsViewport(float viewportHeightDip) const noexcept
    {
        if (! (viewportHeightDip > 0.0f))
            return false;
        return contentHeightDip - viewportHeightDip > PixelToDip(0.5f);
    }

    [[nodiscard]] bool NeedsScrollbar() const noexcept
    {
        return ContentOverflowsViewport(menuHeightDip);
    }

    [[nodiscard]] D2D1_RECT_F GetSurfaceRect() const noexcept
    {
        return D2D1::RectF(shadowMargins.leftDip, shadowMargins.topDip, shadowMargins.leftDip + menuWidthDip, shadowMargins.topDip + menuHeightDip);
    }

    [[nodiscard]] float GetScrollExtent() const noexcept
    {
        // A described popup never turns whole-pixel rounding slack into a scroll range.
        if (! descriptionLayouts.empty() && ! NeedsScrollbar())
            return 0.0f;
        return (std::max)(0.0f, contentHeightDip - menuHeightDip);
    }

    void ClampScrollOffset() noexcept
    {
        scrollOffsetDip = (std::clamp)(scrollOffsetDip, 0.0f, GetScrollExtent());
    }

    [[nodiscard]] D2D1_RECT_F GetViewportRect() const noexcept
    {
        const D2D1_RECT_F surfaceRect = GetSurfaceRect();
        return NeedsScrollbar() ? D2D1::RectF(surfaceRect.left, surfaceRect.top, surfaceRect.right - kScrollbarThicknessDip, surfaceRect.bottom) : surfaceRect;
    }

    [[nodiscard]] D2D1_RECT_F GetScrollbarTrackRect() const noexcept
    {
        const D2D1_RECT_F surfaceRect = GetSurfaceRect();
        return D2D1::RectF(surfaceRect.right - kScrollbarThicknessDip, surfaceRect.top, surfaceRect.right, surfaceRect.bottom);
    }

    [[nodiscard]] D2D1_RECT_F GetScrollbarThumbRect() const noexcept
    {
        return ComputeScrollbarThumbRect(
            GetScrollbarTrackRect(), ScrollbarOrientation::Vertical, menuHeightDip, contentHeightDip, scrollOffsetDip, GetScrollExtent());
    }

    [[nodiscard]] float GetContentWidthDip() const noexcept
    {
        return NeedsScrollbar() ? menuWidthDip - kScrollbarThicknessDip : menuWidthDip;
    }

    void RebuildItemOffsets()
    {
        const ThemePalette& theme   = host.GetTheme();
        const float itemHeightDip   = ResolveMenuItemHeightDip(theme);
        const float headerHeightDip = ResolveMenuHeaderHeightDip(theme);

        itemOffsetsDip.clear();
        itemOffsetsDip.reserve(itemCount + 1u);
        float offset = kMenuPaddingTopDip;
        itemOffsetsDip.push_back(offset);
        for (size_t i = 0; i < itemCount; ++i)
        {
            switch (items[i].kind)
            {
                case MenuItemKind::Separator: offset += kSeparatorHeightDip; break;
                case MenuItemKind::Header: offset += headerHeightDip; break;
                case MenuItemKind::Slider: offset += kSliderItemHeightDip; break;
                case MenuItemKind::Standard:
                case MenuItemKind::Toggle:
                case MenuItemKind::Radio:
                case MenuItemKind::Info:
                    offset += ! descriptionLayouts.empty() && descriptionLayouts[i].heightDip > 0.0f ? descriptionLayouts[i].heightDip : itemHeightDip;
                    break;
            }
            itemOffsetsDip.push_back(offset);
        }
    }

    [[nodiscard]] D2D1_RECT_F GetItemRect(size_t index, float widthDip) const noexcept
    {
        if (index >= itemCount || itemOffsetsDip.size() != itemCount + 1u)
        {
            return D2D1::RectF();
        }
        return D2D1::RectF(kMenuBorderDip, itemOffsetsDip[index], widthDip - kMenuBorderDip, itemOffsetsDip[index + 1u]);
    }

    [[nodiscard]] RECT GetInteractiveScreenRect() const noexcept
    {
        RECT windowRect{};
        if (! hwnd || GetWindowRect(hwnd, &windowRect) == FALSE)
        {
            return RECT{};
        }

        const auto roundToLong = [](double value) noexcept
        {
            if (value <= static_cast<double>((std::numeric_limits<LONG>::min)()))
            {
                return (std::numeric_limits<LONG>::min)();
            }
            if (value >= static_cast<double>((std::numeric_limits<LONG>::max)()))
            {
                return (std::numeric_limits<LONG>::max)();
            }
            return static_cast<LONG>(std::lround(value));
        };

        return RECT{roundToLong(static_cast<double>(windowRect.left) + DipToPixel(shadowMargins.leftDip)),
                    roundToLong(static_cast<double>(windowRect.top) + DipToPixel(shadowMargins.topDip)),
                    roundToLong(static_cast<double>(windowRect.left) + DipToPixel(shadowMargins.leftDip + menuWidthDip)),
                    roundToLong(static_cast<double>(windowRect.top) + DipToPixel(shadowMargins.topDip + menuHeightDip))};
    }

    void EnsureItemVisible(size_t index) noexcept
    {
        const D2D1_RECT_F itemRect = GetItemRect(index, GetContentWidthDip());
        if (itemRect.bottom <= itemRect.top || ! NeedsScrollbar())
        {
            return;
        }

        // Before the first navigable row and after the last there is only padding, headers and separators, so reaching
        // either row (Home, End or a wrapping arrow) brings that edge of the menu into view with it when both fit.
        float revealTop    = FindFirstNavigableItem() == index ? 0.0f : itemRect.top;
        float revealBottom = FindLastNavigableItem() == index ? (std::max)(itemRect.bottom, contentHeightDip) : itemRect.bottom;
        if (revealBottom - revealTop > menuHeightDip)
        {
            revealTop    = itemRect.top;
            revealBottom = itemRect.bottom;
        }
        if (revealBottom - revealTop > menuHeightDip || revealTop < scrollOffsetDip)
        {
            scrollOffsetDip = revealTop;
        }
        else if (revealBottom > (scrollOffsetDip + menuHeightDip))
        {
            scrollOffsetDip = revealBottom - menuHeightDip;
        }
        ClampScrollOffset();
    }

    [[nodiscard]] std::optional<size_t> FindNextNavigableItem(size_t from, bool forward) const noexcept
    {
        if (itemCount == 0)
            return std::nullopt;
        for (size_t i = 0; i < itemCount; ++i)
        {
            size_t idx;
            if (forward)
                idx = (from + 1 + i) % itemCount;
            else
                idx = (from + itemCount - 1 - i) % itemCount;
            if (IsNavigableItem(idx))
                return idx;
        }
        return std::nullopt;
    }

    [[nodiscard]] std::optional<size_t> FindFirstNavigableItem() const noexcept
    {
        for (size_t i = 0; i < itemCount; ++i)
        {
            if (IsNavigableItem(i))
                return i;
        }
        return std::nullopt;
    }

    [[nodiscard]] std::optional<size_t> FindInitialKeyboardItem(bool focusFirstNavigableItem) const noexcept
    {
        if (focusFirstNavigableItem)
        {
            return FindFirstNavigableItem();
        }

        return std::nullopt;
    }

    [[nodiscard]] std::optional<size_t> FindLastNavigableItem() const noexcept
    {
        for (size_t i = itemCount; i > 0; --i)
        {
            if (IsNavigableItem(i - 1))
                return i - 1;
        }
        return std::nullopt;
    }

    [[nodiscard]] std::optional<size_t> FindMnemonicItem(wchar_t ch) const noexcept
    {
        const wchar_t upper = NormalizeMenuMnemonicChar(ch);
        for (size_t i = 0; i < itemCount; ++i)
        {
            if (! IsNavigableItem(i) || ! items[i].enabled)
                continue;

            const ParsedMenuLabel label = ParseMenuLabel(DecodeMenuItemText(items[i]).labelText);
            const wchar_t itemMnemonic  = ResolveMenuLabelMnemonic(label);
            if (itemMnemonic != L'\0' && NormalizeMenuMnemonicChar(itemMnemonic) == upper)
            {
                return i;
            }
        }
        return std::nullopt;
    }
};

void InvalidatePopup(MenuPopup& popup) noexcept;
[[nodiscard]] D2D1_RECT_F GetVisibleItemRect(const MenuPopup& popup, size_t index) noexcept;

// ---------------------------------------------------------------------------
// Menu controller — owns the cascade chain, modal loop, result
// ---------------------------------------------------------------------------

struct MenuController
{
    ~MenuController() noexcept;

    HWND ownerHwnd = nullptr;
    ThemePalette theme;
    MenuItemVisualStyle style;
    ContextMenuSessionCallbacks sessionCallbacks;
    ContextMenuClosedCallback asyncOnClosed;
    std::optional<int> result;
    bool running                = true;
    bool asyncSession           = false;
    bool asyncFinalizing        = false;
    bool asyncInteractionActive = false;
    // True while DestroyMenuPopupWindow runs DestroyWindow on one of this
    // controller's popups. Distinguishes controller-initiated popup destruction
    // (submenu close, chain replacement, root switch) from external teardown so
    // the popup WndProc does not finalize the async session re-entrantly.
    bool destroyingPopupWindow      = false;
    HWND previousCapture            = nullptr;
    HWND previousFocus              = nullptr;
    bool ignoreInitialLeftButtonUp  = false;
    bool ignoreInitialRightButtonUp = false;
    bool leftButtonDownInPopup      = false;
    bool rightButtonDownInPopup     = false;
    bool cursorChosen               = false; // The menu set or forwarded a cursor; closing lets the window re-choose.
    bool cursorForwardPending       = false; // A posted MenuPopupForwardCursor message will forward for cursorForwardPoint.
    POINT cursorForwardPoint{};
    POINT lastPointerScreenPoint{};
    bool hasLastPointerScreenPoint = false;
    POINT lastRootSwitchPointerScreenPoint{};
    bool hasLastRootSwitchPointerScreenPoint  = false;
    DWORD lastKeyboardRootSwitchMessageTime   = 0;
    bool hasLastKeyboardRootSwitchMessageTime = false;
#if DXUI_ENABLE_DIAGNOSTICS
    uint64_t rootPointerSwitchCount         = 0;
    uint64_t rootSwitchImmediateRenderCount = 0;
#endif

    // Cascade stack: [0] = root menu, [1..N] = submenus
    std::vector<std::unique_ptr<MenuPopup>> popups;

    // Root items (owned copy)
    std::vector<MenuFlyoutItem> rootItems;

    void Dismiss() noexcept
    {
        DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.dismiss",
                                    L"owner={:#x} popups={} resultBefore={} runningBefore={}",
                                    TraceHwndValue(ownerHwnd),
                                    popups.size(),
                                    result.value_or(-1),
                                    TraceBool(running));
        running = false;
    }

    void InvokeItem(int commandId) noexcept
    {
        DXUI_MENU_DIAGNOSTICS_TRACE(
            L"menu.invoke", L"owner={:#x} commandId={} popups={} runningBefore={}", TraceHwndValue(ownerHwnd), commandId, popups.size(), TraceBool(running));
        result  = commandId;
        running = false;
    }

    void CloseTopmostSubmenu() noexcept
    {
        if (popups.size() > 1)
        {
            auto& parent = popups[popups.size() - 2];
            parent->hoveredIndex.reset();
            auto& child = popups.back();
            DestroyMenuPopupWindow(*child);
            popups.pop_back();
            if (! popups.empty() && popups.back()->hwnd)
            {
                InvalidatePopup(*popups.back());
            }
        }
    }

    [[nodiscard]] bool IsPointInAnyPopup(POINT screenPt) const noexcept
    {
        for (const auto& popup : popups)
        {
            if (popup->hwnd)
            {
                const RECT rc = popup->GetInteractiveScreenRect();
                if (PtInRect(&rc, screenPt))
                    return true;
            }
        }
        return false;
    }

    [[nodiscard]] MenuPopup* FindPopupForHwnd(HWND hwnd) const noexcept
    {
        for (const auto& popup : popups)
        {
            if (popup->hwnd == hwnd)
                return popup.get();
        }
        return nullptr;
    }

    [[nodiscard]] MenuPopup* GetRootPopup() const noexcept
    {
        return popups.empty() ? nullptr : popups.front().get();
    }

    [[nodiscard]] MenuPopup* GetTopmostPopup() const noexcept
    {
        return popups.empty() ? nullptr : popups.back().get();
    }
};

#if DXUI_ENABLE_DIAGNOSTICS
std::atomic<ContextMenuModalLoopPeekHook> g_menuModalLoopPeekHook{nullptr};
std::atomic<void*> g_menuModalLoopPeekHookContext{nullptr};
#endif

// Removes the first `message` queued for a popup of the chain, root first. PeekMessageW first runs the handlers of messages
// other threads sent to this thread, and such a handler can open or close a submenu, which changes controller.popups under
// the loop. So the chain is indexed afresh on every iteration and nothing from it is held across the call: a popup that
// closes is not visited, and no popup is read after it was freed. Nothing allocates.
[[nodiscard]] bool PeekMenuPopupMessage(const MenuController& controller, UINT message, MSG& msg) noexcept
{
    for (size_t index = 0u; index < controller.popups.size(); ++index)
    {
        const HWND popupHwnd = controller.popups[index]->hwnd;
        if (! popupHwnd)
        {
            continue;
        }
#if DXUI_ENABLE_DIAGNOSTICS
        if (const ContextMenuModalLoopPeekHook hook = g_menuModalLoopPeekHook.load(std::memory_order_acquire))
        {
            hook(g_menuModalLoopPeekHookContext.load(std::memory_order_acquire), popupHwnd, message);
        }
#endif
        if (PeekMessageW(&msg, popupHwnd, message, message, PM_REMOVE) != FALSE)
        {
            return true;
        }
    }
    return false;
}

[[nodiscard]] bool PeekMenuModalLoopPriorityMessage(const MenuController& controller, MSG& msg) noexcept
{
    if (PeekMenuPriorityMessage(msg))
    {
        return true;
    }
    // Input invalidates the popup, but ordinary WM_PAINT is lower priority than posted owner traffic.
    // Drain only our pending popup paints before that traffic so visible feedback cannot starve.
    if (PeekMenuPopupMessage(controller, WM_PAINT, msg))
    {
        return true;
    }
#if DXUI_ENABLE_DIAGNOSTICS
    // Test-only state probes must observe already-prioritized input without
    // waiting behind unrelated owner traffic in the modal thread queue.
    // A filter of 0 through 0 would retrieve every message; without its registered message no probe was posted.
    const WndMsg::RegisteredMessage probe = WndMsg::MenuPopupDebugGetState();
    return probe && PeekMenuPopupMessage(controller, probe.value, msg);
#else
    static_cast<void>(controller);
    return false;
#endif
}

void InvalidatePopup(MenuPopup& popup) noexcept
{
    if (! popup.hwnd || IsWindow(popup.hwnd) == FALSE)
    {
        return;
    }

    SynchronizeMenuAccessibility(popup);
    InvalidateRect(popup.hwnd, nullptr, FALSE);
}

[[nodiscard]] float ResolveSliderStopVisualExtentDip(size_t stopIndex, size_t stopCount) noexcept
{
    if (stopCount <= 1u)
    {
        return kSliderStopMaxExtentDip;
    }

    const float normalized = static_cast<float>(stopIndex) / static_cast<float>(stopCount - 1u);
    return std::lerp(kSliderStopMinExtentDip, kSliderStopMaxExtentDip, normalized);
}

void SetSliderAnimationTarget(MenuPopup& popup, float targetPosition) noexcept
{
    const float maxPosition   = popup.draggingSliderItemIndex.has_value() && popup.draggingSliderItemIndex.value() < popup.itemCount
                                    ? static_cast<float>((std::max)(size_t{1u}, popup.items[popup.draggingSliderItemIndex.value()].sliderStops.size()) - 1u)
                                    : targetPosition;
    const float clampedTarget = std::clamp(targetPosition, 0.0f, maxPosition);
    if (! popup.sliderAnimationInitialized)
    {
        popup.sliderAnimatedPosition        = clampedTarget;
        popup.sliderAnimationStartPosition  = clampedTarget;
        popup.sliderAnimationTargetPosition = clampedTarget;
        popup.sliderAnimationInitialized    = true;
        return;
    }

    if (std::fabs(popup.sliderAnimationTargetPosition - clampedTarget) <= 0.0001f)
    {
        return;
    }

    popup.sliderAnimationStartPosition  = popup.sliderAnimatedPosition;
    popup.sliderAnimationTargetPosition = clampedTarget;
    popup.sliderAnimationStartTickMs    = GetTickCount64();
    popup.sliderAnimationActive         = ! popup.host.GetTheme().reducedMotion;
    if (! popup.sliderAnimationActive)
    {
        popup.sliderAnimatedPosition = clampedTarget;
    }
    else
    {
        popup.host.RequestAnimation();
    }
    InvalidatePopup(popup);
}

[[nodiscard]] bool AdvanceSliderAnimation(MenuPopup& popup, uint64_t nowTickMs) noexcept
{
    if (! popup.sliderAnimationActive)
    {
        return false;
    }

    if (popup.host.GetTheme().reducedMotion)
    {
        popup.sliderAnimatedPosition = popup.sliderAnimationTargetPosition;
        popup.sliderAnimationActive  = false;
        return false;
    }

    const uint64_t elapsedMs     = nowTickMs > popup.sliderAnimationStartTickMs ? nowTickMs - popup.sliderAnimationStartTickMs : 0u;
    const float progress         = std::clamp(static_cast<float>(elapsedMs) / static_cast<float>(kSliderAnimationDurationMs), 0.0f, 1.0f);
    const float inverse          = 1.0f - progress;
    const float eased            = 1.0f - (inverse * inverse * inverse);
    popup.sliderAnimatedPosition = std::lerp(popup.sliderAnimationStartPosition, popup.sliderAnimationTargetPosition, eased);
    if (progress >= 1.0f)
    {
        popup.sliderAnimatedPosition = popup.sliderAnimationTargetPosition;
        popup.sliderAnimationActive  = false;
    }
    return popup.sliderAnimationActive;
}

void UpdateSliderInteractionAtPoint(MenuPopup& popup, size_t itemIndex, D2D1_POINT_2F pointDip) noexcept
{
    if (itemIndex >= popup.ownedItems.size())
    {
        return;
    }

    MenuFlyoutItem& item = popup.ownedItems[itemIndex];
    if (item.kind != MenuItemKind::Slider || item.sliderStops.empty())
    {
        return;
    }

    const uint32_t stopIndex = HitTestSliderStop(item, GetVisibleItemRect(popup, itemIndex), pointDip);
    if (stopIndex == ClampSliderValue(item) && popup.sliderAnimationInitialized)
    {
        return;
    }

    item.sliderValue     = stopIndex;
    item.acceleratorText = item.sliderStops[stopIndex].text;
    ++popup.sliderDragTargetChangeCount;
    SetSliderAnimationTarget(popup, static_cast<float>(stopIndex));
}

void BeginSliderInteraction(MenuPopup& popup, size_t itemIndex, D2D1_POINT_2F pointDip) noexcept
{
    if (itemIndex >= popup.itemCount || popup.items[itemIndex].kind != MenuItemKind::Slider || popup.items[itemIndex].sliderStops.empty())
    {
        return;
    }

    popup.draggingSliderItemIndex     = itemIndex;
    popup.sliderDragTargetChangeCount = 0u;
    popup.sliderInteractionStartedAt  = std::chrono::steady_clock::now();
    if (! popup.sliderAnimationInitialized || popup.sliderAnimationItemIndex != std::optional<size_t>{itemIndex})
    {
        const float currentPosition         = static_cast<float>(ClampSliderValue(popup.items[itemIndex]));
        popup.sliderAnimationItemIndex      = itemIndex;
        popup.sliderAnimatedPosition        = currentPosition;
        popup.sliderAnimationStartPosition  = currentPosition;
        popup.sliderAnimationTargetPosition = currentPosition;
        popup.sliderAnimationInitialized    = true;
    }
    UpdateSliderInteractionAtPoint(popup, itemIndex, pointDip);
    InvalidatePopup(popup);
}

[[nodiscard]] int TracePopupIndex(const MenuController& controller, const MenuPopup* popup) noexcept
{
    if (! popup)
    {
        return -1;
    }

    for (size_t index = 0; index < controller.popups.size(); ++index)
    {
        if (controller.popups[index].get() == popup)
        {
            return index <= static_cast<size_t>(std::numeric_limits<int>::max()) ? static_cast<int>(index) : -1;
        }
    }

    return -1;
}

[[nodiscard]] POINT UnpackMousePoint(LPARAM lParam) noexcept
{
    return POINT{static_cast<LONG>(static_cast<short>(LOWORD(static_cast<DWORD_PTR>(lParam)))),
                 static_cast<LONG>(static_cast<short>(HIWORD(static_cast<DWORD_PTR>(lParam))))};
}

[[nodiscard]] POINT ResolveMouseScreenPoint(const MSG& msg) noexcept
{
    POINT screenPt{};
    if (msg.message == WM_MOUSEWHEEL || msg.message == WM_MOUSEHWHEEL)
    {
        return UnpackMousePoint(msg.lParam);
    }

    screenPt = UnpackMousePoint(msg.lParam);
    if (msg.hwnd && IsWindow(msg.hwnd) != FALSE)
    {
        POINT clientPoint = screenPt;
        if (ClientToScreen(msg.hwnd, &clientPoint) != FALSE)
        {
            return clientPoint;
        }
    }

    return screenPt;
}

enum class MenuInputSource : uint8_t
{
    ModalMessage,
    PopupWndProc,
};

enum class MenuPointerKind : uint8_t
{
    Move,
    LeftDown,
    LeftUp,
    RightDown,
    RightUp,
    Wheel,
};

enum class MenuKeyboardKind : uint8_t
{
    Up,
    Down,
    Left,
    Right,
    Home,
    End,
    Enter,
    Space,
    Escape,
    Tab,
    F10,
    Alt,
    Mnemonic,
};

struct MenuPointerEvent
{
    MenuInputSource source = MenuInputSource::ModalMessage;
    MenuPointerKind kind   = MenuPointerKind::Move;
    HWND hwnd              = nullptr;
    POINT screenPoint{};
    DWORD messageTime = 0;
    std::optional<D2D1_POINT_2F> deliveredPopupPointDip;
    WPARAM wParam             = 0;
    LPARAM lParam             = 0;
    bool mayInvoke            = false;
    bool mayDismiss           = false;
    bool maySwitchRoot        = false;
    bool mayTakeKeyboardFocus = false;
};

struct MenuKeyboardEvent
{
    MenuInputSource source = MenuInputSource::ModalMessage;
    MenuKeyboardKind kind  = MenuKeyboardKind::Mnemonic;
    HWND hwnd              = nullptr;
    UINT virtualKey        = 0;
    wchar_t mnemonic       = L'\0';
    DWORD messageTime      = 0;
    LPARAM lParam          = 0;
};

enum class MenuInputDisposition : uint8_t
{
    Ignored,
    Consumed,
    HoverChanged,
    Dismissed,
    Invoked,
    SwitchedRoot,
};

[[nodiscard]] bool IsMessageTimeAfter(DWORD candidate, DWORD reference) noexcept
{
    return static_cast<LONG>(candidate - reference) > 0;
}

[[nodiscard]] DWORD CurrentMessageTime() noexcept
{
    return static_cast<DWORD>(GetMessageTime());
}

void RememberKeyboardRootSwitchMessageTime(MenuController& controller, DWORD messageTime) noexcept
{
    controller.lastKeyboardRootSwitchMessageTime    = messageTime;
    controller.hasLastKeyboardRootSwitchMessageTime = true;
    controller.hasLastRootSwitchPointerScreenPoint  = false;
    controller.lastRootSwitchPointerScreenPoint     = {};
}

void ClearKeyboardRootSwitchMessageTime(MenuController& controller) noexcept
{
    controller.hasLastKeyboardRootSwitchMessageTime = false;
    controller.lastKeyboardRootSwitchMessageTime    = 0;
}

[[nodiscard]] bool IsStaleRootSwitchPointerMoveAfterKeyboard(const MenuController& controller, const MenuPointerEvent& event) noexcept
{
    if ((event.source != MenuInputSource::ModalMessage && event.source != MenuInputSource::PopupWndProc) || ! controller.hasLastKeyboardRootSwitchMessageTime)
    {
        return false;
    }

    if (! controller.hasLastRootSwitchPointerScreenPoint)
    {
        return true;
    }

    return event.messageTime != 0 && ! IsMessageTimeAfter(event.messageTime, controller.lastKeyboardRootSwitchMessageTime);
}

void RememberRootSwitchPointerPoint(MenuController& controller, POINT screenPoint) noexcept
{
    controller.lastRootSwitchPointerScreenPoint    = screenPoint;
    controller.hasLastRootSwitchPointerScreenPoint = true;
}

[[nodiscard]] bool ShouldRememberRejectedRootSwitchPointer(const MenuPointerEvent& event) noexcept
{
    return event.source == MenuInputSource::ModalMessage;
}

#if DXUI_MENU_SINK_DIAGNOSTICS
[[nodiscard]] const wchar_t* TraceInputSourceName(MenuInputSource source) noexcept
{
    switch (source)
    {
        case MenuInputSource::ModalMessage: return L"ModalMessage";
        case MenuInputSource::PopupWndProc: return L"PopupWndProc";
    }
    return L"unknown";
}

[[nodiscard]] const wchar_t* TracePointerKindName(MenuPointerKind kind) noexcept
{
    switch (kind)
    {
        case MenuPointerKind::Move: return L"Move";
        case MenuPointerKind::LeftDown: return L"LeftDown";
        case MenuPointerKind::LeftUp: return L"LeftUp";
        case MenuPointerKind::RightDown: return L"RightDown";
        case MenuPointerKind::RightUp: return L"RightUp";
        case MenuPointerKind::Wheel: return L"Wheel";
    }
    return L"unknown";
}

[[nodiscard]] const wchar_t* TraceKeyboardKindName(MenuKeyboardKind kind) noexcept
{
    switch (kind)
    {
        case MenuKeyboardKind::Up: return L"Up";
        case MenuKeyboardKind::Down: return L"Down";
        case MenuKeyboardKind::Left: return L"Left";
        case MenuKeyboardKind::Right: return L"Right";
        case MenuKeyboardKind::Home: return L"Home";
        case MenuKeyboardKind::End: return L"End";
        case MenuKeyboardKind::Enter: return L"Enter";
        case MenuKeyboardKind::Space: return L"Space";
        case MenuKeyboardKind::Escape: return L"Escape";
        case MenuKeyboardKind::Tab: return L"Tab";
        case MenuKeyboardKind::F10: return L"F10";
        case MenuKeyboardKind::Alt: return L"Alt";
        case MenuKeyboardKind::Mnemonic: return L"Mnemonic";
    }
    return L"unknown";
}

[[nodiscard]] const wchar_t* TraceDispositionName(MenuInputDisposition disposition) noexcept
{
    switch (disposition)
    {
        case MenuInputDisposition::Ignored: return L"Ignored";
        case MenuInputDisposition::Consumed: return L"Consumed";
        case MenuInputDisposition::HoverChanged: return L"HoverChanged";
        case MenuInputDisposition::Dismissed: return L"Dismissed";
        case MenuInputDisposition::Invoked: return L"Invoked";
        case MenuInputDisposition::SwitchedRoot: return L"SwitchedRoot";
    }
    return L"unknown";
}

[[nodiscard]] uint64_t TraceOptionalSizeValue(std::optional<size_t> value) noexcept
{
    return value.has_value() ? static_cast<uint64_t>(value.value()) : UINT64_MAX;
}
#endif

// ---------------------------------------------------------------------------
// Window class registration
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Window class registration — WndProc delegates to ControlHost
// ---------------------------------------------------------------------------

#if DXUI_ENABLE_DIAGNOSTICS
// A test probe of a popup that lives on another thread is answered by that thread, into this state, which the caller and the
// probe's payload share. The caller waits a bounded time and then gives up; an answer that comes later lands here, never in the
// caller's frame, and a payload the popup thread never takes is freed with its window.
template <class Result> struct MenuDebugDispatch
{
    MenuDebugDispatch()                                    = default;
    MenuDebugDispatch(const MenuDebugDispatch&)            = delete;
    MenuDebugDispatch& operator=(const MenuDebugDispatch&) = delete;
    MenuDebugDispatch(MenuDebugDispatch&&)                 = delete;
    MenuDebugDispatch& operator=(MenuDebugDispatch&&)      = delete;

    enum class State : uint8_t
    {
        Pending,
        Taken,
        Abandoned,
    };

    std::atomic<State> state{State::Pending};
    Result result{};
    wil::unique_event_nothrow completedEvent;
    bool succeeded = false;
};

template <class Result> struct MenuDebugPayload
{
    MenuDebugPayload()                                   = default;
    MenuDebugPayload(const MenuDebugPayload&)            = delete;
    MenuDebugPayload& operator=(const MenuDebugPayload&) = delete;
    MenuDebugPayload(MenuDebugPayload&&)                 = delete;
    MenuDebugPayload& operator=(MenuDebugPayload&&)      = delete;

    ~MenuDebugPayload() noexcept
    {
        if (! dispatch)
        {
            return;
        }
        // A payload freed unanswered leaves its dispatch abandoned; an answered one was taken. Either way its caller wakes.
        auto expected = MenuDebugDispatch<Result>::State::Pending;
        static_cast<void>(dispatch->state.compare_exchange_strong(
            expected, MenuDebugDispatch<Result>::State::Abandoned, std::memory_order_acq_rel, std::memory_order_acquire));
        if (dispatch->completedEvent)
        {
            static_cast<void>(SetEvent(dispatch->completedEvent.get()));
        }
    }

    std::shared_ptr<MenuDebugDispatch<Result>> dispatch;
    size_t itemIndex = 0u;
    WindowHostBitmapCapture backdrop; // What DebugSetContextMenuPopupBackdropCapture installs.
};

[[nodiscard]] bool IsAnotherThreadsWindow(HWND hwnd) noexcept
{
    const DWORD windowThreadId = GetWindowThreadProcessId(hwnd, nullptr);
    return windowThreadId != 0 && windowThreadId != GetCurrentThreadId();
}

// Asks the thread of `hwnd` for `out` and waits at most `timeoutMs`. A posted probe reaches the menu loop's priority peek, ahead of
// owner traffic; a sent one is answered at the popup thread's next message retrieval, as SendMessage would be.
template <class Result>
[[nodiscard]] bool CallMenuPopupDebugProbe(
    HWND hwnd, WndMsg::RegisteredMessage probe, bool post, DWORD timeoutMs, size_t itemIndex, const WindowHostBitmapCapture* backdrop, Result& out) noexcept
{
    using Dispatch = MenuDebugDispatch<Result>;
    if (! probe)
    {
        return false;
    }
    auto dispatch = std::shared_ptr<Dispatch>(new (std::nothrow) Dispatch());
    if (! dispatch)
    {
        return false;
    }
    dispatch->completedEvent.reset(CreateEventW(nullptr, TRUE, FALSE, nullptr));
    if (! dispatch->completedEvent)
    {
        return false;
    }
    auto payload = std::unique_ptr<MenuDebugPayload<Result>>(new (std::nothrow) MenuDebugPayload<Result>());
    if (! payload)
    {
        return false;
    }
    payload->dispatch  = dispatch;
    payload->itemIndex = itemIndex;
    if (backdrop)
    {
        try
        {
            payload->backdrop = *backdrop;
        }
        catch (const std::bad_alloc&)
        {
            return false; // A capture that cannot be copied is not installed.
        }
    }

    const bool answered =
        post ? PostMessagePayload(hwnd, probe.value, 0, std::move(payload)) && WaitForSingleObject(dispatch->completedEvent.get(), timeoutMs) == WAIT_OBJECT_0
             : SendMessagePayload(hwnd, probe.value, 0, std::move(payload), timeoutMs) &&
                   WaitForSingleObject(dispatch->completedEvent.get(), 0u) == WAIT_OBJECT_0;
    if (! answered)
    {
        auto expected = Dispatch::State::Pending;
        if (dispatch->state.compare_exchange_strong(expected, Dispatch::State::Abandoned, std::memory_order_acq_rel, std::memory_order_acquire))
        {
            return false;
        }
        // The popup thread took the probe and may be answering now: its answer counts only once it is complete.
        if (expected != Dispatch::State::Taken || WaitForSingleObject(dispatch->completedEvent.get(), 0u) != WAIT_OBJECT_0)
        {
            return false;
        }
    }
    if (! dispatch->succeeded)
    {
        return false;
    }
    out = std::move(dispatch->result);
    return true;
}

// Answers a probe on the popup's own thread, into its dispatch, unless its caller has given up already.
template <class Result, class Answer> [[nodiscard]] LRESULT AnswerMenuPopupDebugProbe(LPARAM lp, Answer&& answer) noexcept
{
    using Dispatch = MenuDebugDispatch<Result>;
    auto payload   = TakeMessagePayload<MenuDebugPayload<Result>>(lp);
    if (! payload || ! payload->dispatch)
    {
        return FALSE;
    }
    auto expected = Dispatch::State::Pending;
    if (! payload->dispatch->state.compare_exchange_strong(expected, Dispatch::State::Taken, std::memory_order_acq_rel, std::memory_order_acquire))
    {
        return FALSE;
    }
    payload->dispatch->succeeded = answer(*payload, payload->dispatch->result);
    return payload->dispatch->succeeded ? TRUE : FALSE;
}

std::atomic<HANDLE> g_menuDebugStateHandlerEnteredEvent{nullptr};
std::atomic<HANDLE> g_menuDebugStateHandlerReleaseEvent{nullptr};

bool TryGetMenuPopupItemText(const MenuPopup& popup, size_t itemIndex, std::wstring& outText)
{
    outText.clear();
    if (itemIndex >= popup.itemCount)
    {
        return false;
    }

    outText = ParseMenuLabel(DecodeMenuItemText(popup.items[itemIndex]).labelText).displayText;
    return true;
}

#endif

static LRESULT CALLBACK MenuWndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    if (msg == WM_NCCREATE)
    {
        InitPostedPayloadWindow(hwnd);
    }
    if (msg == WM_MOUSEACTIVATE)
    {
        return MA_NOACTIVATE;
    }

    auto* popup = reinterpret_cast<MenuPopup*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (popup)
    {
        MenuController* const controller = popup->controller;
        if (WndMsg::MenuPopupAccessibleInvoke().Matches(msg))
        {
            auto request       = TakeMessagePayload<MenuAccessibilityRequest>(lp);
            const size_t index = request ? request->index : SIZE_MAX;
            if (request && request->target == hwnd && controller && controller->running && index < popup->itemCount && popup->IsNavigableItem(index))
            {
                // Close the submenus above this popup; a popup outside the chain (never expected) is left alone.
                while (controller->popups.size() > 1u && controller->GetTopmostPopup() != popup)
                    controller->CloseTopmostSubmenu();
                if (controller->GetTopmostPopup() != popup)
                    return 0;
                popup->keyboardIndex = index;
                static_cast<void>(ProcessMenuPopupMessage(*controller, hwnd, WM_KEYDOWN, VK_RETURN, 0));
                if (controller->asyncSession && ! controller->running)
                    FinalizeAsyncMenuController(*controller);
            }
            return 0;
        }
        if (WndMsg::MenuPopupAccessibleFocus().Matches(msg))
        {
            auto request = TakeMessagePayload<MenuAccessibilityRequest>(lp);
            if (request && request->target == hwnd)
            {
                InvalidatePopup(*popup);
                Control* const root = popup->host.GetRoot();
                if (root && request->index < root->GetLogicalChildCount())
                {
                    Control* const focused = root->GetLogicalChild(request->index);
                    if (popup->keyboardIndex == request->index && popup->host.GetFocusControl() == focused)
                        RaiseWindowHostFocusChanged(hwnd, focused);
                }
            }
            return 0;
        }
        if (WndMsg::MenuPopupForwardCursor().Matches(msg))
        {
            // Read everything first: the forwarded WM_SETCURSOR may run code that closes the menu and frees both.
            if (! controller || ! controller->running || ! controller->cursorForwardPending)
                return 0;
            controller->cursorForwardPending = false;
            const POINT point                = controller->cursorForwardPoint;
            if (! ForwardSetCursorToThreadWindowAt(point))
                ShowArrowCursor();
            return 0;
        }
        if (WndMsg::MenuPopupDeferredFinalize().Matches(msg))
        {
            // The window operation that delivered the failed reflow has unwound. A running session
            // (for example one that reused this HWND) ignores a stale request.
            if (controller && controller->asyncSession && ! controller->running)
                FinalizeAsyncMenuController(*controller);
            return 0;
        }
#if DXUI_ENABLE_DIAGNOSTICS
        // Cross-thread test probes, answered here on the popup's thread into a dispatch their caller shares (see
        // CallMenuPopupDebugProbe). The same-thread Debug* functions below take their direct path on this thread.
        if (WndMsg::MenuPopupDebugCaptureBitmap().Matches(msg))
        {
            return AnswerMenuPopupDebugProbe<WindowHostBitmapCapture>(
                lp, [&](MenuDebugPayload<WindowHostBitmapCapture>&, WindowHostBitmapCapture& out) { return popup->host.DebugCaptureBitmap(out); });
        }
        if (WndMsg::MenuPopupDebugGetItemText().Matches(msg))
        {
            return AnswerMenuPopupDebugProbe<std::wstring>(
                lp, [&](MenuDebugPayload<std::wstring>& request, std::wstring& out) { return TryGetMenuPopupItemText(*popup, request.itemIndex, out); });
        }
        if (WndMsg::MenuPopupDebugGetState().Matches(msg))
        {
            // A test can wedge this handler, standing for a popup thread that stops answering.
            const HANDLE enteredEvent = g_menuDebugStateHandlerEnteredEvent.load(std::memory_order_acquire);
            const HANDLE releaseEvent = g_menuDebugStateHandlerReleaseEvent.load(std::memory_order_acquire);
            if (enteredEvent)
            {
                static_cast<void>(SetEvent(enteredEvent));
            }
            if (releaseEvent)
            {
                static_cast<void>(WaitForSingleObject(releaseEvent, kMenuDebugProbeTimeoutMs + 2000u));
            }
            return AnswerMenuPopupDebugProbe<ContextMenuPopupDebugState>(
                lp, [&](MenuDebugPayload<ContextMenuPopupDebugState>&, ContextMenuPopupDebugState& out) { return DebugGetContextMenuPopupState(hwnd, out); });
        }
        if (WndMsg::MenuPopupDebugGetItemRect().Matches(msg))
        {
            return AnswerMenuPopupDebugProbe<D2D1_RECT_F>(
                lp, [&](MenuDebugPayload<D2D1_RECT_F>& request, D2D1_RECT_F& out) { return DebugGetContextMenuPopupItemRect(hwnd, request.itemIndex, out); });
        }
        if (WndMsg::MenuPopupDebugGetItemPaint().Matches(msg))
        {
            return AnswerMenuPopupDebugProbe<ContextMenuPopupItemPaintDebugState>(
                lp, [&](MenuDebugPayload<ContextMenuPopupItemPaintDebugState>& request, ContextMenuPopupItemPaintDebugState& out) {
                return DebugGetContextMenuPopupItemPaint(hwnd, request.itemIndex, out);
            });
        }
        if (WndMsg::MenuPopupDebugGetItemLayout().Matches(msg))
        {
            return AnswerMenuPopupDebugProbe<ContextMenuPopupItemLayoutDebugState>(
                lp, [&](MenuDebugPayload<ContextMenuPopupItemLayoutDebugState>& request, ContextMenuPopupItemLayoutDebugState& out) {
                return DebugGetContextMenuPopupItemLayout(hwnd, request.itemIndex, out);
            });
        }
        if (WndMsg::MenuPopupDebugSetBackdrop().Matches(msg))
        {
            return AnswerMenuPopupDebugProbe<bool>(lp,
                                                   [&](MenuDebugPayload<bool>& request, bool&)
            {
                const WindowHostBitmapCapture& capture = request.backdrop;
                if (capture.widthPx == 0u || capture.heightPx == 0u || capture.bgraPixels.empty())
                {
                    return false;
                }
                popup->backdropSnapshot.capture      = std::move(request.backdrop);
                popup->backdropSnapshot.cachedBitmap = nullptr;
                popup->backdropSnapshot.cachedDevice = nullptr;
                popup->usesAppBackdropBlur           = true;
                popup->host.Invalidate();
                return true;
            });
        }
#endif
        if (msg == WM_NCDESTROY)
        {
            popup->host.Detach();
            static_cast<void>(DrainPostedPayloadsForWindow(hwnd));
            if (popup->hwnd == hwnd)
            {
                popup->hwnd = nullptr;
            }
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, 0);
            // Finalize only for external teardown (e.g. the owner window being
            // destroyed while the async menu is open). Controller-initiated
            // destroys (submenu close, chain replacement, root switch) reach this
            // handler synchronously from DestroyMenuPopupWindow's DestroyWindow
            // call; finalizing here would delete the controller and its popups
            // while that caller is still using them.
            if (controller && controller->asyncSession && ! controller->asyncFinalizing && ! controller->destroyingPopupWindow)
            {
                // The owner may be in the middle of its own DestroyWindow: no window is messaged to choose a cursor.
                controller->cursorChosen = false;
                controller->Dismiss();
                FinalizeAsyncMenuController(*controller);
            }
            return DefWindowProcW(hwnd, msg, wp, lp);
        }
        if (msg == WM_DPICHANGED || msg == WM_DPICHANGED_AFTERPARENT)
        {
            const UINT dpi = ResolveMenuPopupMessageDpi(hwnd, msg, wp);
            RelayoutMenuPopupForDpi(*popup, dpi, msg == WM_DPICHANGED ? reinterpret_cast<const RECT*>(lp) : nullptr);
            return 0;
        }
        if (msg == WM_NCHITTEST)
        {
            const POINT screenPoint{GET_X_LPARAM(lp), GET_Y_LPARAM(lp)};
            if (! PtInRect(&popup->surfaceRectPx, screenPoint))
            {
                return HTTRANSPARENT;
            }

            return HTCLIENT;
        }

        if (controller && controller->running && (! controller->asyncSession || controller->asyncInteractionActive) && ! controller->asyncFinalizing &&
            ! controller->destroyingPopupWindow)
        {
            const bool dismissForActivation = (msg == WM_ACTIVATEAPP && wp == FALSE) ||
                                              (msg == WM_ACTIVATE && LOWORD(static_cast<DWORD_PTR>(wp)) == WA_INACTIVE) ||
                                              (msg == WM_NCACTIVATE && wp == FALSE);
            const bool dismissForCancel     = msg == WM_CANCELMODE;
            if (dismissForActivation || dismissForCancel)
            {
                controller->Dismiss();
                if (controller->asyncSession && controller->asyncInteractionActive)
                    FinalizeAsyncMenuController(*controller);
                return 0;
            }

            const bool dismissForCaptureLoss =
                msg == WM_CAPTURECHANGED && (! controller->GetRootPopup() || reinterpret_cast<HWND>(lp) != controller->GetRootPopup()->hwnd);
            if (controller->asyncSession && controller->asyncInteractionActive && dismissForCaptureLoss)
            {
                controller->Dismiss();
                FinalizeAsyncMenuController(*controller);
                return 0;
            }
        }

        if (controller && ProcessMenuPopupMessage(*controller, hwnd, msg, wp, lp))
        {
            if (controller->asyncSession && ! controller->running)
            {
                FinalizeAsyncMenuController(*controller);
            }
            return 0;
        }

        if (msg == WM_SETFOCUS)
        {
            // Native activation restores only a row that keyboard or UIA navigation chose. The host's
            // first-focusable fallback would otherwise make row 0 the keyboard target of a pointer-opened
            // menu (Enter would invoke it) and announce it as focused.
            SynchronizeMenuAccessibility(*popup);
            if (! popup->host.GetFocusControl())
            {
                return 0;
            }
        }

        bool handled   = false;
        LRESULT result = popup->host.HandleMessage(hwnd, msg, wp, lp, handled);
        if (handled)
            return result;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

void EnsureMenuWindowClass(HINSTANCE hInstance)
{
    if (s_classRegistered.load(std::memory_order_acquire))
    {
        return;
    }

    WNDCLASSEXW wc{};
    wc.cbSize        = sizeof(wc);
    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = MenuWndProc;
    wc.hInstance     = hInstance;
    wc.hCursor       = LoadCursorW(nullptr, IDC_ARROW);
    wc.lpszClassName = kMenuWindowClass;
    if (RegisterClassExW(&wc) != 0 || GetLastError() == ERROR_CLASS_ALREADY_EXISTS)
    {
        s_classRegistered.store(true, std::memory_order_release);
        return;
    }

    Debug::ErrorWithLastError(L"DxUi: failed to register menu window class.");
}

// ---------------------------------------------------------------------------
// Compute menu content size
// ---------------------------------------------------------------------------

[[nodiscard]] D2D1_SIZE_F ComputeMenuSize(
    const MenuFlyoutItem* items, size_t count, ControlHost& host, float* outAcceleratorColumnWidthDip = nullptr, bool* outHasSubmenuItems = nullptr) noexcept
{
    const ThemePalette& theme   = host.GetTheme();
    const float itemHeightDip   = ResolveMenuItemHeightDip(theme);
    const float headerHeightDip = ResolveMenuHeaderHeightDip(theme);
    float maxTextWidth          = 0.0f;
    float maxAccelWidth         = 0.0f;
    float totalHeight           = kMenuPaddingTopDip + kMenuPaddingBottomDip;
    bool hasSubmenu             = false;
    bool hasSlider              = false;

    for (size_t i = 0; i < count; ++i)
    {
        const auto& item = items[i];
        if (HasMenuDescription(item))
        {
            // Detailed entries use the bounded menu width; their complete fields are
            // measured below after monitor/scrollbar constraints are known.
            maxTextWidth = kMenuMaxWidthDip;
        }
        switch (item.kind)
        {
            case MenuItemKind::Separator: totalHeight += kSeparatorHeightDip; break;
            case MenuItemKind::Header:
                totalHeight += headerHeightDip;
                // Measure header text
                if (auto* fmt = host.GetTextFormat(FontRole::Small))
                {
                    const ParsedMenuLabel label = ParseMenuLabel(DecodeMenuItemText(item).labelText);
                    wil::com_ptr<IDWriteTextLayout> layout;
                    if (auto* factory = host.GetWriteFactory())
                    {
                        if (SUCCEEDED(factory->CreateTextLayout(
                                label.displayText.c_str(), static_cast<UINT32>(label.displayText.size()), fmt, kTextMeasureWidthDip, headerHeightDip, &layout)))
                        {
                            DWRITE_TEXT_METRICS metrics{};
                            if (SUCCEEDED(layout->GetMetrics(&metrics)))
                            {
                                maxTextWidth = (std::max)(maxTextWidth, metrics.widthIncludingTrailingWhitespace);
                            }
                        }
                    }
                }
                break;
            case MenuItemKind::Slider:
                totalHeight += kSliderItemHeightDip;
                hasSlider = true;
                if (auto* fmt = host.GetTextFormat(FontRole::Body))
                {
                    const DecodedMenuItemText decoded = DecodeMenuItemText(item);
                    const ParsedMenuLabel label       = ParseMenuLabel(decoded.labelText);
                    wil::com_ptr<IDWriteTextLayout> layout;
                    if (auto* factory = host.GetWriteFactory())
                    {
                        if (SUCCEEDED(factory->CreateTextLayout(
                                label.displayText.c_str(), static_cast<UINT32>(label.displayText.size()), fmt, kTextMeasureWidthDip, itemHeightDip, &layout)))
                        {
                            DWRITE_TEXT_METRICS metrics{};
                            if (SUCCEEDED(layout->GetMetrics(&metrics)))
                            {
                                maxTextWidth = (std::max)(maxTextWidth, metrics.widthIncludingTrailingWhitespace);
                            }
                        }

                        if (! decoded.acceleratorText.empty())
                        {
                            if (SUCCEEDED(factory->CreateTextLayout(decoded.acceleratorText.data(),
                                                                    static_cast<UINT32>(decoded.acceleratorText.size()),
                                                                    fmt,
                                                                    kTextMeasureWidthDip,
                                                                    itemHeightDip,
                                                                    &layout)))
                            {
                                DWRITE_TEXT_METRICS metrics{};
                                if (SUCCEEDED(layout->GetMetrics(&metrics)))
                                {
                                    maxAccelWidth = (std::max)(maxAccelWidth, metrics.widthIncludingTrailingWhitespace);
                                }
                            }
                        }
                    }
                }
                break;
            case MenuItemKind::Info:
            case MenuItemKind::Standard:
            case MenuItemKind::Toggle:
            case MenuItemKind::Radio:
                totalHeight += itemHeightDip;
                if (! item.children.empty())
                    hasSubmenu = true;
                // Measure item text
                if (auto* fmt = host.GetTextFormat(FontRole::Body))
                {
                    const DecodedMenuItemText decoded = DecodeMenuItemText(item);
                    const ParsedMenuLabel label       = ParseMenuLabel(decoded.labelText);
                    wil::com_ptr<IDWriteTextLayout> layout;
                    if (auto* factory = host.GetWriteFactory())
                    {
                        if (SUCCEEDED(factory->CreateTextLayout(
                                label.displayText.c_str(), static_cast<UINT32>(label.displayText.size()), fmt, kTextMeasureWidthDip, itemHeightDip, &layout)))
                        {
                            DWRITE_TEXT_METRICS metrics{};
                            if (SUCCEEDED(layout->GetMetrics(&metrics)))
                            {
                                maxTextWidth = (std::max)(maxTextWidth, metrics.widthIncludingTrailingWhitespace);
                            }
                        }
                        // Measure accelerator text
                        if (! decoded.acceleratorText.empty())
                        {
                            if (SUCCEEDED(factory->CreateTextLayout(decoded.acceleratorText.data(),
                                                                    static_cast<UINT32>(decoded.acceleratorText.size()),
                                                                    fmt,
                                                                    kTextMeasureWidthDip,
                                                                    itemHeightDip,
                                                                    &layout)))
                            {
                                DWRITE_TEXT_METRICS metrics{};
                                if (SUCCEEDED(layout->GetMetrics(&metrics)))
                                {
                                    maxAccelWidth = (std::max)(maxAccelWidth, metrics.widthIncludingTrailingWhitespace);
                                }
                            }
                        }
                    }
                }
                break;
        }
    }

    if (outAcceleratorColumnWidthDip)
    {
        *outAcceleratorColumnWidthDip = maxAccelWidth;
    }
    if (outHasSubmenuItems)
    {
        *outHasSubmenuItems = hasSubmenu;
    }

    float width = kTextLeftPaddingDip + maxTextWidth + 16.0f; // gap after text
    if (maxAccelWidth > 0.0f)
        width += kTextToAccelGapDip + maxAccelWidth + kAccelRightPaddingDip;
    if (hasSubmenu)
        width += kChevronAreaWidthDip;
    width += kMenuBorderDip * 2.0f;
    if (hasSlider)
        width = (std::max)(width, kSliderMenuMinWidthDip);

    width = std::clamp(width, kMenuMinWidthDip, kMenuMaxWidthDip);

    return D2D1::SizeF(width, totalHeight);
}

// How the small text format's font differs from the body format's: what a row layout built from the body format must override
// on the description range for DirectWrite to shape the description as a layout made from the small format would.
struct MenuDescriptionFont
{
    std::wstring family;
    std::wstring locale;
    wil::com_ptr<IDWriteFontCollection> collection;
    float size                  = 0.0f;
    float tabStop               = 0.0f;
    DWRITE_FONT_WEIGHT weight   = DWRITE_FONT_WEIGHT_NORMAL;
    DWRITE_FONT_STYLE style     = DWRITE_FONT_STYLE_NORMAL;
    DWRITE_FONT_STRETCH stretch = DWRITE_FONT_STRETCH_NORMAL;
    bool overridesFamily        = false;
    bool overridesCollection    = false;
    bool overridesLocale        = false;
    bool overridesSize          = false;
    bool overridesWeight        = false;
    bool overridesStyle         = false;
    bool overridesStretch       = false;
    bool overridesTabStop       = false;
};

[[nodiscard]] bool ReadMenuFormatNames(IDWriteTextFormat& format, std::wstring& family, std::wstring& locale)
{
    family.assign(static_cast<size_t>(format.GetFontFamilyNameLength()) + 1u, L'\0');
    locale.assign(static_cast<size_t>(format.GetLocaleNameLength()) + 1u, L'\0');
    if (FAILED(format.GetFontFamilyName(family.data(), static_cast<UINT32>(family.size()))) ||
        FAILED(format.GetLocaleName(locale.data(), static_cast<UINT32>(locale.size()))))
        return false;
    family.resize(std::wcslen(family.c_str()));
    locale.resize(std::wcslen(locale.c_str()));
    return true;
}

// Every property a DirectWrite layout holds per range is read back from the formats rather than assumed, so a host that
// configures its small format differently still gets the small format's description. Properties a layout holds for all its text
// (alignment, wrapping, directions, line spacing) come from the body format: the host creates both formats alike, and a test
// holds them to it.
[[nodiscard]] bool ReadMenuDescriptionFont(IDWriteTextFormat& bodyFormat, IDWriteTextFormat& smallFormat, MenuDescriptionFont& font)
{
    std::wstring bodyFamily;
    std::wstring bodyLocale;
    wil::com_ptr<IDWriteFontCollection> bodyCollection;
    if (! ReadMenuFormatNames(bodyFormat, bodyFamily, bodyLocale) || ! ReadMenuFormatNames(smallFormat, font.family, font.locale) ||
        FAILED(bodyFormat.GetFontCollection(bodyCollection.put())) || FAILED(smallFormat.GetFontCollection(font.collection.put())))
        return false;
    font.size                = smallFormat.GetFontSize();
    font.tabStop             = smallFormat.GetIncrementalTabStop();
    font.weight              = smallFormat.GetFontWeight();
    font.style               = smallFormat.GetFontStyle();
    font.stretch             = smallFormat.GetFontStretch();
    font.overridesFamily     = font.family != bodyFamily;
    font.overridesLocale     = font.locale != bodyLocale;
    font.overridesCollection = font.collection.get() != bodyCollection.get();
    font.overridesSize       = font.size != bodyFormat.GetFontSize();
    font.overridesWeight     = font.weight != bodyFormat.GetFontWeight();
    font.overridesStyle      = font.style != bodyFormat.GetFontStyle();
    font.overridesStretch    = font.stretch != bodyFormat.GetFontStretch();
    font.overridesTabStop    = font.tabStop != bodyFormat.GetIncrementalTabStop();
    return true;
}

// The spacer paragraph's font size before any measurement. Font metrics scale with the size, so one measurement at any size
// tells what size gives the wanted height.
constexpr float kDescriptionSpacerReferenceSizeDip = kDescriptionGapDip;
// How far the spacer's height may be from the wanted one, in DIPs. DirectWrite reports heights as floats: the calibration
// reaches them to a few millionths, and this is far below what shifts a glyph onto another device pixel.
constexpr float kDescriptionSpacerToleranceDip = 1.0f / 8192.0f;

// What preparing a popup's described rows carries from one row to the next.
struct MenuDescriptionPreparation
{
    MenuDescriptionFont font;
    // The spacer size the last row settled on. A row whose label is as tall starts from it and needs no correction, so the
    // first measurement confirms it and the row's layout is computed once.
    float spacerSizeDip = kDescriptionSpacerReferenceSizeDip;
    std::vector<DWRITE_LINE_METRICS> lines; // Scratch for the measurements.
};

// Creates the row's layout: the label, the spacer paragraph and the description, wrapped at textWidthDip. The caller measures it.
[[nodiscard]] bool CreateMenuDescriptionLayout(IDWriteFactory& factory,
                                               IDWriteTextFormat& bodyFormat,
                                               const MenuDescriptionFont& font,
                                               float spacerSizeDip,
                                               std::wstring_view primary,
                                               std::wstring_view secondary,
                                               float textWidthDip,
                                               MenuDescriptionLayout& row)
{
    // One newline ends the label's paragraph and one is the spacer paragraph. A label never ends in a carriage return that the
    // first newline would join into a line break of its own: DecodeMenuItemText trims its trailing white space.
    constexpr size_t kSeparatorLength = 2u;
    if (primary.size() > (std::numeric_limits<UINT32>::max)() || secondary.size() > (std::numeric_limits<UINT32>::max)() - primary.size() - kSeparatorLength)
        return false;
    std::wstring text;
    text.reserve(primary.size() + kSeparatorLength + secondary.size());
    text.append(primary).append(L"\n\n").append(secondary);

    wil::com_ptr<IDWriteTextLayout> layout;
    const DWRITE_TRIMMING trimming{DWRITE_TRIMMING_GRANULARITY_NONE, 0, 0};
    if (FAILED(factory.CreateTextLayout(text.data(), static_cast<UINT32>(text.size()), &bodyFormat, textWidthDip, 1000000.0f, layout.put())) ||
        FAILED(layout->SetWordWrapping(DWRITE_WORD_WRAPPING_EMERGENCY_BREAK)) || FAILED(layout->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_NEAR)) ||
        FAILED(layout->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING)) || FAILED(layout->SetTrimming(&trimming, nullptr)))
        return false;

    const UINT32 spacerPosition = static_cast<UINT32>(primary.size()) + 1u;
    const DWRITE_TEXT_RANGE description{spacerPosition + 1u, static_cast<UINT32>(secondary.size())};
    if ((font.overridesFamily && FAILED(layout->SetFontFamilyName(font.family.c_str(), description))) ||
        (font.overridesCollection && FAILED(layout->SetFontCollection(font.collection.get(), description))) ||
        (font.overridesLocale && FAILED(layout->SetLocaleName(font.locale.c_str(), description))) ||
        (font.overridesSize && FAILED(layout->SetFontSize(font.size, description))) ||
        (font.overridesWeight && FAILED(layout->SetFontWeight(font.weight, description))) ||
        (font.overridesStyle && FAILED(layout->SetFontStyle(font.style, description))) ||
        (font.overridesStretch && FAILED(layout->SetFontStretch(font.stretch, description))) ||
        // A tab stop is a property of the whole layout; only the description can hold a tab, since the label ends at the first one.
        (font.overridesTabStop && FAILED(layout->SetIncrementalTabStop(font.tabStop))) ||
        FAILED(layout->SetFontSize(spacerSizeDip, DWRITE_TEXT_RANGE{spacerPosition, 1u})))
        return false;

    row.layout           = std::move(layout);
    row.description      = description;
    row.spacerPosition   = spacerPosition;
    row.spacerSizeDip    = spacerSizeDip;
    row.descriptionBrush = nullptr;
    return true;
}

// Measures the row's layout at its current width and sizes the spacer paragraph so that the description begins where a layout
// of its own would be drawn: kDescriptionGapDip below the label's height rounded up to whole DIPs. The heights are the sums of
// the layout's line heights, as a separate layout reports its own, so the rounded heights agree with two separate layouts'.
// False when DirectWrite cannot report the lines or the spacer cannot reach its height. `lines` is scratch.
[[nodiscard]] bool MeasureMenuDescriptionRow(MenuDescriptionLayout& row, std::vector<DWRITE_LINE_METRICS>& lines)
{
    IDWriteTextLayout* const layout = row.layout.get();
    // The first pass may find the spacer at another height: its size was chosen for another label height or none. The
    // correction is exact to the float, so the second pass confirms it; the rest is margin.
    for (int pass = 0; pass < 4; ++pass)
    {
        UINT32 lineCount = 0u;
        static_cast<void>(layout->GetLineMetrics(nullptr, 0u, &lineCount)); // Reports the count with E_NOT_SUFFICIENT_BUFFER.
        lines.assign(lineCount, DWRITE_LINE_METRICS{});
        if (lineCount == 0u || FAILED(layout->GetLineMetrics(lines.data(), lineCount, &lineCount)))
            return false;
        MenuFieldMetrics primary;
        MenuFieldMetrics secondary;
        float spacerHeight = 0.0f;
        UINT32 position    = 0u;
        for (const DWRITE_LINE_METRICS& line : lines)
        {
            if (position < row.spacerPosition)
            {
                primary.height += line.height;
                ++primary.lineCount;
            }
            else if (position == row.spacerPosition)
                spacerHeight = line.height;
            else
            {
                secondary.height += line.height;
                ++secondary.lineCount;
            }
            position += line.length;
        }
        if (! (spacerHeight > 0.0f))
            return false;
        const float wantedHeight = std::ceil(primary.height) - primary.height + kDescriptionGapDip;
        if (std::abs(spacerHeight - wantedHeight) <= kDescriptionSpacerToleranceDip)
        {
            row.primaryMetrics   = primary;
            row.secondaryMetrics = secondary;
            row.heightDip        = 2.0f * kDescriptionPaddingDip + std::ceil(primary.height) + kDescriptionGapDip + std::ceil(secondary.height);
            return true;
        }
        row.spacerSizeDip *= wantedHeight / spacerHeight;
        if (! (row.spacerSizeDip > 0.0f) || FAILED(layout->SetFontSize(row.spacerSizeDip, DWRITE_TEXT_RANGE{row.spacerPosition, 1u})))
            return false;
    }
    return false;
}

[[nodiscard]] bool PrepareMenuDescriptionLayouts(MenuPopup& popup, float contentWidthDip) noexcept
{
    const bool hasDescriptions = std::any_of(popup.items, popup.items + popup.itemCount, HasMenuDescription);
    if (! hasDescriptions)
    {
        popup.RebuildItemOffsets();
        return true;
    }
    try
    {
        auto* factory     = popup.host.GetWriteFactory();
        auto* bodyFormat  = popup.host.GetTextFormat(FontRole::Body);
        auto* smallFormat = popup.host.GetTextFormat(FontRole::Small);
        MenuDescriptionPreparation preparation;
        if (! factory || ! bodyFormat || ! smallFormat || ! ReadMenuDescriptionFont(*bodyFormat, *smallFormat, preparation.font))
            return false;
        std::vector<MenuDescriptionLayout> prepared(popup.itemCount);
        size_t layoutCount = 0u;
        for (size_t i = 0; i < popup.itemCount; ++i)
        {
            const auto& item = popup.items[i];
            if (! HasMenuDescription(item))
                continue;
            auto& row                 = prepared[i];
            const auto decoded        = DecodeMenuItemText(item);
            const auto label          = ParseMenuLabel(decoded.labelText);
            const float reservedAccel = decoded.acceleratorText.empty() ? 0.0f : popup.acceleratorColumnWidthDip + kTextToAccelGapDip;
            const float textWidth     = (std::max)(1.0f,
                                                   contentWidthDip - kTextLeftPaddingDip - kAccelRightPaddingDip -
                                                       (popup.hasSubmenuItems ? kChevronAreaWidthDip : 0.0f) - reservedAccel);
            if (! CreateMenuDescriptionLayout(
                    *factory, *bodyFormat, preparation.font, preparation.spacerSizeDip, label.displayText, item.secondaryText, textWidth, row) ||
                ! MeasureMenuDescriptionRow(row, preparation.lines))
                return false;
            preparation.spacerSizeDip = row.spacerSizeDip;
            row.textWidthDip          = textWidth;
            ++layoutCount;
        }
        popup.descriptionLayouts = std::move(prepared);
        popup.liveRowLayouts     = Detail::LiveResourceCount(Detail::LiveResource::MenuRowLayout, layoutCount);
        popup.RebuildItemOffsets();
        popup.contentHeightDip = popup.itemOffsetsDip.back() + kMenuPaddingBottomDip;
        ++popup.descriptionPreparationCount;
        return true;
    }
    catch (const std::bad_alloc&)
    {
        // Opening/reflow fails without publishing partially measured rows.
        return false;
    }
}

[[nodiscard]] bool PrepareMenuDescriptionSize(MenuPopup& popup, D2D1_SIZE_F& sizeDip, const RECT& availableRectPx) noexcept
{
    if (! std::any_of(popup.items, popup.items + popup.itemCount, HasMenuDescription))
        return true;
    const float width            = popup.PixelToDip(static_cast<float>(availableRectPx.right - availableRectPx.left));
    const int availableHeightPx  = (std::max)(1, static_cast<int>(availableRectPx.bottom - availableRectPx.top));
    const float maxRootHeightDip = (! popup.isSubmenu && popup.controller) ? popup.controller->sessionCallbacks.maxRootHeightDip : 0.0f;
    if (! PrepareMenuDescriptionLayouts(popup, width))
        return false;
    // Decide the lane with the viewport the caller will create: the requested height rounded to
    // whole device pixels inside the work area. NeedsScrollbar applies the same comparison to the
    // final surface, and reserving the lane can only grow the content, so the two agree.
    const float requestedHeightDip = maxRootHeightDip > 0.0f ? (std::min)(popup.contentHeightDip, maxRootHeightDip) : popup.contentHeightDip;
    const int viewportHeightPx     = (std::min)(DipExtentToPixels(requestedHeightDip, popup.dpi), availableHeightPx);
    if (popup.ContentOverflowsViewport(popup.PixelToDip(static_cast<float>(viewportHeightPx))))
    {
        // These layouts were just prepared for this text/font/DPI. Reserving a
        // scrollbar changes only their width: do not allocate a second full set
        // while the first set is still alive. A failed reflow rejects opening
        // or dismisses the existing popup through the caller's failure path.
        try
        {
            std::vector<DWRITE_LINE_METRICS> lines;
            for (auto& row : popup.descriptionLayouts)
            {
                if (! row.layout)
                    continue;
                // The width is absolute, from the width the row was prepared at: never subtracted from the layout's own.
                const float textWidth = (std::max)(1.0f, row.textWidthDip - kScrollbarThicknessDip);
                if (FAILED(row.layout->SetMaxWidth(textWidth)) || ! MeasureMenuDescriptionRow(row, lines))
                    return false;
            }
        }
        catch (const std::bad_alloc&)
        {
            return false;
        }
        popup.RebuildItemOffsets();
        popup.contentHeightDip = popup.itemOffsetsDip.back() + kMenuPaddingBottomDip;
        ++popup.descriptionPreparationCount;
    }
    sizeDip.height = popup.contentHeightDip;
    return true;
}

[[nodiscard]] float ResolveVisibleMenuWidthDip(float contentWidthDip, const MenuController* controller, bool isSubmenu) noexcept
{
    if (isSubmenu || ! controller)
    {
        return contentWidthDip;
    }

    const float minRootWidthDip = controller->sessionCallbacks.minRootWidthDip;
    return std::isfinite(minRootWidthDip) && minRootWidthDip > 0.0f ? (std::max)(contentWidthDip, minRootWidthDip) : contentWidthDip;
}

[[nodiscard]] D2D1_RECT_F GetVisibleItemRect(const MenuPopup& popup, size_t targetIndex) noexcept
{
    D2D1_RECT_F rect = popup.GetItemRect(targetIndex, popup.GetContentWidthDip());
    rect.left += popup.shadowMargins.leftDip;
    rect.right += popup.shadowMargins.leftDip;
    rect.top += popup.shadowMargins.topDip;
    rect.bottom += popup.shadowMargins.topDip;
    rect.top -= popup.scrollOffsetDip;
    rect.bottom -= popup.scrollOffsetDip;
    return rect;
}

[[nodiscard]] D2D1_RECT_F ClampHorizontalRect(float left, float right, float top, float bottom, float minLeft) noexcept
{
    const float resolvedRight = (std::max)(right, minLeft);
    const float resolvedLeft  = (std::min)(left, resolvedRight);
    return D2D1::RectF(resolvedLeft, top, resolvedRight, bottom);
}

[[nodiscard]] MenuItemLayoutRects GetMenuItemLayoutRects(const MenuPopup& popup, size_t targetIndex) noexcept
{
    MenuItemLayoutRects layout{};
    if (targetIndex >= popup.itemCount)
    {
        return layout;
    }

    const ThemePalette& theme   = popup.host.GetTheme();
    const float itemHeightDip   = ResolveMenuItemHeightDip(theme);
    const float headerHeightDip = ResolveMenuHeaderHeightDip(theme);
    const auto& item            = popup.items[targetIndex];
    float rowHeightDip          = itemHeightDip;
    if (item.kind == MenuItemKind::Header)
        rowHeightDip = headerHeightDip;
    else if (item.kind == MenuItemKind::Slider)
        rowHeightDip = kSliderItemHeightDip;
    const float contentWidthDip             = popup.GetContentWidthDip();
    const float surfaceLeftDip              = popup.GetSurfaceRect().left;
    const std::wstring_view acceleratorText = DecodeMenuItemText(item).acceleratorText;

    layout.itemRectDip = GetVisibleItemRect(popup, targetIndex);
    rowHeightDip       = layout.itemRectDip.bottom - layout.itemRectDip.top;
    layout.iconRectDip = D2D1::RectF(surfaceLeftDip + kIconSlotLeftInsetDip,
                                     layout.itemRectDip.top,
                                     surfaceLeftDip + kIconSlotLeftInsetDip + kIconSlotWidthDip,
                                     layout.itemRectDip.top + rowHeightDip);

    const float reservedChevronWidthDip   = popup.hasSubmenuItems ? kChevronAreaWidthDip : 0.0f;
    const float acceleratorColumnWidthDip = acceleratorText.empty() ? 0.0f : popup.acceleratorColumnWidthDip;
    const float reservedAccelWidthDip     = acceleratorColumnWidthDip > 0.0f ? (acceleratorColumnWidthDip + kTextToAccelGapDip) : 0.0f;
    const float textRightDip              = surfaceLeftDip + contentWidthDip - kAccelRightPaddingDip - reservedChevronWidthDip - reservedAccelWidthDip;
    layout.textRectDip                    = ClampHorizontalRect(surfaceLeftDip + kTextLeftPaddingDip,
                                                                textRightDip,
                                                                layout.itemRectDip.top,
                                                                layout.itemRectDip.top + rowHeightDip,
                                                                surfaceLeftDip + kTextLeftPaddingDip);

    if (acceleratorColumnWidthDip > 0.0f)
    {
        const float accelRightDip = surfaceLeftDip + contentWidthDip - kAccelRightPaddingDip - reservedChevronWidthDip;
        const float accelLeftDip  = accelRightDip - acceleratorColumnWidthDip;
        layout.acceleratorRectDip =
            ClampHorizontalRect(accelLeftDip, accelRightDip, layout.itemRectDip.top, layout.itemRectDip.top + rowHeightDip, layout.textRectDip.right);
    }

    if (! item.children.empty())
    {
        layout.chevronRectDip = D2D1::RectF(surfaceLeftDip + contentWidthDip - kChevronRightPaddingDip - 16.0f,
                                            layout.itemRectDip.top,
                                            surfaceLeftDip + contentWidthDip - kChevronRightPaddingDip,
                                            layout.itemRectDip.top + rowHeightDip);
    }

    if (item.kind == MenuItemKind::Slider)
    {
        const float sliderTextTopDip    = layout.itemRectDip.top + 6.0f;
        const float sliderTextBottomDip = sliderTextTopDip + 22.0f;
        layout.iconRectDip              = D2D1::RectF();
        layout.textRectDip              = ClampHorizontalRect(
            surfaceLeftDip + kAccelRightPaddingDip, textRightDip, sliderTextTopDip, sliderTextBottomDip, surfaceLeftDip + kAccelRightPaddingDip);
        if (acceleratorColumnWidthDip > 0.0f)
        {
            const float accelRightDip = surfaceLeftDip + contentWidthDip - kAccelRightPaddingDip - reservedChevronWidthDip;
            const float accelLeftDip  = accelRightDip - acceleratorColumnWidthDip;
            layout.acceleratorRectDip = ClampHorizontalRect(accelLeftDip, accelRightDip, sliderTextTopDip, sliderTextBottomDip, layout.textRectDip.right);
        }
    }

    if (! popup.descriptionLayouts.empty() && HasMenuDescription(item))
    {
        const auto& row             = popup.descriptionLayouts[targetIndex];
        layout.textRectDip.top      = layout.itemRectDip.top + kDescriptionPaddingDip;
        layout.textRectDip.bottom   = layout.textRectDip.top + std::ceil(row.primaryMetrics.height);
        layout.secondaryTextRectDip = D2D1::RectF(layout.textRectDip.left,
                                                  layout.textRectDip.bottom + kDescriptionGapDip,
                                                  layout.textRectDip.right,
                                                  layout.itemRectDip.bottom - kDescriptionPaddingDip);
        // Shortcut and selection indicators align to the primary field.
        layout.acceleratorRectDip.top    = layout.textRectDip.top;
        layout.acceleratorRectDip.bottom = layout.textRectDip.bottom;
        layout.iconRectDip.top           = layout.textRectDip.top;
        layout.iconRectDip.bottom        = layout.textRectDip.bottom;
    }

    return layout;
}

// ---------------------------------------------------------------------------
// Hit-test: find item index under a DIP point (menu-local)
// ---------------------------------------------------------------------------

[[nodiscard]] std::optional<size_t> HitTestMenuItem(const MenuPopup& popup, D2D1_POINT_2F pointDip) noexcept
{
    if (! PointInRect(popup.GetViewportRect(), pointDip))
    {
        return std::nullopt;
    }

    const float contentY = pointDip.y + popup.scrollOffsetDip - popup.shadowMargins.topDip;
    if (pointDip.x < popup.shadowMargins.leftDip || pointDip.x >= popup.shadowMargins.leftDip + popup.GetContentWidthDip() ||
        popup.itemOffsetsDip.size() != popup.itemCount + 1u)
    {
        return std::nullopt;
    }

    const auto upper = std::upper_bound(popup.itemOffsetsDip.begin(), popup.itemOffsetsDip.end(), contentY);
    if (upper == popup.itemOffsetsDip.begin() || upper == popup.itemOffsetsDip.end())
    {
        return std::nullopt;
    }
    const size_t index = static_cast<size_t>(std::distance(popup.itemOffsetsDip.begin(), upper) - 1);
    return popup.IsNavigableItem(index) ? std::optional<size_t>{index} : std::nullopt;
}

// ---------------------------------------------------------------------------
// Paint menu content (called from WM_PAINT via ControlHost)
// ---------------------------------------------------------------------------

// The brush that draws a row's description in `color`: the popup's one brush, recolored here (Direct2D resolves a brush's color
// when the draw is issued, so each row's draw keeps its own) and bound to the row's layout the first time it draws with it.
// Null when the brush cannot be made or bound; the row then draws nothing, like a null brush from the host.
[[nodiscard]] ID2D1SolidColorBrush* BindMenuDescriptionBrush(ID2D1DeviceContext& dc,
                                                             MenuPopup& popup,
                                                             MenuDescriptionLayout& row,
                                                             const D2D1_COLOR_F& color) noexcept
{
    wil::com_ptr<ID2D1Device> device;
    dc.GetDevice(device.put());
    if (! device)
        return nullptr;
    if (! popup.descriptionBrush || popup.descriptionBrushDevice.get() != device.get())
    {
        wil::com_ptr<ID2D1SolidColorBrush> brush;
        if (FAILED(dc.CreateSolidColorBrush(color, brush.put())) || ! brush)
            return nullptr;
        popup.descriptionBrush       = std::move(brush);
        popup.descriptionBrushDevice = std::move(device);
    }
    popup.descriptionBrush->SetColor(color);
    if (row.descriptionBrush != popup.descriptionBrush.get())
    {
        if (FAILED(row.layout->SetDrawingEffect(popup.descriptionBrush.get(), row.description)))
            return nullptr;
        row.descriptionBrush = popup.descriptionBrush.get();
    }
    return popup.descriptionBrush.get();
}

// Draws a described row's layout: the label in primaryColor and the description in secondaryColor, at the row's text origin,
// where two separate layouts drew them a measured gap apart. False leaves a plain row to the caller. Color glyphs (emoji)
// render as in plain rows; like the Grid, no clip to the fractional layout box.
[[nodiscard]] bool DrawMenuDescription(ControlHost& host,
                                       ID2D1DeviceContext& dc,
                                       MenuPopup& popup,
                                       size_t index,
                                       const MenuItemLayoutRects& layout,
                                       const D2D1_COLOR_F& primaryColor,
                                       const D2D1_COLOR_F& secondaryColor) noexcept
{
    if (popup.descriptionLayouts.empty() || ! HasMenuDescription(popup.items[index]))
    {
        return false;
    }
    // GetSolidBrush can return null; like every other draw here, skip rather than pass it.
    auto& row = popup.descriptionLayouts[index];
    if (auto* primaryBrush = host.GetSolidBrush(primaryColor); primaryBrush && row.layout && BindMenuDescriptionBrush(dc, popup, row, secondaryColor))
    {
        dc.DrawTextLayout(
            D2D1::Point2F(layout.textRectDip.left, layout.textRectDip.top), row.layout.get(), primaryBrush, D2D1_DRAW_TEXT_OPTIONS_ENABLE_COLOR_FONT);
    }
    return true;
}

class MenuContentControl final : public Panel
{
public:
    MenuPopup* popup = nullptr;

    bool Tick(ControlHost& host, uint64_t nowTickMs) override
    {
        if (! popup || ! popup->sliderAnimationActive)
        {
            return false;
        }
        const bool active = AdvanceSliderAnimation(*popup, nowTickMs);
        // The animated slider position moved this tick, including the tick that settles it on its target.
        Invalidate(host);
        return active;
    }

    void Paint(ControlHost& host) const override
    {
        if (! popup || ! popup->controller)
            return;

        Debug::Perf::Scope menuPaintPerf(L"dxui.menu.popup.paint");

        auto* dc = host.GetDeviceContext();
        if (! dc)
            return;

        const auto& style             = popup->controller->style;
        const auto& theme             = popup->controller->theme;
        const float itemHeightDip     = ResolveMenuItemHeightDip(theme);
        const float contentWidth      = popup->GetContentWidthDip();
        const D2D1_RECT_F surfaceRect = popup->GetSurfaceRect();
        const float surfaceLeft       = surfaceRect.left;
        const float surfaceTop        = surfaceRect.top;

        // Background
        const MenuSurfaceMaterialStyle material = ResolveMenuSurfaceMaterialStyle(theme, style);
        PaintMenuMaterialSurface(host, popup->usesAppBackdropBlur ? &popup->backdropSnapshot : nullptr, surfaceRect, kMenuCornerRadiusDip, material);

        const D2D1_RECT_F viewportRect = popup->GetViewportRect();
        dc->PushAxisAlignedClip(viewportRect, D2D1_ANTIALIAS_MODE_PER_PRIMITIVE);

        // Items
        size_t firstVisibleItem = 0u;
        if (popup->itemOffsetsDip.size() == popup->itemCount + 1u)
        {
            const auto upper = std::upper_bound(popup->itemOffsetsDip.begin(), popup->itemOffsetsDip.end(), popup->scrollOffsetDip);
            if (upper != popup->itemOffsetsDip.begin())
            {
                firstVisibleItem = static_cast<size_t>(std::distance(popup->itemOffsetsDip.begin(), upper) - 1);
                firstVisibleItem = (std::min)(firstVisibleItem, popup->itemCount);
            }
        }

        size_t paintedItemCount = 0u;
        for (size_t i = firstVisibleItem; i < popup->itemCount; ++i)
        {
            const auto& item       = popup->items[i];
            const float y          = popup->itemOffsetsDip.size() == popup->itemCount + 1u ? popup->itemOffsetsDip[i] : kMenuPaddingTopDip;
            const float itemHeight = popup->itemOffsetsDip.size() == popup->itemCount + 1u ? popup->itemOffsetsDip[i + 1u] - y : itemHeightDip;

            const D2D1_RECT_F itemRect        = D2D1::RectF(kMenuBorderDip, y, contentWidth - kMenuBorderDip, y + itemHeight);
            const D2D1_RECT_F visibleItemRect = D2D1::RectF(surfaceLeft + itemRect.left,
                                                            surfaceTop + itemRect.top - popup->scrollOffsetDip,
                                                            surfaceLeft + itemRect.right,
                                                            surfaceTop + itemRect.bottom - popup->scrollOffsetDip);

            if (visibleItemRect.top >= viewportRect.bottom)
            {
                break;
            }
            if (visibleItemRect.bottom <= viewportRect.top)
            {
                continue;
            }
            ++paintedItemCount;

            if (item.kind == MenuItemKind::Separator)
            {
                // Separator line
                const float lineY     = visibleItemRect.top + kSeparatorMarginDip + 0.5f;
                const float lineLeft  = surfaceLeft + kItemHoverInsetDip;
                const float lineRight = surfaceLeft + contentWidth - kItemHoverInsetDip;
                auto* brush           = host.GetSolidBrush(style.separatorColor);
                if (brush)
                {
                    dc->DrawLine(D2D1::Point2F(lineLeft, lineY), D2D1::Point2F(lineRight, lineY), brush, 1.0f);
                }
                continue;
            }

            if (item.kind == MenuItemKind::Header)
            {
                // Header text (Caption font, subdued)
                const MenuItemLayoutRects layout = GetMenuItemLayoutRects(*popup, i);
                const ParsedMenuLabel label      = ParseMenuLabel(DecodeMenuItemText(item).labelText);
                const D2D1_RECT_F textRect =
                    D2D1::RectF(layout.textRectDip.left, layout.textRectDip.top, surfaceLeft + contentWidth - kAccelRightPaddingDip, layout.textRectDip.bottom);
                DrawCenteredText(
                    host, label.displayText, textRect, FontRole::Small, style.headerText, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
                continue;
            }

            if (item.kind == MenuItemKind::Slider)
            {
                const MenuItemLayoutRects layout           = GetMenuItemLayoutRects(*popup, i);
                const bool isHovered                       = (popup->hoveredIndex.has_value() && popup->hoveredIndex.value() == i) ||
                                                             (popup->keyboardIndex.has_value() && popup->keyboardIndex.value() == i);
                const bool isDisabled                      = ! item.enabled;
                const DecodedMenuItemText decoded          = DecodeMenuItemText(item);
                const ParsedMenuLabel label                = ParseMenuLabel(decoded.labelText);
                const MenuResolvedItemPaintStyle itemPaint = ResolveMenuItemPaintStyle(theme, style, item, label.displayText, isHovered);
                const D2D1_COLOR_F textColor = isDisabled ? D2D1::ColorF(itemPaint.text.r, itemPaint.text.g, itemPaint.text.b, 0.4f) : itemPaint.text;
                const D2D1_COLOR_F accelColor =
                    isDisabled ? D2D1::ColorF(itemPaint.accelText.r, itemPaint.accelText.g, itemPaint.accelText.b, 0.4f) : itemPaint.accelText;

                if (itemPaint.showHighlightFill)
                {
                    const D2D1_RECT_F hoverRect = D2D1::RectF(
                        visibleItemRect.left + kItemHoverInsetDip, visibleItemRect.top, visibleItemRect.right - kItemHoverInsetDip, visibleItemRect.bottom);
                    const D2D1_COLOR_F transparent = D2D1::ColorF(0, 0, 0, 0);
                    DrawRoundedRect(host, hoverRect, itemPaint.fill, transparent, kItemHoverRadiusDip);
                }

                DrawCenteredText(
                    host, label.displayText, layout.textRectDip, FontRole::Body, textColor, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);

                if (! decoded.acceleratorText.empty())
                {
                    DrawCenteredText(host,
                                     decoded.acceleratorText,
                                     layout.acceleratorRectDip,
                                     FontRole::Body,
                                     accelColor,
                                     DWRITE_TEXT_ALIGNMENT_TRAILING,
                                     DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
                }

                const D2D1_RECT_F trackRect = GetSliderTrackRect(layout.itemRectDip);
                const D2D1_COLOR_F trackColor =
                    isDisabled ? D2D1::ColorF(style.separatorColor.r, style.separatorColor.g, style.separatorColor.b, 0.45f) : style.separatorColor;
                const D2D1_COLOR_F activeColor =
                    isDisabled ? D2D1::ColorF(itemPaint.checkColor.r, itemPaint.checkColor.g, itemPaint.checkColor.b, 0.45f) : itemPaint.checkColor;
                auto* trackBrush  = host.GetSolidBrush(trackColor);
                auto* activeBrush = host.GetSolidBrush(activeColor);
                if (trackBrush)
                {
                    DrawRoundedRect(host, trackRect, trackColor, D2D1::ColorF(0, 0, 0, 0), kSliderTrackHeightDip * 0.5f);
                }

                const size_t stopCount = item.sliderStops.size();
                if (activeBrush && stopCount > 0u)
                {
                    const uint32_t sliderValue   = ClampSliderValue(item);
                    const float trackCenterY     = (trackRect.top + trackRect.bottom) * 0.5f;
                    const float animatedPosition = popup->sliderAnimationItemIndex == std::optional<size_t>{i} && popup->sliderAnimationInitialized
                                                       ? popup->sliderAnimatedPosition
                                                       : static_cast<float>(sliderValue);
                    const float activeRight =
                        stopCount <= 1u ? trackRect.left
                                        : trackRect.left + ((trackRect.right - trackRect.left) * animatedPosition / static_cast<float>(stopCount - 1u));
                    if (activeRight > trackRect.left)
                    {
                        const D2D1_RECT_F activeRect = D2D1::RectF(trackRect.left, trackRect.top, activeRight, trackRect.bottom);
                        DrawRoundedRect(host, activeRect, activeColor, D2D1::ColorF(0, 0, 0, 0), kSliderTrackHeightDip * 0.5f);
                    }

                    for (size_t stopIndex = 0u; stopIndex < stopCount; ++stopIndex)
                    {
                        const float t      = stopCount <= 1u ? 0.0f : static_cast<float>(stopIndex) / static_cast<float>(stopCount - 1u);
                        const float x      = trackRect.left + ((trackRect.right - trackRect.left) * t);
                        const float extent = ResolveSliderStopVisualExtentDip(stopIndex, stopCount);
                        const D2D1_ROUNDED_RECT stopRect{
                            D2D1::RectF(x - extent * 0.5f, trackCenterY - extent * 0.5f, x + extent * 0.5f, trackCenterY + extent * 0.5f),
                            kSliderStopCornerRadiusDip,
                            kSliderStopCornerRadiusDip,
                        };
                        if (auto* stopBrush = host.GetSolidBrush(style.background))
                        {
                            dc->FillRoundedRectangle(stopRect, stopBrush);
                        }
                        if (auto* borderBrush = host.GetSolidBrush(activeColor))
                        {
                            dc->DrawRoundedRectangle(stopRect, borderBrush, 1.25f);
                        }
                    }

                    const float animatedT   = stopCount <= 1u ? 0.0f : std::clamp(animatedPosition / static_cast<float>(stopCount - 1u), 0.0f, 1.0f);
                    const float thumbX      = std::lerp(trackRect.left, trackRect.right, animatedT);
                    const float thumbExtent = std::lerp(kSliderStopMinExtentDip, kSliderStopMaxExtentDip, animatedT);
                    const D2D1_ROUNDED_RECT thumbRect{
                        D2D1::RectF(
                            thumbX - thumbExtent * 0.5f, trackCenterY - thumbExtent * 0.5f, thumbX + thumbExtent * 0.5f, trackCenterY + thumbExtent * 0.5f),
                        kSliderStopCornerRadiusDip,
                        kSliderStopCornerRadiusDip,
                    };
                    dc->FillRoundedRectangle(thumbRect, activeBrush);
                    if (auto* thumbBorderBrush = host.GetSolidBrush(textColor))
                    {
                        dc->DrawRoundedRectangle(thumbRect, thumbBorderBrush, 1.0f);
                    }
                }

                continue;
            }

            if (item.kind == MenuItemKind::Info)
            {
                const MenuItemLayoutRects layout  = GetMenuItemLayoutRects(*popup, i);
                const DecodedMenuItemText decoded = DecodeMenuItemText(item);
                const ParsedMenuLabel label       = ParseMenuLabel(decoded.labelText);
                const D2D1_COLOR_F infoLabelColor = decoded.acceleratorText.empty() ? style.text : style.accelText;
                // A described Info row was measured with its description; draw it rather than leave the row's space empty.
                if (! DrawMenuDescription(host, *dc, *popup, i, layout, infoLabelColor, style.accelText))
                {
                    DrawCenteredText(host,
                                     label.displayText,
                                     layout.textRectDip,
                                     FontRole::Body,
                                     infoLabelColor,
                                     DWRITE_TEXT_ALIGNMENT_LEADING,
                                     DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
                }

                if (! decoded.acceleratorText.empty())
                {
                    DrawCenteredText(host,
                                     decoded.acceleratorText,
                                     layout.acceleratorRectDip,
                                     FontRole::Body,
                                     style.text,
                                     DWRITE_TEXT_ALIGNMENT_TRAILING,
                                     DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
                }

                continue;
            }

            // Standard/Toggle/Radio item
            const MenuItemLayoutRects layout           = GetMenuItemLayoutRects(*popup, i);
            const bool isHovered                       = (popup->hoveredIndex.has_value() && popup->hoveredIndex.value() == i) ||
                                                         (popup->keyboardIndex.has_value() && popup->keyboardIndex.value() == i);
            const bool isDisabled                      = ! item.enabled;
            const DecodedMenuItemText decoded          = DecodeMenuItemText(item);
            const ParsedMenuLabel label                = ParseMenuLabel(decoded.labelText);
            const MenuResolvedItemPaintStyle itemPaint = ResolveMenuItemPaintStyle(theme, style, item, label.displayText, isHovered);
            const D2D1_COLOR_F textColor               = isDisabled ? D2D1::ColorF(itemPaint.text.r, itemPaint.text.g, itemPaint.text.b, 0.4f) : itemPaint.text;
            const D2D1_COLOR_F accelColor =
                isDisabled ? D2D1::ColorF(itemPaint.accelText.r, itemPaint.accelText.g, itemPaint.accelText.b, 0.4f) : itemPaint.accelText;

            // Hover backplate
            if (itemPaint.showHighlightFill)
            {
                const D2D1_RECT_F hoverRect = D2D1::RectF(
                    visibleItemRect.left + kItemHoverInsetDip, visibleItemRect.top, visibleItemRect.right - kItemHoverInsetDip, visibleItemRect.bottom);
                const D2D1_COLOR_F transparent = D2D1::ColorF(0, 0, 0, 0);
                DrawRoundedRect(host, hoverRect, itemPaint.fill, transparent, kItemHoverRadiusDip);
            }

            // Icon area (check/radio indicator or custom icon)
            if (item.checked)
            {
                if (item.kind == MenuItemKind::Toggle)
                {
                    DrawCenteredText(host,
                                     kCheckMarkGlyph,
                                     layout.iconRectDip,
                                     FontRole::Icon,
                                     isDisabled ? D2D1::ColorF(itemPaint.checkColor.r, itemPaint.checkColor.g, itemPaint.checkColor.b, 0.4f)
                                                : itemPaint.checkColor,
                                     DWRITE_TEXT_ALIGNMENT_CENTER,
                                     DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
                }
                else if (item.kind == MenuItemKind::Radio)
                {
                    DrawCenteredText(host,
                                     kRadioBulletGlyph,
                                     layout.iconRectDip,
                                     FontRole::Icon,
                                     isDisabled ? D2D1::ColorF(itemPaint.checkColor.r, itemPaint.checkColor.g, itemPaint.checkColor.b, 0.4f)
                                                : itemPaint.checkColor,
                                     DWRITE_TEXT_ALIGNMENT_CENTER,
                                     DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
                }
            }
            else if (! item.iconGlyph.empty())
            {
                DrawCenteredText(host,
                                 item.iconGlyph,
                                 layout.iconRectDip,
                                 FontRole::Icon,
                                 isDisabled ? D2D1::ColorF(itemPaint.iconColor.r, itemPaint.iconColor.g, itemPaint.iconColor.b, 0.4f) : itemPaint.iconColor,
                                 DWRITE_TEXT_ALIGNMENT_CENTER,
                                 DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
            }
            else if (item.iconBitmap)
            {
                DrawMenuBitmapIcon(host, *item.iconBitmap, layout.iconRectDip, isDisabled ? 0.4f : 1.0f);
            }

            // Detailed text is prepared at the final available width outside paint.
            if (! DrawMenuDescription(host, *dc, *popup, i, layout, textColor, accelColor))
            {
                DrawCenteredText(
                    host, label.displayText, layout.textRectDip, FontRole::Body, textColor, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
            }

            // Accelerator text
            if (! decoded.acceleratorText.empty())
            {
                DrawCenteredText(host,
                                 decoded.acceleratorText,
                                 layout.acceleratorRectDip,
                                 FontRole::Body,
                                 accelColor,
                                 DWRITE_TEXT_ALIGNMENT_TRAILING,
                                 DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
            }

            // Submenu chevron
            if (! item.children.empty())
            {
                DrawCenteredText(host,
                                 kChevronRightGlyph,
                                 layout.chevronRectDip,
                                 FontRole::Icon,
                                 isDisabled ? D2D1::ColorF(itemPaint.chevronColor.r, itemPaint.chevronColor.g, itemPaint.chevronColor.b, 0.4f)
                                            : itemPaint.chevronColor,
                                 DWRITE_TEXT_ALIGNMENT_CENTER,
                                 DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
            }
        }

        popup->lastPaintedItemCount = paintedItemCount;
        if (Debug::Perf::IsCaptureEnabled())
        {
            Debug::Perf::EmitValue(L"dxui.menu.popup.visible_rows", static_cast<uint64_t>(paintedItemCount));
        }

        dc->PopAxisAlignedClip();

        if (popup->NeedsScrollbar())
        {
            const auto visuals = ResolveScrollbarVisuals(host.GetTheme(),
                                                         popup->scrollbarHotPart == MenuPopup::ScrollbarHotPart::Track,
                                                         popup->scrollbarHotPart == MenuPopup::ScrollbarHotPart::Thumb,
                                                         popup->draggingScrollbarThumb);
            PaintScrollbar(host, popup->GetScrollbarTrackRect(), popup->GetScrollbarThumbRect(), visuals);
        }
    }
};

// ---------------------------------------------------------------------------
// Every menu row is a UI Automation element, with the row's retained identity and geometry.
// ---------------------------------------------------------------------------

template <typename Base> class MenuAccessibilityItem final : public Base
{
public:
    // Not noexcept: the Label/Toggle bases allocate (lifetime token, strings), and
    // PopulateMenuAccessibility turns that bad_alloc into a rejected popup.
    MenuAccessibilityItem(MenuPopup& owner, size_t index) : _popup(owner), _index(index)
    {
    }
    void Paint(ControlHost&) const override
    {
    }
    bool OnMnemonic(ControlHost& host) override
    {
        return this->InvokeAccessible(host);
    }

protected:
    void OnFocusChanged(ControlHost& host, bool focused) override
    {
        Base::OnFocusChanged(host, focused);
        if (focused)
        {
            const bool changed   = _popup.keyboardIndex != _index || _popup.hoveredIndex.has_value();
            _popup.keyboardIndex = _index;
            _popup.hoveredIndex.reset();
            _popup.EnsureItemVisible(_index);
            if (changed)
                PostMenuAccessibilityRequest(_popup.hwnd, WndMsg::MenuPopupAccessibleFocus(), _index);
        }
    }

private:
    MenuPopup& _popup;
    size_t _index;
};

[[nodiscard]] bool PopulateMenuAccessibility(MenuContentControl& content, MenuPopup& popup) noexcept
try
{
    for (size_t i = 0; i < popup.itemCount; ++i)
    {
        const auto& item = popup.items[i];
        Control* child   = nullptr;
        if (item.kind == MenuItemKind::Radio || item.kind == MenuItemKind::Toggle)
        {
            auto* check = content.AddChild<MenuAccessibilityItem<Toggle>>(popup, i);
            check->SetChecked(item.checked);
            child = check;
        }
        else
            child = content.AddChild<MenuAccessibilityItem<Label>>(popup, i);
        const auto label  = ParseMenuLabel(DecodeMenuItemText(item).labelText);
        std::wstring name = item.accessibleName;
        if (name.empty())
        {
            name = label.displayText;
            if (HasMenuDescription(item))
                name += L"\n" + item.secondaryText;
        }
        child->SetAccessibleName(std::move(name));
        child->SetAccessibleAutomationId(std::format(L"menu.item.{}", i));
        child->SetEnabled(item.enabled);
        child->SetFocusable(popup.IsNavigableItem(i));
        const bool command =
            item.kind != MenuItemKind::Separator && item.kind != MenuItemKind::Header && item.kind != MenuItemKind::Info && item.kind != MenuItemKind::Slider;
        if (command)
        {
            child->SetAccessibilityRole(AccessibilityRole::MenuItem);
            child->SetAccessibleInvoke([hwnd = popup.hwnd, i](ControlHost&)
            {
                // Post to the existing dispatcher so provider calls never destroy their own tree.
                PostMenuAccessibilityRequest(hwnd, WndMsg::MenuPopupAccessibleInvoke(), i);
            });
        }
        child->SetVisible(item.kind != MenuItemKind::Separator);
    }
    return true;
}
catch (const std::bad_alloc&)
{
    // The detached content owns any partial nodes. Reject the unpublished popup
    // rather than allowing allocation failure through a native menu callback.
    return false;
}

void SynchronizeMenuAccessibility(MenuPopup& popup) noexcept
{
    auto* root = dynamic_cast<MenuContentControl*>(popup.host.GetRoot());
    if (! root || root->GetChildren().size() != popup.itemCount)
        return;
    const auto children = root->GetChildren();
    const auto viewport = popup.GetViewportRect();
    bool boundsChanged  = false;
    for (size_t i = 0; i < children.size(); ++i)
    {
        auto rect   = GetVisibleItemRect(popup, i);
        rect.top    = (std::max)(rect.top, viewport.top);
        rect.bottom = (std::min)(rect.bottom, viewport.bottom);
        if (rect.bottom < rect.top)
            rect = D2D1::RectF();
        const D2D1_RECT_F previous = children[i]->GetBounds();
        if (previous.left != rect.left || previous.top != rect.top || previous.right != rect.right || previous.bottom != rect.bottom)
        {
            children[i]->SetBounds(rect);
            boundsChanged = true;
        }
    }
    Control* focus = popup.keyboardIndex && *popup.keyboardIndex < children.size() ? children[*popup.keyboardIndex].get() : nullptr;
    // Keep the session's native focus target while tracking logical entry focus: modal and
    // asynchronous menus both activate their root popup for keyboard dispatch.
    bool published = false;
    if (popup.host.GetFocusControl() != focus)
    {
        popup.host.SetFocusControl(focus, false);
        // A completed focus transition republishes the UIA snapshot, including the bounds above.
        published = popup.host.GetFocusControl() == focus;
        // Win32 focus stays on the session's root popup, so no system focus event reports a row change: raise it for
        // clients that track focus (screen readers) as the keyboard moves through the rows.
        if (published && focus)
            RaiseWindowHostFocusChanged(popup.hwnd, focus);
    }
    // Providers answer BoundingRectangle and ElementProviderFromPoint from that published
    // snapshot. Scrolling, DPI reflow and UIA-driven reveal move rows without a focus change,
    // so republish when a row actually moved; unchanged hover repaints publish nothing.
    if (boundsChanged && ! published)
        popup.host.RefreshAccessibilitySnapshot();
}

// ---------------------------------------------------------------------------
// Popup positioning with screen-edge flip
// ---------------------------------------------------------------------------

[[nodiscard]] RECT ConstrainPopupSurfaceRectToWorkArea(POINT topLeft, int desiredWidthPx, int desiredHeightPx, const RECT& work) noexcept
{
    const int workWidthPx  = (std::max)(1, static_cast<int>(work.right - work.left));
    const int workHeightPx = (std::max)(1, static_cast<int>(work.bottom - work.top));
    const int widthPx      = (std::min)((std::max)(1, desiredWidthPx), workWidthPx);
    const int heightPx     = (std::min)((std::max)(1, desiredHeightPx), workHeightPx);
    const int maxX         = (std::max)(static_cast<int>(work.left), static_cast<int>(work.right - widthPx));
    const int maxY         = (std::max)(static_cast<int>(work.top), static_cast<int>(work.bottom - heightPx));
    const int x            = std::clamp(static_cast<int>(topLeft.x), static_cast<int>(work.left), maxX);
    const int y            = std::clamp(static_cast<int>(topLeft.y), static_cast<int>(work.top), maxY);
    return RECT{x, y, x + widthPx, y + heightPx};
}

[[nodiscard]] RECT GetPopupItemScreenRect(const MenuPopup& popup, size_t itemIndex) noexcept
{
    RECT windowRect{};
    if (! popup.hwnd || GetWindowRect(popup.hwnd, &windowRect) == FALSE)
    {
        return RECT{};
    }

    const D2D1_RECT_F itemRect = GetVisibleItemRect(popup, itemIndex);
    const float scale          = static_cast<float>(popup.dpi) / 96.0f;
    return RECT{RoundToLongSaturated(static_cast<double>(windowRect.left) + (static_cast<double>(itemRect.left) * static_cast<double>(scale))),
                RoundToLongSaturated(static_cast<double>(windowRect.top) + (static_cast<double>(itemRect.top) * static_cast<double>(scale))),
                RoundToLongSaturated(static_cast<double>(windowRect.left) + (static_cast<double>(itemRect.right) * static_cast<double>(scale))),
                RoundToLongSaturated(static_cast<double>(windowRect.top) + (static_cast<double>(itemRect.bottom) * static_cast<double>(scale)))};
}

[[nodiscard]] RECT ComputePopupPosition(POINT screenPoint,
                                        float widthDip,
                                        float heightDip,
                                        UINT dpi,
                                        bool isSubmenu,
                                        ContextMenuRootHorizontalAlignment rootHorizontalAlignment,
                                        ContextMenuRootVerticalPlacement rootVerticalPlacement,
                                        const RECT* parentRect,
                                        const RECT* parentItemRect) noexcept
{
    const float scale         = static_cast<float>(dpi) / 96.0f;
    const int desiredWidthPx  = DipExtentToPixels(widthDip, dpi);
    const int desiredHeightPx = DipExtentToPixels(heightDip, dpi);

    HMONITOR monitor = MonitorFromPoint(screenPoint, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi{};
    mi.cbSize = sizeof(mi);
    GetMonitorInfoW(monitor, &mi);
    const RECT work            = mi.rcWork;
    const RECT constrainedSize = ConstrainPopupSurfaceRectToWorkArea(POINT{work.left, work.top}, desiredWidthPx, desiredHeightPx, work);
    const int widthPx          = constrainedSize.right - constrainedSize.left;
    const int heightPx         = constrainedSize.bottom - constrainedSize.top;

    int x = screenPoint.x;
    int y = screenPoint.y;

    if (isSubmenu && parentItemRect)
    {
        x = parentItemRect->right;
        y = parentItemRect->top + static_cast<int>(kSubmenuVerticalOffsetDip * scale + 0.5f);
    }
    else if (! isSubmenu)
    {
        if (rootHorizontalAlignment == ContextMenuRootHorizontalAlignment::End)
        {
            x -= widthPx;
            if (x < work.left)
            {
                x = screenPoint.x;
            }
        }

        if (rootVerticalPlacement == ContextMenuRootVerticalPlacement::Above)
        {
            y -= heightPx;
            if (y < work.top && screenPoint.y + heightPx <= work.bottom)
            {
                y = screenPoint.y;
            }
            y = (std::max)(y, static_cast<int>(work.top));
        }
    }

    // Flip horizontally if would go off-screen right
    if (x + widthPx > work.right)
    {
        if (isSubmenu)
        {
            const int anchorLeft = parentItemRect ? parentItemRect->left : (parentRect ? parentRect->left : x);
            x                    = anchorLeft - widthPx;
        }
        else
            x = work.right - widthPx;
    }

    // Flip vertically if would go off-screen bottom
    if (y + heightPx > work.bottom)
    {
        y = work.bottom - heightPx;
    }

    return ConstrainPopupSurfaceRectToWorkArea(POINT{x, y}, widthPx, heightPx, work);
}

[[nodiscard]] RECT ComputePopupWindowRect(const RECT& surfaceRectPx, const MenuPopupShadowMargins& shadowMargins, UINT dpi) noexcept
{
    const int shadowLeftPx   = DipExtentToPixels(shadowMargins.leftDip, dpi);
    const int shadowTopPx    = DipExtentToPixels(shadowMargins.topDip, dpi);
    const int shadowRightPx  = DipExtentToPixels(shadowMargins.rightDip, dpi);
    const int shadowBottomPx = DipExtentToPixels(shadowMargins.bottomDip, dpi);

    return RECT{surfaceRectPx.left - shadowLeftPx, surfaceRectPx.top - shadowTopPx, surfaceRectPx.right + shadowRightPx, surfaceRectPx.bottom + shadowBottomPx};
}

[[nodiscard]] wil::unique_hrgn CreateMenuPopupWindowRegion(const MenuPopupShadowMargins& shadowMargins, UINT dpi, int widthPx, int heightPx) noexcept
{
    if (widthPx <= 0 || heightPx <= 0)
    {
        return nullptr;
    }

    const int menuCornerRadiusPx = DipExtentToPixels(kMenuCornerRadiusDip, dpi);
    const int shadowLeftPx       = DipExtentToPixels(shadowMargins.leftDip, dpi);
    const int shadowTopPx        = DipExtentToPixels(shadowMargins.topDip, dpi);
    const int shadowRightPx      = DipExtentToPixels(shadowMargins.rightDip, dpi);
    const int shadowBottomPx     = DipExtentToPixels(shadowMargins.bottomDip, dpi);

    const int topLeftRadiusXPx     = (std::clamp)(menuCornerRadiusPx + shadowLeftPx, 1, widthPx);
    const int topLeftRadiusYPx     = (std::clamp)(menuCornerRadiusPx + shadowTopPx, 1, heightPx);
    const int topRightRadiusXPx    = (std::clamp)(menuCornerRadiusPx + shadowRightPx, 1, widthPx);
    const int topRightRadiusYPx    = (std::clamp)(menuCornerRadiusPx + shadowTopPx, 1, heightPx);
    const int bottomLeftRadiusXPx  = (std::clamp)(menuCornerRadiusPx + shadowLeftPx, 1, widthPx);
    const int bottomLeftRadiusYPx  = (std::clamp)(menuCornerRadiusPx + shadowBottomPx, 1, heightPx);
    const int bottomRightRadiusXPx = (std::clamp)(menuCornerRadiusPx + shadowRightPx, 1, widthPx);
    const int bottomRightRadiusYPx = (std::clamp)(menuCornerRadiusPx + shadowBottomPx, 1, heightPx);

    wil::unique_hrgn region(CreateRectRgn(0, 0, widthPx, heightPx));
    if (! region)
    {
        return nullptr;
    }

    const auto subtractCornerCutout =
        [&](int boxLeft, int boxTop, int boxRight, int boxBottom, int ellipseLeft, int ellipseTop, int ellipseRight, int ellipseBottom) noexcept
    {
        if (boxRight <= boxLeft || boxBottom <= boxTop)
        {
            return true;
        }

        wil::unique_hrgn cornerBox(CreateRectRgn(boxLeft, boxTop, boxRight, boxBottom));
        wil::unique_hrgn ellipse(CreateEllipticRgn(ellipseLeft, ellipseTop, ellipseRight, ellipseBottom));
        wil::unique_hrgn quarter(CreateRectRgn(0, 0, 0, 0));
        wil::unique_hrgn cutout(CreateRectRgn(0, 0, 0, 0));
        if (! cornerBox || ! ellipse || ! quarter || ! cutout)
        {
            return false;
        }

        if (CombineRgn(quarter.get(), cornerBox.get(), ellipse.get(), RGN_AND) == ERROR)
        {
            return false;
        }

        if (CombineRgn(cutout.get(), cornerBox.get(), quarter.get(), RGN_DIFF) == ERROR)
        {
            return false;
        }

        return CombineRgn(region.get(), region.get(), cutout.get(), RGN_DIFF) != ERROR;
    };

    if (! subtractCornerCutout(0, 0, topLeftRadiusXPx, topLeftRadiusYPx, 0, 0, topLeftRadiusXPx * 2, topLeftRadiusYPx * 2) ||
        ! subtractCornerCutout(
            widthPx - topRightRadiusXPx, 0, widthPx, topRightRadiusYPx, widthPx - (topRightRadiusXPx * 2), 0, widthPx, topRightRadiusYPx * 2) ||
        ! subtractCornerCutout(
            0, heightPx - bottomLeftRadiusYPx, bottomLeftRadiusXPx, heightPx, 0, heightPx - (bottomLeftRadiusYPx * 2), bottomLeftRadiusXPx * 2, heightPx) ||
        ! subtractCornerCutout(widthPx - bottomRightRadiusXPx,
                               heightPx - bottomRightRadiusYPx,
                               widthPx,
                               heightPx,
                               widthPx - (bottomRightRadiusXPx * 2),
                               heightPx - (bottomRightRadiusYPx * 2),
                               widthPx,
                               heightPx))
    {
        return nullptr;
    }

    return region;
}

void ApplyMenuPopupWindowRegion(HWND hwnd, const MenuPopupShadowMargins& shadowMargins, UINT dpi, int widthPx, int heightPx) noexcept
{
    if (! hwnd || widthPx <= 0 || heightPx <= 0)
    {
        return;
    }

    wil::unique_hrgn region = CreateMenuPopupWindowRegion(shadowMargins, dpi, widthPx, heightPx);
    if (! region)
    {
        return;
    }

    if (SetWindowRgn(hwnd, region.get(), FALSE) == 0)
    {
        Debug::Warning(L"DxUi::ContextMenu: SetWindowRgn failed for popup host");
        return;
    }
    static_cast<void>(region.release());
}

[[nodiscard]] UINT ResolveMenuPopupMessageDpi(HWND hwnd, UINT msg, WPARAM wp) noexcept
{
    UINT dpi = msg == WM_DPICHANGED ? static_cast<UINT>(HIWORD(wp)) : 0u;
    if (dpi == 0u && hwnd && IsWindow(hwnd) != FALSE)
    {
        dpi = GetDpiForWindow(hwnd);
    }
    if (dpi == 0u)
    {
        dpi = GetDpiForSystem();
    }
    return dpi == 0u ? USER_DEFAULT_SCREEN_DPI : dpi;
}

[[nodiscard]] RECT ComputePopupSurfaceRectFromTopLeft(POINT topLeft, float widthDip, float heightDip, UINT dpi) noexcept
{
    const int widthPx  = DipExtentToPixels(widthDip, dpi);
    const int heightPx = DipExtentToPixels(heightDip, dpi);

    const HMONITOR monitor = MonitorFromPoint(topLeft, MONITOR_DEFAULTTONEAREST);
    MONITORINFO mi{};
    mi.cbSize = sizeof(mi);
    if (monitor == nullptr || GetMonitorInfoW(monitor, &mi) == FALSE)
    {
        mi.rcWork = RECT{GetSystemMetrics(SM_XVIRTUALSCREEN),
                         GetSystemMetrics(SM_YVIRTUALSCREEN),
                         GetSystemMetrics(SM_XVIRTUALSCREEN) + (std::max)(1, GetSystemMetrics(SM_CXVIRTUALSCREEN)),
                         GetSystemMetrics(SM_YVIRTUALSCREEN) + (std::max)(1, GetSystemMetrics(SM_CYVIRTUALSCREEN))};
    }

    return ConstrainPopupSurfaceRectToWorkArea(topLeft, widthPx, heightPx, mi.rcWork);
}

void RefreshMenuPopupBackdrop(MenuPopup& popup, const RECT& surfaceRectPx) noexcept
{
    popup.backdropSnapshot    = {};
    popup.usesAppBackdropBlur = false;

    const MenuItemVisualStyle itemStyle     = ResolveMenuVisualStyle(popup.host.GetTheme());
    const MenuSurfaceMaterialStyle material = ResolveMenuSurfaceMaterialStyle(popup.host.GetTheme(), itemStyle);
    if (material.backdropOpacity <= 0.0f || material.backdropBlurDip <= 0.0f)
    {
        return;
    }

    const auto backdropStartedAt = std::chrono::steady_clock::now();
    popup.usesAppBackdropBlur    = CaptureBackdropScreenRegion(surfaceRectPx, popup.backdropSnapshot.capture, L"Menu");
    Debug::Perf::Emit(L"dxui.menu.backdrop_capture_us",
                      popup.isSubmenu ? L"submenu_dpi" : L"root_dpi",
                      Debug::Perf::ElapsedUs(backdropStartedAt),
                      static_cast<uint64_t>(surfaceRectPx.right - surfaceRectPx.left),
                      static_cast<uint64_t>(surfaceRectPx.bottom - surfaceRectPx.top),
                      popup.usesAppBackdropBlur ? S_OK : E_FAIL);
}

void RelayoutMenuPopupForDpi(MenuPopup& popup, UINT dpi, const RECT* suggestedWindowRect) noexcept
{
    if (! popup.hwnd || IsWindow(popup.hwnd) == FALSE || dpi == 0u)
    {
        return;
    }

    const auto startedAt = std::chrono::steady_clock::now();
    popup.dpi            = dpi;

    bool hostDpiHandled = false;
    static_cast<void>(popup.host.HandleMessage(popup.hwnd, WM_DPICHANGED, MAKEWPARAM(static_cast<WORD>(dpi), static_cast<WORD>(dpi)), 0, hostDpiHandled));
    popup.RebuildItemOffsets();

    POINT surfaceTopLeft{popup.surfaceRectPx.left, popup.surfaceRectPx.top};
    if (suggestedWindowRect)
    {
        surfaceTopLeft.x = suggestedWindowRect->left + DipExtentToPixels(popup.shadowMargins.leftDip, dpi);
        surfaceTopLeft.y = suggestedWindowRect->top + DipExtentToPixels(popup.shadowMargins.topDip, dpi);
    }

    D2D1_SIZE_F sizeDip                  = ComputeMenuSize(popup.items, popup.itemCount, popup.host, &popup.acceleratorColumnWidthDip, &popup.hasSubmenuItems);
    const float requestedVisibleWidthDip = ResolveVisibleMenuWidthDip(sizeDip.width, popup.controller, popup.isSubmenu);
    if (! PrepareMenuDescriptionSize(popup, sizeDip, ComputePopupSurfaceRectFromTopLeft(surfaceTopLeft, requestedVisibleWidthDip, 1000000.0f, dpi)))
    {
        // A failed reflow must not leave an actionable partially measured menu. WM_DPICHANGED can
        // arrive synchronously inside a window operation, such as CreateMenuPopupWindow moving a new
        // popup to its monitor, whose caller still uses this popup and controller. Only dismiss here:
        // no command can run, and an asynchronous session finalizes after that caller unwinds.
        if (MenuController* const controller = popup.controller)
        {
            controller->Dismiss();
            // Without its registered message nothing is posted, as when the post fails.
            const WndMsg::RegisteredMessage finalize = WndMsg::MenuPopupDeferredFinalize();
            if (controller->asyncSession && finalize)
                static_cast<void>(PostMessageW(popup.hwnd, finalize.value, 0, 0));
        }
        return;
    }
    const float requestedVisibleHeightDip = (! popup.isSubmenu && popup.controller && popup.controller->sessionCallbacks.maxRootHeightDip > 0.0f)
                                                ? (std::min)(sizeDip.height, popup.controller->sessionCallbacks.maxRootHeightDip)
                                                : sizeDip.height;

    const RECT surfaceRectPx     = ComputePopupSurfaceRectFromTopLeft(surfaceTopLeft, requestedVisibleWidthDip, requestedVisibleHeightDip, dpi);
    const RECT windowRect        = ComputePopupWindowRect(surfaceRectPx, popup.shadowMargins, dpi);
    const int windowWidthPx      = windowRect.right - windowRect.left;
    const int windowHeightPx     = windowRect.bottom - windowRect.top;
    popup.menuWidthDip           = popup.PixelToDip(static_cast<float>(surfaceRectPx.right - surfaceRectPx.left));
    popup.menuHeightDip          = popup.PixelToDip(static_cast<float>(surfaceRectPx.bottom - surfaceRectPx.top));
    popup.windowWidthDip         = popup.PixelToDip(static_cast<float>(windowWidthPx));
    popup.windowHeightDip        = popup.PixelToDip(static_cast<float>(windowHeightPx));
    popup.surfaceRectPx          = surfaceRectPx;
    popup.windowRectPx           = windowRect;
    popup.contentHeightDip       = sizeDip.height;
    popup.draggingScrollbarThumb = false;
    popup.draggingSliderItemIndex.reset();
    popup.scrollbarHotPart = MenuPopup::ScrollbarHotPart::None;
    popup.ClampScrollOffset();

    if (popup.keyboardIndex)
        popup.EnsureItemVisible(*popup.keyboardIndex);

    SetWindowPos(popup.hwnd, HWND_TOP, windowRect.left, windowRect.top, windowWidthPx, windowHeightPx, SWP_NOACTIVATE | SWP_NOOWNERZORDER);
    ApplyMenuPopupWindowRegion(popup.hwnd, popup.shadowMargins, dpi, windowWidthPx, windowHeightPx);
    if (Control* const root = popup.host.GetRoot())
    {
        root->SetBounds(D2D1::RectF(0.0f, 0.0f, popup.windowWidthDip, popup.windowHeightDip));
    }
    RefreshMenuPopupBackdrop(popup, surfaceRectPx);
    SynchronizeMenuAccessibility(popup);
    popup.host.Invalidate();

    Debug::Perf::Emit(L"dxui.menu.dpi_relayout_us",
                      popup.isSubmenu ? L"submenu" : L"root",
                      Debug::Perf::ElapsedUs(startedAt),
                      static_cast<uint64_t>(popup.itemCount),
                      static_cast<uint64_t>(dpi),
                      S_OK);
}

// ---------------------------------------------------------------------------
// Create/show a menu popup window
// ---------------------------------------------------------------------------

static constexpr UINT_PTR kSubmenuHoverTimerId = 1;

bool CreateMenuPopupWindow(MenuController& controller,
                           const MenuFlyoutItem* items,
                           size_t itemCount,
                           POINT screenPoint,
                           bool isSubmenu,
                           const RECT* parentWindowRect,
                           const RECT* parentItemRect,
                           bool forceInitialRender      = true,
                           bool focusFirstNavigableItem = false)
{
    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.popup-create-begin",
                                L"owner={:#x} point=({}, {}) items={} submenu={} forceInitialRender={} focusFirst={} maxRootHeightDip={:.1f}",
                                TraceHwndValue(controller.ownerHwnd),
                                screenPoint.x,
                                screenPoint.y,
                                itemCount,
                                TraceBool(isSubmenu),
                                TraceBool(forceInitialRender),
                                TraceBool(focusFirstNavigableItem),
                                controller.sessionCallbacks.maxRootHeightDip);

    auto popup = std::make_unique<MenuPopup>();
    if (items && itemCount > 0u)
    {
        popup->ownedItems.assign(items, items + itemCount);
    }
    popup->items      = popup->ownedItems.data();
    popup->itemCount  = popup->ownedItems.size();
    popup->controller = &controller;
    popup->isSubmenu  = isSubmenu;
    for (size_t itemIndex = 0u; itemIndex < popup->ownedItems.size(); ++itemIndex)
    {
        const auto& item = popup->ownedItems[itemIndex];
        if (item.kind == MenuItemKind::Slider && ! item.sliderStops.empty())
        {
            const float initialPosition          = static_cast<float>(ClampSliderValue(item));
            popup->sliderAnimationItemIndex      = itemIndex;
            popup->sliderAnimatedPosition        = initialPosition;
            popup->sliderAnimationStartPosition  = initialPosition;
            popup->sliderAnimationTargetPosition = initialPosition;
            popup->sliderAnimationInitialized    = true;
            break;
        }
    }

    const HINSTANCE hInstance = wil::GetModuleInstanceHandle();
    EnsureMenuWindowClass(hInstance);

    // DPI from target monitor
    HMONITOR monitor = MonitorFromPoint(screenPoint, MONITOR_DEFAULTTONEAREST);
    UINT dpiX        = USER_DEFAULT_SCREEN_DPI;
    UINT dpiY        = USER_DEFAULT_SCREEN_DPI;
    if (SUCCEEDED(GetDpiForMonitor(monitor, MDT_EFFECTIVE_DPI, &dpiX, &dpiY)))
        popup->dpi = dpiX;
    else
        popup->dpi = GetDpiForSystem();

    // Create a temporary dummy window to initialize ControlHost for text measurement
    // We need the host before we can compute the menu size
    const DWORD exStyle = WS_EX_TOOLWINDOW | WS_EX_NOREDIRECTIONBITMAP | (isSubmenu ? WS_EX_NOACTIVATE : 0u);
    const DWORD style   = WS_POPUP | WS_CLIPCHILDREN | WS_CLIPSIBLINGS;

    HWND hwnd = CreateWindowExW(exStyle, kMenuWindowClass, L"", style, 0, 0, 1, 1, controller.ownerHwnd, nullptr, hInstance, nullptr);

    if (! hwnd)
    {
        DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.popup-create-failed",
                                    L"owner={:#x} stage=CreateWindowEx lastError={}",
                                    TraceHwndValue(controller.ownerHwnd),
                                    static_cast<unsigned long>(GetLastError()));
        return false;
    }

    popup->hwnd = hwnd;

    // Store the popup pointer on the HWND before Attach so the WndProc can find it
    SetWindowLongPtrW(hwnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(popup.get()));

    // Attach ControlHost and set theme
    if (! popup->host.Attach(hwnd, ControlHost::AttachOptions{.presentationMode = ControlHost::PresentationMode::CompositionSwapChain}))
    {
        DXUI_MENU_DIAGNOSTICS_TRACE(
            L"menu.popup-create-failed", L"owner={:#x} hwnd={:#x} stage=ControlHost.Attach", TraceHwndValue(controller.ownerHwnd), TraceHwndValue(hwnd));
        // Controller-initiated destroy: keep the WM_NCDESTROY external-teardown
        // guard from finalizing the async session re-entrantly (see
        // DestroyMenuPopupWindow).
        const bool previousDestroying    = controller.destroyingPopupWindow;
        controller.destroyingPopupWindow = true;
        DestroyWindow(hwnd);
        controller.destroyingPopupWindow = previousDestroying;
        return false;
    }
    const auto closeUnregisteredPopup = wil::scope_exit([&]() noexcept
    {
        if (popup && popup->hwnd)
            DestroyMenuPopupWindow(*popup);
    });
    popup->host.SetTheme(controller.theme);
    popup->RebuildItemOffsets();
    // Popup menus stay fully app-rendered even on the transparent composition host.
    // Applying a DWM system backdrop here pulls in OS palette colors that do not match
    // custom consumer themes, so the popup HWND intentionally stays backdrop-free.
    popup->usesSystemBackdrop = false;

    // Compute menu size
    D2D1_SIZE_F sizeDip                  = ComputeMenuSize(items, itemCount, popup->host, &popup->acceleratorColumnWidthDip, &popup->hasSubmenuItems);
    const float requestedVisibleWidthDip = ResolveVisibleMenuWidthDip(sizeDip.width, &controller, isSubmenu);
    const RECT availableRectPx           = ComputePopupPosition(screenPoint,
                                                                requestedVisibleWidthDip,
                                                                1000000.0f,
                                                                popup->dpi,
                                                                isSubmenu,
                                                                controller.sessionCallbacks.rootHorizontalAlignment,
                                                                controller.sessionCallbacks.rootVerticalPlacement,
                                                                parentWindowRect,
                                                                parentItemRect);
    if (! PrepareMenuDescriptionSize(*popup, sizeDip, availableRectPx))
        return false;
    const float requestedVisibleHeightDip = (! isSubmenu && controller.sessionCallbacks.maxRootHeightDip > 0.0f)
                                                ? (std::min)(sizeDip.height, controller.sessionCallbacks.maxRootHeightDip)
                                                : sizeDip.height;

    // Position the window
    const RECT surfaceRectPx     = ComputePopupPosition(screenPoint,
                                                        requestedVisibleWidthDip,
                                                        requestedVisibleHeightDip,
                                                        popup->dpi,
                                                        isSubmenu,
                                                        controller.sessionCallbacks.rootHorizontalAlignment,
                                                        controller.sessionCallbacks.rootVerticalPlacement,
                                                        parentWindowRect,
                                                        parentItemRect);
    const RECT windowRect        = ComputePopupWindowRect(surfaceRectPx, popup->shadowMargins, popup->dpi);
    const float visibleWidthDip  = popup->PixelToDip(static_cast<float>(surfaceRectPx.right - surfaceRectPx.left));
    const float visibleHeightDip = popup->PixelToDip(static_cast<float>(surfaceRectPx.bottom - surfaceRectPx.top));
    popup->menuWidthDip          = visibleWidthDip;
    popup->menuHeightDip         = visibleHeightDip;
    popup->windowWidthDip        = popup->PixelToDip(static_cast<float>(windowRect.right - windowRect.left));
    popup->windowHeightDip       = popup->PixelToDip(static_cast<float>(windowRect.bottom - windowRect.top));
    popup->surfaceRectPx         = surfaceRectPx;
    popup->windowRectPx          = windowRect;
    popup->contentHeightDip      = sizeDip.height;
    popup->ClampScrollOffset();

    const MenuItemVisualStyle popupItemStyle     = ResolveMenuVisualStyle(controller.theme);
    const MenuSurfaceMaterialStyle popupMaterial = ResolveMenuSurfaceMaterialStyle(controller.theme, popupItemStyle);
    if (popupMaterial.backdropOpacity > 0.0f && popupMaterial.backdropBlurDip > 0.0f)
    {
        const auto backdropStartedAt = std::chrono::steady_clock::now();
        popup->usesAppBackdropBlur   = CaptureBackdropScreenRegion(surfaceRectPx, popup->backdropSnapshot.capture, L"Menu");
        Debug::Perf::Emit(L"dxui.menu.backdrop_capture_us",
                          isSubmenu ? L"submenu" : L"root",
                          Debug::Perf::ElapsedUs(backdropStartedAt),
                          static_cast<uint64_t>(surfaceRectPx.right - surfaceRectPx.left),
                          static_cast<uint64_t>(surfaceRectPx.bottom - surfaceRectPx.top),
                          popup->usesAppBackdropBlur ? S_OK : E_FAIL);
    }

    // Create the content control
    auto content   = std::make_unique<MenuContentControl>();
    content->popup = popup.get();
    if (! PopulateMenuAccessibility(*content, *popup))
        return false;
    content->SetBounds(D2D1::RectF(0, 0, popup->windowWidthDip, popup->windowHeightDip));
    popup->host.SetRoot(std::move(content));
    popup->keyboardIndex = popup->FindInitialKeyboardItem(focusFirstNavigableItem);
    SynchronizeMenuAccessibility(*popup);
    MenuPopup* const registeredPopup = popup.get();
    controller.popups.push_back(std::move(popup));

    // Resize and show
    const int widthPx  = windowRect.right - windowRect.left;
    const int heightPx = windowRect.bottom - windowRect.top;
    SetWindowPos(hwnd, HWND_TOP, windowRect.left, windowRect.top, widthPx, heightPx, SWP_NOACTIVATE | SWP_NOOWNERZORDER);
    if (! controller.running)
    {
        // Moving to a monitor with another DPI can reflow synchronously. A failed reflow dismissed the
        // session: never show or activate this popup. It stays registered, so the modal loop, the
        // deferred async finalization or the unpublished controller's destructor tears it down.
        return false;
    }
    ApplyMenuPopupWindowRegion(hwnd, registeredPopup->shadowMargins, registeredPopup->dpi, widthPx, heightPx);
    if (! registeredPopup->keyboardIndex.has_value())
    {
        POINT cursorScreen{};
        if (GetCursorPos(&cursorScreen) != FALSE) // getcursorpos-allow: initialize stationary popup hover on show
        {
            POINT cursorClient = cursorScreen;
            if (ScreenToClient(hwnd, &cursorClient) != FALSE)
            {
                const D2D1_POINT_2F cursorDip{
                    registeredPopup->PixelToDip(static_cast<float>(cursorClient.x)),
                    registeredPopup->PixelToDip(static_cast<float>(cursorClient.y)),
                };
                if (const std::optional<size_t> hit = HitTestMenuItem(*registeredPopup, cursorDip); hit.has_value())
                {
                    registeredPopup->hoveredIndex        = hit;
                    controller.lastPointerScreenPoint    = cursorScreen;
                    controller.hasLastPointerScreenPoint = true;
                }
            }
        }
    }
    [[maybe_unused]] const bool initialFrameReady =
        forceInitialRender ? registeredPopup->host.RenderInitialFrameForShow() : registeredPopup->host.PrimeForShow();
    ShowWindow(hwnd, SW_SHOWNOACTIVATE);

    InvalidateRect(hwnd, nullptr, FALSE);

    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.popup-create-end",
                                L"owner={:#x} hwnd={:#x} popupIndex={} point=({}, {}) windowRect=({}, {}, {}, {}) surfaceRect=({}, {}, {}, {}) "
                                L"dpi={} items={} keyboardHas={} keyboard={} visibleDip=({:.1f}, {:.1f}) contentHeightDip={:.1f} "
                                L"maxRootHeightDip={:.1f} initialFrameReady={}",
                                TraceHwndValue(controller.ownerHwnd),
                                TraceHwndValue(hwnd),
                                TracePopupIndex(controller, registeredPopup),
                                screenPoint.x,
                                screenPoint.y,
                                windowRect.left,
                                windowRect.top,
                                windowRect.right,
                                windowRect.bottom,
                                surfaceRectPx.left,
                                surfaceRectPx.top,
                                surfaceRectPx.right,
                                surfaceRectPx.bottom,
                                static_cast<unsigned int>(registeredPopup->dpi),
                                registeredPopup->itemCount,
                                TraceBool(registeredPopup->keyboardIndex.has_value()),
                                TraceOptionalSizeValue(registeredPopup->keyboardIndex),
                                registeredPopup->menuWidthDip,
                                registeredPopup->menuHeightDip,
                                registeredPopup->contentHeightDip,
                                controller.sessionCallbacks.maxRootHeightDip,
                                TraceBool(initialFrameReady));

    return true;
}

// ---------------------------------------------------------------------------
// Open a submenu for a given item
// ---------------------------------------------------------------------------

void OpenSubmenu(MenuController& controller, MenuPopup& parent, size_t itemIndex, bool focusFirstNavigableItem)
{
    if (itemIndex >= parent.itemCount)
        return;
    const auto& item = parent.items[itemIndex];
    if (item.children.empty())
        return;

    // Close any existing submenu deeper than this parent
    while (controller.popups.size() > 1 && controller.popups.back().get() != &parent)
    {
        auto& child = controller.popups.back();
        DestroyMenuPopupWindow(*child);
        controller.popups.pop_back();
    }

    // Compute position: right edge of the parent item using the spec-defined cascade offset
    const float previousScrollOffsetDip = parent.scrollOffsetDip;
    parent.EnsureItemVisible(itemIndex);
    if (parent.scrollOffsetDip != previousScrollOffsetDip)
        InvalidatePopup(parent);
    RECT parentWindowRect{};
    GetWindowRect(parent.hwnd, &parentWindowRect);
    const RECT parentItemRect = GetPopupItemScreenRect(parent, itemIndex);
    POINT subPt{parentItemRect.right, parentItemRect.top};

    const auto startedAt = std::chrono::steady_clock::now();
    if (CreateMenuPopupWindow(
            controller, item.children.data(), item.children.size(), subPt, true, &parentWindowRect, &parentItemRect, true, focusFirstNavigableItem))
    {
        if (! controller.popups.empty())
        {
            controller.popups.back()->openedFromItemIndex = itemIndex;
        }

        Debug::Perf::Emit(
            L"DxUi::PopupShow", L"submenu", Debug::Perf::ElapsedUs(startedAt), static_cast<uint64_t>(item.children.size()), static_cast<uint64_t>(itemIndex));
    }
}

void CancelSubmenuHoverTimer(MenuPopup& popup) noexcept
{
    if (! popup.hoverTimerId || ! popup.hwnd)
    {
        popup.hoverTimerId        = 0;
        popup.hoverTimerKind      = MenuPopup::SubmenuHoverTimerKind::None;
        popup.hoverTimerItemIndex = SIZE_MAX;
        return;
    }

    KillTimer(popup.hwnd, kSubmenuHoverTimerId);
    popup.hoverTimerId        = 0;
    popup.hoverTimerKind      = MenuPopup::SubmenuHoverTimerKind::None;
    popup.hoverTimerItemIndex = SIZE_MAX;
}

void DestroyMenuPopupWindow(MenuPopup& popup) noexcept
{
    CancelSubmenuHoverTimer(popup);

    const HWND hwnd = popup.hwnd;
    if (hwnd && IsWindow(hwnd) != FALSE)
    {
        // DestroyWindow delivers WM_NCDESTROY (and possibly WM_CAPTURECHANGED)
        // synchronously while GWLP_USERDATA still points at this popup. Mark the
        // destroy as controller-initiated so the popup WndProc's external-teardown
        // guard does not Dismiss + FinalizeAsyncMenuController re-entrantly, which
        // would delete this popup (and the controller) while callers such as
        // CloseSubmenuChainFrom and CloseTopmostSubmenu are still using them.
        MenuController* const controller = popup.controller;
        const bool previousDestroying    = controller ? controller->destroyingPopupWindow : false;
        if (controller)
        {
            controller->destroyingPopupWindow = true;
        }
        DestroyWindow(hwnd);
        if (controller)
        {
            controller->destroyingPopupWindow = previousDestroying;
        }
    }

    popup.host.Detach();
    popup.hwnd = nullptr;
}

[[nodiscard]] bool HasPendingSubmenuOpenTimer(const MenuPopup& popup) noexcept
{
    return popup.hoverTimerId != 0 && popup.hoverTimerKind == MenuPopup::SubmenuHoverTimerKind::PendingOpen;
}

[[nodiscard]] std::optional<size_t> FindPopupIndex(const MenuController& controller, const MenuPopup& popup) noexcept
{
    for (size_t i = 0; i < controller.popups.size(); ++i)
    {
        if (controller.popups[i].get() == &popup)
        {
            return i;
        }
    }

    return std::nullopt;
}

[[nodiscard]] bool PopupOwnsOpenChildFromItem(const MenuController& controller, size_t popupIndex, size_t itemIndex) noexcept
{
    const size_t childIndex = popupIndex + 1u;
    if (childIndex >= controller.popups.size())
    {
        return false;
    }

    const std::optional<size_t> openedFromItemIndex = controller.popups[childIndex]->openedFromItemIndex;
    return openedFromItemIndex.has_value() && openedFromItemIndex.value() == itemIndex;
}

[[nodiscard]] bool PopupHoverOwnsOpenChild(const MenuController& controller, size_t popupIndex, const MenuPopup& popup) noexcept
{
    return popup.hoveredIndex.has_value() && PopupOwnsOpenChildFromItem(controller, popupIndex, popup.hoveredIndex.value());
}

void ScheduleSubmenuCloseTimer(MenuPopup& popup) noexcept
{
    if (! popup.hwnd)
    {
        popup.hoverTimerId        = 0;
        popup.hoverTimerKind      = MenuPopup::SubmenuHoverTimerKind::None;
        popup.hoverTimerItemIndex = SIZE_MAX;
        return;
    }

    if (popup.hoverTimerId && popup.hoverTimerKind == MenuPopup::SubmenuHoverTimerKind::PendingClose)
    {
        return;
    }

    CancelSubmenuHoverTimer(popup);
    popup.hoverTimerId        = SetTimer(popup.hwnd, kSubmenuHoverTimerId, static_cast<UINT>(kCascadeHoverDelayMs), nullptr);
    popup.hoverTimerKind      = MenuPopup::SubmenuHoverTimerKind::PendingClose;
    popup.hoverTimerItemIndex = SIZE_MAX;
}

void ScheduleSubmenuOpenTimer(MenuPopup& popup, size_t itemIndex) noexcept
{
    if (! popup.hwnd || itemIndex >= popup.itemCount)
    {
        CancelSubmenuHoverTimer(popup);
        return;
    }

    CancelSubmenuHoverTimer(popup);
    popup.hoverTimerId        = SetTimer(popup.hwnd, kSubmenuHoverTimerId, static_cast<UINT>(kCascadeHoverDelayMs), nullptr);
    popup.hoverTimerKind      = MenuPopup::SubmenuHoverTimerKind::PendingOpen;
    popup.hoverTimerItemIndex = itemIndex;
}

void ReconcileOpenSubmenuAfterScroll(MenuController& controller, MenuPopup& popup) noexcept
{
    const std::optional<size_t> popupIndex = FindPopupIndex(controller, popup);
    if (! popupIndex.has_value() || popupIndex.value() + 1u >= controller.popups.size())
        return;

    if (PopupHoverOwnsOpenChild(controller, popupIndex.value(), popup))
        CancelSubmenuHoverTimer(popup);
    else if (! HasPendingSubmenuOpenTimer(popup))
        ScheduleSubmenuCloseTimer(popup);
}

void CloseSubmenuChainFrom(MenuController& controller, MenuPopup& parent) noexcept
{
    bool closedAny = false;
    while (controller.popups.size() > 1 && controller.popups.back().get() != &parent)
    {
        auto& child = controller.popups.back();
        DestroyMenuPopupWindow(*child);
        controller.popups.pop_back();
        closedAny = true;
    }

    if (closedAny && parent.hwnd)
    {
        InvalidatePopup(parent);
    }
}

// Fires a pending submenu hover timer on a popup: opens the deferred submenu or
// closes the open submenu chain. Both async and modal sessions dispatch popup
// timers through this window procedure; unrelated thread timers use normal dispatch.
void HandleSubmenuHoverTimer(MenuController& controller, MenuPopup& popup)
{
    if (popup.hoverTimerId == 0 || popup.hoverTimerKind == MenuPopup::SubmenuHoverTimerKind::None)
    {
        return;
    }

    if (popup.hoverTimerKind == MenuPopup::SubmenuHoverTimerKind::PendingOpen && popup.hoverTimerItemIndex < popup.itemCount)
    {
        KillTimer(popup.hwnd, kSubmenuHoverTimerId);
        popup.hoverTimerId         = 0;
        popup.hoverTimerKind       = MenuPopup::SubmenuHoverTimerKind::None;
        const size_t openItemIndex = popup.hoverTimerItemIndex;
        popup.hoverTimerItemIndex  = SIZE_MAX;
        OpenSubmenu(controller, popup, openItemIndex, false);
    }
    else if (popup.hoverTimerKind == MenuPopup::SubmenuHoverTimerKind::PendingClose)
    {
        KillTimer(popup.hwnd, kSubmenuHoverTimerId);
        popup.hoverTimerId        = 0;
        popup.hoverTimerKind      = MenuPopup::SubmenuHoverTimerKind::None;
        popup.hoverTimerItemIndex = SIZE_MAX;
        CloseSubmenuChainFrom(controller, popup);
    }
}

// ---------------------------------------------------------------------------
// Process mouse move in a popup
// ---------------------------------------------------------------------------

void HandleMenuMouseMoveAtPointDip(MenuController& controller, MenuPopup& popup, D2D1_POINT_2F pointDip, bool pointerTakesKeyboardFocus = true) noexcept
{
    if (popup.draggingSliderItemIndex.has_value())
    {
        UpdateSliderInteractionAtPoint(popup, popup.draggingSliderItemIndex.value(), pointDip);
        return;
    }

    if (popup.draggingScrollbarThumb)
    {
        const float previousScrollOffsetDip = popup.scrollOffsetDip;
        const D2D1_RECT_F track             = popup.GetScrollbarTrackRect();
        const D2D1_RECT_F thumb             = popup.GetScrollbarThumbRect();
        const float thumbHeight             = thumb.bottom - thumb.top;
        const float available               = (std::max)(0.0f, (track.bottom - track.top) - thumbHeight);
        if (available > 0.0f)
        {
            const float thumbTop  = (std::clamp)(pointDip.y - popup.scrollbarDragOffsetDip, track.top, track.bottom - thumbHeight);
            popup.scrollOffsetDip = ((thumbTop - track.top) / available) * popup.GetScrollExtent();
            popup.ClampScrollOffset();
            if (popup.scrollOffsetDip != previousScrollOffsetDip)
            {
                popup.hoveredIndex.reset();
                CancelSubmenuHoverTimer(popup);
                InvalidatePopup(popup);
                ReconcileOpenSubmenuAfterScroll(controller, popup);
            }
        }
        return;
    }

    MenuPopup::ScrollbarHotPart nextHotPart = MenuPopup::ScrollbarHotPart::None;
    if (popup.NeedsScrollbar() && PointInRect(popup.GetScrollbarTrackRect(), pointDip))
    {
        nextHotPart = PointInRect(popup.GetScrollbarThumbRect(), pointDip) ? MenuPopup::ScrollbarHotPart::Thumb : MenuPopup::ScrollbarHotPart::Track;
    }
    if (popup.scrollbarHotPart != nextHotPart)
    {
        popup.scrollbarHotPart = nextHotPart;
        InvalidatePopup(popup);
    }

    const std::optional<size_t> hit = HitTestMenuItem(popup, pointDip);
    const bool changed              = (hit != popup.hoveredIndex);
    popup.hoveredIndex              = hit;
    const bool keyboardFocusCleared = pointerTakesKeyboardFocus && popup.keyboardIndex.has_value();
    if (keyboardFocusCleared)
        popup.keyboardIndex.reset();

    if (changed || keyboardFocusCleared)
        InvalidatePopup(popup);

    if (changed)
    {
        // Start/cancel submenu hover timer
        if (popup.hoverTimerId)
        {
            KillTimer(popup.hwnd, kSubmenuHoverTimerId);
            popup.hoverTimerId        = 0;
            popup.hoverTimerKind      = MenuPopup::SubmenuHoverTimerKind::None;
            popup.hoverTimerItemIndex = SIZE_MAX;
        }

        if (hit.has_value())
        {
            const size_t hitIndex = hit.value();
            if (hitIndex < popup.itemCount && ! popup.items[hitIndex].children.empty() && popup.items[hitIndex].enabled)
            {
                const std::optional<size_t> popupIndex = FindPopupIndex(controller, popup);
                if (popupIndex.has_value() && PopupOwnsOpenChildFromItem(controller, popupIndex.value(), hitIndex))
                {
                    CancelSubmenuHoverTimer(popup);
                }
                else
                {
                    ScheduleSubmenuOpenTimer(popup, hitIndex);
                }
            }
            else if (controller.popups.size() > 1 && controller.popups.back().get() != &popup)
            {
                ScheduleSubmenuCloseTimer(popup);
            }
        }
        else if (controller.popups.size() > 1 && controller.popups.back().get() != &popup)
        {
            ScheduleSubmenuCloseTimer(popup);
        }
    }
}

void DestroyPopupChain(MenuController& controller) noexcept
{
    for (auto it = controller.popups.rbegin(); it != controller.popups.rend(); ++it)
    {
        auto& popup = *it;
        DestroyMenuPopupWindow(*popup);
    }
    controller.popups.clear();
}

void ActivatePopupForKeyboard(MenuPopup& popup) noexcept
{
    if (! popup.hwnd || IsWindow(popup.hwnd) == FALSE)
    {
        return;
    }

    SetWindowPos(popup.hwnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOOWNERZORDER);
    SetActiveWindow(popup.hwnd);
    SetFocus(popup.hwnd);
}

std::vector<std::unique_ptr<MenuController>>& ActiveAsyncMenuControllers() noexcept
{
    thread_local std::vector<std::unique_ptr<MenuController>> controllers;
    return controllers;
}

// Process-exit shutdown runs before the window-host registry is swept. Keep async menus
// disabled for the rest of this UI thread so reentrant teardown callbacks cannot add a
// popup host after that sweep has taken its snapshot.
thread_local bool g_asyncMenuProcessExit = false;

[[nodiscard]] bool BeginAsyncMenuInteraction(MenuController& controller) noexcept
{
    MenuPopup* root = controller.GetRootPopup();
    if (! root || ! root->hwnd)
    {
        return false;
    }

    controller.previousCapture            = GetCapture();
    controller.previousFocus              = GetFocus();
    controller.ignoreInitialLeftButtonUp  = controller.sessionCallbacks.ignoreInitialLeftButtonUp || (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
    controller.ignoreInitialRightButtonUp = controller.sessionCallbacks.ignoreInitialRightButtonUp || (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
    controller.leftButtonDownInPopup      = false;
    controller.rightButtonDownInPopup     = false;

    SetCapture(root->hwnd);
    ActivatePopupForKeyboard(*root);
    controller.asyncInteractionActive = true;
    ApplyMenuCursorAtPointer(controller);
    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.async-start",
                                L"owner={:#x} root={:#x} previousCapture={:#x} previousFocus={:#x} currentCapture={:#x} popupCount={} items={} "
                                L"ignoreLeft={} ignoreRight={}",
                                TraceHwndValue(controller.ownerHwnd),
                                TraceHwndValue(root->hwnd),
                                TraceHwndValue(controller.previousCapture),
                                TraceHwndValue(controller.previousFocus),
                                TraceHwndValue(GetCapture()),
                                controller.popups.size(),
                                controller.rootItems.size(),
                                TraceBool(controller.ignoreInitialLeftButtonUp),
                                TraceBool(controller.ignoreInitialRightButtonUp));
    return true;
}

void EndAsyncMenuInteraction(MenuController& controller) noexcept
{
    controller.asyncInteractionActive = false;
    if (const HWND captured = GetCapture(); captured && controller.FindPopupForHwnd(captured))
    {
        DXUI_MENU_DIAGNOSTICS_TRACE(
            L"menu.async-release-capture", L"captured={:#x} owner={:#x}", TraceHwndValue(captured), TraceHwndValue(controller.ownerHwnd));
        ReleaseCapture();
    }

    const HWND currentFocus = GetFocus();
    if (controller.previousFocus && IsWindow(controller.previousFocus) != FALSE && currentFocus && controller.FindPopupForHwnd(currentFocus))
    {
        SetFocus(controller.previousFocus);
        DXUI_MENU_DIAGNOSTICS_TRACE(
            L"menu.async-restore-focus", L"previousFocus={:#x} focusAfter={:#x}", TraceHwndValue(controller.previousFocus), TraceHwndValue(GetFocus()));
    }
}

MenuController::~MenuController() noexcept
{
    // CRT thread-local teardown can destroy a still-open async controller.
    // ReleaseCapture/DestroyWindow synchronously re-enter MenuWndProc: keep
    // finalization closed before any host/member destructor can release it.
    asyncFinalizing = true;
    running         = false;
    EndAsyncMenuInteraction(*this);
    DestroyPopupChain(*this);
}

void FinalizeAsyncMenuController(MenuController& controller) noexcept
{
    if (! controller.asyncSession || controller.asyncFinalizing)
    {
        return;
    }

    controller.asyncFinalizing = true;

    std::unique_ptr<MenuController> ownedController;
    auto& controllers = ActiveAsyncMenuControllers();
    const auto it     = std::find_if(controllers.begin(), controllers.end(), [&controller](const std::unique_ptr<MenuController>& candidate) noexcept {
        return candidate.get() == &controller;
    });
    if (it != controllers.end())
    {
        ownedController = std::move(*it);
        controllers.erase(it);
    }

    MenuController& target             = ownedController ? *ownedController : controller;
    const std::optional<int> result    = target.result;
    ContextMenuClosedCallback onClosed = std::move(target.asyncOnClosed);
    EndAsyncMenuInteraction(target);
    DestroyPopupChain(target);
    RestoreWindowCursorAfterMenu(target);

    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.async-end",
                                L"owner={:#x} result={} captureAfter={:#x} focusAfter={:#x}",
                                TraceHwndValue(target.ownerHwnd),
                                result.value_or(-1),
                                TraceHwndValue(GetCapture()),
                                TraceHwndValue(GetFocus()));

    if (onClosed)
    {
        onClosed(result);
    }
}

[[nodiscard]] bool SwitchRootPopup(MenuController& controller,
                                   ContextMenuRootSwitchRequest request,
                                   std::wstring_view popupDetail,
                                   bool focusFirstNavigableItem) noexcept
{
    DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup switch-begin owner={:#x} capture={:#x} detail='{}' oldPopupCount={} newItems={} point=({}, {}) focusFirst={}",
                    reinterpret_cast<uintptr_t>(controller.ownerHwnd),
                    reinterpret_cast<uintptr_t>(GetCapture()),
                    popupDetail,
                    controller.popups.size(),
                    request.items.size(),
                    request.screenPoint.x,
                    request.screenPoint.y,
                    focusFirstNavigableItem ? L"true" : L"false");
    DestroyPopupChain(controller);

    controller.rootItems = std::move(request.items);
    if (controller.rootItems.empty())
    {
        DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup switch-dismiss-empty owner={:#x}", reinterpret_cast<uintptr_t>(controller.ownerHwnd));
        controller.Dismiss();
        return false;
    }

    const auto startedAt = std::chrono::steady_clock::now();
    // Root switches repaint before returning to the modal loop so fast hover/keyboard
    // changes never expose a blank popup between the old root and new root.
    if (! CreateMenuPopupWindow(
            controller, controller.rootItems.data(), controller.rootItems.size(), request.screenPoint, false, nullptr, nullptr, true, focusFirstNavigableItem))
    {
        DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup switch-create-failed owner={:#x}", reinterpret_cast<uintptr_t>(controller.ownerHwnd));
        controller.Dismiss();
        return false;
    }

    if (MenuPopup* root = controller.GetRootPopup(); root && root->hwnd)
    {
#if DXUI_ENABLE_DIAGNOSTICS
        if (root->host.DebugGetRenderCount() > 0u)
        {
            ++controller.rootSwitchImmediateRenderCount;
        }
#endif
        [[maybe_unused]] const HWND previousCapture = GetCapture();
        SetCapture(root->hwnd);
        ActivatePopupForKeyboard(*root);
        ApplyMenuCursorAtPointer(controller);
        DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup switch-capture root={:#x} previousCapture={:#x} currentCapture={:#x}",
                        reinterpret_cast<uintptr_t>(root->hwnd),
                        reinterpret_cast<uintptr_t>(previousCapture),
                        reinterpret_cast<uintptr_t>(GetCapture()));
    }
    Debug::Perf::Emit(L"DxUi::PopupShow", popupDetail, Debug::Perf::ElapsedUs(startedAt), static_cast<uint64_t>(controller.rootItems.size()), 0u);
    return true;
}

[[nodiscard]] MenuPopup* FindPointerTargetPopup(MenuController& controller, POINT screenPt) noexcept
{
    for (auto it = controller.popups.rbegin(); it != controller.popups.rend(); ++it)
    {
        const RECT wr = (*it)->GetInteractiveScreenRect();
        if (PtInRect(&wr, screenPt))
        {
            return it->get();
        }
    }

    for (auto& popup : controller.popups)
    {
        if (popup->draggingScrollbarThumb || popup->draggingSliderItemIndex.has_value())
        {
            return popup.get();
        }
    }

    return nullptr;
}

[[nodiscard]] bool IsPointInAnyPopupInteractiveRect(const MenuController& controller, POINT screenPt) noexcept
{
    for (const auto& popup : controller.popups)
    {
        const RECT interactiveRect = popup->GetInteractiveScreenRect();
        if (PtInRect(&interactiveRect, screenPt))
        {
            return true;
        }
    }

    return false;
}

// While a popup holds capture Windows sends no WM_SETCURSOR, so the menu chooses the cursor itself. A window of this
// thread under the pointer chooses its own, as it would without capture; windows of other threads are never messaged.
[[nodiscard]] bool ForwardSetCursorToThreadWindowAt(POINT screenPoint) noexcept
{
    const HWND window = WindowFromPoint(screenPoint);
    if (! window || GetWindowThreadProcessId(window, nullptr) != GetCurrentThreadId())
        return false;
    const LPARAM point = MAKELPARAM(static_cast<WORD>(static_cast<SHORT>(screenPoint.x)), static_cast<WORD>(static_cast<SHORT>(screenPoint.y)));
    const LRESULT hit  = SendMessageW(window, WM_NCHITTEST, 0, point);
    if (hit == HTTRANSPARENT || ! IsWindow(window))
        return false;
    SendMessageW(window, WM_SETCURSOR, reinterpret_cast<WPARAM>(window), MAKELPARAM(static_cast<WORD>(static_cast<SHORT>(hit)), WM_MOUSEMOVE));
    return true;
}

void ShowArrowCursor() noexcept
{
    static const HCURSOR arrow = LoadCursorW(nullptr, IDC_ARROW);
    if (GetCursor() != arrow)
        SetCursor(arrow);
}

// The standard arrow over the menu's popups (and while one drags a slider or scrollbar); elsewhere the cursor the
// window under the pointer chooses, or the arrow for another thread's window. That window's WM_SETCURSOR handling
// may dismiss the menu, so the forward never runs inside a menu handler: it is posted to the root popup, whose
// handler forwards as its last action and touches neither popup nor controller afterwards.
void ApplyMenuPointerCursor(MenuController& controller, POINT screenPoint, bool overMenu) noexcept
{
    controller.cursorChosen = true;
    if (overMenu)
    {
        controller.cursorForwardPending = false;
        ShowArrowCursor();
        return;
    }
    // Without its registered message the forward is not posted, and the arrow shows, as when the post fails.
    const MenuPopup* const root                   = controller.GetRootPopup();
    const WndMsg::RegisteredMessage forwardCursor = WndMsg::MenuPopupForwardCursor();
    controller.cursorForwardPoint                 = screenPoint;
    controller.cursorForwardPending               = forwardCursor && root && root->hwnd && PostMessageW(root->hwnd, forwardCursor.value, 0, 0) != FALSE;
    if (! controller.cursorForwardPending)
        ShowArrowCursor();
}

// One cursor choice when the menu takes or moves capture; pointer moves choose it afterwards.
void ApplyMenuCursorAtPointer(MenuController& controller) noexcept
{
    POINT pointer{};
    if (GetCursorPos(&pointer) != FALSE) // getcursorpos-allow: one-shot cursor choice when a menu takes or moves capture
        ApplyMenuPointerCursor(controller, pointer, FindPointerTargetPopup(controller, pointer) != nullptr);
}

// When the menu closes, the window under the pointer chooses its cursor at once rather than at the next pointer move
// (a caller that runs a long command after a modal menu would otherwise keep the menu's arrow).
void RestoreWindowCursorAfterMenu(const MenuController& controller) noexcept
{
    POINT pointer{};
    if (controller.cursorChosen && GetCursorPos(&pointer) != FALSE) // getcursorpos-allow: one-shot cursor restoration when a menu closes
        static_cast<void>(ForwardSetCursorToThreadWindowAt(pointer));
}

[[nodiscard]] std::optional<D2D1_POINT_2F> ScreenPointToPopupDip(const MenuPopup& popup, POINT screenPt) noexcept
{
    RECT wr{};
    if (! popup.hwnd || GetWindowRect(popup.hwnd, &wr) == FALSE)
    {
        return std::nullopt;
    }

    return D2D1::Point2F(popup.PixelToDip(static_cast<float>(screenPt.x - wr.left)), popup.PixelToDip(static_cast<float>(screenPt.y - wr.top)));
}

[[nodiscard]] D2D1_POINT_2F PopupClientPointToDip(const MenuPopup& popup, POINT clientPoint) noexcept
{
    return D2D1::Point2F(popup.PixelToDip(static_cast<float>(clientPoint.x)), popup.PixelToDip(static_cast<float>(clientPoint.y)));
}

[[nodiscard]] bool IsDeliveredPopupSurfacePoint(const MenuPopup& popup, const MenuPointerEvent& event) noexcept
{
    return event.source == MenuInputSource::PopupWndProc && event.hwnd == popup.hwnd && event.deliveredPopupPointDip.has_value() &&
           PointInRect(popup.GetSurfaceRect(), event.deliveredPopupPointDip.value());
}

[[nodiscard]] MenuPopup* FindPointerTargetPopup(MenuController& controller, const MenuPointerEvent& event) noexcept
{
    if (MenuPopup* popup = controller.FindPopupForHwnd(event.hwnd); popup && IsDeliveredPopupSurfacePoint(*popup, event))
    {
        return popup;
    }

    return FindPointerTargetPopup(controller, event.screenPoint);
}

[[nodiscard]] std::optional<D2D1_POINT_2F> ResolvePointerPopupPointDip(const MenuPopup& popup, const MenuPointerEvent& event) noexcept
{
    if (event.hwnd == popup.hwnd && event.deliveredPopupPointDip.has_value())
    {
        return event.deliveredPopupPointDip;
    }

    return ScreenPointToPopupDip(popup, event.screenPoint);
}

struct MenuPointerTargetTrace
{
    int popupIndex      = -1;
    uintptr_t popupHwnd = 0u;
    std::optional<size_t> hitIndex;
    std::optional<size_t> hoveredIndex;
    std::optional<size_t> keyboardIndex;
};

[[nodiscard]] MenuPointerTargetTrace CaptureMenuPointerTargetTrace(MenuController& controller, const MenuPointerEvent& event) noexcept
{
    MenuPointerTargetTrace trace;
    MenuPopup* popup = FindPointerTargetPopup(controller, event);
    if (! popup)
    {
        return trace;
    }

    trace.popupIndex                            = TracePopupIndex(controller, popup);
    trace.popupHwnd                             = TraceHwndValue(popup->hwnd);
    trace.hoveredIndex                          = popup->hoveredIndex;
    trace.keyboardIndex                         = popup->keyboardIndex;
    const std::optional<D2D1_POINT_2F> pointDip = ResolvePointerPopupPointDip(*popup, event);
    if (pointDip.has_value())
    {
        trace.hitIndex = HitTestMenuItem(*popup, pointDip.value());
    }
    return trace;
}

void TraceMenuPointerRoute(MenuController& controller,
                           const MenuPointerEvent& event,
                           const MenuPointerTargetTrace& before,
                           MenuInputDisposition disposition) noexcept
{
    static_cast<void>(before);
    static_cast<void>(disposition);

    const MenuPointerTargetTrace after = CaptureMenuPointerTargetTrace(controller, event);
    DXUI_MENU_DIAGNOSTICS_TRACE(
        L"menu.pointer",
        L"source={} kind={} hwnd={:#x} point=({}, {}) messageTime={} keyboardRootTimeHas={} keyboardRootTime={} deliveredPopupPointHas={} "
        L"deliveredPopupPoint=({:.1f}, {:.1f}) "
        L"hitWindow={:#x} mayInvoke={} mayDismiss={} maySwitchRoot={} "
        L"mayKeyboardFocus={} beforePopup={} beforePopupHwnd={:#x} beforeHitHas={} beforeHit={} beforeHoverHas={} "
        L"beforeHover={} beforeKeyboardHas={} beforeKeyboard={} afterPopup={} afterPopupHwnd={:#x} afterHitHas={} "
        L"afterHit={} afterHoverHas={} afterHover={} afterKeyboardHas={} afterKeyboard={} popups={} running={} result={} disposition={}",
        TraceInputSourceName(event.source),
        TracePointerKindName(event.kind),
        TraceHwndValue(event.hwnd),
        event.screenPoint.x,
        event.screenPoint.y,
        static_cast<unsigned int>(event.messageTime),
        TraceBool(controller.hasLastKeyboardRootSwitchMessageTime),
        static_cast<unsigned int>(controller.lastKeyboardRootSwitchMessageTime),
        TraceBool(event.deliveredPopupPointDip.has_value()),
        event.deliveredPopupPointDip.has_value() ? event.deliveredPopupPointDip->x : -1.0f,
        event.deliveredPopupPointDip.has_value() ? event.deliveredPopupPointDip->y : -1.0f,
        TraceHwndValue(WindowFromPoint(event.screenPoint)),
        TraceBool(event.mayInvoke),
        TraceBool(event.mayDismiss),
        TraceBool(event.maySwitchRoot),
        TraceBool(event.mayTakeKeyboardFocus),
        before.popupIndex,
        before.popupHwnd,
        TraceBool(before.hitIndex.has_value()),
        TraceOptionalSizeValue(before.hitIndex),
        TraceBool(before.hoveredIndex.has_value()),
        TraceOptionalSizeValue(before.hoveredIndex),
        TraceBool(before.keyboardIndex.has_value()),
        TraceOptionalSizeValue(before.keyboardIndex),
        after.popupIndex,
        after.popupHwnd,
        TraceBool(after.hitIndex.has_value()),
        TraceOptionalSizeValue(after.hitIndex),
        TraceBool(after.hoveredIndex.has_value()),
        TraceOptionalSizeValue(after.hoveredIndex),
        TraceBool(after.keyboardIndex.has_value()),
        TraceOptionalSizeValue(after.keyboardIndex),
        controller.popups.size(),
        TraceBool(controller.running),
        controller.result.value_or(-1),
        TraceDispositionName(disposition));
}

[[nodiscard]] MenuInputDisposition RouteMenuPointerHover(MenuController& controller, const MenuPointerEvent& event) noexcept
{
    MenuPopup* targetPopup = FindPointerTargetPopup(controller, event);
    if (! targetPopup && ! event.maySwitchRoot)
    {
        return MenuInputDisposition::Ignored;
    }

    POINT routedRootSwitchPoint = event.screenPoint;

    bool pointerMoved = false;
    if (! targetPopup && event.maySwitchRoot)
    {
        pointerMoved = ! controller.hasLastRootSwitchPointerScreenPoint || routedRootSwitchPoint.x != controller.lastRootSwitchPointerScreenPoint.x ||
                       routedRootSwitchPoint.y != controller.lastRootSwitchPointerScreenPoint.y;
    }
    else
    {
        pointerMoved                         = ! controller.hasLastPointerScreenPoint || event.screenPoint.x != controller.lastPointerScreenPoint.x ||
                                               event.screenPoint.y != controller.lastPointerScreenPoint.y;
        controller.lastPointerScreenPoint    = event.screenPoint;
        controller.hasLastPointerScreenPoint = true;
    }

    DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup route-pointer source={} kind=move hwnd={:#x} capture={:#x} screen=({}, {}) moved={} targetPopup={} popupCount={}",
                    static_cast<int>(event.source),
                    reinterpret_cast<uintptr_t>(event.hwnd),
                    reinterpret_cast<uintptr_t>(GetCapture()),
                    event.screenPoint.x,
                    event.screenPoint.y,
                    pointerMoved ? L"true" : L"false",
                    TracePopupIndex(controller, targetPopup),
                    controller.popups.size());

    const bool initializeStationaryPopupHover =
        ! pointerMoved && targetPopup && ! targetPopup->hoveredIndex.has_value() && ! targetPopup->keyboardIndex.has_value();
    const bool stationaryCascadeParentReturn = ! pointerMoved && targetPopup && controller.popups.size() > 1u && controller.GetTopmostPopup() != targetPopup;
    if (! pointerMoved && ! initializeStationaryPopupHover && ! stationaryCascadeParentReturn)
    {
        return MenuInputDisposition::Ignored;
    }

    if (! targetPopup && event.maySwitchRoot && controller.sessionCallbacks.switchRootFromPointer)
    {
        if (IsStaleRootSwitchPointerMoveAfterKeyboard(controller, event))
        {
            if (ShouldRememberRejectedRootSwitchPointer(event))
            {
                RememberRootSwitchPointerPoint(controller, routedRootSwitchPoint);
            }
            DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup root-switch-stale-after-keyboard point=({}, {}) messageTime={} keyboardTime={}",
                            routedRootSwitchPoint.x,
                            routedRootSwitchPoint.y,
                            static_cast<unsigned int>(event.messageTime),
                            static_cast<unsigned int>(controller.lastKeyboardRootSwitchMessageTime));
            return MenuInputDisposition::Consumed;
        }
        if (IsPointInAnyPopupInteractiveRect(controller, routedRootSwitchPoint))
        {
            return MenuInputDisposition::Consumed;
        }
        DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup root-switch-probe point=({}, {}) targetPopup={} activeItems={}",
                        routedRootSwitchPoint.x,
                        routedRootSwitchPoint.y,
                        TracePopupIndex(controller, targetPopup),
                        controller.rootItems.size());
        if (auto request = controller.sessionCallbacks.switchRootFromPointer(routedRootSwitchPoint); request.has_value())
        {
            DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup root-switch-accepted point=({}, {}) newItems={} newPoint=({}, {})",
                            routedRootSwitchPoint.x,
                            routedRootSwitchPoint.y,
                            request->items.size(),
                            request->screenPoint.x,
                            request->screenPoint.y);
#if DXUI_ENABLE_DIAGNOSTICS
            ++controller.rootPointerSwitchCount;
#endif
            RememberRootSwitchPointerPoint(controller, routedRootSwitchPoint);
            ClearKeyboardRootSwitchMessageTime(controller);
            static_cast<void>(SwitchRootPopup(controller, std::move(request.value()), L"root-switch-pointer", false));
            return MenuInputDisposition::SwitchedRoot;
        }
        DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup root-switch-rejected point=({}, {})", routedRootSwitchPoint.x, routedRootSwitchPoint.y);
        if (ShouldRememberRejectedRootSwitchPointer(event))
        {
            RememberRootSwitchPointerPoint(controller, routedRootSwitchPoint);
        }
    }

    if (targetPopup)
    {
        if (const std::optional<D2D1_POINT_2F> pointDip = ResolvePointerPopupPointDip(*targetPopup, event); pointDip.has_value())
        {
            HandleMenuMouseMoveAtPointDip(controller, *targetPopup, pointDip.value(), event.mayTakeKeyboardFocus);
        }
        size_t targetPopupIndex = controller.popups.size();
        for (size_t i = 0; i < controller.popups.size(); ++i)
        {
            if (controller.popups[i].get() == targetPopup)
            {
                targetPopupIndex = i;
                break;
            }
        }

        for (size_t i = 0; i < targetPopupIndex && i < controller.popups.size(); ++i)
        {
            CancelSubmenuHoverTimer(*controller.popups[i]);
        }

        if (targetPopupIndex + 1u < controller.popups.size())
        {
            if (PopupHoverOwnsOpenChild(controller, targetPopupIndex, *targetPopup))
            {
                CancelSubmenuHoverTimer(*targetPopup);
            }
            else if (! HasPendingSubmenuOpenTimer(*targetPopup))
            {
                ScheduleSubmenuCloseTimer(*targetPopup);
            }
        }

        for (size_t i = 0; i < controller.popups.size(); ++i)
        {
            auto& popup = controller.popups[i];
            if (popup.get() == targetPopup)
            {
                continue;
            }

            bool invalidate = false;
            if (i < targetPopupIndex)
            {
                const std::optional<size_t> cascadeHighlight = controller.popups[i + 1u]->openedFromItemIndex;
                if (popup->hoveredIndex != cascadeHighlight)
                {
                    popup->hoveredIndex = cascadeHighlight;
                    invalidate          = true;
                }
                if (event.mayTakeKeyboardFocus && popup->keyboardIndex.has_value())
                {
                    popup->keyboardIndex.reset();
                    invalidate = true;
                }
            }
            else
            {
                if (popup->hoveredIndex.has_value())
                {
                    popup->hoveredIndex.reset();
                    invalidate = true;
                }
                if (event.mayTakeKeyboardFocus && popup->keyboardIndex.has_value())
                {
                    popup->keyboardIndex.reset();
                    invalidate = true;
                }
            }

            if (invalidate && popup->hwnd)
            {
                InvalidatePopup(*popup);
            }
        }

        return MenuInputDisposition::HoverChanged;
    }

    for (auto& popup : controller.popups)
    {
        if (popup->hoveredIndex.has_value())
        {
            popup->hoveredIndex.reset();
            InvalidatePopup(*popup);
        }
    }

    if (controller.popups.size() > 1)
    {
        for (size_t i = 1; i < controller.popups.size(); ++i)
        {
            CancelSubmenuHoverTimer(*controller.popups[i]);
        }
        ScheduleSubmenuCloseTimer(*controller.popups.front());
    }
    else if (! controller.popups.empty())
    {
        CancelSubmenuHoverTimer(*controller.popups.front());
    }

    return MenuInputDisposition::Consumed;
}

[[nodiscard]] MenuInputDisposition RouteMenuPointerEvent(MenuController& controller, const MenuPointerEvent& event) noexcept
{
    const bool traceEnabled                  = IsMenuDiagnosticsTraceEnabled();
    const MenuPointerTargetTrace traceBefore = traceEnabled ? CaptureMenuPointerTargetTrace(controller, event) : MenuPointerTargetTrace{};
    const auto finish                        = [&](MenuInputDisposition disposition) noexcept
    {
        if (traceEnabled)
        {
            TraceMenuPointerRoute(controller, event, traceBefore, disposition);
        }
        return disposition;
    };

    if (! controller.running)
    {
        return finish(MenuInputDisposition::Ignored);
    }

    if (event.kind == MenuPointerKind::Move)
    {
        const MenuInputDisposition disposition = RouteMenuPointerHover(controller, event);
        if (controller.running)
            ApplyMenuPointerCursor(controller, event.screenPoint, FindPointerTargetPopup(controller, event) != nullptr);
        return finish(disposition);
    }

    MenuPopup* targetPopup = FindPointerTargetPopup(controller, event);
    if (event.kind == MenuPointerKind::Wheel)
    {
        if (targetPopup && targetPopup->NeedsScrollbar())
        {
            const float previousScrollOffsetDip = targetPopup->scrollOffsetDip;
            const short wheelDelta              = GET_WHEEL_DELTA_WPARAM(event.wParam);
            const float steps                   = static_cast<float>(wheelDelta) / static_cast<float>(WHEEL_DELTA);
            targetPopup->scrollOffsetDip -= steps * ResolveMenuItemHeightDip(targetPopup->host.GetTheme());
            targetPopup->ClampScrollOffset();
            if (targetPopup->scrollOffsetDip != previousScrollOffsetDip)
            {
                if (const auto pointDip = ResolvePointerPopupPointDip(*targetPopup, event); pointDip.has_value())
                    HandleMenuMouseMoveAtPointDip(controller, *targetPopup, pointDip.value(), false);
                ReconcileOpenSubmenuAfterScroll(controller, *targetPopup);
            }
            InvalidatePopup(*targetPopup);
            return finish(MenuInputDisposition::Consumed);
        }

        return finish(targetPopup ? MenuInputDisposition::Consumed : MenuInputDisposition::Ignored);
    }

    if (event.kind == MenuPointerKind::LeftDown || event.kind == MenuPointerKind::RightDown)
    {
        if (! targetPopup)
        {
            if (event.mayDismiss)
            {
                controller.Dismiss();
                return finish(MenuInputDisposition::Dismissed);
            }
            return finish(MenuInputDisposition::Ignored);
        }

        if (event.kind == MenuPointerKind::LeftDown)
        {
            controller.leftButtonDownInPopup = true;
        }
        else
        {
            controller.rightButtonDownInPopup = true;
        }

        const std::optional<D2D1_POINT_2F> pointDip = ResolvePointerPopupPointDip(*targetPopup, event);
        if (pointDip.has_value())
        {
            HandleMenuMouseMoveAtPointDip(controller, *targetPopup, pointDip.value(), event.mayTakeKeyboardFocus);
        }
        if (event.kind == MenuPointerKind::LeftDown)
        {
            const std::optional<size_t> itemIndex = pointDip.has_value() ? HitTestMenuItem(*targetPopup, pointDip.value()) : std::nullopt;
            if (pointDip.has_value() && itemIndex.has_value() && targetPopup->items[itemIndex.value()].kind == MenuItemKind::Slider &&
                targetPopup->items[itemIndex.value()].enabled)
            {
                BeginSliderInteraction(*targetPopup, itemIndex.value(), pointDip.value());
            }
            else if (pointDip.has_value() && targetPopup->NeedsScrollbar() && PointInRect(targetPopup->GetScrollbarTrackRect(), pointDip.value()))
            {
                const D2D1_RECT_F thumb = targetPopup->GetScrollbarThumbRect();
                if (PointInRect(thumb, pointDip.value()))
                {
                    targetPopup->draggingScrollbarThumb = true;
                    targetPopup->scrollbarDragOffsetDip = pointDip->y - thumb.top;
                    targetPopup->scrollbarHotPart       = MenuPopup::ScrollbarHotPart::Thumb;
                }
                else
                {
                    const float pageStep                = targetPopup->menuHeightDip * 0.8f;
                    const float previousScrollOffsetDip = targetPopup->scrollOffsetDip;
                    targetPopup->scrollOffsetDip += pointDip->y < thumb.top ? -pageStep : pageStep;
                    targetPopup->ClampScrollOffset();
                    targetPopup->scrollbarHotPart = MenuPopup::ScrollbarHotPart::Track;
                    if (targetPopup->scrollOffsetDip != previousScrollOffsetDip)
                    {
                        targetPopup->hoveredIndex.reset();
                        CancelSubmenuHoverTimer(*targetPopup);
                        ReconcileOpenSubmenuAfterScroll(controller, *targetPopup);
                    }
                }
                InvalidatePopup(*targetPopup);
            }
        }
        return finish(MenuInputDisposition::Consumed);
    }

    if (event.kind == MenuPointerKind::LeftUp || event.kind == MenuPointerKind::RightUp)
    {
        const bool isLeftButton      = event.kind == MenuPointerKind::LeftUp;
        const bool buttonDownInPopup = isLeftButton ? controller.leftButtonDownInPopup : controller.rightButtonDownInPopup;
        if (isLeftButton && controller.ignoreInitialLeftButtonUp && ! buttonDownInPopup)
        {
            controller.ignoreInitialLeftButtonUp = false;
            return finish(MenuInputDisposition::Consumed);
        }
        if (! isLeftButton && controller.ignoreInitialRightButtonUp && ! buttonDownInPopup)
        {
            controller.ignoreInitialRightButtonUp = false;
            return finish(MenuInputDisposition::Consumed);
        }

        if (isLeftButton)
        {
            controller.leftButtonDownInPopup = false;
        }
        else
        {
            controller.rightButtonDownInPopup = false;
        }

        if (isLeftButton && targetPopup && targetPopup->draggingSliderItemIndex.has_value())
        {
            const size_t sliderItemIndex = targetPopup->draggingSliderItemIndex.value();
            if (const std::optional<D2D1_POINT_2F> pointDip = ResolvePointerPopupPointDip(*targetPopup, event); pointDip.has_value())
            {
                UpdateSliderInteractionAtPoint(*targetPopup, sliderItemIndex, pointDip.value());
            }
            const uint32_t stopIndex = ClampSliderValue(targetPopup->items[sliderItemIndex]);
            const int commandId      = GetSliderCommandId(targetPopup->items[sliderItemIndex], stopIndex);
            targetPopup->draggingSliderItemIndex.reset();
            Debug::Perf::Emit(L"dxui.menu.slider_interaction_us",
                              L"thumbnail_size",
                              Debug::Perf::ElapsedUs(targetPopup->sliderInteractionStartedAt),
                              targetPopup->sliderDragTargetChangeCount,
                              static_cast<uint64_t>(stopIndex),
                              commandId != 0 ? S_OK : E_FAIL);
            if (commandId != 0)
            {
                controller.InvokeItem(commandId);
                return finish(MenuInputDisposition::Invoked);
            }
            return finish(MenuInputDisposition::Consumed);
        }

        if (targetPopup && targetPopup->draggingScrollbarThumb)
        {
            targetPopup->draggingScrollbarThumb = false;
            return finish(MenuInputDisposition::Consumed);
        }

        std::optional<size_t> targetIndex = targetPopup ? targetPopup->hoveredIndex : std::nullopt;
        if (targetPopup && ! targetIndex.has_value())
        {
            const std::optional<D2D1_POINT_2F> pointDip = ResolvePointerPopupPointDip(*targetPopup, event);
            if (pointDip.has_value())
            {
                targetIndex = HitTestMenuItem(*targetPopup, pointDip.value());
                if (targetIndex != targetPopup->hoveredIndex)
                {
                    targetPopup->hoveredIndex = targetIndex;
                    if (event.mayTakeKeyboardFocus)
                    {
                        targetPopup->keyboardIndex.reset();
                    }
                    InvalidatePopup(*targetPopup);
                }
            }
        }

        if (targetPopup && targetIndex.has_value())
        {
            const size_t idx = targetIndex.value();
            const auto& item = targetPopup->items[idx];
            if (item.kind == MenuItemKind::Slider && item.enabled)
            {
                const std::optional<D2D1_POINT_2F> pointDip = ResolvePointerPopupPointDip(*targetPopup, event);
                if (pointDip.has_value())
                {
                    const D2D1_RECT_F itemRect = GetVisibleItemRect(*targetPopup, idx);
                    const uint32_t stopIndex   = HitTestSliderStop(item, itemRect, pointDip.value());
                    const int commandId        = GetSliderCommandId(item, stopIndex);
                    if (commandId != 0)
                    {
                        controller.InvokeItem(commandId);
                        return finish(MenuInputDisposition::Invoked);
                    }
                }
            }
            else if (! item.children.empty() && item.enabled)
            {
                OpenSubmenu(controller, *targetPopup, idx, false);
            }
            else if (event.mayInvoke && IsInvokableMenuItem(item))
            {
                controller.InvokeItem(item.commandId);
                return finish(MenuInputDisposition::Invoked);
            }
        }
        else if (! targetPopup && event.mayDismiss)
        {
            controller.Dismiss();
            return finish(MenuInputDisposition::Dismissed);
        }

        return finish(MenuInputDisposition::Consumed);
    }

    return finish(MenuInputDisposition::Ignored);
}

[[nodiscard]] std::optional<MenuPointerKind> MenuPointerKindFromMessage(UINT message) noexcept
{
    switch (message)
    {
        case WM_MOUSEMOVE: return MenuPointerKind::Move;
        case WM_LBUTTONDOWN: return MenuPointerKind::LeftDown;
        case WM_LBUTTONUP: return MenuPointerKind::LeftUp;
        case WM_RBUTTONDOWN: return MenuPointerKind::RightDown;
        case WM_RBUTTONUP: return MenuPointerKind::RightUp;
        case WM_MOUSEWHEEL:
        case WM_MOUSEHWHEEL: return MenuPointerKind::Wheel;
        default: return std::nullopt;
    }
}

[[nodiscard]] MenuInputDisposition RouteMenuKeyboardEvent(MenuController& controller, const MenuKeyboardEvent& event) noexcept
{
    MenuPopup* topmost = controller.GetTopmostPopup();
    if (! topmost || ! controller.running)
    {
        return MenuInputDisposition::Ignored;
    }

    const auto focusedIndex = [&]() noexcept -> std::optional<size_t>
    {
        auto idx = topmost->keyboardIndex.has_value() ? topmost->keyboardIndex : topmost->hoveredIndex;
        if (! idx.has_value() || idx.value() >= topmost->itemCount)
        {
            return std::nullopt;
        }
        return idx;
    };
    const auto invokeFocusedSliderStop = [&](uint32_t stopIndex) -> bool
    {
        const auto idx = focusedIndex();
        if (! idx.has_value())
        {
            return false;
        }
        const auto& item = topmost->items[idx.value()];
        if (item.kind != MenuItemKind::Slider || ! item.enabled)
        {
            return false;
        }
        const int commandId = GetSliderCommandId(item, stopIndex);
        if (commandId == 0)
        {
            return true;
        }
        controller.InvokeItem(commandId);
        return true;
    };
    const auto invokeFocusedSliderDelta = [&](int delta) -> bool
    {
        const auto idx = focusedIndex();
        if (! idx.has_value())
        {
            return false;
        }
        const auto& item = topmost->items[idx.value()];
        if (item.kind != MenuItemKind::Slider || ! item.enabled || item.sliderStops.empty())
        {
            return false;
        }
        const int current = static_cast<int>(ClampSliderValue(item));
        const int maxStop = static_cast<int>(item.sliderStops.size() - 1u);
        return invokeFocusedSliderStop(static_cast<uint32_t>(std::clamp(current + delta, 0, maxStop)));
    };

    switch (event.kind)
    {
        case MenuKeyboardKind::Up:
        {
            auto cur  = topmost->keyboardIndex.value_or(topmost->hoveredIndex.value_or(SIZE_MAX));
            auto next = (cur == SIZE_MAX) ? topmost->FindLastNavigableItem() : topmost->FindNextNavigableItem(cur, false);
            if (next.has_value())
            {
                topmost->keyboardIndex = next;
                topmost->hoveredIndex.reset();
                topmost->EnsureItemVisible(next.value());
                InvalidatePopup(*topmost);
            }
            return MenuInputDisposition::Consumed;
        }
        case MenuKeyboardKind::Down:
        {
            auto cur  = topmost->keyboardIndex.value_or(topmost->hoveredIndex.value_or(SIZE_MAX));
            auto next = (cur == SIZE_MAX) ? topmost->FindFirstNavigableItem() : topmost->FindNextNavigableItem(cur, true);
            if (next.has_value())
            {
                topmost->keyboardIndex = next;
                topmost->hoveredIndex.reset();
                topmost->EnsureItemVisible(next.value());
                InvalidatePopup(*topmost);
            }
            return MenuInputDisposition::Consumed;
        }
        case MenuKeyboardKind::Home:
        {
            if (invokeFocusedSliderStop(0u))
            {
                return controller.running ? MenuInputDisposition::Consumed : MenuInputDisposition::Invoked;
            }
            auto first = topmost->FindFirstNavigableItem();
            if (first.has_value())
            {
                topmost->keyboardIndex = first;
                topmost->hoveredIndex.reset();
                topmost->EnsureItemVisible(first.value());
                InvalidatePopup(*topmost);
            }
            return MenuInputDisposition::Consumed;
        }
        case MenuKeyboardKind::End:
        {
            const auto idx = focusedIndex();
            if (idx.has_value())
            {
                const auto& item = topmost->items[idx.value()];
                if (item.kind == MenuItemKind::Slider && ! item.sliderStops.empty() && item.enabled)
                {
                    static_cast<void>(invokeFocusedSliderStop(static_cast<uint32_t>(item.sliderStops.size() - 1u)));
                    return controller.running ? MenuInputDisposition::Consumed : MenuInputDisposition::Invoked;
                }
            }
            auto last = topmost->FindLastNavigableItem();
            if (last.has_value())
            {
                topmost->keyboardIndex = last;
                topmost->hoveredIndex.reset();
                topmost->EnsureItemVisible(last.value());
                InvalidatePopup(*topmost);
            }
            return MenuInputDisposition::Consumed;
        }
        case MenuKeyboardKind::Enter:
        case MenuKeyboardKind::Space:
        {
            auto idx = topmost->keyboardIndex.has_value() ? topmost->keyboardIndex : topmost->hoveredIndex;
            if (idx.has_value() && idx.value() < topmost->itemCount)
            {
                const auto& item = topmost->items[idx.value()];
                if (item.kind == MenuItemKind::Slider && item.enabled)
                {
                    static_cast<void>(invokeFocusedSliderStop(ClampSliderValue(item)));
                    return controller.running ? MenuInputDisposition::Consumed : MenuInputDisposition::Invoked;
                }
                if (! item.children.empty() && item.enabled)
                {
                    OpenSubmenu(controller, *topmost, idx.value(), true);
                }
                else if (IsInvokableMenuItem(item))
                {
                    controller.InvokeItem(item.commandId);
                    return MenuInputDisposition::Invoked;
                }
            }
            return MenuInputDisposition::Consumed;
        }
        case MenuKeyboardKind::Escape:
            if (controller.popups.size() > 1)
            {
                controller.CloseTopmostSubmenu();
                return MenuInputDisposition::Consumed;
            }
            controller.Dismiss();
            return MenuInputDisposition::Dismissed;
        case MenuKeyboardKind::Tab:
        case MenuKeyboardKind::F10:
        case MenuKeyboardKind::Alt: controller.Dismiss(); return MenuInputDisposition::Dismissed;
        case MenuKeyboardKind::Right:
        {
            if (invokeFocusedSliderDelta(1))
            {
                return controller.running ? MenuInputDisposition::Consumed : MenuInputDisposition::Invoked;
            }
            auto idx = topmost->keyboardIndex.has_value() ? topmost->keyboardIndex : topmost->hoveredIndex;
            if (idx.has_value() && idx.value() < topmost->itemCount && ! topmost->items[idx.value()].children.empty() && topmost->items[idx.value()].enabled)
            {
                OpenSubmenu(controller, *topmost, idx.value(), true);
                return MenuInputDisposition::Consumed;
            }

            if (controller.sessionCallbacks.switchRootFromDirection)
            {
                if (auto request = controller.sessionCallbacks.switchRootFromDirection(true); request.has_value())
                {
                    if (SwitchRootPopup(controller, std::move(request.value()), L"root-switch-keyboard", true))
                    {
                        RememberKeyboardRootSwitchMessageTime(controller, event.messageTime);
                        return MenuInputDisposition::SwitchedRoot;
                    }
                }
            }
            return MenuInputDisposition::Consumed;
        }
        case MenuKeyboardKind::Left:
        {
            if (invokeFocusedSliderDelta(-1))
            {
                return controller.running ? MenuInputDisposition::Consumed : MenuInputDisposition::Invoked;
            }
            if (controller.popups.size() > 1)
            {
                controller.CloseTopmostSubmenu();
            }
            else if (controller.sessionCallbacks.switchRootFromDirection)
            {
                if (auto request = controller.sessionCallbacks.switchRootFromDirection(false); request.has_value())
                {
                    if (SwitchRootPopup(controller, std::move(request.value()), L"root-switch-keyboard", true))
                    {
                        RememberKeyboardRootSwitchMessageTime(controller, event.messageTime);
                        return MenuInputDisposition::SwitchedRoot;
                    }
                }
            }
            return MenuInputDisposition::Consumed;
        }
        case MenuKeyboardKind::Mnemonic:
        {
            auto match = topmost->FindMnemonicItem(event.mnemonic);
            if (match.has_value())
            {
                const auto& item = topmost->items[match.value()];
                if (! item.children.empty() && item.enabled)
                {
                    topmost->keyboardIndex = match;
                    InvalidatePopup(*topmost);
                    OpenSubmenu(controller, *topmost, match.value(), true);
                }
                else if (IsInvokableMenuItem(item))
                {
                    controller.InvokeItem(item.commandId);
                    return MenuInputDisposition::Invoked;
                }
            }
            return MenuInputDisposition::Consumed;
        }
    }

    return MenuInputDisposition::Ignored;
}

[[nodiscard]] std::optional<MenuKeyboardKind> MenuKeyboardKindFromVirtualKey(UINT virtualKey) noexcept
{
    switch (virtualKey)
    {
        case VK_UP: return MenuKeyboardKind::Up;
        case VK_DOWN: return MenuKeyboardKind::Down;
        case VK_LEFT: return MenuKeyboardKind::Left;
        case VK_RIGHT: return MenuKeyboardKind::Right;
        case VK_HOME: return MenuKeyboardKind::Home;
        case VK_END: return MenuKeyboardKind::End;
        case VK_RETURN: return MenuKeyboardKind::Enter;
        case VK_SPACE: return MenuKeyboardKind::Space;
        case VK_ESCAPE: return MenuKeyboardKind::Escape;
        case VK_TAB: return MenuKeyboardKind::Tab;
        case VK_F10: return MenuKeyboardKind::F10;
        case VK_MENU: return MenuKeyboardKind::Alt;
        default:
            if (virtualKey >= 'A' && virtualKey <= 'Z')
            {
                return MenuKeyboardKind::Mnemonic;
            }
            return std::nullopt;
    }
}

struct MenuKeyboardTargetTrace
{
    int popupIndex      = -1;
    uintptr_t popupHwnd = 0u;
    std::optional<size_t> hoveredIndex;
    std::optional<size_t> keyboardIndex;
};

[[nodiscard]] MenuKeyboardTargetTrace CaptureMenuKeyboardTargetTrace(const MenuController& controller) noexcept
{
    MenuKeyboardTargetTrace trace;
    const MenuPopup* popup = controller.GetTopmostPopup();
    if (! popup)
    {
        return trace;
    }

    trace.popupIndex    = TracePopupIndex(controller, popup);
    trace.popupHwnd     = TraceHwndValue(popup->hwnd);
    trace.hoveredIndex  = popup->hoveredIndex;
    trace.keyboardIndex = popup->keyboardIndex;
    return trace;
}

void TraceMenuKeyboardRoute(const MenuController& controller,
                            const MenuKeyboardEvent& event,
                            const MenuKeyboardTargetTrace& before,
                            MenuInputDisposition disposition) noexcept
{
    static_cast<void>(event);
    static_cast<void>(before);
    static_cast<void>(disposition);

    const MenuKeyboardTargetTrace after = CaptureMenuKeyboardTargetTrace(controller);
    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.keyboard",
                                L"source={} kind={} hwnd={:#x} virtualKey={:#x} mnemonic={:#x} messageTime={} keyboardRootTimeHas={} keyboardRootTime={} "
                                L"beforePopup={} beforePopupHwnd={:#x} "
                                L"beforeHoverHas={} beforeHover={} beforeKeyboardHas={} beforeKeyboard={} afterPopup={} afterPopupHwnd={:#x} "
                                L"afterHoverHas={} afterHover={} afterKeyboardHas={} afterKeyboard={} popups={} running={} result={} disposition={}",
                                TraceInputSourceName(event.source),
                                TraceKeyboardKindName(event.kind),
                                TraceHwndValue(event.hwnd),
                                static_cast<unsigned int>(event.virtualKey),
                                static_cast<unsigned int>(event.mnemonic),
                                static_cast<unsigned int>(event.messageTime),
                                TraceBool(controller.hasLastKeyboardRootSwitchMessageTime),
                                static_cast<unsigned int>(controller.lastKeyboardRootSwitchMessageTime),
                                before.popupIndex,
                                before.popupHwnd,
                                TraceBool(before.hoveredIndex.has_value()),
                                TraceOptionalSizeValue(before.hoveredIndex),
                                TraceBool(before.keyboardIndex.has_value()),
                                TraceOptionalSizeValue(before.keyboardIndex),
                                after.popupIndex,
                                after.popupHwnd,
                                TraceBool(after.hoveredIndex.has_value()),
                                TraceOptionalSizeValue(after.hoveredIndex),
                                TraceBool(after.keyboardIndex.has_value()),
                                TraceOptionalSizeValue(after.keyboardIndex),
                                controller.popups.size(),
                                TraceBool(controller.running),
                                controller.result.value_or(-1),
                                TraceDispositionName(disposition));
}

[[nodiscard]] bool ProcessMenuPopupMessage(MenuController& controller, HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    if (! controller.running)
    {
        DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.popup-message",
                                    L"msg={} msgId={:#x} hwnd={:#x} wParam={:#x} lParam={:#x} running=false handled=false",
                                    TraceMenuMessageName(msg),
                                    static_cast<unsigned int>(msg),
                                    TraceHwndValue(hwnd),
                                    static_cast<uintptr_t>(wp),
                                    static_cast<uintptr_t>(lp));
        return false;
    }

    if (msg == WM_TIMER && wp == kSubmenuHoverTimerId)
    {
        if (MenuPopup* popup = controller.FindPopupForHwnd(hwnd))
        {
            HandleSubmenuHoverTimer(controller, *popup);
        }

        return true;
    }

    if (msg >= WM_MOUSEFIRST && msg <= WM_MOUSELAST)
    {
        const std::optional<MenuPointerKind> kind = MenuPointerKindFromMessage(msg);
        if (! kind.has_value())
        {
            DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.popup-message",
                                        L"msg={} msgId={:#x} hwnd={:#x} wParam={:#x} lParam={:#x} supported=false handled=false",
                                        TraceMenuMessageName(msg),
                                        static_cast<unsigned int>(msg),
                                        TraceHwndValue(hwnd),
                                        static_cast<uintptr_t>(wp),
                                        static_cast<uintptr_t>(lp));
            return false;
        }

        std::optional<D2D1_POINT_2F> deliveredPopupPointDip;
        if (msg != WM_MOUSEWHEEL && msg != WM_MOUSEHWHEEL)
        {
            if (const MenuPopup* deliveredPopup = controller.FindPopupForHwnd(hwnd))
            {
                deliveredPopupPointDip = PopupClientPointToDip(*deliveredPopup, UnpackMousePoint(lp));
            }
        }

        const MSG syntheticMessage{.hwnd = hwnd, .message = msg, .wParam = wp, .lParam = lp, .time = CurrentMessageTime()};
        const MenuPointerEvent event{
            .source                 = MenuInputSource::PopupWndProc,
            .kind                   = kind.value(),
            .hwnd                   = hwnd,
            .screenPoint            = ResolveMouseScreenPoint(syntheticMessage),
            .messageTime            = syntheticMessage.time,
            .deliveredPopupPointDip = deliveredPopupPointDip,
            .wParam                 = wp,
            .lParam                 = lp,
            .mayInvoke              = true,
            .mayDismiss             = true,
            .maySwitchRoot          = msg == WM_MOUSEMOVE,
            .mayTakeKeyboardFocus   = true,
        };
        const MenuInputDisposition disposition = RouteMenuPointerEvent(controller, event);
        DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.popup-message",
                                    L"msg={} msgId={:#x} hwnd={:#x} wParam={:#x} lParam={:#x} handled={} disposition={}",
                                    TraceMenuMessageName(msg),
                                    static_cast<unsigned int>(msg),
                                    TraceHwndValue(hwnd),
                                    static_cast<uintptr_t>(wp),
                                    static_cast<uintptr_t>(lp),
                                    TraceBool(disposition != MenuInputDisposition::Ignored),
                                    TraceDispositionName(disposition));
        return disposition != MenuInputDisposition::Ignored;
    }

    if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN)
    {
        const UINT virtualKey                      = static_cast<UINT>(wp);
        const std::optional<MenuKeyboardKind> kind = MenuKeyboardKindFromVirtualKey(virtualKey);
        if (! kind.has_value())
        {
            DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.popup-message",
                                        L"msg={} msgId={:#x} hwnd={:#x} virtualKey={:#x} supported=false handled=false",
                                        TraceMenuMessageName(msg),
                                        static_cast<unsigned int>(msg),
                                        TraceHwndValue(hwnd),
                                        static_cast<unsigned int>(virtualKey));
            return false;
        }

        const MenuKeyboardEvent event{
            .source      = MenuInputSource::PopupWndProc,
            .kind        = kind.value(),
            .hwnd        = hwnd,
            .virtualKey  = virtualKey,
            .mnemonic    = static_cast<wchar_t>(virtualKey),
            .messageTime = CurrentMessageTime(),
            .lParam      = lp,
        };
        const bool traceEnabled                   = IsMenuDiagnosticsTraceEnabled();
        const MenuKeyboardTargetTrace traceBefore = traceEnabled ? CaptureMenuKeyboardTargetTrace(controller) : MenuKeyboardTargetTrace{};
        const MenuInputDisposition disposition    = RouteMenuKeyboardEvent(controller, event);
        if (traceEnabled)
        {
            TraceMenuKeyboardRoute(controller, event, traceBefore, disposition);
        }
        DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.popup-message",
                                    L"msg={} msgId={:#x} hwnd={:#x} virtualKey={:#x} handled={} disposition={}",
                                    TraceMenuMessageName(msg),
                                    static_cast<unsigned int>(msg),
                                    TraceHwndValue(hwnd),
                                    static_cast<unsigned int>(virtualKey),
                                    TraceBool(disposition != MenuInputDisposition::Ignored),
                                    TraceDispositionName(disposition));
        return disposition != MenuInputDisposition::Ignored;
    }

    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.popup-message",
                                L"msg={} msgId={:#x} hwnd={:#x} wParam={:#x} lParam={:#x} handled=false",
                                TraceMenuMessageName(msg),
                                static_cast<unsigned int>(msg),
                                TraceHwndValue(hwnd),
                                static_cast<uintptr_t>(wp),
                                static_cast<uintptr_t>(lp));
    return false;
}

// ---------------------------------------------------------------------------
// Modal message loop
// ---------------------------------------------------------------------------

void RunMenuModalLoop(MenuController& controller)
{
    // Capture mouse on root popup for light-dismiss
    MenuPopup* root = controller.GetRootPopup();
    if (! root || ! root->hwnd)
        return;

    [[maybe_unused]] const HWND previousCapture = GetCapture();
    const HWND previousFocus                    = GetFocus();
    SetCapture(root->hwnd);
    ActivatePopupForKeyboard(*root);
    ApplyMenuCursorAtPointer(controller);
    DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup loop-start owner={:#x} root={:#x} previousCapture={:#x} currentCapture={:#x} popupCount={} items={}",
                    reinterpret_cast<uintptr_t>(controller.ownerHwnd),
                    reinterpret_cast<uintptr_t>(root->hwnd),
                    reinterpret_cast<uintptr_t>(previousCapture),
                    reinterpret_cast<uintptr_t>(GetCapture()),
                    controller.popups.size(),
                    controller.rootItems.size());
    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.loop-start",
                                L"owner={:#x} root={:#x} previousCapture={:#x} previousFocus={:#x} currentCapture={:#x} popupCount={} items={}",
                                TraceHwndValue(controller.ownerHwnd),
                                TraceHwndValue(root->hwnd),
                                TraceHwndValue(previousCapture),
                                TraceHwndValue(previousFocus),
                                TraceHwndValue(GetCapture()),
                                controller.popups.size(),
                                controller.rootItems.size());

    controller.ignoreInitialLeftButtonUp  = controller.sessionCallbacks.ignoreInitialLeftButtonUp || (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
    controller.ignoreInitialRightButtonUp = controller.sessionCallbacks.ignoreInitialRightButtonUp || (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
    controller.leftButtonDownInPopup      = false;
    controller.rightButtonDownInPopup     = false;
    DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup loop-initial-up-filter left={} right={} asyncLeft={} asyncRight={}",
                    controller.ignoreInitialLeftButtonUp ? L"true" : L"false",
                    controller.ignoreInitialRightButtonUp ? L"true" : L"false",
                    (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0 ? L"down" : L"up",
                    (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0 ? L"down" : L"up");
    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.loop-initial-up-filter",
                                L"ignoreLeft={} ignoreRight={} asyncLeftDown={} asyncRightDown={}",
                                TraceBool(controller.ignoreInitialLeftButtonUp),
                                TraceBool(controller.ignoreInitialRightButtonUp),
                                TraceBool((GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0),
                                TraceBool((GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0));
    MSG msg{};
#if DXUI_MENU_SINK_DIAGNOSTICS
    struct MenuLoopRepeatedMessageTrace
    {
        UINT message             = 0;
        HWND hwnd                = nullptr;
        WPARAM wParam            = 0;
        LPARAM lParam            = 0;
        bool popupMessage        = false;
        bool ownerOrPopupMessage = false;
        uint64_t count           = 0u;
    };
    MenuLoopRepeatedMessageTrace repeatedMessageTrace{};
    const auto flushRepeatedMessageTrace = [&]() noexcept
    {
        if (repeatedMessageTrace.count == 0u)
        {
            return;
        }
        DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.loop-message-repeat",
                                    L"msg={} msgId={:#x} hwnd={:#x} wParam={:#x} lParam={:#x} popup={} ownerOrPopup={} count={}",
                                    TraceMenuMessageName(repeatedMessageTrace.message),
                                    static_cast<unsigned int>(repeatedMessageTrace.message),
                                    TraceHwndValue(repeatedMessageTrace.hwnd),
                                    static_cast<uintptr_t>(repeatedMessageTrace.wParam),
                                    static_cast<uintptr_t>(repeatedMessageTrace.lParam),
                                    TraceBool(repeatedMessageTrace.popupMessage),
                                    TraceBool(repeatedMessageTrace.ownerOrPopupMessage),
                                    repeatedMessageTrace.count);
        repeatedMessageTrace = {};
    };
    const auto traceLoopMessage = [&](const MSG& loopMessage, bool popupMessage, bool ownerOrPopupMessage) noexcept
    {
        if (ShouldTraceMenuLoopMessageImmediately(loopMessage.message, popupMessage))
        {
            flushRepeatedMessageTrace();
            DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.loop-message",
                                        L"msg={} msgId={:#x} hwnd={:#x} wParam={:#x} lParam={:#x} popup={} ownerOrPopup={}",
                                        TraceMenuMessageName(loopMessage.message),
                                        static_cast<unsigned int>(loopMessage.message),
                                        TraceHwndValue(loopMessage.hwnd),
                                        static_cast<uintptr_t>(loopMessage.wParam),
                                        static_cast<uintptr_t>(loopMessage.lParam),
                                        TraceBool(popupMessage),
                                        TraceBool(ownerOrPopupMessage));
            return;
        }

        if (repeatedMessageTrace.count == 0u || repeatedMessageTrace.message != loopMessage.message || repeatedMessageTrace.hwnd != loopMessage.hwnd ||
            repeatedMessageTrace.wParam != loopMessage.wParam || repeatedMessageTrace.lParam != loopMessage.lParam ||
            repeatedMessageTrace.popupMessage != popupMessage || repeatedMessageTrace.ownerOrPopupMessage != ownerOrPopupMessage)
        {
            flushRepeatedMessageTrace();
            repeatedMessageTrace.message             = loopMessage.message;
            repeatedMessageTrace.hwnd                = loopMessage.hwnd;
            repeatedMessageTrace.wParam              = loopMessage.wParam;
            repeatedMessageTrace.lParam              = loopMessage.lParam;
            repeatedMessageTrace.popupMessage        = popupMessage;
            repeatedMessageTrace.ownerOrPopupMessage = ownerOrPopupMessage;
        }
        ++repeatedMessageTrace.count;
        if (repeatedMessageTrace.count >= kMenuLoopTraceRepeatFlushCount)
        {
            flushRepeatedMessageTrace();
        }
    };
#else
    const auto flushRepeatedMessageTrace = []() noexcept {};
    const auto traceLoopMessage          = [](const MSG& /*loopMessage*/, bool /*popupMessage*/, bool /*ownerOrPopupMessage*/) noexcept {};
#endif
    while (controller.running)
    {
        if (! PeekMenuModalLoopPriorityMessage(controller, msg) && PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE) == FALSE)
        {
            MenuPopup* currentRoot = controller.GetRootPopup();
            if (! currentRoot || ! currentRoot->hwnd || IsWindow(currentRoot->hwnd) == FALSE)
            {
                DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup loop-dismiss-missing-root owner={:#x} root={:#x} popupCount={} capture={:#x}",
                                reinterpret_cast<uintptr_t>(controller.ownerHwnd),
                                reinterpret_cast<uintptr_t>(currentRoot ? currentRoot->hwnd : nullptr),
                                controller.popups.size(),
                                reinterpret_cast<uintptr_t>(GetCapture()));
                DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.loop-dismiss-missing-root",
                                            L"owner={:#x} root={:#x} popupCount={} capture={:#x}",
                                            TraceHwndValue(controller.ownerHwnd),
                                            TraceHwndValue(currentRoot ? currentRoot->hwnd : nullptr),
                                            controller.popups.size(),
                                            TraceHwndValue(GetCapture()));
                controller.Dismiss();
                break;
            }
            if (GetCapture() != currentRoot->hwnd)
            {
                [[maybe_unused]] const HWND previousPopupCapture = GetCapture();
                SetCapture(currentRoot->hwnd);
                DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup loop-recapture root={:#x} previousCapture={:#x} currentCapture={:#x}",
                                reinterpret_cast<uintptr_t>(currentRoot->hwnd),
                                reinterpret_cast<uintptr_t>(previousPopupCapture),
                                reinterpret_cast<uintptr_t>(GetCapture()));
                DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.loop-recapture",
                                            L"root={:#x} previousCapture={:#x} currentCapture={:#x}",
                                            TraceHwndValue(currentRoot->hwnd),
                                            TraceHwndValue(previousPopupCapture),
                                            TraceHwndValue(GetCapture()));
            }

            static_cast<void>(MsgWaitForMultipleObjectsEx(0, nullptr, INFINITE, QS_ALLINPUT, MWMO_INPUTAVAILABLE));
            continue;
        }

        if (msg.message == WM_QUIT)
        {
            flushRepeatedMessageTrace();
            PostQuitMessage(static_cast<int>(msg.wParam));
            break;
        }

        const HWND originalMessageHwnd = msg.hwnd;
        if (originalMessageHwnd && IsWindow(originalMessageHwnd) == FALSE)
        {
            flushRepeatedMessageTrace();
            DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.loop-message-stale",
                                        L"msg={} msgId={:#x} hwnd={:#x} wParam={:#x} lParam={:#x}",
                                        TraceMenuMessageName(msg.message),
                                        static_cast<unsigned int>(msg.message),
                                        TraceHwndValue(originalMessageHwnd),
                                        static_cast<uintptr_t>(msg.wParam),
                                        static_cast<uintptr_t>(msg.lParam));
            continue;
        }

        // ContextMenu::PostMenuBarHover posts this registered message to any window of the thread.
        if (WndMsg::ContextMenuRootHoverChanged().Matches(msg.message))
        {
            flushRepeatedMessageTrace();
            if (controller.sessionCallbacks.switchRootFromMenuBarHover)
            {
                const size_t hoverIndex            = static_cast<size_t>(msg.wParam);
                const std::uintptr_t hoverSequence = static_cast<std::uintptr_t>(msg.lParam);
                if (auto request = controller.sessionCallbacks.switchRootFromMenuBarHover(hoverIndex, hoverSequence); request.has_value())
                {
                    DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup root-switch-menu-bar-hover-accepted newItems={} newPoint=({}, {})",
                                    request->items.size(),
                                    request->screenPoint.x,
                                    request->screenPoint.y);
#if DXUI_ENABLE_DIAGNOSTICS
                    ++controller.rootPointerSwitchCount;
#endif
                    ClearKeyboardRootSwitchMessageTime(controller);
                    static_cast<void>(SwitchRootPopup(controller, std::move(request.value()), L"root-switch-menu-bar-hover", false));
                }
            }
            continue;
        }

        if (msg.message == WM_CAPTURECHANGED || msg.message == WM_CANCELMODE)
        {
            DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup message msg={} hwnd={:#x} wParam={:#x} lParam={:#x} capture={:#x}",
                            TraceMenuMessageName(msg.message),
                            reinterpret_cast<uintptr_t>(msg.hwnd),
                            static_cast<uintptr_t>(msg.wParam),
                            static_cast<uintptr_t>(msg.lParam),
                            reinterpret_cast<uintptr_t>(GetCapture()));
        }

        const bool popupMessage        = controller.FindPopupForHwnd(msg.hwnd) != nullptr;
        const bool ownerOrPopupMessage = msg.hwnd == controller.ownerHwnd || popupMessage;
        traceLoopMessage(msg, popupMessage, ownerOrPopupMessage);
        if (ownerOrPopupMessage)
        {
            if ((msg.message == WM_ACTIVATEAPP && msg.wParam == FALSE) ||
                (msg.message == WM_ACTIVATE && LOWORD(static_cast<DWORD_PTR>(msg.wParam)) == WA_INACTIVE) ||
                (msg.message == WM_NCACTIVATE && msg.wParam == FALSE) || (msg.message == WM_DESTROY && msg.hwnd == controller.ownerHwnd))
            {
                DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup dismiss-activation msg={} hwnd={:#x} owner={:#x} capture={:#x}",
                                TraceMenuMessageName(msg.message),
                                reinterpret_cast<uintptr_t>(msg.hwnd),
                                reinterpret_cast<uintptr_t>(controller.ownerHwnd),
                                reinterpret_cast<uintptr_t>(GetCapture()));
                DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.loop-dismiss-activation",
                                            L"msg={} msgId={:#x} hwnd={:#x} owner={:#x} capture={:#x}",
                                            TraceMenuMessageName(msg.message),
                                            static_cast<unsigned int>(msg.message),
                                            TraceHwndValue(msg.hwnd),
                                            TraceHwndValue(controller.ownerHwnd),
                                            TraceHwndValue(GetCapture()));
                controller.Dismiss();
                break;
            }
        }

        if (popupMessage)
        {
            DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.loop-dispatch-popup",
                                        L"msg={} msgId={:#x} hwnd={:#x}",
                                        TraceMenuMessageName(msg.message),
                                        static_cast<unsigned int>(msg.message),
                                        TraceHwndValue(msg.hwnd));
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
            continue;
        }

        // Route non-popup mouse messages through the shared menu input router.
        if (IsMenuClientMouseMessage(msg.message))
        {
            const std::optional<MenuPointerKind> pointerKind = MenuPointerKindFromMessage(msg.message);
            if (! pointerKind.has_value())
            {
                continue;
            }
            const MenuPointerEvent event{
                .source               = MenuInputSource::ModalMessage,
                .kind                 = pointerKind.value(),
                .hwnd                 = msg.hwnd,
                .screenPoint          = ResolveMouseScreenPoint(msg),
                .messageTime          = msg.time,
                .wParam               = msg.wParam,
                .lParam               = msg.lParam,
                .mayInvoke            = true,
                .mayDismiss           = true,
                .maySwitchRoot        = msg.message == WM_MOUSEMOVE,
                .mayTakeKeyboardFocus = true,
            };
            const MenuInputDisposition disposition = RouteMenuPointerEvent(controller, event);
            DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.loop-nonpopup-pointer",
                                        L"msg={} msgId={:#x} hwnd={:#x} disposition={} running={}",
                                        TraceMenuMessageName(msg.message),
                                        static_cast<unsigned int>(msg.message),
                                        TraceHwndValue(msg.hwnd),
                                        TraceDispositionName(disposition),
                                        TraceBool(controller.running));
            if (disposition == MenuInputDisposition::Dismissed || disposition == MenuInputDisposition::Invoked)
            {
                break;
            }
            continue;
        }

        // Keyboard messages — route to topmost popup
        if (msg.message == WM_KEYDOWN || msg.message == WM_SYSKEYDOWN)
        {
            const UINT virtualKey                              = static_cast<UINT>(msg.wParam);
            const std::optional<MenuKeyboardKind> keyboardKind = MenuKeyboardKindFromVirtualKey(virtualKey);
            if (keyboardKind.has_value())
            {
                const MenuKeyboardEvent event{
                    .source      = MenuInputSource::ModalMessage,
                    .kind        = keyboardKind.value(),
                    .hwnd        = msg.hwnd,
                    .virtualKey  = virtualKey,
                    .mnemonic    = static_cast<wchar_t>(virtualKey),
                    .messageTime = msg.time,
                    .lParam      = msg.lParam,
                };
                const bool traceEnabled                   = IsMenuDiagnosticsTraceEnabled();
                const MenuKeyboardTargetTrace traceBefore = traceEnabled ? CaptureMenuKeyboardTargetTrace(controller) : MenuKeyboardTargetTrace{};
                const MenuInputDisposition disposition    = RouteMenuKeyboardEvent(controller, event);
                if (traceEnabled)
                {
                    TraceMenuKeyboardRoute(controller, event, traceBefore, disposition);
                }
                DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.loop-keyboard",
                                            L"msg={} msgId={:#x} hwnd={:#x} virtualKey={:#x} disposition={} running={}",
                                            TraceMenuMessageName(msg.message),
                                            static_cast<unsigned int>(msg.message),
                                            TraceHwndValue(msg.hwnd),
                                            static_cast<unsigned int>(virtualKey),
                                            TraceDispositionName(disposition),
                                            TraceBool(controller.running));
                if (disposition == MenuInputDisposition::Dismissed || disposition == MenuInputDisposition::Invoked)
                {
                    break;
                }
                if (disposition != MenuInputDisposition::Ignored)
                {
                    continue;
                }
            }

            // Fall through for unhandled keys
        }

        // All WM_PAINT/WM_ERASEBKGND handled by MenuWndProc → ControlHost::HandleMessage
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    flushRepeatedMessageTrace();

    // Release capture
    if (const HWND captured = GetCapture(); captured && controller.FindPopupForHwnd(captured))
    {
        DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup loop-release-capture captured={:#x} owner={:#x}",
                        reinterpret_cast<uintptr_t>(captured),
                        reinterpret_cast<uintptr_t>(controller.ownerHwnd));
        DXUI_MENU_DIAGNOSTICS_TRACE(
            L"menu.loop-release-capture", L"captured={:#x} owner={:#x}", TraceHwndValue(captured), TraceHwndValue(controller.ownerHwnd));
        ReleaseCapture();
    }
    DXUI_MENU_TRACE(L"DxUi::MenuTrace Popup loop-end owner={:#x} result={} capture={:#x}",
                    reinterpret_cast<uintptr_t>(controller.ownerHwnd),
                    controller.result.value_or(-1),
                    reinterpret_cast<uintptr_t>(GetCapture()));
    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.loop-end",
                                L"owner={:#x} result={} capture={:#x} focus={:#x} previousFocus={:#x}",
                                TraceHwndValue(controller.ownerHwnd),
                                controller.result.value_or(-1),
                                TraceHwndValue(GetCapture()),
                                TraceHwndValue(GetFocus()),
                                TraceHwndValue(previousFocus));

    const HWND currentFocus = GetFocus();
    if (previousFocus && IsWindow(previousFocus) != FALSE && currentFocus && controller.FindPopupForHwnd(currentFocus))
    {
        SetFocus(previousFocus);
        DXUI_MENU_DIAGNOSTICS_TRACE(
            L"menu.loop-restore-focus", L"previousFocus={:#x} focusAfter={:#x}", TraceHwndValue(previousFocus), TraceHwndValue(GetFocus()));
    }
}

} // anonymous namespace

void DismissAsyncMenusForProcessExit() noexcept
{
    g_asyncMenuProcessExit = true;
    auto& controllers      = ActiveAsyncMenuControllers();
    while (! controllers.empty())
    {
        MenuController& controller = *controllers.back();
        // Closing callbacks are application code. Do not run them during process
        // teardown: they can throw through this noexcept path or reopen a menu.
        controller.asyncOnClosed = nullptr;
        FinalizeAsyncMenuController(controller);
    }
}

bool IsNativeMenuPopupWindow(HWND hwnd) noexcept
{
    // Only this module registers the popup class, so its exact name identifies a menu popup host.
    wchar_t className[std::size(kMenuWindowClass) + 1u]{};
    const int length = hwnd ? GetClassNameW(hwnd, className, static_cast<int>(std::size(className))) : 0;
    return length == static_cast<int>(std::size(kMenuWindowClass) - 1u) && std::wstring_view(className, static_cast<size_t>(length)) == kMenuWindowClass;
}

// ---------------------------------------------------------------------------
// ContextMenu::Show — public API
// ---------------------------------------------------------------------------

bool IsContextMenuDiagnosticsEnabled() noexcept
{
    return IsMenuDiagnosticsTraceEnabled();
}

void TraceContextMenuDiagnostics(std::wstring_view eventName, std::wstring_view details) noexcept
{
    WriteMenuDiagnosticsTraceLine(eventName, details);
}

std::optional<int> ContextMenu::Show(
    HWND ownerHwnd, POINT screenPoint, std::span<const MenuFlyoutItem> items, const ThemePalette& theme, const ContextMenuSessionCallbacks& sessionCallbacks)
{
    if (items.empty() || ! ownerHwnd)
        return std::nullopt;

    DXUI_MENU_TRACE(L"DxUi::MenuTrace ContextMenu show-begin owner={:#x} point=({}, {}) items={} focusFirst={} ignoreInitialUp=({}, {}) captureBefore={:#x}",
                    reinterpret_cast<uintptr_t>(ownerHwnd),
                    screenPoint.x,
                    screenPoint.y,
                    items.size(),
                    sessionCallbacks.focusFirstNavigableItem ? L"true" : L"false",
                    sessionCallbacks.ignoreInitialLeftButtonUp ? L"true" : L"false",
                    sessionCallbacks.ignoreInitialRightButtonUp ? L"true" : L"false",
                    reinterpret_cast<uintptr_t>(GetCapture()));
    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.show-begin",
                                L"owner={:#x} point=({}, {}) items={} focusFirst={} ignoreInitialLeftUp={} ignoreInitialRightUp={} maxRootHeightDip={:.1f} "
                                L"captureBefore={:#x} focusBefore={:#x} activeBefore={:#x} hitWindow={:#x}",
                                TraceHwndValue(ownerHwnd),
                                screenPoint.x,
                                screenPoint.y,
                                items.size(),
                                TraceBool(sessionCallbacks.focusFirstNavigableItem),
                                TraceBool(sessionCallbacks.ignoreInitialLeftButtonUp),
                                TraceBool(sessionCallbacks.ignoreInitialRightButtonUp),
                                sessionCallbacks.maxRootHeightDip,
                                TraceHwndValue(GetCapture()),
                                TraceHwndValue(GetFocus()),
                                TraceHwndValue(GetActiveWindow()),
                                TraceHwndValue(WindowFromPoint(screenPoint)));

    MenuController controller;
    controller.ownerHwnd        = ownerHwnd;
    controller.theme            = theme; // Copy
    controller.style            = ResolveMenuVisualStyle(theme);
    controller.sessionCallbacks = sessionCallbacks;
    if (sessionCallbacks.focusFirstNavigableItem)
    {
        RememberKeyboardRootSwitchMessageTime(controller, CurrentMessageTime());
    }

    // Copy items so they outlive the caller's temporaries
    controller.rootItems.assign(items.begin(), items.end());

    const auto startedAt = std::chrono::steady_clock::now();
    if (! CreateMenuPopupWindow(controller,
                                controller.rootItems.data(),
                                controller.rootItems.size(),
                                screenPoint,
                                false,
                                nullptr,
                                nullptr,
                                true,
                                sessionCallbacks.focusFirstNavigableItem))
    {
        DXUI_MENU_DIAGNOSTICS_TRACE(
            L"menu.show-create-failed", L"owner={:#x} point=({}, {}) items={}", TraceHwndValue(ownerHwnd), screenPoint.x, screenPoint.y, items.size());
        return std::nullopt;
    }
    Debug::Perf::Emit(L"DxUi::PopupShow", L"root", Debug::Perf::ElapsedUs(startedAt), static_cast<uint64_t>(controller.rootItems.size()), 0u);

    // Run the modal loop
    RunMenuModalLoop(controller);

    DestroyPopupChain(controller);
    RestoreWindowCursorAfterMenu(controller);

    DXUI_MENU_TRACE(L"DxUi::MenuTrace ContextMenu show-end owner={:#x} result={} captureAfter={:#x}",
                    reinterpret_cast<uintptr_t>(ownerHwnd),
                    controller.result.value_or(-1),
                    reinterpret_cast<uintptr_t>(GetCapture()));
    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.show-end",
                                L"owner={:#x} result={} captureAfter={:#x} focusAfter={:#x}",
                                TraceHwndValue(ownerHwnd),
                                controller.result.value_or(-1),
                                TraceHwndValue(GetCapture()),
                                TraceHwndValue(GetFocus()));

    return controller.result;
}

bool ContextMenu::ShowAsync(HWND ownerHwnd,
                            POINT screenPoint,
                            std::span<const MenuFlyoutItem> items,
                            const ThemePalette& theme,
                            ContextMenuClosedCallback onClosed,
                            const ContextMenuSessionCallbacks& sessionCallbacks)
{
    if (g_asyncMenuProcessExit || items.empty() || ! ownerHwnd)
    {
        return false;
    }

    DXUI_MENU_TRACE(
        L"DxUi::MenuTrace ContextMenu show-async-begin owner={:#x} point=({}, {}) items={} focusFirst={} ignoreInitialUp=({}, {}) captureBefore={:#x}",
        reinterpret_cast<uintptr_t>(ownerHwnd),
        screenPoint.x,
        screenPoint.y,
        items.size(),
        sessionCallbacks.focusFirstNavigableItem ? L"true" : L"false",
        sessionCallbacks.ignoreInitialLeftButtonUp ? L"true" : L"false",
        sessionCallbacks.ignoreInitialRightButtonUp ? L"true" : L"false",
        reinterpret_cast<uintptr_t>(GetCapture()));
    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.show-async-begin",
                                L"owner={:#x} point=({}, {}) items={} focusFirst={} ignoreInitialLeftUp={} ignoreInitialRightUp={} maxRootHeightDip={:.1f} "
                                L"captureBefore={:#x} focusBefore={:#x} activeBefore={:#x} hitWindow={:#x}",
                                TraceHwndValue(ownerHwnd),
                                screenPoint.x,
                                screenPoint.y,
                                items.size(),
                                TraceBool(sessionCallbacks.focusFirstNavigableItem),
                                TraceBool(sessionCallbacks.ignoreInitialLeftButtonUp),
                                TraceBool(sessionCallbacks.ignoreInitialRightButtonUp),
                                sessionCallbacks.maxRootHeightDip,
                                TraceHwndValue(GetCapture()),
                                TraceHwndValue(GetFocus()),
                                TraceHwndValue(GetActiveWindow()),
                                TraceHwndValue(WindowFromPoint(screenPoint)));

    auto controller              = std::make_unique<MenuController>();
    controller->ownerHwnd        = ownerHwnd;
    controller->theme            = theme;
    controller->style            = ResolveMenuVisualStyle(theme);
    controller->sessionCallbacks = sessionCallbacks;
    controller->asyncOnClosed    = std::move(onClosed);
    controller->asyncSession     = true;
    if (sessionCallbacks.focusFirstNavigableItem)
    {
        RememberKeyboardRootSwitchMessageTime(*controller, CurrentMessageTime());
    }

    controller->rootItems.assign(items.begin(), items.end());

    const auto startedAt = std::chrono::steady_clock::now();
    if (! CreateMenuPopupWindow(*controller,
                                controller->rootItems.data(),
                                controller->rootItems.size(),
                                screenPoint,
                                false,
                                nullptr,
                                nullptr,
                                true,
                                sessionCallbacks.focusFirstNavigableItem))
    {
        DXUI_MENU_DIAGNOSTICS_TRACE(
            L"menu.show-async-create-failed", L"owner={:#x} point=({}, {}) items={}", TraceHwndValue(ownerHwnd), screenPoint.x, screenPoint.y, items.size());
        return false;
    }
    Debug::Perf::Emit(L"DxUi::PopupShow", L"root_async", Debug::Perf::ElapsedUs(startedAt), static_cast<uint64_t>(controller->rootItems.size()), 0u);

    MenuController& controllerRef = *controller;
    ActiveAsyncMenuControllers().push_back(std::move(controller));
    if (! BeginAsyncMenuInteraction(controllerRef))
    {
        // Contract: returning false means the closed callback never fires. Drop
        // it before finalizing so FinalizeAsyncMenuController cannot invoke it.
        controllerRef.asyncOnClosed = nullptr;
        FinalizeAsyncMenuController(controllerRef);
        return false;
    }

    DXUI_MENU_DIAGNOSTICS_TRACE(L"menu.show-async-end",
                                L"owner={:#x} root={:#x} captureAfter={:#x} focusAfter={:#x}",
                                TraceHwndValue(ownerHwnd),
                                TraceHwndValue(controllerRef.GetRootPopup() ? controllerRef.GetRootPopup()->hwnd : nullptr),
                                TraceHwndValue(GetCapture()),
                                TraceHwndValue(GetFocus()));
    return true;
}

bool ContextMenu::PostMenuBarHover(HWND target, size_t hoverIndex, std::uintptr_t sequence) noexcept
{
    // Without its registered message nothing is posted, and the caller sees a failed post.
    const WndMsg::RegisteredMessage hover = WndMsg::ContextMenuRootHoverChanged();
    return hover && PostMessageW(target, hover.value, static_cast<WPARAM>(hoverIndex), static_cast<LPARAM>(sequence)) != FALSE;
}

#if DXUI_ENABLE_DIAGNOSTICS
bool DebugGetContextMenuItemDisplayText(const MenuFlyoutItem& item, std::wstring& outText)
{
    outText = ParseMenuLabel(DecodeMenuItemText(item).labelText).displayText;
    return true;
}

bool TryGetMenuPopupState(const MenuPopup& popup, ContextMenuPopupDebugState& outState) noexcept
{
    outState = {};

    outState.hasScrollbar                = popup.NeedsScrollbar();
    outState.descriptionPreparationCount = popup.descriptionPreparationCount;
    outState.usesSystemBackdrop          = popup.usesSystemBackdrop;
    outState.usesAppBackdropBlur         = popup.usesAppBackdropBlur;
    outState.dpi                         = popup.dpi;
    outState.visibleWidthDip             = popup.menuWidthDip;
    outState.visibleHeightDip            = popup.menuHeightDip;
    outState.contentHeightDip            = popup.contentHeightDip;
    outState.scrollOffsetDip             = popup.scrollOffsetDip;
    outState.viewportRectDip             = popup.GetViewportRect();
    outState.scrollbarTrackRectDip       = popup.NeedsScrollbar() ? popup.GetScrollbarTrackRect() : D2D1::RectF();
    outState.scrollbarThumbRectDip       = popup.NeedsScrollbar() ? popup.GetScrollbarThumbRect() : D2D1::RectF();
    outState.surfaceRectPx               = popup.surfaceRectPx;
    outState.windowRectPx                = popup.windowRectPx;
    outState.hoveredIndex                = popup.hoveredIndex;
    outState.keyboardIndex               = popup.keyboardIndex;
    outState.hoverTimerActive            = popup.hoverTimerId != 0;
    outState.hoverTimerPendingOpen       = popup.hoverTimerKind == MenuPopup::SubmenuHoverTimerKind::PendingOpen;
    outState.hoverTimerPendingClose      = popup.hoverTimerKind == MenuPopup::SubmenuHoverTimerKind::PendingClose;
    outState.hoverTimerItemIndex         = popup.hoverTimerItemIndex != SIZE_MAX ? std::optional<size_t>{popup.hoverTimerItemIndex} : std::nullopt;
    outState.itemTexts.reserve(popup.itemCount);
    outState.itemAcceleratorTexts.reserve(popup.itemCount);
    outState.itemSecondaryTexts.reserve(popup.itemCount);
    outState.itemKinds.reserve(popup.itemCount);
    outState.itemEnabled.reserve(popup.itemCount);
    outState.sliderValues.reserve(popup.itemCount);
    outState.sliderStopCounts.reserve(popup.itemCount);
    outState.sliderAnimatedPositions.reserve(popup.itemCount);
    outState.sliderTargetPositions.reserve(popup.itemCount);
    outState.sliderDragging.reserve(popup.itemCount);
    outState.sliderStopVisualExtentsDip.reserve(popup.itemCount);
    for (size_t itemIndex = 0; itemIndex < popup.itemCount; ++itemIndex)
    {
        std::wstring text;
        static_cast<void>(DebugGetContextMenuItemDisplayText(popup.items[itemIndex], text));
        outState.itemTexts.push_back(std::move(text));
        outState.itemAcceleratorTexts.push_back(std::wstring(DecodeMenuItemText(popup.items[itemIndex]).acceleratorText));
        outState.itemSecondaryTexts.push_back(popup.items[itemIndex].secondaryText);
        outState.itemKinds.push_back(popup.items[itemIndex].kind);
        outState.itemEnabled.push_back(popup.items[itemIndex].enabled);
        if (popup.items[itemIndex].kind == MenuItemKind::Slider)
        {
            outState.sliderValues.push_back(ClampSliderValue(popup.items[itemIndex]));
            outState.sliderStopCounts.push_back(static_cast<uint32_t>(popup.items[itemIndex].sliderStops.size()));
            const bool ownsAnimation = popup.sliderAnimationInitialized && popup.sliderAnimationItemIndex == std::optional<size_t>{itemIndex};
            outState.sliderAnimatedPositions.push_back(ownsAnimation ? popup.sliderAnimatedPosition
                                                                     : static_cast<float>(ClampSliderValue(popup.items[itemIndex])));
            outState.sliderTargetPositions.push_back(ownsAnimation ? popup.sliderAnimationTargetPosition
                                                                   : static_cast<float>(ClampSliderValue(popup.items[itemIndex])));
            outState.sliderDragging.push_back(popup.draggingSliderItemIndex == std::optional<size_t>{itemIndex});
            std::vector<float> visualExtents;
            visualExtents.reserve(popup.items[itemIndex].sliderStops.size());
            for (size_t stopIndex = 0u; stopIndex < popup.items[itemIndex].sliderStops.size(); ++stopIndex)
            {
                visualExtents.push_back(ResolveSliderStopVisualExtentDip(stopIndex, popup.items[itemIndex].sliderStops.size()));
            }
            outState.sliderStopVisualExtentsDip.push_back(std::move(visualExtents));
        }
        else
        {
            outState.sliderValues.push_back(0u);
            outState.sliderStopCounts.push_back(0u);
            outState.sliderAnimatedPositions.push_back(0.0f);
            outState.sliderTargetPositions.push_back(0.0f);
            outState.sliderDragging.push_back(false);
            outState.sliderStopVisualExtentsDip.emplace_back();
        }
    }
    outState.renderCount          = popup.host.DebugGetRenderCount();
    outState.lastPaintedItemCount = popup.lastPaintedItemCount;
    if (popup.controller)
    {
        outState.rootPointerSwitchCount         = popup.controller->rootPointerSwitchCount;
        outState.rootSwitchImmediateRenderCount = popup.controller->rootSwitchImmediateRenderCount;
    }
    return true;
}

bool DebugGetContextMenuPopupState(HWND hwnd, ContextMenuPopupDebugState& outState) noexcept
{
    outState = {};
    if (IsAnotherThreadsWindow(hwnd))
    {
        // Posted, so the menu loop answers it ahead of owner traffic.
        return CallMenuPopupDebugProbe(hwnd, WndMsg::MenuPopupDebugGetState(), true, kMenuDebugStateDispatchTimeoutMs, 0u, nullptr, outState);
    }

    const auto* popup = reinterpret_cast<const MenuPopup*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (! popup || popup->hwnd != hwnd)
    {
        return false;
    }

    return TryGetMenuPopupState(*popup, outState);
}

ContextMenuResourceDebugState DebugGetContextMenuResources() noexcept
{
    return ContextMenuResourceDebugState{.popups               = Detail::LiveResourceCount::Live(Detail::LiveResource::MenuPopup),
                                         .rowLayouts           = Detail::LiveResourceCount::Live(Detail::LiveResource::MenuRowLayout),
                                         .accessibilityRecords = Detail::LiveResourceCount::Live(Detail::LiveResource::MenuAccessibilityRecord)};
}

void DebugSetContextMenuStateProbeStallForTest(HANDLE enteredEvent, HANDLE releaseEvent) noexcept
{
    g_menuDebugStateHandlerEnteredEvent.store(enteredEvent, std::memory_order_release);
    g_menuDebugStateHandlerReleaseEvent.store(releaseEvent, std::memory_order_release);
}

void DebugSetContextMenuModalLoopPeekHookForTest(ContextMenuModalLoopPeekHook hook, void* context) noexcept
{
    // The context first, so the loop never calls a new hook with the previous context.
    g_menuModalLoopPeekHook.store(nullptr, std::memory_order_release);
    g_menuModalLoopPeekHookContext.store(context, std::memory_order_release);
    g_menuModalLoopPeekHook.store(hook, std::memory_order_release);
}

bool DebugFireContextMenuPopupHoverTimer(HWND hwnd) noexcept
{
    const DWORD windowThreadId = GetWindowThreadProcessId(hwnd, nullptr);
    if (windowThreadId != 0 && windowThreadId != GetCurrentThreadId())
    {
        return PostMessageW(hwnd, WM_TIMER, kSubmenuHoverTimerId, 0) != FALSE;
    }

    const auto* popup = reinterpret_cast<const MenuPopup*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (! popup || popup->hwnd != hwnd)
    {
        return false;
    }

    return PostMessageW(hwnd, WM_TIMER, kSubmenuHoverTimerId, 0) != FALSE;
}

bool TryGetMenuPopupItemRect(const MenuPopup& popup, size_t itemIndex, D2D1_RECT_F& outRectDip) noexcept
{
    outRectDip = D2D1::RectF();
    if (itemIndex >= popup.itemCount)
    {
        return false;
    }

    outRectDip = GetVisibleItemRect(popup, itemIndex);
    return outRectDip.right > outRectDip.left && outRectDip.bottom > outRectDip.top;
}

bool DebugGetContextMenuPopupItemRect(HWND hwnd, size_t itemIndex, D2D1_RECT_F& outRectDip) noexcept
{
    outRectDip = D2D1::RectF();
    if (IsAnotherThreadsWindow(hwnd))
    {
        return CallMenuPopupDebugProbe(hwnd, WndMsg::MenuPopupDebugGetItemRect(), false, kMenuDebugProbeTimeoutMs, itemIndex, nullptr, outRectDip);
    }

    const auto* popup = reinterpret_cast<const MenuPopup*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (! popup || popup->hwnd != hwnd)
    {
        return false;
    }

    return TryGetMenuPopupItemRect(*popup, itemIndex, outRectDip);
}

bool TryGetMenuPopupItemPaint(const MenuPopup& popup, size_t itemIndex, ContextMenuPopupItemPaintDebugState& outState) noexcept
{
    outState = {};
    if (itemIndex >= popup.itemCount || ! popup.controller)
    {
        return false;
    }

    const auto& item              = popup.items[itemIndex];
    const bool isHovered          = (popup.hoveredIndex.has_value() && popup.hoveredIndex.value() == itemIndex) ||
                                    (popup.keyboardIndex.has_value() && popup.keyboardIndex.value() == itemIndex);
    const ParsedMenuLabel label   = ParseMenuLabel(DecodeMenuItemText(item).labelText);
    const auto itemPaint          = ResolveMenuItemPaintStyle(popup.controller->theme, popup.controller->style, item, label.displayText, isHovered);
    outState.hovered              = isHovered;
    outState.disabled             = ! item.enabled;
    outState.usesHighlightFill    = itemPaint.showHighlightFill;
    outState.usesRainbowHighlight = itemPaint.usesRainbowHighlight;
    outState.fillColor            = itemPaint.fill;
    outState.compositeFillColor   = itemPaint.compositeFill;
    outState.textColor            = itemPaint.text;
    outState.acceleratorColor     = itemPaint.accelText;
    outState.iconColor            = itemPaint.iconColor;
    outState.checkColor           = itemPaint.checkColor;
    outState.chevronColor         = itemPaint.chevronColor;
    return true;
}

bool DebugGetContextMenuPopupItemPaint(HWND hwnd, size_t itemIndex, ContextMenuPopupItemPaintDebugState& outState) noexcept
{
    outState = {};
    if (IsAnotherThreadsWindow(hwnd))
    {
        return CallMenuPopupDebugProbe(hwnd, WndMsg::MenuPopupDebugGetItemPaint(), false, kMenuDebugProbeTimeoutMs, itemIndex, nullptr, outState);
    }

    const auto* popup = reinterpret_cast<const MenuPopup*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (! popup || popup->hwnd != hwnd)
    {
        return false;
    }

    return TryGetMenuPopupItemPaint(*popup, itemIndex, outState);
}

bool DebugGetContextMenuPopupItemText(HWND hwnd, size_t itemIndex, std::wstring& outText) noexcept
{
    outText.clear();
    if (IsAnotherThreadsWindow(hwnd))
    {
        return CallMenuPopupDebugProbe(hwnd, WndMsg::MenuPopupDebugGetItemText(), false, kMenuDebugProbeTimeoutMs, itemIndex, nullptr, outText);
    }

    const auto* popup = reinterpret_cast<const MenuPopup*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (! popup || popup->hwnd != hwnd)
    {
        return false;
    }

    return TryGetMenuPopupItemText(*popup, itemIndex, outText);
}

bool DebugGetContextMenuPopupItemLayout(HWND hwnd, size_t itemIndex, ContextMenuPopupItemLayoutDebugState& outState) noexcept
{
    outState = {};
    if (IsAnotherThreadsWindow(hwnd))
    {
        return CallMenuPopupDebugProbe(hwnd, WndMsg::MenuPopupDebugGetItemLayout(), false, kMenuDebugProbeTimeoutMs, itemIndex, nullptr, outState);
    }

    const auto* popup = reinterpret_cast<const MenuPopup*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (! popup || popup->hwnd != hwnd || itemIndex >= popup->itemCount)
    {
        return false;
    }

    const MenuItemLayoutRects layout = GetMenuItemLayoutRects(*popup, itemIndex);
    outState.itemRectDip             = layout.itemRectDip;
    outState.iconRectDip             = layout.iconRectDip;
    outState.textRectDip             = layout.textRectDip;
    outState.acceleratorRectDip      = layout.acceleratorRectDip;
    outState.chevronRectDip          = layout.chevronRectDip;
    outState.secondaryTextRectDip    = layout.secondaryTextRectDip;
    if (! popup->descriptionLayouts.empty())
    {
        const auto& row             = popup->descriptionLayouts[itemIndex];
        outState.primaryLineCount   = row.primaryMetrics.lineCount;
        outState.secondaryLineCount = row.secondaryMetrics.lineCount;
        // One layout holds both fields, so both wrap at its width.
        outState.primaryLayoutWidthDip   = row.layout ? row.layout->GetMaxWidth() : 0.0f;
        outState.secondaryLayoutWidthDip = outState.primaryLayoutWidthDip;
        if (row.layout)
        {
            // Where DirectWrite starts the description: the top of the line that holds its first character.
            float pointX = 0.0f;
            float pointY = 0.0f;
            DWRITE_HIT_TEST_METRICS hit{};
            if (SUCCEEDED(row.layout->HitTestTextPosition(row.description.startPosition, FALSE, &pointX, &pointY, &hit)))
                outState.descriptionOffsetDip = hit.top;
        }
    }
    outState.hasBitmapIcon = popup->items[itemIndex].iconBitmap != nullptr;
    return outState.itemRectDip.right > outState.itemRectDip.left && outState.itemRectDip.bottom > outState.itemRectDip.top;
}

bool DebugSetContextMenuPopupBackdropCapture(HWND hwnd, const WindowHostBitmapCapture& capture) noexcept
{
    if (capture.widthPx == 0u || capture.heightPx == 0u || capture.bgraPixels.empty())
    {
        return false;
    }
    if (IsAnotherThreadsWindow(hwnd))
    {
        // The popup is read only on its own thread, which may be freeing it now.
        bool installed = false;
        return CallMenuPopupDebugProbe(hwnd, WndMsg::MenuPopupDebugSetBackdrop(), false, kMenuDebugProbeTimeoutMs, 0u, &capture, installed);
    }

    auto* popup = reinterpret_cast<MenuPopup*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (! popup || popup->hwnd != hwnd)
    {
        return false;
    }
    popup->backdropSnapshot.capture      = capture;
    popup->backdropSnapshot.cachedBitmap = nullptr;
    popup->backdropSnapshot.cachedDevice = nullptr;
    popup->usesAppBackdropBlur           = true;
    popup->host.Invalidate();
    return true;
}

bool DebugSimulateContextMenuPopupDeviceLoss(HWND hwnd) noexcept
{
    auto* popup = reinterpret_cast<MenuPopup*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (! popup || popup->hwnd != hwnd || GetWindowThreadProcessId(hwnd, nullptr) != GetCurrentThreadId())
    {
        return false;
    }

    popup->host.DebugSimulateDeviceLoss();
    return true;
}

bool DebugCaptureContextMenuPopupBitmap(HWND hwnd, WindowHostBitmapCapture& outCapture) noexcept
{
    outCapture = {};
    if (IsAnotherThreadsWindow(hwnd))
    {
        // The popup is read only on its own thread, which may be freeing it now.
        return CallMenuPopupDebugProbe(hwnd, WndMsg::MenuPopupDebugCaptureBitmap(), false, kMenuDebugProbeTimeoutMs, 0u, nullptr, outCapture);
    }

    auto* popup = reinterpret_cast<MenuPopup*>(GetWindowLongPtrW(hwnd, GWLP_USERDATA));
    if (! popup || popup->hwnd != hwnd)
    {
        return false;
    }
    return popup->host.DebugCaptureBitmap(outCapture);
}

bool DebugComputeContextMenuPopupPosition(POINT screenPoint,
                                          float widthDip,
                                          float heightDip,
                                          UINT dpi,
                                          bool isSubmenu,
                                          const RECT* parentRect,
                                          const RECT* parentItemRect,
                                          ContextMenuRootHorizontalAlignment rootHorizontalAlignment,
                                          RECT& outRect) noexcept
{
    return DebugComputeContextMenuPopupPosition(screenPoint,
                                                widthDip,
                                                heightDip,
                                                dpi,
                                                isSubmenu,
                                                parentRect,
                                                parentItemRect,
                                                rootHorizontalAlignment,
                                                ContextMenuRootVerticalPlacement::Below,
                                                outRect);
}

bool DebugComputeContextMenuPopupPosition(POINT screenPoint,
                                          float widthDip,
                                          float heightDip,
                                          UINT dpi,
                                          bool isSubmenu,
                                          const RECT* parentRect,
                                          const RECT* parentItemRect,
                                          ContextMenuRootHorizontalAlignment rootHorizontalAlignment,
                                          ContextMenuRootVerticalPlacement rootVerticalPlacement,
                                          RECT& outRect) noexcept
{
    outRect = RECT{};
    if (dpi == 0 || widthDip <= 0.0f || heightDip <= 0.0f)
    {
        return false;
    }

    outRect =
        ComputePopupPosition(screenPoint, widthDip, heightDip, dpi, isSubmenu, rootHorizontalAlignment, rootVerticalPlacement, parentRect, parentItemRect);
    return outRect.right > outRect.left && outRect.bottom > outRect.top;
}
#endif

} // namespace DxUi
