#include "../Support/Diagnostics.h"
#include "../Support/LiveResourceCount.h"
#include "../Support/WindowMessages.h"
#include "DxUi.AccessibilityTextUnits.h"
#include "DxUi.Internal.h"
#include <DxUi/Embedded.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstring>
#include <format>
#include <limits>
#include <memory>
#include <mutex>
#include <new>
#include <optional>
#include <span>
#include <string>
#include <unordered_set>
#include <utility>
#include <vector>

#include <UIAutomation.h>
#include <oleauto.h>

#pragma comment(lib, "uiautomationcore.lib")

namespace DxUi
{
struct EmbeddedAccessibilityAccess
{
    static void*& Target(ControlHost& host) noexcept
    {
        return host._embeddedAccessibilityTarget;
    }

    // Who reports the focus move a window host just published; focusResolutions is how many calls of the fragment
    // root's GetFocus had begun once the snapshot was stored.
    //
    // The system raises a focus event when the window gains focus, and UI Automation answers it in one of two ways. It
    // asks a window it has not reported before with a call of GetFocus, on whatever thread, which reads the snapshot
    // published when the call runs. A window it has reported it answers without GetFocus: it asks the window's root
    // element whether it has the keyboard focus, and reports that element when it does and nothing when the focus is
    // inside a control. The click that activates a window moves focus in the same turn as the gain, before UI Automation
    // has acted on the event, so in a window UI Automation has asked before, the moved-to control is the host's to
    // announce: nothing else reports it. In a window it has never asked, the GetFocus call that answers the event comes
    // after the move and reports the moved-to element, so the host leaves the move to it.
    enum class FocusMoveReporter : uint8_t
    {
        Host,            // The host raises the focus change.
        SystemAtGain,    // Made inside OnSetFocus: the system's focus event for the gain reports it.
        SystemUnanswered // Made later in the gain's turn in a window no GetFocus call has begun on: the call that answers
                         // the system's focus event reads the moved-to element.
    };

    [[nodiscard]] static FocusMoveReporter ReporterOfFocusMove(const ControlHost& host, uint64_t focusResolutions) noexcept
    {
        if (host._gainingWindowFocus)
            return FocusMoveReporter::SystemAtGain;
        if (host.IsInFocusGainTurn() && focusResolutions == 0u)
            return FocusMoveReporter::SystemUnanswered;
        return FocusMoveReporter::Host;
    }

    static void CountFocusAnnouncement(ControlHost& host) noexcept
    {
        ++host._debugFocusAnnouncementCount;
    }

    static void CountFocusMoveLeftToSystem(ControlHost& host) noexcept
    {
        ++host._debugFocusMovesLeftToSystemCount;
    }

    // A gain begins while `focusResolutions` fragment-root GetFocus calls have begun.
    static void BeginFocusGain(ControlHost& host, uint64_t focusResolutions) noexcept
    {
        host._focusGainResolutions   = focusResolutions;
        host._focusGainTurnAnnounced = false;
    }

    // The host announced a focus move before the gain's turn ended (a move after the turn's 500 ms limit included), so
    // the end of the turn has nothing left to report.
    static void NoteFocusMoveAnnounced(ControlHost& host) noexcept
    {
        if (host._focusGainTurnStartedMs != 0u)
            host._focusGainTurnAnnounced = true;
    }

    // What the gain focused or restored reaches no client unless the host announces it: UI Automation had asked for the
    // window's focus before the gain began, so it answers the gain without asking, and the host announced no move of the
    // turn since.
    [[nodiscard]] static bool FocusGainIsUnreported(const ControlHost& host) noexcept
    {
        return host._focusGainResolutions != 0u && ! host._focusGainTurnAnnounced;
    }

    static void CountReactivationAnnouncement(ControlHost& host) noexcept
    {
        ++host._debugReactivationAnnouncementCount;
    }
};

namespace
{
constexpr PCWSTR kWindowHostPropName                                = L"DxUi.ControlHost";
constexpr uint32_t kAccessibilityMaxDepth                           = 16u;
constexpr DWORD kAccessibilityUiActionDispatchTimeoutMs             = 5000u;
constexpr LONG kAccessibilityRuntimeIdTreeItem                      = 1'001;
constexpr LONG kAccessibilityRuntimeIdGridRow                       = 1'002;
constexpr LONG kAccessibilityRuntimeIdGridCell                      = 1'003;
constexpr LONG kAccessibilityRuntimeIdGridHeader                    = 1'004;
constexpr LONG kAccessibilityRuntimeIdPasswordRevealButton          = 1'005;
constexpr size_t kAccessibilityMaxRuntimeIdValueCount               = kAccessibilityMaxDepth + 16u;
constexpr size_t kAccessibilityMaxMaterializedOffscreenSelectedRows = 256u;

class AccessibilityProvider;
class AccessibilityTextRangeProvider;

enum class AccessibilityUiActionKind : uint8_t
{
    SetFocus,
    Invoke,
    Toggle,
    SetStringValue,
    SetRangeValue,
    Select,
    AddToSelection,
    RemoveFromSelection,
    Expand,
    Collapse,
    ExpandTextRangeToVisualLine,
    MoveTextRangeByVisualLine,
    MoveTextRangeEndpointByVisualLine,
    ResolveTextRangeBounds,
    ResolveTextRangeFromPoint,
};

struct AccessibilityUiActionRequest
{
    AccessibilityProvider* provider                   = nullptr;
    AccessibilityTextRangeProvider* textRangeProvider = nullptr;
    AccessibilityUiActionKind kind                    = AccessibilityUiActionKind::Invoke;
    std::wstring stringValue{};
    double numberValue                         = 0.0;
    size_t textRangeStart                      = 0u;
    size_t textRangeEnd                        = 0u;
    TextPatternRangeEndpoint textRangeEndpoint = TextPatternRangeEndpoint_Start;
    UiaPoint textRangePoint{};
    int textRangeMoveCount      = 0;
    int textRangeMoved          = 0;
    size_t textRangeResultStart = 0u;
    size_t textRangeResultEnd   = 0u;
    size_t textRangeTextLength  = 0u;
    std::vector<D2D1_RECT_F> textRangeBoundsDip;
    float textRangeDipToPixelScale = 1.0f;
    HRESULT result                 = static_cast<HRESULT>(UIA_E_NOTSUPPORTED);
};

struct AccessibilityUiActionDispatch
{
    AccessibilityUiActionDispatch()                                                = default;
    AccessibilityUiActionDispatch(const AccessibilityUiActionDispatch&)            = delete;
    AccessibilityUiActionDispatch& operator=(const AccessibilityUiActionDispatch&) = delete;
    AccessibilityUiActionDispatch(AccessibilityUiActionDispatch&&)                 = delete;
    AccessibilityUiActionDispatch& operator=(AccessibilityUiActionDispatch&&)      = delete;

    AccessibilityUiActionRequest request;
    wil::com_ptr_nothrow<IRawElementProviderSimple> providerKeepAlive;
    wil::com_ptr_nothrow<ITextRangeProvider> textRangeProviderKeepAlive;
    wil::unique_event_nothrow completedEvent;

    enum class State : uint8_t
    {
        Pending,
        Taken,
        Abandoned,
    };
    std::atomic<State> state{State::Pending};
};

struct AccessibilityUiActionPayload
{
    AccessibilityUiActionPayload()                                               = default;
    AccessibilityUiActionPayload(const AccessibilityUiActionPayload&)            = delete;
    AccessibilityUiActionPayload& operator=(const AccessibilityUiActionPayload&) = delete;
    AccessibilityUiActionPayload(AccessibilityUiActionPayload&&)                 = delete;
    AccessibilityUiActionPayload& operator=(AccessibilityUiActionPayload&&)      = delete;

    ~AccessibilityUiActionPayload() noexcept
    {
        if (! dispatch)
        {
            return;
        }

        AccessibilityUiActionDispatch::State expected = AccessibilityUiActionDispatch::State::Pending;
        if (dispatch->state.compare_exchange_strong(
                expected, AccessibilityUiActionDispatch::State::Abandoned, std::memory_order_acq_rel, std::memory_order_acquire))
        {
            dispatch->request.result = HRESULT_FROM_WIN32(ERROR_CANCELLED);
        }
        if (dispatch->completedEvent)
        {
            static_cast<void>(::SetEvent(dispatch->completedEvent.get()));
        }
    }

    std::shared_ptr<AccessibilityUiActionDispatch> dispatch;
};

struct AccessibilityProviderCreationResult
{
    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> provider;
};

struct AccessibilityProviderCreationPayload
{
    std::shared_ptr<AccessibilityProviderCreationResult> result;
};

#if DXUI_ENABLE_DIAGNOSTICS
std::atomic<HANDLE> g_accessibilityUiActionHandlerEnteredEvent{nullptr};
std::atomic<HANDLE> g_accessibilityUiActionHandlerReleaseEvent{nullptr};
std::atomic<HANDLE> g_accessibilityUiActionHandlerTakenEnteredEvent{nullptr};
std::atomic<HANDLE> g_accessibilityUiActionHandlerTakenReleaseEvent{nullptr};
std::atomic<HANDLE> g_accessibilityUiActionPostedEvent{nullptr};
std::atomic<DWORD> g_accessibilityUiActionDispatchTimeoutOverrideMs{0u};
std::atomic<uint32_t> g_accessibilityUiActionExecutionCount{0u};
std::atomic<size_t> g_accessibilityOffscreenSelectedRowMaterializationLimitOverride{0u};
thread_local bool g_accessibilityResolutionCounting       = false;
thread_local uint64_t g_accessibilityResolutionVisitCount = 0u;

// The window whose GetFocus calls a test holds, and the events it uses. The window is stored last when arming and first
// when clearing, so a call never meets events the test has not armed; the holders are the calls that met the gate.
std::atomic<HWND> g_accessibilityFocusResolutionGateWindow{nullptr};
std::atomic<HANDLE> g_accessibilityFocusResolutionGateEnteredEvent{nullptr};
std::atomic<HANDLE> g_accessibilityFocusResolutionGateReleaseEvent{nullptr};
std::atomic<uint32_t> g_accessibilityFocusResolutionGateHolders{0u};
constexpr DWORD kAccessibilityFocusResolutionGateTimeoutMs = 5000u;

// Holds a call of `hwnd`'s GetFocus while a test has gated that window: sets the test's entered event and waits, bounded,
// for its release event. Dormant (two loads) otherwise.
void HoldFocusResolutionForTest(HWND hwnd) noexcept
{
    if (! hwnd || g_accessibilityFocusResolutionGateWindow.load(std::memory_order_seq_cst) != hwnd)
        return;
    // Registered before the window is read again and the events are used: clearing the gate stores the window first and
    // then waits for the calls registered, so the test's events outlive every use of them here.
    g_accessibilityFocusResolutionGateHolders.fetch_add(1u, std::memory_order_seq_cst);
    const auto leave = wil::scope_exit([]() noexcept
    {
        g_accessibilityFocusResolutionGateHolders.fetch_sub(1u, std::memory_order_seq_cst);
        g_accessibilityFocusResolutionGateHolders.notify_all();
    });
    if (g_accessibilityFocusResolutionGateWindow.load(std::memory_order_seq_cst) != hwnd)
        return;
    if (const HANDLE enteredEvent = g_accessibilityFocusResolutionGateEnteredEvent.load(std::memory_order_acquire))
        static_cast<void>(::SetEvent(enteredEvent));
    if (const HANDLE releaseEvent = g_accessibilityFocusResolutionGateReleaseEvent.load(std::memory_order_acquire))
        static_cast<void>(::WaitForSingleObject(releaseEvent, kAccessibilityFocusResolutionGateTimeoutMs));
}

// The records, slots and tree nodes that resolving a control examined on this thread. Dormant unless a test enables
// it, and per thread so that other threads' UI Automation calls neither add to it nor contend on it.
void CountAccessibilityResolutionVisits(size_t visited) noexcept
{
    if (g_accessibilityResolutionCounting)
    {
        g_accessibilityResolutionVisitCount += visited;
    }
}

// What a test runs after each selection event a host raises (DebugSetAccessibilitySelectionEventHookForTest). The context is
// stored before the hook and cleared after it. Dormant (one load) otherwise.
std::atomic<AccessibilitySelectionEventHookForTest> g_accessibilitySelectionEventHook{nullptr};
std::atomic<void*> g_accessibilitySelectionEventHookContext{nullptr};

void NotifySelectionEventRaisedForTest() noexcept
{
    if (const AccessibilitySelectionEventHookForTest hook = g_accessibilitySelectionEventHook.load(std::memory_order_acquire))
    {
        hook(g_accessibilitySelectionEventHookContext.load(std::memory_order_acquire));
    }
}

[[nodiscard]] DWORD AccessibilityUiActionDispatchTimeoutMs() noexcept
{
    const DWORD timeoutOverride = g_accessibilityUiActionDispatchTimeoutOverrideMs.load(std::memory_order_acquire);
    return timeoutOverride != 0u ? timeoutOverride : kAccessibilityUiActionDispatchTimeoutMs;
}

[[nodiscard]] size_t AccessibilityOffscreenSelectedRowMaterializationLimit() noexcept
{
    const size_t limitOverride = g_accessibilityOffscreenSelectedRowMaterializationLimitOverride.load(std::memory_order_acquire);
    return limitOverride != 0u ? limitOverride : kAccessibilityMaxMaterializedOffscreenSelectedRows;
}

[[nodiscard]] std::wstring_view AccessibilityGridSnapshotPerfDetail() noexcept
{
    const size_t limitOverride = g_accessibilityOffscreenSelectedRowMaterializationLimitOverride.load(std::memory_order_acquire);
    if (limitOverride > kAccessibilityMaxMaterializedOffscreenSelectedRows)
    {
        return L"selection-baseline-unbounded";
    }
    if (limitOverride != 0u)
    {
        return L"selection-candidate-capped";
    }
    return L"selection";
}

void MaybeStallAccessibilityUiActionHandlerForTest() noexcept
{
    const HANDLE enteredEvent = g_accessibilityUiActionHandlerEnteredEvent.load(std::memory_order_acquire);
    const HANDLE releaseEvent = g_accessibilityUiActionHandlerReleaseEvent.load(std::memory_order_acquire);
    if (enteredEvent)
    {
        static_cast<void>(::SetEvent(enteredEvent));
    }
    if (releaseEvent)
    {
        static_cast<void>(::WaitForSingleObject(releaseEvent, AccessibilityUiActionDispatchTimeoutMs() + 2000u));
    }
}

void MaybeStallTakenAccessibilityUiActionHandlerForTest() noexcept
{
    const HANDLE enteredEvent = g_accessibilityUiActionHandlerTakenEnteredEvent.load(std::memory_order_acquire);
    const HANDLE releaseEvent = g_accessibilityUiActionHandlerTakenReleaseEvent.load(std::memory_order_acquire);
    if (enteredEvent)
    {
        static_cast<void>(::SetEvent(enteredEvent));
    }
    if (releaseEvent)
    {
        static_cast<void>(::WaitForSingleObject(releaseEvent, AccessibilityUiActionDispatchTimeoutMs() + 2000u));
    }
}
#else
[[nodiscard]] constexpr DWORD AccessibilityUiActionDispatchTimeoutMs() noexcept
{
    return kAccessibilityUiActionDispatchTimeoutMs;
}

[[nodiscard]] constexpr size_t AccessibilityOffscreenSelectedRowMaterializationLimit() noexcept
{
    return kAccessibilityMaxMaterializedOffscreenSelectedRows;
}

[[nodiscard]] constexpr std::wstring_view AccessibilityGridSnapshotPerfDetail() noexcept
{
    return L"selection";
}

constexpr void CountAccessibilityResolutionVisits(size_t) noexcept
{
}

constexpr void HoldFocusResolutionForTest(HWND) noexcept
{
}

constexpr void NotifySelectionEventRaisedForTest() noexcept
{
}
#endif

struct ControlPath
{
    uint32_t depth = 0u;
    std::array<uint16_t, kAccessibilityMaxDepth> indices{};
};

[[nodiscard]] bool AreControlPathsEqual(const ControlPath& left, const ControlPath& right) noexcept
{
    if (left.depth != right.depth)
    {
        return false;
    }

    for (uint32_t index = 0u; index < left.depth; ++index)
    {
        if (left.indices[index] != right.indices[index])
        {
            return false;
        }
    }
    return true;
}

enum class AccessibilityFragmentKind : uint8_t
{
    Root,
    Control,
    TreeItem,
    GridHeader,
    GridRow,
    GridCell,
    TextFieldPasswordRevealButton,
};

struct AccessibilityFocusedFragmentSnapshot
{
    AccessibilityFragmentKind kind = AccessibilityFragmentKind::Control;
    ControlPath path{};
    size_t treeVisibleIndex = 0u;
    uint64_t treeItemId     = 0u;
    uint64_t gridRowId      = 0u;
};

struct AccessibilityPointHitSnapshot
{
    AccessibilityFragmentKind kind = AccessibilityFragmentKind::Control;
    ControlPath path{};
    D2D1_RECT_F hitRectDip  = D2D1::RectF();
    size_t treeVisibleIndex = 0u;
    uint64_t gridRowId      = 0u;
    size_t gridColumnIndex  = 0u;
};

struct AccessibilityPointHitBuildContext
{
    D2D1_POINT_2F translationDip = D2D1::Point2F();
    std::optional<D2D1_RECT_F> clipRectDip;
};

struct AccessibilityTreeItemSnapshotRecord
{
    size_t visibleIndex = 0u;
    uint64_t itemId     = 0u;
    std::wstring text;
    size_t depth     = 0u;
    bool hasChildren = false;
    bool expanded    = false;
};

struct AccessibilityGridHeaderSnapshotRecord
{
    size_t columnIndex = 0u;
    std::wstring gridHeaderName;
};

struct AccessibilityGridRowSnapshotRecord
{
    size_t rowIndex = 0u;
    uint64_t rowId  = 0u;
    std::wstring gridRowAccessibleName;
};

struct AccessibilityGridCellStateSnapshotRecord
{
    size_t rowIndex                     = 0u;
    uint64_t rowId                      = 0u;
    size_t columnIndex                  = 0u;
    CONTROLTYPEID gridCellControlTypeId = UIA_TextControlTypeId;
    std::wstring gridCellAccessibleText;
    std::wstring gridCellHelpText;
    bool gridCellEnabled            = false;
    bool gridCellChecked            = false;
    bool gridCellSupportsToggle     = false;
    bool gridCellSupportsValue      = false;
    bool gridCellSupportsRangeValue = false;
    double gridCellRangeValue       = 0.0;
};

struct TextRangeSpan
{
    size_t start = 0u;
    size_t end   = 0u;
};

struct AccessibilityControlNavigationSnapshot
{
    ControlPath path{};
    std::weak_ptr<int> controlLifetime;
    uint64_t controlIdentity    = 0;
    CONTROLTYPEID controlTypeId = UIA_TextControlTypeId;
    std::wstring controlAccessibleName;
    std::wstring controlAccessibleHelpText;
    std::wstring controlAutomationId;
    std::wstring controlAccessibleValue;
    std::wstring controlAccessibleText;
    bool controlVisible            = false;
    bool controlEnabled            = false;
    bool controlFocusable          = false;
    bool controlHasFocus           = false;
    bool controlIsPassword         = false;
    bool controlSupportsInvoke     = false;
    bool controlSupportsToggle     = false;
    bool controlSupportsValue      = false;
    bool controlSupportsText       = false;
    bool controlSupportsRangeValue = false;
    bool controlSupportsSelection  = false;
    bool controlSupportsTable      = false;
    bool controlValueReadOnly      = true;
    bool controlToggleChecked      = false;
    std::optional<bool> controlDisclosureExpanded;
    size_t controlTextSelectionStart = 0u;
    size_t controlTextSelectionEnd   = 0u;
    std::vector<D2D1_RECT_F> controlTextSelectionBoundsDip;
    std::optional<size_t> controlTextCompositionStart;
    std::optional<size_t> controlTextCompositionEnd;
    std::optional<size_t> controlTextConversionTargetStart;
    std::optional<size_t> controlTextConversionTargetEnd;
    double controlRangeValue         = 0.0;
    double controlRangeMinimum       = 0.0;
    double controlRangeMaximum       = 0.0;
    double controlRangeSmallChange   = 0.0;
    double controlRangeLargeChange   = 0.0;
    bool isGrid                      = false;
    bool isTree                      = false;
    bool gridCanSelectMultiple       = false;
    bool treeCanSelectMultiple       = false;
    bool hasPasswordRevealButton     = false;
    bool passwordRevealButtonEnabled = false;
    bool treeIsEnabled               = false;
    bool gridIsEnabled               = false;
    size_t gridRowCount              = 0u;
    size_t gridColumnCount           = 0u;
    size_t treeVisibleItemCount      = 0u;
    std::wstring passwordRevealButtonAccessibleName;
    // The tree's selected (focused) item. With multi-select it is the focused item, which need not be selected:
    // selectedTreeItemIds holds the selection, in visible order.
    std::optional<size_t> selectedTreeVisibleIndex;
    std::vector<uint64_t> selectedTreeItemIds;
    std::vector<AccessibilityTreeItemSnapshotRecord> treeItems;
    std::vector<AccessibilityGridHeaderSnapshotRecord> gridHeaders;
    std::vector<AccessibilityGridRowSnapshotRecord> gridRows;
    std::vector<AccessibilityGridCellStateSnapshotRecord> gridCells;
    std::vector<size_t> gridVisibleColumns;
    std::vector<size_t> gridVisibleRows;
    std::vector<uint64_t> gridVisibleRowIds;
    std::vector<uint64_t> selectedGridRowIds;
};

struct AccessibilityNavigationTarget
{
    AccessibilityFragmentKind kind = AccessibilityFragmentKind::Root;
    ControlPath path{};
    uint64_t treeItemId    = 0u;
    uint64_t gridRowId     = 0u;
    size_t gridColumnIndex = 0u;
};

struct AccessibilityGridCellSnapshotRecord
{
    const AccessibilityControlNavigationSnapshot* controlRecord = nullptr;
    const AccessibilityGridCellStateSnapshotRecord* cellRecord  = nullptr;
    size_t rowIndex                                             = 0u;
    size_t columnIndex                                          = 0u;
};

// A hash table of record ordinals. The caller hashes a key; probing steps from the slot that hash picks (by growing
// strides, which visit every slot of a power-of-two table without the clusters that unit strides build) until the
// caller's test accepts a record (its whole key matches) or a slot is empty. It is sized once, to a power of two of at
// least four times its entries, when a snapshot is published and only read afterwards, so a lookup allocates nothing
// and examines a slot or two however many records the snapshot holds.
class AccessibilityOrdinalIndex final
{
public:
    void Reserve(size_t entryCount)
    {
        const size_t slotCount = std::bit_ceil((std::max)(entryCount, size_t{1u}) * 4u);
        _slots.assign(slotCount, 0u);
        _mask = slotCount - 1u;
    }

    // Places the record unless the test accepts one placed on the way: the first record of a key is the one found.
    template <typename Matches> void Place(uint64_t hash, uint32_t ordinal, const Matches& matches) noexcept
    {
        size_t stride = 0u;
        for (size_t slot = static_cast<size_t>(hash) & _mask;; slot = (slot + ++stride) & _mask)
        {
            if (_slots[slot] == 0u)
            {
                _slots[slot] = ordinal + 1u;
                return;
            }
            if (matches(_slots[slot] - 1u))
            {
                return;
            }
        }
    }

    template <typename Matches> [[nodiscard]] std::optional<uint32_t> Find(uint64_t hash, const Matches& matches) const noexcept
    {
        if (_slots.empty())
        {
            return std::nullopt;
        }

        size_t examined = 0u;
        size_t stride   = 0u;
        std::optional<uint32_t> found;
        for (size_t slot = static_cast<size_t>(hash) & _mask; _slots[slot] != 0u; slot = (slot + ++stride) & _mask)
        {
            ++examined;
            if (matches(_slots[slot] - 1u))
            {
                found = _slots[slot] - 1u;
                break;
            }
        }
        CountAccessibilityResolutionVisits(found ? examined : examined + 1u); // A miss also examines the empty slot that ends it.
        return found;
    }

private:
    std::vector<uint32_t> _slots; // A record's ordinal plus one; zero marks an empty slot.
    size_t _mask = 0u;
};

// Where a record's control lived when it was published: compared, never dereferenced, so an event naming a control
// that has since been removed (and perhaps destroyed) is safe.
struct AccessibilityControlAddress
{
    uintptr_t address = 0u;
    uint32_t ordinal  = 0u;
};

struct AccessibilitySnapshot
{
    HWND hwnd     = nullptr;
    bool embedded = false;
    EmbeddedAccessibilityPlacement placement{};
    DWORD buildThreadId           = 0u;
    DWORD windowThreadId          = 0u;
    bool alive                    = false;
    bool hasRetainedRoot          = false;
    bool hasCollapsedSemanticRoot = false;
    float pixelsToDipScale        = 1.0f;
    std::wstring windowName;
    std::optional<AccessibilityFocusedFragmentSnapshot> focusedFragment;
    std::vector<AccessibilityPointHitSnapshot> pointHitRecords;
    // semanticControlOrder[i] is the path of controlNavigationRecords[i], both in tree order.
    std::vector<ControlPath> semanticControlOrder;
    std::vector<AccessibilityControlNavigationSnapshot> controlNavigationRecords;
    // Resolving what a provider or an event names costs a probe or two whatever the size of the tree: these tables
    // over the records above are filled once when the snapshot is published (IndexAccessibilitySnapshot) and only read
    // afterwards. A control's record is found by its path, a fragment's hit rectangle by its kind, path and item, and a
    // control's record by its address (sorted, so a search takes about log2 of the records).
    AccessibilityOrdinalIndex controlRecordsByPath;
    AccessibilityOrdinalIndex pointHitsByFragment;
    std::vector<AccessibilityControlAddress> controlsByAddress;
    // What DebugGetContextMenuResources reports for a snapshot of a menu popup while anything still holds it.
    Detail::LiveResourceCount liveMenuRecords;
};

[[nodiscard]] bool IsSemanticAccessibilityControl(const Control* control) noexcept;
[[nodiscard]] bool TryResolveSingleSemanticRootControlPath(const Control* root, ControlPath& outPath) noexcept;
[[nodiscard]] bool SnapshotHasCollapsedSemanticRoot(const AccessibilitySnapshot& snapshot) noexcept;
[[nodiscard]] const AccessibilityControlNavigationSnapshot* FindControlNavigationRecord(const AccessibilitySnapshot& snapshot,
                                                                                        const ControlPath& path) noexcept;
[[nodiscard]] std::optional<uint32_t> FindControlRecordOrdinalByAddress(const AccessibilitySnapshot& snapshot, const Control* control) noexcept;
void IndexAccessibilitySnapshot(AccessibilitySnapshot& snapshot);
[[nodiscard]] std::wstring_view GetControlAccessibleName(const Control* root, const Control* control) noexcept;
[[nodiscard]] std::wstring_view GetControlAccessibleValue(const Control* control) noexcept;
[[nodiscard]] std::wstring GetControlAccessibleTextRangeText(const Control* control);
[[nodiscard]] TextRangeSpan GetControlAccessibleSelectionRange(const ControlHost* host, const Control* control, size_t textLength) noexcept;
[[nodiscard]] TextRangeSpan GetTextRangeSpanFromState(size_t caretIndex, std::optional<size_t> selectionAnchorIndex, size_t textLength) noexcept;
[[nodiscard]] D2D1_RECT_F ResolveTextPatternViewportRect(const Control* control) noexcept;
[[nodiscard]] std::optional<std::vector<D2D1_RECT_F>> TryResolveTextRangeCaretRects(const ControlHost& host,
                                                                                    const Control& control,
                                                                                    std::wstring_view text,
                                                                                    const TextRangeSpan& range);
[[nodiscard]] std::wstring BuildGridCellAccessibleText(const GridCellData& cellData);
[[nodiscard]] std::wstring_view GetGridHeaderAccessibleName(const GridColumnDesc& columnDesc) noexcept;
[[nodiscard]] CONTROLTYPEID GetGridCellControlTypeId(const GridCellData& cellData) noexcept;
[[nodiscard]] CONTROLTYPEID GetControlTypeId(const Control* control) noexcept;
[[nodiscard]] bool SupportsInvokePattern(const Control* control) noexcept;
[[nodiscard]] bool SupportsTogglePattern(const Control* control) noexcept;
[[nodiscard]] bool SupportsValuePattern(const Control* control) noexcept;
[[nodiscard]] bool SupportsTextPattern(const Control* control) noexcept;
[[nodiscard]] bool SupportsRangeValuePattern(const Control* control) noexcept;
[[nodiscard]] bool IsValueReadOnly(const Control* control) noexcept;
[[nodiscard]] bool GridCellSupportsTogglePattern(const GridCellData& cellData) noexcept;
[[nodiscard]] bool GridCellSupportsValuePattern(const GridCellData& cellData) noexcept;
[[nodiscard]] bool GridCellSupportsRangeValuePattern(const GridCellData& cellData) noexcept;
[[nodiscard]] double GetGridCellRangeValue(const GridCellData& cellData) noexcept;
[[nodiscard]] bool FindAccessibilityPathForTarget(const Control* current, const ControlPath& basePath, const Control* target, ControlPath& outPath) noexcept;
void AppendAccessibilitySnapshotPointHits(ControlHost& host, const Control* current, const ControlPath& basePath, AccessibilitySnapshot& snapshot);
void AppendAccessibilitySnapshotPointHits(
    ControlHost& host, const Control* current, const ControlPath& basePath, AccessibilitySnapshot& snapshot, const AccessibilityPointHitBuildContext& context);
[[nodiscard]] size_t CountAccessibilitySnapshotNavigation(const Control* current, const ControlPath& basePath) noexcept;
void AppendAccessibilitySnapshotNavigation(
    ControlHost& host, const Control* root, const Control* current, const ControlPath& basePath, AccessibilitySnapshot& snapshot);
[[nodiscard]] const AccessibilityPointHitSnapshot* FindSnapshotPointHit(const AccessibilitySnapshot& snapshot, D2D1_POINT_2F pointDip) noexcept;
[[nodiscard]] std::optional<D2D1_RECT_F> FindSnapshotFragmentBounds(const AccessibilitySnapshot& snapshot,
                                                                    AccessibilityFragmentKind kind,
                                                                    const ControlPath& path,
                                                                    size_t treeVisibleIndex,
                                                                    uint64_t gridRowId,
                                                                    size_t gridColumnIndex) noexcept;
[[nodiscard]] std::optional<AccessibilityNavigationTarget> ResolveSnapshotNavigationTarget(const AccessibilitySnapshot& snapshot,
                                                                                           AccessibilityFragmentKind kind,
                                                                                           const ControlPath& path,
                                                                                           uint64_t treeItemId,
                                                                                           uint64_t gridRowId,
                                                                                           size_t gridColumnIndex,
                                                                                           NavigateDirection direction) noexcept;

struct WindowHostAccessibilityTarget final
{
    explicit WindowHostAccessibilityTarget(HWND hwnd, ControlHost* host) noexcept : hwnd(hwnd), host(host)
    {
    }

    WindowHostAccessibilityTarget(const WindowHostAccessibilityTarget&)            = delete;
    WindowHostAccessibilityTarget& operator=(const WindowHostAccessibilityTarget&) = delete;
    WindowHostAccessibilityTarget(WindowHostAccessibilityTarget&&)                 = delete;
    WindowHostAccessibilityTarget& operator=(WindowHostAccessibilityTarget&&)      = delete;

    [[nodiscard]] ULONG AddRef() noexcept
    {
        return _referenceCount.fetch_add(1u, std::memory_order_relaxed) + 1u;
    }

    [[nodiscard]] ULONG Release() noexcept
    {
        const ULONG remaining = _referenceCount.fetch_sub(1u, std::memory_order_acq_rel) - 1u;
        if (remaining == 0u)
        {
            delete this;
        }
        return remaining;
    }

    [[nodiscard]] ControlHost* ResolveHost() const noexcept
    {
        if (embedded)
        {
            if (threadId != GetCurrentThreadId() || rootLifetime.expired())
                return nullptr;
            return host.load(std::memory_order_acquire);
        }
        if (! hwnd || IsWindow(hwnd) == FALSE)
        {
            return nullptr;
        }

        ControlHost* const resolvedHost = host.load(std::memory_order_acquire);
        if (! resolvedHost)
        {
            return nullptr;
        }

        const DWORD windowThreadId = GetWindowThreadProcessId(hwnd, nullptr);
        if (windowThreadId != 0u && windowThreadId != GetCurrentThreadId())
        {
            return nullptr;
        }

        return resolvedHost;
    }

    std::atomic<ULONG> _referenceCount{1u};
    HWND hwnd = nullptr;
    // Decided once: only a menu popup's snapshots count for DebugGetContextMenuResources.
    const bool menuPopup = IsNativeMenuPopupWindow(hwnd);
    bool embedded        = false;
    DWORD threadId       = GetCurrentThreadId();
    uint64_t runtimeId   = 0;
    uint64_t preparation = 0;
    std::weak_ptr<int> rootLifetime;
    std::shared_ptr<EmbeddedAccessibilitySite> site;
    EmbeddedAccessibilityPlacement placement{};
    std::atomic<ControlHost*> host{nullptr};
    std::atomic<std::shared_ptr<const AccessibilitySnapshot>> snapshot;
    // Calls of a provider's GetFocus (the fragment root's, for the system's focus event) that have begun. Each counts
    // itself, then reads the snapshot; a publish stores the snapshot, then reads the count, so a call the count does
    // not include reads the snapshot after the store: see RefreshWindowHostAccessibilitySnapshot. All four operations are
    // sequentially consistent.
    std::atomic<uint64_t> focusResolutions{0u};
    // The last live snapshot while an empty one stands in during a root swap, so the publish after the swap reports
    // what it changed. Set and consumed under the accessibility mutex; never held past that publish.
    std::shared_ptr<const AccessibilitySnapshot> diffBaseline;
    wil::com_ptr_nothrow<IRawElementProviderSimple> rootProvider;
};

[[nodiscard]] UiaRect EmbeddedScreenBounds(const AccessibilitySnapshot& snapshot, const D2D1_RECT_F& bounds) noexcept
{
    const auto& box     = snapshot.placement.viewport;
    const double scale  = 1.0 / snapshot.pixelsToDipScale;
    const double left   = std::clamp(box.left + bounds.left * scale, box.left, box.left + box.width);
    const double top    = std::clamp(box.top + bounds.top * scale, box.top, box.top + box.height);
    const double right  = std::clamp(box.left + bounds.right * scale, left, box.left + box.width);
    const double bottom = std::clamp(box.top + bounds.bottom * scale, top, box.top + box.height);
    return {left, top, right - left, bottom - top};
}

[[nodiscard]] std::recursive_mutex& GetAccessibilityTargetMutex() noexcept
{
    static std::recursive_mutex mutex;
    return mutex;
}

[[nodiscard]] std::shared_ptr<const AccessibilitySnapshot> MakeEmptyAccessibilitySnapshot(HWND hwnd)
{
    auto snapshot            = std::make_shared<AccessibilitySnapshot>();
    snapshot->hwnd           = hwnd;
    snapshot->buildThreadId  = GetCurrentThreadId();
    snapshot->windowThreadId = hwnd ? GetWindowThreadProcessId(hwnd, nullptr) : 0u;
    snapshot->alive          = false;
    return snapshot;
}

void PublishAccessibilitySnapshot(WindowHostAccessibilityTarget& target, std::shared_ptr<const AccessibilitySnapshot> snapshot) noexcept
{
    // Sequentially consistent: the publisher's read of the GetFocus count that follows this store is ordered with the
    // count GetFocus makes before it loads the snapshot (RefreshWindowHostAccessibilitySnapshot).
    target.snapshot.store(std::move(snapshot), std::memory_order_seq_cst);
}

void PublishEmptyAccessibilitySnapshot(WindowHostAccessibilityTarget& target) noexcept
{
    PublishAccessibilitySnapshot(target, MakeEmptyAccessibilitySnapshot(target.hwnd));
}

// How a publish changed the selection of a Tree or a Grid, for the UI Automation selection events. A tree's items are its
// visible items, of which it selects several with multi-select and otherwise one; a grid's are its rows, of which it may
// select several. The rules are WPF's for its selectors: a selection that became exactly one item that was not selected
// before is reported as that item being selected (the others left it, which that event says); any other change is reported
// item by item, as items added to and removed from the selection, and more than kAccessibilityMaxSelectionEvents of them as
// one invalidation of the container, so that selecting everything in a large tree or grid raises one event.
constexpr size_t kAccessibilityMaxSelectionEvents = 20u;

struct SelectionChange
{
    ControlPath path{};
    uint64_t controlIdentity           = 0u; // The tree's or grid's: its events are raised while it is still the one published there.
    AccessibilityFragmentKind itemKind = AccessibilityFragmentKind::TreeItem; // TreeItem or GridRow.
    std::vector<uint64_t> added;                                              // Selected now, not before.
    std::vector<uint64_t> removed; // Selected before, not now, and an element of the new snapshot (a tree's visible item, a grid's row on screen).
    bool replaced    = false;      // The selection is now exactly one item, which was not selected before.
    bool invalidated = false;      // Too many changes to name, or one that cannot be named: an item that left has no element now and
                                   // the selection did not become one new item, whose event would say that it left.
};

// What the selection of each tree and grid of `after` gained and lost since `before`, the snapshot published before it. A control
// that is another control there has nothing to compare with and reports nothing.
[[nodiscard]] std::vector<SelectionChange> CollectSelectionChanges(const AccessibilitySnapshot& before, const AccessibilitySnapshot& after);

// What a window-host publish changed for UI Automation clients; an embedded host diffs the rest of its snapshots itself.
struct WindowHostSnapshotChanges
{
    bool focusMoved       = false;           // Another element (control, tree item, grid row, or none) has focus.
    bool structureChanged = false;           // A semantic control was added, removed or replaced at its path.
    std::vector<SelectionChange> selections; // Trees and grids whose selection changed (embedded hosts too).
    std::shared_ptr<const AccessibilitySnapshot> previous;
    std::shared_ptr<const AccessibilitySnapshot> current;
};

[[nodiscard]] bool SameControlLifetime(const std::weak_ptr<int>& first, const std::weak_ptr<int>& second) noexcept
{
    return ! first.owner_before(second) && ! second.owner_before(first);
}

[[nodiscard]] bool SameFocusedElement(const AccessibilitySnapshot& before, const AccessibilitySnapshot& after) noexcept
{
    if (before.focusedFragment.has_value() != after.focusedFragment.has_value())
        return false;
    if (! after.focusedFragment.has_value())
        return true;
    const AccessibilityFocusedFragmentSnapshot& old = before.focusedFragment.value();
    const AccessibilityFocusedFragmentSnapshot& now = after.focusedFragment.value();
    const AccessibilityControlNavigationSnapshot* a = FindControlNavigationRecord(before, old.path);
    const AccessibilityControlNavigationSnapshot* b = FindControlNavigationRecord(after, now.path);
    return old.kind == now.kind && AreControlPathsEqual(old.path, now.path) && old.treeItemId == now.treeItemId && old.gridRowId == now.gridRowId && a && b &&
           SameControlLifetime(a->controlLifetime, b->controlLifetime);
}

[[nodiscard]] bool SameSemanticControls(const AccessibilitySnapshot& before, const AccessibilitySnapshot& after) noexcept
{
    if (before.controlNavigationRecords.size() != after.controlNavigationRecords.size())
        return false;
    for (size_t index = 0u; index < after.controlNavigationRecords.size(); ++index)
    {
        const AccessibilityControlNavigationSnapshot& old = before.controlNavigationRecords[index];
        const AccessibilityControlNavigationSnapshot& now = after.controlNavigationRecords[index];
        if (! AreControlPathsEqual(old.path, now.path) || ! SameControlLifetime(old.controlLifetime, now.controlLifetime))
            return false;
    }
    return true;
}

WindowHostSnapshotChanges PublishWindowHostAccessibilitySnapshot(WindowHostAccessibilityTarget& target, ControlHost& host)
{
    auto snapshot              = std::make_shared<AccessibilitySnapshot>();
    snapshot->hwnd             = target.hwnd;
    snapshot->buildThreadId    = GetCurrentThreadId();
    snapshot->windowThreadId   = target.hwnd ? GetWindowThreadProcessId(target.hwnd, nullptr) : 0u;
    snapshot->alive            = true;
    snapshot->embedded         = target.embedded;
    snapshot->placement        = target.placement;
    snapshot->pixelsToDipScale = USER_DEFAULT_SCREEN_DPI / host.GetDpi();
    const Control* const root  = host.GetRoot();
    snapshot->hasRetainedRoot  = root != nullptr;
    // Sized once: a menu's rows make thousands of records, which growing vectors would move again and again.
    const size_t semanticControls = CountAccessibilitySnapshotNavigation(root, ControlPath{});
    snapshot->semanticControlOrder.reserve(semanticControls);
    snapshot->controlsByAddress.reserve(semanticControls);
    snapshot->controlNavigationRecords.reserve(semanticControls);
    AppendAccessibilitySnapshotNavigation(host, root, root, ControlPath{}, *snapshot);
    if (root && ! target.embedded)
    {
        ControlPath collapsedRootPath{};
        const bool explicitStatusRoot      = root->GetAccessibilityRole() == AccessibilityRole::Status;
        snapshot->hasCollapsedSemanticRoot = TryResolveSingleSemanticRootControlPath(root, collapsedRootPath) && ! snapshot->semanticControlOrder.empty() &&
                                             (snapshot->semanticControlOrder.size() == 1u || explicitStatusRoot) &&
                                             AreControlPathsEqual(snapshot->semanticControlOrder.front(), collapsedRootPath);
    }
    AppendAccessibilitySnapshotPointHits(host, root, ControlPath{}, *snapshot);
    IndexAccessibilitySnapshot(*snapshot);

    // The host prunes a focused control that left the tree only at its next message, so find it by pointer before
    // touching it: one removed with its panel's children in the meantime is gone, not focused. The records are the
    // semantic controls the tree holds, and their addresses are only compared.
    Control* const focused = host.GetFocusControl();
    if (root && focused)
    {
        if (const std::optional<uint32_t> focusedOrdinal = FindControlRecordOrdinalByAddress(*snapshot, focused))
        {
            AccessibilityFocusedFragmentSnapshot focusedFragment{};
            focusedFragment.path = snapshot->controlNavigationRecords[focusedOrdinal.value()].path;

            if (const auto* tree = dynamic_cast<const Tree*>(focused))
            {
                if (const auto* model = tree->GetModel(); model && tree->GetSelectedItemId())
                {
                    if (const std::optional<size_t> visibleIndex = model->FindVisibleItemById(tree->GetSelectedItemId().value()))
                    {
                        focusedFragment.kind             = AccessibilityFragmentKind::TreeItem;
                        focusedFragment.treeVisibleIndex = visibleIndex.value();
                        focusedFragment.treeItemId       = tree->GetSelectedItemId().value();
                    }
                }
            }
            else if (const auto* grid = dynamic_cast<const Grid*>(focused))
            {
                if (const auto* model = grid->GetModel(); model)
                {
                    if (const std::optional<size_t> selectedRow = grid->GetPrimarySelectedRow())
                    {
                        focusedFragment.kind      = AccessibilityFragmentKind::GridRow;
                        focusedFragment.gridRowId = model->GetStableRowId(selectedRow.value());
                    }
                }
            }

            snapshot->focusedFragment = focusedFragment;
        }
    }

    wchar_t windowText[128]{};
    const int length = target.hwnd ? GetWindowTextW(target.hwnd, windowText, static_cast<int>(std::size(windowText))) : 0;
    snapshot->windowName.assign(windowText, static_cast<size_t>((std::max)(0, length)));
    if (target.embedded)
        snapshot->windowName = root && ! root->GetAccessibleName().empty() ? root->GetAccessibleName() : L"Embedded controls";

    if (target.embedded && ! target.placement.hasKeyboardFocus)
    {
        snapshot->focusedFragment.reset();
        for (auto& record : snapshot->controlNavigationRecords)
            record.controlHasFocus = false;
    }
    if (target.menuPopup)
        snapshot->liveMenuRecords = Detail::LiveResourceCount(Detail::LiveResource::MenuAccessibilityRecord, snapshot->controlNavigationRecords.size());
    WindowHostSnapshotChanges changes{};
    std::shared_ptr<const AccessibilitySnapshot> previous = target.snapshot.load(std::memory_order_acquire);
    if (! previous || ! previous->alive)
        previous = std::move(target.diffBaseline); // A root swap's stand-in: compare with the tree before it.
    target.diffBaseline.reset();
    if (previous && previous->alive && previous->hasRetainedRoot && UiaClientsAreListening())
    {
        changes.focusMoved = ! SameFocusedElement(*previous, *snapshot);
        if (! target.embedded)
        {
            changes.structureChanged = ! SameSemanticControls(*previous, *snapshot);
            changes.previous         = previous;
            changes.current          = snapshot;
        }
        changes.selections = CollectSelectionChanges(*previous, *snapshot);
    }
    PublishAccessibilitySnapshot(target, std::move(snapshot));
    return changes;
}

[[nodiscard]] std::shared_ptr<const AccessibilitySnapshot> CaptureAccessibilitySnapshot(WindowHostAccessibilityTarget* target, HWND hwnd)
{
    if (! target || (target->embedded && (! target->host.load(std::memory_order_acquire) || target->rootLifetime.expired())))
    {
        return nullptr;
    }

    // Sequentially consistent, for a GetFocus that counted itself just before: see PublishAccessibilitySnapshot.
    if (auto snapshot = target->snapshot.load(std::memory_order_seq_cst))
    {
        return snapshot;
    }

    return MakeEmptyAccessibilitySnapshot(hwnd);
}

[[nodiscard]] WindowHostAccessibilityTarget* AcquireWindowHostAccessibilityTarget(HWND hwnd) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return nullptr;
    }

    const std::scoped_lock lock(GetAccessibilityTargetMutex());
    auto* target = static_cast<WindowHostAccessibilityTarget*>(GetPropW(hwnd, kWindowHostPropName));
    if (! target)
    {
        return nullptr;
    }

    static_cast<void>(target->AddRef());
    return target;
}

[[nodiscard]] bool TryAppendPathIndex(const ControlPath& source, size_t childIndex, ControlPath& outPath) noexcept
{
    if (source.depth >= source.indices.size() || childIndex > (std::numeric_limits<uint16_t>::max)())
    {
        return false;
    }

    outPath                        = source;
    outPath.indices[outPath.depth] = static_cast<uint16_t>(childIndex);
    ++outPath.depth;
    return true;
}

template <typename TControl> [[nodiscard]] TControl* ResolveControlAtPath(TControl* root, const ControlPath& path) noexcept
{
    CountAccessibilityResolutionVisits(path.depth + 1u);
    TControl* current = root;
    for (uint32_t depth = 0u; depth < path.depth; ++depth)
    {
        auto* panel = dynamic_cast<Panel*>(current);
        if (! panel)
        {
            return nullptr;
        }

        const auto children = panel->GetChildren();
        const size_t index  = path.indices[depth];
        if (index >= children.size() || ! children[index])
        {
            return nullptr;
        }

        current = children[index].get();
    }

    return current;
}

[[nodiscard]] bool IsControlPathVisible(const Control* root, const ControlPath& path) noexcept
{
    CountAccessibilityResolutionVisits(path.depth + 1u);
    const Control* current = root;
    if (! current || ! current->IsVisible())
    {
        return false;
    }

    for (uint32_t depth = 0u; depth < path.depth; ++depth)
    {
        const auto* panel = dynamic_cast<const Panel*>(current);
        if (! panel)
        {
            return false;
        }

        const auto children = panel->GetChildren();
        const size_t index  = path.indices[depth];
        if (index >= children.size() || ! children[index])
        {
            return false;
        }

        current = children[index].get();
        if (! current->IsVisible())
        {
            return false;
        }
    }

    return true;
}

[[nodiscard]] bool IsSemanticAccessibilityControl(const Control* control) noexcept
{
    return (control && control->GetAccessibilityRole() != AccessibilityRole::Default) || dynamic_cast<const Label*>(control) != nullptr ||
           dynamic_cast<const Button*>(control) != nullptr || dynamic_cast<const TextField*>(control) != nullptr ||
           dynamic_cast<const ComboBox*>(control) != nullptr || dynamic_cast<const Tree*>(control) != nullptr ||
           dynamic_cast<const Grid*>(control) != nullptr || dynamic_cast<const Slider*>(control) != nullptr ||
           dynamic_cast<const ProgressBar*>(control) != nullptr || dynamic_cast<const ThroughputGraph*>(control) != nullptr ||
           dynamic_cast<const ColorSwatch*>(control) != nullptr || dynamic_cast<const Splitter*>(control) != nullptr;
}

[[nodiscard]] bool FindFirstSemanticControl(const Control* current, const ControlPath& basePath, ControlPath& outPath) noexcept
{
    if (! current || ! current->IsVisible())
    {
        return false;
    }

    if (IsSemanticAccessibilityControl(current))
    {
        outPath = basePath;
        return true;
    }

    auto* panel = dynamic_cast<const Panel*>(current);
    if (! panel)
    {
        return false;
    }

    const auto children = panel->GetChildren();
    for (size_t index = 0u; index < children.size(); ++index)
    {
        if (! children[index])
        {
            continue;
        }

        ControlPath childPath{};
        if (! TryAppendPathIndex(basePath, index, childPath))
        {
            continue;
        }

        if (FindFirstSemanticControl(children[index].get(), childPath, outPath))
        {
            return true;
        }
    }

    return false;
}

[[nodiscard]] bool FindNextSemanticControl(const Control* root, const ControlPath& currentPath, ControlPath& outPath) noexcept
{
    if (! root)
    {
        return false;
    }

    ControlPath cursor = currentPath;
    while (cursor.depth != 0u)
    {
        const uint32_t parentDepth = cursor.depth - 1u;
        ControlPath parentPath     = cursor;
        parentPath.depth           = parentDepth;
        const Control* parent      = ResolveControlAtPath(const_cast<Control*>(root), parentPath);
        const auto* panel          = dynamic_cast<const Panel*>(parent);
        if (! panel)
        {
            return false;
        }

        const auto children       = panel->GetChildren();
        const size_t currentIndex = cursor.indices[parentDepth];
        for (size_t siblingIndex = currentIndex + 1u; siblingIndex < children.size(); ++siblingIndex)
        {
            if (! children[siblingIndex])
            {
                continue;
            }

            ControlPath siblingPath{};
            if (! TryAppendPathIndex(parentPath, siblingIndex, siblingPath))
            {
                continue;
            }

            if (FindFirstSemanticControl(children[siblingIndex].get(), siblingPath, outPath))
            {
                return true;
            }
        }

        cursor.depth = parentDepth;
    }

    return false;
}

[[nodiscard]] bool ShouldExposeSingleSemanticRootControl(const Control* control) noexcept
{
    return dynamic_cast<const Checkbox*>(control) != nullptr || dynamic_cast<const Toggle*>(control) != nullptr ||
           dynamic_cast<const Button*>(control) != nullptr || dynamic_cast<const TextField*>(control) != nullptr ||
           dynamic_cast<const ComboBox*>(control) != nullptr || dynamic_cast<const Tree*>(control) != nullptr ||
           dynamic_cast<const Slider*>(control) != nullptr || dynamic_cast<const Grid*>(control) != nullptr ||
           dynamic_cast<const ColorSwatch*>(control) != nullptr;
}

[[nodiscard]] bool TryResolveSingleSemanticRootControlPath(const Control* root, ControlPath& outPath) noexcept
{
    if (root && root->GetAccessibilityRole() == AccessibilityRole::Status)
    {
        outPath = {};
        return true;
    }

    ControlPath firstPath{};
    if (! FindFirstSemanticControl(root, ControlPath{}, firstPath))
    {
        return false;
    }

    const Control* control = ResolveControlAtPath(const_cast<Control*>(root), firstPath);
    if (! ShouldExposeSingleSemanticRootControl(control))
    {
        return false;
    }

    ControlPath nextPath{};
    if (FindNextSemanticControl(root, firstPath, nextPath))
    {
        return false;
    }

    outPath = firstPath;
    return true;
}

[[nodiscard]] bool IsNonEmptyAccessibilityRect(const D2D1_RECT_F& rect) noexcept
{
    return rect.right > rect.left && rect.bottom > rect.top;
}

[[nodiscard]] D2D1_RECT_F TranslateAccessibilityRect(const D2D1_RECT_F& rect, D2D1_POINT_2F translationDip) noexcept
{
    return D2D1::RectF(rect.left + translationDip.x, rect.top + translationDip.y, rect.right + translationDip.x, rect.bottom + translationDip.y);
}

[[nodiscard]] std::optional<D2D1_RECT_F> IntersectAccessibilityRects(const D2D1_RECT_F& left, const D2D1_RECT_F& right) noexcept
{
    const D2D1_RECT_F intersection = D2D1::RectF(
        (std::max)(left.left, right.left), (std::max)(left.top, right.top), (std::min)(left.right, right.right), (std::min)(left.bottom, right.bottom));
    if (! IsNonEmptyAccessibilityRect(intersection))
    {
        return std::nullopt;
    }
    return intersection;
}

[[nodiscard]] std::optional<D2D1_RECT_F> ApplyAccessibilityPointHitContext(const D2D1_RECT_F& rect, const AccessibilityPointHitBuildContext& context) noexcept
{
    const D2D1_RECT_F translated = TranslateAccessibilityRect(rect, context.translationDip);
    if (! IsNonEmptyAccessibilityRect(translated))
    {
        return std::nullopt;
    }
    if (context.clipRectDip)
    {
        return IntersectAccessibilityRects(translated, context.clipRectDip.value());
    }
    return translated;
}

void AppendAccessibilityPointHit(AccessibilitySnapshot& snapshot,
                                 AccessibilityFragmentKind kind,
                                 const ControlPath& path,
                                 const D2D1_RECT_F& hitRectDip,
                                 size_t treeVisibleIndex = 0u,
                                 uint64_t gridRowId      = 0u,
                                 size_t gridColumnIndex  = 0u)
{
    if (! IsNonEmptyAccessibilityRect(hitRectDip))
    {
        return;
    }

    snapshot.pointHitRecords.push_back(AccessibilityPointHitSnapshot{.kind             = kind,
                                                                     .path             = path,
                                                                     .hitRectDip       = hitRectDip,
                                                                     .treeVisibleIndex = treeVisibleIndex,
                                                                     .gridRowId        = gridRowId,
                                                                     .gridColumnIndex  = gridColumnIndex});
}

void AppendTransformedAccessibilityPointHit(AccessibilitySnapshot& snapshot,
                                            AccessibilityFragmentKind kind,
                                            const ControlPath& path,
                                            const D2D1_RECT_F& hitRectDip,
                                            const AccessibilityPointHitBuildContext& context,
                                            size_t treeVisibleIndex = 0u,
                                            uint64_t gridRowId      = 0u,
                                            size_t gridColumnIndex  = 0u)
{
    if (const std::optional<D2D1_RECT_F> transformed = ApplyAccessibilityPointHitContext(hitRectDip, context))
    {
        AppendAccessibilityPointHit(snapshot, kind, path, transformed.value(), treeVisibleIndex, gridRowId, gridColumnIndex);
    }
}

void AppendTreeAccessibilityPointHits(const Tree& tree,
                                      const ControlPath& path,
                                      AccessibilitySnapshot& snapshot,
                                      const AccessibilityPointHitBuildContext& context)
{
    const auto* model = tree.GetModel();
    if (! model)
    {
        return;
    }

    const D2D1_RECT_F treeHitBounds = tree.GetHitBounds();
    const size_t visibleItemCount   = model->GetVisibleItemCount();
    for (size_t visibleIndex = tree.GetFirstVisibleItemIndex(); visibleIndex < visibleItemCount; ++visibleIndex)
    {
        const std::optional<D2D1_RECT_F> rowRect = tree.GetVisibleItemHitRect(visibleIndex);
        if (! rowRect)
        {
            continue;
        }
        if (rowRect->bottom < treeHitBounds.top)
        {
            continue;
        }
        if (rowRect->top > treeHitBounds.bottom)
        {
            break;
        }

        AppendTransformedAccessibilityPointHit(snapshot, AccessibilityFragmentKind::TreeItem, path, rowRect.value(), context, visibleIndex);
    }
}

void AppendGridAccessibilityPointHits(const Grid& grid,
                                      const ControlPath& path,
                                      AccessibilitySnapshot& snapshot,
                                      const AccessibilityPointHitBuildContext& context)
{
    const auto* model = grid.GetModel();
    if (! model)
    {
        return;
    }

    const size_t visibleColumnCount = grid.GetVisibleColumnCount();
    std::vector<size_t> visibleColumns;
    visibleColumns.reserve(visibleColumnCount);
    for (size_t visibleColumnIndex = 0u; visibleColumnIndex < visibleColumnCount; ++visibleColumnIndex)
    {
        const std::optional<size_t> columnIndex = grid.GetVisibleColumnAt(visibleColumnIndex);
        if (! columnIndex)
        {
            continue;
        }

        visibleColumns.push_back(columnIndex.value());
        if (const std::optional<D2D1_RECT_F> headerRect = grid.GetVisibleColumnHeaderRect(columnIndex.value()))
        {
            AppendTransformedAccessibilityPointHit(
                snapshot, AccessibilityFragmentKind::GridHeader, path, headerRect.value(), context, 0u, 0u, columnIndex.value());
        }
    }

    const size_t visibleRowCount = grid.GetVisibleRowCount();
    for (size_t visibleRowIndex = 0u; visibleRowIndex < visibleRowCount; ++visibleRowIndex)
    {
        const std::optional<size_t> rowIndex = grid.GetVisibleRowAt(visibleRowIndex);
        if (! rowIndex)
        {
            continue;
        }

        const uint64_t rowId = model->GetStableRowId(rowIndex.value());
        for (const size_t columnIndex : visibleColumns)
        {
            if (const std::optional<D2D1_RECT_F> cellRect = grid.GetVisibleCellRect(rowIndex.value(), columnIndex))
            {
                AppendTransformedAccessibilityPointHit(snapshot, AccessibilityFragmentKind::GridCell, path, cellRect.value(), context, 0u, rowId, columnIndex);
            }
        }

        if (const std::optional<D2D1_RECT_F> rowRect = grid.GetVisibleRowRect(rowIndex.value()))
        {
            AppendTransformedAccessibilityPointHit(snapshot, AccessibilityFragmentKind::GridRow, path, rowRect.value(), context, 0u, rowId);
        }
    }
}

void AppendAccessibilitySnapshotPointHits(ControlHost& host, const Control* current, const ControlPath& basePath, AccessibilitySnapshot& snapshot)
{
    AppendAccessibilitySnapshotPointHits(host, current, basePath, snapshot, AccessibilityPointHitBuildContext{});
    AppendAccessibilityPointHit(snapshot, AccessibilityFragmentKind::Root, ControlPath{}, host.GetClientBoundsDip());
}

void AppendAccessibilitySnapshotPointHits(
    ControlHost& host, const Control* current, const ControlPath& basePath, AccessibilitySnapshot& snapshot, const AccessibilityPointHitBuildContext& context)
{
    if (! current || ! current->IsVisible())
    {
        return;
    }

    AccessibilityPointHitBuildContext childContext = context;
    if (const auto* scrollPanel = dynamic_cast<const ScrollPanel*>(current))
    {
        const std::optional<D2D1_RECT_F> viewport = ApplyAccessibilityPointHitContext(scrollPanel->GetViewportRect(), context);
        if (! viewport)
        {
            return;
        }

        childContext.clipRectDip = viewport.value();
        childContext.translationDip.y -= scrollPanel->GetScrollOffset();
    }

    if (const auto* panel = dynamic_cast<const Panel*>(current))
    {
        const auto children = panel->GetChildren();
        for (size_t index = children.size(); index-- > 0u;)
        {
            if (! children[index])
            {
                continue;
            }

            ControlPath childPath{};
            if (! TryAppendPathIndex(basePath, index, childPath))
            {
                continue;
            }

            AppendAccessibilitySnapshotPointHits(host, children[index].get(), childPath, snapshot, childContext);
        }
    }

    if (! IsSemanticAccessibilityControl(current))
    {
        return;
    }

    if (const auto* textField = dynamic_cast<const TextField*>(current); textField && textField->IsPasswordRevealButtonVisibleForAccessibility())
    {
        AppendTransformedAccessibilityPointHit(
            snapshot, AccessibilityFragmentKind::TextFieldPasswordRevealButton, basePath, textField->GetPasswordRevealButtonAccessibilityRect(), context);
    }
    if (const auto* tree = dynamic_cast<const Tree*>(current))
    {
        AppendTreeAccessibilityPointHits(*tree, basePath, snapshot, context);
    }
    else if (const auto* grid = dynamic_cast<const Grid*>(current))
    {
        AppendGridAccessibilityPointHits(*grid, basePath, snapshot, context);
    }

    AppendTransformedAccessibilityPointHit(snapshot, AccessibilityFragmentKind::Control, basePath, current->GetHitBounds(), context);
}

const AccessibilityPointHitSnapshot* FindSnapshotPointHit(const AccessibilitySnapshot& snapshot, D2D1_POINT_2F pointDip) noexcept
{
    size_t visited = 0u;
    for (const AccessibilityPointHitSnapshot& hit : snapshot.pointHitRecords)
    {
        ++visited;
        if (PointInRect(hit.hitRectDip, pointDip))
        {
            CountAccessibilityResolutionVisits(visited);
            return &hit;
        }
    }

    CountAccessibilityResolutionVisits(visited);
    return nullptr;
}

bool SnapshotPointHitMatchesFragment(const AccessibilityPointHitSnapshot& hit,
                                     AccessibilityFragmentKind kind,
                                     const ControlPath& path,
                                     size_t treeVisibleIndex,
                                     uint64_t gridRowId,
                                     size_t gridColumnIndex) noexcept
{
    if (hit.kind != kind || ! AreControlPathsEqual(hit.path, path))
    {
        return false;
    }

    switch (kind)
    {
        case AccessibilityFragmentKind::TreeItem: return hit.treeVisibleIndex == treeVisibleIndex;
        case AccessibilityFragmentKind::GridHeader: return hit.gridColumnIndex == gridColumnIndex;
        case AccessibilityFragmentKind::GridRow: return hit.gridRowId == gridRowId;
        case AccessibilityFragmentKind::GridCell: return hit.gridRowId == gridRowId && hit.gridColumnIndex == gridColumnIndex;
        case AccessibilityFragmentKind::Control:
        case AccessibilityFragmentKind::TextFieldPasswordRevealButton: return true;
        case AccessibilityFragmentKind::Root: return false;
    }

    return false;
}

// MurmurHash3's fmix64, as the retained text layouts' keys use it: every input bit reaches the low bits that pick a slot.
[[nodiscard]] uint64_t MixAccessibilityHash(uint64_t hash) noexcept
{
    hash ^= hash >> 33u;
    hash *= 0xFF51AFD7ED558CCDull;
    hash ^= hash >> 33u;
    hash *= 0xC4CEB9FE1A85EC53ull;
    hash ^= hash >> 33u;
    return hash;
}

[[nodiscard]] uint64_t HashControlPath(const ControlPath& path) noexcept
{
    uint64_t hash = (0xCBF29CE484222325ull ^ path.depth) * 0x100000001B3ull;
    for (uint32_t depth = 0u; depth < path.depth; ++depth)
    {
        hash = (hash ^ path.indices[depth]) * 0x100000001B3ull;
    }
    return MixAccessibilityHash(hash);
}

// What identifies a hit record: its kind, its path and, as SnapshotPointHitMatchesFragment decides, the item within
// the control that the kind names.
[[nodiscard]] uint64_t HashPointHitKey(
    AccessibilityFragmentKind kind, const ControlPath& path, size_t treeVisibleIndex, uint64_t gridRowId, size_t gridColumnIndex) noexcept
{
    constexpr uint64_t kRowFactor    = 0xD6E8FEB86659FD93ull;
    constexpr uint64_t kColumnFactor = 0x165667B19E3779F9ull;
    uint64_t hash                    = HashControlPath(path) + (static_cast<uint64_t>(kind) + 1u) * 0x9E3779B97F4A7C15ull;
    switch (kind)
    {
        case AccessibilityFragmentKind::TreeItem: hash += treeVisibleIndex * 0xC2B2AE3D27D4EB4Full; break;
        case AccessibilityFragmentKind::GridHeader: hash += gridColumnIndex * kColumnFactor; break;
        case AccessibilityFragmentKind::GridRow: hash += gridRowId * kRowFactor; break;
        case AccessibilityFragmentKind::GridCell: hash += gridRowId * kRowFactor + gridColumnIndex * kColumnFactor; break;
        case AccessibilityFragmentKind::Root:
        case AccessibilityFragmentKind::Control:
        case AccessibilityFragmentKind::TextFieldPasswordRevealButton: break;
    }
    return MixAccessibilityHash(hash);
}

// Fills the snapshot's lookup tables from its finished records, as the last step of building it.
void IndexAccessibilitySnapshot(AccessibilitySnapshot& snapshot)
{
    const auto& records = snapshot.controlNavigationRecords;
    snapshot.controlRecordsByPath.Reserve(records.size());
    for (size_t ordinal = 0u; ordinal < records.size(); ++ordinal)
    {
        const ControlPath& path = records[ordinal].path;
        snapshot.controlRecordsByPath.Place(
            HashControlPath(path), static_cast<uint32_t>(ordinal), [&](uint32_t placed) noexcept { return AreControlPathsEqual(records[placed].path, path); });
    }

    const auto& hits = snapshot.pointHitRecords;
    snapshot.pointHitsByFragment.Reserve(hits.size());
    for (size_t ordinal = 0u; ordinal < hits.size(); ++ordinal)
    {
        const AccessibilityPointHitSnapshot& hit = hits[ordinal];
        if (hit.kind == AccessibilityFragmentKind::Root)
        {
            continue; // The window's own rectangle is never looked up by fragment.
        }

        snapshot.pointHitsByFragment.Place(HashPointHitKey(hit.kind, hit.path, hit.treeVisibleIndex, hit.gridRowId, hit.gridColumnIndex),
                                           static_cast<uint32_t>(ordinal),
                                           [&](uint32_t placed) noexcept
        { return SnapshotPointHitMatchesFragment(hits[placed], hit.kind, hit.path, hit.treeVisibleIndex, hit.gridRowId, hit.gridColumnIndex); });
    }

    std::ranges::sort(snapshot.controlsByAddress, [](const AccessibilityControlAddress& first, const AccessibilityControlAddress& second) noexcept {
        return first.address != second.address ? first.address < second.address : first.ordinal < second.ordinal;
    });
}

std::optional<uint32_t> FindControlRecordOrdinalByAddress(const AccessibilitySnapshot& snapshot, const Control* control) noexcept
{
    const auto address = reinterpret_cast<uintptr_t>(control);
    const auto& sorted = snapshot.controlsByAddress;
    size_t low         = 0u;
    size_t high        = sorted.size();
    size_t examined    = 0u;
    while (low < high)
    {
        ++examined;
        const size_t middle = low + (high - low) / 2u;
        if (sorted[middle].address < address)
        {
            low = middle + 1u;
        }
        else
        {
            high = middle;
        }
    }

    CountAccessibilityResolutionVisits(examined);
    return low < sorted.size() && sorted[low].address == address ? std::optional<uint32_t>(sorted[low].ordinal) : std::nullopt;
}

std::optional<D2D1_RECT_F> FindSnapshotFragmentBounds(const AccessibilitySnapshot& snapshot,
                                                      AccessibilityFragmentKind kind,
                                                      const ControlPath& path,
                                                      size_t treeVisibleIndex,
                                                      uint64_t gridRowId,
                                                      size_t gridColumnIndex) noexcept
{
    const std::optional<uint32_t> ordinal = snapshot.pointHitsByFragment.Find(HashPointHitKey(kind, path, treeVisibleIndex, gridRowId, gridColumnIndex),
                                                                              [&](uint32_t placed) noexcept
    { return SnapshotPointHitMatchesFragment(snapshot.pointHitRecords[placed], kind, path, treeVisibleIndex, gridRowId, gridColumnIndex); });
    return ordinal ? std::optional<D2D1_RECT_F>(snapshot.pointHitRecords[ordinal.value()].hitRectDip) : std::nullopt;
}

// A control's identity in runtime ids: a process-wide serial kept in its lifetime token (whose value is otherwise
// unused), assigned when the control is first published on its host's thread. A later control can reuse the token's
// address once every weak reference to an old one is gone; a serial does not repeat until 2^32 controls are published.
[[nodiscard]] uint64_t ControlIdentityOf(const std::weak_ptr<int>& lifetime) noexcept
{
    static std::atomic<uint32_t> nextSerial{0u};
    const std::shared_ptr<int> token = lifetime.lock();
    if (! token)
        return 0u;
    if (*token == 0)
    {
        uint32_t serial = 0u;
        while (serial == 0u)
            serial = nextSerial.fetch_add(1u, std::memory_order_relaxed) + 1u;
        *token = static_cast<int>(serial);
    }
    return static_cast<uint32_t>(*token);
}

// The records AppendAccessibilitySnapshotNavigation makes: the same visibility, semantic and path-depth rules.
size_t CountAccessibilitySnapshotNavigation(const Control* current, const ControlPath& basePath) noexcept
{
    if (! current || ! current->IsVisible())
    {
        return 0u;
    }

    size_t count = IsSemanticAccessibilityControl(current) ? 1u : 0u;
    if (const auto* panel = dynamic_cast<const Panel*>(current))
    {
        const auto children = panel->GetChildren();
        for (size_t index = 0u; index < children.size(); ++index)
        {
            ControlPath childPath{};
            if (children[index] && TryAppendPathIndex(basePath, index, childPath))
            {
                count += CountAccessibilitySnapshotNavigation(children[index].get(), childPath);
            }
        }
    }
    return count;
}

void AppendAccessibilitySnapshotNavigation(
    ControlHost& host, const Control* root, const Control* current, const ControlPath& basePath, AccessibilitySnapshot& snapshot)
{
    if (! current || ! current->IsVisible())
    {
        return;
    }

    if (IsSemanticAccessibilityControl(current))
    {
        snapshot.semanticControlOrder.push_back(basePath);
        snapshot.controlsByAddress.push_back(AccessibilityControlAddress{.address = reinterpret_cast<uintptr_t>(current),
                                                                         .ordinal = static_cast<uint32_t>(snapshot.controlNavigationRecords.size())});

        // Made in place, and complete before the children below add theirs.
        AccessibilityControlNavigationSnapshot& record = snapshot.controlNavigationRecords.emplace_back();

        record.path                      = basePath;
        record.controlLifetime           = GetControlLifetimeToken(*current);
        record.controlIdentity           = ControlIdentityOf(record.controlLifetime);
        record.controlTypeId             = GetControlTypeId(current);
        record.controlAccessibleName     = std::wstring(GetControlAccessibleName(root, current));
        record.controlAccessibleHelpText = current->GetAccessibleHelpText();
        record.controlAutomationId       = current->GetAccessibleAutomationId();
        record.controlVisible            = current->IsVisible();
        record.controlEnabled            = current->IsEnabled();
        record.controlFocusable          = current->IsFocusable();
        record.controlHasFocus           = current->HasFocus();
        if (const auto* textField = dynamic_cast<const TextField*>(current))
        {
            record.controlIsPassword = textField->IsMasked();
        }
        record.controlSupportsInvoke = SupportsInvokePattern(current);
        record.controlSupportsToggle = SupportsTogglePattern(current);
        if (const auto* button = dynamic_cast<const Button*>(current))
        {
            record.controlDisclosureExpanded = button->GetDisclosureExpanded();
        }
        record.controlSupportsValue      = SupportsValuePattern(current);
        record.controlSupportsText       = SupportsTextPattern(current);
        record.controlSupportsRangeValue = SupportsRangeValuePattern(current);
        record.controlValueReadOnly      = IsValueReadOnly(current);
        if (record.controlSupportsValue)
        {
            record.controlAccessibleValue = std::wstring(GetControlAccessibleValue(current));
        }
        if (record.controlSupportsText)
        {
            TextRangeSpan selectionRange{};
            bool hasSelectionRange = false;
            NativeTextInputState nativeState{};
            if (host.TryReadNativeTextInputState(current, nativeState))
            {
                record.controlAccessibleText = nativeState.text;
                selectionRange    = GetTextRangeSpanFromState(nativeState.caretIndex, nativeState.selectionAnchorIndex, record.controlAccessibleText.size());
                hasSelectionRange = true;
                record.controlTextSelectionStart        = selectionRange.start;
                record.controlTextSelectionEnd          = selectionRange.end;
                record.controlTextCompositionStart      = nativeState.compositionStartIndex;
                record.controlTextCompositionEnd        = nativeState.compositionEndIndex;
                record.controlTextConversionTargetStart = nativeState.conversionTargetStartIndex;
                record.controlTextConversionTargetEnd   = nativeState.conversionTargetEndIndex;
            }
            else
            {
                record.controlAccessibleText     = GetControlAccessibleTextRangeText(current);
                selectionRange                   = GetControlAccessibleSelectionRange(&host, current, record.controlAccessibleText.size());
                hasSelectionRange                = true;
                record.controlTextSelectionStart = selectionRange.start;
                record.controlTextSelectionEnd   = selectionRange.end;
            }

            if (hasSelectionRange && selectionRange.start != selectionRange.end)
            {
                if (std::optional<std::vector<D2D1_RECT_F>> bounds =
                        TryResolveTextRangeCaretRects(host, *current, record.controlAccessibleText, selectionRange);
                    bounds.has_value() && ! bounds->empty())
                {
                    record.controlTextSelectionBoundsDip = std::move(bounds.value());
                }
                else
                {
                    record.controlTextSelectionBoundsDip.push_back(ResolveTextPatternViewportRect(current));
                }
            }
        }
        if (const auto* toggle = dynamic_cast<const Toggle*>(current))
        {
            record.controlToggleChecked = toggle->IsChecked();
        }
        if (const auto* slider = dynamic_cast<const Slider*>(current))
        {
            record.controlRangeValue       = slider->GetValue();
            record.controlRangeMinimum     = slider->GetMinimum();
            record.controlRangeMaximum     = slider->GetMaximum();
            record.controlRangeSmallChange = slider->GetStep();
            record.controlRangeLargeChange = slider->GetLargeStep();
        }
        else if (const auto* progress = dynamic_cast<const ProgressBar*>(current))
        {
            record.controlRangeValue       = progress->GetValue();
            record.controlRangeMinimum     = progress->GetMinimum();
            record.controlRangeMaximum     = progress->GetMaximum();
            record.controlRangeSmallChange = 0.0;
            record.controlRangeLargeChange = 0.0;
        }
        else if (const auto* splitter = dynamic_cast<const Splitter*>(current))
        {
            // The separator position in DIPs between the limits the pane minimums allow, stepped like the keyboard.
            record.controlRangeValue       = splitter->GetPosition();
            record.controlRangeMinimum     = splitter->ClampPosition(std::numeric_limits<float>::lowest());
            record.controlRangeMaximum     = splitter->ClampPosition((std::numeric_limits<float>::max)());
            record.controlRangeSmallChange = Splitter::kKeyboardStepDip;
            record.controlRangeLargeChange = Splitter::kKeyboardLargeStepDip;
        }
        if (const auto* textField = dynamic_cast<const TextField*>(current))
        {
            record.hasPasswordRevealButton = textField->IsPasswordRevealButtonVisibleForAccessibility();
            if (record.hasPasswordRevealButton)
            {
                record.passwordRevealButtonAccessibleName = textField->GetPasswordRevealAccessibleName();
                record.passwordRevealButtonEnabled        = textField->IsEnabled();
            }
        }
        else if (const auto* tree = dynamic_cast<const Tree*>(current))
        {
            record.isTree                = true;
            record.treeIsEnabled         = tree->IsEnabled();
            record.treeCanSelectMultiple = tree->MultiSelectEnabled();
            if (const auto* model = tree->GetModel())
            {
                record.treeVisibleItemCount = model->GetVisibleItemCount();
                record.treeItems.reserve(record.treeVisibleItemCount);
                const std::optional<uint64_t> selectedItemId = tree->GetSelectedItemId();
                // With multi-select the selection is the tree's set, reported for the rows that are visible. A single
                // selection builds no set.
                std::optional<std::unordered_set<uint64_t>> selectedItemIds;
                if (record.treeCanSelectMultiple)
                {
                    const std::vector<uint64_t> selection = tree->GetSelectedItemIds();
                    selectedItemIds.emplace(selection.begin(), selection.end());
                }
                for (size_t visibleIndex = 0u; visibleIndex < record.treeVisibleItemCount; ++visibleIndex)
                {
                    TreeItemData item{};
                    model->GetVisibleItem(visibleIndex, item);
                    record.treeItems.push_back(AccessibilityTreeItemSnapshotRecord{.visibleIndex = visibleIndex,
                                                                                   .itemId       = item.id,
                                                                                   .text         = item.text,
                                                                                   .depth        = item.depth,
                                                                                   .hasChildren  = item.hasChildren,
                                                                                   .expanded     = item.expanded});
                    if (selectedItemId && selectedItemId.value() == item.id)
                    {
                        record.selectedTreeVisibleIndex = visibleIndex;
                    }
                    if (selectedItemIds && selectedItemIds->contains(item.id))
                    {
                        record.selectedTreeItemIds.push_back(item.id);
                    }
                }
            }
        }
        else if (const auto* grid = dynamic_cast<const Grid*>(current))
        {
            const bool captureGridSnapshotPerf   = Debug::Perf::IsCaptureEnabled();
            const auto gridSnapshotStartedAt     = std::chrono::steady_clock::now();
            size_t materializedOffscreenRowCount = 0u;
            record.isGrid                        = true;
            record.gridCanSelectMultiple         = grid->GetSelectionMode() != GridSelectionMode::Single;
            record.gridIsEnabled                 = grid->IsEnabled();
            if (const auto* model = grid->GetModel())
            {
                record.gridRowCount    = model->GetRowCount();
                record.gridColumnCount = model->GetColumnCount();

                const size_t visibleColumnCount = grid->GetVisibleColumnCount();
                record.gridVisibleColumns.reserve(visibleColumnCount);
                record.gridHeaders.reserve(visibleColumnCount);
                for (size_t visibleColumnIndex = 0u; visibleColumnIndex < visibleColumnCount; ++visibleColumnIndex)
                {
                    if (const std::optional<size_t> columnIndex = grid->GetVisibleColumnAt(visibleColumnIndex))
                    {
                        record.gridVisibleColumns.push_back(columnIndex.value());
                        const GridColumnDesc columnDesc = model->GetColumn(columnIndex.value());
                        record.gridHeaders.push_back(AccessibilityGridHeaderSnapshotRecord{
                            .columnIndex = columnIndex.value(), .gridHeaderName = std::wstring(GetGridHeaderAccessibleName(columnDesc))});
                    }
                }

                const size_t visibleRowCount = grid->GetVisibleRowCount();
                record.gridVisibleRows.reserve(visibleRowCount);
                record.gridVisibleRowIds.reserve(visibleRowCount);
                record.gridRows.reserve(visibleRowCount);
                for (size_t visibleRowIndex = 0u; visibleRowIndex < visibleRowCount; ++visibleRowIndex)
                {
                    if (const std::optional<size_t> rowIndex = grid->GetVisibleRowAt(visibleRowIndex))
                    {
                        const uint64_t rowId = model->GetStableRowId(rowIndex.value());
                        record.gridVisibleRows.push_back(rowIndex.value());
                        record.gridVisibleRowIds.push_back(rowId);
                        record.gridRows.push_back(AccessibilityGridRowSnapshotRecord{.rowIndex = rowIndex.value(), .rowId = rowId});
                    }
                }

                record.gridCells.reserve(record.gridVisibleRows.size() * record.gridColumnCount);
                for (size_t rowOrdinal = 0u; rowOrdinal < record.gridVisibleRows.size(); ++rowOrdinal)
                {
                    const size_t rowIndex = record.gridVisibleRows[rowOrdinal];
                    const uint64_t rowId  = record.gridVisibleRowIds[rowOrdinal];
                    for (size_t columnIndex = 0u; columnIndex < record.gridColumnCount; ++columnIndex)
                    {
                        GridCellData cellData{};
                        model->GetCellData(rowIndex, columnIndex, cellData);

                        std::wstring helpText;
                        std::wstring accessibleText = BuildGridCellAccessibleText(cellData);
                        if (! accessibleText.empty() && rowOrdinal < record.gridRows.size())
                        {
                            std::wstring& rowName = record.gridRows[rowOrdinal].gridRowAccessibleName;
                            if (! rowName.empty())
                            {
                                rowName.append(L" | ");
                            }
                            rowName.append(accessibleText);
                        }
                        if (! cellData.tooltipText.empty() && cellData.tooltipText != cellData.text && cellData.tooltipText != accessibleText)
                        {
                            helpText = cellData.tooltipText;
                        }

                        record.gridCells.push_back(
                            AccessibilityGridCellStateSnapshotRecord{.rowIndex                   = rowIndex,
                                                                     .rowId                      = rowId,
                                                                     .columnIndex                = columnIndex,
                                                                     .gridCellControlTypeId      = GetGridCellControlTypeId(cellData),
                                                                     .gridCellAccessibleText     = std::move(accessibleText),
                                                                     .gridCellHelpText           = std::move(helpText),
                                                                     .gridCellEnabled            = cellData.enabled,
                                                                     .gridCellChecked            = cellData.checked,
                                                                     .gridCellSupportsToggle     = GridCellSupportsTogglePattern(cellData),
                                                                     .gridCellSupportsValue      = GridCellSupportsValuePattern(cellData),
                                                                     .gridCellSupportsRangeValue = GridCellSupportsRangeValuePattern(cellData),
                                                                     .gridCellRangeValue         = GetGridCellRangeValue(cellData)});
                    }
                }

                const auto selection = grid->GetSelectionModel().GetOrderedSelection();
                record.selectedGridRowIds.reserve(selection.size());
                std::unordered_set<uint64_t> visibleRowIds(record.gridVisibleRowIds.begin(), record.gridVisibleRowIds.end());
                for (const uint64_t rowId : selection)
                {
                    const std::optional<size_t> selectedRowIndex = model->FindRowByStableId(rowId);
                    if (selectedRowIndex)
                    {
                        record.selectedGridRowIds.push_back(rowId);
                        if (! visibleRowIds.contains(rowId) && materializedOffscreenRowCount < AccessibilityOffscreenSelectedRowMaterializationLimit())
                        {
                            ++materializedOffscreenRowCount;
                            AccessibilityGridRowSnapshotRecord rowRecord{.rowIndex = selectedRowIndex.value(), .rowId = rowId};
                            for (size_t columnIndex = 0u; columnIndex < record.gridColumnCount; ++columnIndex)
                            {
                                GridCellData cellData{};
                                model->GetCellData(selectedRowIndex.value(), columnIndex, cellData);
                                std::wstring accessibleText = BuildGridCellAccessibleText(cellData);
                                if (! accessibleText.empty())
                                {
                                    if (! rowRecord.gridRowAccessibleName.empty())
                                    {
                                        rowRecord.gridRowAccessibleName.append(L" | ");
                                    }
                                    rowRecord.gridRowAccessibleName.append(accessibleText);
                                }
                            }
                            record.gridRows.push_back(std::move(rowRecord));
                        }
                    }
                }
            }
            if (captureGridSnapshotPerf)
            {
                Debug::Perf::Emit(L"dxui.accessibility.grid_snapshot_rebuild_us",
                                  AccessibilityGridSnapshotPerfDetail(),
                                  Debug::Perf::ElapsedUs(gridSnapshotStartedAt),
                                  record.selectedGridRowIds.size(),
                                  materializedOffscreenRowCount,
                                  S_OK);
            }
        }

        record.controlSupportsSelection = record.isTree || record.isGrid;
        record.controlSupportsTable     = record.isGrid && record.gridColumnCount > 0u;
    }

    if (const auto* panel = dynamic_cast<const Panel*>(current))
    {
        const auto children = panel->GetChildren();
        for (size_t index = 0u; index < children.size(); ++index)
        {
            if (! children[index])
            {
                continue;
            }

            ControlPath childPath{};
            if (! TryAppendPathIndex(basePath, index, childPath))
            {
                continue;
            }

            AppendAccessibilitySnapshotNavigation(host, root, children[index].get(), childPath, snapshot);
        }
    }
}

const AccessibilityControlNavigationSnapshot* FindControlNavigationRecord(const AccessibilitySnapshot& snapshot, const ControlPath& path) noexcept
{
    const std::optional<uint32_t> ordinal = snapshot.controlRecordsByPath.Find(
        HashControlPath(path), [&](uint32_t placed) noexcept { return AreControlPathsEqual(snapshot.controlNavigationRecords[placed].path, path); });
    return ordinal ? &snapshot.controlNavigationRecords[ordinal.value()] : nullptr;
}

const AccessibilityControlNavigationSnapshot* ResolveSnapshotControlRecord(const AccessibilitySnapshot& snapshot,
                                                                           AccessibilityFragmentKind kind,
                                                                           const ControlPath& path) noexcept
{
    if (kind == AccessibilityFragmentKind::Control)
    {
        return FindControlNavigationRecord(snapshot, path);
    }
    if (kind == AccessibilityFragmentKind::Root && SnapshotHasCollapsedSemanticRoot(snapshot))
    {
        return FindControlNavigationRecord(snapshot, snapshot.semanticControlOrder.front());
    }
    return nullptr;
}

// What the window's root element answers when UI Automation asks whether it has the keyboard focus, as its provider's
// GetPropertyValue does: true only for a root that stands for its single semantic control while that control is focused.
// It is how UI Automation reports the gain of a window it asked for its focus before (EndWindowHostFocusGainTurn).
[[nodiscard]] bool RootElementHasKeyboardFocus(const AccessibilitySnapshot& snapshot) noexcept
{
    const AccessibilityControlNavigationSnapshot* const record = ResolveSnapshotControlRecord(snapshot, AccessibilityFragmentKind::Root, ControlPath{});
    return record && record->controlVisible && record->controlHasFocus;
}

std::optional<size_t> FindSemanticControlOrderIndex(const AccessibilitySnapshot& snapshot, const ControlPath& path) noexcept
{
    // The order lists the records' paths, so a record's place in it is its ordinal.
    const AccessibilityControlNavigationSnapshot* const record = FindControlNavigationRecord(snapshot, path);
    return record ? std::optional<size_t>(static_cast<size_t>(record - snapshot.controlNavigationRecords.data())) : std::nullopt;
}

bool SnapshotHasCollapsedSemanticRoot(const AccessibilitySnapshot& snapshot) noexcept
{
    return snapshot.hasCollapsedSemanticRoot;
}

bool SnapshotPathIsCollapsedSemanticRoot(const AccessibilitySnapshot& snapshot, const ControlPath& path) noexcept
{
    return SnapshotHasCollapsedSemanticRoot(snapshot) && AreControlPathsEqual(snapshot.semanticControlOrder.front(), path);
}

std::optional<size_t> FindSizeValueIndex(std::span<const size_t> values, size_t value) noexcept
{
    for (size_t index = 0u; index < values.size(); ++index)
    {
        if (values[index] == value)
        {
            return index;
        }
    }

    return std::nullopt;
}

std::optional<size_t> FindU64ValueIndex(std::span<const uint64_t> values, uint64_t value) noexcept
{
    for (size_t index = 0u; index < values.size(); ++index)
    {
        if (values[index] == value)
        {
            return index;
        }
    }

    return std::nullopt;
}

bool SnapshotContainsGridRow(const AccessibilityControlNavigationSnapshot& record, uint64_t rowId) noexcept
{
    return FindU64ValueIndex(record.gridVisibleRowIds, rowId).has_value();
}

const AccessibilityGridRowSnapshotRecord* FindSnapshotGridRowRecord(const AccessibilityControlNavigationSnapshot& record, uint64_t rowId) noexcept
{
    if (! record.isGrid)
    {
        return nullptr;
    }

    for (const AccessibilityGridRowSnapshotRecord& row : record.gridRows)
    {
        if (row.rowId == rowId)
        {
            return &row;
        }
    }

    return nullptr;
}

const AccessibilityTreeItemSnapshotRecord* FindSnapshotTreeItemRecordByVisibleIndex(const AccessibilityControlNavigationSnapshot& record,
                                                                                    size_t treeVisibleIndex) noexcept
{
    if (! record.isTree || treeVisibleIndex >= record.treeItems.size())
    {
        return nullptr;
    }

    const AccessibilityTreeItemSnapshotRecord& item = record.treeItems[treeVisibleIndex];
    return item.visibleIndex == treeVisibleIndex ? &item : nullptr;
}

const AccessibilityTreeItemSnapshotRecord* FindSnapshotTreeItemRecord(const AccessibilityControlNavigationSnapshot& record, uint64_t itemId) noexcept
{
    if (! record.isTree)
    {
        return nullptr;
    }

    const auto item = std::ranges::find(record.treeItems, itemId, &AccessibilityTreeItemSnapshotRecord::itemId);
    return item != record.treeItems.end() ? &*item : nullptr;
}

const AccessibilityGridHeaderSnapshotRecord* FindSnapshotGridHeaderRecord(const AccessibilityControlNavigationSnapshot& record, size_t gridColumnIndex) noexcept
{
    if (! record.isGrid)
    {
        return nullptr;
    }

    for (const AccessibilityGridHeaderSnapshotRecord& header : record.gridHeaders)
    {
        if (header.columnIndex == gridColumnIndex)
        {
            return &header;
        }
    }

    return nullptr;
}

bool SnapshotContainsTreeItem(const AccessibilityControlNavigationSnapshot& record, uint64_t itemId) noexcept
{
    return FindSnapshotTreeItemRecord(record, itemId) != nullptr;
}

bool SnapshotSupportsSelectionProvider(const AccessibilityControlNavigationSnapshot& record) noexcept
{
    return record.isTree || record.isGrid;
}

// The tree's focused (current) item: its selected item, or with multi-select the item the keyboard focus is on.
bool SnapshotTreeItemIsFocused(const AccessibilityControlNavigationSnapshot& record, uint64_t itemId) noexcept
{
    if (! record.selectedTreeVisibleIndex)
    {
        return false;
    }

    const AccessibilityTreeItemSnapshotRecord* focused = FindSnapshotTreeItemRecordByVisibleIndex(record, record.selectedTreeVisibleIndex.value());
    return focused && focused->itemId == itemId;
}

bool SnapshotTreeItemIsSelected(const AccessibilityControlNavigationSnapshot& record, uint64_t itemId) noexcept
{
    return record.treeCanSelectMultiple ? FindU64ValueIndex(record.selectedTreeItemIds, itemId).has_value() : SnapshotTreeItemIsFocused(record, itemId);
}

bool SnapshotGridRowIsSelected(const AccessibilityControlNavigationSnapshot& record, uint64_t rowId) noexcept
{
    return FindU64ValueIndex(record.selectedGridRowIds, rowId).has_value();
}

bool SnapshotSupportsGridSelectionItem(const AccessibilityControlNavigationSnapshot& record, uint64_t rowId) noexcept
{
    // GetSelection can return selected rows beyond the bounded visible/materialized row cache.
    return record.isGrid && (SnapshotContainsGridRow(record, rowId) || SnapshotGridRowIsSelected(record, rowId));
}

// The ids a tree's or grid's Selection pattern reports, in the snapshot's order: a multi-select tree's selected visible items, a
// single-selection tree's selected item while it is a visible row (`single` holds it for the span), a grid's selected rows.
[[nodiscard]] std::span<const uint64_t> SnapshotSelectedIds(const AccessibilityControlNavigationSnapshot& record, uint64_t& single) noexcept
{
    if (record.isGrid)
    {
        return record.selectedGridRowIds;
    }
    if (record.treeCanSelectMultiple)
    {
        return record.selectedTreeItemIds;
    }
    const AccessibilityTreeItemSnapshotRecord* const item =
        record.selectedTreeVisibleIndex ? FindSnapshotTreeItemRecordByVisibleIndex(record, record.selectedTreeVisibleIndex.value()) : nullptr;
    if (! item)
    {
        return {};
    }
    single = item->itemId;
    return std::span<const uint64_t>(&single, 1u);
}

// Membership in one side of a selection change: a scan of a few ids, or a binary search of a sorted copy of many, so that two
// large selections whose rows only moved are compared in O(n log n) with one allocation a side.
class SelectionIdLookup final
{
public:
    explicit SelectionIdLookup(std::span<const uint64_t> ids) : _ids(ids)
    {
        if (ids.size() > kScanLimit)
        {
            _sorted.assign(ids.begin(), ids.end());
            std::ranges::sort(_sorted);
        }
    }

    [[nodiscard]] bool Contains(uint64_t id) const noexcept
    {
        return _sorted.empty() ? std::ranges::find(_ids, id) != _ids.end() : std::ranges::binary_search(_sorted, id);
    }

private:
    static constexpr size_t kScanLimit = 16u;
    std::span<const uint64_t> _ids;
    std::vector<uint64_t> _sorted;
};

std::vector<SelectionChange> CollectSelectionChanges(const AccessibilitySnapshot& before, const AccessibilitySnapshot& after)
{
    std::vector<SelectionChange> changes;
    for (const AccessibilityControlNavigationSnapshot& record : after.controlNavigationRecords)
    {
        if (! record.isTree && ! record.isGrid)
        {
            continue;
        }
        const AccessibilityControlNavigationSnapshot* const previous = FindControlNavigationRecord(before, record.path);
        if (! previous || previous->isTree != record.isTree || previous->isGrid != record.isGrid || previous->controlIdentity != record.controlIdentity)
        {
            continue;
        }
        uint64_t wasSingle                  = 0u;
        uint64_t isSingle                   = 0u;
        const std::span<const uint64_t> was = SnapshotSelectedIds(*previous, wasSingle);
        const std::span<const uint64_t> now = SnapshotSelectedIds(record, isSingle);
        if (std::ranges::equal(was, now))
        {
            continue;
        }

        SelectionChange change;
        change.path            = record.path;
        change.controlIdentity = record.controlIdentity;
        change.itemKind        = record.isGrid ? AccessibilityFragmentKind::GridRow : AccessibilityFragmentKind::TreeItem;
        const auto tooMany     = [&]() noexcept { return change.added.size() + change.removed.size() > kAccessibilityMaxSelectionEvents; };
        // An id has one place in a selection, so the ids added and removed are at least as many as the two sizes differ by: a
        // change too large to name (selecting everything) is known before an id is compared.
        if ((std::max)(was.size(), now.size()) - (std::min)(was.size(), now.size()) > kAccessibilityMaxSelectionEvents)
        {
            change.invalidated = true;
            changes.push_back(std::move(change));
            continue;
        }

        // A gesture adds or removes a few ids and the others keep their places: only the ids between the longest common start
        // and the longest common end of the two can have joined or left.
        size_t start = 0u;
        while (start < was.size() && start < now.size() && was[start] == now[start])
        {
            ++start;
        }
        size_t end = 0u;
        while (start + end < was.size() && start + end < now.size() && was[was.size() - 1u - end] == now[now.size() - 1u - end])
        {
            ++end;
        }
        const std::span<const uint64_t> left   = was.subspan(start, was.size() - start - end);
        const std::span<const uint64_t> joined = now.subspan(start, now.size() - start - end);
        const SelectionIdLookup wasSelected(left);
        const SelectionIdLookup isSelected(joined);
        for (size_t index = 0u; index < joined.size() && ! tooMany(); ++index)
        {
            if (! wasSelected.Contains(joined[index]))
            {
                change.added.push_back(joined[index]);
            }
        }
        change.replaced = now.size() == 1u && change.added.size() == 1u;
        // An item that left the selection is named by its element, which `after` must hold for a client to read it: a tree holds
        // its visible items, a grid the rows on screen (and the selected ones). One it does not hold cannot be named: a tree's
        // item that left the rows (removed, or hidden by a collapsed ancestor), or a grid's row that is out of view or gone. Of
        // a selection that became one new item, the new item's event says that the others left it, so such an item needs no
        // event of its own there.
        for (size_t index = 0u; index < left.size() && ! tooMany() && ! change.invalidated; ++index)
        {
            const uint64_t id = left[index];
            if (isSelected.Contains(id))
            {
                continue;
            }
            if (record.isGrid ? FindSnapshotGridRowRecord(record, id) != nullptr : SnapshotContainsTreeItem(record, id))
            {
                change.removed.push_back(id);
            }
            else if (! change.replaced)
            {
                change.invalidated = true; // There is nothing to say about it but that the selection changed.
            }
        }
        if (change.added.empty() && change.removed.empty() && ! change.invalidated)
        {
            continue; // The same items in another order: the model moved rows.
        }

        if (tooMany())
        {
            change.invalidated = true;
        }
        changes.push_back(std::move(change));
    }
    return changes;
}

std::optional<AccessibilityGridCellSnapshotRecord> FindSnapshotGridCellRecord(const AccessibilitySnapshot& snapshot,
                                                                              const ControlPath& path,
                                                                              uint64_t rowId,
                                                                              size_t columnIndex) noexcept
{
    const AccessibilityControlNavigationSnapshot* record = FindControlNavigationRecord(snapshot, path);
    if (! record || ! record->isGrid || columnIndex >= record->gridColumnCount)
    {
        return std::nullopt;
    }

    const auto it = std::ranges::find_if(record->gridCells, [&](const AccessibilityGridCellStateSnapshotRecord& cell) noexcept {
        return cell.rowId == rowId && cell.columnIndex == columnIndex;
    });
    if (it == record->gridCells.end())
    {
        return std::nullopt;
    }

    return AccessibilityGridCellSnapshotRecord{.controlRecord = record, .cellRecord = &*it, .rowIndex = it->rowIndex, .columnIndex = it->columnIndex};
}

bool SnapshotGridCellSupportsTogglePattern(const AccessibilityGridCellSnapshotRecord& cell) noexcept
{
    return cell.cellRecord && cell.cellRecord->gridCellSupportsToggle;
}

bool SnapshotGridCellSupportsValuePattern(const AccessibilityGridCellSnapshotRecord& cell) noexcept
{
    return cell.cellRecord && cell.cellRecord->gridCellSupportsValue;
}

bool SnapshotGridCellSupportsRangeValuePattern(const AccessibilityGridCellSnapshotRecord& cell) noexcept
{
    return cell.cellRecord && cell.cellRecord->gridCellSupportsRangeValue;
}

enum class AccessibilityPatternKind
{
    Invoke,
    Toggle,
    Value,
    Text,
    TextEdit,
    RangeValue,
    Selection,
    Table,
    SelectionItem,
    ExpandCollapse,
    GridItem,
    TableItem,
};

struct AccessibilityPatternQueryResult
{
    void* queryInterface      = nullptr;
    IUnknown* patternProvider = nullptr;
};

std::optional<AccessibilityPatternKind> PatternKindFromInterfaceId(REFIID riid) noexcept
{
    if (riid == __uuidof(IInvokeProvider))
    {
        return AccessibilityPatternKind::Invoke;
    }
    if (riid == __uuidof(IToggleProvider))
    {
        return AccessibilityPatternKind::Toggle;
    }
    if (riid == __uuidof(IValueProvider))
    {
        return AccessibilityPatternKind::Value;
    }
    if (riid == __uuidof(ITextProvider))
    {
        return AccessibilityPatternKind::Text;
    }
    if (riid == __uuidof(ITextEditProvider))
    {
        return AccessibilityPatternKind::TextEdit;
    }
    if (riid == __uuidof(IRangeValueProvider))
    {
        return AccessibilityPatternKind::RangeValue;
    }
    if (riid == __uuidof(ISelectionProvider))
    {
        return AccessibilityPatternKind::Selection;
    }
    if (riid == __uuidof(ITableProvider))
    {
        return AccessibilityPatternKind::Table;
    }
    if (riid == __uuidof(ISelectionItemProvider))
    {
        return AccessibilityPatternKind::SelectionItem;
    }
    if (riid == __uuidof(IExpandCollapseProvider))
    {
        return AccessibilityPatternKind::ExpandCollapse;
    }
    if (riid == __uuidof(IGridItemProvider))
    {
        return AccessibilityPatternKind::GridItem;
    }
    if (riid == __uuidof(ITableItemProvider))
    {
        return AccessibilityPatternKind::TableItem;
    }
    return std::nullopt;
}

std::optional<AccessibilityPatternKind> PatternKindFromPatternId(PATTERNID patternId) noexcept
{
    switch (patternId)
    {
        case UIA_InvokePatternId: return AccessibilityPatternKind::Invoke;
        case UIA_TogglePatternId: return AccessibilityPatternKind::Toggle;
        case UIA_ValuePatternId: return AccessibilityPatternKind::Value;
        case UIA_TextPatternId: return AccessibilityPatternKind::Text;
        case UIA_TextEditPatternId: return AccessibilityPatternKind::TextEdit;
        case UIA_RangeValuePatternId: return AccessibilityPatternKind::RangeValue;
        case UIA_SelectionPatternId: return AccessibilityPatternKind::Selection;
        case UIA_TablePatternId: return AccessibilityPatternKind::Table;
        case UIA_SelectionItemPatternId: return AccessibilityPatternKind::SelectionItem;
        case UIA_ExpandCollapsePatternId: return AccessibilityPatternKind::ExpandCollapse;
        case UIA_GridItemPatternId: return AccessibilityPatternKind::GridItem;
        case UIA_TableItemPatternId: return AccessibilityPatternKind::TableItem;
        default: return std::nullopt;
    }
}

AccessibilityNavigationTarget MakeControlNavigationTarget(const ControlPath& path) noexcept
{
    AccessibilityNavigationTarget target{};
    target.kind = AccessibilityFragmentKind::Control;
    target.path = path;
    return target;
}

AccessibilityNavigationTarget MakeNavigationTarget(
    AccessibilityFragmentKind kind, const ControlPath& path, uint64_t treeItemId = 0u, uint64_t gridRowId = 0u, size_t gridColumnIndex = 0u) noexcept
{
    AccessibilityNavigationTarget target{};
    target.kind            = kind;
    target.path            = path;
    target.treeItemId      = treeItemId;
    target.gridRowId       = gridRowId;
    target.gridColumnIndex = gridColumnIndex;
    return target;
}

// The first and the last of the fragments a control exposes of its own, which are the children of its element: a tree's items, a
// grid's headers and then its rows, a text field's reveal button. A control with none has no children of its own.
std::optional<AccessibilityNavigationTarget> FirstControlFragmentTarget(const AccessibilityControlNavigationSnapshot& controlRecord) noexcept
{
    if (! controlRecord.treeItems.empty())
    {
        return MakeNavigationTarget(AccessibilityFragmentKind::TreeItem, controlRecord.path, controlRecord.treeItems.front().itemId);
    }
    if (! controlRecord.gridVisibleColumns.empty())
    {
        return MakeNavigationTarget(AccessibilityFragmentKind::GridHeader, controlRecord.path, 0u, 0u, controlRecord.gridVisibleColumns.front());
    }
    if (! controlRecord.gridVisibleRowIds.empty())
    {
        return MakeNavigationTarget(AccessibilityFragmentKind::GridRow, controlRecord.path, 0u, controlRecord.gridVisibleRowIds.front());
    }
    if (controlRecord.hasPasswordRevealButton)
    {
        return MakeNavigationTarget(AccessibilityFragmentKind::TextFieldPasswordRevealButton, controlRecord.path);
    }
    return std::nullopt;
}

std::optional<AccessibilityNavigationTarget> LastControlFragmentTarget(const AccessibilityControlNavigationSnapshot& controlRecord) noexcept
{
    if (! controlRecord.treeItems.empty())
    {
        return MakeNavigationTarget(AccessibilityFragmentKind::TreeItem, controlRecord.path, controlRecord.treeItems.back().itemId);
    }
    if (! controlRecord.gridVisibleRowIds.empty())
    {
        return MakeNavigationTarget(AccessibilityFragmentKind::GridRow, controlRecord.path, 0u, controlRecord.gridVisibleRowIds.back());
    }
    if (! controlRecord.gridVisibleColumns.empty())
    {
        return MakeNavigationTarget(AccessibilityFragmentKind::GridHeader, controlRecord.path, 0u, 0u, controlRecord.gridVisibleColumns.back());
    }
    if (controlRecord.hasPasswordRevealButton)
    {
        return MakeNavigationTarget(AccessibilityFragmentKind::TextFieldPasswordRevealButton, controlRecord.path);
    }
    return std::nullopt;
}

std::optional<AccessibilityNavigationTarget> ResolveSnapshotNavigationTarget(const AccessibilitySnapshot& snapshot,
                                                                             AccessibilityFragmentKind kind,
                                                                             const ControlPath& path,
                                                                             uint64_t treeItemId,
                                                                             uint64_t gridRowId,
                                                                             size_t gridColumnIndex,
                                                                             NavigateDirection direction) noexcept
{
    const AccessibilityControlNavigationSnapshot* controlRecord = FindControlNavigationRecord(snapshot, path);
    const AccessibilityTreeItemSnapshotRecord* treeItem =
        kind == AccessibilityFragmentKind::TreeItem && controlRecord ? FindSnapshotTreeItemRecord(*controlRecord, treeItemId) : nullptr;
    switch (direction)
    {
        case NavigateDirection_FirstChild:
            if (kind == AccessibilityFragmentKind::Root)
            {
                if (SnapshotHasCollapsedSemanticRoot(snapshot))
                {
                    if (snapshot.semanticControlOrder.size() > 1u)
                    {
                        return MakeControlNavigationTarget(snapshot.semanticControlOrder[1u]);
                    }
                    // The root stands for its only control, whose own fragments (a tree's items, a grid's headers and rows, a
                    // field's reveal button) are therefore the root's children. A control that has other semantic controls below
                    // it (a status root) is a panel, which has no fragments of its own, so the two never both apply.
                    const AccessibilityControlNavigationSnapshot* const collapsed = ResolveSnapshotControlRecord(snapshot, kind, path);
                    return collapsed ? FirstControlFragmentTarget(*collapsed) : std::nullopt;
                }
                if (! snapshot.semanticControlOrder.empty())
                {
                    return MakeControlNavigationTarget(snapshot.semanticControlOrder.front());
                }
                return std::nullopt;
            }
            if (kind == AccessibilityFragmentKind::Control && controlRecord)
            {
                return FirstControlFragmentTarget(*controlRecord);
            }
            if (kind == AccessibilityFragmentKind::GridRow && controlRecord && SnapshotContainsGridRow(*controlRecord, gridRowId) &&
                controlRecord->gridColumnCount > 0u)
            {
                return MakeNavigationTarget(AccessibilityFragmentKind::GridCell, path, 0u, gridRowId, 0u);
            }
            return std::nullopt;
        case NavigateDirection_LastChild:
            if (kind == AccessibilityFragmentKind::Root)
            {
                if (SnapshotHasCollapsedSemanticRoot(snapshot))
                {
                    if (snapshot.semanticControlOrder.size() > 1u)
                    {
                        return MakeControlNavigationTarget(snapshot.semanticControlOrder.back());
                    }
                    const AccessibilityControlNavigationSnapshot* const collapsed = ResolveSnapshotControlRecord(snapshot, kind, path);
                    return collapsed ? LastControlFragmentTarget(*collapsed) : std::nullopt;
                }
                if (! snapshot.semanticControlOrder.empty())
                {
                    return MakeControlNavigationTarget(snapshot.semanticControlOrder.back());
                }
                return std::nullopt;
            }
            if (kind == AccessibilityFragmentKind::Control && controlRecord)
            {
                return LastControlFragmentTarget(*controlRecord);
            }
            if (kind == AccessibilityFragmentKind::GridRow && controlRecord && SnapshotContainsGridRow(*controlRecord, gridRowId) &&
                controlRecord->gridColumnCount > 0u)
            {
                return MakeNavigationTarget(AccessibilityFragmentKind::GridCell, path, 0u, gridRowId, controlRecord->gridColumnCount - 1u);
            }
            return std::nullopt;
        case NavigateDirection_Parent:
            if (kind == AccessibilityFragmentKind::Control)
            {
                if (SnapshotPathIsCollapsedSemanticRoot(snapshot, path))
                {
                    return std::nullopt;
                }
                return MakeNavigationTarget(AccessibilityFragmentKind::Root, ControlPath{});
            }
            if (kind == AccessibilityFragmentKind::GridCell)
            {
                return MakeNavigationTarget(AccessibilityFragmentKind::GridRow, path, 0u, gridRowId);
            }
            if (kind == AccessibilityFragmentKind::TreeItem || kind == AccessibilityFragmentKind::GridHeader || kind == AccessibilityFragmentKind::GridRow ||
                kind == AccessibilityFragmentKind::TextFieldPasswordRevealButton)
            {
                return MakeControlNavigationTarget(path);
            }
            return std::nullopt;
        case NavigateDirection_NextSibling:
            if (kind == AccessibilityFragmentKind::Control)
            {
                if (SnapshotPathIsCollapsedSemanticRoot(snapshot, path))
                {
                    return std::nullopt;
                }
                const std::optional<size_t> ordinal = FindSemanticControlOrderIndex(snapshot, path);
                if (ordinal && (ordinal.value() + 1u) < snapshot.semanticControlOrder.size())
                {
                    return MakeControlNavigationTarget(snapshot.semanticControlOrder[ordinal.value() + 1u]);
                }
            }
            else if (treeItem && (treeItem->visibleIndex + 1u) < controlRecord->treeItems.size())
            {
                return MakeNavigationTarget(AccessibilityFragmentKind::TreeItem, path, controlRecord->treeItems[treeItem->visibleIndex + 1u].itemId);
            }
            else if (kind == AccessibilityFragmentKind::GridHeader && controlRecord)
            {
                const std::optional<size_t> ordinal = FindSizeValueIndex(controlRecord->gridVisibleColumns, gridColumnIndex);
                if (ordinal && (ordinal.value() + 1u) < controlRecord->gridVisibleColumns.size())
                {
                    return MakeNavigationTarget(AccessibilityFragmentKind::GridHeader, path, 0u, 0u, controlRecord->gridVisibleColumns[ordinal.value() + 1u]);
                }
                if (ordinal && ! controlRecord->gridVisibleRowIds.empty())
                {
                    return MakeNavigationTarget(AccessibilityFragmentKind::GridRow, path, 0u, controlRecord->gridVisibleRowIds.front());
                }
            }
            else if (kind == AccessibilityFragmentKind::GridRow && controlRecord)
            {
                const std::optional<size_t> ordinal = FindU64ValueIndex(controlRecord->gridVisibleRowIds, gridRowId);
                if (ordinal && (ordinal.value() + 1u) < controlRecord->gridVisibleRowIds.size())
                {
                    return MakeNavigationTarget(AccessibilityFragmentKind::GridRow, path, 0u, controlRecord->gridVisibleRowIds[ordinal.value() + 1u]);
                }
            }
            else if (kind == AccessibilityFragmentKind::GridCell && controlRecord && SnapshotContainsGridRow(*controlRecord, gridRowId))
            {
                if ((gridColumnIndex + 1u) < controlRecord->gridColumnCount)
                {
                    return MakeNavigationTarget(AccessibilityFragmentKind::GridCell, path, 0u, gridRowId, gridColumnIndex + 1u);
                }
            }
            return std::nullopt;
        case NavigateDirection_PreviousSibling:
            if (kind == AccessibilityFragmentKind::Control)
            {
                if (SnapshotPathIsCollapsedSemanticRoot(snapshot, path))
                {
                    return std::nullopt;
                }
                const std::optional<size_t> ordinal = FindSemanticControlOrderIndex(snapshot, path);
                const size_t firstSiblingOrdinal    = SnapshotHasCollapsedSemanticRoot(snapshot) ? 1u : 0u;
                if (ordinal && ordinal.value() > firstSiblingOrdinal)
                {
                    return MakeControlNavigationTarget(snapshot.semanticControlOrder[ordinal.value() - 1u]);
                }
            }
            else if (treeItem && treeItem->visibleIndex > 0u)
            {
                return MakeNavigationTarget(AccessibilityFragmentKind::TreeItem, path, controlRecord->treeItems[treeItem->visibleIndex - 1u].itemId);
            }
            else if (kind == AccessibilityFragmentKind::GridHeader && controlRecord)
            {
                const std::optional<size_t> ordinal = FindSizeValueIndex(controlRecord->gridVisibleColumns, gridColumnIndex);
                if (ordinal && ordinal.value() > 0u)
                {
                    return MakeNavigationTarget(AccessibilityFragmentKind::GridHeader, path, 0u, 0u, controlRecord->gridVisibleColumns[ordinal.value() - 1u]);
                }
            }
            else if (kind == AccessibilityFragmentKind::GridRow && controlRecord)
            {
                const std::optional<size_t> ordinal = FindU64ValueIndex(controlRecord->gridVisibleRowIds, gridRowId);
                if (ordinal && ordinal.value() > 0u)
                {
                    return MakeNavigationTarget(AccessibilityFragmentKind::GridRow, path, 0u, controlRecord->gridVisibleRowIds[ordinal.value() - 1u]);
                }
                if (ordinal && ! controlRecord->gridVisibleColumns.empty())
                {
                    return MakeNavigationTarget(AccessibilityFragmentKind::GridHeader, path, 0u, 0u, controlRecord->gridVisibleColumns.back());
                }
            }
            else if (kind == AccessibilityFragmentKind::GridCell && controlRecord && SnapshotContainsGridRow(*controlRecord, gridRowId))
            {
                if (gridColumnIndex > 0u && gridColumnIndex < controlRecord->gridColumnCount)
                {
                    return MakeNavigationTarget(AccessibilityFragmentKind::GridCell, path, 0u, gridRowId, gridColumnIndex - 1u);
                }
            }
            return std::nullopt;
        default: return std::nullopt;
    }
}

[[nodiscard]] std::wstring_view FindAssociatedLabelText(const Control* root, const Control* target, uint32_t depth = 0u) noexcept
{
    if (! root || ! target || depth >= kAccessibilityMaxDepth)
    {
        return {};
    }

    if (const auto* label = dynamic_cast<const Label*>(root))
    {
        if (label->GetMnemonicTarget() == target)
        {
            return label->GetText();
        }
    }

    if (const auto* panel = dynamic_cast<const Panel*>(root))
    {
        const auto children = panel->GetChildren();
        for (const auto& child : children)
        {
            if (! child)
            {
                continue;
            }

            if (const std::wstring_view text = FindAssociatedLabelText(child.get(), target, depth + 1u); ! text.empty())
            {
                return text;
            }
        }
    }

    return {};
}

[[nodiscard]] std::wstring_view GetControlAccessibleName(const Control* root, const Control* control) noexcept
{
    if (! control)
    {
        return {};
    }

    if (const std::wstring_view explicitName = control->GetAccessibleName(); ! explicitName.empty())
    {
        return explicitName;
    }

    if (const auto* toggle = dynamic_cast<const Toggle*>(control))
    {
        if (const std::wstring_view labelText = FindAssociatedLabelText(root, toggle); ! labelText.empty())
        {
            return labelText;
        }
        return toggle->GetDisplayedText();
    }
    if (const auto* button = dynamic_cast<const Button*>(control))
    {
        return button->GetText();
    }
    if (const auto* label = dynamic_cast<const Label*>(control))
    {
        return label->GetText();
    }
    if (const auto* textField = dynamic_cast<const TextField*>(control))
    {
        if (const std::wstring_view labelText = FindAssociatedLabelText(root, textField); ! labelText.empty())
        {
            return labelText;
        }
        if (textField->IsMasked())
        {
            return {};
        }
        return textField->GetText();
    }
    if (const auto* comboBox = dynamic_cast<const ComboBox*>(control))
    {
        if (const std::wstring_view labelText = FindAssociatedLabelText(root, comboBox); ! labelText.empty())
        {
            return labelText;
        }
        return comboBox->GetDisplayedText();
    }
    if (const auto* slider = dynamic_cast<const Slider*>(control))
    {
        if (const std::wstring_view labelText = FindAssociatedLabelText(root, slider); ! labelText.empty())
        {
            return labelText;
        }
    }

    return FindAssociatedLabelText(root, control);
}

[[nodiscard]] std::wstring_view GetControlAccessibleValue(const Control* control) noexcept
{
    if (const auto* textField = dynamic_cast<const TextField*>(control))
    {
        if (textField->IsMasked())
        {
            return {};
        }
        return textField->GetText();
    }
    if (const auto* comboBox = dynamic_cast<const ComboBox*>(control))
    {
        return comboBox->GetDisplayedText();
    }
    return {};
}

[[nodiscard]] bool SupportsTextPattern(const Control* control) noexcept
{
    if (const auto* textField = dynamic_cast<const TextField*>(control))
    {
        return ! textField->IsMasked();
    }
    if (const auto* comboBox = dynamic_cast<const ComboBox*>(control))
    {
        return comboBox->IsEditable();
    }
    return false;
}

[[nodiscard]] std::wstring GetControlAccessibleTextRangeText(const Control* control)
{
    if (const auto* textField = dynamic_cast<const TextField*>(control))
    {
        if (textField->IsMasked())
        {
            return {};
        }
        return std::wstring(textField->GetText());
    }
    if (const auto* comboBox = dynamic_cast<const ComboBox*>(control))
    {
        if (! comboBox->IsEditable())
        {
            return {};
        }
        return std::wstring(comboBox->GetText());
    }
    return {};
}

[[nodiscard]] D2D1_RECT_F ResolveTextPatternViewportRect(const Control* control) noexcept
{
    if (! control)
    {
        return D2D1::RectF();
    }
    if (const std::optional<D2D1_RECT_F> viewport = control->TryGetTextInputViewportRect(); viewport.has_value())
    {
        return viewport.value();
    }
    return control->GetHitBounds();
}

[[nodiscard]] bool IsSimpleTextRangeCaretGeometrySupported(const Control& control, std::wstring_view text) noexcept
{
    const DWRITE_READING_DIRECTION readingDirection = ResolveReadingDirection(control.GetFlowDirection());
    return ! ShouldEmitSingleLineBiDiTextMetric(text, readingDirection);
}

[[nodiscard]] bool TextRangeContainsLineBreak(std::wstring_view text, const TextRangeSpan& range) noexcept
{
    const size_t start = (std::min)(range.start, text.size());
    const size_t end   = (std::min)(range.end, text.size());
    return text.substr(start, end - start).find_first_of(L"\r\n") != std::wstring_view::npos;
}

[[nodiscard]] size_t FindNextLineBreak(std::wstring_view text, size_t start, size_t end) noexcept
{
    const size_t clampedStart = (std::min)(start, text.size());
    const size_t clampedEnd   = (std::min)(end, text.size());
    const size_t breakIndex   = text.substr(clampedStart, clampedEnd - clampedStart).find_first_of(L"\r\n");
    return breakIndex == std::wstring_view::npos ? clampedEnd : clampedStart + breakIndex;
}

[[nodiscard]] size_t AdvancePastLineBreak(std::wstring_view text, size_t index, size_t end) noexcept
{
    const size_t clampedIndex = (std::min)(index, text.size());
    const size_t clampedEnd   = (std::min)(end, text.size());
    if (clampedIndex >= clampedEnd)
    {
        return clampedIndex;
    }
    if (text[clampedIndex] == L'\r' && clampedIndex + 1u < clampedEnd && text[clampedIndex + 1u] == L'\n')
    {
        return clampedIndex + 2u;
    }
    return clampedIndex + 1u;
}

[[nodiscard]] bool CaretRectsShareVisualLine(const D2D1_RECT_F& first, const D2D1_RECT_F& second) noexcept
{
    constexpr float kLineToleranceDip = 1.0f;
    return std::fabs(first.top - second.top) <= kLineToleranceDip && std::fabs(first.bottom - second.bottom) <= kLineToleranceDip;
}

[[nodiscard]] D2D1_RECT_F ClipRectToBounds(D2D1_RECT_F rect, const D2D1_RECT_F& bounds) noexcept
{
    rect.left   = std::clamp(rect.left, bounds.left, bounds.right);
    rect.right  = std::clamp(rect.right, rect.left, bounds.right);
    rect.top    = std::clamp(rect.top, bounds.top, bounds.bottom);
    rect.bottom = std::clamp(rect.bottom, rect.top, bounds.bottom);
    if (rect.right <= rect.left)
    {
        rect.right = (std::min)(bounds.right, rect.left + 1.0f);
    }
    if (rect.bottom <= rect.top)
    {
        rect.bottom = (std::min)(bounds.bottom, rect.top + 1.0f);
    }
    return rect;
}

[[nodiscard]] std::optional<D2D1_RECT_F> TryResolveSimpleTextRangeCaretRect(const ControlHost& host,
                                                                            const Control& control,
                                                                            std::wstring_view text,
                                                                            const TextRangeSpan& range) noexcept
{
    if (range.start == range.end || ! IsSimpleTextRangeCaretGeometrySupported(control, text) || TextRangeContainsLineBreak(text, range))
    {
        return std::nullopt;
    }

    const std::optional<D2D1_RECT_F> startRect = control.TryGetTextInputCaretRect(host, range.start);
    const std::optional<D2D1_RECT_F> endRect   = control.TryGetTextInputCaretRect(host, range.end);
    if (! startRect.has_value() || ! endRect.has_value())
    {
        return std::nullopt;
    }
    if (! CaretRectsShareVisualLine(startRect.value(), endRect.value()))
    {
        return std::nullopt;
    }

    const D2D1_RECT_F viewport = ResolveTextPatternViewportRect(&control);
    const D2D1_RECT_F rect     = D2D1::RectF((std::min)(startRect->left, endRect->left),
                                             (std::min)(startRect->top, endRect->top),
                                             (std::max)(startRect->right, endRect->right),
                                             (std::max)(startRect->bottom, endRect->bottom));
    return ClipRectToBounds(rect, viewport);
}

[[nodiscard]] std::optional<std::vector<D2D1_RECT_F>> TryResolveTextRangeCaretRects(const ControlHost& host,
                                                                                    const Control& control,
                                                                                    std::wstring_view text,
                                                                                    const TextRangeSpan& range)
{
    if (range.start == range.end)
    {
        return std::nullopt;
    }

    if (! IsSimpleTextRangeCaretGeometrySupported(control, text))
    {
        if (std::optional<std::vector<D2D1_RECT_F>> rects = control.TryGetTextInputRangeRects(host, range.start, range.end);
            rects.has_value() && ! rects->empty())
        {
            return rects;
        }
        return std::nullopt;
    }

    if (! TextRangeContainsLineBreak(text, range))
    {
        if (std::optional<D2D1_RECT_F> rect = TryResolveSimpleTextRangeCaretRect(host, control, text, range); rect.has_value())
        {
            return std::vector<D2D1_RECT_F>{rect.value()};
        }
        if (std::optional<std::vector<D2D1_RECT_F>> rects = control.TryGetTextInputRangeRects(host, range.start, range.end);
            rects.has_value() && ! rects->empty())
        {
            return rects;
        }
        return std::nullopt;
    }

    const D2D1_RECT_F viewport = ResolveTextPatternViewportRect(&control);
    std::vector<D2D1_RECT_F> rects;
    size_t segmentStart   = (std::min)(range.start, text.size());
    const size_t rangeEnd = (std::min)(range.end, text.size());
    while (segmentStart < rangeEnd)
    {
        const size_t segmentEnd = FindNextLineBreak(text, segmentStart, rangeEnd);
        if (segmentStart < segmentEnd)
        {
            const std::optional<D2D1_RECT_F> startRect = control.TryGetTextInputCaretRect(host, segmentStart);
            const std::optional<D2D1_RECT_F> endRect   = control.TryGetTextInputCaretRect(host, segmentEnd);
            if (! startRect.has_value() || ! endRect.has_value())
            {
                return std::nullopt;
            }

            if (CaretRectsShareVisualLine(startRect.value(), endRect.value()))
            {
                const D2D1_RECT_F rect = D2D1::RectF((std::min)(startRect->left, endRect->left),
                                                     (std::min)(startRect->top, endRect->top),
                                                     (std::max)(startRect->right, endRect->right),
                                                     (std::max)(startRect->bottom, endRect->bottom));
                rects.push_back(ClipRectToBounds(rect, viewport));
            }
            else if (std::optional<std::vector<D2D1_RECT_F>> segmentRects = control.TryGetTextInputRangeRects(host, segmentStart, segmentEnd);
                     segmentRects.has_value() && ! segmentRects->empty())
            {
                rects.insert(rects.end(), segmentRects->begin(), segmentRects->end());
            }
            else
            {
                return std::nullopt;
            }
        }

        if (segmentEnd >= rangeEnd)
        {
            break;
        }
        segmentStart = AdvancePastLineBreak(text, segmentEnd, rangeEnd);
    }

    if (rects.empty())
    {
        return std::nullopt;
    }
    return rects;
}

[[nodiscard]] size_t GetTextRangeEndpointPosition(const TextRangeSpan& range, TextPatternRangeEndpoint endpoint) noexcept
{
    return endpoint == TextPatternRangeEndpoint_Start ? range.start : range.end;
}

[[nodiscard]] TextRangeUnitMoveResult MoveTextRangePositionByUnit(std::wstring_view text, size_t position, TextUnit unit, int count) noexcept
{
    const size_t clampedPosition = std::min(position, text.size());
    if (count == 0)
    {
        return TextRangeUnitMoveResult{clampedPosition, 0};
    }

    if (unit == TextUnit_Character)
    {
        size_t cursor = SnapCaretIndexToTextElementBoundary(text, clampedPosition);
        int moved     = 0;
        if (count > 0)
        {
            while (moved < count)
            {
                const size_t next = StepToNextTextElement(text, cursor);
                if (next == cursor)
                {
                    break;
                }

                cursor = next;
                ++moved;
            }
        }
        else
        {
            while (moved > count)
            {
                const size_t previous = StepToPreviousTextElement(text, cursor);
                if (previous == cursor)
                {
                    break;
                }

                cursor = previous;
                --moved;
            }
        }

        return TextRangeUnitMoveResult{cursor, moved};
    }

    if (unit != TextUnit_Word)
    {
        return TextRangeUnitMoveResult{clampedPosition, 0};
    }

    size_t cursor = clampedPosition;
    int moved     = 0;
    if (count > 0)
    {
        while (moved < count)
        {
            const size_t next = FindNextWordBoundary(text, cursor);
            if (next == cursor)
            {
                break;
            }

            cursor = next;
            ++moved;
        }
    }
    else
    {
        while (moved > count)
        {
            const size_t previous = FindPreviousWordBoundary(text, cursor);
            if (previous == cursor)
            {
                break;
            }

            cursor = previous;
            --moved;
        }
    }

    return TextRangeUnitMoveResult{cursor, moved};
}

[[nodiscard]] TextRangeSpan ClampTextRangeSpan(size_t start, size_t end, size_t textLength) noexcept
{
    start = (std::min)(start, textLength);
    end   = (std::min)(end, textLength);
    if (start > end)
    {
        std::swap(start, end);
    }
    return TextRangeSpan{start, end};
}

[[nodiscard]] bool IsAccessibilityTextRangeWhitespace(wchar_t value) noexcept
{
    WORD charType = 0u;
    return GetStringTypeW(CT_CTYPE1, &value, 1, &charType) && ((charType & C1_SPACE) != 0u);
}

[[nodiscard]] size_t TrimTrailingTextRangeWhitespace(std::wstring_view text, size_t start, size_t end) noexcept
{
    start = (std::min)(start, text.size());
    end   = (std::min)(end, text.size());
    while (end > start)
    {
        const size_t previous = StepToPreviousCodePoint(text, end);
        if (! IsAccessibilityTextRangeWhitespace(text[previous]))
        {
            break;
        }

        end = previous;
    }

    return end;
}

[[nodiscard]] TextRangeSpan GetTextRangeWordSpanAtPosition(std::wstring_view text, size_t position) noexcept
{
    const size_t start = (std::min)(position, text.size());
    if (start >= text.size())
    {
        return TextRangeSpan{text.size(), text.size()};
    }

    const TextRangeUnitMoveResult endBoundary = MoveTextRangePositionByUnit(text, start, TextUnit_Word, 1);
    const size_t end                          = TrimTrailingTextRangeWhitespace(text, start, endBoundary.position);
    return TextRangeSpan{start, end};
}

[[nodiscard]] TextRangeSpan GetEnclosingTextRangeCharacterSpan(std::wstring_view text, size_t position) noexcept
{
    if (text.empty())
    {
        return {};
    }

    size_t start = (std::min)(position, text.size());
    if (start == text.size())
    {
        start = StepToPreviousTextElement(text, start);
    }
    else
    {
        const size_t snapped = SnapCaretIndexToTextElementBoundary(text, start);
        start                = snapped > start ? StepToPreviousTextElement(text, snapped) : snapped;
    }
    return TextRangeSpan{start, StepToNextTextElement(text, start)};
}

[[nodiscard]] TextRangeSpan GetEnclosingTextRangeWordSpan(std::wstring_view text, size_t position) noexcept
{
    if (text.empty())
    {
        return {};
    }

    const size_t clampedPosition = (std::min)(position, text.size());
    size_t unitStart             = 0u;
    while (unitStart < text.size())
    {
        const TextRangeUnitMoveResult next = MoveTextRangePositionByUnit(text, unitStart, TextUnit_Word, 1);
        if (next.position <= unitStart)
        {
            return GetEnclosingTextRangeCharacterSpan(text, clampedPosition);
        }
        if (clampedPosition < next.position || clampedPosition == unitStart)
        {
            const size_t unitEnd = TrimTrailingTextRangeWhitespace(text, unitStart, next.position);
            return TextRangeSpan{unitStart, (std::max)(unitStart, unitEnd)};
        }
        unitStart = next.position;
    }

    const size_t lastUnitStart = FindPreviousWordBoundary(text, text.size());
    return TextRangeSpan{lastUnitStart, TrimTrailingTextRangeWhitespace(text, lastUnitStart, text.size())};
}

struct TextRangeSpanMoveResult
{
    TextRangeSpan range{};
    int moved = 0;
};

[[nodiscard]] TextRangeSpanMoveResult MoveTextRangeSpanByWord(std::wstring_view text, const TextRangeSpan& range, int count) noexcept
{
    const TextRangeSpan clampedRange = ClampTextRangeSpan(range.start, range.end, text.size());
    if (count == 0)
    {
        return TextRangeSpanMoveResult{clampedRange, 0};
    }

    size_t cursor = clampedRange.start;
    int moved     = 0;
    if (count > 0)
    {
        while (moved < count)
        {
            const TextRangeUnitMoveResult moveResult = MoveTextRangePositionByUnit(text, cursor, TextUnit_Word, 1);
            if (moveResult.position == cursor || moveResult.moved == 0)
            {
                break;
            }

            cursor = moveResult.position;
            ++moved;
        }
    }
    else
    {
        while (moved > count)
        {
            const TextRangeUnitMoveResult moveResult = MoveTextRangePositionByUnit(text, cursor, TextUnit_Word, -1);
            if (moveResult.position == cursor || moveResult.moved == 0)
            {
                break;
            }

            cursor = moveResult.position;
            --moved;
        }
    }

    if (moved == 0)
    {
        return TextRangeSpanMoveResult{clampedRange, 0};
    }

    return TextRangeSpanMoveResult{GetTextRangeWordSpanAtPosition(text, cursor), moved};
}

[[nodiscard]] bool IsAccessibilityTextRangeLineBreak(wchar_t value) noexcept
{
    return value == L'\r' || value == L'\n';
}

[[nodiscard]] size_t GetTextRangeLineStart(std::wstring_view text, size_t position) noexcept
{
    size_t cursor = (std::min)(position, text.size());
    while (cursor > 0u)
    {
        const size_t previous = StepToPreviousCodePoint(text, cursor);
        if (IsAccessibilityTextRangeLineBreak(text[previous]))
        {
            return cursor;
        }

        cursor = previous;
    }

    return 0u;
}

[[nodiscard]] size_t GetTextRangeLineEnd(std::wstring_view text, size_t lineStart) noexcept
{
    size_t cursor = (std::min)(lineStart, text.size());
    while (cursor < text.size() && ! IsAccessibilityTextRangeLineBreak(text[cursor]))
    {
        cursor = StepToNextCodePoint(text, cursor);
    }

    return cursor;
}

[[nodiscard]] size_t AdvancePastTextRangeLineBreak(std::wstring_view text, size_t position) noexcept
{
    position = (std::min)(position, text.size());
    if (position >= text.size())
    {
        return text.size();
    }

    if (text[position] == L'\r')
    {
        const size_t afterCarriageReturn = StepToNextCodePoint(text, position);
        if (afterCarriageReturn < text.size() && text[afterCarriageReturn] == L'\n')
        {
            return StepToNextCodePoint(text, afterCarriageReturn);
        }

        return afterCarriageReturn;
    }

    if (text[position] == L'\n')
    {
        return StepToNextCodePoint(text, position);
    }

    return position;
}

[[nodiscard]] TextRangeSpan GetTextRangeLineSpanAtPosition(std::wstring_view text, size_t position) noexcept
{
    const size_t lineStart = GetTextRangeLineStart(text, position);
    return TextRangeSpan{lineStart, GetTextRangeLineEnd(text, lineStart)};
}

[[nodiscard]] size_t GetPreviousTextRangeLineStart(std::wstring_view text, size_t lineStart) noexcept
{
    lineStart = (std::min)(lineStart, text.size());
    if (lineStart == 0u)
    {
        return 0u;
    }

    size_t previousLineEnd = StepToPreviousCodePoint(text, lineStart);
    if (text[previousLineEnd] == L'\n' && previousLineEnd > 0u)
    {
        const size_t beforeLineFeed = StepToPreviousCodePoint(text, previousLineEnd);
        if (text[beforeLineFeed] == L'\r')
        {
            previousLineEnd = beforeLineFeed;
        }
    }

    return GetTextRangeLineStart(text, previousLineEnd);
}

[[nodiscard]] TextRangeSpanMoveResult MoveTextRangeSpanByLine(std::wstring_view text, const TextRangeSpan& range, int count) noexcept
{
    const TextRangeSpan clampedRange = ClampTextRangeSpan(range.start, range.end, text.size());
    if (count == 0)
    {
        return TextRangeSpanMoveResult{clampedRange, 0};
    }

    size_t cursor = GetTextRangeLineStart(text, clampedRange.start);
    int moved     = 0;
    if (count > 0)
    {
        while (moved < count)
        {
            const size_t lineEnd = GetTextRangeLineEnd(text, cursor);
            if (lineEnd >= text.size())
            {
                break;
            }

            const size_t nextLineStart = AdvancePastTextRangeLineBreak(text, lineEnd);
            if (nextLineStart == cursor)
            {
                break;
            }

            cursor = nextLineStart;
            ++moved;
        }
    }
    else
    {
        while (moved > count)
        {
            const size_t previousLineStart = GetPreviousTextRangeLineStart(text, cursor);
            if (previousLineStart == cursor)
            {
                break;
            }

            cursor = previousLineStart;
            --moved;
        }
    }

    if (moved == 0)
    {
        return TextRangeSpanMoveResult{clampedRange, 0};
    }

    return TextRangeSpanMoveResult{GetTextRangeLineSpanAtPosition(text, cursor), moved};
}

[[nodiscard]] std::optional<std::vector<TextRangeSpan>> TryResolveTextRangeVisualLineSpans(const ControlHost& host,
                                                                                           const Control& control,
                                                                                           std::wstring_view text) noexcept
{
    if (text.empty() || ! IsSimpleTextRangeCaretGeometrySupported(control, text))
    {
        return std::nullopt;
    }

    std::vector<TextRangeSpan> spans;
    size_t logicalLineCount = 0u;
    size_t logicalLineStart = 0u;
    while (logicalLineStart <= text.size())
    {
        ++logicalLineCount;
        const size_t logicalLineEnd = GetTextRangeLineEnd(text, logicalLineStart);
        if (logicalLineStart == logicalLineEnd)
        {
            spans.push_back(TextRangeSpan{logicalLineStart, logicalLineEnd});
        }
        else
        {
            size_t visualLineStart                    = logicalLineStart;
            std::optional<D2D1_RECT_F> visualLineRect = control.TryGetTextInputCaretRect(host, visualLineStart);
            if (! visualLineRect.has_value())
            {
                return std::nullopt;
            }

            size_t cursor = logicalLineStart;
            while (cursor < logicalLineEnd)
            {
                const size_t next                         = StepToNextCodePoint(text, cursor);
                const std::optional<D2D1_RECT_F> nextRect = control.TryGetTextInputCaretRect(host, next);
                if (! nextRect.has_value())
                {
                    return std::nullopt;
                }

                if (! CaretRectsShareVisualLine(visualLineRect.value(), nextRect.value()))
                {
                    if (visualLineStart < next)
                    {
                        spans.push_back(TextRangeSpan{visualLineStart, next});
                    }
                    visualLineStart = next;
                    visualLineRect  = nextRect;
                }

                cursor = next;
            }

            if (visualLineStart < logicalLineEnd)
            {
                spans.push_back(TextRangeSpan{visualLineStart, logicalLineEnd});
            }
        }

        if (logicalLineEnd >= text.size())
        {
            break;
        }

        const size_t nextLogicalLineStart = AdvancePastTextRangeLineBreak(text, logicalLineEnd);
        if (nextLogicalLineStart <= logicalLineStart)
        {
            break;
        }
        logicalLineStart = nextLogicalLineStart;
    }

    if (spans.size() <= logicalLineCount)
    {
        return std::nullopt;
    }
    return spans;
}

[[nodiscard]] size_t FindTextRangeVisualLineIndex(std::span<const TextRangeSpan> spans, size_t position) noexcept
{
    if (spans.empty())
    {
        return 0u;
    }

    for (size_t index = 0u; index < spans.size(); ++index)
    {
        const TextRangeSpan& span = spans[index];
        if (position == span.start || (position > span.start && position < span.end))
        {
            return index;
        }
        if (position < span.start)
        {
            return index == 0u ? 0u : index - 1u;
        }
    }

    return spans.size() - 1u;
}

[[nodiscard]] std::optional<TextRangeSpan> TryGetEnclosingTextRangeVisualLineSpan(const ControlHost& host,
                                                                                  const Control& control,
                                                                                  std::wstring_view text,
                                                                                  size_t position) noexcept
{
    const std::optional<std::vector<TextRangeSpan>> spans = TryResolveTextRangeVisualLineSpans(host, control, text);
    if (! spans || spans->empty())
    {
        return std::nullopt;
    }

    return spans->at(FindTextRangeVisualLineIndex(*spans, (std::min)(position, text.size())));
}

[[nodiscard]] std::optional<TextRangeSpanMoveResult> TryMoveTextRangeSpanByVisualLine(
    const ControlHost& host, const Control& control, std::wstring_view text, const TextRangeSpan& range, int count) noexcept
{
    const TextRangeSpan clampedRange = ClampTextRangeSpan(range.start, range.end, text.size());
    if (count == 0)
    {
        return TextRangeSpanMoveResult{clampedRange, 0};
    }

    const std::optional<std::vector<TextRangeSpan>> spans = TryResolveTextRangeVisualLineSpans(host, control, text);
    if (! spans.has_value() || spans->empty())
    {
        return std::nullopt;
    }

    const size_t currentIndex = FindTextRangeVisualLineIndex(*spans, clampedRange.start);
    const size_t lastIndex    = spans->size() - 1u;
    size_t targetIndex        = currentIndex;
    int moved                 = 0;
    if (count > 0)
    {
        const size_t requested = static_cast<size_t>(count);
        const size_t remaining = lastIndex - currentIndex;
        if (requested > remaining)
        {
            targetIndex = lastIndex;
            moved       = static_cast<int>(remaining);
        }
        else
        {
            targetIndex = currentIndex + requested;
            moved       = count;
        }
    }
    else
    {
        const uint64_t requested = static_cast<uint64_t>(-static_cast<int64_t>(count));
        if (currentIndex > requested)
        {
            targetIndex = currentIndex - static_cast<size_t>(requested);
            moved       = count;
        }
        else
        {
            targetIndex = 0u;
            moved       = currentIndex == requested ? count : -static_cast<int>(currentIndex);
        }
    }
    if (moved == 0)
    {
        return TextRangeSpanMoveResult{clampedRange, 0};
    }

    return TextRangeSpanMoveResult{spans->at(static_cast<size_t>(targetIndex)), moved};
}

[[nodiscard]] TextRangeUnitMoveResult MoveTextRangePositionByLine(std::wstring_view text, size_t position, int count) noexcept
{
    const size_t clampedPosition = (std::min)(position, text.size());
    if (count == 0)
    {
        return TextRangeUnitMoveResult{clampedPosition, 0};
    }

    const TextRangeSpan lineRange            = GetTextRangeLineSpanAtPosition(text, clampedPosition);
    const TextRangeSpanMoveResult moveResult = MoveTextRangeSpanByLine(text, lineRange, count);
    if (moveResult.moved == 0)
    {
        return TextRangeUnitMoveResult{clampedPosition, 0};
    }

    return TextRangeUnitMoveResult{moveResult.range.start, moveResult.moved};
}

[[nodiscard]] std::optional<TextRangeUnitMoveResult> TryMoveTextRangePositionByVisualLine(
    const ControlHost& host, const Control& control, std::wstring_view text, size_t position, int count) noexcept
{
    const size_t clampedPosition = (std::min)(position, text.size());
    if (count == 0)
    {
        return TextRangeUnitMoveResult{clampedPosition, 0};
    }

    const std::optional<TextRangeSpanMoveResult> moveResult =
        TryMoveTextRangeSpanByVisualLine(host, control, text, TextRangeSpan{clampedPosition, clampedPosition}, count);
    if (! moveResult.has_value())
    {
        return std::nullopt;
    }

    return TextRangeUnitMoveResult{moveResult->range.start, moveResult->moved};
}

[[nodiscard]] TextRangeSpan GetTextRangeSpanFromState(size_t caretIndex, std::optional<size_t> selectionAnchorIndex, size_t textLength) noexcept
{
    const size_t clampedCaret = (std::min)(caretIndex, textLength);
    if (! selectionAnchorIndex)
    {
        return TextRangeSpan{clampedCaret, clampedCaret};
    }

    return ClampTextRangeSpan(selectionAnchorIndex.value(), clampedCaret, textLength);
}

[[nodiscard]] TextRangeSpan GetControlAccessibleSelectionRange(const ControlHost* host, const Control* control, size_t textLength) noexcept
{
    if (host && control)
    {
        NativeTextInputState nativeState{};
        if (host->TryReadNativeTextInputState(control, nativeState))
        {
            return GetTextRangeSpanFromState(nativeState.caretIndex, nativeState.selectionAnchorIndex, textLength);
        }

        TextInputState textInputState{};
        if (host->TryReadTextInputState(control, textInputState))
        {
            return GetTextRangeSpanFromState(textInputState.caretIndex, textInputState.selectionAnchorIndex, textLength);
        }
    }

    if (const auto* textField = dynamic_cast<const TextField*>(control))
    {
        if (const std::optional<std::pair<size_t, size_t>> selectionRange = textField->GetSelectionRange())
        {
            return ClampTextRangeSpan(selectionRange->first, selectionRange->second, textLength);
        }
    }
    if (const auto* comboBox = dynamic_cast<const ComboBox*>(control); comboBox && comboBox->IsEditable())
    {
        if (const std::optional<std::pair<size_t, size_t>> selectionRange = comboBox->GetEditableSelectionRange())
        {
            return ClampTextRangeSpan(selectionRange->first, selectionRange->second, textLength);
        }
    }

    return TextRangeSpan{textLength, textLength};
}

[[nodiscard]] std::wstring BuildGridCellAccessibleText(const GridCellData& cellData)
{
    std::wstring text;
    if (cellData.kind == GridCellKind::Checkbox)
    {
        text.assign(cellData.checked ? L"[x]" : L"[ ]");
        if (! cellData.text.empty())
        {
            text.push_back(L' ');
        }
    }

    if (! cellData.text.empty())
    {
        text.append(cellData.text);
    }
    else if (cellData.kind == GridCellKind::ColorSwatch && cellData.hasSwatchValue)
    {
        text.append(std::format(L"#{:08X}", cellData.swatchArgb));
    }
    else if (cellData.kind == GridCellKind::IconText && ! cellData.iconText.empty())
    {
        text.append(cellData.iconText);
    }

    if (! cellData.badgeText.empty())
    {
        if (! text.empty())
        {
            text.push_back(L' ');
        }
        text.push_back(L'[');
        text.append(cellData.badgeText);
        text.push_back(L']');
    }

    return text;
}

[[nodiscard]] std::wstring_view GetGridHeaderAccessibleName(const GridColumnDesc& columnDesc) noexcept
{
    if (! columnDesc.title.empty())
    {
        return columnDesc.title;
    }

    return columnDesc.id;
}

[[nodiscard]] CONTROLTYPEID GetGridCellControlTypeId(const GridCellData& cellData) noexcept
{
    switch (cellData.kind)
    {
        case GridCellKind::Checkbox: return UIA_CheckBoxControlTypeId;
        case GridCellKind::ColorSwatch: return UIA_ImageControlTypeId;
        case GridCellKind::Spinner:
        case GridCellKind::Marquee: return UIA_ProgressBarControlTypeId;
        case GridCellKind::IconText: return (! cellData.iconText.empty() && cellData.text.empty()) ? UIA_ImageControlTypeId : UIA_TextControlTypeId;
        case GridCellKind::Text:
        default: return UIA_TextControlTypeId;
    }
}

[[nodiscard]] bool GridCellSupportsTogglePattern(const GridCellData& cellData) noexcept
{
    return cellData.kind == GridCellKind::Checkbox && cellData.enabled;
}

[[nodiscard]] bool GridCellSupportsValuePattern(const GridCellData& cellData) noexcept
{
    switch (cellData.kind)
    {
        case GridCellKind::Text:
        case GridCellKind::ColorSwatch: return true;
        case GridCellKind::IconText: return ! cellData.text.empty();
        case GridCellKind::Checkbox:
        case GridCellKind::Spinner:
        case GridCellKind::Marquee:
        default: return false;
    }
}

[[nodiscard]] bool GridCellSupportsRangeValuePattern(const GridCellData& cellData) noexcept
{
    return cellData.kind == GridCellKind::Marquee && std::isfinite(cellData.progress) && cellData.progress > 0.0f;
}

[[nodiscard]] double GetGridCellRangeValue(const GridCellData& cellData) noexcept
{
    return std::clamp(static_cast<double>(cellData.progress), 0.0, 1.0);
}

[[nodiscard]] CONTROLTYPEID GetControlTypeId(const Control* control) noexcept
{
    if (control && control->GetAccessibilityRole() == AccessibilityRole::MenuItem)
    {
        return UIA_MenuItemControlTypeId;
    }
    if (control && control->GetAccessibilityRole() == AccessibilityRole::Status)
    {
        return UIA_StatusBarControlTypeId;
    }

    if (dynamic_cast<const Checkbox*>(control) != nullptr)
    {
        return UIA_CheckBoxControlTypeId;
    }
    if (dynamic_cast<const Toggle*>(control) != nullptr || dynamic_cast<const Button*>(control) != nullptr)
    {
        return UIA_ButtonControlTypeId;
    }
    if (dynamic_cast<const TextField*>(control) != nullptr)
    {
        return UIA_EditControlTypeId;
    }
    if (dynamic_cast<const ComboBox*>(control) != nullptr)
    {
        return UIA_ComboBoxControlTypeId;
    }
    if (dynamic_cast<const Slider*>(control) != nullptr)
    {
        return UIA_SliderControlTypeId;
    }
    if (dynamic_cast<const ProgressBar*>(control) != nullptr)
    {
        return UIA_ProgressBarControlTypeId;
    }
    if (dynamic_cast<const Splitter*>(control) != nullptr)
    {
        // A focusable separator maps to a Thumb with RangeValue (Core-AAM), which screen readers speak with its position.
        return UIA_ThumbControlTypeId;
    }
    if (dynamic_cast<const ThroughputGraph*>(control) != nullptr)
    {
        return UIA_CustomControlTypeId;
    }
    if (dynamic_cast<const Tree*>(control) != nullptr)
    {
        return UIA_TreeControlTypeId;
    }
    if (dynamic_cast<const Grid*>(control) != nullptr)
    {
        return UIA_DataGridControlTypeId;
    }
    if (dynamic_cast<const ColorSwatch*>(control) != nullptr)
    {
        return UIA_ImageControlTypeId;
    }
    return UIA_TextControlTypeId;
}

[[nodiscard]] bool SupportsInvokePattern(const Control* control) noexcept
{
    return (control && control->SupportsAccessibleInvoke()) ||
           (dynamic_cast<const Button*>(control) != nullptr && dynamic_cast<const Toggle*>(control) == nullptr);
}

[[nodiscard]] bool SupportsTogglePattern(const Control* control) noexcept
{
    return dynamic_cast<const Toggle*>(control) != nullptr;
}

[[nodiscard]] bool SupportsValuePattern(const Control* control) noexcept
{
    if (const auto* textField = dynamic_cast<const TextField*>(control))
    {
        return ! textField->IsMultiline();
    }
    return dynamic_cast<const ComboBox*>(control) != nullptr;
}

[[nodiscard]] bool SupportsRangeValuePattern(const Control* control) noexcept
{
    return dynamic_cast<const Slider*>(control) != nullptr || dynamic_cast<const ProgressBar*>(control) != nullptr ||
           dynamic_cast<const Splitter*>(control) != nullptr;
}

[[nodiscard]] bool IsValueReadOnly(const Control* control) noexcept
{
    if (const auto* textField = dynamic_cast<const TextField*>(control))
    {
        return textField->IsReadOnly();
    }
    if (const auto* comboBox = dynamic_cast<const ComboBox*>(control))
    {
        return ! comboBox->IsEditable();
    }
    if (dynamic_cast<const Slider*>(control) != nullptr || dynamic_cast<const Splitter*>(control) != nullptr)
    {
        return false;
    }
    if (dynamic_cast<const ProgressBar*>(control) != nullptr)
    {
        return true;
    }
    return true;
}

[[nodiscard]] VARIANT VariantFromBool(bool value) noexcept
{
    VARIANT variant{};
    variant.vt      = VT_BOOL;
    variant.boolVal = value ? VARIANT_TRUE : VARIANT_FALSE;
    return variant;
}

[[nodiscard]] VARIANT VariantFromInt(int value) noexcept
{
    VARIANT variant{};
    variant.vt   = VT_I4;
    variant.lVal = value;
    return variant;
}

[[nodiscard]] VARIANT VariantFromDouble(double value) noexcept
{
    VARIANT variant{};
    variant.vt     = VT_R8;
    variant.dblVal = value;
    return variant;
}

HRESULT SetVariantFromString(VARIANT* outVariant, std::wstring_view value) noexcept
{
    if (! outVariant)
    {
        return E_POINTER;
    }

    VariantInit(outVariant);
    BSTR text = SysAllocStringLen(value.data(), static_cast<UINT>(value.size()));
    if (! text && ! value.empty())
    {
        return E_OUTOFMEMORY;
    }

    outVariant->vt      = VT_BSTR;
    outVariant->bstrVal = text;
    return S_OK;
}

using RuntimeIdValueBuffer = std::array<LONG, kAccessibilityMaxRuntimeIdValueCount>;

[[nodiscard]] bool AppendRuntimeIdValue(RuntimeIdValueBuffer& values, size_t& valueCount, LONG value) noexcept
{
    if (valueCount >= values.size())
    {
        return false;
    }

    values[valueCount] = value;
    ++valueCount;
    return true;
}

[[nodiscard]] bool AppendControlPathRuntimeIdPrefix(RuntimeIdValueBuffer& values, size_t& valueCount, const ControlPath& path) noexcept
{
    for (uint32_t depth = 0u; depth < path.depth; ++depth)
    {
        if (! AppendRuntimeIdValue(values, valueCount, static_cast<LONG>(path.indices[depth])))
        {
            return false;
        }
    }

    return AppendRuntimeIdValue(values, valueCount, static_cast<LONG>(path.depth));
}

[[nodiscard]] bool AppendWindowRuntimeIdPrefix(RuntimeIdValueBuffer& values, size_t& valueCount, HWND hwnd) noexcept
{
    return AppendRuntimeIdValue(values, valueCount, UiaAppendRuntimeId) && AppendRuntimeIdValue(values, valueCount, HandleToLong(hwnd)) &&
           AppendRuntimeIdValue(values, valueCount, static_cast<LONG>((static_cast<ULONG_PTR>(reinterpret_cast<ULONG_PTR>(hwnd)) >> 32) & 0x7FFFFFFF));
}

// A window-host fragment (tree item, grid header/row/cell, reveal button) also carries its control's identity, so a
// replacement control at the same path never reuses an old fragment's runtime id.
[[nodiscard]] bool AppendFragmentRuntimeIdPrefix(RuntimeIdValueBuffer& values, size_t& valueCount, const ControlPath& path, uint64_t controlIdentity) noexcept
{
    return AppendRuntimeIdValue(values, valueCount, UiaAppendRuntimeId) && AppendControlPathRuntimeIdPrefix(values, valueCount, path) &&
           (controlIdentity == 0u || (AppendRuntimeIdValue(values, valueCount, static_cast<LONG>(controlIdentity)) &&
                                      AppendRuntimeIdValue(values, valueCount, static_cast<LONG>(controlIdentity >> 32))));
}

HRESULT BuildRuntimeId(SAFEARRAY** outArray, std::span<const LONG> values) noexcept
{
    if (! outArray)
    {
        return E_POINTER;
    }

    *outArray = nullptr;
    unique_safearray array(SafeArrayCreateVector(VT_I4, 0, static_cast<ULONG>(values.size())));
    if (! array)
    {
        return E_OUTOFMEMORY;
    }

    for (size_t valueIndex = 0u; valueIndex < values.size(); ++valueIndex)
    {
        LONG arrayIndex  = static_cast<LONG>(valueIndex);
        LONG value       = values[valueIndex];
        const HRESULT hr = SafeArrayPutElement(array.get(), &arrayIndex, &value);
        if (FAILED(hr))
        {
            return hr;
        }
    }

    *outArray = array.release();
    return S_OK;
}

HRESULT SetRuntimeId(SAFEARRAY** outArray, HWND hwnd, const ControlPath* path, uint64_t controlIdentity = 0u) noexcept
{
    RuntimeIdValueBuffer values{};
    size_t valueCount = 0u;
    if (! AppendWindowRuntimeIdPrefix(values, valueCount, hwnd))
    {
        return E_INVALIDARG;
    }

    if (path)
    {
        if (! AppendControlPathRuntimeIdPrefix(values, valueCount, *path))
        {
            return E_INVALIDARG;
        }
    }
    if (controlIdentity != 0u && (! AppendRuntimeIdValue(values, valueCount, static_cast<LONG>(controlIdentity)) ||
                                  ! AppendRuntimeIdValue(values, valueCount, static_cast<LONG>(controlIdentity >> 32))))
    {
        return E_INVALIDARG;
    }

    return BuildRuntimeId(outArray, std::span<const LONG>(values.data(), valueCount));
}

HRESULT SetTextFieldPasswordRevealButtonRuntimeId(SAFEARRAY** outArray, const ControlPath& path, uint64_t controlIdentity) noexcept
{
    RuntimeIdValueBuffer values{};
    size_t valueCount = 0u;
    if (! AppendFragmentRuntimeIdPrefix(values, valueCount, path, controlIdentity) ||
        ! AppendRuntimeIdValue(values, valueCount, kAccessibilityRuntimeIdPasswordRevealButton))
    {
        return E_INVALIDARG;
    }

    return BuildRuntimeId(outArray, std::span<const LONG>(values.data(), valueCount));
}

HRESULT SetTreeItemRuntimeId(SAFEARRAY** outArray, const ControlPath& path, uint64_t itemId, uint64_t controlIdentity) noexcept
{
    if (! outArray)
    {
        return E_POINTER;
    }

    RuntimeIdValueBuffer values{};
    size_t valueCount = 0u;
    if (! AppendFragmentRuntimeIdPrefix(values, valueCount, path, controlIdentity) ||
        ! AppendRuntimeIdValue(values, valueCount, kAccessibilityRuntimeIdTreeItem) ||
        ! AppendRuntimeIdValue(values, valueCount, static_cast<LONG>(itemId & 0xFFFFFFFFull)) ||
        ! AppendRuntimeIdValue(values, valueCount, static_cast<LONG>((itemId >> 32u) & 0xFFFFFFFFull)))
    {
        return E_INVALIDARG;
    }

    return BuildRuntimeId(outArray, std::span<const LONG>(values.data(), valueCount));
}

HRESULT SetGridRowRuntimeId(SAFEARRAY** outArray, const ControlPath& path, uint64_t rowId, uint64_t controlIdentity) noexcept
{
    RuntimeIdValueBuffer values{};
    size_t valueCount = 0u;
    if (! AppendFragmentRuntimeIdPrefix(values, valueCount, path, controlIdentity) ||
        ! AppendRuntimeIdValue(values, valueCount, kAccessibilityRuntimeIdGridRow) ||
        ! AppendRuntimeIdValue(values, valueCount, static_cast<LONG>(rowId & 0xFFFFFFFFull)) ||
        ! AppendRuntimeIdValue(values, valueCount, static_cast<LONG>((rowId >> 32u) & 0xFFFFFFFFull)))
    {
        return E_INVALIDARG;
    }

    return BuildRuntimeId(outArray, std::span<const LONG>(values.data(), valueCount));
}

HRESULT SetGridHeaderRuntimeId(SAFEARRAY** outArray, const ControlPath& path, size_t columnIndex, uint64_t controlIdentity) noexcept
{
    if (! outArray)
    {
        return E_POINTER;
    }

    if (columnIndex > static_cast<size_t>((std::numeric_limits<LONG>::max)()))
    {
        return E_INVALIDARG;
    }

    RuntimeIdValueBuffer values{};
    size_t valueCount = 0u;
    if (! AppendFragmentRuntimeIdPrefix(values, valueCount, path, controlIdentity) ||
        ! AppendRuntimeIdValue(values, valueCount, kAccessibilityRuntimeIdGridHeader) ||
        ! AppendRuntimeIdValue(values, valueCount, static_cast<LONG>(columnIndex)))
    {
        return E_INVALIDARG;
    }

    return BuildRuntimeId(outArray, std::span<const LONG>(values.data(), valueCount));
}

HRESULT SetGridCellRuntimeId(SAFEARRAY** outArray, const ControlPath& path, uint64_t rowId, size_t columnIndex, uint64_t controlIdentity) noexcept
{
    if (! outArray)
    {
        return E_POINTER;
    }

    if (columnIndex > static_cast<size_t>((std::numeric_limits<LONG>::max)()))
    {
        return E_INVALIDARG;
    }

    RuntimeIdValueBuffer values{};
    size_t valueCount = 0u;
    if (! AppendFragmentRuntimeIdPrefix(values, valueCount, path, controlIdentity) ||
        ! AppendRuntimeIdValue(values, valueCount, kAccessibilityRuntimeIdGridCell) ||
        ! AppendRuntimeIdValue(values, valueCount, static_cast<LONG>(rowId & 0xFFFFFFFFull)) ||
        ! AppendRuntimeIdValue(values, valueCount, static_cast<LONG>((rowId >> 32u) & 0xFFFFFFFFull)) ||
        ! AppendRuntimeIdValue(values, valueCount, static_cast<LONG>(columnIndex)))
    {
        return E_INVALIDARG;
    }

    return BuildRuntimeId(outArray, std::span<const LONG>(values.data(), valueCount));
}

HRESULT SetProviderArray(SAFEARRAY** outArray, std::span<IRawElementProviderSimple* const> providers) noexcept
{
    if (! outArray)
    {
        return E_POINTER;
    }

    *outArray = nullptr;
    unique_safearray array(SafeArrayCreateVector(VT_UNKNOWN, 0, static_cast<ULONG>(providers.size())));
    if (! array)
    {
        return E_OUTOFMEMORY;
    }

    for (LONG index = 0; index < static_cast<LONG>(providers.size()); ++index)
    {
        IRawElementProviderSimple* provider = providers[static_cast<size_t>(index)];
        const HRESULT hr                    = SafeArrayPutElement(array.get(), &index, provider);
        if (FAILED(hr))
        {
            return hr;
        }
    }

    *outArray = array.release();
    return S_OK;
}

HRESULT SetTextRangeProviderArray(SAFEARRAY** outArray, std::span<ITextRangeProvider* const> providers) noexcept
{
    if (! outArray)
    {
        return E_POINTER;
    }

    *outArray = nullptr;
    unique_safearray array(SafeArrayCreateVector(VT_UNKNOWN, 0, static_cast<ULONG>(providers.size())));
    if (! array)
    {
        return E_OUTOFMEMORY;
    }

    for (LONG index = 0; index < static_cast<LONG>(providers.size()); ++index)
    {
        ITextRangeProvider* provider = providers[static_cast<size_t>(index)];
        const HRESULT hr             = SafeArrayPutElement(array.get(), &index, provider);
        if (FAILED(hr))
        {
            return hr;
        }
    }

    *outArray = array.release();
    return S_OK;
}

HRESULT SetDoubleArray(SAFEARRAY** outArray, std::span<const double> values) noexcept
{
    if (! outArray)
    {
        return E_POINTER;
    }

    *outArray = nullptr;
    unique_safearray array(SafeArrayCreateVector(VT_R8, 0, static_cast<ULONG>(values.size())));
    if (! array)
    {
        return E_OUTOFMEMORY;
    }

    for (LONG index = 0; index < static_cast<LONG>(values.size()); ++index)
    {
        double value     = values[static_cast<size_t>(index)];
        const HRESULT hr = SafeArrayPutElement(array.get(), &index, &value);
        if (FAILED(hr))
        {
            return hr;
        }
    }

    *outArray = array.release();
    return S_OK;
}

HRESULT SetScreenRectDoubleArray(
    SAFEARRAY** outArray, WindowHostAccessibilityTarget* target, HWND hwnd, std::span<const D2D1_RECT_F> boundsDip, float dipToPixelScale) noexcept
{
    if (! std::isfinite(dipToPixelScale) || dipToPixelScale <= 0.0f)
    {
        dipToPixelScale = 1.0f;
    }

    std::vector<double> values;
    values.reserve(boundsDip.size() * 4u);
    const auto snapshot = CaptureAccessibilitySnapshot(target, hwnd);
    if (target && target->embedded && (! snapshot || ! snapshot->alive))
        return UIA_E_ELEMENTNOTAVAILABLE;
    for (const D2D1_RECT_F& rectDip : boundsDip)
    {
        if (snapshot && snapshot->embedded)
        {
            const auto rect = EmbeddedScreenBounds(*snapshot, rectDip);
            if (rect.width > 0 && rect.height > 0)
                values.insert(values.end(), {rect.left, rect.top, rect.width, rect.height});
            continue;
        }
        POINT topLeft{static_cast<LONG>(std::lround(rectDip.left * dipToPixelScale)), static_cast<LONG>(std::lround(rectDip.top * dipToPixelScale))};
        POINT bottomRight{static_cast<LONG>(std::lround(rectDip.right * dipToPixelScale)), static_cast<LONG>(std::lround(rectDip.bottom * dipToPixelScale))};
        ClientToScreen(hwnd, &topLeft);
        ClientToScreen(hwnd, &bottomRight);
        values.push_back(static_cast<double>(topLeft.x));
        values.push_back(static_cast<double>(topLeft.y));
        values.push_back(static_cast<double>(bottomRight.x - topLeft.x));
        values.push_back(static_cast<double>(bottomRight.y - topLeft.y));
    }

    return SetDoubleArray(outArray, values);
}

// A window-host element keeps the identity of the control it was created for, read from the published snapshot, so a
// different control that later sits at the same path (a rebuilt list) is never reached through it and gets a
// different runtime id. Embedded elements check the same identity against the snapshot they pin. An unknown identity
// (the control was not published yet) resolves by path alone.
struct AccessibilityControlIdentity
{
    std::weak_ptr<int> lifetime;
    uint64_t value = 0u;
};

[[nodiscard]] AccessibilityControlIdentity CaptureWindowHostControlIdentity(WindowHostAccessibilityTarget* target,
                                                                            const ControlPath& path,
                                                                            bool hasControl) noexcept
{
    if (! target || target->embedded || ! hasControl)
        return {};
    const auto snapshot = target->snapshot.load(std::memory_order_acquire);
    const auto* record  = snapshot ? FindControlNavigationRecord(*snapshot, path) : nullptr;
    return record ? AccessibilityControlIdentity{record->controlLifetime, record->controlIdentity} : AccessibilityControlIdentity{};
}

// The identity a window-host element binds to: its control's, or, for the window's root element, the identity of the
// single semantic control collapsed into it, whose element it then is. A root that stands for no control has none and
// represents the host.
[[nodiscard]] AccessibilityControlIdentity CaptureWindowHostElementIdentity(WindowHostAccessibilityTarget* target,
                                                                            const ControlPath& path,
                                                                            AccessibilityFragmentKind kind) noexcept
{
    if (kind != AccessibilityFragmentKind::Root)
        return CaptureWindowHostControlIdentity(target, path, true);
    if (! target || target->embedded)
        return {};
    const auto snapshot = target->snapshot.load(std::memory_order_acquire);
    if (! snapshot || ! SnapshotHasCollapsedSemanticRoot(*snapshot))
        return {};
    const auto* record = FindControlNavigationRecord(*snapshot, snapshot->semanticControlOrder.front());
    return record ? AccessibilityControlIdentity{record->controlLifetime, record->controlIdentity} : AccessibilityControlIdentity{};
}

template <typename TControl>
[[nodiscard]] TControl* ResolveIdentifiedControlAtPath(TControl* root, const ControlPath& path, const AccessibilityControlIdentity& identity) noexcept
{
    TControl* const control = ResolveControlAtPath(root, path);
    if (! control || identity.value == 0u)
        return control;
    const std::weak_ptr<int> lifetime = GetControlLifetimeToken(*control);
    const bool sameControl = ! identity.lifetime.expired() && ! identity.lifetime.owner_before(lifetime) && ! lifetime.owner_before(identity.lifetime);
    return sameControl ? control : nullptr;
}

class AccessibilityTextRangeProvider final : public ITextRangeProvider
{
public:
    AccessibilityTextRangeProvider(WindowHostAccessibilityTarget* target, HWND hwnd, const ControlPath& path, size_t start, size_t end) noexcept
        : _target(target),
          _hwnd(hwnd),
          _snapshot(CaptureAccessibilitySnapshot(target, hwnd)),
          _path(path),
          _rangeStart(start),
          _rangeEnd(end)
    {
    }

    AccessibilityTextRangeProvider(
        WindowHostAccessibilityTarget* target, HWND hwnd, const ControlPath& path, size_t start, size_t end, std::wstring textOverride) noexcept
        : _target(target),
          _hwnd(hwnd),
          _snapshot(CaptureAccessibilitySnapshot(target, hwnd)),
          _textOverride(std::move(textOverride)),
          _path(path),
          _rangeStart(start),
          _rangeEnd(end)
    {
    }

    AccessibilityTextRangeProvider(WindowHostAccessibilityTarget* target,
                                   HWND hwnd,
                                   const ControlPath& path,
                                   size_t start,
                                   size_t end,
                                   std::vector<D2D1_RECT_F> boundsOverrideDip) noexcept
        : _target(target),
          _hwnd(hwnd),
          _snapshot(CaptureAccessibilitySnapshot(target, hwnd)),
          _boundsOverrideDip(std::move(boundsOverrideDip)),
          _path(path),
          _rangeStart(start),
          _rangeEnd(end)
    {
    }

    AccessibilityTextRangeProvider(const AccessibilityTextRangeProvider&)            = delete;
    AccessibilityTextRangeProvider& operator=(const AccessibilityTextRangeProvider&) = delete;
    AccessibilityTextRangeProvider(AccessibilityTextRangeProvider&&)                 = delete;
    AccessibilityTextRangeProvider& operator=(AccessibilityTextRangeProvider&&)      = delete;

    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppvObject) noexcept override;
    ULONG STDMETHODCALLTYPE AddRef() noexcept override;
    ULONG STDMETHODCALLTYPE Release() noexcept override;

    HRESULT STDMETHODCALLTYPE Clone(ITextRangeProvider** outClone) noexcept override;
    HRESULT STDMETHODCALLTYPE Compare(ITextRangeProvider* range, BOOL* outSame) noexcept override;
    HRESULT STDMETHODCALLTYPE CompareEndpoints(TextPatternRangeEndpoint endpoint,
                                               ITextRangeProvider* targetRange,
                                               TextPatternRangeEndpoint targetEndpoint,
                                               int* outResult) noexcept override;
    HRESULT STDMETHODCALLTYPE ExpandToEnclosingUnit(TextUnit unit) noexcept override;
    HRESULT STDMETHODCALLTYPE FindAttribute(TEXTATTRIBUTEID attributeId, VARIANT value, BOOL backward, ITextRangeProvider** outRange) noexcept override;
    HRESULT STDMETHODCALLTYPE FindText(BSTR text, BOOL backward, BOOL ignoreCase, ITextRangeProvider** outRange) noexcept override;
    HRESULT STDMETHODCALLTYPE GetAttributeValue(TEXTATTRIBUTEID attributeId, VARIANT* outValue) noexcept override;
    HRESULT STDMETHODCALLTYPE GetBoundingRectangles(SAFEARRAY** outRectangles) noexcept override;
    HRESULT STDMETHODCALLTYPE GetEnclosingElement(IRawElementProviderSimple** outElement) noexcept override;
    HRESULT STDMETHODCALLTYPE GetText(int maxLength, BSTR* outText) noexcept override;
    HRESULT STDMETHODCALLTYPE Move(TextUnit unit, int count, int* outMoved) noexcept override;
    HRESULT STDMETHODCALLTYPE MoveEndpointByUnit(TextPatternRangeEndpoint endpoint, TextUnit unit, int count, int* outMoved) noexcept override;
    HRESULT STDMETHODCALLTYPE MoveEndpointByRange(TextPatternRangeEndpoint endpoint,
                                                  ITextRangeProvider* targetRange,
                                                  TextPatternRangeEndpoint targetEndpoint) noexcept override;
    HRESULT STDMETHODCALLTYPE Select() noexcept override;
    HRESULT STDMETHODCALLTYPE AddToSelection() noexcept override;
    HRESULT STDMETHODCALLTYPE RemoveFromSelection() noexcept override;
    HRESULT STDMETHODCALLTYPE ScrollIntoView(BOOL alignToTop) noexcept override;
    HRESULT STDMETHODCALLTYPE GetChildren(SAFEARRAY** outChildren) noexcept override;
    HRESULT ExecuteSelectOnWindowThread() noexcept;
    HRESULT ExecuteExpandToVisualLineOnWindowThread(size_t start, size_t end, size_t& outStart, size_t& outEnd) noexcept;
    HRESULT ExecuteMoveByVisualLineOnWindowThread(size_t start, size_t end, int count, size_t& outStart, size_t& outEnd, int& outMoved) noexcept;
    HRESULT ExecuteMoveEndpointByVisualLineOnWindowThread(
        size_t start, size_t end, TextPatternRangeEndpoint endpoint, int count, size_t& outStart, size_t& outEnd, int& outMoved) noexcept;
    HRESULT ExecuteResolveBoundsOnWindowThread(size_t start, size_t end, std::vector<D2D1_RECT_F>& outBoundsDip, float& outDipToPixelScale) noexcept;

private:
    [[nodiscard]] bool IsCurrentThreadWindowThread() const noexcept;
    HRESULT DispatchActionToWindowThread(AccessibilityUiActionRequest& request) const noexcept;
    HRESULT DispatchVisualLineExpansionToWindowThread(size_t start, size_t end, size_t& outStart, size_t& outEnd) noexcept;
    HRESULT DispatchLineMovementToWindowThread(size_t start, size_t end, int count, size_t& outStart, size_t& outEnd, int& outMoved) noexcept;
    HRESULT DispatchEndpointLineMovementToWindowThread(
        size_t start, size_t end, TextPatternRangeEndpoint endpoint, int count, size_t& outStart, size_t& outEnd, int& outMoved) noexcept;
    HRESULT DispatchBoundingRectanglesToWindowThread(size_t start, size_t end, std::vector<D2D1_RECT_F>& outBoundsDip, float& outDipToPixelScale) noexcept;
    [[nodiscard]] std::shared_ptr<const AccessibilitySnapshot> CaptureSnapshot() const noexcept;
    [[nodiscard]] ControlHost* ResolveHost() const noexcept;
    [[nodiscard]] const Control* ResolveControl() const noexcept;
    [[nodiscard]] Control* ResolveMutableControl() const noexcept;
    [[nodiscard]] std::wstring ResolveText() const;
    [[nodiscard]] TextRangeSpan ClampCurrentRange(size_t textLength) const noexcept;
    [[nodiscard]] ITextRangeProvider* CreateRange(size_t start, size_t end) const noexcept;

    std::atomic<ULONG> _referenceCount{1u};
    WindowHostAccessibilityTarget* _target = nullptr;
    HWND _hwnd                             = nullptr;
    std::shared_ptr<const AccessibilitySnapshot> _snapshot;
    std::optional<std::wstring> _textOverride;
    std::optional<std::vector<D2D1_RECT_F>> _boundsOverrideDip;
    ControlPath _path{};
    size_t _rangeStart                     = 0u;
    size_t _rangeEnd                       = 0u;
    AccessibilityControlIdentity _identity = CaptureWindowHostControlIdentity(_target, _path, true);
};

// Only embedded providers compare against the snapshot they were created with (lifetime guard, runtime id); a
// window-host provider always reads the current snapshot. UI Automation keeps event providers alive while a client
// listens, so pinning an O(controls) snapshot in each window-host provider would accumulate until the window closes.
[[nodiscard]] std::shared_ptr<const AccessibilitySnapshot> CaptureProviderCreationSnapshot(WindowHostAccessibilityTarget* target, HWND hwnd) noexcept
{
    return target && target->embedded ? CaptureAccessibilitySnapshot(target, hwnd) : nullptr;
}

class AccessibilityProvider final : public IRawElementProviderSimple,
                                    public IRawElementProviderFragment,
                                    public IRawElementProviderFragmentRoot,
                                    public IInvokeProvider,
                                    public ITextEditProvider,
                                    public ITableProvider,
                                    public IToggleProvider,
                                    public IValueProvider,
                                    public IRangeValueProvider,
                                    public ISelectionProvider,
                                    public ISelectionItemProvider,
                                    public IExpandCollapseProvider,
                                    public IGridItemProvider,
                                    public ITableItemProvider
{
public:
    struct TreeItemTag
    {
    };

    struct GridHeaderTag
    {
    };

    AccessibilityProvider(WindowHostAccessibilityTarget* target, HWND hwnd) noexcept
        : _target(target),
          _hwnd(hwnd),
          _snapshot(CaptureProviderCreationSnapshot(target, hwnd))
    {
    }

    // Whether this element's control is gone for its clients (see CaptureSnapshot), as a window's cached root is once the
    // control it stood for no longer collapses into it.
    [[nodiscard]] bool IsElementGone() const noexcept
    {
        return ! CaptureSnapshot();
    }

    AccessibilityProvider(WindowHostAccessibilityTarget* target, HWND hwnd, const ControlPath& path) noexcept
        : _target(target),
          _hwnd(hwnd),
          _snapshot(CaptureProviderCreationSnapshot(target, hwnd)),
          _path(path),
          _kind(AccessibilityFragmentKind::Control)
    {
    }

    AccessibilityProvider(WindowHostAccessibilityTarget* target, HWND hwnd, const ControlPath& path, AccessibilityFragmentKind kind) noexcept
        : _target(target),
          _hwnd(hwnd),
          _snapshot(CaptureProviderCreationSnapshot(target, hwnd)),
          _path(path),
          _kind(kind)
    {
    }

    AccessibilityProvider(WindowHostAccessibilityTarget* target, HWND hwnd, const ControlPath& path, uint64_t treeItemId, TreeItemTag) noexcept
        : _target(target),
          _hwnd(hwnd),
          _snapshot(CaptureProviderCreationSnapshot(target, hwnd)),
          _path(path),
          _kind(AccessibilityFragmentKind::TreeItem),
          _treeItemId(treeItemId)
    {
    }

    AccessibilityProvider(WindowHostAccessibilityTarget* target, HWND hwnd, const ControlPath& path, size_t gridColumnIndex, GridHeaderTag) noexcept
        : _target(target),
          _hwnd(hwnd),
          _snapshot(CaptureProviderCreationSnapshot(target, hwnd)),
          _path(path),
          _kind(AccessibilityFragmentKind::GridHeader),
          _gridColumnIndex(gridColumnIndex)
    {
    }

    AccessibilityProvider(
        WindowHostAccessibilityTarget* target, HWND hwnd, const ControlPath& path, uint64_t gridRowId, AccessibilityFragmentKind kind) noexcept
        : _target(target),
          _hwnd(hwnd),
          _snapshot(CaptureProviderCreationSnapshot(target, hwnd)),
          _path(path),
          _kind(kind),
          _gridRowId(gridRowId)
    {
    }

    AccessibilityProvider(WindowHostAccessibilityTarget* target, HWND hwnd, const ControlPath& path, uint64_t gridRowId, size_t gridColumnIndex) noexcept
        : _target(target),
          _hwnd(hwnd),
          _snapshot(CaptureProviderCreationSnapshot(target, hwnd)),
          _path(path),
          _kind(AccessibilityFragmentKind::GridCell),
          _gridRowId(gridRowId),
          _gridColumnIndex(gridColumnIndex)
    {
    }

    AccessibilityProvider(const AccessibilityProvider&)            = delete;
    AccessibilityProvider& operator=(const AccessibilityProvider&) = delete;
    AccessibilityProvider(AccessibilityProvider&&)                 = delete;
    AccessibilityProvider& operator=(AccessibilityProvider&&)      = delete;

    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppvObject) noexcept override;
    ULONG STDMETHODCALLTYPE AddRef() noexcept override;
    ULONG STDMETHODCALLTYPE Release() noexcept override;

    HRESULT STDMETHODCALLTYPE get_ProviderOptions(ProviderOptions* outOptions) noexcept override;
    HRESULT STDMETHODCALLTYPE GetPatternProvider(PATTERNID patternId, IUnknown** outProvider) noexcept override;
    HRESULT STDMETHODCALLTYPE GetPropertyValue(PROPERTYID propertyId, VARIANT* outValue) noexcept override;
    HRESULT STDMETHODCALLTYPE get_HostRawElementProvider(IRawElementProviderSimple** outProvider) noexcept override;

    HRESULT STDMETHODCALLTYPE Navigate(NavigateDirection direction, IRawElementProviderFragment** outProvider) noexcept override;
    HRESULT STDMETHODCALLTYPE GetRuntimeId(SAFEARRAY** outRuntimeId) noexcept override;
    HRESULT STDMETHODCALLTYPE get_BoundingRectangle(UiaRect* outRect) noexcept override;
    HRESULT STDMETHODCALLTYPE GetEmbeddedFragmentRoots(SAFEARRAY** outRoots) noexcept override;
    HRESULT STDMETHODCALLTYPE SetFocus() noexcept override;
    HRESULT STDMETHODCALLTYPE get_FragmentRoot(IRawElementProviderFragmentRoot** outRoot) noexcept override;

    HRESULT STDMETHODCALLTYPE ElementProviderFromPoint(double x, double y, IRawElementProviderFragment** outProvider) noexcept override;
    HRESULT STDMETHODCALLTYPE GetFocus(IRawElementProviderFragment** outProvider) noexcept override;

    HRESULT STDMETHODCALLTYPE Invoke() noexcept override;
    HRESULT STDMETHODCALLTYPE Toggle() noexcept override;
    HRESULT STDMETHODCALLTYPE get_ToggleState(ToggleState* outState) noexcept override;
    HRESULT STDMETHODCALLTYPE GetVisibleRanges(SAFEARRAY** outRanges) noexcept override;
    HRESULT STDMETHODCALLTYPE RangeFromChild(IRawElementProviderSimple* childElement, ITextRangeProvider** outRange) noexcept override;
    HRESULT STDMETHODCALLTYPE RangeFromPoint(UiaPoint point, ITextRangeProvider** outRange) noexcept override;
    HRESULT STDMETHODCALLTYPE get_DocumentRange(ITextRangeProvider** outRange) noexcept override;
    HRESULT STDMETHODCALLTYPE get_SupportedTextSelection(SupportedTextSelection* outSupportedSelection) noexcept override;
    HRESULT STDMETHODCALLTYPE GetActiveComposition(ITextRangeProvider** outRange) noexcept override;
    HRESULT STDMETHODCALLTYPE GetConversionTarget(ITextRangeProvider** outRange) noexcept override;
    HRESULT STDMETHODCALLTYPE SetValue(LPCWSTR value) noexcept override;
    HRESULT STDMETHODCALLTYPE SetValue(double value) noexcept override;
    HRESULT STDMETHODCALLTYPE get_Value(BSTR* outValue) noexcept override;
    HRESULT STDMETHODCALLTYPE get_Value(double* outValue) noexcept override;
    HRESULT STDMETHODCALLTYPE get_IsReadOnly(BOOL* outReadOnly) noexcept override;
    HRESULT STDMETHODCALLTYPE get_Maximum(double* outMaximum) noexcept override;
    HRESULT STDMETHODCALLTYPE get_Minimum(double* outMinimum) noexcept override;
    HRESULT STDMETHODCALLTYPE get_LargeChange(double* outLargeChange) noexcept override;
    HRESULT STDMETHODCALLTYPE get_SmallChange(double* outSmallChange) noexcept override;
    HRESULT STDMETHODCALLTYPE GetSelection(SAFEARRAY** outSelection) noexcept override;
    HRESULT STDMETHODCALLTYPE get_CanSelectMultiple(BOOL* outCanSelectMultiple) noexcept override;
    HRESULT STDMETHODCALLTYPE get_IsSelectionRequired(BOOL* outIsSelectionRequired) noexcept override;
    HRESULT STDMETHODCALLTYPE GetRowHeaders(SAFEARRAY** outRowHeaders) noexcept override;
    HRESULT STDMETHODCALLTYPE GetColumnHeaders(SAFEARRAY** outColumnHeaders) noexcept override;
    HRESULT STDMETHODCALLTYPE get_RowOrColumnMajor(RowOrColumnMajor* outRowOrColumnMajor) noexcept override;
    HRESULT STDMETHODCALLTYPE Select() noexcept override;
    HRESULT STDMETHODCALLTYPE AddToSelection() noexcept override;
    HRESULT STDMETHODCALLTYPE RemoveFromSelection() noexcept override;
    HRESULT STDMETHODCALLTYPE get_IsSelected(BOOL* outSelected) noexcept override;
    HRESULT STDMETHODCALLTYPE get_SelectionContainer(IRawElementProviderSimple** outContainer) noexcept override;
    HRESULT STDMETHODCALLTYPE Expand() noexcept override;
    HRESULT STDMETHODCALLTYPE Collapse() noexcept override;
    HRESULT STDMETHODCALLTYPE get_ExpandCollapseState(ExpandCollapseState* outState) noexcept override;
    HRESULT STDMETHODCALLTYPE get_Row(int* outRow) noexcept override;
    HRESULT STDMETHODCALLTYPE get_Column(int* outColumn) noexcept override;
    HRESULT STDMETHODCALLTYPE get_RowSpan(int* outRowSpan) noexcept override;
    HRESULT STDMETHODCALLTYPE get_ColumnSpan(int* outColumnSpan) noexcept override;
    HRESULT STDMETHODCALLTYPE get_ContainingGrid(IRawElementProviderSimple** outContainingGrid) noexcept override;
    HRESULT STDMETHODCALLTYPE GetRowHeaderItems(SAFEARRAY** outRowHeaderItems) noexcept override;
    HRESULT STDMETHODCALLTYPE GetColumnHeaderItems(SAFEARRAY** outColumnHeaderItems) noexcept override;
    HRESULT ExecuteUiThreadAction(AccessibilityUiActionRequest& request) noexcept;

private:
    [[nodiscard]] std::shared_ptr<const AccessibilitySnapshot> CaptureSnapshot() const noexcept;
    [[nodiscard]] ControlHost* ResolveHost() const noexcept;
    [[nodiscard]] const Control* ResolveRootControl() const noexcept;
    [[nodiscard]] bool ResolveControlPath(ControlPath& outPath) const noexcept;
    [[nodiscard]] const Control* ResolveControl() const noexcept;
    [[nodiscard]] Control* ResolveMutableControl() const noexcept;
    [[nodiscard]] const Tree* ResolveTreeControl() const noexcept;
    [[nodiscard]] Tree* ResolveMutableTreeControl() const noexcept;
    [[nodiscard]] const Grid* ResolveGridControl() const noexcept;
    [[nodiscard]] Grid* ResolveMutableGridControl() const noexcept;
    [[nodiscard]] bool ResolveTreeVisibleIndex(size_t& outVisibleIndex) const noexcept;
    [[nodiscard]] bool ResolveTreeItemData(TreeItemData& outItem) const noexcept;
    [[nodiscard]] bool ResolveGridRowIndex(size_t& outRowIndex) const noexcept;
    [[nodiscard]] bool ResolveGridCellData(size_t& outRowIndex, size_t& outColumnIndex, GridCellData& outCellData) const noexcept;
    [[nodiscard]] AccessibilityPatternQueryResult QueryPattern(AccessibilityPatternKind patternKind) noexcept;
    template <typename TInterface, typename TProvider, typename... Args> [[nodiscard]] TInterface* MakeProvider(Args&&... args) const noexcept
    {
        WindowHostAccessibilityTarget* target = AddRefTarget();
        auto* provider                        = new (std::nothrow) TProvider(target, std::forward<Args>(args)...);
        if (! provider && target)
        {
            static_cast<void>(target->Release());
        }
        return provider ? static_cast<TInterface*>(provider) : nullptr;
    }
    [[nodiscard]] IRawElementProviderFragmentRoot* CreateRootProvider() noexcept;
    [[nodiscard]] IRawElementProviderFragment* CreateRootFragmentProvider() noexcept;
    [[nodiscard]] IRawElementProviderFragment* CreateChildProvider(const ControlPath& path) noexcept;
    [[nodiscard]] IRawElementProviderFragment* CreateControlProvider(const ControlPath& path) noexcept;
    [[nodiscard]] IRawElementProviderFragment* CreateTextFieldPasswordRevealButtonProvider(const ControlPath& path) noexcept;
    [[nodiscard]] IRawElementProviderFragment* CreateTreeItemProvider(const ControlPath& path, uint64_t itemId) noexcept;
    [[nodiscard]] IRawElementProviderFragment* CreateGridHeaderProvider(const ControlPath& path, size_t columnIndex) noexcept;
    [[nodiscard]] IRawElementProviderFragment* CreateGridRowProvider(const ControlPath& path, uint64_t rowId) noexcept;
    [[nodiscard]] IRawElementProviderFragment* CreateGridCellProvider(const ControlPath& path, uint64_t rowId, size_t columnIndex) noexcept;
    [[nodiscard]] IRawElementProviderFragment* CreateProviderFromNavigationTarget(const AccessibilityNavigationTarget& navigationTarget) noexcept;
    [[nodiscard]] ITextRangeProvider* CreateTextRangeProvider(const ControlPath& path, size_t start, size_t end) noexcept;
    [[nodiscard]] ITextRangeProvider* CreateTextRangeProvider(const ControlPath& path,
                                                              size_t start,
                                                              size_t end,
                                                              std::vector<D2D1_RECT_F> boundsOverrideDip) noexcept;
    [[nodiscard]] ITextRangeProvider* CreateTextRangeProvider(const ControlPath& path, size_t start, size_t end, std::wstring textOverride) noexcept;
    [[nodiscard]] ITextRangeProvider* CreateTextDocumentRangeProvider(const AccessibilityControlNavigationSnapshot& record) noexcept;
    [[nodiscard]] WindowHostAccessibilityTarget* AddRefTarget() const noexcept;
    [[nodiscard]] bool IsCurrentThreadWindowThread() const noexcept;
    HRESULT DispatchActionToWindowThread(AccessibilityUiActionRequest& request) noexcept;
    HRESULT ExecuteSetFocusOnWindowThread() noexcept;
    HRESULT ExecuteInvokeOnWindowThread() noexcept;
    HRESULT ExecuteToggleOnWindowThread() noexcept;
    HRESULT ExecuteSetStringValueOnWindowThread(LPCWSTR value) noexcept;
    HRESULT ExecuteSetRangeValueOnWindowThread(double value) noexcept;
    HRESULT ExecuteResolveTextRangeFromPointOnWindowThread(UiaPoint point, size_t& outCaretIndex, size_t& outTextLength) noexcept;
    HRESULT ExecuteSelectOnWindowThread() noexcept;
    HRESULT ExecuteAddToSelectionOnWindowThread() noexcept;
    HRESULT ExecuteRemoveFromSelectionOnWindowThread() noexcept;
    HRESULT ExecuteExpandOnWindowThread(bool expanded) noexcept;

    std::atomic<ULONG> _referenceCount{1u};
    WindowHostAccessibilityTarget* _target = nullptr;
    HWND _hwnd                             = nullptr;
    std::shared_ptr<const AccessibilitySnapshot> _snapshot;
    ControlPath _path{};
    AccessibilityFragmentKind _kind        = AccessibilityFragmentKind::Root;
    uint64_t _treeItemId                   = 0u;
    uint64_t _gridRowId                    = 0u;
    size_t _gridColumnIndex                = 0u;
    AccessibilityControlIdentity _identity = CaptureWindowHostElementIdentity(_target, _path, _kind);
};

[[nodiscard]] wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> AcquireCanonicalRootProvider(WindowHostAccessibilityTarget* target) noexcept
{
    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> root;
    if (! target)
    {
        return root;
    }

    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    // A cached root that stood for a control no longer collapsed into the window is gone for the clients that hold it; a
    // newly acquiring client gets a fresh root, which stands for what the window shows now.
    if (target->rootProvider && ! target->embedded && static_cast<AccessibilityProvider*>(target->rootProvider.get())->IsElementGone())
        target->rootProvider.reset();
    if (! target->rootProvider)
    {
        static_cast<void>(target->AddRef());
        auto* provider = new (std::nothrow) AccessibilityProvider(target, target->hwnd);
        if (! provider)
        {
            static_cast<void>(target->Release());
            return root;
        }

        // The target-owned cache retains the sole canonical root identity. Every root
        // path QIs/AddRefs this object instead of constructing an equivalent provider.
        target->rootProvider.attach(static_cast<IRawElementProviderSimple*>(provider));
    }

    static_cast<void>(target->rootProvider.query_to(root.put()));
    return root;
}

// The element of the control at `path`, as a client reaches it. When the published snapshot's collapsed semantic root stands for
// that control, the element is the window's canonical root element and no other: the control has no second element, so what
// reports through it (an event, a selection container, a containing grid, the enclosing element of a text range) is one that
// UI Automation reaches from the window. Otherwise it is a provider of its own, which takes a reference of `target` (borrowed
// here). Null when out of memory.
[[nodiscard]] wil::com_ptr_nothrow<IRawElementProviderSimple> CreateControlElement(WindowHostAccessibilityTarget* target,
                                                                                   HWND hwnd,
                                                                                   const ControlPath& path) noexcept
{
    wil::com_ptr_nothrow<IRawElementProviderSimple> element;
    if (! target)
    {
        return element;
    }

    const auto snapshot = target->snapshot.load(std::memory_order_acquire);
    if (snapshot && SnapshotPathIsCollapsedSemanticRoot(*snapshot, path))
    {
        if (const auto root = AcquireCanonicalRootProvider(target))
        {
            static_cast<void>(root.query_to(element.put()));
        }
        return element;
    }

    static_cast<void>(target->AddRef());
    auto* provider = new (std::nothrow) AccessibilityProvider(target, hwnd, path);
    if (! provider)
    {
        static_cast<void>(target->Release());
        return element;
    }

    element.attach(static_cast<IRawElementProviderSimple*>(provider));
    return element;
}

HRESULT AccessibilityTextRangeProvider::QueryInterface(REFIID riid, void** ppvObject) noexcept
{
    if (! ppvObject)
    {
        return E_POINTER;
    }

    *ppvObject = nullptr;
    if (riid == __uuidof(IUnknown) || riid == __uuidof(ITextRangeProvider))
    {
        *ppvObject = static_cast<ITextRangeProvider*>(this);
        AddRef();
        return S_OK;
    }

    return E_NOINTERFACE;
}

ULONG AccessibilityTextRangeProvider::AddRef() noexcept
{
    return _referenceCount.fetch_add(1u, std::memory_order_relaxed) + 1u;
}

ULONG AccessibilityTextRangeProvider::Release() noexcept
{
    const ULONG remaining = _referenceCount.fetch_sub(1u, std::memory_order_acq_rel) - 1u;
    if (remaining == 0u)
    {
        if (_target)
        {
            static_cast<void>(_target->Release());
            _target = nullptr;
        }
        delete this;
    }
    return remaining;
}

HRESULT AccessibilityTextRangeProvider::Clone(ITextRangeProvider** outClone) noexcept
{
    if (outClone)
        *outClone = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outClone)
    {
        return E_POINTER;
    }

    *outClone = CreateRange(_rangeStart, _rangeEnd);
    return *outClone ? S_OK : E_OUTOFMEMORY;
}

HRESULT AccessibilityTextRangeProvider::Compare(ITextRangeProvider* range, BOOL* outSame) noexcept
{
    if (outSame)
        *outSame = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outSame)
    {
        return E_POINTER;
    }

    const auto* other = dynamic_cast<AccessibilityTextRangeProvider*>(range);
    *outSame = (other && _target == other->_target && _hwnd == other->_hwnd && AreControlPathsEqual(_path, other->_path) && _rangeStart == other->_rangeStart &&
                _rangeEnd == other->_rangeEnd)
                   ? TRUE
                   : FALSE;
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::CompareEndpoints(TextPatternRangeEndpoint endpoint,
                                                         ITextRangeProvider* targetRange,
                                                         TextPatternRangeEndpoint targetEndpoint,
                                                         int* outResult) noexcept
{
    if (outResult)
        *outResult = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outResult)
    {
        return E_POINTER;
    }
    if (! targetRange)
    {
        return E_INVALIDARG;
    }

    const auto* other = dynamic_cast<AccessibilityTextRangeProvider*>(targetRange);
    if (! other || _target != other->_target || _hwnd != other->_hwnd || ! AreControlPathsEqual(_path, other->_path))
    {
        return E_INVALIDARG;
    }

    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    const std::wstring text        = ResolveText();
    const TextRangeSpan range      = ClampCurrentRange(text.size());
    const TextRangeSpan otherRange = other->ClampCurrentRange(text.size());
    const size_t position          = GetTextRangeEndpointPosition(range, endpoint);
    const size_t targetPosition    = GetTextRangeEndpointPosition(otherRange, targetEndpoint);

    *outResult = position < targetPosition ? -1 : (position > targetPosition ? 1 : 0);
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::ExpandToEnclosingUnit(TextUnit unit) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const auto startedAt         = std::chrono::steady_clock::now();
    const TextUnit supportedUnit = NormalizeAccessibilityTextUnit(unit);

    if (supportedUnit == TextUnit_Line && ! IsCurrentThreadWindowThread())
    {
        size_t rangeStart = 0u;
        size_t rangeEnd   = 0u;
        size_t textLength = 0u;
        {
            const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
            const std::wstring text   = ResolveText();
            const TextRangeSpan range = ClampCurrentRange(text.size());
            rangeStart                = range.start;
            rangeEnd                  = range.end;
            textLength                = text.size();
        }

        size_t resultStart = rangeStart;
        size_t resultEnd   = rangeEnd;
        const HRESULT hr   = DispatchVisualLineExpansionToWindowThread(rangeStart, rangeEnd, resultStart, resultEnd);
        if (SUCCEEDED(hr))
        {
            const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
            const TextRangeSpan resultRange = ClampTextRangeSpan(resultStart, resultEnd, ResolveText().size());
            _boundsOverrideDip.reset();
            _rangeStart = resultRange.start;
            _rangeEnd   = resultRange.end;
        }
        Debug::Perf::Emit(L"dxui.uia.text_range_us",
                          L"expand-line-dispatch",
                          Debug::Perf::ElapsedUs(startedAt),
                          SUCCEEDED(hr) ? resultEnd - resultStart : 0u,
                          textLength,
                          hr);
        return hr;
    }

    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    const std::wstring text = ResolveText();
    _boundsOverrideDip.reset();
    TextRangeSpan expandedRange{};
    if (supportedUnit == TextUnit_Document)
    {
        expandedRange = TextRangeSpan{0u, text.size()};
    }
    else if (supportedUnit == TextUnit_Character)
    {
        const TextRangeSpan range = ClampCurrentRange(text.size());
        expandedRange             = GetEnclosingTextRangeCharacterSpan(text, range.start);
    }
    else if (supportedUnit == TextUnit_Word)
    {
        const TextRangeSpan range = ClampCurrentRange(text.size());
        expandedRange             = GetEnclosingTextRangeWordSpan(text, range.start);
    }
    else
    {
        const TextRangeSpan range    = ClampCurrentRange(text.size());
        ControlHost* const host      = ResolveHost();
        const Control* const control = ResolveControl();
        expandedRange =
            (host && control)
                ? TryGetEnclosingTextRangeVisualLineSpan(*host, *control, text, range.start).value_or(GetTextRangeLineSpanAtPosition(text, range.start))
                : GetTextRangeLineSpanAtPosition(text, range.start);
    }

    _rangeStart           = expandedRange.start;
    _rangeEnd             = expandedRange.end;
    const wchar_t* detail = supportedUnit == TextUnit_Character ? L"expand-character"
                            : supportedUnit == TextUnit_Word    ? L"expand-word"
                            : supportedUnit == TextUnit_Line    ? L"expand-line"
                                                                : L"expand-document";
    Debug::Perf::Emit(L"dxui.uia.text_range_us", detail, Debug::Perf::ElapsedUs(startedAt), _rangeEnd - _rangeStart, text.size(), S_OK);
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::FindAttribute(TEXTATTRIBUTEID /*attributeId*/,
                                                      VARIANT /*value*/,
                                                      BOOL /*backward*/,
                                                      ITextRangeProvider** outRange) noexcept
{
    if (outRange)
        *outRange = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outRange)
    {
        return E_POINTER;
    }

    *outRange = nullptr;
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::FindText(BSTR /*text*/, BOOL /*backward*/, BOOL /*ignoreCase*/, ITextRangeProvider** outRange) noexcept
{
    if (outRange)
        *outRange = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outRange)
    {
        return E_POINTER;
    }

    *outRange = nullptr;
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::GetAttributeValue(TEXTATTRIBUTEID /*attributeId*/, VARIANT* outValue) noexcept
{
    if (outValue)
        *outValue = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outValue)
    {
        return E_POINTER;
    }

    VariantInit(outValue);
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::GetBoundingRectangles(SAFEARRAY** outRectangles) noexcept
{
    if (outRectangles)
        *outRectangles = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outRectangles)
    {
        return E_POINTER;
    }

    const auto startedAt = std::chrono::steady_clock::now();
    *outRectangles       = nullptr;

    TextRangeSpan range{};
    std::optional<std::vector<D2D1_RECT_F>> boundsOverrideDip;
    size_t textLength = 0u;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        const std::wstring text = ResolveText();
        textLength              = text.size();
        range                   = ClampCurrentRange(textLength);
        if (_boundsOverrideDip && ! _boundsOverrideDip->empty())
        {
            boundsOverrideDip = _boundsOverrideDip.value();
        }
    }

    if (range.start == range.end)
    {
        const HRESULT hr = SetDoubleArray(outRectangles, {});
        Debug::Perf::Emit(L"dxui.uia.text_range_us", L"bounding-rectangles-empty", Debug::Perf::ElapsedUs(startedAt), 0u, 0u, hr);
        return hr;
    }

    if (boundsOverrideDip && ! boundsOverrideDip->empty())
    {
        const float dipToPixelScale = (_snapshot && _snapshot->pixelsToDipScale > 0.0f) ? 1.0f / _snapshot->pixelsToDipScale : 1.0f;
        const HRESULT hr            = SetScreenRectDoubleArray(outRectangles, _target, _hwnd, boundsOverrideDip.value(), dipToPixelScale);
        Debug::Perf::Emit(L"dxui.uia.text_range_us",
                          L"bounding-rectangles-snapshot",
                          Debug::Perf::ElapsedUs(startedAt),
                          boundsOverrideDip->size(),
                          range.end - range.start,
                          hr);
        return hr;
    }

    if (! IsCurrentThreadWindowThread())
    {
        std::vector<D2D1_RECT_F> boundsDip;
        float dipToPixelScale    = 1.0f;
        const HRESULT dispatchHr = DispatchBoundingRectanglesToWindowThread(range.start, range.end, boundsDip, dipToPixelScale);
        if (FAILED(dispatchHr))
        {
            Debug::Perf::Emit(L"dxui.uia.text_range_us", L"bounding-rectangles-dispatch", Debug::Perf::ElapsedUs(startedAt), 0u, textLength, dispatchHr);
            return dispatchHr;
        }

        const HRESULT hr = SetScreenRectDoubleArray(outRectangles, _target, _hwnd, boundsDip, dipToPixelScale);
        Debug::Perf::Emit(
            L"dxui.uia.text_range_us", L"bounding-rectangles-dispatch", Debug::Perf::ElapsedUs(startedAt), boundsDip.size(), range.end - range.start, hr);
        return hr;
    }

    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    ControlHost* const host      = ResolveHost();
    const Control* const control = ResolveControl();
    if (! host || ! control)
    {
        const HRESULT hr = SetDoubleArray(outRectangles, {});
        Debug::Perf::Emit(L"dxui.uia.text_range_us", L"bounding-rectangles-empty", Debug::Perf::ElapsedUs(startedAt), 0u, 0u, hr);
        return hr;
    }

    const std::wstring text = _textOverride ? _textOverride.value() : GetControlAccessibleTextRangeText(control);
    range                   = ClampCurrentRange(text.size());
    if (range.start == range.end)
    {
        const HRESULT hr = SetDoubleArray(outRectangles, {});
        Debug::Perf::Emit(L"dxui.uia.text_range_us", L"bounding-rectangles-empty", Debug::Perf::ElapsedUs(startedAt), 0u, 0u, hr);
        return hr;
    }

    std::vector<D2D1_RECT_F> boundsDip =
        TryResolveTextRangeCaretRects(*host, *control, text, range).value_or(std::vector<D2D1_RECT_F>{ResolveTextPatternViewportRect(control)});
    const float dipToPixelScale = static_cast<float>(host->GetDpi()) / static_cast<float>(USER_DEFAULT_SCREEN_DPI);
    const HRESULT hr            = SetScreenRectDoubleArray(outRectangles, _target, _hwnd, boundsDip, dipToPixelScale);
    Debug::Perf::Emit(L"dxui.uia.text_range_us", L"bounding-rectangles", Debug::Perf::ElapsedUs(startedAt), boundsDip.size(), range.end - range.start, hr);
    return hr;
}

HRESULT AccessibilityTextRangeProvider::GetEnclosingElement(IRawElementProviderSimple** outElement) noexcept
{
    if (outElement)
        *outElement = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outElement)
    {
        return E_POINTER;
    }

    *outElement = nullptr;
    const AccessibilityControlNavigationSnapshot* record =
        (_snapshot && _snapshot->alive && _snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*_snapshot, _path) : nullptr;
    if (! record || ! record->controlSupportsText)
    {
        return UIA_E_ELEMENTNOTAVAILABLE;
    }

    // The field's element: the window's own when the field is the one control the window's root stands for.
    wil::com_ptr_nothrow<IRawElementProviderSimple> element = CreateControlElement(_target, _hwnd, record->path);
    if (! element)
    {
        return E_OUTOFMEMORY;
    }

    *outElement = element.detach();
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::GetText(int maxLength, BSTR* outText) noexcept
{
    if (outText)
        *outText = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const auto startedAt = std::chrono::steady_clock::now();
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outText)
    {
        return E_POINTER;
    }

    *outText                  = nullptr;
    const std::wstring text   = ResolveText();
    const TextRangeSpan range = ClampCurrentRange(text.size());
    std::wstring_view value(text.data() + range.start, range.end - range.start);
    if (maxLength >= 0)
    {
        value = value.substr(0u, (std::min)(value.size(), static_cast<size_t>(maxLength)));
    }

    *outText         = SysAllocStringLen(value.data(), static_cast<UINT>(value.size()));
    const HRESULT hr = (*outText || value.empty()) ? S_OK : E_OUTOFMEMORY;
    Debug::Perf::Emit(L"dxui.uia.text_range_us", L"gettext", Debug::Perf::ElapsedUs(startedAt), value.size(), text.size(), hr);
    return hr;
}

HRESULT AccessibilityTextRangeProvider::Move(TextUnit unit, int count, int* outMoved) noexcept
{
    if (outMoved)
        *outMoved = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const auto startedAt = std::chrono::steady_clock::now();
    if (! outMoved)
    {
        return E_POINTER;
    }

    *outMoved = 0;
    unit      = NormalizeAccessibilityTextUnit(unit);
    if (count == 0)
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        const std::wstring text = ResolveText();
        Debug::Perf::Emit(L"dxui.uia.text_range_us", L"move-unsupported", Debug::Perf::ElapsedUs(startedAt), 0u, text.size(), S_OK);
        return S_OK;
    }

    if (unit == TextUnit_Line && ! IsCurrentThreadWindowThread())
    {
        size_t rangeStart = 0u;
        size_t rangeEnd   = 0u;
        size_t textLength = 0u;
        {
            const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
            const std::wstring text   = ResolveText();
            const TextRangeSpan range = ClampCurrentRange(text.size());
            rangeStart                = range.start;
            rangeEnd                  = range.end;
            textLength                = text.size();
        }

        size_t resultStart = rangeStart;
        size_t resultEnd   = rangeEnd;
        int moved          = 0;
        const HRESULT hr   = DispatchLineMovementToWindowThread(rangeStart, rangeEnd, count, resultStart, resultEnd, moved);
        if (SUCCEEDED(hr))
        {
            const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
            const std::wstring text         = ResolveText();
            const TextRangeSpan resultRange = ClampTextRangeSpan(resultStart, resultEnd, text.size());
            _boundsOverrideDip.reset();
            _rangeStart = resultRange.start;
            _rangeEnd   = resultRange.end;
            *outMoved   = moved;
        }
        Debug::Perf::Emit(
            L"dxui.uia.text_range_us", L"move-line-dispatch", Debug::Perf::ElapsedUs(startedAt), SUCCEEDED(hr) ? resultEnd - resultStart : 0u, textLength, hr);
        return hr;
    }

    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    const std::wstring text   = ResolveText();
    const TextRangeSpan range = ClampCurrentRange(text.size());
    if (unit == TextUnit_Line)
    {
        ControlHost* const host      = ResolveHost();
        const Control* const control = ResolveControl();
        const TextRangeSpanMoveResult moveResult =
            (host && control) ? TryMoveTextRangeSpanByVisualLine(*host, *control, text, range, count).value_or(MoveTextRangeSpanByLine(text, range, count))
                              : MoveTextRangeSpanByLine(text, range, count);
        _boundsOverrideDip.reset();
        _rangeStart = moveResult.range.start;
        _rangeEnd   = moveResult.range.end;
        *outMoved   = moveResult.moved;
        Debug::Perf::Emit(L"dxui.uia.text_range_us", L"move-line", Debug::Perf::ElapsedUs(startedAt), _rangeEnd - _rangeStart, text.size(), S_OK);
        return S_OK;
    }

    if (unit == TextUnit_Word)
    {
        if (range.start != range.end)
        {
            const TextRangeSpanMoveResult moveResult = MoveTextRangeSpanByWord(text, range, count);
            _boundsOverrideDip.reset();
            _rangeStart = moveResult.range.start;
            _rangeEnd   = moveResult.range.end;
            *outMoved   = moveResult.moved;
            Debug::Perf::Emit(L"dxui.uia.text_range_us", L"move-word", Debug::Perf::ElapsedUs(startedAt), _rangeEnd - _rangeStart, text.size(), S_OK);
            return S_OK;
        }

        const TextRangeUnitMoveResult moveResult = MoveTextRangePositionByUnit(text, range.start, unit, count);
        _boundsOverrideDip.reset();
        _rangeStart = moveResult.position;
        _rangeEnd   = moveResult.position;
        *outMoved   = moveResult.moved;
        Debug::Perf::Emit(L"dxui.uia.text_range_us", L"move-word", Debug::Perf::ElapsedUs(startedAt), 0u, text.size(), S_OK);
        return S_OK;
    }

    if (unit == TextUnit_Character || unit == TextUnit_Document)
    {
        const bool collapsed                      = range.start == range.end;
        const TextRangeUnitMoveResult moveResult  = MoveAccessibilityTextPositionByUnit(text, range.start, unit, count);
        const AccessibilityTextUnitSpan movedSpan = GetEnclosingAccessibilityTextUnitSpan(text, moveResult.position, unit);
        _boundsOverrideDip.reset();
        const size_t nextStart = collapsed ? moveResult.position : movedSpan.start;
        const size_t nextEnd   = collapsed ? moveResult.position : movedSpan.end;
        _rangeStart            = nextStart;
        _rangeEnd              = nextEnd;
        *outMoved              = nextStart == range.start && nextEnd == range.end ? 0 : moveResult.moved;
        if (! collapsed && unit == TextUnit_Document)
            *outMoved = 0; // Normalizing a partial range to the only document unit does not move that unit.
        else if (! collapsed && count > 0 && moveResult.position == text.size() && *outMoved > 0)
            --*outMoved; // A nondegenerate range stops on the last character, before the end caret boundary.
        Debug::Perf::Emit(L"dxui.uia.text_range_us",
                          unit == TextUnit_Document ? L"move-document" : L"move-character",
                          Debug::Perf::ElapsedUs(startedAt),
                          _rangeEnd - _rangeStart,
                          text.size(),
                          S_OK);
        return S_OK;
    }

    Debug::Perf::Emit(L"dxui.uia.text_range_us", L"move-unsupported", Debug::Perf::ElapsedUs(startedAt), 0u, text.size(), S_OK);
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::MoveEndpointByUnit(TextPatternRangeEndpoint endpoint, TextUnit unit, int count, int* outMoved) noexcept
{
    if (outMoved)
        *outMoved = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const auto startedAt = std::chrono::steady_clock::now();
    if (! outMoved)
    {
        return E_POINTER;
    }

    *outMoved = 0;
    unit      = NormalizeAccessibilityTextUnit(unit);
    if (count == 0)
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        const std::wstring text = ResolveText();
        Debug::Perf::Emit(L"dxui.uia.text_range_us", L"move-endpoint-unsupported", Debug::Perf::ElapsedUs(startedAt), 0u, text.size(), S_OK);
        return S_OK;
    }

    if (unit == TextUnit_Line && ! IsCurrentThreadWindowThread())
    {
        size_t rangeStart = 0u;
        size_t rangeEnd   = 0u;
        size_t textLength = 0u;
        {
            const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
            const std::wstring text   = ResolveText();
            const TextRangeSpan range = ClampCurrentRange(text.size());
            rangeStart                = range.start;
            rangeEnd                  = range.end;
            textLength                = text.size();
        }

        size_t resultStart = rangeStart;
        size_t resultEnd   = rangeEnd;
        int moved          = 0;
        const HRESULT hr   = DispatchEndpointLineMovementToWindowThread(rangeStart, rangeEnd, endpoint, count, resultStart, resultEnd, moved);
        if (SUCCEEDED(hr))
        {
            const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
            const std::wstring text         = ResolveText();
            const TextRangeSpan resultRange = ClampTextRangeSpan(resultStart, resultEnd, text.size());
            _boundsOverrideDip.reset();
            _rangeStart = resultRange.start;
            _rangeEnd   = resultRange.end;
            *outMoved   = moved;
        }
        Debug::Perf::Emit(L"dxui.uia.text_range_us",
                          L"move-endpoint-line-dispatch",
                          Debug::Perf::ElapsedUs(startedAt),
                          SUCCEEDED(hr) ? resultEnd - resultStart : 0u,
                          textLength,
                          hr);
        return hr;
    }

    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    const std::wstring text       = ResolveText();
    const TextRangeSpan range     = ClampCurrentRange(text.size());
    const size_t endpointPosition = GetTextRangeEndpointPosition(range, endpoint);
    TextRangeUnitMoveResult moveResult{};
    if (unit == TextUnit_Line)
    {
        ControlHost* const host      = ResolveHost();
        const Control* const control = ResolveControl();
        moveResult                   = (host && control) ? TryMoveTextRangePositionByVisualLine(*host, *control, text, endpointPosition, count)
                                                               .value_or(MoveTextRangePositionByLine(text, endpointPosition, count))
                                                         : MoveTextRangePositionByLine(text, endpointPosition, count);
    }
    else
    {
        moveResult = MoveAccessibilityTextPositionByUnit(text, endpointPosition, unit, count);
    }
    const size_t movedTo = moveResult.position;
    *outMoved            = moveResult.moved;
    _boundsOverrideDip.reset();
    if (endpoint == TextPatternRangeEndpoint_Start)
    {
        _rangeStart = movedTo;
        _rangeEnd   = range.end < _rangeStart ? _rangeStart : range.end;
    }
    else
    {
        _rangeEnd   = movedTo;
        _rangeStart = _rangeEnd < range.start ? _rangeEnd : range.start;
    }
    const wchar_t* detail = unit == TextUnit_Line ? L"move-endpoint-line" : unit == TextUnit_Word ? L"move-endpoint-word" : L"move-endpoint-character";
    Debug::Perf::Emit(L"dxui.uia.text_range_us", detail, Debug::Perf::ElapsedUs(startedAt), _rangeEnd - _rangeStart, text.size(), S_OK);
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::MoveEndpointByRange(TextPatternRangeEndpoint /*endpoint*/,
                                                            ITextRangeProvider* /*targetRange*/,
                                                            TextPatternRangeEndpoint /*targetEndpoint*/) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::Select() noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! IsCurrentThreadWindowThread())
    {
        AccessibilityUiActionRequest request{};
        request.textRangeProvider = this;
        request.kind              = AccessibilityUiActionKind::Select;
        return DispatchActionToWindowThread(request);
    }

    return ExecuteSelectOnWindowThread();
}

HRESULT AccessibilityTextRangeProvider::ExecuteSelectOnWindowThread() noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const auto startedAt = std::chrono::steady_clock::now();
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());

    ControlHost* host = ResolveHost();
    Control* control  = ResolveMutableControl();
    if (! host || ! control || ! SupportsTextPattern(control))
    {
        return UIA_E_ELEMENTNOTAVAILABLE;
    }

    const std::wstring text   = GetControlAccessibleTextRangeText(control);
    const TextRangeSpan range = ClampCurrentRange(text.size());
    if (auto* textField = dynamic_cast<TextField*>(control))
    {
        textField->SetSelectionRange(range.start, range.end);
        host->SyncTextInput(textField);
        host->Invalidate();
        Debug::Perf::Emit(L"dxui.uia.text_range_us", L"select", Debug::Perf::ElapsedUs(startedAt), range.end - range.start, text.size(), S_OK);
        return S_OK;
    }
    if (auto* comboBox = dynamic_cast<ComboBox*>(control); comboBox && comboBox->IsEditable())
    {
        comboBox->SetEditableSelectionRange(range.start, range.end);
        host->SyncTextInput(comboBox);
        host->Invalidate();
        Debug::Perf::Emit(L"dxui.uia.text_range_us", L"select", Debug::Perf::ElapsedUs(startedAt), range.end - range.start, text.size(), S_OK);
        return S_OK;
    }

    return UIA_E_NOTSUPPORTED;
}

HRESULT AccessibilityTextRangeProvider::ExecuteExpandToVisualLineOnWindowThread(size_t start, size_t end, size_t& outStart, size_t& outEnd) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());

    ControlHost* const host      = ResolveHost();
    const Control* const control = ResolveControl();
    const std::wstring text      = control ? (_textOverride ? _textOverride.value() : GetControlAccessibleTextRangeText(control)) : ResolveText();
    const TextRangeSpan range    = ClampTextRangeSpan(start, end, text.size());
    const TextRangeSpan expandedRange =
        (host && control)
            ? TryGetEnclosingTextRangeVisualLineSpan(*host, *control, text, range.start).value_or(GetTextRangeLineSpanAtPosition(text, range.start))
            : GetTextRangeLineSpanAtPosition(text, range.start);

    outStart = expandedRange.start;
    outEnd   = expandedRange.end;
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::ExecuteMoveByVisualLineOnWindowThread(
    size_t start, size_t end, int count, size_t& outStart, size_t& outEnd, int& outMoved) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());

    ControlHost* const host      = ResolveHost();
    const Control* const control = ResolveControl();
    const std::wstring text      = control ? (_textOverride ? _textOverride.value() : GetControlAccessibleTextRangeText(control)) : ResolveText();
    const TextRangeSpan range    = ClampTextRangeSpan(start, end, text.size());
    const TextRangeSpanMoveResult moveResult =
        (host && control) ? TryMoveTextRangeSpanByVisualLine(*host, *control, text, range, count).value_or(MoveTextRangeSpanByLine(text, range, count))
                          : MoveTextRangeSpanByLine(text, range, count);

    outStart = moveResult.range.start;
    outEnd   = moveResult.range.end;
    outMoved = moveResult.moved;
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::ExecuteMoveEndpointByVisualLineOnWindowThread(
    size_t start, size_t end, TextPatternRangeEndpoint endpoint, int count, size_t& outStart, size_t& outEnd, int& outMoved) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());

    ControlHost* const host       = ResolveHost();
    const Control* const control  = ResolveControl();
    const std::wstring text       = control ? (_textOverride ? _textOverride.value() : GetControlAccessibleTextRangeText(control)) : ResolveText();
    const TextRangeSpan range     = ClampTextRangeSpan(start, end, text.size());
    const size_t endpointPosition = GetTextRangeEndpointPosition(range, endpoint);

    const TextRangeUnitMoveResult moveResult = (host && control) ? TryMoveTextRangePositionByVisualLine(*host, *control, text, endpointPosition, count)
                                                                       .value_or(MoveTextRangePositionByLine(text, endpointPosition, count))
                                                                 : MoveTextRangePositionByLine(text, endpointPosition, count);
    outMoved                                 = moveResult.moved;
    const size_t movedTo                     = moveResult.position;
    if (endpoint == TextPatternRangeEndpoint_Start)
    {
        outStart = movedTo;
        outEnd   = range.end < outStart ? outStart : range.end;
    }
    else
    {
        outEnd   = movedTo;
        outStart = outEnd < range.start ? outEnd : range.start;
    }

    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::ExecuteResolveBoundsOnWindowThread(size_t start,
                                                                           size_t end,
                                                                           std::vector<D2D1_RECT_F>& outBoundsDip,
                                                                           float& outDipToPixelScale) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());

    outBoundsDip.clear();
    outDipToPixelScale = 1.0f;

    ControlHost* const host      = ResolveHost();
    const Control* const control = ResolveControl();
    if (! host || ! control)
    {
        return S_OK;
    }

    outDipToPixelScale        = static_cast<float>(host->GetDpi()) / static_cast<float>(USER_DEFAULT_SCREEN_DPI);
    const std::wstring text   = _textOverride ? _textOverride.value() : GetControlAccessibleTextRangeText(control);
    const TextRangeSpan range = ClampTextRangeSpan(start, end, text.size());
    if (range.start == range.end)
    {
        return S_OK;
    }

    outBoundsDip = TryResolveTextRangeCaretRects(*host, *control, text, range).value_or(std::vector<D2D1_RECT_F>{ResolveTextPatternViewportRect(control)});
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::AddToSelection() noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::RemoveFromSelection() noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::ScrollIntoView(BOOL /*alignToTop*/) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    return S_OK;
}

HRESULT AccessibilityTextRangeProvider::GetChildren(SAFEARRAY** outChildren) noexcept
{
    if (outChildren)
        *outChildren = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outChildren)
    {
        return E_POINTER;
    }

    return SetProviderArray(outChildren, {});
}

bool AccessibilityTextRangeProvider::IsCurrentThreadWindowThread() const noexcept
{
    return _target &&
           (_target->embedded ? _target->threadId == GetCurrentThreadId() : _hwnd && GetWindowThreadProcessId(_hwnd, nullptr) == GetCurrentThreadId());
}

HRESULT DispatchAccessibilityUiActionToWindowThread(HWND hwnd, AccessibilityUiActionRequest& request) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return UIA_E_ELEMENTNOTAVAILABLE;
    }
    // Without its registered message the action cannot reach the window's thread: it fails as a post that reports no
    // Win32 error does.
    const WndMsg::RegisteredMessage actionMessage = WndMsg::AccessibilityUiThreadAction();
    if (! actionMessage)
    {
        return UIA_E_ELEMENTNOTAVAILABLE;
    }

    auto dispatch = std::shared_ptr<AccessibilityUiActionDispatch>(new (std::nothrow) AccessibilityUiActionDispatch());
    if (! dispatch)
    {
        return E_OUTOFMEMORY;
    }

    dispatch->request = std::move(request);
    if (dispatch->request.provider)
    {
        dispatch->providerKeepAlive = static_cast<IRawElementProviderSimple*>(dispatch->request.provider);
    }
    if (dispatch->request.textRangeProvider)
    {
        dispatch->textRangeProviderKeepAlive = static_cast<ITextRangeProvider*>(dispatch->request.textRangeProvider);
    }

    dispatch->completedEvent.reset(::CreateEventW(nullptr, TRUE, FALSE, nullptr));
    if (! dispatch->completedEvent)
    {
        const DWORD lastError = ::GetLastError();
        return lastError != 0u ? HRESULT_FROM_WIN32(lastError) : E_OUTOFMEMORY;
    }

    auto payload = std::unique_ptr<AccessibilityUiActionPayload>(new (std::nothrow) AccessibilityUiActionPayload());
    if (! payload)
    {
        return E_OUTOFMEMORY;
    }
    payload->dispatch = dispatch;

    ::SetLastError(ERROR_SUCCESS);
    if (! PostMessagePayload(hwnd, actionMessage.value, 0, std::move(payload)))
    {
        const DWORD lastError = ::GetLastError();
        return lastError != 0u ? HRESULT_FROM_WIN32(lastError) : static_cast<HRESULT>(UIA_E_ELEMENTNOTAVAILABLE);
    }

#if DXUI_ENABLE_DIAGNOSTICS
    if (const HANDLE postedEvent = g_accessibilityUiActionPostedEvent.load(std::memory_order_acquire); postedEvent)
    {
        static_cast<void>(::SetEvent(postedEvent));
    }
#endif

    const DWORD waitResult = ::WaitForSingleObject(dispatch->completedEvent.get(), AccessibilityUiActionDispatchTimeoutMs());
    if (waitResult != WAIT_OBJECT_0)
    {
        if (waitResult == WAIT_TIMEOUT)
        {
            AccessibilityUiActionDispatch::State expected = AccessibilityUiActionDispatch::State::Pending;
            if (dispatch->state.compare_exchange_strong(
                    expected, AccessibilityUiActionDispatch::State::Abandoned, std::memory_order_acq_rel, std::memory_order_acquire))
            {
                return HRESULT_FROM_WIN32(ERROR_TIMEOUT);
            }

            if (expected == AccessibilityUiActionDispatch::State::Taken && ::WaitForSingleObject(dispatch->completedEvent.get(), 0u) == WAIT_OBJECT_0)
            {
                request = std::move(dispatch->request);
                return request.result;
            }
            return HRESULT_FROM_WIN32(ERROR_TIMEOUT);
        }

        const DWORD lastError = ::GetLastError();
        return lastError != 0u ? HRESULT_FROM_WIN32(lastError) : E_FAIL;
    }

    request = std::move(dispatch->request);
    return request.result;
}

HRESULT AccessibilityTextRangeProvider::DispatchActionToWindowThread(AccessibilityUiActionRequest& request) const noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (_target && _target->embedded)
        return RPC_E_WRONG_THREAD;
    return DispatchAccessibilityUiActionToWindowThread(_hwnd, request);
}

HRESULT AccessibilityTextRangeProvider::DispatchVisualLineExpansionToWindowThread(size_t start, size_t end, size_t& outStart, size_t& outEnd) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    AccessibilityUiActionRequest request{};
    request.textRangeProvider    = this;
    request.kind                 = AccessibilityUiActionKind::ExpandTextRangeToVisualLine;
    request.textRangeStart       = start;
    request.textRangeEnd         = end;
    request.textRangeResultStart = start;
    request.textRangeResultEnd   = end;

    const HRESULT hr = DispatchActionToWindowThread(request);
    outStart         = request.textRangeResultStart;
    outEnd           = request.textRangeResultEnd;
    return hr;
}

HRESULT AccessibilityTextRangeProvider::DispatchLineMovementToWindowThread(
    size_t start, size_t end, int count, size_t& outStart, size_t& outEnd, int& outMoved) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    AccessibilityUiActionRequest request{};
    request.textRangeProvider    = this;
    request.kind                 = AccessibilityUiActionKind::MoveTextRangeByVisualLine;
    request.textRangeStart       = start;
    request.textRangeEnd         = end;
    request.textRangeMoveCount   = count;
    request.textRangeMoved       = 0;
    request.textRangeResultStart = start;
    request.textRangeResultEnd   = end;

    const HRESULT hr = DispatchActionToWindowThread(request);
    outStart         = request.textRangeResultStart;
    outEnd           = request.textRangeResultEnd;
    outMoved         = request.textRangeMoved;
    return hr;
}

HRESULT AccessibilityTextRangeProvider::DispatchEndpointLineMovementToWindowThread(
    size_t start, size_t end, TextPatternRangeEndpoint endpoint, int count, size_t& outStart, size_t& outEnd, int& outMoved) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    AccessibilityUiActionRequest request{};
    request.textRangeProvider    = this;
    request.kind                 = AccessibilityUiActionKind::MoveTextRangeEndpointByVisualLine;
    request.textRangeStart       = start;
    request.textRangeEnd         = end;
    request.textRangeEndpoint    = endpoint;
    request.textRangeMoveCount   = count;
    request.textRangeMoved       = 0;
    request.textRangeResultStart = start;
    request.textRangeResultEnd   = end;

    const HRESULT hr = DispatchActionToWindowThread(request);
    outStart         = request.textRangeResultStart;
    outEnd           = request.textRangeResultEnd;
    outMoved         = request.textRangeMoved;
    return hr;
}

HRESULT AccessibilityTextRangeProvider::DispatchBoundingRectanglesToWindowThread(size_t start,
                                                                                 size_t end,
                                                                                 std::vector<D2D1_RECT_F>& outBoundsDip,
                                                                                 float& outDipToPixelScale) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    AccessibilityUiActionRequest request{};
    request.textRangeProvider        = this;
    request.kind                     = AccessibilityUiActionKind::ResolveTextRangeBounds;
    request.textRangeStart           = start;
    request.textRangeEnd             = end;
    request.textRangeDipToPixelScale = outDipToPixelScale;

    const HRESULT hr   = DispatchActionToWindowThread(request);
    outBoundsDip       = std::move(request.textRangeBoundsDip);
    outDipToPixelScale = request.textRangeDipToPixelScale;
    return hr;
}

// The current snapshot, or null when the element's control is gone: an embedded element compares the control at its
// path with the one in the snapshot it pinned, a window-host element with the identity it recorded at creation.
[[nodiscard]] std::shared_ptr<const AccessibilitySnapshot> GuardedElementSnapshot(WindowHostAccessibilityTarget* target,
                                                                                  HWND hwnd,
                                                                                  const std::shared_ptr<const AccessibilitySnapshot>& original,
                                                                                  const ControlPath* path,
                                                                                  const AccessibilityControlIdentity& identity) noexcept
{
    auto snapshot = CaptureAccessibilitySnapshot(target, hwnd);
    if (! target || ! snapshot)
        return snapshot;
    if (! target->embedded)
    {
        if (! path || identity.value == 0u)
            return snapshot;
        const auto* now = FindControlNavigationRecord(*snapshot, *path);
        const bool same = now && ! identity.lifetime.expired() && ! identity.lifetime.owner_before(now->controlLifetime) &&
                          ! now->controlLifetime.owner_before(identity.lifetime);
        return same ? snapshot : nullptr;
    }
    if (path)
    {
        const auto* before = original ? FindControlNavigationRecord(*original, *path) : nullptr;
        const auto* now    = FindControlNavigationRecord(*snapshot, *path);
        if (! before || ! now || before->controlLifetime.expired() || before->controlLifetime.owner_before(now->controlLifetime) ||
            now->controlLifetime.owner_before(before->controlLifetime))
            return nullptr;
    }
    return snapshot;
}
std::shared_ptr<const AccessibilitySnapshot> AccessibilityTextRangeProvider::CaptureSnapshot() const noexcept
{
    return GuardedElementSnapshot(_target, _hwnd, _snapshot, &_path, _identity);
}
std::shared_ptr<const AccessibilitySnapshot> AccessibilityProvider::CaptureSnapshot() const noexcept
{
    if (_kind != AccessibilityFragmentKind::Root || ! _target || _target->embedded)
        return GuardedElementSnapshot(_target, _hwnd, _snapshot, _kind == AccessibilityFragmentKind::Root ? nullptr : &_path, _identity);
    // A window's root element that stands for the semantic control collapsed into it is that control's element, and lives
    // as long as that control stays collapsed into it, as every element lives with its control: neither a retained root
    // nor an action queued on it reaches a control that replaced it, and the window gives newly acquiring clients a fresh
    // root (AcquireCanonicalRootProvider). A root that stood for no control represents the host until one collapses into it.
    auto snapshot = CaptureAccessibilitySnapshot(_target, _hwnd);
    if (! snapshot)
        return snapshot;
    const bool collapsed = SnapshotHasCollapsedSemanticRoot(*snapshot);
    if (_identity.value == 0u)
        return collapsed ? nullptr : snapshot;
    const auto* now = collapsed ? FindControlNavigationRecord(*snapshot, snapshot->semanticControlOrder.front()) : nullptr;
    return now && ! _identity.lifetime.expired() && SameControlLifetime(_identity.lifetime, now->controlLifetime) ? snapshot : nullptr;
}

ControlHost* AccessibilityTextRangeProvider::ResolveHost() const noexcept
{
    if (! CaptureSnapshot())
        return nullptr;
    return (_target && _target->hwnd == _hwnd) ? _target->ResolveHost() : nullptr;
}

const Control* AccessibilityTextRangeProvider::ResolveControl() const noexcept
{
    ControlHost* host = ResolveHost();
    if (! host || ! IsControlPathVisible(host->GetRoot(), _path))
    {
        return nullptr;
    }

    return ResolveIdentifiedControlAtPath(host->GetRoot(), _path, _identity);
}

Control* AccessibilityTextRangeProvider::ResolveMutableControl() const noexcept
{
    ControlHost* host = ResolveHost();
    if (! host || ! IsControlPathVisible(host->GetRoot(), _path))
    {
        return nullptr;
    }

    return ResolveIdentifiedControlAtPath(host->GetRoot(), _path, _identity);
}

std::wstring AccessibilityTextRangeProvider::ResolveText() const
{
    if (_textOverride)
    {
        return _textOverride.value();
    }

    const AccessibilityControlNavigationSnapshot* record =
        (_snapshot && _snapshot->alive && _snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*_snapshot, _path) : nullptr;
    if (! record || ! record->controlSupportsText)
    {
        return {};
    }

    return record->controlAccessibleText;
}

TextRangeSpan AccessibilityTextRangeProvider::ClampCurrentRange(size_t textLength) const noexcept
{
    return ClampTextRangeSpan(_rangeStart, _rangeEnd, textLength);
}

ITextRangeProvider* AccessibilityTextRangeProvider::CreateRange(size_t start, size_t end) const noexcept
{
    WindowHostAccessibilityTarget* target = _target;
    if (target)
    {
        static_cast<void>(target->AddRef());
    }

    AccessibilityTextRangeProvider* provider = nullptr;
    if (_textOverride)
    {
        provider = new (std::nothrow) AccessibilityTextRangeProvider(target, _hwnd, _path, start, end, _textOverride.value());
    }
    else if (_boundsOverrideDip && start == _rangeStart && end == _rangeEnd)
    {
        provider = new (std::nothrow) AccessibilityTextRangeProvider(target, _hwnd, _path, start, end, _boundsOverrideDip.value());
    }
    else
    {
        provider = new (std::nothrow) AccessibilityTextRangeProvider(target, _hwnd, _path, start, end);
    }

    if (! provider && target)
    {
        static_cast<void>(target->Release());
    }
    return provider ? static_cast<ITextRangeProvider*>(provider) : nullptr;
}

AccessibilityPatternQueryResult AccessibilityProvider::QueryPattern(AccessibilityPatternKind patternKind) noexcept
{
    const auto makeResult = []<typename TInterface>(TInterface* provider) noexcept -> AccessibilityPatternQueryResult
    { return AccessibilityPatternQueryResult{.queryInterface = static_cast<void*>(provider), .patternProvider = static_cast<IUnknown*>(provider)}; };

    if (_kind == AccessibilityFragmentKind::TreeItem && patternKind == AccessibilityPatternKind::SelectionItem)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
        const AccessibilityControlNavigationSnapshot* record =
            (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*snapshot, _path) : nullptr;
        return (record && SnapshotContainsTreeItem(*record, _treeItemId)) ? makeResult(static_cast<ISelectionItemProvider*>(this))
                                                                          : AccessibilityPatternQueryResult{};
    }

    if (_kind == AccessibilityFragmentKind::TreeItem && patternKind == AccessibilityPatternKind::ExpandCollapse)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
        const AccessibilityControlNavigationSnapshot* record =
            (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*snapshot, _path) : nullptr;
        const AccessibilityTreeItemSnapshotRecord* item = record ? FindSnapshotTreeItemRecord(*record, _treeItemId) : nullptr;
        return (item && item->hasChildren) ? makeResult(static_cast<IExpandCollapseProvider*>(this)) : AccessibilityPatternQueryResult{};
    }

    if (_kind == AccessibilityFragmentKind::GridRow)
    {
        if (patternKind != AccessibilityPatternKind::SelectionItem)
        {
            return {};
        }

        const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
        const AccessibilityControlNavigationSnapshot* record =
            (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*snapshot, _path) : nullptr;
        return (record && SnapshotSupportsGridSelectionItem(*record, _gridRowId)) ? makeResult(static_cast<ISelectionItemProvider*>(this))
                                                                                  : AccessibilityPatternQueryResult{};
    }

    if (_kind == AccessibilityFragmentKind::GridCell)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot   = CaptureSnapshot();
        const std::optional<AccessibilityGridCellSnapshotRecord> cell = (snapshot && snapshot->alive && snapshot->hasRetainedRoot)
                                                                            ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex)
                                                                            : std::nullopt;
        if (! cell)
        {
            return {};
        }

        switch (patternKind)
        {
            case AccessibilityPatternKind::Invoke:
            case AccessibilityPatternKind::Text:
            case AccessibilityPatternKind::TextEdit:
            case AccessibilityPatternKind::Selection:
            case AccessibilityPatternKind::Table:
            case AccessibilityPatternKind::SelectionItem:
            case AccessibilityPatternKind::ExpandCollapse: return {};
            case AccessibilityPatternKind::Toggle:
                return SnapshotGridCellSupportsTogglePattern(cell.value()) ? makeResult(static_cast<IToggleProvider*>(this))
                                                                           : AccessibilityPatternQueryResult{};
            case AccessibilityPatternKind::Value:
                return SnapshotGridCellSupportsValuePattern(cell.value()) ? makeResult(static_cast<IValueProvider*>(this)) : AccessibilityPatternQueryResult{};
            case AccessibilityPatternKind::RangeValue:
                return SnapshotGridCellSupportsRangeValuePattern(cell.value()) ? makeResult(static_cast<IRangeValueProvider*>(this))
                                                                               : AccessibilityPatternQueryResult{};
            case AccessibilityPatternKind::GridItem: return makeResult(static_cast<IGridItemProvider*>(this));
            case AccessibilityPatternKind::TableItem:
                return (cell->controlRecord && cell->controlRecord->gridColumnCount > 0u) ? makeResult(static_cast<ITableItemProvider*>(this))
                                                                                          : AccessibilityPatternQueryResult{};
        }
        return {};
    }

    if (_kind == AccessibilityFragmentKind::TextFieldPasswordRevealButton)
    {
        if (patternKind != AccessibilityPatternKind::Invoke)
        {
            return {};
        }

        const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
        const AccessibilityControlNavigationSnapshot* record =
            (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*snapshot, _path) : nullptr;
        return (record && record->hasPasswordRevealButton) ? makeResult(static_cast<IInvokeProvider*>(this)) : AccessibilityPatternQueryResult{};
    }

    if (_kind != AccessibilityFragmentKind::Control && _kind != AccessibilityFragmentKind::Root)
    {
        return {};
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record)
    {
        return {};
    }

    switch (patternKind)
    {
        case AccessibilityPatternKind::Invoke:
            return record->controlSupportsInvoke ? makeResult(static_cast<IInvokeProvider*>(this)) : AccessibilityPatternQueryResult{};
        case AccessibilityPatternKind::Toggle:
            return record->controlSupportsToggle ? makeResult(static_cast<IToggleProvider*>(this)) : AccessibilityPatternQueryResult{};
        case AccessibilityPatternKind::Value:
            return record->controlSupportsValue ? makeResult(static_cast<IValueProvider*>(this)) : AccessibilityPatternQueryResult{};
        case AccessibilityPatternKind::Text:
            return record->controlSupportsText ? makeResult(static_cast<ITextProvider*>(static_cast<ITextEditProvider*>(this)))
                                               : AccessibilityPatternQueryResult{};
        case AccessibilityPatternKind::TextEdit:
            return record->controlSupportsText ? makeResult(static_cast<ITextEditProvider*>(this)) : AccessibilityPatternQueryResult{};
        case AccessibilityPatternKind::RangeValue:
            return record->controlSupportsRangeValue ? makeResult(static_cast<IRangeValueProvider*>(this)) : AccessibilityPatternQueryResult{};
        case AccessibilityPatternKind::Selection:
            return record->controlSupportsSelection ? makeResult(static_cast<ISelectionProvider*>(this)) : AccessibilityPatternQueryResult{};
        case AccessibilityPatternKind::Table:
            return record->controlSupportsTable ? makeResult(static_cast<ITableProvider*>(this)) : AccessibilityPatternQueryResult{};
        case AccessibilityPatternKind::SelectionItem:
        case AccessibilityPatternKind::GridItem:
        case AccessibilityPatternKind::TableItem: return {};
        case AccessibilityPatternKind::ExpandCollapse:
            return record->controlDisclosureExpanded.has_value() ? makeResult(static_cast<IExpandCollapseProvider*>(this)) : AccessibilityPatternQueryResult{};
    }
    return {};
}

HRESULT AccessibilityProvider::QueryInterface(REFIID riid, void** ppvObject) noexcept
{
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! ppvObject)
    {
        return E_POINTER;
    }

    *ppvObject = nullptr;
    if (riid == __uuidof(IUnknown) || riid == __uuidof(IRawElementProviderSimple))
    {
        *ppvObject = static_cast<IRawElementProviderSimple*>(this);
        AddRef();
        return S_OK;
    }
    if (riid == __uuidof(IRawElementProviderFragment))
    {
        *ppvObject = static_cast<IRawElementProviderFragment*>(this);
        AddRef();
        return S_OK;
    }
    if (_kind == AccessibilityFragmentKind::Root && riid == __uuidof(IRawElementProviderFragmentRoot))
    {
        *ppvObject = static_cast<IRawElementProviderFragmentRoot*>(this);
        AddRef();
        return S_OK;
    }

    const std::optional<AccessibilityPatternKind> patternKind = PatternKindFromInterfaceId(riid);
    if (! patternKind)
    {
        return E_NOINTERFACE;
    }

    const AccessibilityPatternQueryResult pattern = QueryPattern(patternKind.value());
    if (! pattern.queryInterface)
    {
        return E_NOINTERFACE;
    }

    *ppvObject = pattern.queryInterface;
    AddRef();
    return S_OK;
}

ULONG AccessibilityProvider::AddRef() noexcept
{
    return _referenceCount.fetch_add(1u, std::memory_order_relaxed) + 1u;
}

ULONG AccessibilityProvider::Release() noexcept
{
    const ULONG remaining = _referenceCount.fetch_sub(1u, std::memory_order_acq_rel) - 1u;
    if (remaining == 0u)
    {
        if (_target)
        {
            static_cast<void>(_target->Release());
            _target = nullptr;
        }
        delete this;
    }
    return remaining;
}

HRESULT AccessibilityProvider::get_ProviderOptions(ProviderOptions* outOptions) noexcept
{
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outOptions)
    {
        return E_POINTER;
    }

    *outOptions =
        _target && _target->embedded
            ? static_cast<ProviderOptions>(ProviderOptions_ServerSideProvider | ProviderOptions_UseComThreading | ProviderOptions_ProviderOwnsSetFocus)
            : ProviderOptions_ServerSideProvider;
    return S_OK;
}

HRESULT AccessibilityProvider::GetPatternProvider(PATTERNID patternId, IUnknown** outProvider) noexcept
{
    if (outProvider)
        *outProvider = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outProvider)
    {
        return E_POINTER;
    }

    *outProvider                                              = nullptr;
    const std::optional<AccessibilityPatternKind> patternKind = PatternKindFromPatternId(patternId);
    if (! patternKind)
    {
        return S_OK;
    }

    const AccessibilityPatternQueryResult pattern = QueryPattern(patternKind.value());
    if (pattern.patternProvider)
    {
        *outProvider = pattern.patternProvider;
        AddRef();
    }

    return S_OK;
}

HRESULT AccessibilityProvider::GetPropertyValue(PROPERTYID propertyId, VARIANT* outValue) noexcept
{
    if (outValue)
        *outValue = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outValue)
    {
        return E_POINTER;
    }

    VariantInit(outValue);
    if (_kind == AccessibilityFragmentKind::TextFieldPasswordRevealButton)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
        const AccessibilityControlNavigationSnapshot* record =
            (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*snapshot, _path) : nullptr;
        const bool buttonVisible = record && record->hasPasswordRevealButton;

        switch (propertyId)
        {
            case UIA_ControlTypePropertyId: *outValue = VariantFromInt(UIA_ButtonControlTypeId); return S_OK;
            case UIA_NamePropertyId:
            {
                const std::wstring_view name = buttonVisible ? std::wstring_view(record->passwordRevealButtonAccessibleName) : std::wstring_view{};
                return SetVariantFromString(outValue, name);
            }
            case UIA_IsControlElementPropertyId:
            case UIA_IsContentElementPropertyId: *outValue = VariantFromBool(buttonVisible); return S_OK;
            case UIA_IsEnabledPropertyId: *outValue = VariantFromBool(buttonVisible && record->passwordRevealButtonEnabled); return S_OK;
            case UIA_IsKeyboardFocusablePropertyId: *outValue = VariantFromBool(buttonVisible); return S_OK;
            case UIA_HasKeyboardFocusPropertyId: *outValue = VariantFromBool(false); return S_OK;
            case UIA_IsOffscreenPropertyId: *outValue = VariantFromBool(! buttonVisible); return S_OK;
            default: return S_OK;
        }
    }

    if (propertyId == UIA_SelectionItemIsSelectedPropertyId && (_kind == AccessibilityFragmentKind::TreeItem || _kind == AccessibilityFragmentKind::GridRow))
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
        const AccessibilityControlNavigationSnapshot* record =
            (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*snapshot, _path) : nullptr;
        if (_kind == AccessibilityFragmentKind::TreeItem)
        {
            if (! record || ! SnapshotContainsTreeItem(*record, _treeItemId))
            {
                return UIA_E_ELEMENTNOTAVAILABLE;
            }
            *outValue = VariantFromBool(SnapshotTreeItemIsSelected(*record, _treeItemId));
            return S_OK;
        }

        if (record && SnapshotSupportsGridSelectionItem(*record, _gridRowId))
        {
            *outValue = VariantFromBool(SnapshotGridRowIsSelected(*record, _gridRowId));
        }
        return S_OK;
    }
    if (_kind == AccessibilityFragmentKind::GridRow)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
        const AccessibilityControlNavigationSnapshot* record =
            (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*snapshot, _path) : nullptr;
        const AccessibilityGridRowSnapshotRecord* row = record ? FindSnapshotGridRowRecord(*record, _gridRowId) : nullptr;
        if (! record || ! row)
        {
            return S_OK;
        }

        switch (propertyId)
        {
            case UIA_ControlTypePropertyId: *outValue = VariantFromInt(UIA_DataItemControlTypeId); return S_OK;
            case UIA_NamePropertyId: return SetVariantFromString(outValue, row->gridRowAccessibleName);
            case UIA_IsControlElementPropertyId:
            case UIA_IsContentElementPropertyId:
            case UIA_IsKeyboardFocusablePropertyId: *outValue = VariantFromBool(true); return S_OK;
            case UIA_IsEnabledPropertyId: *outValue = VariantFromBool(record->gridIsEnabled); return S_OK;
            case UIA_HasKeyboardFocusPropertyId:
                *outValue = VariantFromBool(record->controlHasFocus && snapshot->focusedFragment.has_value() &&
                                            snapshot->focusedFragment->kind == AccessibilityFragmentKind::GridRow &&
                                            AreControlPathsEqual(snapshot->focusedFragment->path, _path) && snapshot->focusedFragment->gridRowId == _gridRowId);
                return S_OK;
            case UIA_IsOffscreenPropertyId:
                *outValue = VariantFromBool(! FindSnapshotFragmentBounds(*snapshot, _kind, _path, 0u, _gridRowId, 0u).has_value());
                return S_OK;
            case UIA_SelectionItemIsSelectedPropertyId: *outValue = VariantFromBool(SnapshotGridRowIsSelected(*record, _gridRowId)); return S_OK;
            default: return S_OK;
        }
    }
    if (_kind == AccessibilityFragmentKind::TreeItem)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
        const AccessibilityControlNavigationSnapshot* record =
            (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*snapshot, _path) : nullptr;
        const AccessibilityTreeItemSnapshotRecord* item = record ? FindSnapshotTreeItemRecord(*record, _treeItemId) : nullptr;
        if (! record || ! item)
        {
            return UIA_E_ELEMENTNOTAVAILABLE;
        }

        switch (propertyId)
        {
            case UIA_ControlTypePropertyId: *outValue = VariantFromInt(UIA_TreeItemControlTypeId); return S_OK;
            case UIA_NamePropertyId: return SetVariantFromString(outValue, item->text);
            case UIA_IsControlElementPropertyId:
            case UIA_IsContentElementPropertyId:
            case UIA_IsKeyboardFocusablePropertyId: *outValue = VariantFromBool(true); return S_OK;
            case UIA_IsEnabledPropertyId: *outValue = VariantFromBool(record->treeIsEnabled); return S_OK;
            case UIA_HasKeyboardFocusPropertyId:
                *outValue = VariantFromBool(record->controlHasFocus && SnapshotTreeItemIsFocused(*record, _treeItemId));
                return S_OK;
            case UIA_IsOffscreenPropertyId:
                *outValue = VariantFromBool(! FindSnapshotFragmentBounds(*snapshot, _kind, _path, item->visibleIndex, 0u, 0u).has_value());
                return S_OK;
            case UIA_LevelPropertyId:
                *outValue = VariantFromInt(static_cast<LONG>((std::min)(item->depth + 1u, static_cast<size_t>((std::numeric_limits<LONG>::max)()))));
                return S_OK;
            case UIA_ExpandCollapseExpandCollapseStatePropertyId:
                if (item->hasChildren)
                {
                    *outValue = VariantFromInt(item->expanded ? ExpandCollapseState_Expanded : ExpandCollapseState_Collapsed);
                }
                return S_OK;
            default: return S_OK;
        }
    }
    if (_kind == AccessibilityFragmentKind::Control && (propertyId == UIA_GridRowCountPropertyId || propertyId == UIA_GridColumnCountPropertyId))
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
        const AccessibilityControlNavigationSnapshot* record =
            (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*snapshot, _path) : nullptr;
        if (! record || ! record->isGrid)
        {
            return S_OK;
        }

        const size_t count = propertyId == UIA_GridRowCountPropertyId ? record->gridRowCount : record->gridColumnCount;
        *outValue          = VariantFromInt(static_cast<LONG>((std::min)(count, static_cast<size_t>((std::numeric_limits<LONG>::max)()))));
        return S_OK;
    }
    if (_kind == AccessibilityFragmentKind::GridHeader)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
        const AccessibilityControlNavigationSnapshot* record =
            (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*snapshot, _path) : nullptr;
        const AccessibilityGridHeaderSnapshotRecord* header = record ? FindSnapshotGridHeaderRecord(*record, _gridColumnIndex) : nullptr;
        if (! record || ! header)
        {
            return S_OK;
        }

        switch (propertyId)
        {
            case UIA_ControlTypePropertyId: *outValue = VariantFromInt(UIA_HeaderItemControlTypeId); return S_OK;
            case UIA_NamePropertyId: return SetVariantFromString(outValue, header->gridHeaderName);
            case UIA_IsControlElementPropertyId:
            case UIA_IsContentElementPropertyId: *outValue = VariantFromBool(true); return S_OK;
            case UIA_IsEnabledPropertyId: *outValue = VariantFromBool(record->gridIsEnabled); return S_OK;
            case UIA_IsKeyboardFocusablePropertyId:
            case UIA_HasKeyboardFocusPropertyId: *outValue = VariantFromBool(false); return S_OK;
            case UIA_IsOffscreenPropertyId:
                *outValue = VariantFromBool(! FindSnapshotFragmentBounds(*snapshot, _kind, _path, 0u, 0u, _gridColumnIndex).has_value());
                return S_OK;
            default: return S_OK;
        }
    }
    if (_kind == AccessibilityFragmentKind::GridCell)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot   = CaptureSnapshot();
        const std::optional<AccessibilityGridCellSnapshotRecord> cell = (snapshot && snapshot->alive && snapshot->hasRetainedRoot)
                                                                            ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex)
                                                                            : std::nullopt;
        const AccessibilityGridCellStateSnapshotRecord* cellRecord    = cell ? cell->cellRecord : nullptr;
        if (! cell || ! cellRecord)
        {
            return S_OK;
        }

        switch (propertyId)
        {
            case UIA_ControlTypePropertyId: *outValue = VariantFromInt(cellRecord->gridCellControlTypeId); return S_OK;
            case UIA_NamePropertyId: return SetVariantFromString(outValue, cellRecord->gridCellAccessibleText);
            case UIA_HelpTextPropertyId:
                if (! cellRecord->gridCellHelpText.empty())
                {
                    return SetVariantFromString(outValue, cellRecord->gridCellHelpText);
                }
                return S_OK;
            case UIA_IsControlElementPropertyId:
            case UIA_IsContentElementPropertyId: *outValue = VariantFromBool(true); return S_OK;
            case UIA_IsEnabledPropertyId:
                *outValue = VariantFromBool(cell->controlRecord && cell->controlRecord->gridIsEnabled && cellRecord->gridCellEnabled);
                return S_OK;
            case UIA_IsKeyboardFocusablePropertyId:
            case UIA_HasKeyboardFocusPropertyId: *outValue = VariantFromBool(false); return S_OK;
            case UIA_IsOffscreenPropertyId:
                *outValue = VariantFromBool(! FindSnapshotFragmentBounds(*snapshot, _kind, _path, 0u, _gridRowId, _gridColumnIndex).has_value());
                return S_OK;
            case UIA_ToggleToggleStatePropertyId:
                if (SnapshotGridCellSupportsTogglePattern(cell.value()))
                {
                    *outValue = VariantFromInt(cellRecord->gridCellChecked ? ToggleState_On : ToggleState_Off);
                }
                return S_OK;
            case UIA_ValueValuePropertyId:
                if (SnapshotGridCellSupportsValuePattern(cell.value()))
                {
                    return SetVariantFromString(outValue, cellRecord->gridCellAccessibleText);
                }
                return S_OK;
            case UIA_ValueIsReadOnlyPropertyId:
                if (SnapshotGridCellSupportsValuePattern(cell.value()) || SnapshotGridCellSupportsRangeValuePattern(cell.value()))
                {
                    *outValue = VariantFromBool(true);
                }
                return S_OK;
            case UIA_RangeValueValuePropertyId:
                if (SnapshotGridCellSupportsRangeValuePattern(cell.value()))
                {
                    *outValue = VariantFromDouble(cellRecord->gridCellRangeValue);
                }
                return S_OK;
            case UIA_RangeValueMinimumPropertyId:
                if (SnapshotGridCellSupportsRangeValuePattern(cell.value()))
                {
                    *outValue = VariantFromDouble(0.0);
                }
                return S_OK;
            case UIA_RangeValueMaximumPropertyId:
                if (SnapshotGridCellSupportsRangeValuePattern(cell.value()))
                {
                    *outValue = VariantFromDouble(1.0);
                }
                return S_OK;
            case UIA_RangeValueLargeChangePropertyId:
            case UIA_RangeValueSmallChangePropertyId:
                if (SnapshotGridCellSupportsRangeValuePattern(cell.value()))
                {
                    *outValue = VariantFromDouble(0.0);
                }
                return S_OK;
            default: return S_OK;
        }
    }

    if (_kind != AccessibilityFragmentKind::Control && _kind != AccessibilityFragmentKind::Root)
    {
        return S_OK;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record)
    {
        if (_kind == AccessibilityFragmentKind::Root)
        {
            switch (propertyId)
            {
                case UIA_ControlTypePropertyId: *outValue = VariantFromInt(UIA_PaneControlTypeId); return S_OK;
                case UIA_IsControlElementPropertyId:
                case UIA_IsContentElementPropertyId:
                case UIA_IsEnabledPropertyId:
                case UIA_IsKeyboardFocusablePropertyId: *outValue = VariantFromBool(true); return S_OK;
                case UIA_HasKeyboardFocusPropertyId: *outValue = VariantFromBool(false); return S_OK;
                case UIA_NamePropertyId:
                    if (snapshot)
                    {
                        return SetVariantFromString(outValue, snapshot->windowName);
                    }
                    return S_OK;
                default: return S_OK;
            }
        }
        return S_OK;
    }

    switch (propertyId)
    {
        case UIA_ControlTypePropertyId: *outValue = VariantFromInt(record->controlTypeId); return S_OK;
        case UIA_NamePropertyId: return SetVariantFromString(outValue, record->controlAccessibleName);
        case UIA_HelpTextPropertyId: return SetVariantFromString(outValue, record->controlAccessibleHelpText);
        case UIA_AutomationIdPropertyId: return SetVariantFromString(outValue, record->controlAutomationId);
        case UIA_ExpandCollapseExpandCollapseStatePropertyId:
            if (record->controlVisible && record->controlDisclosureExpanded.has_value())
            {
                *outValue = VariantFromInt(record->controlDisclosureExpanded.value() ? ExpandCollapseState_Expanded : ExpandCollapseState_Collapsed);
            }
            return S_OK;
        case UIA_IsControlElementPropertyId:
        case UIA_IsContentElementPropertyId: *outValue = VariantFromBool(record->controlVisible); return S_OK;
        case UIA_IsEnabledPropertyId: *outValue = VariantFromBool(record->controlVisible && record->controlEnabled); return S_OK;
        case UIA_IsKeyboardFocusablePropertyId: *outValue = VariantFromBool(record->controlVisible && record->controlFocusable); return S_OK;
        case UIA_HasKeyboardFocusPropertyId: *outValue = VariantFromBool(record->controlVisible && record->controlHasFocus); return S_OK;
        case UIA_IsOffscreenPropertyId:
        {
            // A menu keeps a row its viewport scrolled away as a semantic element, so that UIA focus can reveal it, and
            // publishes no visible rectangle for it: that row is offscreen.
            const bool scrolledAway = record->controlVisible && _target && _target->menuPopup &&
                                      ! FindSnapshotFragmentBounds(*snapshot, AccessibilityFragmentKind::Control, record->path, 0u, 0u, 0u).has_value();
            *outValue               = VariantFromBool(! record->controlVisible || scrolledAway);
            return S_OK;
        }
        case UIA_IsPasswordPropertyId: *outValue = VariantFromBool(record->controlVisible && record->controlIsPassword); return S_OK;
        case UIA_ValueValuePropertyId:
            if (record->controlVisible && record->controlSupportsValue)
            {
                return SetVariantFromString(outValue, record->controlAccessibleValue);
            }
            return S_OK;
        case UIA_ValueIsReadOnlyPropertyId:
            if (record->controlVisible && (record->controlSupportsValue || record->controlSupportsRangeValue))
            {
                *outValue = VariantFromBool(record->controlValueReadOnly);
            }
            return S_OK;
        case UIA_RangeValueValuePropertyId:
            if (record->controlVisible && record->controlSupportsRangeValue)
            {
                *outValue = VariantFromDouble(record->controlRangeValue);
            }
            return S_OK;
        case UIA_RangeValueMinimumPropertyId:
            if (record->controlVisible && record->controlSupportsRangeValue)
            {
                *outValue = VariantFromDouble(record->controlRangeMinimum);
            }
            return S_OK;
        case UIA_RangeValueMaximumPropertyId:
            if (record->controlVisible && record->controlSupportsRangeValue)
            {
                *outValue = VariantFromDouble(record->controlRangeMaximum);
            }
            return S_OK;
        case UIA_RangeValueSmallChangePropertyId:
            if (record->controlVisible && record->controlSupportsRangeValue)
            {
                *outValue = VariantFromDouble(record->controlRangeSmallChange);
            }
            return S_OK;
        case UIA_RangeValueLargeChangePropertyId:
            if (record->controlVisible && record->controlSupportsRangeValue)
            {
                *outValue = VariantFromDouble(record->controlRangeLargeChange);
            }
            return S_OK;
        default: return S_OK;
    }
}

HRESULT AccessibilityProvider::get_HostRawElementProvider(IRawElementProviderSimple** outProvider) noexcept
{
    if (outProvider)
        *outProvider = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outProvider)
    {
        return E_POINTER;
    }

    *outProvider = nullptr;
    if (_kind != AccessibilityFragmentKind::Root)
    {
        return S_OK;
    }
    if (_target && _target->embedded)
        return S_OK;
    return UiaHostProviderFromHwnd(_hwnd, outProvider);
}

HRESULT AccessibilityProvider::Navigate(NavigateDirection direction, IRawElementProviderFragment** outProvider) noexcept
{
    if (outProvider)
        *outProvider = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outProvider)
    {
        return E_POINTER;
    }

    *outProvider                                                = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    if (! snapshot || ! snapshot->alive || ! snapshot->hasRetainedRoot)
    {
        return S_OK;
    }

    if (_kind == AccessibilityFragmentKind::Root && _target->embedded &&
        (direction == NavigateDirection_Parent || direction == NavigateDirection_NextSibling || direction == NavigateDirection_PreviousSibling))
    {
        if (! IsCurrentThreadWindowThread())
            return RPC_E_WRONG_THREAD;
        const auto site = _target->site;
        return site ? site->Navigate(direction, outProvider) : UIA_E_ELEMENTNOTAVAILABLE;
    }

    if (_kind == AccessibilityFragmentKind::TreeItem)
    {
        const AccessibilityControlNavigationSnapshot* record = FindControlNavigationRecord(*snapshot, _path);
        if (! record || ! SnapshotContainsTreeItem(*record, _treeItemId))
        {
            return UIA_E_ELEMENTNOTAVAILABLE;
        }
    }

    const std::optional<AccessibilityNavigationTarget> navigationTarget =
        ResolveSnapshotNavigationTarget(*snapshot, _kind, _path, _treeItemId, _gridRowId, _gridColumnIndex, direction);
    if (! navigationTarget)
    {
        return S_OK;
    }

    *outProvider = CreateProviderFromNavigationTarget(navigationTarget.value());
    return S_OK;
}

HRESULT AccessibilityProvider::GetRuntimeId(SAFEARRAY** outRuntimeId) noexcept
{
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (_target && _target->embedded)
    {
        if (! outRuntimeId)
            return E_POINTER;
        *outRuntimeId = nullptr;
        if (! CaptureSnapshot())
            return UIA_E_ELEMENTNOTAVAILABLE;
        RuntimeIdValueBuffer values{};
        size_t count = 0;
        if (! (AppendRuntimeIdValue(values, count, UiaAppendRuntimeId) && AppendRuntimeIdValue(values, count, static_cast<LONG>(_target->runtimeId)) &&
               AppendRuntimeIdValue(values, count, static_cast<LONG>(_target->runtimeId >> 32)) &&
               AppendRuntimeIdValue(values, count, static_cast<LONG>(_kind)) && AppendControlPathRuntimeIdPrefix(values, count, _path) &&
               AppendRuntimeIdValue(values, count, static_cast<LONG>(_treeItemId)) &&
               AppendRuntimeIdValue(values, count, static_cast<LONG>(_treeItemId >> 32)) &&
               AppendRuntimeIdValue(values, count, static_cast<LONG>(_gridRowId)) && AppendRuntimeIdValue(values, count, static_cast<LONG>(_gridRowId >> 32)) &&
               AppendRuntimeIdValue(values, count, static_cast<LONG>(_gridColumnIndex))))
            return E_INVALIDARG;
        if (_kind != AccessibilityFragmentKind::Root)
        {
            const auto* record = FindControlNavigationRecord(*_snapshot, _path);
            if (! record || ! AppendRuntimeIdValue(values, count, static_cast<LONG>(record->controlIdentity)) ||
                ! AppendRuntimeIdValue(values, count, static_cast<LONG>(record->controlIdentity >> 32)))
                return E_INVALIDARG;
        }
        return BuildRuntimeId(outRuntimeId, std::span<const LONG>(values.data(), count));
    }
    // An element whose control is gone has no runtime id either, as it answers nothing else.
    if (_target && ! CaptureSnapshot())
    {
        if (outRuntimeId)
            *outRuntimeId = nullptr;
        return UIA_E_ELEMENTNOTAVAILABLE;
    }
    if (_kind == AccessibilityFragmentKind::Root)
    {
        return SetRuntimeId(outRuntimeId, _hwnd, nullptr);
    }
    if (_kind == AccessibilityFragmentKind::TreeItem)
    {
        return SetTreeItemRuntimeId(outRuntimeId, _path, _treeItemId, _identity.value);
    }
    if (_kind == AccessibilityFragmentKind::GridHeader)
    {
        return SetGridHeaderRuntimeId(outRuntimeId, _path, _gridColumnIndex, _identity.value);
    }
    if (_kind == AccessibilityFragmentKind::GridRow)
    {
        return SetGridRowRuntimeId(outRuntimeId, _path, _gridRowId, _identity.value);
    }
    if (_kind == AccessibilityFragmentKind::GridCell)
    {
        return SetGridCellRuntimeId(outRuntimeId, _path, _gridRowId, _gridColumnIndex, _identity.value);
    }
    if (_kind == AccessibilityFragmentKind::TextFieldPasswordRevealButton)
    {
        return SetTextFieldPasswordRevealButtonRuntimeId(outRuntimeId, _path, _identity.value);
    }
    return SetRuntimeId(outRuntimeId, _hwnd, &_path, _identity.value);
}

HRESULT AccessibilityProvider::get_BoundingRectangle(UiaRect* outRect) noexcept
{
    if (outRect)
        *outRect = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outRect)
    {
        return E_POINTER;
    }

    *outRect                                                    = UiaRect{};
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    if (! snapshot || ! snapshot->alive)
    {
        return S_OK;
    }

    if (snapshot->embedded)
    {
        if (_kind == AccessibilityFragmentKind::Root)
        {
            *outRect = snapshot->placement.viewport;
            return S_OK;
        }
        size_t visibleIndex = 0;
        if (_kind == AccessibilityFragmentKind::TreeItem)
        {
            const auto* record = FindControlNavigationRecord(*snapshot, _path);
            const auto* item   = record ? FindSnapshotTreeItemRecord(*record, _treeItemId) : nullptr;
            if (! item)
                return UIA_E_ELEMENTNOTAVAILABLE;
            visibleIndex = item->visibleIndex;
        }
        const auto bounds = FindSnapshotFragmentBounds(*snapshot, _kind, _path, visibleIndex, _gridRowId, _gridColumnIndex);
        if (bounds)
            *outRect = EmbeddedScreenBounds(*snapshot, *bounds);
        return S_OK;
    }
    if (_kind == AccessibilityFragmentKind::Root)
    {
        if (SnapshotHasCollapsedSemanticRoot(*snapshot) && snapshot->hwnd && snapshot->pixelsToDipScale > 0.0f)
        {
            const std::optional<D2D1_RECT_F> boundsDip =
                FindSnapshotFragmentBounds(*snapshot, AccessibilityFragmentKind::Control, snapshot->semanticControlOrder.front(), 0u, 0u, 0u);
            if (boundsDip)
            {
                const float dipToPixelsScale = 1.0f / snapshot->pixelsToDipScale;
                POINT topLeft{static_cast<LONG>(std::lround(boundsDip->left * dipToPixelsScale)),
                              static_cast<LONG>(std::lround(boundsDip->top * dipToPixelsScale))};
                POINT bottomRight{static_cast<LONG>(std::lround(boundsDip->right * dipToPixelsScale)),
                                  static_cast<LONG>(std::lround(boundsDip->bottom * dipToPixelsScale))};
                if (ClientToScreen(snapshot->hwnd, &topLeft) != FALSE && ClientToScreen(snapshot->hwnd, &bottomRight) != FALSE)
                {
                    outRect->left   = static_cast<double>(topLeft.x);
                    outRect->top    = static_cast<double>(topLeft.y);
                    outRect->width  = static_cast<double>(bottomRight.x - topLeft.x);
                    outRect->height = static_cast<double>(bottomRight.y - topLeft.y);
                    return S_OK;
                }
            }
        }

        RECT windowRect{};
        if (! snapshot->hwnd || GetWindowRect(snapshot->hwnd, &windowRect) == FALSE)
        {
            return S_OK;
        }

        outRect->left   = static_cast<double>(windowRect.left);
        outRect->top    = static_cast<double>(windowRect.top);
        outRect->width  = static_cast<double>(windowRect.right - windowRect.left);
        outRect->height = static_cast<double>(windowRect.bottom - windowRect.top);
        return S_OK;
    }

    if (! snapshot->hasRetainedRoot || ! snapshot->hwnd || snapshot->pixelsToDipScale <= 0.0f)
    {
        return S_OK;
    }

    size_t treeVisibleIndex = 0u;
    if (_kind == AccessibilityFragmentKind::TreeItem)
    {
        const AccessibilityControlNavigationSnapshot* record = FindControlNavigationRecord(*snapshot, _path);
        const AccessibilityTreeItemSnapshotRecord* item      = record ? FindSnapshotTreeItemRecord(*record, _treeItemId) : nullptr;
        if (! item)
        {
            return UIA_E_ELEMENTNOTAVAILABLE;
        }
        treeVisibleIndex = item->visibleIndex;
    }

    const std::optional<D2D1_RECT_F> boundsDip = FindSnapshotFragmentBounds(*snapshot, _kind, _path, treeVisibleIndex, _gridRowId, _gridColumnIndex);
    if (! boundsDip)
    {
        return S_OK;
    }

    const float dipToPixelsScale = 1.0f / snapshot->pixelsToDipScale;
    POINT topLeft{static_cast<LONG>(std::lround(boundsDip->left * dipToPixelsScale)), static_cast<LONG>(std::lround(boundsDip->top * dipToPixelsScale))};
    POINT bottomRight{static_cast<LONG>(std::lround(boundsDip->right * dipToPixelsScale)),
                      static_cast<LONG>(std::lround(boundsDip->bottom * dipToPixelsScale))};
    if (ClientToScreen(snapshot->hwnd, &topLeft) == FALSE || ClientToScreen(snapshot->hwnd, &bottomRight) == FALSE)
    {
        return S_OK;
    }

    outRect->left   = static_cast<double>(topLeft.x);
    outRect->top    = static_cast<double>(topLeft.y);
    outRect->width  = static_cast<double>(bottomRight.x - topLeft.x);
    outRect->height = static_cast<double>(bottomRight.y - topLeft.y);
    return S_OK;
}

HRESULT AccessibilityProvider::GetEmbeddedFragmentRoots(SAFEARRAY** outRoots) noexcept
{
    if (outRoots)
        *outRoots = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outRoots)
    {
        return E_POINTER;
    }

    *outRoots = nullptr;
    return S_OK;
}

HRESULT AccessibilityProvider::SetFocus() noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! IsCurrentThreadWindowThread())
    {
        AccessibilityUiActionRequest request{};
        request.provider = this;
        request.kind     = AccessibilityUiActionKind::SetFocus;
        return DispatchActionToWindowThread(request);
    }

    return ExecuteSetFocusOnWindowThread();
}

HRESULT AccessibilityProvider::get_FragmentRoot(IRawElementProviderFragmentRoot** outRoot) noexcept
{
    if (outRoot)
        *outRoot = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outRoot)
    {
        return E_POINTER;
    }

    *outRoot = nullptr;
    if (_target && _target->embedded)
    {
        if (! CaptureSnapshot())
            return UIA_E_ELEMENTNOTAVAILABLE;
        if (! IsCurrentThreadWindowThread())
            return RPC_E_WRONG_THREAD;
        const auto site = _target->site;
        return site ? site->FragmentRoot(outRoot) : UIA_E_ELEMENTNOTAVAILABLE;
    }
    *outRoot = CreateRootProvider();
    return S_OK;
}

HRESULT AccessibilityProvider::ElementProviderFromPoint(double x, double y, IRawElementProviderFragment** outProvider) noexcept
{
    if (outProvider)
        *outProvider = nullptr;

    if (! CaptureSnapshot())
    {
        // A window's root element whose control is gone (see CaptureSnapshot) still answers for its window, where it finds
        // nothing any more; an embedded view's replaced root is gone for every call.
        if (_kind != AccessibilityFragmentKind::Root || ! _target || _target->embedded)
            return UIA_E_ELEMENTNOTAVAILABLE;
        return outProvider ? S_OK : E_POINTER;
    }
    if (! outProvider)
    {
        return E_POINTER;
    }

    *outProvider                                                = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    if (! snapshot || ! snapshot->alive || ! snapshot->hasRetainedRoot)
    {
        return S_OK;
    }

    if (! std::isfinite(x) || ! std::isfinite(y) || x < LONG_MIN || x > LONG_MAX || y < LONG_MIN || y > LONG_MAX)
        return E_INVALIDARG;
    if (snapshot->embedded)
    {
        const auto& box = snapshot->placement.viewport;
        if (x < box.left || y < box.top || x >= box.left + box.width || y >= box.top + box.height)
            return S_OK;
        x -= box.left;
        y -= box.top;
    }
    POINT pointPx{static_cast<LONG>(std::lround(x)), static_cast<LONG>(std::lround(y))};
    if (! snapshot->embedded && (! snapshot->hwnd || ScreenToClient(snapshot->hwnd, &pointPx) == FALSE))
    {
        return S_OK;
    }

    const D2D1_POINT_2F pointDip =
        D2D1::Point2F(static_cast<float>(pointPx.x) * snapshot->pixelsToDipScale, static_cast<float>(pointPx.y) * snapshot->pixelsToDipScale);
    const AccessibilityPointHitSnapshot* hit = FindSnapshotPointHit(*snapshot, pointDip);
    if (! hit)
    {
        return S_OK;
    }

    switch (hit->kind)
    {
        case AccessibilityFragmentKind::TextFieldPasswordRevealButton: *outProvider = CreateTextFieldPasswordRevealButtonProvider(hit->path); return S_OK;
        case AccessibilityFragmentKind::TreeItem:
        {
            const AccessibilityControlNavigationSnapshot* record = FindControlNavigationRecord(*snapshot, hit->path);
            const AccessibilityTreeItemSnapshotRecord* item      = record ? FindSnapshotTreeItemRecordByVisibleIndex(*record, hit->treeVisibleIndex) : nullptr;
            if (! item)
            {
                return UIA_E_ELEMENTNOTAVAILABLE;
            }
            *outProvider = CreateTreeItemProvider(hit->path, item->itemId);
            return S_OK;
        }
        case AccessibilityFragmentKind::GridHeader: *outProvider = CreateGridHeaderProvider(hit->path, hit->gridColumnIndex); return S_OK;
        case AccessibilityFragmentKind::GridRow: *outProvider = CreateGridRowProvider(hit->path, hit->gridRowId); return S_OK;
        case AccessibilityFragmentKind::GridCell: *outProvider = CreateGridCellProvider(hit->path, hit->gridRowId, hit->gridColumnIndex); return S_OK;
        case AccessibilityFragmentKind::Control: *outProvider = CreateControlProvider(hit->path); return S_OK;
        case AccessibilityFragmentKind::Root: *outProvider = CreateRootFragmentProvider(); return S_OK;
    }

    return S_OK;
}

HRESULT AccessibilityProvider::GetFocus(IRawElementProviderFragment** outProvider) noexcept
{
    if (outProvider)
        *outProvider = nullptr;

    // UI Automation calls this on any thread, to answer the system's focus event for a window it has not reported before
    // among other things, and the answer comes from the published snapshot, not from the window's thread. The call counts
    // itself before it reads the snapshot so a window host that publishes a focus move can tell, from the count it reads
    // after storing the snapshot, whether this read can still come before the move (ReporterOfFocusMove).
    HoldFocusResolutionForTest(_hwnd);
    if (_target)
        static_cast<void>(_target->focusResolutions.fetch_add(1u, std::memory_order_seq_cst));

    if (! CaptureSnapshot())
    {
        // A window's root element whose control is gone (see CaptureSnapshot) still answers for its window, through which
        // nothing has focus any more; an embedded view's replaced root is gone for every call.
        if (_kind != AccessibilityFragmentKind::Root || ! _target || _target->embedded)
            return UIA_E_ELEMENTNOTAVAILABLE;
        return outProvider ? S_OK : E_POINTER;
    }
    if (! outProvider)
    {
        return E_POINTER;
    }

    *outProvider                                                = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    if (! snapshot || ! snapshot->alive || ! snapshot->hasRetainedRoot || ! snapshot->focusedFragment.has_value())
    {
        return S_OK;
    }

    const AccessibilityFocusedFragmentSnapshot& focusedFragment = snapshot->focusedFragment.value();
    switch (focusedFragment.kind)
    {
        case AccessibilityFragmentKind::TreeItem: *outProvider = CreateTreeItemProvider(focusedFragment.path, focusedFragment.treeItemId); return S_OK;
        case AccessibilityFragmentKind::GridRow: *outProvider = CreateGridRowProvider(focusedFragment.path, focusedFragment.gridRowId); return S_OK;
        case AccessibilityFragmentKind::Control: *outProvider = CreateControlProvider(focusedFragment.path); return S_OK;
        case AccessibilityFragmentKind::Root:
        case AccessibilityFragmentKind::GridHeader:
        case AccessibilityFragmentKind::GridCell:
        case AccessibilityFragmentKind::TextFieldPasswordRevealButton: return S_OK;
    }

    return S_OK;
}

HRESULT AccessibilityProvider::Invoke() noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! IsCurrentThreadWindowThread())
    {
        AccessibilityUiActionRequest request{};
        request.provider = this;
        request.kind     = AccessibilityUiActionKind::Invoke;
        return DispatchActionToWindowThread(request);
    }

    return ExecuteInvokeOnWindowThread();
}

HRESULT AccessibilityProvider::Toggle() noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! IsCurrentThreadWindowThread())
    {
        AccessibilityUiActionRequest request{};
        request.provider = this;
        request.kind     = AccessibilityUiActionKind::Toggle;
        return DispatchActionToWindowThread(request);
    }

    return ExecuteToggleOnWindowThread();
}

HRESULT AccessibilityProvider::get_ToggleState(ToggleState* outState) noexcept
{
    if (outState)
        *outState = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outState)
    {
        return E_POINTER;
    }

    if (_kind == AccessibilityFragmentKind::GridCell)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot   = CaptureSnapshot();
        const std::optional<AccessibilityGridCellSnapshotRecord> cell = (snapshot && snapshot->alive && snapshot->hasRetainedRoot)
                                                                            ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex)
                                                                            : std::nullopt;
        if (! cell || ! SnapshotGridCellSupportsTogglePattern(cell.value()) || ! cell->cellRecord)
        {
            return UIA_E_NOTSUPPORTED;
        }

        *outState = cell->cellRecord->gridCellChecked ? ToggleState_On : ToggleState_Off;
        return S_OK;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! record->controlSupportsToggle)
    {
        return UIA_E_NOTSUPPORTED;
    }

    *outState = record->controlToggleChecked ? ToggleState_On : ToggleState_Off;
    return S_OK;
}

HRESULT AccessibilityProvider::GetVisibleRanges(SAFEARRAY** outRanges) noexcept
{
    if (outRanges)
        *outRanges = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const auto startedAt = std::chrono::steady_clock::now();
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outRanges)
    {
        return E_POINTER;
    }

    *outRanges                                                  = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! record->controlSupportsText)
    {
        return UIA_E_NOTSUPPORTED;
    }

    wil::com_ptr_nothrow<ITextRangeProvider> range;
    range.attach(CreateTextDocumentRangeProvider(*record));
    if (! range)
    {
        return E_OUTOFMEMORY;
    }

    ITextRangeProvider* rawRanges[] = {range.get()};
    const HRESULT hr                = SetTextRangeProviderArray(outRanges, rawRanges);
    Debug::Perf::Emit(L"dxui.uia.text_range_us", L"visible-ranges", Debug::Perf::ElapsedUs(startedAt), 1u, record->controlAccessibleText.size(), hr);
    return hr;
}

HRESULT AccessibilityProvider::RangeFromChild(IRawElementProviderSimple* /*childElement*/, ITextRangeProvider** outRange) noexcept
{
    if (outRange)
        *outRange = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    return get_DocumentRange(outRange);
}

HRESULT AccessibilityProvider::RangeFromPoint(UiaPoint point, ITextRangeProvider** outRange) noexcept
{
    if (outRange)
        *outRange = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const auto startedAt = std::chrono::steady_clock::now();
    if (! outRange)
    {
        return E_POINTER;
    }

    *outRange                                                   = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! record->controlSupportsText)
    {
        return UIA_E_NOTSUPPORTED;
    }

    AccessibilityUiActionRequest request{};
    request.provider       = this;
    request.kind           = AccessibilityUiActionKind::ResolveTextRangeFromPoint;
    request.textRangePoint = point;

    const HRESULT resolveHr = IsCurrentThreadWindowThread()
                                  ? ExecuteResolveTextRangeFromPointOnWindowThread(point, request.textRangeResultStart, request.textRangeTextLength)
                                  : DispatchActionToWindowThread(request);
    if (FAILED(resolveHr) || resolveHr != S_OK)
    {
        return resolveHr;
    }

    *outRange        = CreateTextRangeProvider(record->path, request.textRangeResultStart, request.textRangeResultStart);
    const HRESULT hr = *outRange ? S_OK : E_OUTOFMEMORY;
    Debug::Perf::Emit(
        L"dxui.uia.text_range_us", L"range-from-point", Debug::Perf::ElapsedUs(startedAt), request.textRangeResultStart, request.textRangeTextLength, hr);
    return hr;
}

HRESULT AccessibilityProvider::ExecuteResolveTextRangeFromPointOnWindowThread(UiaPoint point, size_t& outCaretIndex, size_t& outTextLength) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    outCaretIndex = 0u;
    outTextLength = 0u;

    ControlHost* host      = ResolveHost();
    const Control* control = ResolveControl();
    if (! host || ! control || ! SupportsTextPattern(control))
    {
        return UIA_E_NOTSUPPORTED;
    }

    const std::wstring text = GetControlAccessibleTextRangeText(control);
    outTextLength           = text.size();
    if (! std::isfinite(point.x) || ! std::isfinite(point.y) || point.x < LONG_MIN || point.x > LONG_MAX || point.y < LONG_MIN || point.y > LONG_MAX)
        return E_INVALIDARG;
    const POINT pointScreen{static_cast<LONG>(std::lround(point.x)), static_cast<LONG>(std::lround(point.y))};
    std::optional<PointDip> pointDip;
    if (_target->embedded)
    {
        const auto snapshot = CaptureSnapshot();
        if (! snapshot)
            return UIA_E_ELEMENTNOTAVAILABLE;
        pointDip = PointDip{static_cast<float>((point.x - snapshot->placement.viewport.left) * snapshot->pixelsToDipScale),
                            static_cast<float>((point.y - snapshot->placement.viewport.top) * snapshot->pixelsToDipScale)};
    }
    else
        pointDip = host->ScreenPointToDipPoint(pointScreen);
    if (! pointDip)
    {
        return E_INVALIDARG;
    }

    const D2D1_POINT_2F hitPoint = D2D1::Point2F(pointDip->x, pointDip->y);
    size_t caretIndex            = 0u;
    if (const std::optional<size_t> hitIndex = control->TryHitTestTextInputPoint(*host, hitPoint); hitIndex.has_value())
    {
        caretIndex = (std::min)(hitIndex.value(), text.size());
    }
    else if (const auto* comboBox = dynamic_cast<const ComboBox*>(control); comboBox && comboBox->IsEditable())
    {
        caretIndex = comboBox->HitTestEditableCaretIndex(*host, hitPoint);
    }
    else
    {
        caretIndex = HitTestCaretIndexDip(
            host, text, FontRole::Body, ResolveTextPatternViewportRect(control), 0.0f, hitPoint, ResolveReadingDirection(control->GetFlowDirection()));
    }

    outCaretIndex = caretIndex;
    return S_OK;
}

HRESULT AccessibilityProvider::get_DocumentRange(ITextRangeProvider** outRange) noexcept
{
    if (outRange)
        *outRange = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const auto startedAt = std::chrono::steady_clock::now();
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outRange)
    {
        return E_POINTER;
    }

    *outRange                                                   = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! record->controlSupportsText)
    {
        return UIA_E_NOTSUPPORTED;
    }

    *outRange        = CreateTextDocumentRangeProvider(*record);
    const HRESULT hr = *outRange ? S_OK : E_OUTOFMEMORY;
    Debug::Perf::Emit(L"dxui.uia.text_range_us", L"document-range", Debug::Perf::ElapsedUs(startedAt), record->controlAccessibleText.size(), 0u, hr);
    return hr;
}

HRESULT AccessibilityProvider::get_SupportedTextSelection(SupportedTextSelection* outSupportedSelection) noexcept
{
    if (outSupportedSelection)
        *outSupportedSelection = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outSupportedSelection)
    {
        return E_POINTER;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! record->controlSupportsText)
    {
        return UIA_E_NOTSUPPORTED;
    }

    *outSupportedSelection = SupportedTextSelection_Single;
    return S_OK;
}

HRESULT AccessibilityProvider::GetActiveComposition(ITextRangeProvider** outRange) noexcept
{
    if (outRange)
        *outRange = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const auto startedAt = std::chrono::steady_clock::now();
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outRange)
    {
        return E_POINTER;
    }

    *outRange                                                   = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! record->controlSupportsText)
    {
        return UIA_E_NOTSUPPORTED;
    }

    if (! record->controlTextCompositionStart || ! record->controlTextCompositionEnd)
    {
        Debug::Perf::Emit(L"dxui.uia.text_range_us", L"active-composition", Debug::Perf::ElapsedUs(startedAt), 0u, 0u, S_OK);
        return S_OK;
    }

    const TextRangeSpan range =
        ClampTextRangeSpan(record->controlTextCompositionStart.value(), record->controlTextCompositionEnd.value(), record->controlAccessibleText.size());
    *outRange        = CreateTextRangeProvider(record->path, range.start, range.end, record->controlAccessibleText);
    const HRESULT hr = *outRange ? S_OK : E_OUTOFMEMORY;
    Debug::Perf::Emit(
        L"dxui.uia.text_range_us", L"active-composition", Debug::Perf::ElapsedUs(startedAt), range.end - range.start, record->controlAccessibleText.size(), hr);
    return hr;
}

HRESULT AccessibilityProvider::GetConversionTarget(ITextRangeProvider** outRange) noexcept
{
    if (outRange)
        *outRange = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const auto startedAt = std::chrono::steady_clock::now();
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outRange)
    {
        return E_POINTER;
    }

    *outRange                                                   = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! record->controlSupportsText)
    {
        return UIA_E_NOTSUPPORTED;
    }

    if (! record->controlTextConversionTargetStart || ! record->controlTextConversionTargetEnd)
    {
        Debug::Perf::Emit(L"dxui.uia.text_range_us", L"conversion-target", Debug::Perf::ElapsedUs(startedAt), 0u, 0u, S_OK);
        return S_OK;
    }

    const TextRangeSpan range = ClampTextRangeSpan(
        record->controlTextConversionTargetStart.value(), record->controlTextConversionTargetEnd.value(), record->controlAccessibleText.size());
    *outRange        = CreateTextRangeProvider(record->path, range.start, range.end, record->controlAccessibleText);
    const HRESULT hr = *outRange ? S_OK : E_OUTOFMEMORY;
    Debug::Perf::Emit(
        L"dxui.uia.text_range_us", L"conversion-target", Debug::Perf::ElapsedUs(startedAt), range.end - range.start, record->controlAccessibleText.size(), hr);
    return hr;
}

HRESULT AccessibilityProvider::SetValue(LPCWSTR value) noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! IsCurrentThreadWindowThread())
    {
        AccessibilityUiActionRequest request{};
        request.provider    = this;
        request.kind        = AccessibilityUiActionKind::SetStringValue;
        request.stringValue = value ? value : L"";
        return DispatchActionToWindowThread(request);
    }

    return ExecuteSetStringValueOnWindowThread(value);
}

HRESULT AccessibilityProvider::SetValue(double value) noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! IsCurrentThreadWindowThread())
    {
        AccessibilityUiActionRequest request{};
        request.provider    = this;
        request.kind        = AccessibilityUiActionKind::SetRangeValue;
        request.numberValue = value;
        return DispatchActionToWindowThread(request);
    }

    return ExecuteSetRangeValueOnWindowThread(value);
}

HRESULT AccessibilityProvider::get_Value(BSTR* outValue) noexcept
{
    if (outValue)
        *outValue = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outValue)
    {
        return E_POINTER;
    }

    *outValue = nullptr;
    if (_kind == AccessibilityFragmentKind::GridCell)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot   = CaptureSnapshot();
        const std::optional<AccessibilityGridCellSnapshotRecord> cell = (snapshot && snapshot->alive && snapshot->hasRetainedRoot)
                                                                            ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex)
                                                                            : std::nullopt;
        if (! cell || ! SnapshotGridCellSupportsValuePattern(cell.value()) || ! cell->cellRecord)
        {
            return UIA_E_NOTSUPPORTED;
        }

        const std::wstring& value = cell->cellRecord->gridCellAccessibleText;
        *outValue                 = SysAllocStringLen(value.data(), static_cast<UINT>(value.size()));
        return (*outValue || value.empty()) ? S_OK : E_OUTOFMEMORY;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! record->controlSupportsValue)
    {
        return UIA_E_NOTSUPPORTED;
    }

    *outValue = SysAllocStringLen(record->controlAccessibleValue.data(), static_cast<UINT>(record->controlAccessibleValue.size()));
    return (*outValue || record->controlAccessibleValue.empty()) ? S_OK : E_OUTOFMEMORY;
}

HRESULT AccessibilityProvider::get_Value(double* outValue) noexcept
{
    if (outValue)
        *outValue = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outValue)
    {
        return E_POINTER;
    }

    if (_kind == AccessibilityFragmentKind::GridCell)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot   = CaptureSnapshot();
        const std::optional<AccessibilityGridCellSnapshotRecord> cell = (snapshot && snapshot->alive && snapshot->hasRetainedRoot)
                                                                            ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex)
                                                                            : std::nullopt;
        if (! cell || ! SnapshotGridCellSupportsRangeValuePattern(cell.value()) || ! cell->cellRecord)
        {
            return UIA_E_NOTSUPPORTED;
        }

        *outValue = cell->cellRecord->gridCellRangeValue;
        return S_OK;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (record && record->controlSupportsRangeValue)
    {
        *outValue = record->controlRangeValue;
        return S_OK;
    }
    return UIA_E_NOTSUPPORTED;
}

HRESULT AccessibilityProvider::get_IsReadOnly(BOOL* outReadOnly) noexcept
{
    if (outReadOnly)
        *outReadOnly = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outReadOnly)
    {
        return E_POINTER;
    }

    if (_kind == AccessibilityFragmentKind::GridCell)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot   = CaptureSnapshot();
        const std::optional<AccessibilityGridCellSnapshotRecord> cell = (snapshot && snapshot->alive && snapshot->hasRetainedRoot)
                                                                            ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex)
                                                                            : std::nullopt;
        if (! cell || (! SnapshotGridCellSupportsValuePattern(cell.value()) && ! SnapshotGridCellSupportsRangeValuePattern(cell.value())))
        {
            return UIA_E_NOTSUPPORTED;
        }

        *outReadOnly = TRUE;
        return S_OK;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || (! record->controlSupportsValue && ! record->controlSupportsRangeValue))
    {
        return UIA_E_NOTSUPPORTED;
    }

    *outReadOnly = record->controlValueReadOnly ? TRUE : FALSE;
    return S_OK;
}

HRESULT AccessibilityProvider::get_Maximum(double* outMaximum) noexcept
{
    if (outMaximum)
        *outMaximum = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outMaximum)
    {
        return E_POINTER;
    }

    if (_kind == AccessibilityFragmentKind::GridCell)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot   = CaptureSnapshot();
        const std::optional<AccessibilityGridCellSnapshotRecord> cell = (snapshot && snapshot->alive && snapshot->hasRetainedRoot)
                                                                            ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex)
                                                                            : std::nullopt;
        if (! cell || ! SnapshotGridCellSupportsRangeValuePattern(cell.value()))
        {
            return UIA_E_NOTSUPPORTED;
        }

        *outMaximum = 1.0;
        return S_OK;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (record && record->controlSupportsRangeValue)
    {
        *outMaximum = record->controlRangeMaximum;
        return S_OK;
    }

    return UIA_E_NOTSUPPORTED;
}

HRESULT AccessibilityProvider::get_Minimum(double* outMinimum) noexcept
{
    if (outMinimum)
        *outMinimum = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outMinimum)
    {
        return E_POINTER;
    }

    if (_kind == AccessibilityFragmentKind::GridCell)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot   = CaptureSnapshot();
        const std::optional<AccessibilityGridCellSnapshotRecord> cell = (snapshot && snapshot->alive && snapshot->hasRetainedRoot)
                                                                            ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex)
                                                                            : std::nullopt;
        if (! cell || ! SnapshotGridCellSupportsRangeValuePattern(cell.value()))
        {
            return UIA_E_NOTSUPPORTED;
        }

        *outMinimum = 0.0;
        return S_OK;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (record && record->controlSupportsRangeValue)
    {
        *outMinimum = record->controlRangeMinimum;
        return S_OK;
    }

    return UIA_E_NOTSUPPORTED;
}

HRESULT AccessibilityProvider::get_LargeChange(double* outLargeChange) noexcept
{
    if (outLargeChange)
        *outLargeChange = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outLargeChange)
    {
        return E_POINTER;
    }

    if (_kind == AccessibilityFragmentKind::GridCell)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot   = CaptureSnapshot();
        const std::optional<AccessibilityGridCellSnapshotRecord> cell = (snapshot && snapshot->alive && snapshot->hasRetainedRoot)
                                                                            ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex)
                                                                            : std::nullopt;
        if (! cell || ! SnapshotGridCellSupportsRangeValuePattern(cell.value()))
        {
            return UIA_E_NOTSUPPORTED;
        }

        *outLargeChange = 0.0;
        return S_OK;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (record && record->controlSupportsRangeValue)
    {
        *outLargeChange = record->controlRangeLargeChange;
        return S_OK;
    }

    return UIA_E_NOTSUPPORTED;
}

HRESULT AccessibilityProvider::get_SmallChange(double* outSmallChange) noexcept
{
    if (outSmallChange)
        *outSmallChange = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outSmallChange)
    {
        return E_POINTER;
    }

    if (_kind == AccessibilityFragmentKind::GridCell)
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot   = CaptureSnapshot();
        const std::optional<AccessibilityGridCellSnapshotRecord> cell = (snapshot && snapshot->alive && snapshot->hasRetainedRoot)
                                                                            ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex)
                                                                            : std::nullopt;
        if (! cell || ! SnapshotGridCellSupportsRangeValuePattern(cell.value()))
        {
            return UIA_E_NOTSUPPORTED;
        }

        *outSmallChange = 0.0;
        return S_OK;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (record && record->controlSupportsRangeValue)
    {
        *outSmallChange = record->controlRangeSmallChange;
        return S_OK;
    }

    return UIA_E_NOTSUPPORTED;
}

HRESULT AccessibilityProvider::GetSelection(SAFEARRAY** outSelection) noexcept
{
    if (outSelection)
        *outSelection = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outSelection)
    {
        return E_POINTER;
    }

    *outSelection                                               = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (record && SnapshotSupportsSelectionProvider(*record))
    {
        std::vector<wil::com_ptr_nothrow<IRawElementProviderSimple>> selectionProviders;
        if (record->isTree)
        {
            if (record->treeCanSelectMultiple)
            {
                // Every selected item that is a visible row, in visible order.
                selectionProviders.reserve(record->selectedTreeItemIds.size());
                for (const uint64_t itemId : record->selectedTreeItemIds)
                {
                    wil::com_ptr_nothrow<IRawElementProviderFragment> fragment;
                    fragment.attach(CreateTreeItemProvider(record->path, itemId));
                    wil::com_ptr_nothrow<IRawElementProviderSimple> simple;
                    if (! fragment || FAILED(fragment.query_to(simple.put())))
                    {
                        return E_OUTOFMEMORY;
                    }
                    selectionProviders.push_back(std::move(simple));
                }
            }
            else if (record->selectedTreeVisibleIndex)
            {
                const AccessibilityTreeItemSnapshotRecord* selectedItem =
                    FindSnapshotTreeItemRecordByVisibleIndex(*record, record->selectedTreeVisibleIndex.value());
                if (! selectedItem)
                {
                    return UIA_E_ELEMENTNOTAVAILABLE;
                }
                wil::com_ptr_nothrow<IRawElementProviderFragment> fragment;
                fragment.attach(CreateTreeItemProvider(record->path, selectedItem->itemId));
                wil::com_ptr_nothrow<IRawElementProviderSimple> simple;
                if (! fragment || FAILED(fragment.query_to(simple.put())))
                {
                    return E_OUTOFMEMORY;
                }
                selectionProviders.push_back(std::move(simple));
            }
        }
        else if (record->isGrid)
        {
            selectionProviders.reserve(record->selectedGridRowIds.size());
            for (const uint64_t rowId : record->selectedGridRowIds)
            {
                wil::com_ptr_nothrow<IRawElementProviderFragment> fragment;
                fragment.attach(CreateGridRowProvider(record->path, rowId));
                wil::com_ptr_nothrow<IRawElementProviderSimple> simple;
                if (! fragment || FAILED(fragment.query_to(simple.put())))
                {
                    return E_OUTOFMEMORY;
                }
                selectionProviders.push_back(std::move(simple));
            }
        }

        std::vector<IRawElementProviderSimple*> rawProviders;
        rawProviders.reserve(selectionProviders.size());
        for (const auto& provider : selectionProviders)
        {
            rawProviders.push_back(provider.get());
        }

        return SetProviderArray(outSelection, rawProviders);
    }

    const AccessibilityControlNavigationSnapshot* textRecord =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (textRecord && textRecord->controlSupportsText)
    {
        wil::com_ptr_nothrow<ITextRangeProvider> range;
        if (! textRecord->controlTextSelectionBoundsDip.empty())
        {
            range.attach(CreateTextRangeProvider(
                textRecord->path, textRecord->controlTextSelectionStart, textRecord->controlTextSelectionEnd, textRecord->controlTextSelectionBoundsDip));
        }
        else
        {
            range.attach(CreateTextRangeProvider(textRecord->path, textRecord->controlTextSelectionStart, textRecord->controlTextSelectionEnd));
        }
        if (! range)
        {
            return E_OUTOFMEMORY;
        }

        ITextRangeProvider* rawRanges[] = {range.get()};
        return SetTextRangeProviderArray(outSelection, rawRanges);
    }

    return UIA_E_NOTSUPPORTED;
}

HRESULT AccessibilityProvider::get_CanSelectMultiple(BOOL* outCanSelectMultiple) noexcept
{
    if (outCanSelectMultiple)
        *outCanSelectMultiple = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outCanSelectMultiple)
    {
        return E_POINTER;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! SnapshotSupportsSelectionProvider(*record))
    {
        return UIA_E_NOTSUPPORTED;
    }

    if (record->isTree)
    {
        *outCanSelectMultiple = record->treeCanSelectMultiple ? TRUE : FALSE;
        return S_OK;
    }
    if (record->isGrid)
    {
        *outCanSelectMultiple = record->gridCanSelectMultiple ? TRUE : FALSE;
        return S_OK;
    }

    return UIA_E_NOTSUPPORTED;
}

HRESULT AccessibilityProvider::get_IsSelectionRequired(BOOL* outIsSelectionRequired) noexcept
{
    if (outIsSelectionRequired)
        *outIsSelectionRequired = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outIsSelectionRequired)
    {
        return E_POINTER;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! SnapshotSupportsSelectionProvider(*record))
    {
        return UIA_E_NOTSUPPORTED;
    }

    *outIsSelectionRequired = FALSE;
    return S_OK;
}

HRESULT AccessibilityProvider::GetRowHeaders(SAFEARRAY** outRowHeaders) noexcept
{
    if (outRowHeaders)
        *outRowHeaders = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    if (! outRowHeaders)
    {
        return E_POINTER;
    }

    *outRowHeaders                                              = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! record->isGrid)
    {
        return UIA_E_NOTSUPPORTED;
    }

    return SetProviderArray(outRowHeaders, {});
}

HRESULT AccessibilityProvider::GetColumnHeaders(SAFEARRAY** outColumnHeaders) noexcept
{
    if (outColumnHeaders)
        *outColumnHeaders = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outColumnHeaders)
    {
        return E_POINTER;
    }

    *outColumnHeaders                                           = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! record->isGrid)
    {
        return UIA_E_NOTSUPPORTED;
    }

    std::vector<wil::com_ptr_nothrow<IRawElementProviderSimple>> headerProviders;
    headerProviders.reserve(record->gridVisibleColumns.size());
    for (const size_t columnIndex : record->gridVisibleColumns)
    {
        wil::com_ptr_nothrow<IRawElementProviderFragment> fragment;
        fragment.attach(CreateGridHeaderProvider(record->path, columnIndex));
        wil::com_ptr_nothrow<IRawElementProviderSimple> simple;
        if (! fragment || FAILED(fragment.query_to(simple.put())))
        {
            return E_OUTOFMEMORY;
        }

        headerProviders.push_back(std::move(simple));
    }

    std::vector<IRawElementProviderSimple*> rawProviders;
    rawProviders.reserve(headerProviders.size());
    for (const auto& provider : headerProviders)
    {
        rawProviders.push_back(provider.get());
    }

    return SetProviderArray(outColumnHeaders, rawProviders);
}

HRESULT AccessibilityProvider::get_RowOrColumnMajor(RowOrColumnMajor* outRowOrColumnMajor) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outRowOrColumnMajor)
    {
        return E_POINTER;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path) : nullptr;
    if (! record || ! record->isGrid)
    {
        return UIA_E_NOTSUPPORTED;
    }

    *outRowOrColumnMajor = RowOrColumnMajor_Indeterminate;
    return S_OK;
}

HRESULT AccessibilityProvider::Select() noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! IsCurrentThreadWindowThread())
    {
        AccessibilityUiActionRequest request{};
        request.provider = this;
        request.kind     = AccessibilityUiActionKind::Select;
        return DispatchActionToWindowThread(request);
    }

    return ExecuteSelectOnWindowThread();
}

HRESULT AccessibilityProvider::AddToSelection() noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! IsCurrentThreadWindowThread())
    {
        AccessibilityUiActionRequest request{};
        request.provider = this;
        request.kind     = AccessibilityUiActionKind::AddToSelection;
        return DispatchActionToWindowThread(request);
    }

    return ExecuteAddToSelectionOnWindowThread();
}

HRESULT AccessibilityProvider::RemoveFromSelection() noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! IsCurrentThreadWindowThread())
    {
        AccessibilityUiActionRequest request{};
        request.provider = this;
        request.kind     = AccessibilityUiActionKind::RemoveFromSelection;
        return DispatchActionToWindowThread(request);
    }

    return ExecuteRemoveFromSelectionOnWindowThread();
}

HRESULT AccessibilityProvider::get_IsSelected(BOOL* outSelected) noexcept
{
    if (outSelected)
        *outSelected = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outSelected)
    {
        return E_POINTER;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*snapshot, _path) : nullptr;
    if (_kind == AccessibilityFragmentKind::TreeItem)
    {
        if (! record || ! SnapshotContainsTreeItem(*record, _treeItemId))
        {
            return UIA_E_ELEMENTNOTAVAILABLE;
        }

        *outSelected = SnapshotTreeItemIsSelected(*record, _treeItemId) ? TRUE : FALSE;
        return S_OK;
    }

    if (_kind == AccessibilityFragmentKind::GridRow)
    {
        if (! record || ! SnapshotSupportsGridSelectionItem(*record, _gridRowId))
        {
            return UIA_E_NOTSUPPORTED;
        }

        *outSelected = SnapshotGridRowIsSelected(*record, _gridRowId) ? TRUE : FALSE;
        return S_OK;
    }

    return UIA_E_NOTSUPPORTED;
}

HRESULT AccessibilityProvider::get_SelectionContainer(IRawElementProviderSimple** outContainer) noexcept
{
    if (outContainer)
        *outContainer = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outContainer)
    {
        return E_POINTER;
    }

    *outContainer                                               = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindControlNavigationRecord(*snapshot, _path) : nullptr;
    const bool treeItemSupported = _kind == AccessibilityFragmentKind::TreeItem && record && SnapshotContainsTreeItem(*record, _treeItemId);
    const bool gridRowSupported  = _kind == AccessibilityFragmentKind::GridRow && record && SnapshotSupportsGridSelectionItem(*record, _gridRowId);
    if (! treeItemSupported && ! gridRowSupported)
    {
        if (_kind == AccessibilityFragmentKind::TreeItem)
        {
            return UIA_E_ELEMENTNOTAVAILABLE;
        }
        return UIA_E_NOTSUPPORTED;
    }

    // The tree's or grid's own element: the window's root element when that is the one control it stands for.
    wil::com_ptr_nothrow<IRawElementProviderSimple> container = CreateControlElement(_target, _hwnd, _path);
    if (! container)
    {
        return E_OUTOFMEMORY;
    }

    *outContainer = container.detach();
    return S_OK;
}

HRESULT AccessibilityProvider::Expand() noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! IsCurrentThreadWindowThread())
    {
        AccessibilityUiActionRequest request{};
        request.provider = this;
        request.kind     = AccessibilityUiActionKind::Expand;
        return DispatchActionToWindowThread(request);
    }

    return ExecuteExpandOnWindowThread(true);
}

HRESULT AccessibilityProvider::Collapse() noexcept
{
    const auto site      = _target && _target->embedded && IsCurrentThreadWindowThread() ? _target->site : nullptr;
    const auto completed = wil::scope_exit([&]
    {
        if (site)
            site->ActionCompleted();
    });
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! IsCurrentThreadWindowThread())
    {
        AccessibilityUiActionRequest request{};
        request.provider = this;
        request.kind     = AccessibilityUiActionKind::Collapse;
        return DispatchActionToWindowThread(request);
    }

    return ExecuteExpandOnWindowThread(false);
}

HRESULT AccessibilityProvider::get_ExpandCollapseState(ExpandCollapseState* outState) noexcept
{
    if (outState)
        *outState = ExpandCollapseState_LeafNode;
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outState)
    {
        return E_POINTER;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const AccessibilityControlNavigationSnapshot* record =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot)
            ? ((_kind == AccessibilityFragmentKind::Control || _kind == AccessibilityFragmentKind::Root) ? ResolveSnapshotControlRecord(*snapshot, _kind, _path)
                                                                                                         : FindControlNavigationRecord(*snapshot, _path))
            : nullptr;
    if (_kind == AccessibilityFragmentKind::Control || _kind == AccessibilityFragmentKind::Root)
    {
        if (! record)
        {
            return UIA_E_ELEMENTNOTAVAILABLE;
        }
        if (! record->controlDisclosureExpanded.has_value())
        {
            return UIA_E_NOTSUPPORTED;
        }
        *outState = record->controlDisclosureExpanded.value() ? ExpandCollapseState_Expanded : ExpandCollapseState_Collapsed;
        return S_OK;
    }
    const AccessibilityTreeItemSnapshotRecord* item = record ? FindSnapshotTreeItemRecord(*record, _treeItemId) : nullptr;
    if (! item)
    {
        return UIA_E_ELEMENTNOTAVAILABLE;
    }
    if (! item->hasChildren)
    {
        return UIA_E_NOTSUPPORTED;
    }

    *outState = item->expanded ? ExpandCollapseState_Expanded : ExpandCollapseState_Collapsed;
    return S_OK;
}

HRESULT AccessibilityProvider::get_Row(int* outRow) noexcept
{
    if (outRow)
        *outRow = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outRow)
    {
        return E_POINTER;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const std::optional<AccessibilityGridCellSnapshotRecord> cell =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex) : std::nullopt;
    if (! cell || cell->rowIndex > static_cast<size_t>((std::numeric_limits<int>::max)()))
    {
        return UIA_E_NOTSUPPORTED;
    }

    *outRow = static_cast<int>(cell->rowIndex);
    return S_OK;
}

HRESULT AccessibilityProvider::get_Column(int* outColumn) noexcept
{
    if (outColumn)
        *outColumn = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outColumn)
    {
        return E_POINTER;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const std::optional<AccessibilityGridCellSnapshotRecord> cell =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex) : std::nullopt;
    if (! cell || cell->columnIndex > static_cast<size_t>((std::numeric_limits<int>::max)()))
    {
        return UIA_E_NOTSUPPORTED;
    }

    *outColumn = static_cast<int>(cell->columnIndex);
    return S_OK;
}

HRESULT AccessibilityProvider::get_RowSpan(int* outRowSpan) noexcept
{
    if (outRowSpan)
        *outRowSpan = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outRowSpan)
    {
        return E_POINTER;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const std::optional<AccessibilityGridCellSnapshotRecord> cell =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex) : std::nullopt;
    if (! cell)
    {
        return UIA_E_NOTSUPPORTED;
    }

    *outRowSpan = 1;
    return S_OK;
}

HRESULT AccessibilityProvider::get_ColumnSpan(int* outColumnSpan) noexcept
{
    if (outColumnSpan)
        *outColumnSpan = {};

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outColumnSpan)
    {
        return E_POINTER;
    }

    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const std::optional<AccessibilityGridCellSnapshotRecord> cell =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex) : std::nullopt;
    if (! cell)
    {
        return UIA_E_NOTSUPPORTED;
    }

    *outColumnSpan = 1;
    return S_OK;
}

HRESULT AccessibilityProvider::get_ContainingGrid(IRawElementProviderSimple** outContainingGrid) noexcept
{
    if (outContainingGrid)
        *outContainingGrid = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outContainingGrid)
    {
        return E_POINTER;
    }

    *outContainingGrid                                          = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const std::optional<AccessibilityGridCellSnapshotRecord> cell =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex) : std::nullopt;
    if (! cell)
    {
        return UIA_E_NOTSUPPORTED;
    }

    // The grid's own element: the window's root element when that is the one control it stands for.
    wil::com_ptr_nothrow<IRawElementProviderSimple> grid = CreateControlElement(_target, _hwnd, _path);
    if (! grid)
    {
        return E_OUTOFMEMORY;
    }

    *outContainingGrid = grid.detach();
    return S_OK;
}

HRESULT AccessibilityProvider::GetRowHeaderItems(SAFEARRAY** outRowHeaderItems) noexcept
{
    if (outRowHeaderItems)
        *outRowHeaderItems = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outRowHeaderItems)
    {
        return E_POINTER;
    }

    *outRowHeaderItems                                          = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const std::optional<AccessibilityGridCellSnapshotRecord> cell =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex) : std::nullopt;
    if (! cell || cell->controlRecord->gridVisibleColumns.empty())
    {
        return UIA_E_NOTSUPPORTED;
    }

    return SetProviderArray(outRowHeaderItems, {});
}

HRESULT AccessibilityProvider::GetColumnHeaderItems(SAFEARRAY** outColumnHeaderItems) noexcept
{
    if (outColumnHeaderItems)
        *outColumnHeaderItems = nullptr;

    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! outColumnHeaderItems)
    {
        return E_POINTER;
    }

    *outColumnHeaderItems                                       = nullptr;
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = CaptureSnapshot();
    const std::optional<AccessibilityGridCellSnapshotRecord> cell =
        (snapshot && snapshot->alive && snapshot->hasRetainedRoot) ? FindSnapshotGridCellRecord(*snapshot, _path, _gridRowId, _gridColumnIndex) : std::nullopt;
    if (! cell || cell->controlRecord->gridVisibleColumns.empty())
    {
        return UIA_E_NOTSUPPORTED;
    }

    wil::com_ptr_nothrow<IRawElementProviderFragment> fragment;
    fragment.attach(CreateGridHeaderProvider(_path, cell->columnIndex));
    wil::com_ptr_nothrow<IRawElementProviderSimple> simple;
    if (! fragment || FAILED(fragment.query_to(simple.put())))
    {
        return E_OUTOFMEMORY;
    }

    IRawElementProviderSimple* provider = simple.get();
    return SetProviderArray(outColumnHeaderItems, std::span<IRawElementProviderSimple* const>(&provider, 1u));
}

ControlHost* AccessibilityProvider::ResolveHost() const noexcept
{
    if (! CaptureSnapshot())
        return nullptr;
    return _target ? _target->ResolveHost() : nullptr;
}

const Control* AccessibilityProvider::ResolveRootControl() const noexcept
{
    ControlHost* host = ResolveHost();
    return host ? host->GetRoot() : nullptr;
}

bool AccessibilityProvider::ResolveControlPath(ControlPath& outPath) const noexcept
{
    if (_kind == AccessibilityFragmentKind::Control || _kind == AccessibilityFragmentKind::TextFieldPasswordRevealButton)
    {
        outPath = _path;
        return true;
    }

    if (_kind == AccessibilityFragmentKind::Root)
    {
        return TryResolveSingleSemanticRootControlPath(ResolveRootControl(), outPath);
    }

    return false;
}

const Control* AccessibilityProvider::ResolveControl() const noexcept
{
    ControlPath path{};
    if (! ResolveControlPath(path))
    {
        return nullptr;
    }

    ControlHost* host = ResolveHost();
    if (! host || ! IsControlPathVisible(host->GetRoot(), path))
        return nullptr;
    return ResolveIdentifiedControlAtPath(host->GetRoot(), path, _identity);
}

Control* AccessibilityProvider::ResolveMutableControl() const noexcept
{
    ControlPath path{};
    if (! ResolveControlPath(path))
    {
        return nullptr;
    }

    ControlHost* host = ResolveHost();
    if (! host || ! IsControlPathVisible(host->GetRoot(), path))
        return nullptr;
    return ResolveIdentifiedControlAtPath(host->GetRoot(), path, _identity);
}

const Tree* AccessibilityProvider::ResolveTreeControl() const noexcept
{
    ControlPath path{};
    if (_kind == AccessibilityFragmentKind::TreeItem)
    {
        path = _path;
    }
    else if (! ResolveControlPath(path))
    {
        return nullptr;
    }

    ControlHost* host = ResolveHost();
    return host ? dynamic_cast<const Tree*>(ResolveIdentifiedControlAtPath(host->GetRoot(), path, _identity)) : nullptr;
}

Tree* AccessibilityProvider::ResolveMutableTreeControl() const noexcept
{
    ControlPath path{};
    if (_kind == AccessibilityFragmentKind::TreeItem)
    {
        path = _path;
    }
    else if (! ResolveControlPath(path))
    {
        return nullptr;
    }

    ControlHost* host = ResolveHost();
    return host ? dynamic_cast<Tree*>(ResolveIdentifiedControlAtPath(host->GetRoot(), path, _identity)) : nullptr;
}

const Grid* AccessibilityProvider::ResolveGridControl() const noexcept
{
    ControlPath path{};
    if (_kind == AccessibilityFragmentKind::GridHeader || _kind == AccessibilityFragmentKind::GridRow || _kind == AccessibilityFragmentKind::GridCell)
    {
        path = _path;
    }
    else if (! ResolveControlPath(path))
    {
        return nullptr;
    }

    ControlHost* host = ResolveHost();
    return host ? dynamic_cast<const Grid*>(ResolveIdentifiedControlAtPath(host->GetRoot(), path, _identity)) : nullptr;
}

Grid* AccessibilityProvider::ResolveMutableGridControl() const noexcept
{
    ControlPath path{};
    if (_kind == AccessibilityFragmentKind::GridHeader || _kind == AccessibilityFragmentKind::GridRow || _kind == AccessibilityFragmentKind::GridCell)
    {
        path = _path;
    }
    else if (! ResolveControlPath(path))
    {
        return nullptr;
    }

    ControlHost* host = ResolveHost();
    return host ? dynamic_cast<Grid*>(ResolveIdentifiedControlAtPath(host->GetRoot(), path, _identity)) : nullptr;
}

bool AccessibilityProvider::ResolveTreeVisibleIndex(size_t& outVisibleIndex) const noexcept
{
    const Tree* tree  = ResolveTreeControl();
    const auto* model = tree ? tree->GetModel() : nullptr;
    if (! tree || ! model)
    {
        return false;
    }

    const std::optional<size_t> visibleIndex = model->FindVisibleItemById(_treeItemId);
    if (! visibleIndex)
    {
        return false;
    }

    outVisibleIndex = visibleIndex.value();
    return true;
}

bool AccessibilityProvider::ResolveTreeItemData(TreeItemData& outItem) const noexcept
{
    const Tree* tree    = ResolveTreeControl();
    const auto* model   = tree ? tree->GetModel() : nullptr;
    size_t visibleIndex = 0u;
    if (! model || ! ResolveTreeVisibleIndex(visibleIndex))
    {
        return false;
    }

    model->GetVisibleItem(visibleIndex, outItem);
    return true;
}

bool AccessibilityProvider::ResolveGridRowIndex(size_t& outRowIndex) const noexcept
{
    const Grid* grid  = ResolveGridControl();
    const auto* model = grid ? grid->GetModel() : nullptr;
    if (! grid || ! model)
    {
        return false;
    }

    const std::optional<size_t> rowIndex = model->FindRowByStableId(_gridRowId);
    if (! rowIndex)
    {
        return false;
    }

    outRowIndex = rowIndex.value();
    return true;
}

bool AccessibilityProvider::ResolveGridCellData(size_t& outRowIndex, size_t& outColumnIndex, GridCellData& outCellData) const noexcept
{
    const Grid* grid  = ResolveGridControl();
    const auto* model = grid ? grid->GetModel() : nullptr;
    if (! grid || ! model || ! ResolveGridRowIndex(outRowIndex) || ! grid->FindVisibleRowOrdinal(outRowIndex) ||
        ! grid->FindVisibleColumnOrdinal(_gridColumnIndex))
    {
        return false;
    }

    outColumnIndex = _gridColumnIndex;
    outCellData    = {};
    model->GetCellData(outRowIndex, outColumnIndex, outCellData);
    return true;
}

WindowHostAccessibilityTarget* AccessibilityProvider::AddRefTarget() const noexcept
{
    if (_target)
    {
        static_cast<void>(_target->AddRef());
    }

    return _target;
}

bool AccessibilityProvider::IsCurrentThreadWindowThread() const noexcept
{
    return _target &&
           (_target->embedded ? _target->threadId == GetCurrentThreadId() : _hwnd && GetWindowThreadProcessId(_hwnd, nullptr) == GetCurrentThreadId());
}

HRESULT AccessibilityProvider::DispatchActionToWindowThread(AccessibilityUiActionRequest& request) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (_target && _target->embedded)
        return RPC_E_WRONG_THREAD;
    return DispatchAccessibilityUiActionToWindowThread(_hwnd, request);
}

HRESULT AccessibilityProvider::ExecuteUiThreadAction(AccessibilityUiActionRequest& request) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    switch (request.kind)
    {
        case AccessibilityUiActionKind::SetFocus: return ExecuteSetFocusOnWindowThread();
        case AccessibilityUiActionKind::Invoke: return ExecuteInvokeOnWindowThread();
        case AccessibilityUiActionKind::Toggle: return ExecuteToggleOnWindowThread();
        case AccessibilityUiActionKind::SetStringValue: return ExecuteSetStringValueOnWindowThread(request.stringValue.c_str());
        case AccessibilityUiActionKind::SetRangeValue: return ExecuteSetRangeValueOnWindowThread(request.numberValue);
        case AccessibilityUiActionKind::ResolveTextRangeFromPoint:
            return ExecuteResolveTextRangeFromPointOnWindowThread(request.textRangePoint, request.textRangeResultStart, request.textRangeTextLength);
        case AccessibilityUiActionKind::Select: return ExecuteSelectOnWindowThread();
        case AccessibilityUiActionKind::AddToSelection: return ExecuteAddToSelectionOnWindowThread();
        case AccessibilityUiActionKind::RemoveFromSelection: return ExecuteRemoveFromSelectionOnWindowThread();
        case AccessibilityUiActionKind::Expand: return ExecuteExpandOnWindowThread(true);
        case AccessibilityUiActionKind::Collapse: return ExecuteExpandOnWindowThread(false);
        case AccessibilityUiActionKind::ExpandTextRangeToVisualLine: return UIA_E_NOTSUPPORTED;
        case AccessibilityUiActionKind::MoveTextRangeByVisualLine: return UIA_E_NOTSUPPORTED;
        case AccessibilityUiActionKind::MoveTextRangeEndpointByVisualLine: return UIA_E_NOTSUPPORTED;
        case AccessibilityUiActionKind::ResolveTextRangeBounds: return UIA_E_NOTSUPPORTED;
    }

    return UIA_E_NOTSUPPORTED;
}

template <typename ResolveCurrentTarget>
[[nodiscard]] bool RevalidateAccessibilityActionTarget(const std::weak_ptr<int>& lifetime, ResolveCurrentTarget&& resolveCurrentTarget) noexcept
{
    // Check the independently captured owner token before the provider resolves its path again. The provider identity may be
    // zero, and a callback may have replaced the control at the same path with a new object.
    if (lifetime.expired())
        return false;
    const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
    return resolveCurrentTarget();
}

HRESULT AccessibilityProvider::ExecuteSetFocusOnWindowThread() noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    // The mutex guards resolving the host only. Moving focus runs the application's callbacks (the embedded site's
    // RequestFocus, the host's focus-changed callback) and raises UI Automation events, none of which run under it.
    ControlHost* host = nullptr;
    std::shared_ptr<EmbeddedAccessibilitySite> site;
    Control* owner  = nullptr;
    Tree* ownerTree = nullptr;
    Grid* ownerGrid = nullptr;
    std::weak_ptr<int> lifetime;
    TreeItemData treeItem{};
    size_t itemIndex            = 0u;
    size_t requestedColumnIndex = 0u;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        host = ResolveHost();
        if (! host)
        {
            return S_OK;
        }
        if (_target->embedded)
        {
            site = _target->site;
            if (! site)
                return UIA_E_ELEMENTNOTAVAILABLE;
        }

        if (_kind == AccessibilityFragmentKind::TreeItem)
        {
            ownerTree = ResolveMutableTreeControl();
            if (! ownerTree || ! ResolveTreeItemData(treeItem) || ! ResolveTreeVisibleIndex(itemIndex))
                return UIA_E_ELEMENTNOTAVAILABLE;
            owner = ownerTree;
        }
        else if (_kind == AccessibilityFragmentKind::GridHeader || _kind == AccessibilityFragmentKind::GridRow || _kind == AccessibilityFragmentKind::GridCell)
        {
            ownerGrid = ResolveMutableGridControl();
            owner     = ownerGrid;
            if (ownerGrid && _kind == AccessibilityFragmentKind::GridRow && ! ResolveGridRowIndex(itemIndex))
                return UIA_E_ELEMENTNOTAVAILABLE;
            if (ownerGrid && _kind == AccessibilityFragmentKind::GridCell)
            {
                GridCellData cellData{};
                if (! ResolveGridCellData(itemIndex, requestedColumnIndex, cellData))
                    return UIA_E_ELEMENTNOTAVAILABLE;
            }
        }
        else
            owner = ResolveMutableControl();

        if (owner)
            lifetime = GetControlLifetimeToken(*owner);
    }

    const auto survived = [&]() noexcept
    {
        if (! owner)
        {
            const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
            return ResolveHost() == host && (_kind != AccessibilityFragmentKind::Root || ResolveMutableControl() == nullptr);
        }
        return RevalidateAccessibilityActionTarget(lifetime,
                                                   [&]() noexcept
        {
            if (ResolveHost() != host)
                return false;
            if (owner)
            {
                Control* current = ownerTree ? static_cast<Control*>(ResolveMutableTreeControl())
                                             : (ownerGrid ? static_cast<Control*>(ResolveMutableGridControl()) : ResolveMutableControl());
                if (current != owner)
                    return false;
                if (ownerTree)
                {
                    size_t currentIndex = 0u;
                    TreeItemData currentItem{};
                    return ResolveTreeVisibleIndex(currentIndex) && ResolveTreeItemData(currentItem) && currentItem.id == treeItem.id;
                }
                if (ownerGrid && _kind == AccessibilityFragmentKind::GridRow)
                {
                    size_t currentIndex = 0u;
                    return ResolveGridRowIndex(currentIndex);
                }
                if (ownerGrid && _kind == AccessibilityFragmentKind::GridCell)
                {
                    size_t currentRow = 0u, currentColumn = 0u;
                    GridCellData currentCell{};
                    return ResolveGridCellData(currentRow, currentColumn, currentCell) && currentColumn == requestedColumnIndex;
                }
            }
            return true;
        });
    };

    if (site)
    {
        const HRESULT hr = site->RequestFocus();
        if (FAILED(hr))
            return hr;
        if (! survived())
            return UIA_E_ELEMENTNOTAVAILABLE;
    }
    // Moving focus runs application code (native focus, the host's focus-changed callback) that can rebuild the controls:
    // an element whose control did not survive it reports itself gone instead of success, and moves no further focus.
    if (_kind == AccessibilityFragmentKind::Root)
    {
        // A native menu popup keeps its session's Win32 focus target: activating a submenu popup would dismiss the
        // whole menu, as for its rows below.
        if (! _target->embedded && ! IsNativeMenuPopupWindow(_hwnd))
            ::SetFocus(_hwnd);
        return survived() ? S_OK : UIA_E_ELEMENTNOTAVAILABLE;
    }

    if (_kind == AccessibilityFragmentKind::TreeItem)
    {
        TreeItemData item{};
        Tree* tree = ResolveMutableTreeControl();
        if (! tree || ! ResolveTreeItemData(item))
        {
            return UIA_E_ELEMENTNOTAVAILABLE;
        }

        // A tree that selects one item selects what it focuses; with multi-select only the focus moves. The selection's
        // delegate may rebuild the controls: a tree it destroyed is not focused.
        tree->SetFocusedItemId(item.id);
        if (! survived())
            return UIA_E_ELEMENTNOTAVAILABLE;
        host->SetFocusControl(tree);
        if (! survived())
            return UIA_E_ELEMENTNOTAVAILABLE;
        RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
        if (! survived())
            return UIA_E_ELEMENTNOTAVAILABLE;
        if (! _target->embedded)
            ::SetFocus(_hwnd);
        if (! survived())
            return UIA_E_ELEMENTNOTAVAILABLE;
        host->Invalidate();
        return survived() ? S_OK : UIA_E_ELEMENTNOTAVAILABLE;
    }

    if (_kind == AccessibilityFragmentKind::GridHeader)
    {
        Grid* grid = ResolveMutableGridControl();
        if (grid)
        {
            host->SetFocusControl(grid);
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            if (! _target->embedded)
                ::SetFocus(_hwnd);
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            host->Invalidate();
        }
        return survived() ? S_OK : UIA_E_ELEMENTNOTAVAILABLE;
    }

    if (_kind == AccessibilityFragmentKind::GridRow)
    {
        size_t rowIndex = 0u;
        Grid* grid      = ResolveMutableGridControl();
        if (grid && ResolveGridRowIndex(rowIndex) && grid->RequestSelectRow(rowIndex, 0u))
        {
            // The selection's delegate may rebuild the controls: a grid it destroyed is not focused.
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            host->SetFocusControl(grid);
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            if (! _target->embedded)
                ::SetFocus(_hwnd);
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            host->Invalidate();
        }
        return survived() ? S_OK : UIA_E_ELEMENTNOTAVAILABLE;
    }

    if (_kind == AccessibilityFragmentKind::GridCell)
    {
        size_t rowIndex    = 0u;
        size_t columnIndex = 0u;
        GridCellData cellData{};
        Grid* grid = ResolveMutableGridControl();
        if (grid && ResolveGridCellData(rowIndex, columnIndex, cellData) && grid->RequestSelectRow(rowIndex, 0u))
        {
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            host->SetFocusControl(grid);
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            if (! _target->embedded)
                ::SetFocus(_hwnd);
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            host->Invalidate();
        }
        return survived() ? S_OK : UIA_E_ELEMENTNOTAVAILABLE;
    }

    if (_kind == AccessibilityFragmentKind::TextFieldPasswordRevealButton)
    {
        auto* textField = dynamic_cast<TextField*>(ResolveMutableControl());
        if (textField && textField->IsPasswordRevealButtonVisibleForAccessibility())
        {
            host->SetFocusControl(textField);
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            if (! _target->embedded)
                ::SetFocus(_hwnd);
            if (! survived())
                return UIA_E_ELEMENTNOTAVAILABLE;
            host->Invalidate();
        }
        return survived() ? S_OK : UIA_E_ELEMENTNOTAVAILABLE;
    }

    Control* control = ResolveMutableControl();
    if (control && control->IsFocusable())
    {
        // Native menu popups track logical row focus while the menu session keeps its Win32
        // focus target: the root popup, which modal and asynchronous tracking both activate.
        // Submenus never activate. This follows the popup host, so every focusable row qualifies,
        // including sliders, and ordinary controls that use the MenuItem role keep native focus transfer.
        const bool nativeMenuRow = ! _target->embedded && IsNativeMenuPopupWindow(_hwnd);
        host->SetFocusControl(control, ! nativeMenuRow);
        if (! survived())
            return UIA_E_ELEMENTNOTAVAILABLE;
        if (! _target->embedded && ! nativeMenuRow)
            ::SetFocus(_hwnd);
        if (! survived())
            return UIA_E_ELEMENTNOTAVAILABLE;
    }
    return survived() ? S_OK : UIA_E_ELEMENTNOTAVAILABLE;
}

HRESULT AccessibilityProvider::ExecuteInvokeOnWindowThread() noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    ControlHost* host          = nullptr;
    TextField* revealTextField = nullptr;
    Button* button             = nullptr;
    Control* accessibleControl = nullptr;
    Control* owner             = nullptr;
    std::weak_ptr<int> lifetime;

    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        host = ResolveHost();
        if (! host)
        {
            return UIA_E_NOTSUPPORTED;
        }

        // Invoke callbacks can rebuild or destroy parts of the DxUi tree and may
        // raise accessibility events. Validate the target while locked, then run
        // the application callback after releasing the accessibility mutex.
        if (_kind == AccessibilityFragmentKind::TextFieldPasswordRevealButton)
        {
            revealTextField = dynamic_cast<TextField*>(ResolveMutableControl());
            if (! revealTextField || ! revealTextField->IsPasswordRevealButtonVisibleForAccessibility())
            {
                return UIA_E_NOTSUPPORTED;
            }
            owner = revealTextField;
        }
        else
        {
            accessibleControl = ResolveMutableControl();
            if (! accessibleControl || ! SupportsInvokePattern(accessibleControl))
            {
                return UIA_E_NOTSUPPORTED;
            }
            button = dynamic_cast<Button*>(accessibleControl);
            owner  = accessibleControl;
        }
        lifetime = GetControlLifetimeToken(*owner);
    }

    const auto survived = [&]() noexcept
    {
        return RevalidateAccessibilityActionTarget(lifetime,
                                                   [&]() noexcept
        {
            if (ResolveHost() != host)
                return false;
            return _kind == AccessibilityFragmentKind::TextFieldPasswordRevealButton ? ResolveMutableControl() == revealTextField
                                                                                     : ResolveMutableControl() == accessibleControl;
        });
    };

    if (_kind == AccessibilityFragmentKind::TextFieldPasswordRevealButton)
    {
        const bool invoked = revealTextField->InvokePasswordRevealButton(*host);
        if (! survived())
            return UIA_E_ELEMENTNOTAVAILABLE;
        return invoked ? S_OK : UIA_E_NOTSUPPORTED;
    }

    if (accessibleControl && accessibleControl->SupportsAccessibleInvoke())
    {
        const bool invoked = accessibleControl->InvokeAccessible(*host);
        if (! survived())
            return UIA_E_ELEMENTNOTAVAILABLE;
        return invoked ? S_OK : UIA_E_NOTSUPPORTED;
    }

    // The button focuses itself first, and a focus callback that rebuilds the controls ends the invocation (Button::Invoke):
    // the element then reports its control gone.
    const bool invoked = button->Invoke(*host, true);
    if (! survived())
        return UIA_E_ELEMENTNOTAVAILABLE;
    return invoked ? S_OK : UIA_E_NOTSUPPORTED;
}

HRESULT AccessibilityProvider::ExecuteToggleOnWindowThread() noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    ControlHost* host = nullptr;
    Control* owner    = nullptr;
    std::weak_ptr<int> ownerLifetime;
    size_t rowIndex    = 0u;
    size_t columnIndex = 0u;
    GridCellData cellData{};
    DxUi::Toggle* toggle = nullptr;
    Grid* grid           = nullptr;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        host = ResolveHost();
        if (! host)
            return UIA_E_NOTSUPPORTED;

        if (_kind == AccessibilityFragmentKind::GridCell)
        {
            grid = ResolveMutableGridControl();
            if (! grid || ! ResolveGridCellData(rowIndex, columnIndex, cellData) || ! GridCellSupportsTogglePattern(cellData))
                return UIA_E_NOTSUPPORTED;
            if (! grid->IsEnabled())
                return UIA_E_ELEMENTNOTENABLED;
            owner = grid;
        }
        else
        {
            toggle = dynamic_cast<DxUi::Toggle*>(ResolveMutableControl());
            if (! toggle)
                return UIA_E_NOTSUPPORTED;
            if (! toggle->IsEnabled())
                return UIA_E_ELEMENTNOTENABLED;
            owner = toggle;
        }
        ownerLifetime = GetControlLifetimeToken(*owner);
    }

    // Application delegates are allowed to query UI Automation or replace the retained tree.
    const bool changed = grid ? grid->RequestToggleCheckboxCell(*host, rowIndex, columnIndex) : toggle->OnMnemonic(*host);
    if (ownerLifetime.expired())
        return UIA_E_ELEMENTNOTAVAILABLE;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        if (ResolveHost() != host || (_kind == AccessibilityFragmentKind::GridCell ? ResolveMutableGridControl() != grid : ResolveMutableControl() != toggle))
            return UIA_E_ELEMENTNOTAVAILABLE;
        if (_kind == AccessibilityFragmentKind::GridCell)
        {
            size_t currentRow = 0u, currentColumn = 0u;
            GridCellData current{};
            if (! ResolveGridCellData(currentRow, currentColumn, current) || currentRow != rowIndex || currentColumn != columnIndex)
                return UIA_E_ELEMENTNOTAVAILABLE;
        }
    }
    if (! changed)
    {
        return UIA_E_NOTSUPPORTED;
    }
    RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
    if (ownerLifetime.expired())
        return UIA_E_ELEMENTNOTAVAILABLE;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        if (ResolveHost() != host || (grid ? ResolveMutableGridControl() != grid : ResolveMutableControl() != toggle))
            return UIA_E_ELEMENTNOTAVAILABLE;
        if (grid)
        {
            size_t currentRow = 0u, currentColumn = 0u;
            GridCellData current{};
            if (! ResolveGridCellData(currentRow, currentColumn, current) || currentRow != rowIndex || currentColumn != columnIndex)
                return UIA_E_ELEMENTNOTAVAILABLE;
        }
    }
    return S_OK;
}

HRESULT AccessibilityProvider::ExecuteSetStringValueOnWindowThread(LPCWSTR value) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    ControlHost* host = nullptr;
    Control* control  = nullptr;
    std::weak_ptr<int> lifetime;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        host    = ResolveHost();
        control = ResolveMutableControl();
        if (! host || ! control || ! control->IsEnabled() || ! SupportsValuePattern(control) || IsValueReadOnly(control))
            return UIA_E_NOTSUPPORTED;
        lifetime = GetControlLifetimeToken(*control);
    }
    const size_t length = value ? wcsnlen(value, 65537) : 0;
    if (length > 65536)
        return E_INVALIDARG;
    for (size_t i = 0; i < length; ++i)
    {
        if (IsUtf16LeadSurrogate(value[i]))
        {
            if (++i == length || ! IsUtf16TrailSurrogate(value[i]))
                return E_INVALIDARG;
        }
        else if (IsUtf16TrailSurrogate(value[i]))
            return E_INVALIDARG;
    }
    try
    {
        if (auto* field = dynamic_cast<TextField*>(control))
            field->SetTextAndNotify(value ? value : L"");
        else if (auto* combo = dynamic_cast<ComboBox*>(control))
            combo->SetTextAndNotify(value ? value : L"");
        else
            return UIA_E_NOTSUPPORTED;
        if (lifetime.expired())
            return UIA_E_ELEMENTNOTAVAILABLE;
        {
            const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
            if (ResolveHost() != host || ResolveMutableControl() != control)
                return UIA_E_ELEMENTNOTAVAILABLE;
        }
        host->SyncTextInput(control);
        RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
        if (lifetime.expired())
            return UIA_E_ELEMENTNOTAVAILABLE;
        {
            const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
            if (ResolveHost() != host || ResolveMutableControl() != control)
                return UIA_E_ELEMENTNOTAVAILABLE;
        }
        host->Invalidate();
        return S_OK;
    }
    catch (const std::bad_alloc&)
    {
        return E_OUTOFMEMORY;
    }
    catch (const std::exception&)
    {
        return E_FAIL;
    }
}

HRESULT AccessibilityProvider::ExecuteSetRangeValueOnWindowThread(double value) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    ControlHost* host  = nullptr;
    Control* control   = nullptr;
    Slider* slider     = nullptr;
    Splitter* splitter = nullptr;
    std::weak_ptr<int> lifetime;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        host    = ResolveHost();
        control = ResolveMutableControl();
        if (! host || ! control || ! control->IsEnabled() || ! SupportsRangeValuePattern(control) || IsValueReadOnly(control))
            return UIA_E_NOTSUPPORTED;
        slider   = dynamic_cast<Slider*>(control);
        splitter = dynamic_cast<Splitter*>(control);
        if (! slider && ! splitter)
            return UIA_E_NOTSUPPORTED;
        lifetime = GetControlLifetimeToken(*control);
    }

    bool accepted = false;
    if (slider)
        accepted = slider->RequestValue(*host, value);
    else
        // One committed change, like the keyboard; refused mid-drag. The consumer re-lays out its panes.
        accepted = std::isfinite(value) && splitter->RequestPosition(*host, static_cast<float>(value));

    if (lifetime.expired())
        return UIA_E_ELEMENTNOTAVAILABLE;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        if (ResolveHost() != host || ResolveMutableControl() != control)
            return UIA_E_ELEMENTNOTAVAILABLE;
    }
    if (! accepted)
        return E_INVALIDARG;
    RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
    if (lifetime.expired())
        return UIA_E_ELEMENTNOTAVAILABLE;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        if (ResolveHost() != host || ResolveMutableControl() != control)
            return UIA_E_ELEMENTNOTAVAILABLE;
    }
    host->Invalidate();
    return S_OK;
}

HRESULT AccessibilityProvider::ExecuteSelectOnWindowThread() noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    ControlHost* host = nullptr;
    Tree* tree        = nullptr;
    Grid* grid        = nullptr;
    Control* owner    = nullptr;
    std::weak_ptr<int> lifetime;
    size_t index = 0u;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        host = ResolveHost();
        if (! host)
            return UIA_E_NOTSUPPORTED;
        if (_kind == AccessibilityFragmentKind::TreeItem)
        {
            tree = ResolveMutableTreeControl();
            if (! tree || ! tree->IsEnabled() || ! ResolveTreeVisibleIndex(index))
                return tree && ! tree->IsEnabled() ? UIA_E_ELEMENTNOTENABLED : UIA_E_ELEMENTNOTAVAILABLE;
            owner = tree;
        }
        else if (_kind == AccessibilityFragmentKind::GridRow)
        {
            grid = ResolveMutableGridControl();
            if (! grid || ! grid->IsEnabled() || ! ResolveGridRowIndex(index))
                return grid && ! grid->IsEnabled() ? UIA_E_ELEMENTNOTENABLED : UIA_E_ELEMENTNOTAVAILABLE;
            owner = grid;
        }
        else
            return UIA_E_NOTSUPPORTED;
        lifetime = GetControlLifetimeToken(*owner);
    }

    const auto survives = [&]() noexcept
    {
        if (lifetime.expired())
            return false;
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        if (ResolveHost() != host || (tree ? ResolveMutableTreeControl() != tree : ResolveMutableGridControl() != grid))
            return false;
        size_t currentIndex = 0u;
        return _kind == AccessibilityFragmentKind::TreeItem ? ResolveTreeVisibleIndex(currentIndex) : ResolveGridRowIndex(currentIndex);
    };

    const bool accepted = tree ? tree->RequestSelectVisibleItem(index) : grid->RequestSelectRow(index, 0u);
    if (! survives())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! accepted)
        return tree ? UIA_E_ELEMENTNOTAVAILABLE : UIA_E_NOTSUPPORTED;
    host->SetFocusControl(owner);
    if (! survives())
        return UIA_E_ELEMENTNOTAVAILABLE;
    RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
    if (! survives())
        return UIA_E_ELEMENTNOTAVAILABLE;
    host->Invalidate();
    return S_OK;
}

HRESULT AccessibilityProvider::ExecuteAddToSelectionOnWindowThread() noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    ControlHost* host = nullptr;
    Tree* tree        = nullptr;
    Grid* grid        = nullptr;
    Control* owner    = nullptr;
    std::weak_ptr<int> lifetime;
    size_t index         = 0u;
    bool alreadySelected = false;
    bool singleSelect    = false;
    if (_kind == AccessibilityFragmentKind::TreeItem)
    {
        {
            const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
            host = ResolveHost();
            tree = ResolveMutableTreeControl();
            if (! host || ! tree)
                return UIA_E_ELEMENTNOTAVAILABLE;
            if (! tree->IsEnabled())
                return UIA_E_ELEMENTNOTENABLED;
            if (! ResolveTreeVisibleIndex(index))
                return UIA_E_ELEMENTNOTAVAILABLE;
            singleSelect = ! tree->MultiSelectEnabled();
            owner        = tree;
            lifetime     = GetControlLifetimeToken(*tree);
        }
        if (singleSelect)
        {
            // A single selection has nothing to add to: the item becomes the selection.
            return ExecuteSelectOnWindowThread();
        }
    }
    else if (_kind == AccessibilityFragmentKind::GridRow)
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        host = ResolveHost();
        grid = ResolveMutableGridControl();
        if (! host || ! grid || ! ResolveGridRowIndex(index))
            return UIA_E_ELEMENTNOTAVAILABLE;
        if (! grid->IsEnabled())
            return UIA_E_ELEMENTNOTENABLED;
        alreadySelected = grid->IsRowSelected(index);
        owner           = grid;
        lifetime        = GetControlLifetimeToken(*grid);
    }
    else
        return UIA_E_NOTSUPPORTED;

    const auto survives = [&]() noexcept
    {
        if (lifetime.expired())
            return false;
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        if (ResolveHost() != host || (tree ? ResolveMutableTreeControl() != tree : ResolveMutableGridControl() != grid))
            return false;
        size_t currentIndex = 0u;
        return tree ? ResolveTreeVisibleIndex(currentIndex) : ResolveGridRowIndex(currentIndex);
    };
    bool accepted = true;
    if (tree)
        accepted = tree->RequestAddVisibleItemToSelection(index);
    else if (! alreadySelected)
        accepted = grid->RequestSelectRow(index, MK_CONTROL);
    if (! survives())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (! accepted)
        return UIA_E_NOTSUPPORTED;
    host->SetFocusControl(owner);
    if (! survives())
        return UIA_E_ELEMENTNOTAVAILABLE;
    RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
    if (! survives())
        return UIA_E_ELEMENTNOTAVAILABLE;
    host->Invalidate();
    return S_OK;
}

HRESULT AccessibilityProvider::ExecuteRemoveFromSelectionOnWindowThread() noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    ControlHost* host = nullptr;
    Tree* tree        = nullptr;
    Grid* grid        = nullptr;
    Control* owner    = nullptr;
    std::weak_ptr<int> lifetime;
    size_t index = 0u;
    TreeItemData item{};
    bool wasSelected = false;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        host = ResolveHost();
        if (! host)
            return UIA_E_NOTSUPPORTED;
        if (_kind == AccessibilityFragmentKind::TreeItem)
        {
            tree = ResolveMutableTreeControl();
            if (! tree || ! ResolveTreeItemData(item) || ! ResolveTreeVisibleIndex(index))
                return UIA_E_ELEMENTNOTAVAILABLE;
            if (! tree->IsEnabled())
                return UIA_E_ELEMENTNOTENABLED;
            owner       = tree;
            wasSelected = tree->GetSelectedItemId() && tree->GetSelectedItemId().value() == item.id;
            lifetime    = GetControlLifetimeToken(*tree);
        }
        else if (_kind == AccessibilityFragmentKind::GridRow)
        {
            grid = ResolveMutableGridControl();
            if (! grid || ! ResolveGridRowIndex(index))
                return UIA_E_ELEMENTNOTAVAILABLE;
            if (! grid->IsEnabled())
                return UIA_E_ELEMENTNOTENABLED;
            owner       = grid;
            wasSelected = grid->IsRowSelected(index);
            lifetime    = GetControlLifetimeToken(*grid);
        }
        else
            return UIA_E_NOTSUPPORTED;
    }

    const auto survives = [&]() noexcept
    {
        if (lifetime.expired())
            return false;
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        if (ResolveHost() != host || (tree ? ResolveMutableTreeControl() != tree : ResolveMutableGridControl() != grid))
            return false;
        size_t currentIndex = 0u;
        return tree ? ResolveTreeVisibleIndex(currentIndex) : ResolveGridRowIndex(currentIndex);
    };

    if (_kind == AccessibilityFragmentKind::TreeItem)
    {
        if (tree->MultiSelectEnabled())
        {
            // Only this item leaves the selection; the others stay and so does the focus.
            const bool accepted = tree->RequestRemoveVisibleItemFromSelection(index);
            if (! survives())
                return UIA_E_ELEMENTNOTAVAILABLE;
            if (! accepted)
                return UIA_E_ELEMENTNOTAVAILABLE;

            RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
            if (! survives())
                return UIA_E_ELEMENTNOTAVAILABLE;
            host->Invalidate();
            return S_OK;
        }

        if (wasSelected)
        {
            tree->SetSelectedItemId(std::nullopt);
            if (! survives())
                return UIA_E_ELEMENTNOTAVAILABLE;
            RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
            if (! survives())
                return UIA_E_ELEMENTNOTAVAILABLE;
            host->Invalidate();
        }

        return S_OK;
    }

    if (_kind == AccessibilityFragmentKind::GridRow)
    {
        const bool accepted = wasSelected && grid->RequestRemoveRowSelection(index);
        if (! survives())
            return UIA_E_ELEMENTNOTAVAILABLE;
        if (wasSelected && ! accepted)
            return UIA_E_NOTSUPPORTED;

        RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
        if (! survives())
            return UIA_E_ELEMENTNOTAVAILABLE;
        host->Invalidate();
        return S_OK;
    }

    return UIA_E_NOTSUPPORTED;
}

HRESULT AccessibilityProvider::ExecuteExpandOnWindowThread(bool expanded) noexcept
{
    if (! CaptureSnapshot())
        return UIA_E_ELEMENTNOTAVAILABLE;
    if (_kind == AccessibilityFragmentKind::Control || _kind == AccessibilityFragmentKind::Root)
    {
        ControlHost* host = nullptr;
        Button* button    = nullptr;
        std::weak_ptr<int> lifetime;
        {
            const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
            host   = ResolveHost();
            button = dynamic_cast<Button*>(ResolveMutableControl());
            if (! host || ! button)
            {
                return UIA_E_ELEMENTNOTAVAILABLE;
            }
            const auto acknowledged = button->GetDisclosureExpanded();
            if (! acknowledged.has_value())
            {
                return UIA_E_NOTSUPPORTED;
            }
            if (! button->IsEnabled())
            {
                return UIA_E_ELEMENTNOTENABLED;
            }
            if (acknowledged.value() == expanded)
            {
                return S_OK;
            }
            lifetime = GetControlLifetimeToken(*button);
        }
        // Like Invoke, release the snapshot lock before a callback which may destroy the tree.
        // The application acknowledges state and owns content visibility; do not retain/touch button afterward.
        const bool invoked = button->Invoke(*host, true);
        if (lifetime.expired())
            return UIA_E_ELEMENTNOTAVAILABLE;
        {
            const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
            if (ResolveHost() != host || ResolveMutableControl() != button)
                return UIA_E_ELEMENTNOTAVAILABLE;
        }
        return invoked ? S_OK : UIA_E_NOTSUPPORTED;
    }
    ControlHost* host = nullptr;
    Tree* tree        = nullptr;
    std::weak_ptr<int> lifetime;
    TreeItemData item;
    size_t visibleIndex = 0u;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        host = ResolveHost();
        tree = ResolveMutableTreeControl();
        if (! host || ! tree)
            return UIA_E_ELEMENTNOTAVAILABLE;
        if (! tree->IsEnabled())
            return UIA_E_ELEMENTNOTENABLED;
        if (! ResolveTreeItemData(item) || ! ResolveTreeVisibleIndex(visibleIndex))
            return UIA_E_ELEMENTNOTAVAILABLE;
        lifetime = GetControlLifetimeToken(*tree);
    }
    if (! item.hasChildren)
    {
        return UIA_E_NOTSUPPORTED;
    }
    const bool stateChanged = item.expanded != expanded;
    const bool accepted     = tree->RequestExpandedState(visibleIndex, expanded);
    if (lifetime.expired())
        return UIA_E_ELEMENTNOTAVAILABLE;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        size_t currentIndex = 0u;
        if (ResolveHost() != host || ResolveMutableTreeControl() != tree || ! ResolveTreeVisibleIndex(currentIndex))
            return UIA_E_ELEMENTNOTAVAILABLE;
    }
    if (! accepted)
        return UIA_E_NOTSUPPORTED;

    RefreshWindowHostAccessibilitySnapshot(_hwnd, host);
    if (lifetime.expired())
        return UIA_E_ELEMENTNOTAVAILABLE;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        size_t currentIndex = 0u;
        if (ResolveHost() != host || ResolveMutableTreeControl() != tree || ! ResolveTreeVisibleIndex(currentIndex))
            return UIA_E_ELEMENTNOTAVAILABLE;
    }
    if (stateChanged && ! host->GetTheme().reducedMotion)
    {
        host->RequestAnimation();
    }
    if (lifetime.expired())
        return UIA_E_ELEMENTNOTAVAILABLE;
    {
        const std::scoped_lock accessibilityLock(GetAccessibilityTargetMutex());
        if (ResolveHost() != host || ResolveMutableTreeControl() != tree)
            return UIA_E_ELEMENTNOTAVAILABLE;
    }
    host->Invalidate();
    return S_OK;
}

IRawElementProviderFragmentRoot* AccessibilityProvider::CreateRootProvider() noexcept
{
    auto retainedRoot = AcquireCanonicalRootProvider(_target);
    return retainedRoot.detach();
}

IRawElementProviderFragment* AccessibilityProvider::CreateRootFragmentProvider() noexcept
{
    const auto retainedRoot = AcquireCanonicalRootProvider(_target);
    wil::com_ptr_nothrow<IRawElementProviderFragment> fragment;
    if (retainedRoot)
    {
        (void)retainedRoot.query_to(&fragment);
    }
    return fragment.detach();
}

IRawElementProviderFragment* AccessibilityProvider::CreateChildProvider(const ControlPath& path) noexcept
{
    return MakeProvider<IRawElementProviderFragment, AccessibilityProvider>(_hwnd, path);
}

// The element of the control at `path`, which is the window's root element when a collapsed semantic root stands for it.
IRawElementProviderFragment* AccessibilityProvider::CreateControlProvider(const ControlPath& path) noexcept
{
    const wil::com_ptr_nothrow<IRawElementProviderSimple> element = CreateControlElement(_target, _hwnd, path);
    wil::com_ptr_nothrow<IRawElementProviderFragment> fragment;
    if (element)
    {
        static_cast<void>(element.query_to(fragment.put()));
    }
    return fragment.detach();
}

IRawElementProviderFragment* AccessibilityProvider::CreateTextFieldPasswordRevealButtonProvider(const ControlPath& path) noexcept
{
    return MakeProvider<IRawElementProviderFragment, AccessibilityProvider>(_hwnd, path, AccessibilityFragmentKind::TextFieldPasswordRevealButton);
}

IRawElementProviderFragment* AccessibilityProvider::CreateTreeItemProvider(const ControlPath& path, uint64_t itemId) noexcept
{
    return MakeProvider<IRawElementProviderFragment, AccessibilityProvider>(_hwnd, path, itemId, AccessibilityProvider::TreeItemTag{});
}

IRawElementProviderFragment* AccessibilityProvider::CreateGridHeaderProvider(const ControlPath& path, size_t columnIndex) noexcept
{
    return MakeProvider<IRawElementProviderFragment, AccessibilityProvider>(_hwnd, path, columnIndex, AccessibilityProvider::GridHeaderTag{});
}

IRawElementProviderFragment* AccessibilityProvider::CreateGridRowProvider(const ControlPath& path, uint64_t rowId) noexcept
{
    return MakeProvider<IRawElementProviderFragment, AccessibilityProvider>(_hwnd, path, rowId, AccessibilityFragmentKind::GridRow);
}

IRawElementProviderFragment* AccessibilityProvider::CreateGridCellProvider(const ControlPath& path, uint64_t rowId, size_t columnIndex) noexcept
{
    return MakeProvider<IRawElementProviderFragment, AccessibilityProvider>(_hwnd, path, rowId, columnIndex);
}

IRawElementProviderFragment* AccessibilityProvider::CreateProviderFromNavigationTarget(const AccessibilityNavigationTarget& navigationTarget) noexcept
{
    switch (navigationTarget.kind)
    {
        case AccessibilityFragmentKind::Root:
        {
            return MakeProvider<IRawElementProviderFragment, AccessibilityProvider>(_hwnd);
        }
        // A control's element, which is the window's root element when a collapsed semantic root stands for the control: the
        // parent of the control's fragments (its tree items, grid headers and rows, reveal button) is a Control target.
        case AccessibilityFragmentKind::Control: return CreateControlProvider(navigationTarget.path);
        case AccessibilityFragmentKind::TextFieldPasswordRevealButton: return CreateTextFieldPasswordRevealButtonProvider(navigationTarget.path);
        case AccessibilityFragmentKind::TreeItem: return CreateTreeItemProvider(navigationTarget.path, navigationTarget.treeItemId);
        case AccessibilityFragmentKind::GridHeader: return CreateGridHeaderProvider(navigationTarget.path, navigationTarget.gridColumnIndex);
        case AccessibilityFragmentKind::GridRow: return CreateGridRowProvider(navigationTarget.path, navigationTarget.gridRowId);
        case AccessibilityFragmentKind::GridCell:
            return CreateGridCellProvider(navigationTarget.path, navigationTarget.gridRowId, navigationTarget.gridColumnIndex);
        default: return nullptr;
    }
}

ITextRangeProvider* AccessibilityProvider::CreateTextRangeProvider(const ControlPath& path, size_t start, size_t end) noexcept
{
    return MakeProvider<ITextRangeProvider, AccessibilityTextRangeProvider>(_hwnd, path, start, end);
}

ITextRangeProvider* AccessibilityProvider::CreateTextRangeProvider(const ControlPath& path,
                                                                   size_t start,
                                                                   size_t end,
                                                                   std::vector<D2D1_RECT_F> boundsOverrideDip) noexcept
{
    return MakeProvider<ITextRangeProvider, AccessibilityTextRangeProvider>(_hwnd, path, start, end, std::move(boundsOverrideDip));
}

ITextRangeProvider* AccessibilityProvider::CreateTextRangeProvider(const ControlPath& path, size_t start, size_t end, std::wstring textOverride) noexcept
{
    return MakeProvider<ITextRangeProvider, AccessibilityTextRangeProvider>(_hwnd, path, start, end, std::move(textOverride));
}

ITextRangeProvider* AccessibilityProvider::CreateTextDocumentRangeProvider(const AccessibilityControlNavigationSnapshot& record) noexcept
{
    if (! record.controlSupportsText)
    {
        return nullptr;
    }

    return CreateTextRangeProvider(record.path, 0u, record.controlAccessibleText.size());
}

[[nodiscard]] bool SearchAccessibilityPathForTarget(
    const Control* current, const ControlPath& basePath, const Control* target, ControlPath& outPath, size_t& visited) noexcept
{
    if (! current)
    {
        return false;
    }

    ++visited;
    if (! current->IsVisible())
    {
        return false;
    }

    if (current == target && IsSemanticAccessibilityControl(current))
    {
        outPath = basePath;
        return true;
    }

    const auto* panel = dynamic_cast<const Panel*>(current);
    if (! panel)
    {
        return false;
    }

    const auto children = panel->GetChildren();
    for (size_t index = 0u; index < children.size(); ++index)
    {
        if (! children[index])
        {
            continue;
        }

        ControlPath childPath{};
        if (! TryAppendPathIndex(basePath, index, childPath))
        {
            continue;
        }

        if (SearchAccessibilityPathForTarget(children[index].get(), childPath, target, outPath, visited))
        {
            return true;
        }
    }

    return false;
}

[[nodiscard]] bool FindAccessibilityPathForTarget(const Control* current, const ControlPath& basePath, const Control* target, ControlPath& outPath) noexcept
{
    size_t visited   = 0u;
    const bool found = SearchAccessibilityPathForTarget(current, basePath, target, outPath, visited);
    CountAccessibilityResolutionVisits(visited);
    return found;
}

// The path of `control` in a window host's live tree, which is what a search of that tree finds. While the published
// snapshot still describes the tree, its table names the path and a walk down it confirms the control is there; a
// control the snapshot does not hold (added since it was published, or hidden, or no element) is searched for.
[[nodiscard]] bool FindWindowHostControlPath(const AccessibilitySnapshot* snapshot, Control* root, const Control* control, ControlPath& outPath) noexcept
{
    if (snapshot)
    {
        if (const std::optional<uint32_t> ordinal = FindControlRecordOrdinalByAddress(*snapshot, control))
        {
            const ControlPath& published = snapshot->controlNavigationRecords[ordinal.value()].path;
            if (ResolveControlAtPath(root, published) == control && IsControlPathVisible(root, published) && IsSemanticAccessibilityControl(control))
            {
                outPath = published;
                return true;
            }
        }
    }

    return FindAccessibilityPathForTarget(root, ControlPath{}, control, outPath);
}

} // namespace

TextUnit NormalizeAccessibilityTextUnit(TextUnit unit) noexcept
{
    switch (unit)
    {
        case TextUnit_Character: return TextUnit_Character;
        case TextUnit_Format:
        case TextUnit_Word: return TextUnit_Word;
        case TextUnit_Line: return TextUnit_Line;
        case TextUnit_Paragraph:
        case TextUnit_Page:
        case TextUnit_Document:
        default: return TextUnit_Document;
    }
}

TextRangeUnitMoveResult MoveAccessibilityTextPositionByUnit(std::wstring_view text, size_t position, TextUnit unit, int count) noexcept
{
    const TextUnit supportedUnit = NormalizeAccessibilityTextUnit(unit);
    if (supportedUnit == TextUnit_Character || supportedUnit == TextUnit_Word)
    {
        return MoveTextRangePositionByUnit(text, position, supportedUnit, count);
    }
    if (supportedUnit == TextUnit_Line)
    {
        return MoveTextRangePositionByLine(text, position, count);
    }

    const size_t clamped = std::min(position, text.size());
    if (count > 0 && clamped < text.size())
    {
        return TextRangeUnitMoveResult{text.size(), 1};
    }
    if (count < 0 && clamped > 0u)
    {
        return TextRangeUnitMoveResult{0u, -1};
    }
    return TextRangeUnitMoveResult{clamped, 0};
}

AccessibilityTextUnitSpan GetEnclosingAccessibilityTextUnitSpan(std::wstring_view text, size_t position, TextUnit unit) noexcept
{
    const TextUnit supportedUnit = NormalizeAccessibilityTextUnit(unit);
    TextRangeSpan span{};
    if (supportedUnit == TextUnit_Character)
    {
        span = GetEnclosingTextRangeCharacterSpan(text, position);
    }
    else if (supportedUnit == TextUnit_Word)
    {
        span = GetEnclosingTextRangeWordSpan(text, position);
    }
    else if (supportedUnit == TextUnit_Line)
    {
        span = GetTextRangeLineSpanAtPosition(text, position);
    }
    else
    {
        span = TextRangeSpan{0u, text.size()};
    }
    return AccessibilityTextUnitSpan{span.start, span.end};
}

// A provider for an event about `control` in a window host, or null when no client could observe it. A collapsed
// semantic root is reported through the canonical root provider, as clients see it. A path provider adopts the
// retained target and pins no snapshot, so UIA's retention of event providers stays O(1) per event.
[[nodiscard]] wil::com_ptr_nothrow<IRawElementProviderSimple> CreateWindowHostEventProvider(HWND hwnd, const Control* control) noexcept
{
    if (! hwnd || ! control || ! UiaClientsAreListening())
        return {};
    // This internal intrusive target is not IUnknown (its Release result is nodiscard).
    // Give WIL an explicit close policy instead of imposing COM pointer semantics on it.
    constexpr auto releaseTarget = [](WindowHostAccessibilityTarget* value) noexcept { static_cast<void>(value->Release()); };
    wil::unique_any<WindowHostAccessibilityTarget*, decltype(releaseTarget), releaseTarget> target(AcquireWindowHostAccessibilityTarget(hwnd));
    if (! target)
        return {};
    ControlHost* const host = target.get()->ResolveHost();
    ControlPath path{};
    const auto snapshot = target.get()->snapshot.load(std::memory_order_acquire);
    if (! host || ! FindWindowHostControlPath(snapshot.get(), host->GetRoot(), control, path))
        return {};
    // The provider retains the target and survives UIA reentrancy without borrowing the control.
    return CreateControlElement(target.get(), hwnd, path);
}

namespace
{
// The UIA focus-changed event for the element a window host's snapshot has focused, as GetFocus reports it: a tree
// item, a grid row, a control, or the window itself when no control has focus. Only while that window holds the
// foreground's keyboard focus (a window that just lost the foreground must not take a screen reader's attention back)
// and a client listens. Native menu popups raise theirs once a keyboard transition completes. Returns whether it
// raised the event.
bool AnnounceWindowHostFocus(HWND hwnd) noexcept
{
    if (! hwnd || IsNativeMenuPopupWindow(hwnd) || ! UiaClientsAreListening())
        return false;
    GUITHREADINFO focus{};
    focus.cbSize = sizeof(focus);
    if (GetGUIThreadInfo(0u, &focus) == FALSE || focus.hwndFocus != hwnd)
        return false;
    constexpr auto releaseTarget = [](WindowHostAccessibilityTarget* value) noexcept { static_cast<void>(value->Release()); };
    wil::unique_any<WindowHostAccessibilityTarget*, decltype(releaseTarget), releaseTarget> target(AcquireWindowHostAccessibilityTarget(hwnd));
    if (! target)
        return false;
    const auto snapshot = target.get()->snapshot.load(std::memory_order_acquire);
    if (! snapshot || ! snapshot->alive || ! snapshot->hasRetainedRoot)
        return false;
    wil::com_ptr_nothrow<IRawElementProviderSimple> provider;
    const std::optional<AccessibilityFocusedFragmentSnapshot>& fragment = snapshot->focusedFragment;
    if (! fragment.has_value() || (fragment->kind == AccessibilityFragmentKind::Control && SnapshotPathIsCollapsedSemanticRoot(*snapshot, fragment->path)))
    {
        const auto root = AcquireCanonicalRootProvider(target.get());
        if (! root || FAILED(root.query_to(provider.put())))
            return false;
    }
    else
    {
        AccessibilityProvider* raw = nullptr;
        switch (fragment->kind)
        {
            case AccessibilityFragmentKind::TreeItem:
                raw = new (std::nothrow) AccessibilityProvider(target.get(), hwnd, fragment->path, fragment->treeItemId, AccessibilityProvider::TreeItemTag{});
                break;
            case AccessibilityFragmentKind::GridRow:
                raw = new (std::nothrow) AccessibilityProvider(target.get(), hwnd, fragment->path, fragment->gridRowId, AccessibilityFragmentKind::GridRow);
                break;
            default: raw = new (std::nothrow) AccessibilityProvider(target.get(), hwnd, fragment->path); break;
        }
        if (! raw)
            return false;
        // The provider adopts the retained target.
        static_cast<void>(target.release());
        provider.attach(raw);
    }
    return SUCCEEDED(UiaRaiseAutomationEvent(provider.get(), UIA_AutomationFocusChangedEventId));
}

// The UI Automation selection events for the selection changes a publish found in trees and grids (see SelectionChange): per
// changed item or row, from that item's own element, the IsSelected property change and the pattern's selected, added or
// removed event; for a change too large to name, the invalidated event of the tree's or grid's element (the window's when a
// collapsed semantic root stands for it). Every provider holds a reference of `target`, which the caller keeps; `hwnd` is null
// for an embedded target. Something else may run while they are raised (an outgoing call of UI Automation's in a single-threaded
// apartment dispatches messages): the raising ends once the host is disconnected or an embedded view's root is gone, and the
// raising of a control's change ends once that control is no longer the one published at its path (hidden, removed or replaced,
// which republishes). The providers never touch a control; the events left are dropped, not raised on elements that are gone.
void RaiseSelectionEvents(WindowHostAccessibilityTarget& target, HWND hwnd, const std::vector<SelectionChange>& changes) noexcept
{
    const auto connected = [&]() noexcept
    { return target.host.load(std::memory_order_acquire) != nullptr && (! target.embedded || ! target.rootLifetime.expired()); };
    const auto published = [&](const SelectionChange& change) noexcept
    {
        const std::shared_ptr<const AccessibilitySnapshot> snapshot = target.snapshot.load(std::memory_order_acquire);
        const AccessibilityControlNavigationSnapshot* const record  = snapshot ? FindControlNavigationRecord(*snapshot, change.path) : nullptr;
        return record && record->controlIdentity == change.controlIdentity;
    };
    const auto live             = [&](const SelectionChange& change) noexcept { return connected() && published(change); };
    const auto makeItemProvider = [&](const SelectionChange& change, uint64_t id) noexcept -> wil::com_ptr_nothrow<IRawElementProviderSimple>
    {
        static_cast<void>(target.AddRef());
        AccessibilityProvider* const raw = change.itemKind == AccessibilityFragmentKind::GridRow
                                               ? new (std::nothrow) AccessibilityProvider(&target, hwnd, change.path, id, AccessibilityFragmentKind::GridRow)
                                               : new (std::nothrow) AccessibilityProvider(&target, hwnd, change.path, id, AccessibilityProvider::TreeItemTag{});
        if (! raw)
        {
            static_cast<void>(target.Release());
            return {};
        }
        wil::com_ptr_nothrow<IRawElementProviderSimple> provider;
        provider.attach(static_cast<IRawElementProviderSimple*>(raw));
        return provider;
    };
    // An item's events; false once the raising of its change has ended.
    const auto raiseItem = [&](const SelectionChange& change, uint64_t id, bool selected, EVENTID eventId) noexcept
    {
        if (! live(change))
            return false;
        if (const wil::com_ptr_nothrow<IRawElementProviderSimple> item = makeItemProvider(change, id))
        {
            static_cast<void>(UiaRaiseAutomationPropertyChangedEvent(
                item.get(), UIA_SelectionItemIsSelectedPropertyId, VariantFromBool(! selected), VariantFromBool(selected)));
            NotifySelectionEventRaisedForTest();
            if (eventId != 0 && live(change))
            {
                static_cast<void>(UiaRaiseAutomationEvent(item.get(), eventId));
                NotifySelectionEventRaisedForTest();
            }
        }
        return true;
    };

    for (const SelectionChange& change : changes)
    {
        if (! connected())
            return;
        if (! published(change))
            continue;
        if (change.invalidated)
        {
            // The tree or grid itself: its own element, or the window's when a collapsed semantic root stands for it, as clients see it.
            if (const wil::com_ptr_nothrow<IRawElementProviderSimple> container = CreateControlElement(&target, hwnd, change.path))
            {
                static_cast<void>(UiaRaiseAutomationEvent(container.get(), UIA_Selection_InvalidatedEventId));
                NotifySelectionEventRaisedForTest();
            }
            continue;
        }
        // A selection that became one new item says so with that item's event, which says the others left it.
        bool raising = true;
        for (size_t index = 0u; raising && index < change.removed.size(); ++index)
            raising = raiseItem(change, change.removed[index], false, change.replaced ? 0 : UIA_SelectionItem_ElementRemovedFromSelectionEventId);
        for (size_t index = 0u; raising && index < change.added.size(); ++index)
            raising = raiseItem(change,
                                change.added[index],
                                true,
                                change.replaced ? UIA_SelectionItem_ElementSelectedEventId : UIA_SelectionItem_ElementAddedToSelectionEventId);
    }
}

// The selection events of a window host's publish, raised outside its lock like the focus and structure events.
void RaiseWindowHostSelectionChanges(HWND hwnd, const std::vector<SelectionChange>& changes) noexcept
{
    if (! hwnd || changes.empty() || ! UiaClientsAreListening())
        return;
    constexpr auto releaseTarget = [](WindowHostAccessibilityTarget* value) noexcept { static_cast<void>(value->Release()); };
    wil::unique_any<WindowHostAccessibilityTarget*, decltype(releaseTarget), releaseTarget> target(AcquireWindowHostAccessibilityTarget(hwnd));
    if (target)
        RaiseSelectionEvents(*target.get(), hwnd, changes);
}

struct RangePropertyChange
{
    PROPERTYID id;
    double previous;
    double current;
};

[[nodiscard]] std::array<RangePropertyChange, 5> GetRangePropertyChanges(const AccessibilityControlNavigationSnapshot& previous,
                                                                         const AccessibilityControlNavigationSnapshot& current) noexcept
{
    return {{{UIA_RangeValueValuePropertyId, previous.controlRangeValue, current.controlRangeValue},
             {UIA_RangeValueMinimumPropertyId, previous.controlRangeMinimum, current.controlRangeMinimum},
             {UIA_RangeValueMaximumPropertyId, previous.controlRangeMaximum, current.controlRangeMaximum},
             {UIA_RangeValueSmallChangePropertyId, previous.controlRangeSmallChange, current.controlRangeSmallChange},
             {UIA_RangeValueLargeChangePropertyId, previous.controlRangeLargeChange, current.controlRangeLargeChange}}};
}

void RaiseWindowHostRangeValueChanges(HWND hwnd, const WindowHostSnapshotChanges& changes) noexcept
{
    if (! hwnd || ! changes.previous || ! changes.current || ! UiaClientsAreListening())
        return;
    constexpr auto releaseTarget = [](WindowHostAccessibilityTarget* value) noexcept { static_cast<void>(value->Release()); };
    wil::unique_any<WindowHostAccessibilityTarget*, decltype(releaseTarget), releaseTarget> target(AcquireWindowHostAccessibilityTarget(hwnd));
    if (! target)
        return;
    for (const auto& record : changes.current->controlNavigationRecords)
    {
        // A property event can reenter and publish another tree. Stop rather than announce stale values on it.
        if (! target.get()->host.load(std::memory_order_acquire) || target.get()->snapshot.load(std::memory_order_acquire) != changes.current)
            return;
        const auto* before = FindControlNavigationRecord(*changes.previous, record.path);
        if (! before || ! record.controlSupportsRangeValue || ! before->controlSupportsRangeValue ||
            ! SameControlLifetime(before->controlLifetime, record.controlLifetime))
            continue;
        const auto properties = GetRangePropertyChanges(*before, record);
        if (! std::ranges::any_of(properties, [](const RangePropertyChange& property) noexcept { return property.previous != property.current; }))
            continue;
        if (const auto provider = CreateControlElement(target.get(), hwnd, record.path))
            for (const RangePropertyChange& property : properties)
            {
                if (property.previous == property.current)
                    continue;
                if (! target.get()->host.load(std::memory_order_acquire) || target.get()->snapshot.load(std::memory_order_acquire) != changes.current)
                    return;
                static_cast<void>(UiaRaiseAutomationPropertyChangedEvent(
                    provider.get(), property.id, VariantFromDouble(property.previous), VariantFromDouble(property.current)));
            }
    }
}

// Clients learn that semantic controls were added, removed or replaced, so they drop elements that now report
// UIA_E_ELEMENTNOTAVAILABLE and navigate again.
void RaiseWindowHostStructureInvalidated(HWND hwnd) noexcept
{
    if (! hwnd || ! UiaClientsAreListening())
        return;
    constexpr auto releaseTarget = [](WindowHostAccessibilityTarget* value) noexcept { static_cast<void>(value->Release()); };
    wil::unique_any<WindowHostAccessibilityTarget*, decltype(releaseTarget), releaseTarget> target(AcquireWindowHostAccessibilityTarget(hwnd));
    if (! target)
        return;
    wil::com_ptr_nothrow<IRawElementProviderSimple> root;
    if (const auto fragmentRoot = AcquireCanonicalRootProvider(target.get()); fragmentRoot && SUCCEEDED(fragmentRoot.query_to(root.put())))
        static_cast<void>(UiaRaiseStructureChangedEvent(root.get(), StructureChangeType_ChildrenInvalidated, nullptr, 0));
}
} // namespace

void RaiseWindowHostFocusChanged(HWND hwnd, const Control* control) noexcept
{
    if (const auto provider = CreateWindowHostEventProvider(hwnd, control))
        static_cast<void>(UiaRaiseAutomationEvent(provider.get(), UIA_AutomationFocusChangedEventId));
}

void RaiseWindowHostDisclosureChanged(HWND hwnd, const Control* control, bool expanded) noexcept
{
    if (const auto provider = CreateWindowHostEventProvider(hwnd, control))
        static_cast<void>(UiaRaiseAutomationPropertyChangedEvent(provider.get(),
                                                                 UIA_ExpandCollapseExpandCollapseStatePropertyId,
                                                                 VariantFromInt(expanded ? ExpandCollapseState_Collapsed : ExpandCollapseState_Expanded),
                                                                 VariantFromInt(expanded ? ExpandCollapseState_Expanded : ExpandCollapseState_Collapsed)));
}

bool RaiseWindowHostTextInputAutomationEvent(HWND hwnd, const Control* control, TextInputAutomationEventKind kind) noexcept
{
    if (! hwnd || ! control)
    {
        return false;
    }

    WindowHostAccessibilityTarget* target = AcquireWindowHostAccessibilityTarget(hwnd);
    if (! target)
    {
        return false;
    }

    ControlHost* const host = target->ResolveHost();
    ControlPath controlPath{};
    const auto snapshot = target->snapshot.load(std::memory_order_acquire);
    if (! host || ! FindWindowHostControlPath(snapshot.get(), host->GetRoot(), control, controlPath))
    {
        static_cast<void>(target->Release());
        return false;
    }

    // The event comes from the field's element, which is the window's own when the field is the one control its root stands for.
    const wil::com_ptr_nothrow<IRawElementProviderSimple> provider = CreateControlElement(target, hwnd, controlPath);
    if (! provider)
    {
        static_cast<void>(target->Release());
        return false;
    }
    const auto releaseTarget = wil::scope_exit([&] { static_cast<void>(target->Release()); });

    switch (kind)
    {
        case TextInputAutomationEventKind::TextChanged: static_cast<void>(UiaRaiseAutomationEvent(provider.get(), UIA_Text_TextChangedEventId)); return true;
        case TextInputAutomationEventKind::TextSelectionChanged:
            static_cast<void>(UiaRaiseAutomationEvent(provider.get(), UIA_Text_TextSelectionChangedEventId));
            return true;
        case TextInputAutomationEventKind::ActiveTextPositionChanged:
        {
            wil::com_ptr_nothrow<ITextRangeProvider> activeRange;
            NativeTextInputState state{};
            if (host->TryReadNativeTextInputState(control, state))
            {
                const size_t caretIndex = std::min(state.caretIndex, state.text.size());
                static_cast<void>(target->AddRef());
                auto* rangeProvider = new (std::nothrow) AccessibilityTextRangeProvider(target, hwnd, controlPath, caretIndex, caretIndex);
                if (rangeProvider)
                {
                    activeRange.attach(static_cast<ITextRangeProvider*>(rangeProvider));
                }
                else
                {
                    static_cast<void>(target->Release());
                }
            }
            static_cast<void>(UiaRaiseActiveTextPositionChangedEvent(provider.get(), activeRange.get()));
            return true;
        }
        case TextInputAutomationEventKind::TextEditCompositionChanged:
        {
            unique_safearray changedData(SafeArrayCreateVector(VT_BSTR, 0u, 0u));
            static_cast<void>(UiaRaiseTextEditTextChangedEvent(provider.get(), TextEditChangeType_Composition, changedData.get()));
            return true;
        }
        case TextInputAutomationEventKind::TextEditConversionTargetChanged:
            static_cast<void>(UiaRaiseAutomationEvent(provider.get(), UIA_TextEdit_ConversionTargetChangedEventId));
            return true;
        default: return false;
    }
}

void RegisterWindowHostAccessibilityTarget(HWND hwnd, ControlHost* host) noexcept
{
    if (hwnd && host)
    {
        const std::scoped_lock lock(GetAccessibilityTargetMutex());
        if (auto* target = static_cast<WindowHostAccessibilityTarget*>(GetPropW(hwnd, kWindowHostPropName)))
        {
            target->host.store(host, std::memory_order_release);
            PublishWindowHostAccessibilitySnapshot(*target, *host);
            return;
        }

        auto* target = new (std::nothrow) WindowHostAccessibilityTarget(hwnd, host);
        if (! target)
        {
            return;
        }

        if (SetPropW(hwnd, kWindowHostPropName, target) == 0)
        {
            static_cast<void>(target->Release());
            return;
        }

        PublishWindowHostAccessibilitySnapshot(*target, *host);
    }
}

void UnregisterWindowHostAccessibilityTarget(HWND hwnd, ControlHost* host) noexcept
{
    if (! hwnd)
    {
        return;
    }

    wil::com_ptr_nothrow<IRawElementProviderSimple> providerToDisconnect;
    {
        const std::scoped_lock lock(GetAccessibilityTargetMutex());
        auto* target = static_cast<WindowHostAccessibilityTarget*>(GetPropW(hwnd, kWindowHostPropName));
        if (! target)
        {
            return;
        }

        const ControlHost* current = target->host.load(std::memory_order_acquire);
        if (host && current != host)
        {
            return;
        }

        target->diffBaseline.reset();
        PublishEmptyAccessibilitySnapshot(*target);
        target->host.store(nullptr, std::memory_order_release);
        providerToDisconnect.attach(target->rootProvider.detach());
        if (RemovePropW(hwnd, kWindowHostPropName) == target)
        {
            static_cast<void>(target->Release());
        }
    }

    // Disconnect the exact provider identity returned for this host before retiring the HWND map.
    // UI Automation may otherwise retain that provider when Win32 recycles the HWND for a later host.
    if (providerToDisconnect)
    {
        static_cast<void>(UiaDisconnectProvider(providerToDisconnect.get()));
    }
    static_cast<void>(UiaReturnRawElementProvider(hwnd, 0, 0, nullptr));
}

void NotifyWindowHostAccessibilityDestroyed(HWND hwnd) noexcept
{
    if (hwnd)
    {
        // UI Automation requires the provider map to be retired while handling window destruction.
        // Unregister repeats this as a fallback for owners that detach before WM_DESTROY.
        static_cast<void>(UiaReturnRawElementProvider(hwnd, 0, 0, nullptr));
    }
}

void RefreshWindowHostAccessibilitySnapshot(HWND hwnd, ControlHost* host) noexcept
{
    if (! host)
        return;
    if (! hwnd)
        return; // EmbeddedHost::UpdateAccessibility publishes after coherent preparation.

    WindowHostSnapshotChanges changes{};
    uint64_t focusResolutions = 0u;
    {
        const std::scoped_lock lock(GetAccessibilityTargetMutex());
        auto* target = static_cast<WindowHostAccessibilityTarget*>(GetPropW(hwnd, kWindowHostPropName));
        if (! target || target->host.load(std::memory_order_acquire) != host)
        {
            return;
        }

        changes = PublishWindowHostAccessibilitySnapshot(*target, *host);
        // Read after the publish stored the snapshot. A call of GetFocus counts itself before it loads the snapshot, all
        // four operations sequentially consistent, so a call this read does not count loads the snapshot after the
        // store and reports the element the host just focused, while one it counts may have loaded the snapshot before.
        if (changes.focusMoved)
            focusResolutions = target->focusResolutions.load(std::memory_order_seq_cst);
    }
    // Raised outside the publish lock: clients may call back into these providers from other threads.
    if (changes.structureChanged)
        RaiseWindowHostStructureInvalidated(hwnd);
    if (changes.focusMoved)
    {
        // What the gain itself focuses is left to the system's focus event, and a move later in its turn is too while no
        // GetFocus call has begun on the window (see ReporterOfFocusMove): every call that begins later loads the snapshot
        // after the store above and reports the moved-to element. Otherwise the host announces the move, at worst as a
        // duplicate of a call that answered the event before it.
        switch (EmbeddedAccessibilityAccess::ReporterOfFocusMove(*host, focusResolutions))
        {
            case EmbeddedAccessibilityAccess::FocusMoveReporter::Host:
                EmbeddedAccessibilityAccess::NoteFocusMoveAnnounced(*host);
                if (AnnounceWindowHostFocus(hwnd))
                    EmbeddedAccessibilityAccess::CountFocusAnnouncement(*host);
                break;
            case EmbeddedAccessibilityAccess::FocusMoveReporter::SystemUnanswered: EmbeddedAccessibilityAccess::CountFocusMoveLeftToSystem(*host); break;
            case EmbeddedAccessibilityAccess::FocusMoveReporter::SystemAtGain: break;
        }
    }
    // After the focus move, as a list view reports its focus and then its selection.
    RaiseWindowHostSelectionChanges(hwnd, changes.selections);
    RaiseWindowHostRangeValueChanges(hwnd, changes);
}

void BeginWindowHostFocusGain(HWND hwnd, ControlHost* host) noexcept
{
    if (! hwnd || ! host)
        return;

    uint64_t focusResolutions = 0u;
    {
        const std::scoped_lock lock(GetAccessibilityTargetMutex());
        const auto* target = static_cast<const WindowHostAccessibilityTarget*>(GetPropW(hwnd, kWindowHostPropName));
        // Read as the gain begins, before it publishes anything. UI Automation asks a window for its focus only for the
        // first focus event it answers, so a call counted here answered an earlier event and this gain will be answered
        // without asking, while a call this gain's event brings comes later and reads what the gain published.
        if (target && target->host.load(std::memory_order_acquire) == host)
            focusResolutions = target->focusResolutions.load(std::memory_order_seq_cst);
    }
    EmbeddedAccessibilityAccess::BeginFocusGain(*host, focusResolutions);
}

void EndWindowHostFocusGainTurn(HWND hwnd, ControlHost* host) noexcept
{
    if (! hwnd || ! host || ! EmbeddedAccessibilityAccess::FocusGainIsUnreported(*host) || ! UiaClientsAreListening())
        return;

    {
        const std::scoped_lock lock(GetAccessibilityTargetMutex());
        const auto* target = static_cast<const WindowHostAccessibilityTarget*>(GetPropW(hwnd, kWindowHostPropName));
        if (! target || target->host.load(std::memory_order_acquire) != host)
            return;
        const auto snapshot = target->snapshot.load(std::memory_order_seq_cst);
        // UI Automation reports the root element itself when the root says it has the keyboard focus.
        if (! snapshot || ! snapshot->alive || ! snapshot->hasRetainedRoot || RootElementHasKeyboardFocus(*snapshot))
            return;
    }
    EmbeddedAccessibilityAccess::CountReactivationAnnouncement(*host);
    // Raised outside the publish lock, like the host's other focus changes: clients may call back into these providers.
    if (AnnounceWindowHostFocus(hwnd))
        EmbeddedAccessibilityAccess::CountFocusAnnouncement(*host);
}

void PublishEmptyWindowHostAccessibilitySnapshot(HWND hwnd, ControlHost* host) noexcept
{
    if (! hwnd)
    {
        return;
    }

    const std::scoped_lock lock(GetAccessibilityTargetMutex());
    auto* target = static_cast<WindowHostAccessibilityTarget*>(GetPropW(hwnd, kWindowHostPropName));
    if (! target)
    {
        return;
    }

    const ControlHost* current = target->host.load(std::memory_order_acquire);
    if (host && current != host)
    {
        return;
    }

    if (auto live = target->snapshot.load(std::memory_order_acquire); live && live->alive)
        target->diffBaseline = std::move(live);
    PublishEmptyAccessibilitySnapshot(*target);
}

LRESULT ReturnWindowHostAccessibilityProvider(HWND hwnd, WPARAM wp, LPARAM lp) noexcept
{
    WindowHostAccessibilityTarget* target = AcquireWindowHostAccessibilityTarget(hwnd);
    if (! target || target->ResolveHost() == nullptr)
    {
        if (target)
        {
            static_cast<void>(target->Release());
        }
        return 0;
    }

    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> rootProvider = AcquireCanonicalRootProvider(target);
    static_cast<void>(target->Release());
    wil::com_ptr_nothrow<IRawElementProviderSimple> provider;
    static_cast<void>(rootProvider.query_to(provider.put()));

    return UiaReturnRawElementProvider(hwnd, wp, lp, provider.get());
}

bool TryHandleWindowHostAccessibilityMessage(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp, LRESULT& outResult) noexcept
{
    outResult = 0;
    if (msg == WM_GETOBJECT)
    {
        if (lp != static_cast<LPARAM>(UiaRootObjectId))
        {
            return false;
        }

        const LRESULT providerResult = ReturnWindowHostAccessibilityProvider(hwnd, wp, lp);
        if (providerResult == 0)
        {
            return false;
        }

        outResult = providerResult;
        return true;
    }

    if (WndMsg::AccessibilityCreateProvider().Matches(msg))
    {
        auto payload = TakeMessagePayload<AccessibilityProviderCreationPayload>(lp);
        if (payload && payload->result)
            payload->result->provider.attach(CreateWindowHostAccessibilityProvider(hwnd));
        return true;
    }

    if (! WndMsg::AccessibilityUiThreadAction().Matches(msg))
    {
        return false;
    }

    auto payload = TakeMessagePayload<AccessibilityUiActionPayload>(lp);
    if (! payload || ! payload->dispatch)
    {
        return true;
    }

    std::shared_ptr<AccessibilityUiActionDispatch> dispatch = payload->dispatch;

#if DXUI_ENABLE_DIAGNOSTICS
    MaybeStallAccessibilityUiActionHandlerForTest();
#endif

    AccessibilityUiActionDispatch::State expected = AccessibilityUiActionDispatch::State::Pending;
    if (! dispatch->state.compare_exchange_strong(expected, AccessibilityUiActionDispatch::State::Taken, std::memory_order_acq_rel, std::memory_order_acquire))
    {
        return true;
    }

#if DXUI_ENABLE_DIAGNOSTICS
    MaybeStallTakenAccessibilityUiActionHandlerForTest();
    g_accessibilityUiActionExecutionCount.fetch_add(1u, std::memory_order_relaxed);
#endif

    auto& request = dispatch->request;

    if (request.provider)
    {
        request.result = request.provider->ExecuteUiThreadAction(request);
        return true;
    }
    if (request.textRangeProvider && request.kind == AccessibilityUiActionKind::Select)
    {
        request.result = request.textRangeProvider->ExecuteSelectOnWindowThread();
        return true;
    }
    if (request.textRangeProvider && request.kind == AccessibilityUiActionKind::ExpandTextRangeToVisualLine)
    {
        request.result = request.textRangeProvider->ExecuteExpandToVisualLineOnWindowThread(
            request.textRangeStart, request.textRangeEnd, request.textRangeResultStart, request.textRangeResultEnd);
        return true;
    }
    if (request.textRangeProvider && request.kind == AccessibilityUiActionKind::MoveTextRangeByVisualLine)
    {
        request.result = request.textRangeProvider->ExecuteMoveByVisualLineOnWindowThread(request.textRangeStart,
                                                                                          request.textRangeEnd,
                                                                                          request.textRangeMoveCount,
                                                                                          request.textRangeResultStart,
                                                                                          request.textRangeResultEnd,
                                                                                          request.textRangeMoved);
        return true;
    }
    if (request.textRangeProvider && request.kind == AccessibilityUiActionKind::MoveTextRangeEndpointByVisualLine)
    {
        request.result = request.textRangeProvider->ExecuteMoveEndpointByVisualLineOnWindowThread(request.textRangeStart,
                                                                                                  request.textRangeEnd,
                                                                                                  request.textRangeEndpoint,
                                                                                                  request.textRangeMoveCount,
                                                                                                  request.textRangeResultStart,
                                                                                                  request.textRangeResultEnd,
                                                                                                  request.textRangeMoved);
        return true;
    }
    if (request.textRangeProvider && request.kind == AccessibilityUiActionKind::ResolveTextRangeBounds)
    {
        request.result = request.textRangeProvider->ExecuteResolveBoundsOnWindowThread(
            request.textRangeStart, request.textRangeEnd, request.textRangeBoundsDip, request.textRangeDipToPixelScale);
        return true;
    }

    request.result = UIA_E_NOTSUPPORTED;
    return true;
}

namespace
{
// `selections` is the selection diff of the publish. The caller makes it, where running out of memory is reported,
// because this function raises events and never throws.
void RaiseEmbeddedAccessibilityChanges(WindowHostAccessibilityTarget& target,
                                       const std::shared_ptr<const AccessibilitySnapshot>& previous,
                                       const WindowHostSnapshotChanges& changes) noexcept
{
    const auto current = target.snapshot.load(std::memory_order_acquire);
    if (! previous || ! current || ! target.rootProvider || ! UiaClientsAreListening())
        return;
    // Keep target/provider alive through UIA callbacks; disconnect during a callback stops later notifications.
    static_cast<void>(target.AddRef());
    const auto release   = wil::scope_exit([&] { static_cast<void>(target.Release()); });
    auto root            = target.rootProvider;
    const auto connected = [&] { return target.host.load(std::memory_order_acquire) != nullptr && target.snapshot.load(std::memory_order_acquire) == current; };
    bool structureChanged = previous->controlNavigationRecords.size() != current->controlNavigationRecords.size();
    for (const auto& record : current->controlNavigationRecords)
    {
        if (! connected())
            return;
        const auto* before = FindControlNavigationRecord(*previous, record.path);
        if (! before || before->controlIdentity != record.controlIdentity)
        {
            structureChanged = true;
            continue;
        }
        const bool nameChanged  = before->controlAccessibleName != record.controlAccessibleName;
        const bool helpChanged  = before->controlAccessibleHelpText != record.controlAccessibleHelpText;
        const bool textChanged  = before->controlAccessibleText != record.controlAccessibleText;
        const bool valueChanged = before->controlAccessibleValue != record.controlAccessibleValue;
        const bool selectionChanged =
            before->controlTextSelectionStart != record.controlTextSelectionStart || before->controlTextSelectionEnd != record.controlTextSelectionEnd;
        const bool compositionChanged =
            before->controlTextCompositionStart != record.controlTextCompositionStart || before->controlTextCompositionEnd != record.controlTextCompositionEnd;
        const auto rangeProperties = GetRangePropertyChanges(*before, record);
        const bool rangeChanged    = record.controlSupportsRangeValue && std::ranges::any_of(rangeProperties, [](const RangePropertyChange& property) noexcept {
            return property.previous != property.current;
        });
        if (! nameChanged && ! helpChanged && ! textChanged && ! valueChanged && ! selectionChanged && ! compositionChanged &&
            before->controlEnabled == record.controlEnabled && before->controlToggleChecked == record.controlToggleChecked &&
            before->controlDisclosureExpanded == record.controlDisclosureExpanded && ! rangeChanged && before->controlHasFocus == record.controlHasFocus)
            continue;
        static_cast<void>(target.AddRef());
        auto* raw = new (std::nothrow) AccessibilityProvider(&target, nullptr, record.path);
        if (! raw)
        {
            static_cast<void>(target.Release());
            return;
        }
        wil::com_ptr_nothrow<IRawElementProviderSimple> provider;
        provider.attach(raw);
        const auto property = [&](PROPERTYID id, VARIANT oldValue, VARIANT newValue)
        {
            if (connected())
                static_cast<void>(UiaRaiseAutomationPropertyChangedEvent(provider.get(), id, oldValue, newValue));
        };
        const auto stringProperty = [&](PROPERTYID id, const std::wstring& oldText, const std::wstring& newText)
        {
            wil::unique_bstr oldValue(SysAllocStringLen(oldText.data(), static_cast<UINT>(oldText.size())));
            wil::unique_bstr newValue(SysAllocStringLen(newText.data(), static_cast<UINT>(newText.size())));
            if ((! oldValue && ! oldText.empty()) || (! newValue && ! newText.empty()))
                return;
            VARIANT a{}, b{};
            a.vt = b.vt = VT_BSTR;
            a.bstrVal   = oldValue.get();
            b.bstrVal   = newValue.get();
            property(id, a, b);
        };
        if (nameChanged)
            stringProperty(UIA_NamePropertyId, before->controlAccessibleName, record.controlAccessibleName);
        if (helpChanged)
            stringProperty(UIA_HelpTextPropertyId, before->controlAccessibleHelpText, record.controlAccessibleHelpText);
        if (valueChanged)
            stringProperty(UIA_ValueValuePropertyId, before->controlAccessibleValue, record.controlAccessibleValue);
        if (before->controlEnabled != record.controlEnabled)
            property(UIA_IsEnabledPropertyId, VariantFromBool(before->controlEnabled), VariantFromBool(record.controlEnabled));
        if (record.controlSupportsToggle && before->controlToggleChecked != record.controlToggleChecked)
            property(UIA_ToggleToggleStatePropertyId,
                     VariantFromInt(before->controlToggleChecked ? ToggleState_On : ToggleState_Off),
                     VariantFromInt(record.controlToggleChecked ? ToggleState_On : ToggleState_Off));
        if (record.controlDisclosureExpanded.has_value() && before->controlDisclosureExpanded.has_value() &&
            record.controlDisclosureExpanded != before->controlDisclosureExpanded)
            property(UIA_ExpandCollapseExpandCollapseStatePropertyId,
                     VariantFromInt(before->controlDisclosureExpanded.value() ? ExpandCollapseState_Expanded : ExpandCollapseState_Collapsed),
                     VariantFromInt(record.controlDisclosureExpanded.value() ? ExpandCollapseState_Expanded : ExpandCollapseState_Collapsed));
        if (rangeChanged)
            for (const RangePropertyChange& change : rangeProperties)
                if (change.previous != change.current)
                    property(change.id, VariantFromDouble(change.previous), VariantFromDouble(change.current));
        if (before->controlHasFocus != record.controlHasFocus)
        {
            property(UIA_HasKeyboardFocusPropertyId, VariantFromBool(before->controlHasFocus), VariantFromBool(record.controlHasFocus));
        }
        if (connected() && record.controlSupportsText && textChanged)
            static_cast<void>(UiaRaiseAutomationEvent(provider.get(), UIA_Text_TextChangedEventId));
        if (connected() && record.controlSupportsText && selectionChanged)
            static_cast<void>(UiaRaiseAutomationEvent(provider.get(), UIA_Text_TextSelectionChangedEventId));
        if (connected() && record.controlSupportsText && compositionChanged)
        {
            unique_safearray changed(SafeArrayCreateVector(VT_BSTR, 0, 0));
            if (changed)
                static_cast<void>(UiaRaiseTextEditTextChangedEvent(provider.get(), TextEditChangeType_Composition, changed.get()));
        }
    }
    if (connected() && structureChanged)
        static_cast<void>(UiaRaiseStructureChangedEvent(root.get(), StructureChangeType_ChildrenInvalidated, nullptr, 0));
    if (connected() && changes.focusMoved && target.snapshot.load(std::memory_order_acquire) == current && current->focusedFragment)
    {
        const auto fragmentRoot = AcquireCanonicalRootProvider(&target);
        wil::com_ptr_nothrow<IRawElementProviderFragment> focused;
        wil::com_ptr_nothrow<IRawElementProviderSimple> provider;
        if (fragmentRoot && SUCCEEDED(fragmentRoot->GetFocus(focused.put())) && focused && SUCCEEDED(focused.query_to(provider.put())) && connected())
            static_cast<void>(UiaRaiseAutomationEvent(provider.get(), UIA_AutomationFocusChangedEventId));
    }
    if (connected())
        RaiseSelectionEvents(target, nullptr, changes.selections);
}
} // namespace

HRESULT EmbeddedHost::AttachAccessibility(std::shared_ptr<EmbeddedAccessibilitySite> site,
                                          uint64_t runtimeId,
                                          const EmbeddedAccessibilityPlacement& placement) noexcept
{
    if (! site || runtimeId == 0)
        return E_INVALIDARG;
    if (EmbeddedAccessibilityAccess::Target(_host))
        return HRESULT_FROM_WIN32(ERROR_ALREADY_INITIALIZED);
    if (! InputIsCoherent(false) || ! _host.GetRoot())
        return S_FALSE;
    APTTYPE apartment{};
    APTTYPEQUALIFIER qualifier{};
    const HRESULT apartmentHr = CoGetApartmentType(&apartment, &qualifier);
    if (FAILED(apartmentHr))
        return apartmentHr;
    if (apartment != APTTYPE_STA && apartment != APTTYPE_MAINSTA)
        return RPC_E_WRONG_THREAD;
    auto* target = new (std::nothrow) WindowHostAccessibilityTarget(nullptr, &_host);
    if (! target)
        return E_OUTOFMEMORY;
    target->embedded                           = true;
    target->runtimeId                          = runtimeId;
    target->rootLifetime                       = GetControlLifetimeToken(*_host.GetRoot());
    target->site                               = std::move(site);
    EmbeddedAccessibilityAccess::Target(_host) = target;
    const HRESULT hr                           = UpdateAccessibility(placement);
    if (hr != S_OK)
        DisconnectAccessibility();
    return hr;
}
HRESULT EmbeddedHost::UpdateAccessibility(const EmbeddedAccessibilityPlacement& placement) noexcept
{
    auto* target = static_cast<WindowHostAccessibilityTarget*>(EmbeddedAccessibilityAccess::Target(_host));
    if (! target)
        return S_FALSE;
    if (target->threadId != GetCurrentThreadId())
        return RPC_E_WRONG_THREAD;
    const auto& box = placement.viewport;
    if (! std::isfinite(box.left) || ! std::isfinite(box.top) || ! std::isfinite(box.width) || ! std::isfinite(box.height) || box.width <= 0 ||
        box.height <= 0 || box.left < LONG_MIN || box.top < LONG_MIN || box.left + box.width > LONG_MAX || box.top + box.height > LONG_MAX)
        return E_INVALIDARG;
    if (! InputIsCoherent(false) || ! target->ResolveHost())
        return S_FALSE;
    if (std::abs(box.width - _host._widthPx) > 0.01 || std::abs(box.height - _host._heightPx) > 0.01)
        return E_INVALIDARG;
    const auto preparation  = GetStatistics().preparations;
    const auto& previousBox = target->placement.viewport;
    if (target->snapshot.load(std::memory_order_acquire) && target->preparation == preparation && previousBox.left == box.left && previousBox.top == box.top &&
        previousBox.width == box.width && previousBox.height == box.height && target->placement.hasKeyboardFocus == placement.hasKeyboardFocus)
        return S_FALSE;
    try
    {
        const auto previous = target->snapshot.load(std::memory_order_acquire);
        target->placement   = placement;
        // The publish diffs the selections against `previous` while clients listen.
        const WindowHostSnapshotChanges changes = PublishWindowHostAccessibilitySnapshot(*target, _host);
        target->preparation                     = preparation;
        RaiseEmbeddedAccessibilityChanges(*target, previous, changes);
        return S_OK;
    }
    catch (const std::bad_alloc&)
    {
        return E_OUTOFMEMORY;
    }
}
HRESULT EmbeddedHost::GetAccessibilityProvider(IRawElementProviderFragmentRoot** result) noexcept
{
    if (! result)
        return E_POINTER;
    *result      = nullptr;
    auto* target = static_cast<WindowHostAccessibilityTarget*>(EmbeddedAccessibilityAccess::Target(_host));
    if (! target)
        return S_FALSE;
    if (target->threadId != GetCurrentThreadId())
        return RPC_E_WRONG_THREAD;
    if (! target->ResolveHost() || ! InputIsCoherent(false))
        return S_FALSE;
    auto root = AcquireCanonicalRootProvider(target);
    if (! root)
        return E_OUTOFMEMORY;
    *result = root.detach();
    return S_OK;
}
void EmbeddedHost::DisconnectAccessibility() noexcept
{
    auto* target = static_cast<WindowHostAccessibilityTarget*>(EmbeddedAccessibilityAccess::Target(_host));
    if (! target || target->threadId != GetCurrentThreadId())
        return;
    EmbeddedAccessibilityAccess::Target(_host) = nullptr;
    target->host.store(nullptr, std::memory_order_release);
    target->snapshot.store(nullptr, std::memory_order_release);
    target->site.reset();
    auto provider = std::move(target->rootProvider);
    if (provider)
        static_cast<void>(UiaDisconnectProvider(provider.get()));
    static_cast<void>(target->Release());
}

IRawElementProviderFragmentRoot* CreateWindowHostAccessibilityProvider(HWND hwnd) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return nullptr;
    }

    DWORD windowProcessId      = 0u;
    const DWORD windowThreadId = GetWindowThreadProcessId(hwnd, &windowProcessId);
    if (windowThreadId == 0u || windowProcessId != GetCurrentProcessId())
    {
        return nullptr;
    }
    if (windowThreadId != GetCurrentThreadId())
    {
        // Resolve on the owner with bounded transport. A late reply owns its result independently of the
        // caller's frame; registered-message parameters are tokens, never writable caller addresses.
        const WndMsg::RegisteredMessage createMessage = WndMsg::AccessibilityCreateProvider();
        if (! createMessage)
            return nullptr;
        try
        {
            auto result     = std::make_shared<AccessibilityProviderCreationResult>();
            auto payload    = std::make_unique<AccessibilityProviderCreationPayload>();
            payload->result = result;
            if (! SendMessagePayload(hwnd, createMessage.value, 0, std::move(payload), AccessibilityUiActionDispatchTimeoutMs()))
                return nullptr;
            return result->provider.detach();
        }
        catch (const std::bad_alloc&)
        {
            return nullptr;
        }
    }

    WindowHostAccessibilityTarget* target = AcquireWindowHostAccessibilityTarget(hwnd);
    if (! target || target->ResolveHost() == nullptr)
    {
        if (target)
        {
            static_cast<void>(target->Release());
        }
        return nullptr;
    }

    auto provider = AcquireCanonicalRootProvider(target);
    static_cast<void>(target->Release());
    return provider.detach();
}

bool RaiseWindowHostAccessibilityNotification(HWND hwnd, std::wstring_view notification, std::wstring_view activityId) noexcept
{
    if (notification.empty())
    {
        return false;
    }

    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> provider;
    provider.attach(CreateWindowHostAccessibilityProvider(hwnd));
    if (! provider)
    {
        return false;
    }
    wil::com_ptr_nothrow<IRawElementProviderSimple> simpleProvider;
    if (FAILED(provider.query_to(simpleProvider.put())) || ! simpleProvider)
    {
        return false;
    }

    wil::unique_bstr notificationText(SysAllocStringLen(notification.data(), static_cast<UINT>(notification.size())));
    wil::unique_bstr activityText(SysAllocStringLen(activityId.data(), static_cast<UINT>(activityId.size())));
    if (! notificationText || (! activityId.empty() && ! activityText))
    {
        return false;
    }

    return SUCCEEDED(UiaRaiseNotificationEvent(
        simpleProvider.get(), NotificationKind_ActionCompleted, NotificationProcessing_MostRecent, notificationText.get(), activityText.get()));
}

#if DXUI_ENABLE_DIAGNOSTICS

void DebugSetAccessibilityUiActionHandlerStallForTest(HANDLE enteredEvent, HANDLE releaseEvent) noexcept
{
    g_accessibilityUiActionHandlerEnteredEvent.store(enteredEvent, std::memory_order_release);
    g_accessibilityUiActionHandlerReleaseEvent.store(releaseEvent, std::memory_order_release);
}

void DebugSetAccessibilityUiActionHandlerTakenStallForTest(HANDLE enteredEvent, HANDLE releaseEvent) noexcept
{
    g_accessibilityUiActionHandlerTakenEnteredEvent.store(enteredEvent, std::memory_order_release);
    g_accessibilityUiActionHandlerTakenReleaseEvent.store(releaseEvent, std::memory_order_release);
}

void DebugSetAccessibilityUiActionPostedEventForTest(HANDLE postedEvent) noexcept
{
    g_accessibilityUiActionPostedEvent.store(postedEvent, std::memory_order_release);
}

void DebugSetAccessibilityUiActionDispatchTimeoutForTest(DWORD timeoutMs) noexcept
{
    g_accessibilityUiActionDispatchTimeoutOverrideMs.store(timeoutMs, std::memory_order_release);
}

void DebugResetAccessibilityUiActionExecutionCountForTest() noexcept
{
    g_accessibilityUiActionExecutionCount.store(0u, std::memory_order_release);
}

uint32_t DebugGetAccessibilityUiActionExecutionCountForTest() noexcept
{
    return g_accessibilityUiActionExecutionCount.load(std::memory_order_acquire);
}

void DebugSetAccessibilityOffscreenSelectedRowMaterializationLimitForTest(size_t limit) noexcept
{
    g_accessibilityOffscreenSelectedRowMaterializationLimitOverride.store(limit, std::memory_order_release);
}

uint64_t DebugGetAccessibilityFocusResolutionCountForTest(HWND hwnd) noexcept
{
    if (! hwnd)
        return (std::numeric_limits<uint64_t>::max)();
    const std::scoped_lock lock(GetAccessibilityTargetMutex());
    const auto* target = static_cast<const WindowHostAccessibilityTarget*>(GetPropW(hwnd, kWindowHostPropName));
    return target ? target->focusResolutions.load(std::memory_order_seq_cst) : (std::numeric_limits<uint64_t>::max)();
}

void DebugSetAccessibilityFocusResolutionGateForTest(HWND hwnd, HANDLE enteredEvent, HANDLE releaseEvent) noexcept
{
    if (hwnd && (enteredEvent || releaseEvent))
    {
        g_accessibilityFocusResolutionGateEnteredEvent.store(enteredEvent, std::memory_order_release);
        g_accessibilityFocusResolutionGateReleaseEvent.store(releaseEvent, std::memory_order_release);
        g_accessibilityFocusResolutionGateWindow.store(hwnd, std::memory_order_seq_cst);
        return;
    }

    // Clearing: no call meets the gate from here on, and the ones that met it leave (each waits at most five seconds for
    // its release event) before the test gets to close its events.
    g_accessibilityFocusResolutionGateWindow.store(nullptr, std::memory_order_seq_cst);
    for (uint32_t holders = g_accessibilityFocusResolutionGateHolders.load(std::memory_order_seq_cst); holders != 0u;
         holders          = g_accessibilityFocusResolutionGateHolders.load(std::memory_order_seq_cst))
    {
        g_accessibilityFocusResolutionGateHolders.wait(holders);
    }
    g_accessibilityFocusResolutionGateEnteredEvent.store(nullptr, std::memory_order_release);
    g_accessibilityFocusResolutionGateReleaseEvent.store(nullptr, std::memory_order_release);
}

void DebugSetAccessibilitySelectionEventHookForTest(AccessibilitySelectionEventHookForTest hook, void* context) noexcept
{
    if (! hook)
    {
        g_accessibilitySelectionEventHook.store(nullptr, std::memory_order_release);
        g_accessibilitySelectionEventHookContext.store(nullptr, std::memory_order_release);
        return;
    }
    g_accessibilitySelectionEventHookContext.store(context, std::memory_order_release);
    g_accessibilitySelectionEventHook.store(hook, std::memory_order_release);
}

void DebugSetAccessibilityResolutionCountingForTest(bool enabled) noexcept
{
    g_accessibilityResolutionVisitCount = 0u;
    g_accessibilityResolutionCounting   = enabled;
}

void DebugResetAccessibilityResolutionVisitCountForTest() noexcept
{
    g_accessibilityResolutionVisitCount = 0u;
}

uint64_t DebugGetAccessibilityResolutionVisitCountForTest() noexcept
{
    return g_accessibilityResolutionVisitCount;
}

bool DebugResolveWindowHostEventPathForTest(HWND hwnd, const Control* control, std::span<uint16_t> indices, uint32_t& depth) noexcept
{
    depth                        = 0u;
    constexpr auto releaseTarget = [](WindowHostAccessibilityTarget* value) noexcept { static_cast<void>(value->Release()); };
    wil::unique_any<WindowHostAccessibilityTarget*, decltype(releaseTarget), releaseTarget> target(AcquireWindowHostAccessibilityTarget(hwnd));
    if (! target)
        return false;
    ControlHost* const host = target.get()->ResolveHost();
    ControlPath path{};
    const auto snapshot = target.get()->snapshot.load(std::memory_order_acquire);
    if (! host || ! FindWindowHostControlPath(snapshot.get(), host->GetRoot(), control, path))
        return false;
    depth = path.depth;
    for (uint32_t index = 0u; index < path.depth && index < indices.size(); ++index)
        indices[index] = path.indices[index];
    return true;
}

size_t DebugCountAccessibilityIndexMismatchesForTest(HWND hwnd) noexcept
{
    constexpr auto releaseTarget = [](WindowHostAccessibilityTarget* value) noexcept { static_cast<void>(value->Release()); };
    wil::unique_any<WindowHostAccessibilityTarget*, decltype(releaseTarget), releaseTarget> target(AcquireWindowHostAccessibilityTarget(hwnd));
    const std::shared_ptr<const AccessibilitySnapshot> snapshot = target ? target.get()->snapshot.load(std::memory_order_acquire) : nullptr;
    if (! snapshot)
        return (std::numeric_limits<size_t>::max)();

    // The checks are not resolutions to count.
    const bool counting        = std::exchange(g_accessibilityResolutionCounting, false);
    const auto restoreCounting = wil::scope_exit([&]() noexcept { g_accessibilityResolutionCounting = counting; });
    ControlHost* const host    = target.get()->ResolveHost();
    const auto& records        = snapshot->controlNavigationRecords;
    const auto& hits           = snapshot->pointHitRecords;
    size_t mismatches          = snapshot->semanticControlOrder.size() == records.size() ? 0u : 1u;

    const auto scanRecord = [&](const ControlPath& path) noexcept -> const AccessibilityControlNavigationSnapshot*
    {
        for (const AccessibilityControlNavigationSnapshot& record : records)
        {
            if (AreControlPathsEqual(record.path, path))
                return &record;
        }
        return nullptr;
    };
    const auto checkRecord = [&](const ControlPath& path) noexcept
    {
        if (FindControlNavigationRecord(*snapshot, path) != scanRecord(path))
            ++mismatches;
    };
    for (size_t ordinal = 0u; ordinal < records.size(); ++ordinal)
    {
        const ControlPath& path = records[ordinal].path;
        if (FindControlNavigationRecord(*snapshot, path) != &records[ordinal] || FindSemanticControlOrderIndex(*snapshot, path) != ordinal)
            ++mismatches;
        // Paths beside this one, which may or may not hold a record: the parent, the next sibling and the first child.
        if (path.depth != 0u)
        {
            ControlPath parent = path;
            --parent.depth;
            checkRecord(parent);
            ControlPath sibling = path;
            ++sibling.indices[sibling.depth - 1u];
            checkRecord(sibling);
        }
        if (path.depth < kAccessibilityMaxDepth)
        {
            ControlPath child            = path;
            child.indices[child.depth++] = 0u;
            checkRecord(child);
        }
        // The published control at this path, found by its address (the tree is expected to match its snapshot).
        if (const Control* const live = host ? ResolveControlAtPath(host->GetRoot(), path) : nullptr;
            live && FindControlRecordOrdinalByAddress(*snapshot, live) != ordinal)
            ++mismatches;
    }

    const auto scanBounds = [&](const AccessibilityPointHitSnapshot& key, size_t treeVisibleIndex, uint64_t gridRowId, size_t gridColumnIndex) noexcept
    {
        std::optional<D2D1_RECT_F> expected;
        for (const AccessibilityPointHitSnapshot& hit : hits)
        {
            if (SnapshotPointHitMatchesFragment(hit, key.kind, key.path, treeVisibleIndex, gridRowId, gridColumnIndex))
            {
                expected = hit.hitRectDip;
                break;
            }
        }
        const std::optional<D2D1_RECT_F> found = FindSnapshotFragmentBounds(*snapshot, key.kind, key.path, treeVisibleIndex, gridRowId, gridColumnIndex);
        if (found.has_value() != expected.has_value() || (found && std::memcmp(&found.value(), &expected.value(), sizeof(D2D1_RECT_F)) != 0))
            ++mismatches;
    };
    for (const AccessibilityPointHitSnapshot& hit : hits)
    {
        scanBounds(hit, hit.treeVisibleIndex, hit.gridRowId, hit.gridColumnIndex);
        // The same fragment one item along, which may or may not exist.
        scanBounds(hit, hit.treeVisibleIndex + 1u, hit.gridRowId + 1u, hit.gridColumnIndex + 1u);
    }
    return mismatches;
}
#endif
} // namespace DxUi
