#include "DxUi.Internal.h"
#include "TextStoreTarget.h"

#include "../Support/Diagnostics.h"

#include <algorithm>
#include <atomic>
#include <exception>
#include <limits>

#include <msctf.h>
#include <textstor.h>

namespace DxUi
{
namespace
{
constexpr TsViewCookie kTextStoreView = 1u;

[[nodiscard]] LONG ToAcp(size_t value) noexcept
{
    return static_cast<LONG>((std::min)(value, static_cast<size_t>((std::numeric_limits<LONG>::max)())));
}

[[nodiscard]] bool IsTextStoreLayoutAvailable(const D2D1_RECT_F& bounds) noexcept
{
    return bounds.right > bounds.left && bounds.bottom > bounds.top;
}

[[nodiscard]] size_t ClampAcp(LONG value, size_t textLength, bool negativeMeansEnd = false) noexcept
{
    if (value < 0)
    {
        return negativeMeansEnd ? textLength : 0u;
    }

    return (std::min)(static_cast<size_t>(value), textLength);
}

struct AcpRange
{
    size_t start = 0u;
    size_t end   = 0u;
};

[[nodiscard]] AcpRange ClampAcpRange(LONG start, LONG end, size_t textLength, bool endMinusOneMeansEnd = true) noexcept
{
    AcpRange range{ClampAcp(start, textLength), ClampAcp(end, textLength, endMinusOneMeansEnd)};
    if (range.end < range.start)
    {
        std::swap(range.start, range.end);
    }
    return range;
}

[[nodiscard]] bool HasSelection(const TextInputState& state) noexcept
{
    return state.selectionAnchorIndex.has_value() && state.selectionAnchorIndex.value() != state.caretIndex;
}

[[nodiscard]] AcpRange GetSelectionRange(const TextInputState& state) noexcept
{
    if (! HasSelection(state))
    {
        const size_t caretIndex = (std::min)(state.caretIndex, state.text.size());
        return AcpRange{caretIndex, caretIndex};
    }

    return ClampAcpRange(ToAcp(state.selectionAnchorIndex.value()), ToAcp(state.caretIndex), state.text.size(), false);
}

[[nodiscard]] bool IsSameSelection(const TextInputState& left, const TextInputState& right) noexcept
{
    return left.caretIndex == right.caretIndex && left.selectionAnchorIndex == right.selectionAnchorIndex;
}

[[nodiscard]] bool IsSameRect(const D2D1_RECT_F& left, const D2D1_RECT_F& right) noexcept
{
    return left.left == right.left && left.top == right.top && left.right == right.right && left.bottom == right.bottom;
}

[[nodiscard]] RECT DipRectToScreenRect(ControlHost& host, const D2D1_RECT_F& rectDip) noexcept
{
    POINT topLeft{static_cast<LONG>(std::lround(host.DipsToPixels(rectDip.left))), static_cast<LONG>(std::lround(host.DipsToPixels(rectDip.top)))};
    POINT bottomRight{static_cast<LONG>(std::lround(host.DipsToPixels(rectDip.right))), static_cast<LONG>(std::lround(host.DipsToPixels(rectDip.bottom)))};
    ClientToScreen(host.GetHwnd(), &topLeft);
    ClientToScreen(host.GetHwnd(), &bottomRight);
    return RECT{topLeft.x, topLeft.y, bottomRight.x, bottomRight.y};
}

[[nodiscard]] D2D1_RECT_F ClipTextStoreRectToBounds(D2D1_RECT_F rect, const D2D1_RECT_F& bounds) noexcept
{
    rect.left   = std::clamp(rect.left, bounds.left, bounds.right);
    rect.right  = std::clamp(rect.right, rect.left, bounds.right);
    rect.top    = std::clamp(rect.top, bounds.top, bounds.bottom);
    rect.bottom = std::clamp(rect.bottom, rect.top, bounds.bottom);
    if (rect.right <= rect.left)
    {
        rect.right = (std::min)(bounds.right, rect.left + 1.0f);
    }
    if (rect.bottom <= rect.top)
    {
        rect.bottom = (std::min)(bounds.bottom, rect.top + 1.0f);
    }
    return rect;
}

[[nodiscard]] std::optional<D2D1_RECT_F> TryResolveMultilineTextStoreRangeRect(const ControlHost& host,
                                                                               const Control& control,
                                                                               const AcpRange& range,
                                                                               const D2D1_RECT_F& bounds) noexcept
{
    if (range.start < range.end)
    {
        const std::optional<std::vector<D2D1_RECT_F>> rangeRects = control.TryGetTextInputRangeRects(host, range.start, range.end);
        if (rangeRects.has_value() && ! rangeRects.value().empty())
        {
            D2D1_RECT_F rect = rangeRects.value().front();
            for (const D2D1_RECT_F& rangeRect : rangeRects.value())
            {
                rect.left   = (std::min)(rect.left, rangeRect.left);
                rect.top    = (std::min)(rect.top, rangeRect.top);
                rect.right  = (std::max)(rect.right, rangeRect.right);
                rect.bottom = (std::max)(rect.bottom, rangeRect.bottom);
            }
            return ClipTextStoreRectToBounds(rect, bounds);
        }
    }

    std::optional<D2D1_RECT_F> result;
    for (size_t index = range.start;; ++index)
    {
        const std::optional<D2D1_RECT_F> caretRect = control.TryGetTextInputCaretRect(host, index);
        if (! caretRect.has_value())
        {
            return std::nullopt;
        }

        if (! result.has_value())
        {
            result = caretRect.value();
        }
        else
        {
            D2D1_RECT_F rect = result.value();
            rect.left        = (std::min)(rect.left, caretRect->left);
            rect.top         = (std::min)(rect.top, caretRect->top);
            rect.right       = (std::max)(rect.right, caretRect->right);
            rect.bottom      = (std::max)(rect.bottom, caretRect->bottom);
            result           = rect;
        }

        if (index == range.end)
        {
            break;
        }
    }

    return ClipTextStoreRectToBounds(result.value(), bounds);
}

[[nodiscard]] bool TextStoreControlBelongsToTree(const Control* root, const Control* target) noexcept
{
    if (! root || ! target)
    {
        return false;
    }
    if (root == target)
    {
        return true;
    }
    const auto* panel = dynamic_cast<const Panel*>(root);
    if (! panel)
    {
        return false;
    }
    for (const auto& child : panel->GetChildren())
    {
        if (child && TextStoreControlBelongsToTree(child.get(), target))
        {
            return true;
        }
    }
    return false;
}

class NativeTextStoreTarget final : public TextStoreTarget
{
public:
    NativeTextStoreTarget(ControlHost& host, Control& control) noexcept : _host(&host), _control(&control), _controlLifetime(GetControlLifetimeToken(control))
    {
    }
    void Disconnect() noexcept override
    {
        _host    = nullptr;
        _control = nullptr;
        _controlLifetime.reset();
    }
    [[nodiscard]] HWND GetHwnd() const noexcept override
    {
        return _host ? _host->GetHwnd() : nullptr;
    }
    HRESULT GetAcpFromScreenPoint(const POINT* ptScreen, LONG* pacp) const noexcept override
    {
        TextInputState state{};
        Control* const control = GetLiveControl();
        if (! ReadState(state) || ! control)
        {
            return TS_E_INVALIDPOS;
        }

        const std::optional<PointDip> pointDip = _host->ScreenPointToDipPoint(*ptScreen);
        if (! pointDip)
        {
            return TS_E_INVALIDPOS;
        }

        const D2D1_RECT_F bounds = ResolveTextViewportBounds();
        if (! IsTextStoreLayoutAvailable(bounds))
        {
            *pacp = 0;
            return TS_E_NOLAYOUT;
        }
        if (! PointInRect(bounds, D2D1::Point2F(pointDip->x, pointDip->y)))
        {
            return TS_E_INVALIDPOS;
        }

        const D2D1_POINT_2F queryPoint = D2D1::Point2F(pointDip->x, pointDip->y);
        if (const std::optional<size_t> hitIndex = control->TryHitTestTextInputPoint(*_host, queryPoint); hitIndex.has_value())
        {
            *pacp = ToAcp((std::min)(hitIndex.value(), state.text.size()));
            return S_OK;
        }

        const DWRITE_READING_DIRECTION readingDirection = ResolveReadingDirection(control->GetFlowDirection());
        *pacp = ToAcp(HitTestCaretIndexDip(_host, state.text, FontRole::Body, bounds, 0.0f, queryPoint, readingDirection));
        return S_OK;
    }
    HRESULT GetRangeScreenRect(LONG acpStart, LONG acpEnd, RECT* prc, BOOL* pfClipped) const noexcept override
    {
        TextInputState state{};
        Control* const control = GetLiveControl();
        if (! ReadState(state) || ! control)
        {
            return TS_E_INVALIDPOS;
        }

        const D2D1_RECT_F bounds = ResolveTextViewportBounds();
        if (! IsTextStoreLayoutAvailable(bounds))
        {
            *prc       = RECT{};
            *pfClipped = TRUE;
            return TS_E_NOLAYOUT;
        }
        const AcpRange range = ClampAcpRange(acpStart, acpEnd, state.text.size(), false);
        if (state.multiline)
        {
            const std::optional<D2D1_RECT_F> rectDip = TryResolveMultilineTextStoreRangeRect(*_host, *control, range, bounds);
            if (! rectDip.has_value())
            {
                *prc       = RECT{};
                *pfClipped = TRUE;
                return TS_E_NOLAYOUT;
            }

            *prc       = DipRectToScreenRect(*_host, rectDip.value());
            *pfClipped = FALSE;
            return S_OK;
        }

        const float heightDip                           = (std::max)(1.0f, bounds.bottom - bounds.top);
        const float layoutWidth                         = (std::max)(1.0f, bounds.right - bounds.left);
        const DWRITE_READING_DIRECTION readingDirection = ResolveReadingDirection(control->GetFlowDirection());
        const float startOffset = MeasureCaretOffsetDip(_host, state.text, FontRole::Body, range.start, heightDip, readingDirection, layoutWidth);
        const float endOffset   = MeasureCaretOffsetDip(_host, state.text, FontRole::Body, range.end, heightDip, readingDirection, layoutWidth);
        D2D1_RECT_F rectDip     = bounds;
        rectDip.left            = std::clamp(bounds.left + (std::min)(startOffset, endOffset), bounds.left, bounds.right);
        const float minRight    = (std::min)(rectDip.left + 1.0f, bounds.right);
        rectDip.right           = std::clamp(bounds.left + (std::max)(startOffset, endOffset), minRight, bounds.right);

        *prc       = DipRectToScreenRect(*_host, rectDip);
        *pfClipped = FALSE;
        return S_OK;
    }
    HRESULT GetScreenRect(RECT* prc) const noexcept override
    {
        if (! GetLiveControl())
        {
            return TS_E_INVALIDPOS;
        }

        const D2D1_RECT_F bounds = ResolveTextViewportBounds();
        if (! IsTextStoreLayoutAvailable(bounds))
        {
            *prc = RECT{};
            return TS_E_NOLAYOUT;
        }
        POINT topLeft{static_cast<LONG>(std::lround(_host->DipsToPixels(bounds.left))), static_cast<LONG>(std::lround(_host->DipsToPixels(bounds.top)))};
        POINT bottomRight{static_cast<LONG>(std::lround(_host->DipsToPixels(bounds.right))),
                          static_cast<LONG>(std::lround(_host->DipsToPixels(bounds.bottom)))};
        ClientToScreen(_host->GetHwnd(), &topLeft);
        ClientToScreen(_host->GetHwnd(), &bottomRight);
        *prc = RECT{topLeft.x, topLeft.y, bottomRight.x, bottomRight.y};
        return S_OK;
    }
    [[nodiscard]] Control* GetLiveControl() const noexcept
    {
        if (! _host || ! _control || _controlLifetime.expired() || ! TextStoreControlBelongsToTree(_host->GetRoot(), _control))
        {
            return nullptr;
        }
        return _control;
    }

    [[nodiscard]] bool ReadState(TextInputState& outState) const noexcept override
    {
        try
        {
            Control* const control = GetLiveControl();
            if (! control)
            {
                return false;
            }

            NativeTextInputState nativeState{};
            if (_host->TryReadNativeTextInputState(control, nativeState))
            {
                outState.text                 = nativeState.text;
                outState.selectionAnchorIndex = nativeState.selectionAnchorIndex;
                outState.caretIndex           = nativeState.caretIndex;
                outState.firstVisibleLine     = nativeState.firstVisibleLine;
                outState.readOnly             = nativeState.readOnly;
                outState.masked               = nativeState.masked;
                outState.multiline            = nativeState.multiline;
                return true;
            }

            if (const auto* textField = dynamic_cast<const TextField*>(control))
            {
                outState.text       = textField->GetText();
                outState.readOnly   = textField->IsReadOnly();
                outState.masked     = textField->IsMasked();
                outState.caretIndex = outState.text.size();
                if (const std::optional<std::pair<size_t, size_t>> selection = textField->GetSelectionRange())
                {
                    outState.selectionAnchorIndex = selection->first;
                    outState.caretIndex           = selection->second;
                }
                return true;
            }

            if (const auto* comboBox = dynamic_cast<const ComboBox*>(control); comboBox && comboBox->IsEditable())
            {
                outState.text       = comboBox->GetText();
                outState.caretIndex = outState.text.size();
                if (const std::optional<std::pair<size_t, size_t>> selection = comboBox->GetEditableSelectionRange())
                {
                    outState.selectionAnchorIndex = selection->first;
                    outState.caretIndex           = selection->second;
                }
                return true;
            }

            return false;
        }
        catch (const std::bad_alloc&)
        {
            outState = {};
            return false;
        }
    }

    [[nodiscard]] bool ApplyState(const TextInputState& state, bool notifyChange) noexcept override
    {
        Control* const control = GetLiveControl();
        if (! control || state.readOnly)
        {
            return false;
        }

        Control* const previousFocus = _host->GetFocusControl();
        try
        {
            if (auto* textField = dynamic_cast<TextField*>(control))
            {
                if (notifyChange)
                {
                    textField->SetTextAndNotify(state.text);
                }
                else
                {
                    textField->SetText(state.text);
                }

                // Notifying user code may replace the tree, focus or text. Never apply stale selection afterward.
                if (GetLiveControl() != control || _host->GetFocusControl() != previousFocus || textField->GetText() != state.text)
                    return false;
                const size_t selectionStart = state.selectionAnchorIndex.value_or(state.caretIndex);
                textField->SetSelectionRange(selectionStart, state.caretIndex);
                _host->SyncTextInput(control);
                _host->Invalidate();
                return true;
            }

            if (auto* comboBox = dynamic_cast<ComboBox*>(control); comboBox && comboBox->IsEditable())
            {
                if (notifyChange)
                {
                    comboBox->SetTextAndNotify(state.text);
                }
                else
                {
                    comboBox->SetText(state.text);
                }

                if (GetLiveControl() != control || _host->GetFocusControl() != previousFocus || comboBox->GetText() != state.text)
                    return false;
                const size_t selectionStart = state.selectionAnchorIndex.value_or(state.caretIndex);
                comboBox->SetEditableSelectionRange(selectionStart, state.caretIndex);
                _host->SyncTextInput(control);
                _host->Invalidate();
                return true;
            }
        }
        catch (const std::exception&)
        {
            // Contain allocation/user callback failures at the COM boundary. SetText already invalidated its view.
            return false;
        }
        return false;
    }

    [[nodiscard]] D2D1_RECT_F ResolveTextViewportBounds() const noexcept override
    {
        Control* const control = GetLiveControl();
        if (! control)
        {
            return D2D1::RectF();
        }
        if (const std::optional<D2D1_RECT_F> viewport = control->TryGetTextInputViewportRect(); viewport.has_value())
        {
            return viewport.value();
        }
        return control->GetHitBounds();
    }

private:
    ControlHost* _host = nullptr;
    Control* _control  = nullptr;
    std::weak_ptr<int> _controlLifetime;
};

class TextStoreACP final : public ITextStoreACP, public ITextStoreACP2, public ITfContextOwnerCompositionSink
{
public:
    explicit TextStoreACP(std::shared_ptr<TextStoreTarget> target) noexcept : _target(std::move(target))
    {
    }

    TextStoreACP(const TextStoreACP&)            = delete;
    TextStoreACP& operator=(const TextStoreACP&) = delete;
    TextStoreACP(TextStoreACP&&)                 = delete;
    TextStoreACP& operator=(TextStoreACP&&)      = delete;

    ~TextStoreACP() noexcept
    {
        DetachHost();
    }

    void DetachHost() noexcept
    {
        Disconnect();
    }

    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void** ppvObject) noexcept override
    {
        if (! ppvObject)
        {
            return E_POINTER;
        }

        *ppvObject = nullptr;
        if (riid == __uuidof(IUnknown) || riid == __uuidof(ITextStoreACP))
        {
            *ppvObject = static_cast<ITextStoreACP*>(this);
            AddRef();
            return S_OK;
        }
        if (riid == __uuidof(ITextStoreACP2))
        {
            *ppvObject = static_cast<ITextStoreACP2*>(this);
            AddRef();
            return S_OK;
        }
        if (riid == __uuidof(ITfContextOwnerCompositionSink))
        {
            *ppvObject = static_cast<ITfContextOwnerCompositionSink*>(this);
            AddRef();
            return S_OK;
        }

        return E_NOINTERFACE;
    }

    ULONG STDMETHODCALLTYPE AddRef() noexcept override
    {
        return _referenceCount.fetch_add(1u, std::memory_order_relaxed) + 1u;
    }

    ULONG STDMETHODCALLTYPE Release() noexcept override
    {
        const ULONG remaining = _referenceCount.fetch_sub(1u, std::memory_order_acq_rel) - 1u;
        if (remaining == 0u)
        {
            delete this;
        }
        return remaining;
    }

    void Disconnect() noexcept
    {
        _sink.reset();
        _sinkMask         = 0u;
        _lockFlags        = 0u;
        _pendingLockFlags = 0;
        _target->Disconnect();
        SecureWipe::SecureClear(_observedState.text);
        _observedState    = TextInputState{};
        _observedViewport = D2D1::RectF();
        _hasObservedState = false;
    }

    HRESULT STDMETHODCALLTYPE OnStartComposition(ITfCompositionView* composition, BOOL* outAccepted) noexcept override
    {
        if (! outAccepted)
        {
            return E_POINTER;
        }

        *outAccepted = FALSE;
        return _target->StartComposition(composition, outAccepted);
    }

    HRESULT STDMETHODCALLTYPE OnUpdateComposition(ITfCompositionView* composition, ITfRange* rangeNew) noexcept override
    {
        return _target->UpdateComposition(composition, rangeNew);
    }

    HRESULT STDMETHODCALLTYPE OnEndComposition(ITfCompositionView* composition) noexcept override
    {
        return _target->EndComposition(composition);
    }

    HRESULT STDMETHODCALLTYPE AdviseSink(REFIID riid, IUnknown* punk, DWORD dwMask) noexcept override
    {
        if (! punk)
        {
            return E_INVALIDARG;
        }
        if (riid != __uuidof(ITextStoreACPSink))
        {
            return E_NOINTERFACE;
        }
        if (_sink)
        {
            return E_FAIL;
        }

        ITextStoreACPSink* rawSink = nullptr;
        const HRESULT hr           = punk->QueryInterface(__uuidof(ITextStoreACPSink), reinterpret_cast<void**>(&rawSink));
        if (FAILED(hr))
        {
            return hr;
        }

        _sink.attach(rawSink);
        _sinkMask = dwMask;
        CaptureObservedState();
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE UnadviseSink(IUnknown* punk) noexcept override
    {
        if (! punk)
        {
            return E_INVALIDARG;
        }
        if (! _sink)
        {
            return E_FAIL;
        }

        wil::com_ptr_nothrow<IUnknown> requestedIdentity;
        HRESULT hr = punk->QueryInterface(__uuidof(IUnknown), requestedIdentity.put_void());
        if (FAILED(hr) || ! requestedIdentity)
        {
            return E_FAIL;
        }

        wil::com_ptr_nothrow<IUnknown> advisedIdentity;
        hr = _sink->QueryInterface(__uuidof(IUnknown), advisedIdentity.put_void());
        if (FAILED(hr) || ! advisedIdentity || requestedIdentity.get() != advisedIdentity.get())
        {
            return E_FAIL;
        }

        _sink.reset();
        _sinkMask = 0u;
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE RequestLock(DWORD dwLockFlags, HRESULT* phrSession) noexcept override
    {
        if (! phrSession)
        {
            return E_POINTER;
        }

        *phrSession = S_OK;
        if (_lockFlags != 0u)
        {
            *phrSession = TS_E_SYNCHRONOUS;
            if ((dwLockFlags & TS_LF_SYNC) == 0)
            {
                const DWORD previous = _pendingLockFlags;
                _pendingLockFlags |= (dwLockFlags & TS_LF_READWRITE);
                if (_target->ScheduleLock())
                    *phrSession = TS_S_ASYNC;
                else
                    _pendingLockFlags = previous;
            }
            return S_OK;
        }

        NotifyExternalChangesIfNeeded();
        _lockFlags = dwLockFlags;
        // A deferred request may have been accepted while the previous lock was held, but its post could fail while
        // that lock was released. Retain the coalesced flags and make one bounded retry when TSF next requests a lock.
        // Mark this lock active first so a nested message loop can defer, never recursively grant, the queued request.
        if (_pendingLockFlags != 0u)
            static_cast<void>(_target->ScheduleLock());
        wil::com_ptr_nothrow<ITextStoreACPSink> sink = _sink;
        const bool isReadWriteLock                   = (dwLockFlags & TS_LF_READWRITE) == TS_LF_READWRITE;
        const HRESULT beginHr                        = _target->BeginEdit(isReadWriteLock);
        if (FAILED(beginHr))
        {
            ReleaseLockAndSchedulePending();
            *phrSession = beginHr;
            return S_OK;
        }
        bool editTransactionStarted = false;
        if (sink && isReadWriteLock)
        {
            const HRESULT startHr = sink->OnStartEditTransaction();
            if (FAILED(startHr))
            {
                *phrSession = startHr;
                static_cast<void>(_target->EndEdit(false));
                ReleaseLockAndSchedulePending();
                return S_OK;
            }
            editTransactionStarted = true;
        }

        if (sink)
        {
            *phrSession = sink->OnLockGranted(dwLockFlags);
        }

        const HRESULT applyHr = _target->EndEdit(SUCCEEDED(*phrSession));
        if (SUCCEEDED(*phrSession) && FAILED(applyHr))
            *phrSession = applyHr;
        if (SUCCEEDED(*phrSession))
            CaptureObservedState();
        if (sink && editTransactionStarted)
        {
            const HRESULT endHr = sink->OnEndEditTransaction();
            if (SUCCEEDED(*phrSession) && FAILED(endHr))
            {
                *phrSession = endHr;
            }
        }
        ReleaseLockAndSchedulePending();
        return S_OK;
    }

    HRESULT DispatchPendingLock() noexcept
    {
        if (_lockFlags != 0)
            return TS_E_NOLOCK;
        const DWORD flags = std::exchange(_pendingLockFlags, 0);
        if (! flags || ! _sink)
            return S_FALSE;
        HRESULT session  = S_OK;
        const HRESULT hr = RequestLock(flags, &session);
        return FAILED(hr) ? hr : session;
    }

    HRESULT STDMETHODCALLTYPE GetStatus(TS_STATUS* pdcs) noexcept override
    {
        if (! pdcs)
        {
            return E_POINTER;
        }

        pdcs->dwDynamicFlags = 0u;
        pdcs->dwStaticFlags  = TS_SS_NOHIDDENTEXT;
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE QueryInsert(LONG acpTestStart, LONG acpTestEnd, ULONG cch, LONG* pacpResultStart, LONG* pacpResultEnd) noexcept override
    {
        if (! pacpResultStart || ! pacpResultEnd)
        {
            return E_POINTER;
        }

        TextInputState state{};
        if (! ReadState(state))
        {
            return TS_E_INVALIDPOS;
        }

        const AcpRange range = ClampAcpRange(acpTestStart, acpTestEnd, state.text.size());
        *pacpResultStart     = ToAcp(range.start);
        *pacpResultEnd       = ToAcp(range.start + cch);
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetSelection(ULONG ulIndex, ULONG ulCount, TS_SELECTION_ACP* pSelection, ULONG* pcFetched) noexcept override
    {
        if (! HasReadLock())
        {
            return TS_E_NOLOCK;
        }
        if (! pSelection || ! pcFetched)
        {
            return E_POINTER;
        }

        *pcFetched = 0u;
        if (ulCount == 0u || (ulIndex != TS_DEFAULT_SELECTION && ulIndex != 0u))
        {
            return S_OK;
        }

        TextInputState state{};
        if (! ReadState(state))
        {
            return TS_E_INVALIDPOS;
        }

        const AcpRange range             = GetSelectionRange(state);
        pSelection[0].acpStart           = ToAcp(range.start);
        pSelection[0].acpEnd             = ToAcp(range.end);
        pSelection[0].style.ase          = (HasSelection(state) && state.caretIndex < state.selectionAnchorIndex.value()) ? TS_AE_START : TS_AE_END;
        pSelection[0].style.fInterimChar = FALSE;
        *pcFetched                       = 1u;
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE SetSelection(ULONG ulCount, const TS_SELECTION_ACP* pSelection) noexcept override
    {
        if (! HasReadWriteLock())
        {
            return TS_E_NOLOCK;
        }
        if (ulCount == 0u)
        {
            return S_OK;
        }
        if (! pSelection)
        {
            return E_POINTER;
        }

        TextInputState state{};
        if (! ReadState(state))
        {
            return TS_E_INVALIDPOS;
        }

        const AcpRange range       = ClampAcpRange(pSelection[0].acpStart, pSelection[0].acpEnd, state.text.size(), false);
        const bool startIsActive   = pSelection[0].style.ase == TS_AE_START;
        state.caretIndex           = startIsActive ? range.start : range.end;
        state.selectionAnchorIndex = range.start == range.end ? std::nullopt : std::optional<size_t>(startIsActive ? range.end : range.start);
        if (! ApplyState(state, false))
        {
            return E_FAIL;
        }

        NotifySelectionChanged();
        NotifyLayoutChanged();
        CaptureObservedState();
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetText(LONG acpStart,
                                      LONG acpEnd,
                                      WCHAR* pchPlain,
                                      ULONG cchPlainReq,
                                      ULONG* pcchPlainRet,
                                      TS_RUNINFO* prgRunInfo,
                                      ULONG cRunInfoReq,
                                      ULONG* pcRunInfoRet,
                                      LONG* pacpNext) noexcept override
    {
        if (! HasReadLock())
        {
            return TS_E_NOLOCK;
        }
        if (! pcchPlainRet || ! pcRunInfoRet || ! pacpNext)
        {
            return E_POINTER;
        }

        TextInputState state{};
        if (! ReadState(state))
        {
            return TS_E_INVALIDPOS;
        }

        const AcpRange range = ClampAcpRange(acpStart, acpEnd, state.text.size());
        const std::wstring_view value(state.text.data() + range.start, range.end - range.start);
        const size_t copied = (std::min)(value.size(), static_cast<size_t>(cchPlainReq));
        if (pchPlain && copied > 0u)
        {
            std::copy_n(value.data(), copied, pchPlain);
        }

        *pcchPlainRet = static_cast<ULONG>(copied);
        *pcRunInfoRet = 0u;
        if (prgRunInfo && cRunInfoReq > 0u && copied > 0u)
        {
            prgRunInfo[0].type   = TS_RT_PLAIN;
            prgRunInfo[0].uCount = static_cast<ULONG>(copied);
            *pcRunInfoRet        = 1u;
        }
        *pacpNext = ToAcp(range.start + copied);
        return copied == value.size() ? S_OK : S_FALSE;
    }

    HRESULT STDMETHODCALLTYPE SetText(DWORD dwFlags, LONG acpStart, LONG acpEnd, const WCHAR* pchText, ULONG cch, TS_TEXTCHANGE* pChange) noexcept override
    {
        if (! HasReadWriteLock())
        {
            return TS_E_NOLOCK;
        }

        return ReplaceTextRange(dwFlags, acpStart, acpEnd, pchText, cch, pChange);
    }

    HRESULT STDMETHODCALLTYPE GetFormattedText(LONG /*acpStart*/, LONG /*acpEnd*/, IDataObject** ppDataObject) noexcept override
    {
        if (! ppDataObject)
        {
            return E_POINTER;
        }

        *ppDataObject = nullptr;
        return E_NOTIMPL;
    }

    HRESULT STDMETHODCALLTYPE GetEmbedded(LONG /*acpPos*/, REFGUID /*rguidService*/, REFIID /*riid*/, IUnknown** ppunk) noexcept override
    {
        if (! ppunk)
        {
            return E_POINTER;
        }

        *ppunk = nullptr;
        return E_NOTIMPL;
    }

    HRESULT STDMETHODCALLTYPE QueryInsertEmbedded(const GUID* /*pguidService*/, const FORMATETC* /*pFormatEtc*/, BOOL* pfInsertable) noexcept override
    {
        if (! pfInsertable)
        {
            return E_POINTER;
        }

        *pfInsertable = FALSE;
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE
    InsertEmbedded(DWORD /*dwFlags*/, LONG /*acpStart*/, LONG /*acpEnd*/, IDataObject* /*pDataObject*/, TS_TEXTCHANGE* /*pChange*/) noexcept override
    {
        return E_NOTIMPL;
    }

    HRESULT STDMETHODCALLTYPE RequestSupportedAttrs(DWORD /*dwFlags*/, ULONG /*cFilterAttrs*/, const TS_ATTRID* /*paFilterAttrs*/) noexcept override
    {
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE RequestAttrsAtPosition(LONG /*acpPos*/,
                                                     ULONG /*cFilterAttrs*/,
                                                     const TS_ATTRID* /*paFilterAttrs*/,
                                                     DWORD /*dwFlags*/) noexcept override
    {
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE RequestAttrsTransitioningAtPosition(LONG /*acpPos*/,
                                                                  ULONG /*cFilterAttrs*/,
                                                                  const TS_ATTRID* /*paFilterAttrs*/,
                                                                  DWORD /*dwFlags*/) noexcept override
    {
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE FindNextAttrTransition(LONG acpStart,
                                                     LONG /*acpHalt*/,
                                                     ULONG /*cFilterAttrs*/,
                                                     const TS_ATTRID* /*paFilterAttrs*/,
                                                     DWORD /*dwFlags*/,
                                                     LONG* pacpNext,
                                                     BOOL* pfFound,
                                                     LONG* plFoundOffset) noexcept override
    {
        if (! pacpNext || ! pfFound || ! plFoundOffset)
        {
            return E_POINTER;
        }

        *pacpNext      = acpStart;
        *pfFound       = FALSE;
        *plFoundOffset = 0;
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE RetrieveRequestedAttrs(ULONG /*ulCount*/, TS_ATTRVAL* /*paAttrVals*/, ULONG* pcFetched) noexcept override
    {
        if (! pcFetched)
        {
            return E_POINTER;
        }

        *pcFetched = 0u;
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetEndACP(LONG* pacp) noexcept override
    {
        if (! HasReadLock())
        {
            return TS_E_NOLOCK;
        }
        if (! pacp)
        {
            return E_POINTER;
        }

        TextInputState state{};
        if (! ReadState(state))
        {
            return TS_E_INVALIDPOS;
        }

        *pacp = ToAcp(state.text.size());
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetActiveView(TsViewCookie* pvcView) noexcept override
    {
        if (! pvcView)
        {
            return E_POINTER;
        }

        *pvcView = kTextStoreView;
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE GetACPFromPoint(TsViewCookie vcView, const POINT* ptScreen, DWORD /*dwFlags*/, LONG* pacp) noexcept override
    {
        if (! HasReadLock())
        {
            return TS_E_NOLOCK;
        }
        if (! ptScreen || ! pacp)
        {
            return E_POINTER;
        }
        if (vcView != kTextStoreView)
        {
            return E_INVALIDARG;
        }

        return _target->GetAcpFromScreenPoint(ptScreen, pacp);
    }

    HRESULT STDMETHODCALLTYPE GetTextExt(TsViewCookie vcView, LONG acpStart, LONG acpEnd, RECT* prc, BOOL* pfClipped) noexcept override
    {
        if (! HasReadLock())
        {
            return TS_E_NOLOCK;
        }
        if (! prc || ! pfClipped)
        {
            return E_POINTER;
        }
        if (vcView != kTextStoreView)
        {
            return E_INVALIDARG;
        }

        return _target->GetRangeScreenRect(acpStart, acpEnd, prc, pfClipped);
    }

    HRESULT STDMETHODCALLTYPE GetScreenExt(TsViewCookie vcView, RECT* prc) noexcept override
    {
        if (! prc)
        {
            return E_POINTER;
        }
        if (vcView != kTextStoreView)
        {
            return E_INVALIDARG;
        }
        return _target->GetScreenRect(prc);
    }

    HRESULT STDMETHODCALLTYPE GetWnd(TsViewCookie vcView, HWND* phwnd) noexcept override
    {
        if (! phwnd)
        {
            return E_POINTER;
        }
        if (vcView != kTextStoreView)
        {
            return E_INVALIDARG;
        }

        *phwnd = _target->GetHwnd();
        return *phwnd ? S_OK : TS_E_INVALIDPOS;
    }

    HRESULT STDMETHODCALLTYPE
    InsertTextAtSelection(DWORD dwFlags, const WCHAR* pchText, ULONG cch, LONG* pacpStart, LONG* pacpEnd, TS_TEXTCHANGE* pChange) noexcept override
    {
        if (pacpStart)
            *pacpStart = 0;
        if (pacpEnd)
            *pacpEnd = 0;
        if (pChange)
            *pChange = {};
        if (! HasReadWriteLock())
            return TS_E_NOLOCK;
        if ((dwFlags & ~(TS_IAS_NOQUERY | TS_IAS_QUERYONLY)) || (dwFlags & TS_IAS_NOQUERY && dwFlags & TS_IAS_QUERYONLY))
            return E_INVALIDARG;
        const bool queryOnly = (dwFlags & TS_IAS_QUERYONLY) != 0;
        if (! (dwFlags & TS_IAS_NOQUERY) && (! pacpStart || ! pacpEnd))
            return E_POINTER;
        if (! queryOnly && ! pChange)
            return E_POINTER;
        if (cch && ! pchText)
            return E_INVALIDARG;
        TextInputState state;
        if (! ReadState(state))
            return TS_E_INVALIDPOS;
        if (state.readOnly)
            return E_ACCESSDENIED;
        const AcpRange range     = GetSelectionRange(state);
        constexpr size_t maximum = 65536;
        const size_t retained    = state.text.size() - (range.end - range.start);
        if (retained > maximum || cch > maximum - retained)
            return HRESULT_FROM_WIN32(ERROR_BUFFER_OVERFLOW);
        if (! queryOnly)
        {
            const HRESULT hr = ReplaceTextRange(0, ToAcp(range.start), ToAcp(range.end), pchText, cch, pChange);
            if (FAILED(hr))
                return hr;
        }
        if (pacpStart)
            *pacpStart = ToAcp(range.start);
        if (pacpEnd)
            *pacpEnd = ToAcp(range.start + cch);
        if (pChange)
            *pChange = {ToAcp(range.start), ToAcp(range.end), ToAcp(range.start + cch)};
        return S_OK;
    }

    HRESULT STDMETHODCALLTYPE
    InsertEmbeddedAtSelection(DWORD /*dwFlags*/, IDataObject* /*pDataObject*/, LONG* pacpStart, LONG* pacpEnd, TS_TEXTCHANGE* /*pChange*/) noexcept override
    {
        if (! pacpStart || ! pacpEnd)
        {
            return E_POINTER;
        }

        *pacpStart = 0;
        *pacpEnd   = 0;
        return E_NOTIMPL;
    }

private:
    [[nodiscard]] bool HasReadLock() const noexcept
    {
        return (_lockFlags & TS_LF_READ) != 0u;
    }

    [[nodiscard]] bool HasReadWriteLock() const noexcept
    {
        return (_lockFlags & TS_LF_READWRITE) == TS_LF_READWRITE;
    }

    [[nodiscard]] bool ReadState(TextInputState& state) const noexcept
    {
        return _target->ReadState(state);
    }
    [[nodiscard]] bool ApplyState(const TextInputState& state, bool notifyChange) noexcept
    {
        return _target->ApplyState(state, notifyChange);
    }

    HRESULT ReplaceTextRange(DWORD dwFlags, LONG acpStart, LONG acpEnd, const WCHAR* pchText, ULONG cch, TS_TEXTCHANGE* pChange) noexcept
    {
        TextInputState state{};
        if (! ReadState(state))
        {
            return TS_E_INVALIDPOS;
        }
        if (state.readOnly)
        {
            return E_ACCESSDENIED;
        }
        if (cch > 0u && ! pchText)
        {
            return E_POINTER;
        }

        const AcpRange range = ClampAcpRange(acpStart, acpEnd, state.text.size());
        if ((dwFlags & TS_IAS_QUERYONLY) != 0u)
        {
            if (pChange)
            {
                pChange->acpStart  = ToAcp(range.start);
                pChange->acpOldEnd = ToAcp(range.end);
                pChange->acpNewEnd = ToAcp(range.start + cch);
            }
            return S_OK;
        }

        const std::wstring_view replacement(pchText ? pchText : L"", static_cast<size_t>(cch));
        constexpr size_t maximumTextUnits = 65536;
        const size_t retainedUnits        = state.text.size() - (range.end - range.start);
        if (retainedUnits > maximumTextUnits || replacement.size() > maximumTextUnits - retainedUnits)
            return HRESULT_FROM_WIN32(ERROR_BUFFER_OVERFLOW);
        try
        {
            state.text.replace(range.start, range.end - range.start, replacement);
        }
        catch (const std::bad_alloc&)
        {
            return E_OUTOFMEMORY;
        }
        state.caretIndex = range.start + replacement.size();
        state.selectionAnchorIndex.reset();
        if (! ApplyState(state, true))
        {
            return E_FAIL;
        }

        TS_TEXTCHANGE change{};
        change.acpStart  = ToAcp(range.start);
        change.acpOldEnd = ToAcp(range.end);
        change.acpNewEnd = ToAcp(state.caretIndex);
        if (pChange)
        {
            *pChange = change;
        }

        NotifyTextChanged(change);
        NotifySelectionChanged();
        NotifyLayoutChanged();
        CaptureObservedState();
        return S_OK;
    }

    void CaptureObservedState() noexcept
    {
        TextInputState state{};
        if (! ReadState(state))
        {
            _hasObservedState = false;
            return;
        }

        _observedState    = std::move(state);
        _observedViewport = ResolveTextViewportBounds();
        _hasObservedState = true;
    }

public:
    void NotifyExternalChangesIfNeeded() noexcept
    {
        if (! _sink || _lockFlags != 0)
        {
            return;
        }

        TextInputState currentState{};
        if (! ReadState(currentState))
        {
            _hasObservedState = false;
            return;
        }

        const D2D1_RECT_F currentViewport = ResolveTextViewportBounds();
        if (! _hasObservedState)
        {
            _observedState    = std::move(currentState);
            _observedViewport = currentViewport;
            _hasObservedState = true;
            return;
        }

        const bool textChanged      = currentState.text != _observedState.text;
        const bool selectionChanged = ! IsSameSelection(currentState, _observedState);
        const bool layoutChanged    = textChanged || selectionChanged || currentState.firstVisibleLine != _observedState.firstVisibleLine ||
                                      currentState.masked != _observedState.masked || currentState.multiline != _observedState.multiline ||
                                      ! IsSameRect(currentViewport, _observedViewport);

        const TS_TEXTCHANGE textChange{0, ToAcp(_observedState.text.size()), ToAcp(currentState.text.size())};

        _observedState    = std::move(currentState);
        _observedViewport = currentViewport;

        if (textChanged)
        {
            NotifyTextChanged(textChange);
        }
        if (selectionChanged)
        {
            NotifySelectionChanged();
        }
        if (layoutChanged)
        {
            NotifyLayoutChanged();
        }
    }

public:
    void NotifyPreparedLayout() noexcept
    {
        NotifyLayoutChanged();
    }

private:
    void ReleaseLockAndSchedulePending() noexcept
    {
        _lockFlags = 0u;
        if (_pendingLockFlags != 0u)
        {
            // On failure, keep the already-accepted request coalesced for the next real RequestLock call to retry.
            // ScheduleLock is a single PostMessage attempt; it never pumps or waits for the UI queue.
            static_cast<void>(_target->ScheduleLock());
        }
    }

    void NotifyTextChanged(const TS_TEXTCHANGE& change) noexcept
    {
        if (_sink && (_lockFlags == 0 || _target->NotifyDuringLock()) && (_sinkMask & TS_AS_TEXT_CHANGE) != 0u)
        {
            static_cast<void>(_sink->OnTextChange(0u, &change));
        }
    }

    void NotifySelectionChanged() noexcept
    {
        if (_sink && (_lockFlags == 0 || _target->NotifyDuringLock()) && (_sinkMask & TS_AS_SEL_CHANGE) != 0u)
        {
            static_cast<void>(_sink->OnSelectionChange());
        }
    }

    void NotifyLayoutChanged() noexcept
    {
        if (_sink && (_lockFlags == 0 || _target->NotifyDuringLock()) && (_sinkMask & TS_AS_LAYOUT_CHANGE) != 0u)
        {
            static_cast<void>(_sink->OnLayoutChange(TS_LC_CHANGE, kTextStoreView));
        }
    }

    [[nodiscard]] D2D1_RECT_F ResolveTextViewportBounds() const noexcept
    {
        return _target->ResolveTextViewportBounds();
    }

    std::atomic<ULONG> _referenceCount{1u};
    std::shared_ptr<TextStoreTarget> _target;
    DWORD _pendingLockFlags = 0;
    DWORD _lockFlags        = 0u;
    DWORD _sinkMask         = 0u;
    wil::com_ptr_nothrow<ITextStoreACPSink> _sink;
    TextInputState _observedState;
    D2D1_RECT_F _observedViewport = D2D1::RectF();
    bool _hasObservedState        = false;
};
} // namespace

ITextStoreACP* CreateTextStore(std::shared_ptr<TextStoreTarget> target) noexcept
{
    if (! target)
        return nullptr;
    auto* store = new (std::nothrow) TextStoreACP(std::move(target));
    return store ? static_cast<ITextStoreACP*>(store) : nullptr;
}

void NotifyTextStoreLayoutChanged(ITextStoreACP* store) noexcept
{
    // A sink callback can release the application's last reference.
    wil::com_ptr_nothrow<ITextStoreACP> lifetime = store;
    if (auto* concrete = dynamic_cast<TextStoreACP*>(store))
        concrete->NotifyPreparedLayout();
}
HRESULT DispatchPendingTextStoreLock(ITextStoreACP* store) noexcept
{
    // A sink callback can release the application's last reference.
    wil::com_ptr_nothrow<ITextStoreACP> lifetime = store;
    auto* concrete                               = dynamic_cast<TextStoreACP*>(store);
    return concrete ? concrete->DispatchPendingLock() : E_INVALIDARG;
}

void NotifyTextStoreChanged(ITextStoreACP* store) noexcept
{
    // A sink callback can release the application's last reference.
    wil::com_ptr_nothrow<ITextStoreACP> lifetime = store;
    if (auto* concrete = dynamic_cast<TextStoreACP*>(store))
        concrete->NotifyExternalChangesIfNeeded();
}

ITextStoreACP* CreateNativeTextInputTextStore(ControlHost& host, Control& control) noexcept
{
    try
    {
        return CreateTextStore(std::make_shared<NativeTextStoreTarget>(host, control));
    }
    catch (const std::bad_alloc&)
    {
        return nullptr;
    }
}

void DetachNativeTextInputTextStore(IUnknown* store) noexcept
{
    if (! store)
    {
        return;
    }

    wil::com_ptr_nothrow<ITextStoreACP> textStore;
    if (FAILED(store->QueryInterface(IID_PPV_ARGS(textStore.put()))) || ! textStore)
    {
        return;
    }

    auto* concreteStore = static_cast<TextStoreACP*>(textStore.get());
    concreteStore->DetachHost();
}

void DisconnectNativeTextInputTextStore(IUnknown* textStore) noexcept
{
    auto* store = dynamic_cast<TextStoreACP*>(textStore);
    if (store)
    {
        store->Disconnect();
    }
}

#if DXUI_ENABLE_DIAGNOSTICS
ITextStoreACP* ControlHost::DebugCreateNativeTextInputTextStoreForTest() noexcept
{
    if (_textInputBackend != TextInputBackend::Native || ! _nativeTextInputControl || ! _nativeTextInputStateCacheValid)
    {
        return nullptr;
    }

    return CreateNativeTextInputTextStore(*this, *_nativeTextInputControl);
}
#endif
} // namespace DxUi
