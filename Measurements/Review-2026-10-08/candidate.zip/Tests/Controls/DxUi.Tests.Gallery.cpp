#include "Controls.Tests.DxUiTestHelpers.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <format>
#include <iostream>
#include <limits>
#include <string>
#include <string_view>
#include <thread>
#include <unordered_map>
#include <vector>

namespace
{
using namespace DxUi;

constexpr float kGalleryWidthDip = 1600.0f;
constexpr float kMarginDip       = 24.0f;
constexpr float kGapDip          = 10.0f;
constexpr size_t kColumnCount    = 7u;
constexpr float kTileWidthDip = (kGalleryWidthDip - (kMarginDip * 2.0f) - (kGapDip * static_cast<float>(kColumnCount - 1u))) / static_cast<float>(kColumnCount);

[[nodiscard]] UINT DipsToPixelsCeil(const WindowHost& host, float dips) noexcept;
void ResizeClientArea(AttachedHostWindow& window, UINT widthPx, UINT heightPx);

[[nodiscard]] float ClampUnit(float value) noexcept
{
    return std::clamp(value, 0.0f, 1.0f);
}

[[nodiscard]] D2D1_COLOR_F ColorFromArgbForGallery(uint32_t argb) noexcept
{
    const float a = static_cast<float>((argb >> 24u) & 0xFFu) / 255.0f;
    const float r = static_cast<float>((argb >> 16u) & 0xFFu) / 255.0f;
    const float g = static_cast<float>((argb >> 8u) & 0xFFu) / 255.0f;
    const float b = static_cast<float>(argb & 0xFFu) / 255.0f;
    return D2D1::ColorF(r, g, b, a);
}

[[nodiscard]] uint32_t PackArgbForGallery(const D2D1_COLOR_F& color) noexcept
{
    const auto toByte = [](float value) noexcept -> uint32_t { return static_cast<uint32_t>(std::clamp(std::lround(ClampUnit(value) * 255.0f), 0l, 255l)); };

    return (toByte(color.a) << 24u) | (toByte(color.r) << 16u) | (toByte(color.g) << 8u) | toByte(color.b);
}

struct GalleryTheme
{
    std::wstring name;
    std::wstring slug;
    ThemePalette palette;
};
[[nodiscard]] std::vector<GalleryTheme> BuildGalleryThemes()
{
    std::vector<GalleryTheme> themes;
    for (int i = 0; i < 5; ++i)
    {
        const bool dark       = i == 1 || i == 3 || i == 4;
        auto palette          = MakeDefaultThemePalette(dark);
        palette.reducedMotion = true;
        if (i == 2 || i == 3)
        {
            palette.rainbowMode = true;
        }
        if (i == 4)
        {
            ThemeColors colors{};
            colors.backgroundArgb          = 0xFF000000;
            colors.textArgb                = 0xFFFFFFFF;
            colors.selectionBackgroundArgb = 0xFF003B80;
            colors.selectionTextArgb       = 0xFFFFFFFF;
            colors.accentArgb              = 0xFFFFFF00;
            colors.darkMode                = TRUE;
            colors.darkBase                = TRUE;
            colors.highContrast            = TRUE;
            palette                        = MakeThemePalette(colors);
            palette.reducedMotion          = true;
        }
        const wchar_t* names[] = {L"Light", L"Dark", L"Rainbow light", L"Rainbow dark", L"High contrast"};
        const wchar_t* slugs[] = {L"light", L"dark", L"rainbow-light", L"rainbow-dark", L"high-contrast"};
        themes.push_back({names[i], slugs[i], palette});
    }
    return themes;
}

[[nodiscard]] HWND FindOwnedContextMenuPopupWindowByFirstItemText(HWND ownerHwnd, std::wstring_view firstItemText)
{
    HWND popupHwnd               = nullptr;
    const DWORD currentProcessId = GetCurrentProcessId();
    while ((popupHwnd = FindWindowExW(nullptr, popupHwnd, L"DxUi_ContextMenu", nullptr)) != nullptr)
    {
        DWORD popupProcessId = 0u;
        static_cast<void>(GetWindowThreadProcessId(popupHwnd, &popupProcessId));
        if (popupProcessId != currentProcessId || GetWindow(popupHwnd, GW_OWNER) != ownerHwnd || ! IsWindowVisible(popupHwnd))
        {
            continue;
        }

        std::wstring popupFirstItemText;
        if (DebugGetContextMenuPopupItemText(popupHwnd, 0u, popupFirstItemText) && std::wstring_view(popupFirstItemText) == firstItemText)
        {
            return popupHwnd;
        }
    }

    return nullptr;
}

[[nodiscard]] HWND WaitForOwnedContextMenuPopupWindowByFirstItemText(HWND ownerHwnd,
                                                                     std::wstring_view firstItemText,
                                                                     std::chrono::milliseconds timeout = std::chrono::milliseconds(1200))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (HWND popupHwnd = FindOwnedContextMenuPopupWindowByFirstItemText(ownerHwnd, firstItemText))
        {
            return popupHwnd;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return nullptr;
}

void DismissOwnedContextMenuPopupChain(HWND ownerHwnd) noexcept
{
    for (int attempt = 0; attempt < 4; ++attempt)
    {
        HWND popupHwnd               = nullptr;
        const DWORD currentProcessId = GetCurrentProcessId();
        bool dismissed               = false;
        while ((popupHwnd = FindWindowExW(nullptr, popupHwnd, L"DxUi_ContextMenu", nullptr)) != nullptr)
        {
            DWORD popupProcessId = 0u;
            static_cast<void>(GetWindowThreadProcessId(popupHwnd, &popupProcessId));
            if (popupProcessId == currentProcessId && GetWindow(popupHwnd, GW_OWNER) == ownerHwnd)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
                dismissed = true;
                break;
            }
        }

        if (! dismissed)
        {
            break;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(30));
    }
}

template <typename TPredicate>
[[nodiscard]] bool WaitForContextMenuPopupState(HWND popupHwnd,
                                                TPredicate&& predicate,
                                                ContextMenuPopupDebugState& outState,
                                                std::chrono::milliseconds timeout = std::chrono::milliseconds(1200))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (DebugGetContextMenuPopupState(popupHwnd, outState) && predicate(outState))
        {
            return true;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return false;
}

[[nodiscard]] bool HasPaintedPopupContent(const WindowHostBitmapCapture& capture) noexcept
{
    // A shown popup can still expose a newly allocated transparent surface before its first completed paint.
    // Menu content is opaque; require a meaningful painted area instead of accepting only allocated dimensions.
    size_t opaquePixels = 0;
    const size_t pixels = static_cast<size_t>(capture.widthPx) * capture.heightPx;
    if (pixels == 0 || capture.bgraPixels.size() != pixels * 4u)
        return false;
    for (size_t i = 3; i < capture.bgraPixels.size(); i += 4)
        if (capture.bgraPixels[i] >= 128u)
            ++opaquePixels;
    return opaquePixels >= pixels / 4u;
}
[[nodiscard]] bool WaitForContextMenuPopupBitmapCapture(HWND popupHwnd,
                                                        WindowHostBitmapCapture& outCapture,
                                                        std::chrono::milliseconds timeout = std::chrono::milliseconds(1200))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        // The hidden measurement HWND already has a bitmap. Inspect only the shown, sized popup.
        // Capture dimensions are physical pixels; the driver thread's client rectangle can be DPI-virtualized.
        if (IsWindowVisible(popupHwnd) && DebugCaptureContextMenuPopupBitmap(popupHwnd, outCapture) && outCapture.widthPx > 1u && outCapture.heightPx > 1u &&
            HasPaintedPopupContent(outCapture))
        {
            return true;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return false;
}

void CopyCaptureInto(WindowHostBitmapCapture& destination, const WindowHostBitmapCapture& source, UINT leftPx, UINT topPx)
{
    Require(leftPx <= destination.widthPx && topPx <= destination.heightPx, "gallery popup capture destination origin is in range");
    const UINT copyWidthPx  = std::min(source.widthPx, destination.widthPx - leftPx);
    const UINT copyHeightPx = std::min(source.heightPx, destination.heightPx - topPx);
    for (UINT row = 0u; row < copyHeightPx; ++row)
    {
        const size_t sourceOffset      = static_cast<size_t>(row) * static_cast<size_t>(source.widthPx) * 4u;
        const size_t destinationOffset = ((static_cast<size_t>(topPx + row) * static_cast<size_t>(destination.widthPx)) + static_cast<size_t>(leftPx)) * 4u;
        std::copy_n(source.bgraPixels.data() + sourceOffset, static_cast<size_t>(copyWidthPx) * 4u, destination.bgraPixels.data() + destinationOffset);
    }
}

[[nodiscard]] WindowHostBitmapCapture CombinePopupCapturesHorizontally(const WindowHostBitmapCapture& rootCapture,
                                                                       const WindowHostBitmapCapture& submenuCapture)
{
    Require(rootCapture.widthPx > 0u && rootCapture.heightPx > 0u, "gallery root menu capture is non-empty before combining");
    Require(submenuCapture.widthPx > 0u && submenuCapture.heightPx > 0u, "gallery submenu capture is non-empty before combining");

    constexpr UINT kOverlapPx = 10u;
    WindowHostBitmapCapture combined;
    combined.widthPx  = rootCapture.widthPx + submenuCapture.widthPx - std::min(kOverlapPx, rootCapture.widthPx);
    combined.heightPx = std::max(rootCapture.heightPx, submenuCapture.heightPx);
    combined.bgraPixels.assign(static_cast<size_t>(combined.widthPx) * static_cast<size_t>(combined.heightPx) * 4u, 0u);

    CopyCaptureInto(combined, rootCapture, 0u, 0u);
    CopyCaptureInto(combined, submenuCapture, rootCapture.widthPx - std::min(kOverlapPx, rootCapture.widthPx), 0u);
    return combined;
}

[[nodiscard]] WindowHostBitmapCapture CaptureMenuPopupBitmapForGallery(const ThemePalette& theme,
                                                                       const std::vector<MenuFlyoutItem>& items,
                                                                       std::wstring_view firstItemText,
                                                                       std::optional<size_t> submenuItemIndex = std::nullopt,
                                                                       std::wstring_view submenuFirstItemText = {})
{
    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 420, 280, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    WindowHostBitmapCapture capture;
    std::string driverFailure;
    std::thread driver([&]
    {
        const HWND rootPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), firstItemText);
        if (! rootPopupHwnd)
        {
            driverFailure = "gallery menu popup window appears";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        if (submenuItemIndex.has_value())
        {
            ContextMenuPopupDebugState rootState{};
            if (! WaitForContextMenuPopupState(rootPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
                return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f;
            }, rootState))
            {
                driverFailure = "gallery submenu root popup exposes geometry";
                return;
            }

            for (size_t index = 0u; index <= submenuItemIndex.value(); ++index)
            {
                PostMessageW(rootPopupHwnd, WM_KEYDOWN, VK_DOWN, 0);
            }
            if (! WaitForContextMenuPopupState(rootPopupHwnd, [&](const ContextMenuPopupDebugState& state) noexcept {
                return state.keyboardIndex.has_value() && state.keyboardIndex.value() == submenuItemIndex.value();
            }, rootState))
            {
                driverFailure = "gallery submenu root popup focuses requested item";
                return;
            }

            PostMessageW(rootPopupHwnd, WM_KEYDOWN, VK_RIGHT, 0);

            const HWND submenuHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), submenuFirstItemText);
            if (! submenuHwnd)
            {
                driverFailure = "gallery submenu popup window appears";
                return;
            }

            WindowHostBitmapCapture rootCapture;
            WindowHostBitmapCapture submenuCapture;
            if (! WaitForContextMenuPopupBitmapCapture(rootPopupHwnd, rootCapture) || ! WaitForContextMenuPopupBitmapCapture(submenuHwnd, submenuCapture))
            {
                driverFailure = "gallery submenu bitmap captures succeed";
                return;
            }

            capture = CombinePopupCapturesHorizontally(rootCapture, submenuCapture);
            return;
        }

        if (! WaitForContextMenuPopupBitmapCapture(rootPopupHwnd, capture))
        {
            driverFailure = "gallery menu popup bitmap capture succeeds";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "gallery menu capture closes without invoking a command");
    Require(capture.widthPx > 0u && capture.heightPx > 0u && ! capture.bgraPixels.empty(), "gallery menu popup capture is non-empty");
    return capture;
}

[[nodiscard]] std::vector<MenuFlyoutItem> BuildButtonDropDownMenuItems()
{
    return {
        MenuFlyoutItem{.text = L"Open", .acceleratorText = L"Enter", .iconGlyph = L"\xE8E5", .commandId = 4101},
        MenuFlyoutItem{.kind = MenuItemKind::Toggle, .text = L"Show hidden files", .iconGlyph = L"\xE8A5", .checked = true, .commandId = 4102},
        MenuFlyoutItem{.kind = MenuItemKind::Separator},
        MenuFlyoutItem{.text = L"Unavailable action", .iconGlyph = L"\xE711", .enabled = false, .commandId = 4103},
    };
}

[[nodiscard]] std::vector<MenuFlyoutItem> BuildButtonSplitMenuItems()
{
    return {
        MenuFlyoutItem{.text = L"Run normally", .acceleratorText = L"Ctrl+R", .iconGlyph = L"\xE768", .commandId = 4201},
        MenuFlyoutItem{.text = L"Run as administrator", .iconGlyph = L"\xE83D", .commandId = 4202},
        MenuFlyoutItem{.kind = MenuItemKind::Toggle, .text = L"Remember choice", .checked = true, .commandId = 4203},
    };
}

[[nodiscard]] std::vector<MenuFlyoutItem> BuildStatefulSubmenuItems()
{
    return {
        MenuFlyoutItem{.text            = L"Open With",
                       .acceleratorText = L"Ctrl+Enter",
                       .iconGlyph       = L"\xE8A7",
                       .commandId       = 4301,
                       .children =
                           {
                               MenuFlyoutItem{.text = L"Internal Viewer", .iconGlyph = L"\xE890", .commandId = 4311},
                               MenuFlyoutItem{.kind = MenuItemKind::Radio, .text = L"Text Editor", .iconGlyph = L"\xE70F", .checked = true, .commandId = 4312},
                               MenuFlyoutItem{.text = L"External Tool", .iconGlyph = L"\xE8B7", .enabled = false, .commandId = 4313},
                           }},
        MenuFlyoutItem{.kind = MenuItemKind::Toggle, .text = L"Preview pane", .iconGlyph = L"\xE8A5", .checked = true, .commandId = 4302},
        MenuFlyoutItem{.kind = MenuItemKind::Radio, .text = L"Sort by name", .iconGlyph = L"\xE8CB", .checked = true, .commandId = 4303},
        MenuFlyoutItem{.kind = MenuItemKind::Separator},
        MenuFlyoutItem{.text = L"Disabled command", .iconGlyph = L"\xE711", .enabled = false, .commandId = 4304},
    };
}

[[nodiscard]] WindowHostBitmapCapture CaptureComboBoxOpenBitmapForGallery(const ThemePalette& theme, ComboBoxVariant variant, bool editable)
{
    AttachedHostWindow window;
    ResizeClientArea(window, DipsToPixelsCeil(window.Host(), 190.0f), DipsToPixelsCeil(window.Host(), 174.0f));
    window.Host().SetTheme(theme);

    auto root   = std::make_unique<Panel>();
    auto* combo = root->AddChild<ComboBox>();
    combo->SetItems({
        ComboBox::Item{L"system", L"System"},
        ComboBox::Item{L"light", L"Light"},
        ComboBox::Item{L"dark", L"Dark"},
        ComboBox::Item{L"rainbow", L"Rainbow"},
    });
    combo->SetSelectedIndex(1u);
    combo->SetVariant(variant);
    combo->SetMaxVisibleItems(4u);
    if (variant == ComboBoxVariant::Modern)
        combo->SetMinimumPopupItemHeight(48.0f);
    combo->SetEditable(editable);
    if (editable)
    {
        combo->SetText({});
        combo->SetPlaceholder(L"Type to filter");
    }
    combo->SetBounds(D2D1::RectF(1.0f, 1.0f, 189.0f, 33.0f));
    window.Host().SetRoot(std::move(root));

    ShowWindow(window.Hwnd(), SW_SHOWNOACTIVATE);
    window.PumpMessages();

    const D2D1_RECT_F bounds = combo->GetBounds();
    Require(combo->OnMouseDown(window.Host(), D2D1::Point2F(bounds.right - 8.0f, (bounds.top + bounds.bottom) * 0.5f), false, 0u),
            "gallery combo opens for bitmap capture");
    Require(combo->DebugIsPopupOpen(), "gallery combo popup is open before bitmap capture");

    RedrawWindow(window.Hwnd(), nullptr, nullptr, RDW_INVALIDATE | RDW_ALLCHILDREN | RDW_UPDATENOW);
    window.PumpMessages();

    WindowHostBitmapCapture capture;
    Require(window.Host().DebugCaptureBitmap(capture), "gallery combo open bitmap capture succeeds");
    Require(capture.widthPx > 0u && capture.heightPx > 0u && ! capture.bgraPixels.empty(), "gallery combo open capture is non-empty");
    return capture;
}

struct GalleryMenuCaptures
{
    WindowHostBitmapCapture buttonDropDown;
    WindowHostBitmapCapture buttonSplit;
    WindowHostBitmapCapture menuSubmenu;
    WindowHostBitmapCapture menuDescriptions;
    WindowHostBitmapCapture comboWindowOpen;
    WindowHostBitmapCapture comboModernOpen;
    WindowHostBitmapCapture comboEditOpen;
};

[[nodiscard]] GalleryMenuCaptures CaptureGalleryMenus(const ThemePalette& theme)
{
    GalleryMenuCaptures captures;
    captures.buttonDropDown = CaptureMenuPopupBitmapForGallery(theme, BuildButtonDropDownMenuItems(), L"Open");
    captures.buttonSplit    = CaptureMenuPopupBitmapForGallery(theme, BuildButtonSplitMenuItems(), L"Run normally");
    captures.menuSubmenu    = CaptureMenuPopupBitmapForGallery(theme, BuildStatefulSubmenuItems(), L"Open With", 0u, L"Internal Viewer");
    const std::wstring leaf = L"Sélection définitive pour impression et archivage — photographies familiales";
    const std::vector<MenuFlyoutItem> describedItems{
        {.kind          = MenuItemKind::Radio,
         .text          = leaf,
         .checked       = true,
         .commandId     = 801,
         .secondaryText = L"D:\\Sauvegardes\\Archives photographiques personnelles\\Exposition annuelle de la médiathèque"},
        {.kind          = MenuItemKind::Radio,
         .text          = leaf,
         .commandId     = 802,
         .secondaryText = L"D:\\Sauvegardes\\Archives photographiques personnelles\\Collection permanente du musée"}};
    captures.menuDescriptions = CaptureMenuPopupBitmapForGallery(theme, describedItems, leaf);
    captures.comboWindowOpen  = CaptureComboBoxOpenBitmapForGallery(theme, ComboBoxVariant::Window, false);
    captures.comboModernOpen  = CaptureComboBoxOpenBitmapForGallery(theme, ComboBoxVariant::Modern, false);
    captures.comboEditOpen    = CaptureComboBoxOpenBitmapForGallery(theme, ComboBoxVariant::Window, true);
    return captures;
}

class GalleryBitmapPreview final : public Control
{
public:
    explicit GalleryBitmapPreview(WindowHostBitmapCapture capture) : _capture(std::move(capture))
    {
    }

    void Paint(WindowHost& host) const override
    {
        ID2D1Bitmap1* const bitmap   = EnsureBitmap(host);
        ID2D1DeviceContext* const dc = host.GetDeviceContext();
        if (! bitmap || ! dc)
        {
            return;
        }

        const D2D1_RECT_F bounds      = GetBounds();
        const float boundsWidth       = std::max(1.0f, bounds.right - bounds.left);
        const float boundsHeight      = std::max(1.0f, bounds.bottom - bounds.top);
        const D2D1_SIZE_F naturalSize = bitmap->GetSize();
        const float naturalWidth      = std::max(1.0f, naturalSize.width);
        const float naturalHeight     = std::max(1.0f, naturalSize.height);
        const float scale             = std::min({1.0f, boundsWidth / naturalWidth, boundsHeight / naturalHeight});
        const float drawWidth         = naturalWidth * scale;
        const float drawHeight        = naturalHeight * scale;
        const float left              = bounds.left + ((boundsWidth - drawWidth) * 0.5f);
        const D2D1_RECT_F destination = D2D1::RectF(left, bounds.top, left + drawWidth, bounds.top + drawHeight);
        dc->DrawBitmap(bitmap, destination, 1.0f, D2D1_INTERPOLATION_MODE_LINEAR);
    }

private:
    [[nodiscard]] ID2D1Bitmap1* EnsureBitmap(WindowHost& host) const noexcept
    {
        if (_capture.widthPx == 0u || _capture.heightPx == 0u || _capture.bgraPixels.empty())
        {
            return nullptr;
        }

        ID2D1DeviceContext* const dc = host.GetDeviceContext();
        if (! dc)
        {
            return nullptr;
        }

        wil::com_ptr<ID2D1Device> device;
        dc->GetDevice(device.put());
        if (! device)
        {
            return nullptr;
        }

        if (_bitmap && _device && _device.get() == device.get())
        {
            return _bitmap.get();
        }

        const D2D1_BITMAP_PROPERTIES1 bitmapProperties = D2D1::BitmapProperties1(
            D2D1_BITMAP_OPTIONS_NONE, D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED), host.GetDpi(), host.GetDpi());
        wil::com_ptr<ID2D1Bitmap1> bitmap;
        const UINT32 pitch = static_cast<UINT32>(_capture.widthPx * 4u);
        const HRESULT hr =
            dc->CreateBitmap(D2D1::SizeU(_capture.widthPx, _capture.heightPx), _capture.bgraPixels.data(), pitch, &bitmapProperties, bitmap.put());
        if (FAILED(hr) || ! bitmap)
        {
            return nullptr;
        }

        _device = std::move(device);
        _bitmap = std::move(bitmap);
        return _bitmap.get();
    }

    WindowHostBitmapCapture _capture;
    mutable wil::com_ptr<ID2D1Device> _device;
    mutable wil::com_ptr<ID2D1Bitmap1> _bitmap;
};

struct Tile
{
    D2D1_RECT_F outer   = D2D1::RectF();
    D2D1_RECT_F content = D2D1::RectF();
};

struct GalleryFlow
{
    float y         = 80.0f;
    size_t column   = 0u;
    float rowHeight = 0.0f;

    [[nodiscard]] Tile Next(Panel& root, std::wstring label, size_t span = 1u, float heightDip = 96.0f)
    {
        const size_t clampedSpan = std::clamp(span, size_t{1u}, kColumnCount);
        if (column + clampedSpan > kColumnCount)
        {
            NewRow();
        }

        const float left        = kMarginDip + (static_cast<float>(column) * (kTileWidthDip + kGapDip));
        const float width       = (kTileWidthDip * static_cast<float>(clampedSpan)) + (kGapDip * static_cast<float>(clampedSpan - 1u));
        const D2D1_RECT_F outer = D2D1::RectF(left, y, left + width, y + heightDip);
        auto* frame             = root.AddChild<CardPanel>();
        frame->SetBounds(outer);

        auto* caption = root.AddChild<Label>(std::move(label));
        caption->SetFontRole(FontRole::Small);
        caption->SetAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
        caption->SetMultiline(true);
        caption->SetBounds(D2D1::RectF(outer.left + 8.0f, outer.bottom - 30.0f, outer.right - 8.0f, outer.bottom - 6.0f));

        column += clampedSpan;
        rowHeight = std::max(rowHeight, heightDip);
        if (column >= kColumnCount)
        {
            NewRow();
        }

        return Tile{.outer = outer, .content = D2D1::RectF(outer.left + 12.0f, outer.top + 10.0f, outer.right - 12.0f, outer.bottom - 36.0f)};
    }

    void NewRow() noexcept
    {
        if (rowHeight > 0.0f)
        {
            y += rowHeight + kGapDip;
        }
        column    = 0u;
        rowHeight = 0.0f;
    }
};

[[nodiscard]] D2D1_RECT_F CenterIn(const D2D1_RECT_F& bounds, float widthDip, float heightDip) noexcept
{
    const float resolvedWidthDip = std::min(widthDip, std::max(1.0f, bounds.right - bounds.left));
    const float x                = bounds.left + (((bounds.right - bounds.left) - resolvedWidthDip) * 0.5f);
    const float y                = bounds.top + (((bounds.bottom - bounds.top) - heightDip) * 0.5f);
    return D2D1::RectF(x, y, x + resolvedWidthDip, y + heightDip);
}

class GalleryTreeModel final : public ITreeModel
{
public:
    GalleryTreeModel()
    {
        _items = {
            TreeItemData{.id = 1u, .text = L"Controls", .iconText = L"C", .hasChildren = true, .expanded = true},
            TreeItemData{.id = 2u, .parentId = 1u, .text = L"Buttons", .iconText = L"B", .badgeText = L"6", .depth = 1u},
            TreeItemData{.id = 3u, .parentId = 1u, .text = L"Inputs", .iconText = L"I", .badgeText = L"3", .depth = 1u, .badgeTone = AdornmentTone::Info},
            TreeItemData{.id = 4u, .text = L"Themes", .iconText = L"T", .badgeText = L"On", .badgeTone = AdornmentTone::Warning},
        };
    }

    [[nodiscard]] size_t GetVisibleItemCount() const noexcept override
    {
        return _items.size();
    }

    void GetVisibleItem(size_t visibleIndex, TreeItemData& outItem) const override
    {
        outItem = _items.at(visibleIndex);
    }

private:
    std::vector<TreeItemData> _items;
};

class GalleryGridModel final : public IGridModel
{
public:
    [[nodiscard]] size_t GetRowCount() const noexcept override
    {
        return 6u;
    }

    [[nodiscard]] size_t GetColumnCount() const noexcept override
    {
        return 3u;
    }

    [[nodiscard]] GridColumnDesc GetColumn(size_t columnIndex) const override
    {
        switch (columnIndex)
        {
            case 0u: return GridColumnDesc{.id = L"kind", .title = L"Kind", .widthDip = 120.0f, .minWidthDip = 90.0f, .multiline = false};
            case 1u: return GridColumnDesc{.id = L"value", .title = L"Value", .widthDip = 170.0f, .minWidthDip = 120.0f, .multiline = false};
            default: return GridColumnDesc{.id = L"status", .title = L"Status", .widthDip = 120.0f, .minWidthDip = 90.0f, .multiline = false};
        }
    }

    void GetCellData(size_t rowIndex, size_t columnIndex, GridCellData& outCell) const override
    {
        if (columnIndex == 0u)
        {
            constexpr std::wstring_view labels[] = {L"Text", L"Checkbox", L"IconText", L"ColorSwatch", L"Spinner", L"Marquee"};
            outCell.kind                         = GridCellKind::Text;
            outCell.text                         = std::wstring(labels[std::min(rowIndex, std::size(labels) - 1u)]);
            return;
        }

        if (columnIndex == 2u)
        {
            outCell.kind      = GridCellKind::Text;
            outCell.text      = (rowIndex % 2u) == 0u ? L"Ready" : L"Live";
            outCell.badgeText = (rowIndex % 2u) == 0u ? L"Info" : L"Warn";
            outCell.badgeTone = (rowIndex % 2u) == 0u ? AdornmentTone::Info : AdornmentTone::Warning;
            return;
        }

        switch (rowIndex)
        {
            case 1u:
                outCell.kind    = GridCellKind::Checkbox;
                outCell.text    = L"Enabled";
                outCell.checked = true;
                return;
            case 2u:
                outCell.kind      = GridCellKind::IconText;
                outCell.iconText  = L"\xE946";
                outCell.text      = L"Plugin";
                outCell.badgeText = L"Beta";
                outCell.badgeTone = AdornmentTone::Accent;
                return;
            case 3u:
                outCell.kind           = GridCellKind::ColorSwatch;
                outCell.hasSwatchValue = true;
                outCell.swatchArgb     = 0xFF33AA55u;
                return;
            case 4u:
                outCell.kind = GridCellKind::Spinner;
                outCell.text = L"Loading";
                return;
            case 5u:
                outCell.kind     = GridCellKind::Marquee;
                outCell.progress = 0.64f;
                return;
            default:
                outCell.kind      = GridCellKind::Text;
                outCell.text      = L"Une description française suffisamment longue pour montrer le contenu omis";
                outCell.multiline = true;
                return;
        }
    }

    [[nodiscard]] GridRowStyle GetRowStyle(size_t rowIndex) const override
    {
        if (rowIndex == 2u)
        {
            return GridRowStyle{.tone = GridRowTone::Info, .rainbowSeed = L"grid-info"};
        }
        if (rowIndex == 3u)
        {
            return GridRowStyle{.tone = GridRowTone::Warning, .rainbowSeed = L"grid-warning"};
        }
        if (rowIndex == 4u)
        {
            return GridRowStyle{.tone = GridRowTone::Error, .rainbowSeed = L"grid-error"};
        }
        return GridRowStyle{.rainbowSeed = L"grid-row-" + std::to_wstring(rowIndex)};
    }

    [[nodiscard]] uint64_t GetStableRowId(size_t rowIndex) const noexcept override
    {
        return static_cast<uint64_t>(rowIndex + 1u);
    }

    [[nodiscard]] std::optional<size_t> FindRowByStableId(uint64_t rowId) const noexcept override
    {
        return rowId >= 1u && rowId <= GetRowCount() ? std::optional<size_t>(static_cast<size_t>(rowId - 1u)) : std::nullopt;
    }
};

struct GalleryScene
{
    GalleryScene()                               = default;
    GalleryScene(const GalleryScene&)            = delete;
    GalleryScene& operator=(const GalleryScene&) = delete;
    GalleryScene(GalleryScene&&)                 = default;
    GalleryScene& operator=(GalleryScene&&)      = default;
    ~GalleryScene()                              = default;

    std::unique_ptr<GalleryTreeModel> treeModel;
    std::unique_ptr<GalleryTreeModel> multiSelectTreeModel;
    std::unique_ptr<GalleryGridModel> gridModel;
    std::unique_ptr<Panel> root;
    ExposedButton* selectorHoverButton = nullptr;
    ExposedButton* hoverButton         = nullptr;
    ExposedButton* pressedButton       = nullptr;
    Slider* hoverSlider                = nullptr;
    Slider* pressedSlider              = nullptr;
    Slider* touchSlider                = nullptr;
    Control* focusedControl            = nullptr;
    Grid* grid                         = nullptr;
    std::optional<D2D1_POINT_2F> tooltipOrigin;
    float heightDip = 1.0f;
};

void AddSectionHeader(GalleryScene& scene, const GalleryTheme& theme)
{
    auto* title = scene.root->AddChild<Label>(L"DxUi controls and variants - " + theme.name);
    title->SetFontRole(FontRole::Subtitle);
    title->SetBounds(D2D1::RectF(kMarginDip, 18.0f, 760.0f, 48.0f));

    constexpr std::wstring_view swatchLabels[] = {L"Accent", L"Surface", L"Selection", L"Border"};
    const uint32_t colors[]                    = {
        PackArgbForGallery(theme.palette.accent),
        PackArgbForGallery(theme.palette.surfaceBackground),
        PackArgbForGallery(theme.palette.selectionFill),
        PackArgbForGallery(theme.palette.border),
    };

    float x = 1010.0f;
    for (size_t index = 0u; index < std::size(swatchLabels); ++index)
    {
        auto* swatch = scene.root->AddChild<ColorSwatch>(colors[index]);
        swatch->SetBounds(D2D1::RectF(x, 20.0f, x + 28.0f, 48.0f));
        auto* label = scene.root->AddChild<Label>(std::wstring(swatchLabels[index]));
        label->SetFontRole(FontRole::Small);
        label->SetBounds(D2D1::RectF(x + 34.0f, 20.0f, x + 120.0f, 48.0f));
        x += 140.0f;
    }
}

void AddButtonTile(GalleryScene& scene, GalleryFlow& flow, std::wstring label, std::wstring text, ButtonVariant variant, bool primary = false)
{
    const Tile tile = flow.Next(*scene.root, std::move(label));
    auto* button    = scene.root->AddChild<ExposedButton>(std::move(text));
    button->SetVariant(variant);
    button->SetPrimary(primary);
    button->SetBounds(CenterIn(tile.content, variant == ButtonVariant::IconOnly ? 36.0f : 132.0f, 32.0f));
}

void AddOpenButtonTile(
    GalleryScene& scene, GalleryFlow& flow, std::wstring label, std::wstring text, ButtonVariant variant, WindowHostBitmapCapture popupCapture)
{
    const Tile tile = flow.Next(*scene.root, std::move(label), 1u, 174.0f);
    auto* button    = scene.root->AddChild<ExposedButton>(std::move(text));
    button->SetVariant(variant);
    button->SetBounds(D2D1::RectF(tile.content.left + 8.0f, tile.content.top + 2.0f, tile.content.right - 8.0f, tile.content.top + 34.0f));
    button->SetPressed(true);

    auto* preview = scene.root->AddChild<GalleryBitmapPreview>(std::move(popupCapture));
    preview->SetBounds(D2D1::RectF(tile.content.left, tile.content.top + 40.0f, tile.content.right, tile.content.bottom - 2.0f));
}

void AddComboOpenTile(GalleryScene& scene, GalleryFlow& flow, std::wstring label, WindowHostBitmapCapture popupCapture)
{
    const Tile tile = flow.Next(*scene.root, std::move(label), 1u, 220.0f);
    auto* preview   = scene.root->AddChild<GalleryBitmapPreview>(std::move(popupCapture));
    preview->SetBounds(D2D1::RectF(tile.content.left, tile.content.top, tile.content.right, tile.content.bottom));
}

void AddComboItems(ComboBox& combo)
{
    combo.SetItems({
        ComboBox::Item{L"system", L"System"},
        ComboBox::Item{L"light", L"Light"},
        ComboBox::Item{L"dark", L"Dark"},
        ComboBox::Item{L"rainbow", L"Rainbow"},
    });
    combo.SetSelectedIndex(1u);
}

[[nodiscard]] GalleryScene BuildGalleryScene(const GalleryTheme& theme, GalleryMenuCaptures menuCaptures)
{
    GalleryScene scene;
    scene.root = std::make_unique<Panel>();
    AddSectionHeader(scene, theme);

    GalleryFlow flow;

    {
        const Tile tile = flow.Next(*scene.root, L"Label / Body");
        auto* label     = scene.root->AddChild<Label>(L"Readable body text");
        label->SetBounds(CenterIn(tile.content, 220.0f, 28.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"CardPanel / Inline");
        auto* card      = scene.root->AddChild<CardPanel>();
        card->SetBounds(CenterIn(tile.content, 220.0f, 50.0f));
        auto* label = scene.root->AddChild<Label>(L"Card content");
        label->SetAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
        label->SetBounds(CenterIn(tile.content, 200.0f, 34.0f));
    }

    AddButtonTile(scene, flow, L"Button / Standard", L"Standard", ButtonVariant::Standard);
    AddButtonTile(scene, flow, L"Button / Primary", L"Primary", ButtonVariant::Standard, true);
    {
        const Tile tile = flow.Next(*scene.root, L"Button / French multiline", 1u, 128.0f);
        auto* button    = scene.root->AddChild<Button>(L"Conserver les deux versions");
        button->SetMultiline(true);
        button->SetBounds(CenterIn(tile.content, 164.0f, 72.0f));
    }
    AddButtonTile(scene, flow, L"Button / DropDown", L"Options", ButtonVariant::DropDown);
    AddButtonTile(scene, flow, L"Button / Selector", L"Parallel", ButtonVariant::Selector);
    {
        const Tile tile           = flow.Next(*scene.root, L"Button / Selector hover");
        scene.selectorHoverButton = scene.root->AddChild<ExposedButton>(L"Parallel");
        scene.selectorHoverButton->SetVariant(ButtonVariant::Selector);
        scene.selectorHoverButton->SetBounds(CenterIn(tile.content, 132.0f, 32.0f));
    }
    AddButtonTile(scene, flow, L"Button / Split", L"Run", ButtonVariant::Split);
    AddOpenButtonTile(scene, flow, L"Button / DropDown open", L"Options", ButtonVariant::DropDown, std::move(menuCaptures.buttonDropDown));
    AddOpenButtonTile(scene, flow, L"Button / Split open", L"Run", ButtonVariant::Split, std::move(menuCaptures.buttonSplit));
    AddButtonTile(scene, flow, L"Button / Hyperlink", L"Learn more", ButtonVariant::Hyperlink);
    AddButtonTile(scene, flow, L"Button / IconOnly", L"\xE72C", ButtonVariant::IconOnly);
    AddButtonTile(scene, flow, L"Button / Repeat", L"Repeat", ButtonVariant::Repeat);

    {
        const Tile tile   = flow.Next(*scene.root, L"Button / Hover");
        scene.hoverButton = scene.root->AddChild<ExposedButton>(L"Hover");
        scene.hoverButton->SetBounds(CenterIn(tile.content, 132.0f, 32.0f));
    }
    {
        const Tile tile     = flow.Next(*scene.root, L"Button / Pressed");
        scene.pressedButton = scene.root->AddChild<ExposedButton>(L"Pressed");
        scene.pressedButton->SetBounds(CenterIn(tile.content, 132.0f, 32.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Button / Disabled");
        auto* button    = scene.root->AddChild<Button>(L"Disabled");
        button->SetEnabled(false);
        button->SetBounds(CenterIn(tile.content, 132.0f, 32.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Toggle / Off");
        auto* toggle    = scene.root->AddChild<Toggle>(L"Notifications");
        toggle->SetBounds(CenterIn(tile.content, 250.0f, 36.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Toggle / On");
        auto* toggle    = scene.root->AddChild<Toggle>(L"Sync");
        toggle->SetChecked(true);
        toggle->SetBounds(CenterIn(tile.content, 250.0f, 36.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Toggle / Disabled");
        auto* toggle    = scene.root->AddChild<Toggle>(L"Offline");
        toggle->SetEnabled(false);
        toggle->SetBounds(CenterIn(tile.content, 250.0f, 36.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Checkbox / Unchecked");
        auto* checkbox  = scene.root->AddChild<Checkbox>(L"Include hidden");
        checkbox->SetBounds(CenterIn(tile.content, 230.0f, 32.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Checkbox / Checked");
        auto* checkbox  = scene.root->AddChild<Checkbox>(L"Enable preview");
        checkbox->SetChecked(true);
        checkbox->SetBounds(CenterIn(tile.content, 230.0f, 32.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Checkbox / Indeterminate");
        auto* checkbox  = scene.root->AddChild<Checkbox>(L"Mixed plugins");
        checkbox->SetIndeterminate(true);
        checkbox->SetBounds(CenterIn(tile.content, 230.0f, 32.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Checkbox / Wrapped French");
        auto* checkbox  = scene.root->AddChild<Checkbox>(L"Appliquer ce choix aux éléments similaires restants");
        checkbox->SetMultiline(true);
        checkbox->SetChecked(true);
        checkbox->SetBounds(CenterIn(tile.content, 250.0f, 72.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"RadioButton / Selected");
        auto* radio     = scene.root->AddChild<RadioButton>(L"Daily");
        radio->SetChecked(true);
        radio->SetBounds(CenterIn(tile.content, 220.0f, 32.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"RadioButtons / Group");
        auto* group     = scene.root->AddChild<RadioButtons>();
        group->SetHeader(L"Update cadence");
        group->SetBounds(tile.content);
        auto* daily = group->AddItem(L"Daily");
        daily->SetBounds(D2D1::RectF(tile.content.left + 8.0f, tile.content.top + 24.0f, tile.content.left + 95.0f, tile.content.top + 56.0f));
        auto* weekly = group->AddItem(L"Weekly");
        weekly->SetBounds(D2D1::RectF(tile.content.left + 96.0f, tile.content.top + 24.0f, tile.content.right - 8.0f, tile.content.top + 56.0f));
        group->SetSelectedIndex(1);
    }
    {
        const Tile tile = flow.Next(*scene.root, L"ProgressBar / Determinate");
        auto* progress  = scene.root->AddChild<ProgressBar>();
        progress->SetValue(62.0);
        progress->SetBounds(CenterIn(tile.content, 260.0f, 20.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"ProgressBar / Indeterminate");
        auto* progress  = scene.root->AddChild<ProgressBar>();
        progress->SetIndeterminate(true);
        progress->SetBounds(CenterIn(tile.content, 260.0f, 20.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"PageIndicator / Pages");
        auto* indicator = scene.root->AddChild<PageIndicator>();
        indicator->SetPageCount(5);
        indicator->SetSelectedIndex(2);
        indicator->SetBounds(CenterIn(tile.content, 180.0f, PageIndicator::kStripHeightDip));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Splitter / Vertical");
        auto* splitter  = scene.root->AddChild<Splitter>();
        splitter->SetBounds(CenterIn(tile.content, 260.0f, 48.0f));
        splitter->SetMinimumFirstPane(40.0f);
        splitter->SetMinimumSecondPane(40.0f);
        splitter->SetPosition(150.0f);
        auto* first = scene.root->AddChild<Label>(L"Canvas");
        first->SetFontRole(FontRole::Small);
        first->SetAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
        first->SetBounds(splitter->GetFirstPaneBounds());
        auto* second = scene.root->AddChild<Label>(L"Layers");
        second->SetFontRole(FontRole::Small);
        second->SetAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
        second->SetBounds(splitter->GetSecondPaneBounds());
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Splitter / Horizontal");
        auto* splitter  = scene.root->AddChild<Splitter>();
        splitter->SetOrientation(SplitterOrientation::Horizontal);
        splitter->SetBounds(CenterIn(tile.content, 260.0f, 48.0f));
        splitter->SetMinimumFirstPane(8.0f);
        splitter->SetMinimumSecondPane(8.0f);
        splitter->SetPosition(21.0f);
    }
    {
        const Tile tile = flow.Next(*scene.root, L"NumericStepper / Inspector");
        auto* stepper   = scene.root->AddChild<NumericStepper>();
        stepper->SetLabel(L"W", 20.0f);
        stepper->SetUnit(L"px", 24.0f);
        stepper->SetMinimum(0.0);
        stepper->SetMaximum(4096.0);
        stepper->SetDecimals(1);
        stepper->SetValue(1024.5);
        stepper->SetBounds(CenterIn(tile.content, 220.0f, NumericStepper::kDefaultHeightDip));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"ColorPicker / Sheet", 2u, 300.0f);
        auto* picker    = scene.root->AddChild<ColorPicker>();
        picker->SetColor(0xFF3A7BD5u);
        picker->SetBounds(CenterIn(tile.content, ColorPicker::kDefaultWidthDip, ColorPicker::kDefaultHeightDip));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Slider / Horizontal");
        auto* slider    = scene.root->AddChild<Slider>();
        slider->SetValue(68.0);
        slider->SetTickMarks({0.0, 25.0, 50.0, 75.0, 100.0});
        slider->SetBounds(CenterIn(tile.content, 270.0f, 48.0f));
    }
    {
        const Tile tile   = flow.Next(*scene.root, L"Slider / Hover");
        scene.hoverSlider = scene.root->AddChild<Slider>();
        scene.hoverSlider->SetValue(62.0);
        scene.hoverSlider->SetBounds(CenterIn(tile.content, 270.0f, 48.0f));
    }
    {
        const Tile tile     = flow.Next(*scene.root, L"Slider / Pressed");
        scene.pressedSlider = scene.root->AddChild<Slider>();
        scene.pressedSlider->SetValue(54.0);
        scene.pressedSlider->SetBounds(CenterIn(tile.content, 270.0f, 48.0f));
    }
    {
        const Tile tile   = flow.Next(*scene.root, L"Slider / Touch pressed");
        scene.touchSlider = scene.root->AddChild<Slider>();
        scene.touchSlider->SetValue(40.0);
        scene.touchSlider->SetBounds(CenterIn(tile.content, 270.0f, 48.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Slider / Vertical");
        auto* slider    = scene.root->AddChild<Slider>();
        slider->SetOrientation(SliderOrientation::Vertical);
        slider->SetValue(74.0);
        slider->SetBounds(CenterIn(tile.content, 32.0f, 64.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Toolbar / Icon buttons");
        auto* toolbar   = scene.root->AddChild<Toolbar>();
        toolbar->SetBounds(CenterIn(tile.content, 220.0f, 40.0f));
        const auto bar = toolbar->GetBounds();
        toolbar->AddButton(L"Refresh", L"\xE72C")->SetBounds(D2D1::RectF(bar.left + 8, bar.top + 4, bar.left + 44, bar.bottom - 4));
        toolbar->AddButton(L"Copy", L"\xE8C8")->SetBounds(D2D1::RectF(bar.left + 48, bar.top + 4, bar.left + 84, bar.bottom - 4));
        auto* pin = toolbar->AddToggleButton(L"Pin", L"\xE718");
        pin->SetChecked(true);
        pin->SetBounds(D2D1::RectF(bar.left + 104, bar.top + 4, bar.left + 148, bar.bottom - 4));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"MenuBar / Standard");
        auto* menuBar   = scene.root->AddChild<MenuBar>();
        menuBar->SetBounds(CenterIn(tile.content, 300.0f, 32.0f));
        menuBar->SetItems({
            MenuBarItem{.text = L"File", .mnemonic = L'F'},
            MenuBarItem{.text = L"Edit", .mnemonic = L'E'},
            MenuBarItem{.text = L"View", .mnemonic = L'V'},
        });
        menuBar->SetSelectedIndex(1u);
    }
    {
        const Tile tile = flow.Next(*scene.root, L"TabControl / Selected", 2u, 136.0f);
        auto* tabs      = scene.root->AddChild<TabControl>();
        tabs->SetBounds(tile.content);
        tabs->AddTab<Label>(L"Overview", L"Overview page");
        tabs->AddTab<Label>(L"Details", L"Details page");
        tabs->AddTab<Label>(L"Activity", L"Activity page");
        tabs->AddTab<Label>(L"Diagnostics", L"Diagnostics page");
        tabs->SetTabClosable(3u, true);
        tabs->SetSelectedIndex(1u);
    }
    {
        const Tile tile = flow.Next(*scene.root, L"ColorSwatch / Accent");
        auto* swatch    = scene.root->AddChild<ColorSwatch>(PackArgbForGallery(theme.palette.accent));
        swatch->SetBounds(CenterIn(tile.content, 52.0f, 52.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"TextField / Single line");
        auto* field     = scene.root->AddChild<TextField>(L"Search text");
        field->SetClearButtonEnabled(true);
        field->SetBounds(CenterIn(tile.content, 280.0f, 32.0f));
        scene.focusedControl = scene.focusedControl ? scene.focusedControl : field;
    }
    {
        const Tile tile = flow.Next(*scene.root, L"TextField / Multiline");
        auto* field     = scene.root->AddChild<TextField>(L"Alpha\nBeta\nGamma");
        field->SetMultiline(true);
        field->SetBounds(CenterIn(tile.content, 280.0f, 58.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"TextField / Password");
        auto* field     = scene.root->AddChild<TextField>(L"salamander");
        field->SetMasked(true);
        field->SetPasswordRevealMode(PasswordRevealMode::Peek);
        field->SetBounds(CenterIn(tile.content, 280.0f, 32.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"TextField / Read-only");
        auto* field     = scene.root->AddChild<TextField>(L"Read-only value");
        field->SetReadOnly(true);
        field->SetBounds(CenterIn(tile.content, 280.0f, 32.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"ComboBox / Window");
        auto* combo     = scene.root->AddChild<ComboBox>();
        AddComboItems(*combo);
        combo->SetVariant(ComboBoxVariant::Window);
        combo->SetBounds(CenterIn(tile.content, 280.0f, 32.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"ComboBox / Modern");
        auto* combo     = scene.root->AddChild<ComboBox>();
        AddComboItems(*combo);
        combo->SetVariant(ComboBoxVariant::Modern);
        combo->SetBounds(CenterIn(tile.content, 280.0f, 32.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"ComboBox / Edit");
        auto* combo     = scene.root->AddChild<ComboBox>();
        AddComboItems(*combo);
        combo->SetEditable(true);
        combo->SetText(L"theme");
        combo->SetBounds(CenterIn(tile.content, 280.0f, 32.0f));
    }
    AddComboOpenTile(scene, flow, L"ComboBox / Window open", std::move(menuCaptures.comboWindowOpen));
    AddComboOpenTile(scene, flow, L"ComboBox / Modern open, 48-DIP rows", std::move(menuCaptures.comboModernOpen));
    AddComboOpenTile(scene, flow, L"ComboBox / Edit open", std::move(menuCaptures.comboEditOpen));
    {
        const Tile tile = flow.Next(*scene.root, L"StatusStrip / Sections", 2u);
        auto* status    = scene.root->AddChild<StatusStrip>();
        status->SetBounds(CenterIn(tile.content, 600.0f, 28.0f));
        status->SetSections({
            StatusStrip::Section{.text = L"Ready", .widthDip = 0.0f},
            StatusStrip::Section{.text = L"UTF-8", .widthDip = 80.0f},
            StatusStrip::Section{.text = L"Ln 8, Col 42", .widthDip = 126.0f},
        });
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Menu / Submenu state + icon", 3u, 210.0f);
        auto* menuBar   = scene.root->AddChild<MenuBar>();
        menuBar->SetBounds(D2D1::RectF(tile.content.left + 8.0f, tile.content.top + 2.0f, tile.content.right - 8.0f, tile.content.top + 32.0f));
        menuBar->SetItems({
            MenuBarItem{.text = L"File", .mnemonic = L'F'},
            MenuBarItem{.text = L"Edit", .mnemonic = L'E'},
            MenuBarItem{.text = L"View", .mnemonic = L'V'},
        });
        menuBar->SetSelectedIndex(0u);

        auto* preview = scene.root->AddChild<GalleryBitmapPreview>(std::move(menuCaptures.menuSubmenu));
        preview->SetBounds(D2D1::RectF(tile.content.left + 8.0f, tile.content.top + 38.0f, tile.content.right - 8.0f, tile.content.bottom - 2.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Menu / Wrapped French names and distinct parent locations", 3u, 340.0f);
        auto* preview   = scene.root->AddChild<GalleryBitmapPreview>(std::move(menuCaptures.menuDescriptions));
        preview->SetBounds(tile.content);
    }
    {
        const Tile tile = flow.Next(*scene.root, L"ScrollPanel / Internal scrollbar", 2u, 148.0f);
        auto* scroll    = scene.root->AddChild<ScrollPanel>();
        scroll->SetBounds(tile.content);
        scroll->SetContentHeight(230.0f);
        scroll->SetScrollOffset(54.0f);
        for (int index = 0; index < 7; ++index)
        {
            auto* row = scroll->AddChild<Label>(std::format(L"Scrollable row {}", index + 1));
            row->SetBounds(D2D1::RectF(tile.content.left + 14.0f,
                                       tile.content.top + 8.0f + (static_cast<float>(index) * 30.0f),
                                       tile.content.right - 32.0f,
                                       tile.content.top + 36.0f + (static_cast<float>(index) * 30.0f)));
        }
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Tree / Hierarchy", 2u, 156.0f);
        scene.treeModel = std::make_unique<GalleryTreeModel>();
        auto* tree      = scene.root->AddChild<Tree>();
        tree->SetBounds(tile.content);
        tree->SetModel(scene.treeModel.get());
        tree->SetSelectedItemId(3u);
    }
    {
        // Several rows selected, not next to one another: Ctrl+click adds a row, Shift+click a range, and Ctrl+A every row.
        // Tall enough for all four rows: a selected row that is only partly visible paints its fill past the tree's edge.
        const Tile tile            = flow.Next(*scene.root, L"Tree / Multi-select", 2u, 170.0f);
        scene.multiSelectTreeModel = std::make_unique<GalleryTreeModel>();
        auto* tree                 = scene.root->AddChild<Tree>();
        tree->SetBounds(tile.content);
        tree->SetModel(scene.multiSelectTreeModel.get());
        tree->SetMultiSelectEnabled(true);
        tree->SetSelectedItemIds(std::vector<uint64_t>{1u, 3u, 4u});
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Grid / Cell variants", 2u, 176.0f);
        scene.gridModel = std::make_unique<GalleryGridModel>();
        scene.grid      = scene.root->AddChild<Grid>();
        scene.grid->SetBounds(tile.content);
        scene.grid->SetHeaderHeightDip(30.0f);
        scene.grid->SetRowHeightDip(24.0f);
        scene.grid->SetModel(scene.gridModel.get());
        static_cast<void>(scene.grid->RequestSelectRow(1u, 0u));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"PageHost / Transition");
        auto* pageHost  = scene.root->AddChild<PageHost>();
        pageHost->SetBounds(tile.content);
        auto page   = std::make_unique<Panel>();
        auto* label = page->AddChild<Label>(L"Page content");
        label->SetAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
        label->SetBounds(tile.content);
        pageHost->SetPage(std::move(page));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"PopupLayer / Overlay");
        auto* popup     = scene.root->AddChild<PopupLayer>();
        popup->SetBounds(tile.content);
        auto* card = popup->AddChild<CardPanel>();
        card->SetCornerRadius(8.0f);
        card->SetBounds(CenterIn(tile.content, 220.0f, 54.0f));
        auto* label = popup->AddChild<Label>(L"Overlay content");
        label->SetAlignment(DWRITE_TEXT_ALIGNMENT_CENTER);
        label->SetBounds(CenterIn(tile.content, 200.0f, 34.0f));
    }
    {
        const Tile tile = flow.Next(*scene.root, L"TooltipLayer / Tooltip");
        auto* target    = scene.root->AddChild<Button>(L"Hover target");
        target->SetBounds(CenterIn(tile.content, 150.0f, 32.0f));
        scene.tooltipOrigin = D2D1::Point2F(tile.content.left + 16.0f, tile.content.top + 4.0f);
    }

    {
        const Tile tile = flow.Next(*scene.root, L"TagPicker / Selected tags");
        auto* tags      = scene.root->AddChild<TagPicker>();
        tags->SetOptions(L"All", {L"Audio", L"Video", L"Devices"});
        tags->SetSelectedValues({L"Audio", L"Video"});
        tags->SetBounds(tile.content);
    }
    {
        const Tile tile = flow.Next(*scene.root, L"ThroughputGraph / History");
        auto* graph     = scene.root->AddChild<ThroughputGraph>();
        graph->SetBounds(tile.content);
        const std::array<ThroughputGraphSample, 8> samples{{{12}, {24}, {18}, {43}, {28}, {62}, {51}, {74}}};
        graph->SetSamples(samples);
        graph->SetLimit(100);
        graph->SetCurrentValueMarker(74, L"74 MB/s");
    }
    {
        const Tile tile = flow.Next(*scene.root, L"StackPanel / Layout");
        auto* stack     = scene.root->AddChild<StackPanel>();
        stack->SetBounds(tile.content);
        stack->SetGap(4);
        for (int i = 0; i < 2; ++i)
        {
            auto* label = stack->AddChild<Label>(std::format(L"Stacked item {}", i + 1));
            stack->SetChildExtent(label, 26);
        }
        stack->ApplyLayout();
    }
    {
        const Tile tile = flow.Next(*scene.root, L"Panel / Container");
        auto* panel     = scene.root->AddChild<Panel>();
        panel->SetBounds(tile.content);
        auto* label = panel->AddChild<Label>(L"Absolute child layout");
        label->SetBounds(tile.content);
    }
    if (flow.rowHeight > 0.0f)
    {
        flow.NewRow();
    }
    scene.heightDip = std::max(1.0f, flow.y + kMarginDip);
    return scene;
}

[[nodiscard]] UINT DipsToPixelsCeil(const WindowHost& host, float dips) noexcept
{
    return std::max(1u, static_cast<UINT>(std::ceil(host.DipsToPixels(dips))));
}

void ResizeClientArea(AttachedHostWindow& window, UINT widthPx, UINT heightPx)
{
    const HWND hwnd = window.Hwnd();
    RECT rect{0, 0, static_cast<LONG>(widthPx), static_cast<LONG>(heightPx)};
    const DWORD style   = static_cast<DWORD>(GetWindowLongPtrW(hwnd, GWL_STYLE));
    const DWORD exStyle = static_cast<DWORD>(GetWindowLongPtrW(hwnd, GWL_EXSTYLE));
    Require(AdjustWindowRectEx(&rect, style, FALSE, exStyle) != FALSE, "gallery window rect adjusts for client size");
    const int outerWidth  = static_cast<int>(rect.right - rect.left);
    const int outerHeight = static_cast<int>(rect.bottom - rect.top);
    // Sheets exceed common desktops. Without this the default tracking limit crops
    // them to the screen, so generated pixels would depend on the display size.
    window.AllowOuterSizeBeyondDesktop(SIZE{outerWidth, outerHeight});
    Require(SetWindowPos(hwnd, nullptr, -32000, -32000, outerWidth, outerHeight, SWP_NOZORDER | SWP_NOACTIVATE) != FALSE,
            "gallery window resizes to requested client area");
}

[[nodiscard]] WindowHostBitmapCapture CaptureThemeSection(const GalleryTheme& theme)
{
    GalleryScene scene = BuildGalleryScene(theme, CaptureGalleryMenus(theme.palette));
    // Borrowed models must survive capture cancellation and accessibility publication during host teardown.
    AttachedHostWindow window;

    ResizeClientArea(window, DipsToPixelsCeil(window.Host(), kGalleryWidthDip), DipsToPixelsCeil(window.Host(), scene.heightDip));
    window.Host().SetTheme(theme.palette);
    window.Host().SetRoot(std::move(scene.root));

    // A full sheet can take longer than an animation tick under ASAN. Bound queue
    // settling by time; the explicit redraw below establishes the captured frame.
    ShowWindow(window.Hwnd(), SW_SHOWNOACTIVATE);
    window.PumpMessages(100u);

    if (scene.hoverButton)
    {
        scene.hoverButton->OnHoverChanged(window.Host(), true);
    }
    if (scene.selectorHoverButton)
    {
        scene.selectorHoverButton->OnHoverChanged(window.Host(), true);
    }
    if (scene.pressedButton)
    {
        scene.pressedButton->OnHoverChanged(window.Host(), true);
        scene.pressedButton->SetPressed(true);
    }
    if (scene.hoverSlider)
    {
        scene.hoverSlider->OnHoverChanged(window.Host(), true);
    }
    if (scene.pressedSlider)
    {
        const D2D1_RECT_F thumb         = scene.pressedSlider->DebugGetThumbRect();
        const D2D1_POINT_2F thumbCenter = D2D1::Point2F((thumb.left + thumb.right) * 0.5f, (thumb.top + thumb.bottom) * 0.5f);
        scene.pressedSlider->OnHoverChanged(window.Host(), true);
        static_cast<void>(scene.pressedSlider->OnMouseDown(window.Host(), thumbCenter, false, 0));
    }
    if (scene.touchSlider)
    {
        // A finger on the thumb: the press a touch contact makes, with the halo around it.
        const D2D1_RECT_F thumb         = scene.touchSlider->DebugGetThumbRect();
        const D2D1_POINT_2F thumbCenter = D2D1::Point2F((thumb.left + thumb.right) * 0.5f, (thumb.top + thumb.bottom) * 0.5f);
        window.Host().DebugSetPointerDevice(PointerDevice::Touch);
        static_cast<void>(scene.touchSlider->OnMouseDown(window.Host(), thumbCenter, false, 0));
        window.Host().DebugSetPointerDevice(PointerDevice::Mouse);
    }
    if (scene.focusedControl)
    {
        window.Host().SetFocusControl(scene.focusedControl);
    }
    if (scene.grid)
    {
        static_cast<void>(scene.grid->Tick(window.Host(), 300u));
    }
    if (scene.tooltipOrigin)
    {
        static_cast<void>(window.Host().SetTooltip(L"Tooltip sample", scene.tooltipOrigin.value()));
    }

    RedrawWindow(window.Hwnd(), nullptr, nullptr, RDW_INVALIDATE | RDW_ALLCHILDREN | RDW_UPDATENOW);
    window.PumpMessages(100u);

    WindowHostBitmapCapture capture;
    Require(window.Host().DebugCaptureBitmap(capture), "gallery section bitmap capture succeeds");
    Require(capture.widthPx > 0u && capture.heightPx > 0u && ! capture.bgraPixels.empty(), "gallery section capture is non-empty");
    return capture;
}

[[nodiscard]] WindowHostBitmapCapture StitchSections(std::span<const WindowHostBitmapCapture> captures)
{
    Require(! captures.empty(), "gallery has at least one section capture");

    UINT widthPx  = 0u;
    UINT heightPx = 0u;
    for (const auto& capture : captures)
    {
        widthPx = std::max(widthPx, capture.widthPx);
        Require(capture.heightPx <= std::numeric_limits<UINT>::max() - heightPx, "gallery stitched image height stays in range");
        heightPx += capture.heightPx;
    }

    WindowHostBitmapCapture stitched;
    stitched.widthPx  = widthPx;
    stitched.heightPx = heightPx;
    stitched.bgraPixels.assign(static_cast<size_t>(widthPx) * static_cast<size_t>(heightPx) * 4u, 0xFFu);

    UINT destinationY = 0u;
    for (const auto& capture : captures)
    {
        const UINT copyWidth = std::min(widthPx, capture.widthPx);
        for (UINT row = 0u; row < capture.heightPx; ++row)
        {
            const size_t sourceOffset      = (static_cast<size_t>(row) * static_cast<size_t>(capture.widthPx)) * 4u;
            const size_t destinationOffset = ((static_cast<size_t>(destinationY + row) * static_cast<size_t>(widthPx))) * 4u;
            std::copy_n(capture.bgraPixels.data() + sourceOffset, static_cast<size_t>(copyWidth) * 4u, stitched.bgraPixels.data() + destinationOffset);
        }
        destinationY += capture.heightPx;
    }

    return stitched;
}

[[nodiscard]] std::wstring MakeThemeGalleryFileSlug(std::wstring_view name)
{
    std::wstring slug;
    bool pendingSeparator = false;
    for (wchar_t ch : name)
    {
        if (ch >= L'A' && ch <= L'Z')
        {
            ch = static_cast<wchar_t>(L'a' + (ch - L'A'));
        }

        if ((ch >= L'a' && ch <= L'z') || (ch >= L'0' && ch <= L'9'))
        {
            if (pendingSeparator && ! slug.empty())
            {
                slug.push_back(L'-');
            }
            slug.push_back(ch);
            pendingSeparator = false;
            continue;
        }

        pendingSeparator = ! slug.empty();
    }

    return slug.empty() ? L"theme" : slug;
}

[[nodiscard]] std::filesystem::path MakeThemeGalleryOutputPath(const std::filesystem::path& outputDirectory,
                                                               const GalleryTheme& theme,
                                                               std::unordered_map<std::wstring, size_t>& slugCounts)
{
    const std::wstring slug = MakeThemeGalleryFileSlug(theme.slug.empty() ? std::wstring_view(theme.name) : std::wstring_view(theme.slug));
    const size_t count      = ++slugCounts[slug];

    std::wstring fileName = L"theme-controls-" + slug;
    if (count > 1u)
    {
        fileName += L"-" + std::to_wstring(count);
    }
    fileName += L".png";
    return outputDirectory / fileName;
}

constexpr float kButtonAuditWidthDip         = 1680.0f;
constexpr float kButtonAuditMarginDip        = 24.0f;
constexpr float kButtonAuditHeaderHeightDip  = 96.0f;
constexpr float kButtonAuditThemeGapDip      = 18.0f;
constexpr float kButtonAuditStateGapDip      = 10.0f;
constexpr float kButtonAuditRowLabelDip      = 112.0f;
constexpr float kButtonAuditTileHeightDip    = 96.0f;
constexpr float kButtonAuditSectionHeaderDip = 48.0f;

struct ButtonAuditState
{
    std::wstring_view name;
    bool enabled        = true;
    bool hovered        = false;
    bool pressed        = false;
    bool focused        = false;
    bool keyboardFocus  = false;
    float hoverStrength = 0.0f;
    float focusStrength = 0.0f;
};

struct ButtonAuditVariant
{
    std::wstring_view name;
    std::wstring_view buttonText;
    bool primary = false;
};

enum class ButtonAuditQuality : uint8_t
{
    Exempt,
    Fail,
    Aa,
    Aaa,
};

struct ButtonAuditMeasurement
{
    ButtonVisualStyle style{};
    double ratio               = 1.0;
    ButtonAuditQuality quality = ButtonAuditQuality::Fail;
};

struct ButtonAuditThemeSummary
{
    std::wstring name;
    double minimumEnabledRatio = std::numeric_limits<double>::max();
    size_t enabledCount        = 0u;
    size_t aaPassCount         = 0u;
    size_t aaaPassCount        = 0u;
};

constexpr std::array<ButtonAuditState, 5> kButtonAuditStates = {{
    ButtonAuditState{.name = L"Idle", .enabled = true},
    ButtonAuditState{.name = L"Hover", .enabled = true, .hovered = true, .hoverStrength = 1.0f},
    ButtonAuditState{.name = L"Pressed", .enabled = true, .pressed = true},
    ButtonAuditState{.name = L"Keyboard focus", .enabled = true, .focused = true, .keyboardFocus = true, .focusStrength = 1.0f},
    ButtonAuditState{.name = L"Disabled", .enabled = false},
}};

constexpr std::array<ButtonAuditVariant, 2> kButtonAuditVariants = {{
    ButtonAuditVariant{.name = L"Standard", .buttonText = L"Button", .primary = false},
    ButtonAuditVariant{.name = L"Primary", .buttonText = L"Primary", .primary = true},
}};

[[nodiscard]] float ButtonAuditSectionHeightDip() noexcept
{
    return kButtonAuditSectionHeaderDip + (static_cast<float>(kButtonAuditVariants.size()) * kButtonAuditTileHeightDip) +
           (static_cast<float>(kButtonAuditVariants.size() - 1u) * kButtonAuditStateGapDip) + (kButtonAuditMarginDip * 1.25f);
}

[[nodiscard]] D2D1_COLOR_F CompositeColorForAudit(const D2D1_COLOR_F& foreground, const D2D1_COLOR_F& background) noexcept
{
    const float alpha        = ClampUnit(foreground.a);
    const float inverseAlpha = 1.0f - alpha;
    return D2D1::ColorF((foreground.r * alpha) + (background.r * inverseAlpha),
                        (foreground.g * alpha) + (background.g * inverseAlpha),
                        (foreground.b * alpha) + (background.b * inverseAlpha),
                        alpha + (background.a * inverseAlpha));
}

[[nodiscard]] double LinearizeSrgbForAudit(float value) noexcept
{
    const double channel = static_cast<double>(ClampUnit(value));
    return channel <= 0.04045 ? channel / 12.92 : std::pow((channel + 0.055) / 1.055, 2.4);
}

[[nodiscard]] double RelativeLuminanceForAudit(const D2D1_COLOR_F& color) noexcept
{
    return (0.2126 * LinearizeSrgbForAudit(color.r)) + (0.7152 * LinearizeSrgbForAudit(color.g)) + (0.0722 * LinearizeSrgbForAudit(color.b));
}

[[nodiscard]] double ContrastRatioForAudit(const D2D1_COLOR_F& foreground, const D2D1_COLOR_F& background) noexcept
{
    const double foregroundLuminance = RelativeLuminanceForAudit(foreground);
    const double backgroundLuminance = RelativeLuminanceForAudit(background);
    const double lighter             = std::max(foregroundLuminance, backgroundLuminance);
    const double darker              = std::min(foregroundLuminance, backgroundLuminance);
    return (lighter + 0.05) / (darker + 0.05);
}

[[nodiscard]] D2D1_COLOR_F ChooseTextForAudit(const D2D1_COLOR_F& fill) noexcept
{
    const D2D1_COLOR_F white = D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f);
    const D2D1_COLOR_F black = D2D1::ColorF(0.02f, 0.02f, 0.02f, 1.0f);
    return ContrastRatioForAudit(white, fill) >= ContrastRatioForAudit(black, fill) ? white : black;
}

[[nodiscard]] std::wstring FormatContrastRatioForAudit(double ratio)
{
    return std::format(L"{:.1f}:1", ratio);
}

[[nodiscard]] ButtonAuditQuality ResolveButtonAuditQuality(double ratio, bool enabled) noexcept
{
    if (! enabled)
    {
        return ButtonAuditQuality::Exempt;
    }
    if (ratio >= 7.0)
    {
        return ButtonAuditQuality::Aaa;
    }
    if (ratio >= 4.5)
    {
        return ButtonAuditQuality::Aa;
    }
    return ButtonAuditQuality::Fail;
}

[[nodiscard]] std::wstring_view ButtonAuditQualityLabel(ButtonAuditQuality quality) noexcept
{
    switch (quality)
    {
        case ButtonAuditQuality::Aaa: return L"AAA";
        case ButtonAuditQuality::Aa: return L"AA";
        case ButtonAuditQuality::Exempt: return L"Exempt";
        case ButtonAuditQuality::Fail:
        default: return L"Fail";
    }
}

[[nodiscard]] D2D1_COLOR_F ButtonAuditQualityFill(ButtonAuditQuality quality, bool dark) noexcept
{
    switch (quality)
    {
        case ButtonAuditQuality::Aaa: return dark ? D2D1::ColorF(0.18f, 0.58f, 0.28f, 1.0f) : D2D1::ColorF(0.70f, 0.93f, 0.76f, 1.0f);
        case ButtonAuditQuality::Aa: return dark ? D2D1::ColorF(0.30f, 0.48f, 0.18f, 1.0f) : D2D1::ColorF(0.83f, 0.92f, 0.66f, 1.0f);
        case ButtonAuditQuality::Exempt: return dark ? D2D1::ColorF(0.32f, 0.32f, 0.32f, 1.0f) : D2D1::ColorF(0.86f, 0.86f, 0.86f, 1.0f);
        case ButtonAuditQuality::Fail:
        default: return dark ? D2D1::ColorF(0.68f, 0.14f, 0.16f, 1.0f) : D2D1::ColorF(1.0f, 0.72f, 0.72f, 1.0f);
    }
}

[[nodiscard]] ButtonAuditMeasurement MeasureButtonForAudit(const ThemePalette& theme,
                                                           const ButtonAuditVariant& variant,
                                                           const ButtonAuditState& state,
                                                           const D2D1_COLOR_F& tileBackground) noexcept
{
    ButtonAuditMeasurement measurement;
    measurement.style = ResolveButtonVisualStyle(
        theme, state.enabled, state.hovered, state.pressed, state.focused, state.keyboardFocus, variant.primary, state.hoverStrength, state.focusStrength);
    const D2D1_COLOR_F effectiveFill = CompositeColorForAudit(measurement.style.fill, tileBackground);
    const D2D1_COLOR_F effectiveText = CompositeColorForAudit(measurement.style.text, effectiveFill);
    measurement.ratio                = ContrastRatioForAudit(effectiveText, effectiveFill);
    measurement.quality              = ResolveButtonAuditQuality(measurement.ratio, state.enabled);
    return measurement;
}

[[nodiscard]] ButtonAuditThemeSummary SummarizeButtonAuditTheme(const GalleryTheme& theme)
{
    ButtonAuditThemeSummary summary{.name = theme.name};
    const D2D1_COLOR_F tileBackground = theme.palette.surfaceBackground;
    for (const ButtonAuditVariant& variant : kButtonAuditVariants)
    {
        for (const ButtonAuditState& state : kButtonAuditStates)
        {
            const ButtonAuditMeasurement measurement = MeasureButtonForAudit(theme.palette, variant, state, tileBackground);
            if (! state.enabled)
            {
                continue;
            }

            ++summary.enabledCount;
            summary.minimumEnabledRatio = std::min(summary.minimumEnabledRatio, measurement.ratio);
            if (measurement.quality == ButtonAuditQuality::Aa || measurement.quality == ButtonAuditQuality::Aaa)
            {
                ++summary.aaPassCount;
            }
            if (measurement.quality == ButtonAuditQuality::Aaa)
            {
                ++summary.aaaPassCount;
            }
        }
    }

    if (summary.enabledCount == 0u)
    {
        summary.minimumEnabledRatio = 0.0;
    }
    return summary;
}

void DrawAuditText(WindowHost& host, std::wstring_view text, const D2D1_RECT_F& rect, FontRole role, const D2D1_COLOR_F& color)
{
    if (auto* brush = host.GetSolidBrush(color))
    {
        host.GetDeviceContext()->DrawTextW(text.data(), static_cast<UINT32>(text.size()), host.GetTextFormat(role), rect, brush, kTextDrawOptions);
    }
}

void DrawAuditBadge(WindowHost& host, const D2D1_RECT_F& rect, std::wstring_view text, const D2D1_COLOR_F& fill, FontRole role = FontRole::Small)
{
    DrawRoundedRect(host, rect, fill, D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f), 4.0f);
    DrawCenteredText(host, text, rect, role, ChooseTextForAudit(fill));
}

class ButtonContrastAuditControl final : public Control
{
public:
    explicit ButtonContrastAuditControl(std::vector<GalleryTheme> themes, bool showHeader) : _themes(std::move(themes)), _showHeader(showHeader)
    {
    }

    void Paint(WindowHost& host) const override
    {
        const D2D1_RECT_F bounds = GetBounds();
        FillRectangle(host, bounds, D2D1::ColorF(0.96f, 0.96f, 0.96f, 1.0f));

        float y = 0.0f;
        if (_showHeader)
        {
            DrawAuditText(host,
                          L"Button state contrast audit",
                          D2D1::RectF(kButtonAuditMarginDip, 12.0f, bounds.right - kButtonAuditMarginDip, 56.0f),
                          FontRole::TitleLarge,
                          D2D1::ColorF(0.04f, 0.04f, 0.04f, 1.0f));
            DrawAuditText(
                host,
                L"Enabled text uses WCAG normal-text thresholds: AA >= 4.5:1, AAA >= 7:1. Disabled controls are shown with contrast but marked exempt.",
                D2D1::RectF(kButtonAuditMarginDip, 62.0f, bounds.right - kButtonAuditMarginDip, 88.0f),
                FontRole::Small,
                D2D1::ColorF(0.22f, 0.22f, 0.22f, 1.0f));
            y = kButtonAuditHeaderHeightDip + kButtonAuditMarginDip;
        }

        for (const GalleryTheme& theme : _themes)
        {
            PaintThemeSection(host, theme, y, bounds.right);
            y += ButtonAuditSectionHeightDip() + kButtonAuditThemeGapDip;
        }
    }

private:
    static void FillRectangle(WindowHost& host, const D2D1_RECT_F& rect, const D2D1_COLOR_F& color)
    {
        if (auto* brush = host.GetSolidBrush(color))
        {
            host.GetDeviceContext()->FillRectangle(rect, brush);
        }
    }

    static void DrawRectangle(WindowHost& host, const D2D1_RECT_F& rect, const D2D1_COLOR_F& color, float widthDip = 1.0f)
    {
        if (auto* brush = host.GetSolidBrush(color))
        {
            host.GetDeviceContext()->DrawRectangle(rect, brush, widthDip);
        }
    }

    static void PaintButtonTile(
        WindowHost& host, const GalleryTheme& theme, const ButtonAuditVariant& variant, const ButtonAuditState& state, const D2D1_RECT_F& tileRect)
    {
        const D2D1_COLOR_F tileFill = theme.palette.surfaceBackground;
        DrawRoundedRect(host, tileRect, tileFill, theme.palette.borderDefault, 5.0f);
        DrawAuditText(host,
                      state.name,
                      D2D1::RectF(tileRect.left + 10.0f, tileRect.top + 8.0f, tileRect.right - 10.0f, tileRect.top + 28.0f),
                      FontRole::Small,
                      theme.palette.subduedText);

        const ButtonAuditMeasurement measurement = MeasureButtonForAudit(theme.palette, variant, state, tileFill);
        const D2D1_RECT_F buttonRect             = D2D1::RectF(tileRect.left + 12.0f, tileRect.top + 34.0f, tileRect.right - 12.0f, tileRect.top + 68.0f);
        const D2D1_COLOR_F transparent           = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
        DrawRoundedRect(host, buttonRect, measurement.style.fill, measurement.style.showBorder ? measurement.style.border : transparent, 4.0f);
        if (measurement.style.showFocus)
        {
            PaintFocusRing(host, buttonRect, 4.0f);
        }

        const D2D1_RECT_F textRect = D2D1::RectF(buttonRect.left + measurement.style.textOffsetXDip,
                                                 buttonRect.top + measurement.style.textOffsetYDip,
                                                 buttonRect.right + measurement.style.textOffsetXDip,
                                                 buttonRect.bottom + measurement.style.textOffsetYDip);
        DrawCenteredText(host, variant.buttonText, textRect, FontRole::Body, measurement.style.text);

        const D2D1_COLOR_F badgeFill = ButtonAuditQualityFill(measurement.quality, theme.palette.dark);
        const D2D1_RECT_F badgeRect  = D2D1::RectF(tileRect.left + 10.0f, tileRect.bottom - 24.0f, tileRect.left + 74.0f, tileRect.bottom - 6.0f);
        DrawAuditBadge(host, badgeRect, ButtonAuditQualityLabel(measurement.quality), badgeFill);

        DrawAuditText(host,
                      FormatContrastRatioForAudit(measurement.ratio),
                      D2D1::RectF(badgeRect.right + 8.0f, tileRect.bottom - 25.0f, tileRect.right - 8.0f, tileRect.bottom - 4.0f),
                      FontRole::Small,
                      theme.palette.text);
    }

    static void PaintThemeSection(WindowHost& host, const GalleryTheme& theme, float y, float widthDip)
    {
        const float sectionHeight = ButtonAuditSectionHeightDip();
        const D2D1_RECT_F sectionRect =
            D2D1::RectF(kButtonAuditMarginDip, y, std::max(kButtonAuditMarginDip + 1.0f, widthDip - kButtonAuditMarginDip), y + sectionHeight);
        DrawRoundedRect(host, sectionRect, theme.palette.windowBackground, theme.palette.borderDefault, 6.0f);

        const ButtonAuditThemeSummary summary   = SummarizeButtonAuditTheme(theme);
        const bool allAa                        = summary.enabledCount > 0u && summary.aaPassCount == summary.enabledCount;
        const bool allAaa                       = summary.enabledCount > 0u && summary.aaaPassCount == summary.enabledCount;
        const ButtonAuditQuality summaryQuality = allAaa ? ButtonAuditQuality::Aaa : (allAa ? ButtonAuditQuality::Aa : ButtonAuditQuality::Fail);
        const std::wstring summaryText          = std::format(L"{} {}/{} enabled  min {}",
                                                              allAa ? L"Good" : L"Review",
                                                              summary.aaPassCount,
                                                              summary.enabledCount,
                                                              FormatContrastRatioForAudit(summary.minimumEnabledRatio));

        DrawAuditText(host,
                      theme.name,
                      D2D1::RectF(sectionRect.left + 16.0f, sectionRect.top + 12.0f, sectionRect.left + 360.0f, sectionRect.top + 40.0f),
                      FontRole::Header,
                      theme.palette.text);
        DrawAuditBadge(host,
                       D2D1::RectF(sectionRect.right - 310.0f, sectionRect.top + 12.0f, sectionRect.right - 188.0f, sectionRect.top + 36.0f),
                       ButtonAuditQualityLabel(summaryQuality),
                       ButtonAuditQualityFill(summaryQuality, theme.palette.dark),
                       FontRole::BodyStrong);
        DrawAuditText(host,
                      summaryText,
                      D2D1::RectF(sectionRect.right - 178.0f, sectionRect.top + 13.0f, sectionRect.right - 16.0f, sectionRect.top + 38.0f),
                      FontRole::Small,
                      theme.palette.subduedText);

        const float availableWidth = (sectionRect.right - sectionRect.left) - (kButtonAuditMarginDip * 2.0f) - kButtonAuditRowLabelDip -
                                     (kButtonAuditStateGapDip * static_cast<float>(kButtonAuditStates.size() - 1u));
        const float tileWidth      = availableWidth / static_cast<float>(kButtonAuditStates.size());
        const float rowsTop        = sectionRect.top + kButtonAuditSectionHeaderDip;

        for (size_t variantIndex = 0u; variantIndex < kButtonAuditVariants.size(); ++variantIndex)
        {
            const ButtonAuditVariant& variant = kButtonAuditVariants[variantIndex];
            const float rowTop                = rowsTop + (static_cast<float>(variantIndex) * (kButtonAuditTileHeightDip + kButtonAuditStateGapDip));
            DrawAuditText(host,
                          variant.name,
                          D2D1::RectF(sectionRect.left + 16.0f, rowTop + 34.0f, sectionRect.left + 16.0f + kButtonAuditRowLabelDip, rowTop + 58.0f),
                          FontRole::BodyStrong,
                          theme.palette.text);

            float x = sectionRect.left + kButtonAuditMarginDip + kButtonAuditRowLabelDip;
            for (const ButtonAuditState& state : kButtonAuditStates)
            {
                const D2D1_RECT_F tileRect = D2D1::RectF(x, rowTop, x + tileWidth, rowTop + kButtonAuditTileHeightDip);
                PaintButtonTile(host, theme, variant, state, tileRect);
                x += tileWidth + kButtonAuditStateGapDip;
            }
        }

        DrawRectangle(host, sectionRect, theme.palette.borderDefault);
    }

    std::vector<GalleryTheme> _themes;
    bool _showHeader = true;
};

[[nodiscard]] WindowHostBitmapCapture CaptureButtonContrastAuditSlice(std::vector<GalleryTheme> themes, bool showHeader, float heightDip)
{
    AttachedHostWindow window;
    ResizeClientArea(window, static_cast<UINT>(std::ceil(kButtonAuditWidthDip)), static_cast<UINT>(std::ceil(heightDip)));
    ThemePalette hostTheme  = MakeDefaultThemePalette(false);
    hostTheme.reducedMotion = true;
    window.Host().SetTheme(hostTheme);
    window.Host().SetRoot(std::make_unique<ButtonContrastAuditControl>(std::move(themes), showHeader));

    ShowWindow(window.Hwnd(), SW_SHOWNOACTIVATE);
    window.PumpMessages();
    RedrawWindow(window.Hwnd(), nullptr, nullptr, RDW_INVALIDATE | RDW_ALLCHILDREN | RDW_UPDATENOW);
    window.PumpMessages();

    WindowHostBitmapCapture capture;
    Require(window.Host().DebugCaptureBitmap(capture), "button contrast audit bitmap slice capture succeeds");
    Require(capture.widthPx > 0u && capture.heightPx > 0u && ! capture.bgraPixels.empty(), "button contrast audit slice capture is non-empty");
    return capture;
}
} // namespace

void RunGalleryGenerator(const std::filesystem::path& outputPath)
{
    const std::vector<GalleryTheme> themes = BuildGalleryThemes();
    Require(! themes.empty(), "gallery theme list is non-empty");

    std::vector<WindowHostBitmapCapture> sections;
    sections.reserve(themes.size());
    for (const GalleryTheme& theme : themes)
    {
        std::wcerr << L"  [GALLERY] Rendering " << theme.name << L'\n' << std::flush;
        sections.push_back(CaptureThemeSection(theme));
    }

    WindowHostBitmapCapture gallery = StitchSections(sections);
    std::error_code ec;
    const std::filesystem::path absoluteOutput = std::filesystem::absolute(outputPath, ec);
    Require(! ec, "gallery output path resolves to an absolute path");
    ec.clear();
    std::filesystem::remove(absoluteOutput, ec);
    Require(SaveWindowHostBitmapCaptureAsPngForTest(absoluteOutput, gallery), "gallery PNG is written");
    ec.clear();
    Require(std::filesystem::exists(absoluteOutput, ec) && ! ec, "gallery PNG exists after writing");

    std::wcout << L"Gallery image written: " << absoluteOutput.wstring() << L'\n';
}

void RunGalleryGeneratorPerTheme(const std::filesystem::path& outputDirectory)
{
    const std::vector<GalleryTheme> themes = BuildGalleryThemes();
    Require(! themes.empty(), "gallery theme list is non-empty");

    std::error_code ec;
    const std::filesystem::path absoluteOutputDirectory = std::filesystem::absolute(outputDirectory, ec);
    Require(! ec, "gallery output directory resolves to an absolute path");
    ec.clear();
    std::filesystem::create_directories(absoluteOutputDirectory, ec);
    Require(! ec, "gallery output directory is created");

    std::unordered_map<std::wstring, size_t> slugCounts;
    for (const GalleryTheme& theme : themes)
    {
        std::wcerr << L"  [GALLERY] Rendering " << theme.name << L'\n' << std::flush;
        WindowHostBitmapCapture capture        = CaptureThemeSection(theme);
        const std::filesystem::path outputPath = MakeThemeGalleryOutputPath(absoluteOutputDirectory, theme, slugCounts);

        ec.clear();
        std::filesystem::remove(outputPath, ec);
        Require(SaveWindowHostBitmapCaptureAsPngForTest(outputPath, capture), "gallery theme PNG is written");
        ec.clear();
        Require(std::filesystem::exists(outputPath, ec) && ! ec, "gallery theme PNG exists after writing");

        std::wcout << L"Gallery theme image written: " << outputPath.wstring() << L'\n';
    }
}

void RunButtonContrastAuditGenerator(const std::filesystem::path& outputPath)
{
    std::vector<GalleryTheme> themes = BuildGalleryThemes();
    Require(! themes.empty(), "button contrast audit theme list is non-empty");

    std::vector<ButtonAuditThemeSummary> summaries;
    summaries.reserve(themes.size());
    for (const GalleryTheme& theme : themes)
    {
        summaries.push_back(SummarizeButtonAuditTheme(theme));
    }

    std::vector<WindowHostBitmapCapture> captures;
    captures.reserve(themes.size() + 1u);
    captures.push_back(CaptureButtonContrastAuditSlice({}, true, kButtonAuditHeaderHeightDip + kButtonAuditMarginDip));
    for (const GalleryTheme& theme : themes)
    {
        captures.push_back(CaptureButtonContrastAuditSlice({theme}, false, ButtonAuditSectionHeightDip() + kButtonAuditThemeGapDip));
    }

    WindowHostBitmapCapture capture = StitchSections(captures);

    std::error_code ec;
    const std::filesystem::path absoluteOutput = std::filesystem::absolute(outputPath, ec);
    Require(! ec, "button contrast audit output path resolves to an absolute path");
    ec.clear();
    std::filesystem::remove(absoluteOutput, ec);
    Require(SaveWindowHostBitmapCaptureAsPngForTest(absoluteOutput, capture), "button contrast audit PNG is written");
    ec.clear();
    Require(std::filesystem::exists(absoluteOutput, ec) && ! ec, "button contrast audit PNG exists after writing");

    std::wcout << L"Button contrast audit image written: " << absoluteOutput.wstring() << L'\n';
    for (const ButtonAuditThemeSummary& summary : summaries)
    {
        const bool allAa = summary.enabledCount > 0u && summary.aaPassCount == summary.enabledCount;
        std::wcout << L"  " << summary.name << L": " << (allAa ? L"GOOD" : L"REVIEW") << L" " << summary.aaPassCount << L"/" << summary.enabledCount
                   << L" enabled AA, min " << FormatContrastRatioForAudit(summary.minimumEnabledRatio) << L'\n';
    }
}
