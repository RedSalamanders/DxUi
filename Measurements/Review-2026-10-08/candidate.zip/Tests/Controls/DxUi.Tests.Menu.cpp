#include "../../src/Controls/DxUi.Internal.h"
#include "../../src/Controls/DxUi.PointerInput.h"
#include "../../src/Controls/DxUiNativeMenuInterop.h"
#include "../../src/Support/AnimationDispatcher.h"
#include "../../src/Support/PostedPayload.h"
#include "Controls.Tests.DxUiFocusEventClient.h"
#include "Controls.Tests.DxUiTestHelpers.h"
#include <DxUi/Diagnostics.h>
#include <cstdio>

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <commctrl.h>
#include <format>
#include <fstream>
#include <iterator>
#include <string>
#include <thread>
#include <vector>
#include <wrl/implements.h>

// The resource probe is included after the owned menu fixture helpers below.

#pragma comment(lib, "comctl32.lib")

namespace
{
[[nodiscard]] std::string NarrowAsciiForFailureMessage(std::wstring_view text)
{
    std::string result;
    result.reserve(text.size());
    for (const wchar_t ch : text)
    {
        const auto value = static_cast<unsigned int>(ch);
        result.push_back(value >= 0x20u && value <= 0x7eu ? static_cast<char>(value) : '?');
    }

    return result;
}

[[nodiscard]] std::string WideCodeUnitsForFailureMessage(std::wstring_view text)
{
    std::string result;
    for (const wchar_t ch : text)
    {
        std::format_to(std::back_inserter(result), "{:04X} ", static_cast<unsigned int>(ch));
    }

    return result;
}

void TestPointerInputEventMouseMoveUsesDeliveredPoint()
{
    using namespace DxUi;

    AttachedHostWindow window;
    SetWindowPos(window.Hwnd(), nullptr, 240, 180, 320, 200, SWP_NOZORDER | SWP_NOACTIVATE);

    constexpr POINT deliveredClientPoint{37, 49};
    POINT expectedScreenPoint = deliveredClientPoint;
    Require(ClientToScreen(window.Hwnd(), &expectedScreenPoint) != FALSE, "pointer move test converts delivered client point to screen");

    const std::optional<PointerInputEvent> event =
        TryBuildPointerInputEvent(window.Hwnd(), WM_MOUSEMOVE, MK_CONTROL, MAKELPARAM(deliveredClientPoint.x, deliveredClientPoint.y));

    Require(event.has_value(), "pointer move event is built from a mouse message");
    Require(event.value().kind == PointerInputKind::Move, "pointer move event records move kind");
    Require(event.value().targetHwnd == window.Hwnd(), "pointer move event records target HWND");
    Require(event.value().rootHwnd == GetAncestor(window.Hwnd(), GA_ROOT), "pointer move event records root HWND");
    Require(event.value().captureHwnd == GetCapture(), "pointer move event records current capture HWND");
    Require(event.value().message == WM_MOUSEMOVE, "pointer move event records message");
    Require(event.value().wParam == MK_CONTROL, "pointer move event records flags");
    Require(event.value().lParam == MAKELPARAM(deliveredClientPoint.x, deliveredClientPoint.y), "pointer move event records raw lParam");
    Require(event.value().messageTime == static_cast<DWORD>(GetMessageTime()), "pointer move event stores message time metadata");
    Require(event.value().hasClientPoint, "pointer move event has a client point");
    Require(event.value().hasScreenPoint, "pointer move event has a screen point");
    Require(event.value().clientPointPx.x == deliveredClientPoint.x && event.value().clientPointPx.y == deliveredClientPoint.y,
            "pointer move event uses delivered client point");
    Require(event.value().screenPointPx.x == expectedScreenPoint.x && event.value().screenPointPx.y == expectedScreenPoint.y,
            "pointer move event derives screen point from delivered client point");
}

void TestPointerInputEventButtonUsesDeliveredPointAndFlags()
{
    using namespace DxUi;

    AttachedHostWindow window;
    SetWindowPos(window.Hwnd(), nullptr, 260, 210, 320, 200, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(window.Hwnd(), SW_SHOWNOACTIVATE);
    SetCapture(window.Hwnd());
    const auto releaseCapture = wil::scope_exit([]() noexcept { static_cast<void>(ReleaseCapture()); });

    constexpr POINT deliveredClientPoint{11, 23};
    POINT expectedScreenPoint = deliveredClientPoint;
    Require(ClientToScreen(window.Hwnd(), &expectedScreenPoint) != FALSE, "button test converts delivered client point to screen");

    const std::optional<PointerInputEvent> event =
        TryBuildPointerInputEvent(window.Hwnd(), WM_LBUTTONDOWN, MK_LBUTTON | MK_SHIFT, MAKELPARAM(deliveredClientPoint.x, deliveredClientPoint.y));

    Require(event.has_value(), "button event is built from a mouse button message");
    Require(event.value().kind == PointerInputKind::LeftDown, "button event records left-down kind");
    Require(event.value().targetHwnd == window.Hwnd(), "button event records target HWND");
    Require(event.value().captureHwnd == window.Hwnd(), "button event records current capture HWND");
    Require((event.value().wParam & MK_LBUTTON) != 0, "button event records MK_LBUTTON flag");
    Require(event.value().clientPointPx.x == deliveredClientPoint.x && event.value().clientPointPx.y == deliveredClientPoint.y,
            "button event uses delivered client point");
    Require(event.value().screenPointPx.x == expectedScreenPoint.x && event.value().screenPointPx.y == expectedScreenPoint.y,
            "button event derives screen point from delivered client point");
}

void TestPointerInputEventWheelUsesDeliveredScreenPoint()
{
    using namespace DxUi;

    AttachedHostWindow window;
    SetWindowPos(window.Hwnd(), nullptr, 300, 250, 320, 200, SWP_NOZORDER | SWP_NOACTIVATE);

    POINT deliveredScreenPoint{351, 289};
    POINT expectedClientPoint = deliveredScreenPoint;
    Require(ScreenToClient(window.Hwnd(), &expectedClientPoint) != FALSE, "wheel test converts delivered screen point to client");

    const WPARAM wheelFlags                      = MAKEWPARAM(MK_RBUTTON, WHEEL_DELTA);
    const LPARAM wheelPoint                      = MAKELPARAM(deliveredScreenPoint.x, deliveredScreenPoint.y);
    const std::optional<PointerInputEvent> event = TryBuildPointerInputEvent(window.Hwnd(), WM_MOUSEWHEEL, wheelFlags, wheelPoint);

    Require(event.has_value(), "wheel event is built from a wheel message");
    Require(event.value().kind == PointerInputKind::Wheel, "wheel event records wheel kind");
    Require(event.value().wheelDelta == WHEEL_DELTA, "wheel event records delivered wheel delta");
    Require(event.value().hasScreenPoint, "wheel event has a screen point");
    Require(event.value().hasClientPoint, "wheel event has a client point");
    Require(event.value().screenPointPx.x == deliveredScreenPoint.x && event.value().screenPointPx.y == deliveredScreenPoint.y,
            "wheel event uses delivered screen point");
    Require(event.value().clientPointPx.x == expectedClientPoint.x && event.value().clientPointPx.y == expectedClientPoint.y,
            "wheel event derives client point from delivered screen point");
}

class StripedBackdropControl final : public DxUi::Control
{
public:
    explicit StripedBackdropControl(LONG stripeWidthPx = 12) noexcept : _stripeWidthPx((std::max)(1l, stripeWidthPx))
    {
    }

    void Paint(DxUi::WindowHost& host) const override
    {
        auto* const dc = host.GetDeviceContext();
        if (! dc)
        {
            return;
        }

        const D2D1_RECT_F bounds      = host.GetClientBoundsDip();
        const LONG left               = static_cast<LONG>(std::floor(bounds.left));
        const LONG right              = static_cast<LONG>(std::ceil(bounds.right));
        const D2D1_COLOR_F evenStripe = D2D1::ColorF(0.94f, 0.97f, 1.00f, 1.0f);
        const D2D1_COLOR_F oddStripe  = D2D1::ColorF(0.03f, 0.16f, 0.34f, 1.0f);

        for (LONG x = left; x < right; ++x)
        {
            const LONG stripeIndex = (x - left) / _stripeWidthPx;
            if (auto* const brush = host.GetSolidBrush((stripeIndex & 1) == 0 ? evenStripe : oddStripe))
            {
                dc->FillRectangle(D2D1::RectF(static_cast<float>(x), bounds.top, static_cast<float>(x + 1), bounds.bottom), brush);
            }
        }
    }

private:
    LONG _stripeWidthPx = 12;
};

template <typename TPredicate>
bool WaitForContextMenuPopupState(HWND popupHwnd,
                                  TPredicate&& predicate,
                                  DxUi::ContextMenuPopupDebugState& outState,
                                  std::chrono::milliseconds timeout = std::chrono::milliseconds(800))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (DxUi::DebugGetContextMenuPopupState(popupHwnd, outState) && predicate(outState))
        {
            return true;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return false;
}

bool WaitForContextMenuPopupItemRect(HWND popupHwnd,
                                     size_t itemIndex,
                                     D2D1_RECT_F& outRectDip,
                                     std::chrono::milliseconds timeout = std::chrono::milliseconds(800))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (DxUi::DebugGetContextMenuPopupItemRect(popupHwnd, itemIndex, outRectDip))
        {
            return true;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return false;
}

bool WaitForContextMenuPopupItemLayout(HWND popupHwnd,
                                       size_t itemIndex,
                                       DxUi::ContextMenuPopupItemLayoutDebugState& outLayout,
                                       std::chrono::milliseconds timeout = std::chrono::milliseconds(800))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (DxUi::DebugGetContextMenuPopupItemLayout(popupHwnd, itemIndex, outLayout))
        {
            return true;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return false;
}

bool WaitForContextMenuPopupItemPaint(HWND popupHwnd,
                                      size_t itemIndex,
                                      DxUi::ContextMenuPopupItemPaintDebugState& outPaint,
                                      std::chrono::milliseconds timeout = std::chrono::milliseconds(800))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (DxUi::DebugGetContextMenuPopupItemPaint(popupHwnd, itemIndex, outPaint))
        {
            return true;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return false;
}

bool WaitForContextMenuPopupItemText(HWND popupHwnd,
                                     size_t itemIndex,
                                     std::wstring& outText,
                                     std::chrono::milliseconds timeout = std::chrono::milliseconds(800))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (DxUi::DebugGetContextMenuPopupItemText(popupHwnd, itemIndex, outText))
        {
            return true;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    outText.clear();
    return false;
}

bool WaitForContextMenuPopupBitmapCapture(HWND popupHwnd,
                                          DxUi::WindowHostBitmapCapture& outCapture,
                                          std::chrono::milliseconds timeout = std::chrono::milliseconds(5000))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    std::chrono::milliseconds longestProbe{};
    do
    {
        // Popup creation first exposes a hidden 1x1 measurement HWND. Cross-thread SendMessage can run during
        // initialization, so only capture the visible, sized popup used for the material comparison.
        // The bitmap dimensions are physical pixels. Do not compare them with a client rectangle queried
        // by this driver thread, whose DPI-awareness context may virtualize that rectangle.
        const auto probeStarted = std::chrono::steady_clock::now();
        const bool captured     = IsWindowVisible(popupHwnd) && DxUi::DebugCaptureContextMenuPopupBitmap(popupHwnd, outCapture);
        longestProbe = (std::max)(longestProbe, std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - probeStarted));
        if (captured && outCapture.widthPx > 1u && outCapture.heightPx > 1u && ! outCapture.bgraPixels.empty())
        {
            return true;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    // A probe the popup thread does not answer fails at its three-second bound, so a longest probe of about 3000 ms says that
    // thread stopped answering.
    std::cerr << "Popup capture readiness timeout: visible=" << IsWindowVisible(popupHwnd) << " dpi=" << GetDpiForWindow(popupHwnd)
              << " bitmap=" << outCapture.widthPx << 'x' << outCapture.heightPx << " longestProbeMs=" << longestProbe.count() << '\n';
    return false;
}

[[nodiscard]] uint8_t GetCapturePixelAlpha(const DxUi::WindowHostBitmapCapture& capture, UINT xPx, UINT yPx) noexcept
{
    if (xPx >= capture.widthPx || yPx >= capture.heightPx)
    {
        return 0u;
    }

    const size_t base = (static_cast<size_t>(yPx) * static_cast<size_t>(capture.widthPx) + static_cast<size_t>(xPx)) * 4u;
    if ((base + 3u) >= capture.bgraPixels.size())
    {
        return 0u;
    }

    return capture.bgraPixels[base + 3u];
}

[[nodiscard]] uint32_t GetCapturePixelBgra(const DxUi::WindowHostBitmapCapture& capture, UINT xPx, UINT yPx) noexcept
{
    if (xPx >= capture.widthPx || yPx >= capture.heightPx)
    {
        return 0u;
    }

    const size_t base = (static_cast<size_t>(yPx) * static_cast<size_t>(capture.widthPx) + static_cast<size_t>(xPx)) * 4u;
    if ((base + 3u) >= capture.bgraPixels.size())
    {
        return 0u;
    }

    return static_cast<uint32_t>(capture.bgraPixels[base + 0u]) | (static_cast<uint32_t>(capture.bgraPixels[base + 1u]) << 8u) |
           (static_cast<uint32_t>(capture.bgraPixels[base + 2u]) << 16u) | (static_cast<uint32_t>(capture.bgraPixels[base + 3u]) << 24u);
}

[[nodiscard]] UINT DipToPixelForPopup(float dip, UINT dpi) noexcept
{
    return static_cast<UINT>((std::max)(0l, std::lround(static_cast<double>(dip) * static_cast<double>(dpi) / 96.0)));
}

[[nodiscard]] POINT ClientScreenPointForTest(HWND hwnd, LONG x, LONG y, const char* context)
{
    POINT point{x, y};
    Require(ClientToScreen(hwnd, &point) != FALSE, context);
    return point;
}

[[nodiscard]] LPARAM MousePointLParamForMenuSuite(LONG x, LONG y) noexcept
{
    return MAKELPARAM(static_cast<WORD>(static_cast<SHORT>(x)), static_cast<WORD>(static_cast<SHORT>(y)));
}

// The modal loop captures/activates after ShowWindow. A visible HWND alone is not
// ready for input, and Windows can synthesize a move for the physical cursor.
class ScopedMenuPointerFixture final
{
public:
    explicit ScopedMenuPointerFixture(HWND popup) noexcept : _popup(popup), _previousDpi(SetThreadDpiAwarenessContext(GetWindowDpiAwarenessContext(popup)))
    {
    }
    ScopedMenuPointerFixture(const ScopedMenuPointerFixture&)            = delete;
    ScopedMenuPointerFixture& operator=(const ScopedMenuPointerFixture&) = delete;
    ~ScopedMenuPointerFixture() noexcept
    {
        if (_cursorAligned)
        {
            POINT current{};
            // Preserve a person's pointer movement during this interactive test.
            const bool readable = GetPhysicalCursorPos(&current) != FALSE;
            if (readable && current.x == _alignedCursor.x && current.y == _alignedCursor.y)
            {
                const bool restored = SetPhysicalCursorPos(_originalCursor.x, _originalCursor.y) != FALSE;
                POINT verified{};
                const bool exact = restored && GetPhysicalCursorPos(&verified) && verified.x == _originalCursor.x && verified.y == _originalCursor.y;
                std::printf("Menu pointer restoration: restored=%d exact=%d\n", restored, exact);
            }
            else
            {
                std::printf("Menu pointer restoration: preservedExternalMovement=%d positionReadable=%d\n", readable, readable);
            }
        }
        if (_previousDpi)
            SetThreadDpiAwarenessContext(_previousDpi);
    }
    [[nodiscard]] bool HasCapture() const noexcept
    {
        GUITHREADINFO gui{sizeof(GUITHREADINFO)};
        const DWORD threadId = GetWindowThreadProcessId(_popup, nullptr);
        return threadId != 0u && GetGUIThreadInfo(threadId, &gui) && gui.hwndCapture == _popup;
    }
    [[nodiscard]] bool WaitForCapture() const noexcept
    {
        const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(800);
        do
        {
            if (HasCapture())
                return true;
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        } while (std::chrono::steady_clock::now() < deadline);
        return false;
    }
    [[nodiscard]] bool AlignCursor(POINT point) noexcept
    {
        // Keep the established popup-context alignment; record its actual physical
        // result so restoration does not round-trip through virtualized coordinates.
        if (GetPhysicalCursorPos(&_originalCursor) == FALSE || SetCursorPos(point.x, point.y) == FALSE || GetPhysicalCursorPos(&_alignedCursor) == FALSE)
            return false;
        _cursorAligned = true;
        return true;
    }

private:
    HWND _popup;
    DPI_AWARENESS_CONTEXT _previousDpi;
    POINT _originalCursor{};
    POINT _alignedCursor{};
    bool _cursorAligned = false;
};

[[nodiscard]] LRESULT SendCapturedMouseMessageForMenuSuite(HWND hwnd, UINT message, WPARAM wParam, POINT screenPoint) noexcept
{
    RECT windowRect{};
    if (! hwnd || GetWindowRect(hwnd, &windowRect) == FALSE)
    {
        return 0;
    }

    const LPARAM lParam = MousePointLParamForMenuSuite(screenPoint.x - windowRect.left, screenPoint.y - windowRect.top);
    return SendMessageW(hwnd, message, wParam, lParam);
}

[[nodiscard]] bool PostCapturedMouseMessageForMenuSuite(HWND hwnd, UINT message, WPARAM wParam, POINT screenPoint) noexcept
{
    RECT windowRect{};
    if (! hwnd || GetWindowRect(hwnd, &windowRect) == FALSE)
    {
        return false;
    }

    const LPARAM lParam = MousePointLParamForMenuSuite(screenPoint.x - windowRect.left, screenPoint.y - windowRect.top);
    return PostMessageW(hwnd, message, wParam, lParam) != FALSE;
}

[[nodiscard]] bool SendClientMouseMoveForMenuSuite(HWND hwnd, LONG x, LONG y) noexcept
{
    if (! hwnd || IsWindow(hwnd) == FALSE)
    {
        return false;
    }

    static_cast<void>(SendMessageW(hwnd, WM_MOUSEMOVE, 0, MousePointLParamForMenuSuite(x, y)));
    return true;
}

[[nodiscard]] bool SendSettledClientMouseMoveForMenuSuite(HWND hwnd, LONG x, LONG y) noexcept
{
    // Deliver the client-space mouse move that production hover routing reads from the
    // message lParam. This previously also warped the live OS cursor, but routing never
    // samples the cursor (see DxUi.PointerInput.cpp), so the warp was incidental and
    // intrusive -- it is omitted to keep the menu suite from disturbing the interactive
    // user's pointer.
    return SendClientMouseMoveForMenuSuite(hwnd, x, y);
}

void DrainPendingMouseMessagesForMenuSuite() noexcept
{
    MSG msg{};
    while (PeekMessageW(&msg, nullptr, WM_MOUSEFIRST, WM_MOUSELAST, PM_REMOVE) != FALSE)
    {
    }
}

// White-box view of the bounded posted-payload registry that carries queued UIA menu actions.
[[nodiscard]] size_t CountQueuedPayloadsForMenuSuite(HWND hwnd)
{
    auto& registry = DxUi::Detail::Payloads();
    const std::lock_guard lock(registry.mutex);
    return static_cast<size_t>(std::count_if(registry.entries.begin(), registry.entries.end(), [hwnd](const DxUi::Detail::PayloadEntry& entry) noexcept {
        return entry.token != 0 && entry.window == hwnd;
    }));
}

[[nodiscard]] bool WaitForPendingSubmenuCloseTimerForMenuSuite(HWND popupHwnd, DxUi::ContextMenuPopupDebugState& outState)
{
    return WaitForContextMenuPopupState(
        popupHwnd, [](const DxUi::ContextMenuPopupDebugState& state) noexcept { return state.hoverTimerActive && state.hoverTimerPendingClose; }, outState);
}

[[nodiscard]] bool WaitForNoSubmenuHoverTimerForMenuSuite(HWND popupHwnd, DxUi::ContextMenuPopupDebugState& outState)
{
    return WaitForContextMenuPopupState(popupHwnd, [](const DxUi::ContextMenuPopupDebugState& state) noexcept { return ! state.hoverTimerActive; }, outState);
}

[[nodiscard]] bool FirePendingSubmenuHoverTimerForMenuSuite(HWND popupHwnd) noexcept
{
    return DxUi::DebugFireContextMenuPopupHoverTimer(popupHwnd);
}

HWND FindOwnedContextMenuPopupWindowByFirstItemText(HWND ownerHwnd, std::wstring_view firstItemText);

[[nodiscard]] bool WaitForSubmenuOpenAfterHoverForMenuSuite(HWND ownerHwnd,
                                                            HWND popupHwnd,
                                                            size_t itemIndex,
                                                            std::wstring_view submenuFirstItemText,
                                                            HWND& submenuHwnd,
                                                            DxUi::ContextMenuPopupDebugState& outState,
                                                            std::chrono::milliseconds timeout = std::chrono::milliseconds(1200))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    bool timerPosted    = false;
    do
    {
        submenuHwnd = FindOwnedContextMenuPopupWindowByFirstItemText(ownerHwnd, submenuFirstItemText);
        if (submenuHwnd)
        {
            return true;
        }

        if (! timerPosted && DxUi::DebugGetContextMenuPopupState(popupHwnd, outState) && outState.hoverTimerActive && outState.hoverTimerPendingOpen &&
            outState.hoverTimerItemIndex.has_value() && outState.hoverTimerItemIndex.value() == itemIndex)
        {
            if (! FirePendingSubmenuHoverTimerForMenuSuite(popupHwnd))
            {
                return false;
            }
            timerPosted = true;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    submenuHwnd = FindOwnedContextMenuPopupWindowByFirstItemText(ownerHwnd, submenuFirstItemText);
    return submenuHwnd != nullptr;
}

[[nodiscard]] bool WaitForSubmenuClosedAfterHoverForMenuSuite(HWND popupHwnd,
                                                              HWND submenuHwnd,
                                                              DxUi::ContextMenuPopupDebugState& outState,
                                                              std::chrono::milliseconds timeout = std::chrono::milliseconds(1200))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    bool timerPosted    = false;
    do
    {
        if (IsWindow(submenuHwnd) == FALSE)
        {
            return true;
        }

        if (! timerPosted && DxUi::DebugGetContextMenuPopupState(popupHwnd, outState) && outState.hoverTimerActive && outState.hoverTimerPendingClose)
        {
            if (! FirePendingSubmenuHoverTimerForMenuSuite(popupHwnd))
            {
                return false;
            }
            timerPosted = true;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return IsWindow(submenuHwnd) == FALSE;
}

DxUi::WindowHostBitmapCapture CropWindowHostBitmapCaptureForTest(const DxUi::WindowHostBitmapCapture& source, const RECT& cropRect)
{
    DxUi::WindowHostBitmapCapture capture{};
    const LONG widthPx        = cropRect.right - cropRect.left;
    const LONG heightPx       = cropRect.bottom - cropRect.top;
    const LONG sourceWidthPx  = static_cast<LONG>(source.widthPx);
    const LONG sourceHeightPx = static_cast<LONG>(source.heightPx);
    const bool cropIsInBounds =
        widthPx > 0 && heightPx > 0 && cropRect.left >= 0 && cropRect.top >= 0 && cropRect.right <= sourceWidthPx && cropRect.bottom <= sourceHeightPx;
    const std::string cropBoundsMessage = std::format("popup backdrop crop stays inside the owner capture crop=({},{} {}x{}) source={}x{}",
                                                      cropRect.left,
                                                      cropRect.top,
                                                      widthPx,
                                                      heightPx,
                                                      sourceWidthPx,
                                                      sourceHeightPx);
    Require(cropIsInBounds, cropBoundsMessage.c_str());

    capture.widthPx  = static_cast<UINT>(widthPx);
    capture.heightPx = static_cast<UINT>(heightPx);
    capture.bgraPixels.resize(static_cast<size_t>(capture.widthPx) * static_cast<size_t>(capture.heightPx) * 4u);

    const size_t destinationStride = static_cast<size_t>(capture.widthPx) * 4u;
    const size_t sourceStride      = static_cast<size_t>(source.widthPx) * 4u;
    for (LONG y = 0; y < heightPx; ++y)
    {
        const size_t sourceOffset      = (static_cast<size_t>(cropRect.top + y) * sourceStride) + (static_cast<size_t>(cropRect.left) * 4u);
        const size_t destinationOffset = static_cast<size_t>(y) * destinationStride;
        std::copy_n(source.bgraPixels.data() + sourceOffset, destinationStride, capture.bgraPixels.data() + destinationOffset);
    }

    return capture;
}

[[nodiscard]] RECT FindOpaqueBoundsInCapture(const DxUi::WindowHostBitmapCapture& capture, uint8_t alphaThreshold = 8u) noexcept
{
    RECT bounds{static_cast<LONG>(capture.widthPx), static_cast<LONG>(capture.heightPx), 0, 0};
    bool foundOpaque = false;

    for (UINT y = 0u; y < capture.heightPx; ++y)
    {
        for (UINT x = 0u; x < capture.widthPx; ++x)
        {
            if (GetCapturePixelAlpha(capture, x, y) <= alphaThreshold)
            {
                continue;
            }

            bounds.left   = (std::min)(bounds.left, static_cast<LONG>(x));
            bounds.top    = (std::min)(bounds.top, static_cast<LONG>(y));
            bounds.right  = (std::max)(bounds.right, static_cast<LONG>(x + 1u));
            bounds.bottom = (std::max)(bounds.bottom, static_cast<LONG>(y + 1u));
            foundOpaque   = true;
        }
    }

    return foundOpaque ? bounds : RECT{};
}

[[nodiscard]] RECT ComputeRightStripSampleRect(const RECT& opaqueBounds) noexcept
{
    const LONG widthPx  = opaqueBounds.right - opaqueBounds.left;
    const LONG heightPx = opaqueBounds.bottom - opaqueBounds.top;
    if (widthPx <= 24 || heightPx <= 24)
    {
        return RECT{};
    }

    const LONG horizontalInset = (std::max)(10l, widthPx / 12l);
    const LONG verticalInset   = (std::max)(10l, heightPx / 6l);
    const LONG sampleLeft      = opaqueBounds.left + (widthPx * 5l / 8l);
    const LONG sampleRight     = opaqueBounds.right - horizontalInset;
    const LONG sampleTop       = opaqueBounds.top + verticalInset;
    const LONG sampleBottom    = opaqueBounds.bottom - verticalInset;

    return RECT{sampleLeft, sampleTop, (std::max)(sampleLeft + 2l, sampleRight), (std::max)(sampleTop + 2l, sampleBottom)};
}

[[nodiscard]] uint64_t ComputeAverageAdjacentRgbDelta(const DxUi::WindowHostBitmapCapture& capture, const RECT& sampleRect) noexcept
{
    if (sampleRect.right - sampleRect.left < 2 || sampleRect.bottom - sampleRect.top < 1)
    {
        return 0u;
    }

    uint64_t accumulatedDelta = 0u;
    uint64_t sampleCount      = 0u;

    const LONG clampedLeft   = (std::clamp)(sampleRect.left, 0l, static_cast<LONG>(capture.widthPx));
    const LONG clampedTop    = (std::clamp)(sampleRect.top, 0l, static_cast<LONG>(capture.heightPx));
    const LONG clampedRight  = (std::clamp)(sampleRect.right, clampedLeft, static_cast<LONG>(capture.widthPx));
    const LONG clampedBottom = (std::clamp)(sampleRect.bottom, clampedTop, static_cast<LONG>(capture.heightPx));

    for (LONG y = clampedTop; y < clampedBottom; ++y)
    {
        for (LONG x = clampedLeft + 1; x < clampedRight; ++x)
        {
            const size_t currentBase  = (static_cast<size_t>(y) * static_cast<size_t>(capture.widthPx) + static_cast<size_t>(x)) * 4u;
            const size_t previousBase = currentBase - 4u;
            accumulatedDelta += static_cast<uint64_t>(
                std::abs(static_cast<int>(capture.bgraPixels[currentBase + 0u]) - static_cast<int>(capture.bgraPixels[previousBase + 0u])));
            accumulatedDelta += static_cast<uint64_t>(
                std::abs(static_cast<int>(capture.bgraPixels[currentBase + 1u]) - static_cast<int>(capture.bgraPixels[previousBase + 1u])));
            accumulatedDelta += static_cast<uint64_t>(
                std::abs(static_cast<int>(capture.bgraPixels[currentBase + 2u]) - static_cast<int>(capture.bgraPixels[previousBase + 2u])));
            sampleCount += 3u;
        }
    }

    return sampleCount == 0u ? 0u : (accumulatedDelta / sampleCount);
}

[[nodiscard]] uint64_t ComputeAverageAbsoluteRgbDeltaBetweenCaptures(const DxUi::WindowHostBitmapCapture& lhs,
                                                                     const DxUi::WindowHostBitmapCapture& rhs,
                                                                     const RECT& sampleRect) noexcept
{
    if (lhs.widthPx != rhs.widthPx || lhs.heightPx != rhs.heightPx)
    {
        return 0u;
    }

    uint64_t accumulatedDelta = 0u;
    uint64_t sampleCount      = 0u;

    const LONG clampedLeft   = (std::clamp)(sampleRect.left, 0l, static_cast<LONG>(lhs.widthPx));
    const LONG clampedTop    = (std::clamp)(sampleRect.top, 0l, static_cast<LONG>(lhs.heightPx));
    const LONG clampedRight  = (std::clamp)(sampleRect.right, clampedLeft, static_cast<LONG>(lhs.widthPx));
    const LONG clampedBottom = (std::clamp)(sampleRect.bottom, clampedTop, static_cast<LONG>(lhs.heightPx));

    for (LONG y = clampedTop; y < clampedBottom; ++y)
    {
        for (LONG x = clampedLeft; x < clampedRight; ++x)
        {
            const size_t base = (static_cast<size_t>(y) * static_cast<size_t>(lhs.widthPx) + static_cast<size_t>(x)) * 4u;
            accumulatedDelta += static_cast<uint64_t>(std::abs(static_cast<int>(lhs.bgraPixels[base + 0u]) - static_cast<int>(rhs.bgraPixels[base + 0u])));
            accumulatedDelta += static_cast<uint64_t>(std::abs(static_cast<int>(lhs.bgraPixels[base + 1u]) - static_cast<int>(rhs.bgraPixels[base + 1u])));
            accumulatedDelta += static_cast<uint64_t>(std::abs(static_cast<int>(lhs.bgraPixels[base + 2u]) - static_cast<int>(rhs.bgraPixels[base + 2u])));
            sampleCount += 3u;
        }
    }

    return sampleCount == 0u ? 0u : (accumulatedDelta / sampleCount);
}

[[nodiscard]] uint64_t ComputeAverageAbsoluteRgbDeltaToColor(const DxUi::WindowHostBitmapCapture& capture,
                                                             const RECT& sampleRect,
                                                             const D2D1_COLOR_F& color) noexcept
{
    uint64_t accumulatedDelta = 0u;
    uint64_t sampleCount      = 0u;

    const LONG clampedLeft   = (std::clamp)(sampleRect.left, 0l, static_cast<LONG>(capture.widthPx));
    const LONG clampedTop    = (std::clamp)(sampleRect.top, 0l, static_cast<LONG>(capture.heightPx));
    const LONG clampedRight  = (std::clamp)(sampleRect.right, clampedLeft, static_cast<LONG>(capture.widthPx));
    const LONG clampedBottom = (std::clamp)(sampleRect.bottom, clampedTop, static_cast<LONG>(capture.heightPx));

    const int expectedBlue  = static_cast<int>((std::clamp)(color.b, 0.0f, 1.0f) * 255.0f + 0.5f);
    const int expectedGreen = static_cast<int>((std::clamp)(color.g, 0.0f, 1.0f) * 255.0f + 0.5f);
    const int expectedRed   = static_cast<int>((std::clamp)(color.r, 0.0f, 1.0f) * 255.0f + 0.5f);

    for (LONG y = clampedTop; y < clampedBottom; ++y)
    {
        for (LONG x = clampedLeft; x < clampedRight; ++x)
        {
            const size_t base = (static_cast<size_t>(y) * static_cast<size_t>(capture.widthPx) + static_cast<size_t>(x)) * 4u;
            accumulatedDelta += static_cast<uint64_t>(std::abs(static_cast<int>(capture.bgraPixels[base + 0u]) - expectedBlue));
            accumulatedDelta += static_cast<uint64_t>(std::abs(static_cast<int>(capture.bgraPixels[base + 1u]) - expectedGreen));
            accumulatedDelta += static_cast<uint64_t>(std::abs(static_cast<int>(capture.bgraPixels[base + 2u]) - expectedRed));
            sampleCount += 3u;
        }
    }

    return sampleCount == 0u ? 0u : (accumulatedDelta / sampleCount);
}

[[nodiscard]] D2D1_COLOR_F ResolveExpectedAcrylicMenuSlabColor(const DxUi::ThemePalette& theme) noexcept
{
    return DxUi::BlendColor(theme.overlayBackground, theme.headerHovered, theme.dark ? 0.14f : 0.10f);
}

HWND FindOwnedContextMenuPopupWindow(HWND ownerHwnd)
{
    HWND popupHwnd               = nullptr;
    const DWORD currentProcessId = GetCurrentProcessId();
    while ((popupHwnd = FindWindowExW(nullptr, popupHwnd, L"DxUi_ContextMenu", nullptr)) != nullptr)
    {
        DWORD popupProcessId = 0;
        static_cast<void>(GetWindowThreadProcessId(popupHwnd, &popupProcessId));
        if (popupProcessId != currentProcessId)
        {
            continue;
        }

        // The menu creates a hidden 1x1 measurement HWND before its final layout,
        // backdrop capture and initial frame. Drivers must not address that HWND yet.
        if (GetWindow(popupHwnd, GW_OWNER) == ownerHwnd && IsWindowVisible(popupHwnd) != FALSE)
        {
            return popupHwnd;
        }
    }

    return nullptr;
}

HWND WaitForOwnedContextMenuPopupWindow(HWND ownerHwnd, std::chrono::milliseconds timeout = std::chrono::milliseconds(5000))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (HWND popupHwnd = FindOwnedContextMenuPopupWindow(ownerHwnd))
        {
            return popupHwnd;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return nullptr;
}

bool WaitForWindowDestroyed(HWND hwnd, std::chrono::milliseconds timeout);

// Closes the popup the owner has open, if it has one; returns whether there was one.
bool DismissOwnedContextMenuPopupOnce(HWND ownerHwnd) noexcept
{
    const HWND popupHwnd = FindOwnedContextMenuPopupWindow(ownerHwnd);
    if (! popupHwnd)
    {
        return false;
    }

    DWORD_PTR unused = 0;
    static_cast<void>(SendMessageTimeoutW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0, SMTO_ABORTIFHUNG, 1000u, &unused));
    static_cast<void>(WaitForWindowDestroyed(popupHwnd, std::chrono::milliseconds(120)));
    return true;
}

void DismissOwnedContextMenuPopupChain(HWND ownerHwnd) noexcept
{
    for (int attempt = 0; attempt < 16; ++attempt)
    {
        if (! DismissOwnedContextMenuPopupOnce(ownerHwnd))
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(30));
        }
    }
}

// Closes every popup the owner opens within `allowance`, and stops early once the popups it closed are gone for good. Returns
// whether it closed any.
bool DismissOwnedContextMenusForAtMost(HWND ownerHwnd, std::chrono::milliseconds allowance) noexcept
{
    const auto deadline = std::chrono::steady_clock::now() + allowance;
    bool dismissedAny   = false;
    int quietPolls      = 0;
    while (std::chrono::steady_clock::now() < deadline)
    {
        if (DismissOwnedContextMenuPopupOnce(ownerHwnd))
        {
            dismissedAny = true;
            quietPolls   = 0;
            continue;
        }

        if (dismissedAny && ++quietPolls >= 5)
        {
            break;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(30));
    }

    return dismissedAny;
}

// ContextMenu::Show runs its modal loop on the owner thread and returns only when the menu closes, and the driver thread is what
// closes it. A driver that fails before it has a popup to dismiss (the popup can come up later than the driver's wait on a slow
// runner) would leave the owner thread in that loop for good: the test would hang where it should report the failure the driver
// recorded. Declare it first in a driver, before its first wait: when the driver leaves with a failure it keeps closing what
// comes up, for a few seconds. It does nothing when the driver succeeded, which has closed the menu itself. A test that wants to
// know whether it closed a menu passes `dismissedAny`, which is written when the driver leaves.
class DismissMenusIfDriverFails final
{
public:
    DismissMenusIfDriverFails(HWND ownerHwnd, const std::string& driverFailure, bool* dismissedAny = nullptr) noexcept
        : _ownerHwnd(ownerHwnd),
          _driverFailure(driverFailure),
          _dismissedAny(dismissedAny)
    {
    }
    DismissMenusIfDriverFails(const DismissMenusIfDriverFails&)            = delete;
    DismissMenusIfDriverFails& operator=(const DismissMenusIfDriverFails&) = delete;
    DismissMenusIfDriverFails(DismissMenusIfDriverFails&&)                 = delete;
    DismissMenusIfDriverFails& operator=(DismissMenusIfDriverFails&&)      = delete;

    ~DismissMenusIfDriverFails()
    {
        if (_driverFailure.empty())
        {
            return;
        }

        const bool dismissed = DismissOwnedContextMenusForAtMost(_ownerHwnd, std::chrono::seconds(8));
        if (_dismissedAny)
        {
            *_dismissedAny = dismissed;
        }
    }

private:
    HWND _ownerHwnd;
    const std::string& _driverFailure;
    bool* _dismissedAny;
};

[[nodiscard]] bool SendMenuKeyForMenuSuite(HWND popupHwnd, WPARAM virtualKey) noexcept
{
    if (! popupHwnd || IsWindow(popupHwnd) == FALSE)
    {
        return false;
    }

    DWORD_PTR unused = 0;
    return SendMessageTimeoutW(popupHwnd, WM_KEYDOWN, virtualKey, 0, SMTO_ABORTIFHUNG, 1000u, &unused) != 0;
}

HWND FindOwnedContextMenuPopupWindowByFirstItemText(HWND ownerHwnd, std::wstring_view firstItemText)
{
    HWND popupHwnd               = nullptr;
    const DWORD currentProcessId = GetCurrentProcessId();
    while ((popupHwnd = FindWindowExW(nullptr, popupHwnd, L"DxUi_ContextMenu", nullptr)) != nullptr)
    {
        DWORD popupProcessId = 0;
        static_cast<void>(GetWindowThreadProcessId(popupHwnd, &popupProcessId));
        if (popupProcessId != currentProcessId)
        {
            continue;
        }

        // Visibility is published after final positioning and the initial frame.
        // Reading item text alone can succeed on the temporary measurement HWND.
        if (GetWindow(popupHwnd, GW_OWNER) != ownerHwnd || IsWindowVisible(popupHwnd) == FALSE)
        {
            continue;
        }

        std::wstring popupFirstItemText;
        if (DxUi::DebugGetContextMenuPopupItemText(popupHwnd, 0u, popupFirstItemText) && popupFirstItemText == firstItemText)
        {
            return popupHwnd;
        }
    }

    return nullptr;
}

HWND WaitForOwnedContextMenuPopupWindowByFirstItemText(HWND ownerHwnd,
                                                       std::wstring_view firstItemText,
                                                       std::chrono::milliseconds timeout = std::chrono::milliseconds(5000))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (HWND popupHwnd = FindOwnedContextMenuPopupWindowByFirstItemText(ownerHwnd, firstItemText))
        {
            return popupHwnd;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return nullptr;
}

bool WaitForWindowDestroyed(HWND hwnd, std::chrono::milliseconds timeout = std::chrono::milliseconds(800))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (IsWindow(hwnd) == FALSE)
        {
            return true;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return IsWindow(hwnd) == FALSE;
}

bool WaitForFocusedWindow(HWND hwnd, std::chrono::milliseconds timeout = std::chrono::milliseconds(800))
{
    return WaitForDxUiThreadFocus(hwnd, static_cast<DWORD>(timeout.count()));
}

void TestContextMenuDebugStateProbeBoundsWedgedWindowThread()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 220, SWP_NOZORDER);
    if (! TryActivateDxUiTestWindow(ownerWindow.Hwnd()))
    {
        SkipDxUiTest("DxUi menu debug-state timeout requires an interactive desktop");
        return;
    }

    wil::unique_event_nothrow handlerEntered;
    handlerEntered.reset(CreateEventW(nullptr, TRUE, FALSE, nullptr));
    Require(handlerEntered != nullptr, "menu debug-state timeout test creates the handler-entered event");
    wil::unique_event_nothrow releaseHandler;
    releaseHandler.reset(CreateEventW(nullptr, TRUE, FALSE, nullptr));
    Require(releaseHandler != nullptr, "menu debug-state timeout test creates the release event");

    std::string driverFailure;
    bool unwedgedStateObserved = false;
    bool wedgedProbeFailed     = false;
    std::chrono::milliseconds wedgedElapsed{};
    std::thread releaser([&]
    {
        if (WaitForSingleObject(handlerEntered.get(), 3000u) == WAIT_OBJECT_0)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(1200));
        }
        static_cast<void>(SetEvent(releaseHandler.get()));
    });
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });
        const HWND popupHwnd    = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"State probe");
        if (! popupHwnd)
        {
            driverFailure = "menu debug-state timeout popup appears";
            return;
        }

        ContextMenuPopupDebugState state{};
        unwedgedStateObserved = DebugGetContextMenuPopupState(popupHwnd, state) && state.itemTexts.size() == 1u && state.itemTexts[0u] == L"State probe";
        if (! unwedgedStateObserved)
        {
            driverFailure = "unwedged menu debug-state probe returns the correct popup state";
            return;
        }

        DebugSetContextMenuStateProbeStallForTest(handlerEntered.get(), releaseHandler.get());
        const auto started = std::chrono::steady_clock::now();
        ContextMenuPopupDebugState wedgedState{};
        wedgedProbeFailed = ! DebugGetContextMenuPopupState(popupHwnd, wedgedState);
        wedgedElapsed     = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - started);
    });

    const std::vector<MenuFlyoutItem> items{{.text = L"State probe", .enabled = true, .commandId = 91501}};
    const POINT menuAnchor          = ClientScreenPointForTest(ownerWindow.Hwnd(), 24, 60, "menu debug-state timeout anchor converts to screen coordinates");
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), menuAnchor, items, ownerWindow.Host().GetTheme());
    driver.join();
    releaser.join();
    DebugSetContextMenuStateProbeStallForTest(nullptr, nullptr);

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(unwedgedStateObserved, "unwedged menu debug-state probe returns the correct popup state");
    Require(wedgedProbeFailed, "wedged menu debug-state probe returns failure");
    Require(wedgedElapsed >= std::chrono::milliseconds(900) && wedgedElapsed < std::chrono::milliseconds(1800),
            "wedged menu debug-state probe returns within the bounded test timeout");
    Require(! result.has_value(), "dismissed menu debug-state timeout popup returns no command");
}

// A probe sent to a popup whose thread has stopped answering (wedged here in the state probe's handler for four seconds) fails
// within its three-second bound instead of holding its driver for good, and a capture answers again once the thread runs. Before
// the bound, a capture whose popup thread never answered held the driver, and so the open menu, until the watchdog ended the run.
void TestContextMenuDebugCaptureBoundsWedgedWindowThread()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 220, SWP_NOZORDER);
    if (! TryActivateDxUiTestWindow(ownerWindow.Hwnd()))
    {
        SkipDxUiTest("DxUi menu debug-probe timeout requires an interactive desktop");
        return;
    }

    wil::unique_event_nothrow handlerEntered;
    handlerEntered.reset(CreateEventW(nullptr, TRUE, FALSE, nullptr));
    Require(handlerEntered != nullptr, "menu debug-probe timeout test creates the handler-entered event");
    wil::unique_event_nothrow releaseHandler;
    releaseHandler.reset(CreateEventW(nullptr, TRUE, FALSE, nullptr));
    Require(releaseHandler != nullptr, "menu debug-probe timeout test creates the release event");

    std::string driverFailure;
    bool wedgedCaptureFailed      = false;
    bool unwedgedCaptureSucceeded = false;
    std::chrono::milliseconds wedgedElapsed{};
    std::thread releaser([&]
    {
        if (WaitForSingleObject(handlerEntered.get(), 3000u) == WAIT_OBJECT_0)
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(4000));
        }
        static_cast<void>(SetEvent(releaseHandler.get()));
    });
    std::thread wedger;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });
        const HWND popupHwnd    = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Capture probe");
        WindowHostBitmapCapture capture{};
        if (! popupHwnd || ! WaitForContextMenuPopupBitmapCapture(popupHwnd, capture))
        {
            driverFailure = "menu debug-probe timeout popup appears and answers a capture";
            return;
        }

        // A state probe whose handler waits for the release wedges the popup thread; the capture is sent while it waits.
        DebugSetContextMenuStateProbeStallForTest(handlerEntered.get(), releaseHandler.get());
        wedger = std::thread([popupHwnd]
        {
            ContextMenuPopupDebugState state{};
            static_cast<void>(DebugGetContextMenuPopupState(popupHwnd, state));
        });
        if (WaitForSingleObject(handlerEntered.get(), 3000u) != WAIT_OBJECT_0)
        {
            driverFailure = "the state probe wedges the popup thread";
            return;
        }
        const auto started       = std::chrono::steady_clock::now();
        wedgedCaptureFailed      = ! DebugCaptureContextMenuPopupBitmap(popupHwnd, capture);
        wedgedElapsed            = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - started);
        unwedgedCaptureSucceeded = WaitForContextMenuPopupBitmapCapture(popupHwnd, capture);
    });

    const std::vector<MenuFlyoutItem> items{{.text = L"Capture probe", .enabled = true, .commandId = 91502}};
    const POINT menuAnchor          = ClientScreenPointForTest(ownerWindow.Hwnd(), 24, 60, "menu debug-probe timeout anchor converts to screen coordinates");
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), menuAnchor, items, ownerWindow.Host().GetTheme());
    driver.join();
    if (wedger.joinable())
    {
        wedger.join();
    }
    releaser.join();
    DebugSetContextMenuStateProbeStallForTest(nullptr, nullptr);

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(wedgedCaptureFailed, "a capture sent to a wedged popup thread returns failure");
    Require(wedgedElapsed >= std::chrono::milliseconds(2900) && wedgedElapsed < std::chrono::milliseconds(3900),
            "a capture sent to a wedged popup thread returns at its three-second bound, before the thread is released");
    Require(unwedgedCaptureSucceeded, "a capture answers again once the popup thread runs");
    Require(! result.has_value(), "dismissed menu debug-probe timeout popup returns no command");
}

// A driver whose wait for its popup timed out returns without one to dismiss, and a popup that merely came up late then stays
// open under the owner thread's modal loop for good. This driver gives up at once, before its popup exists, as that driver did:
// the guard every driver starts with closes the menu when it comes up, so the failure is reported and the owner thread returns.
// Without the guard this test never returns, and the watchdog ends the run naming it.
void TestMenuDriverThatFailsBeforeItsPopupComesUpStillClosesTheMenu()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<MenuFlyoutItem> items{{.text = L"Late popup", .enabled = true, .commandId = 91601}};
    std::string driverFailure;
    bool closedByGuard = false;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure, &closedByGuard);
        driverFailure = "the driver gave up before its popup came up";
    });

    const auto started              = std::chrono::steady_clock::now();
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, ownerWindow.Host().GetTheme());
    const auto elapsed              = std::chrono::steady_clock::now() - started;
    driver.join();

    Require(! driverFailure.empty(), "the failing driver recorded its failure for the test to report");
    Require(closedByGuard, "the guard of the failed driver closed the menu that came up after the driver gave up");
    Require(! result.has_value(), "the menu a failed driver left open is closed without invoking a command");
    Require(elapsed < std::chrono::seconds(8), "the menu a failed driver left open is closed within the guard's allowance");
}

void TestModalMenuDispatchesUnrelatedTimerWithSubmenuId()
{
    using namespace DxUi;

    if (! DxUiTestWindowsCanActivateFlag())
    {
        SkipDxUiTest("the modal timer-dispatch regression opens a capturing menu and is limited to the interactive Menu lane");
        return;
    }

    AttachedHostWindow ownerWindow;
    const std::vector<MenuFlyoutItem> items{{.text = L"Timer dispatch", .commandId = 91602}};
    size_t timerDispatchCount = 0u;
    bool dismissPosted        = false;
    bool fallbackFired        = false;
    ownerWindow.SetApplicationMessageHandler([&](UINT message, WPARAM wParam, LPARAM, LRESULT& result)
    {
        if (message != WM_TIMER)
        {
            return false;
        }

        if (const HWND popup = FindOwnedContextMenuPopupWindow(ownerWindow.Hwnd()))
        {
            if (wParam == 1u)
            {
                ++timerDispatchCount;
                dismissPosted = PostMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0) != FALSE;
            }
            else if (wParam == 2u)
            {
                // The distinct timer keeps a regression from leaving modal capture held until the test watchdog fires.
                fallbackFired = true;
                static_cast<void>(PostMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0));
            }
        }
        result = 0;
        return true;
    });
    const auto clearHandler = wil::scope_exit([&]() noexcept { ownerWindow.SetApplicationMessageHandler({}); });

    const UINT_PTR timerId = SetTimer(ownerWindow.Hwnd(), 1u, 50u, nullptr);
    Require(timerId == 1u, "the owner installs timer id 1 for the modal-loop regression");
    const auto killTimer           = wil::scope_exit([&]() noexcept { KillTimer(ownerWindow.Hwnd(), timerId); });
    const UINT_PTR fallbackTimerId = SetTimer(ownerWindow.Hwnd(), 2u, 750u, nullptr);
    Require(fallbackTimerId == 2u, "the owner installs a distinct bounded-dismissal timer");
    const auto killFallbackTimer = wil::scope_exit([&]() noexcept { KillTimer(ownerWindow.Hwnd(), fallbackTimerId); });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, ownerWindow.Host().GetTheme());
    Require(timerDispatchCount >= 1u, "the modal loop dispatches an unrelated window timer that shares submenu id 1");
    Require(! fallbackFired, "timer id 1 dispatches before the bounded-dismissal fallback");
    Require(dismissPosted, "the dispatched timer can post Escape to close the modal menu");
    Require(! result.has_value(), "the timer-dismissed modal menu invokes no command");
}

void TestModalMenuDismissesOnSentCancellationAndDeactivation()
{
    using namespace DxUi;

    if (! DxUiTestWindowsCanActivateFlag())
    {
        SkipDxUiTest("modal cancellation and deactivation require a capturing menu and are limited to the interactive Menu lane");
        return;
    }

    struct SentDismissal
    {
        UINT message;
        WPARAM wParam;
        const char* label;
    };
    constexpr SentDismissal cases[] = {{WM_ACTIVATEAPP, FALSE, "WM_ACTIVATEAPP"},
                                       {WM_ACTIVATE, WA_INACTIVE, "WM_ACTIVATE"},
                                       {WM_NCACTIVATE, FALSE, "WM_NCACTIVATE"},
                                       {WM_CANCELMODE, 0, "WM_CANCELMODE"}};
    for (const SentDismissal& test : cases)
    {
        AttachedHostWindow ownerWindow;
        const std::wstring label = std::format(L"Sent dismissal {}", test.message);
        const std::vector<MenuFlyoutItem> items{{.text = label, .commandId = 91603}};
        std::string driverFailure;
        std::thread driver([&]
        {
            const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
            const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), label);
            if (! popup)
            {
                driverFailure = "the modal popup appears before the sent dismissal";
                return;
            }

            DWORD_PTR unused = 0;
            if (SendMessageTimeoutW(popup, test.message, test.wParam, 0, SMTO_ABORTIFHUNG, 1000u, &unused) == 0)
            {
                driverFailure = std::format("{} reaches the modal popup", test.label);
                return;
            }
            const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
            while (IsWindow(popup) != FALSE && std::chrono::steady_clock::now() < deadline)
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
            if (IsWindow(popup) != FALSE)
                driverFailure = std::format("{} dismisses the synchronous menu", test.label);
        });

        const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, ownerWindow.Host().GetTheme());
        driver.join();
        Require(driverFailure.empty(), driverFailure.c_str());
        Require(! result.has_value(), std::format("{} dismisses without invoking a command", test.label).c_str());
    }
}

void TestEmbeddedViewerContextMenuNativeConversionFiltersStandaloneCommands()
{
    using namespace DxUi;

    wil::unique_hmenu menu{CreatePopupMenu()};
    Require(menu != nullptr, "embedded viewer context-menu conversion creates a native popup menu");

    wil::unique_hmenu standaloneSubmenu{CreatePopupMenu()};
    Require(standaloneSubmenu != nullptr, "embedded viewer context-menu conversion creates a standalone-only submenu");
    Require(AppendMenuW(standaloneSubmenu.get(), MF_STRING, 91701u, L"&Standalone action\tAlt+S") != FALSE,
            "embedded viewer context-menu conversion populates a submenu that should become empty after filtering");

    Require(AppendMenuW(menu.get(), MF_SEPARATOR, 0, nullptr) != FALSE, "embedded viewer context-menu conversion can start with a separator");
    Require(AppendMenuW(menu.get(), MF_STRING, 91702u, L"&Open standalone\tCtrl+O") != FALSE,
            "embedded viewer context-menu conversion populates a standalone-only command");
    Require(AppendMenuW(menu.get(), MF_SEPARATOR, 0, nullptr) != FALSE, "embedded viewer context-menu conversion can trim interior separators");
    Require(AppendMenuW(menu.get(), MF_STRING, 91703u, L"&Copy path\tCtrl+C") != FALSE,
            "embedded viewer context-menu conversion populates an embedded-safe command");
    Require(AppendMenuW(menu.get(), MF_POPUP | MF_STRING, reinterpret_cast<UINT_PTR>(standaloneSubmenu.get()), L"&Standalone") != FALSE,
            "embedded viewer context-menu conversion attaches the standalone-only submenu");
    static_cast<void>(standaloneSubmenu.release());
    Require(AppendMenuW(menu.get(), MF_SEPARATOR, 0, nullptr) != FALSE, "embedded viewer context-menu conversion can trim trailing separators");
    Require(AppendMenuW(menu.get(), MF_STRING | MF_CHECKED, 91704u, L"Show &metadata\tF4") != FALSE,
            "embedded viewer context-menu conversion preserves checked embedded-safe commands");

    static constexpr std::array<int, 2> kPreviewContextMenuExcludedCommandIds{{91701, 91702}};
    const NativeMenuFlyoutOptions options{
        .includeAcceleratorText = false,
        .omitEmptySubmenus      = true,
        .trimSeparators         = true,
        .excludedCommandIds     = kPreviewContextMenuExcludedCommandIds,
    };

    const std::vector<MenuFlyoutItem> items = ConvertNativeHMenuToFlyoutItems(menu.get(), options);
    Require(items.size() == 3u, "embedded viewer context-menu conversion removes standalone-only commands, empty submenus, and outer separator runs");
    Require(items[0].text == L"Copy path", "embedded viewer context-menu conversion strips mnemonics from retained command text");
    Require(items[0].commandId == 91703, "embedded viewer context-menu conversion preserves retained command IDs");
    Require(items[0].acceleratorText.empty(), "embedded viewer context-menu conversion suppresses standalone keyboard shortcut text");
    Require(items[1].kind == MenuItemKind::Separator, "embedded viewer context-menu conversion preserves one intentional separator between retained groups");
    Require(items[2].text == L"Show metadata", "embedded viewer context-menu conversion keeps the second embedded-safe command");
    Require(items[2].kind == MenuItemKind::Toggle && items[2].checked, "embedded viewer context-menu conversion preserves checked state");
}

void RunMenuDismissalKeyScenario(UINT message, WPARAM virtualKey, const char* appearExpectation, const char* dismissExpectation, const char* focusExpectation)
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 240, SWP_NOZORDER);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOW);
    ownerWindow.PumpMessages();

    wil::unique_hwnd focusedChild{CreateWindowExW(0,
                                                  L"BUTTON",
                                                  L"DismissalTarget",
                                                  WS_CHILD | WS_VISIBLE | WS_TABSTOP,
                                                  12,
                                                  80,
                                                  140,
                                                  28,
                                                  ownerWindow.Hwnd(),
                                                  nullptr,
                                                  GetModuleHandleW(nullptr),
                                                  nullptr)};
    Require(focusedChild != nullptr, "dismissal validation creates a focusable child control");

    wil::unique_hmenu menu{CreateMenu()};
    Require(menu != nullptr, "dismissal validation creates a top-level native menu");

    wil::unique_hmenu filePopup{CreatePopupMenu()};
    Require(filePopup != nullptr, "dismissal validation creates a native popup menu");
    Require(AppendMenuW(filePopup.get(), MF_STRING, 3701u, L"&Open") != FALSE, "dismissal validation populates the native popup menu");
    Require(AppendMenuW(filePopup.get(), MF_STRING, 3702u, L"&Close") != FALSE, "dismissal validation populates a second native popup item");
    Require(AppendMenuW(menu.get(), MF_POPUP, reinterpret_cast<UINT_PTR>(filePopup.get()), L"&File") != FALSE,
            "dismissal validation attaches the popup menu to the native menu bar");
    static_cast<void>(filePopup.release());

    NativeMenuBarHost menuBarHost;
    Require(menuBarHost.Attach(GetModuleHandleW(nullptr), ownerWindow.Hwnd(), menu.get()), "dismissal validation attaches a native menu bar host");
    ownerWindow.PumpMessages();

    if (! TryActivateDxUiTestWindow(ownerWindow.Hwnd()))
    {
        SkipDxUiTest("DxUi menu popup requires an interactive desktop for native menu-bar focus dismissal");
        return;
    }
    static_cast<void>(SetFocus(focusedChild.get()));
    Require(WaitForFocusedWindow(focusedChild.get()), "dismissal validation starts with focus on the child control");

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = appearExpectation;
            return;
        }

        PostMessageW(popupHwnd, message, virtualKey, 0);
        if (! WaitForWindowDestroyed(popupHwnd))
        {
            driverFailure = dismissExpectation;
        }
    });

    Require(menuBarHost.FocusFirstItem(), "dismissal validation enters native menu-bar mode");
    static_cast<void>(SendMessageW(menuBarHost.GetHwnd(), WM_KEYDOWN, VK_DOWN, 0));
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(WaitForFocusedWindow(focusedChild.get()), focusExpectation);
}

void TestSplitButtonContextMenuSentMouseMessagesHoverAndOutsideDismiss()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 420, 260, SWP_NOZORDER);
    if (! TryActivateDxUiTestWindow(ownerWindow.Hwnd()))
    {
        SkipDxUiTest("DxUi menu popup requires an interactive desktop for split-button outside-dismiss routing");
        return;
    }

    const std::vector<MenuFlyoutItem> items{
        {.text = L"Find Now", .enabled = true, .commandId = 4101},
        {.text = L"Refine - Intersect with Found Items", .enabled = true, .commandId = 4102},
        {.text = L"Refine - Subtract from Found Items", .enabled = true, .commandId = 4103},
        {.text = L"Append to Found Items", .enabled = true, .commandId = 4104},
    };
    ownerWindow.PumpMessages();
    const POINT menuAnchor = ClientScreenPointForTest(ownerWindow.Hwnd(), 24, 60, "split-button-style menu anchor converts to screen coordinates");

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Find Now");
        if (! popupHwnd)
        {
            driverFailure = "split-button opens the owned DxUi context menu";
            return;
        }

        ScopedMenuPointerFixture pointerFixture(popupHwnd);
        if (! pointerFixture.WaitForCapture())
        {
            driverFailure = "sent-message popup establishes modal input capture before interaction";
            return;
        }

        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f;
        }, popupState))
        {
            driverFailure = "split-button popup exposes geometry before live pointer routing validation";
            return;
        }

        D2D1_RECT_F refineRectDip{};
        if (! WaitForContextMenuPopupItemRect(popupHwnd, 1u, refineRectDip))
        {
            driverFailure = "split-button popup exposes the Refine row bounds";
            return;
        }

        POINT refineCenter{
            static_cast<LONG>(std::lround((refineRectDip.left + refineRectDip.right) * 0.5f * static_cast<float>(popupState.dpi) /
                                          static_cast<float>(USER_DEFAULT_SCREEN_DPI))),
            static_cast<LONG>(std::lround((refineRectDip.top + refineRectDip.bottom) * 0.5f * static_cast<float>(popupState.dpi) /
                                          static_cast<float>(USER_DEFAULT_SCREEN_DPI))),
        };
        if (ClientToScreen(popupHwnd, &refineCenter) == FALSE)
        {
            driverFailure = "split-button popup Refine row converts to screen coordinates";
            return;
        }

        // Match real and sent points so a later OS-generated move cannot undo the
        // hover before its paint is observed. The sent down/up still prove invocation.
        if (! pointerFixture.AlignCursor(refineCenter))
        {
            driverFailure = "sent-message interactive fixture aligns the physical cursor";
            return;
        }
        static_cast<void>(SendCapturedMouseMessageForMenuSuite(popupHwnd, WM_MOUSEMOVE, 0, refineCenter));

        ContextMenuPopupItemPaintDebugState paintState{};
        const auto hoverDeadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(800);
        bool hoverObserved       = false;
        const auto observeHover  = [&]() noexcept
        {
            ContextMenuPopupDebugState hoverState{};
            return DebugGetContextMenuPopupState(popupHwnd, hoverState) && hoverState.hoveredIndex == std::optional<size_t>{1u} &&
                   DebugGetContextMenuPopupItemPaint(popupHwnd, 1u, paintState) && paintState.usesHighlightFill;
        };
        hoverObserved = observeHover();
        do
        {
            if (hoverObserved)
            {
                break;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            hoverObserved = observeHover();
        } while (std::chrono::steady_clock::now() < hoverDeadline);
        if (! hoverObserved)
        {
            driverFailure = "sent-message outside-dismiss fixture paints the Refine hover before dismissal";
            return;
        }

        POINT outsidePoint = ownerWindow.Host().DipPointToScreenPoint(D2D1::Point2F(32.0f, 196.0f));
        RECT popupRect{};
        if (GetWindowRect(popupHwnd, &popupRect) != FALSE && PtInRect(&popupRect, outsidePoint) != FALSE)
        {
            outsidePoint = ownerWindow.Host().DipPointToScreenPoint(D2D1::Point2F(388.0f, 196.0f));
        }
        static_cast<void>(SendCapturedMouseMessageForMenuSuite(popupHwnd, WM_LBUTTONDOWN, MK_LBUTTON, outsidePoint));
        if (! WaitForWindowDestroyed(popupHwnd))
        {
            driverFailure = "outside click dismisses the split-button popup";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), menuAnchor, items, ownerWindow.Host().GetTheme());
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "outside-dismissed split-button-style popup returns no command");
}

void TestSplitButtonContextMenuSentMouseMessagesHoverAndInvokeImmediately()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 140, 140, 460, 280, SWP_NOZORDER);
    if (! TryActivateDxUiTestWindow(ownerWindow.Hwnd()))
    {
        SkipDxUiTest("DxUi menu popup requires an interactive desktop for split-button invoke routing");
        return;
    }

    const std::vector<MenuFlyoutItem> items{
        {.text = L"Find Now", .enabled = true, .commandId = 4201},
        {.text = L"Refine - Intersect with Found Items", .enabled = true, .commandId = 4202},
        {.text = L"Refine - Subtract from Found Items", .enabled = true, .commandId = 4203},
        {.text = L"Append to Found Items", .enabled = true, .commandId = 4204},
    };
    ownerWindow.PumpMessages();
    const POINT menuAnchor = ClientScreenPointForTest(ownerWindow.Hwnd(), 24, 60, "sent-message menu anchor converts to screen coordinates");

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Find Now");
        if (! popupHwnd)
        {
            driverFailure = "sent-message split-button popup opens";
            return;
        }

        ScopedMenuPointerFixture pointerFixture(popupHwnd);
        if (! pointerFixture.WaitForCapture())
        {
            driverFailure = "sent-message popup establishes modal input capture before interaction";
            return;
        }

        ContextMenuPopupDebugState popupState{};
        D2D1_RECT_F refineRectDip{};
        if (! WaitForContextMenuPopupState(popupHwnd,
                                           [](const ContextMenuPopupDebugState& state) noexcept
        { return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f; },
                                           popupState) ||
            ! WaitForContextMenuPopupItemRect(popupHwnd, 1u, refineRectDip))
        {
            driverFailure = "sent-message split-button popup exposes the Refine row";
            return;
        }

        POINT refineCenter{
            static_cast<LONG>(std::lround((refineRectDip.left + refineRectDip.right) * 0.5f * static_cast<float>(popupState.dpi) /
                                          static_cast<float>(USER_DEFAULT_SCREEN_DPI))),
            static_cast<LONG>(std::lround((refineRectDip.top + refineRectDip.bottom) * 0.5f * static_cast<float>(popupState.dpi) /
                                          static_cast<float>(USER_DEFAULT_SCREEN_DPI))),
        };
        if (ClientToScreen(popupHwnd, &refineCenter) == FALSE)
        {
            driverFailure = "sent-message split-button Refine row converts to screen coordinates";
            return;
        }

        // Match real and sent points so a later OS-generated move cannot undo the
        // hover before its paint is observed. The sent down/up still prove invocation.
        if (! pointerFixture.AlignCursor(refineCenter))
        {
            driverFailure = "sent-message interactive fixture aligns the physical cursor";
            return;
        }
        static_cast<void>(SendCapturedMouseMessageForMenuSuite(popupHwnd, WM_MOUSEMOVE, 0, refineCenter));

        ContextMenuPopupItemPaintDebugState paintState{};
        const auto hoverDeadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(800);
        bool hoverObserved       = false;
        const auto observeHover  = [&]() noexcept
        {
            ContextMenuPopupDebugState hoverState{};
            return DebugGetContextMenuPopupState(popupHwnd, hoverState) && hoverState.hoveredIndex == std::optional<size_t>{1u} &&
                   DebugGetContextMenuPopupItemPaint(popupHwnd, 1u, paintState) && paintState.usesHighlightFill;
        };
        hoverObserved = observeHover();
        do
        {
            if (hoverObserved)
            {
                break;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            hoverObserved = observeHover();
        } while (std::chrono::steady_clock::now() < hoverDeadline);
        if (! hoverObserved)
        {
            ContextMenuPopupDebugState finalState{};
            static_cast<void>(DebugGetContextMenuPopupState(popupHwnd, finalState));
            RECT popupRect{};
            static_cast<void>(GetWindowRect(popupHwnd, &popupRect));
            driverFailure = std::format("sent WM_MOUSEMOVE over the split-button popup Refine row produces visible hover highlight "
                                        "(hovered={}, keyboard={}, center=({},{}), popup=({},{} {}x{}), row=({:.1f},{:.1f},{:.1f},{:.1f}), renders={})",
                                        finalState.hoveredIndex.has_value() ? static_cast<long long>(finalState.hoveredIndex.value()) : -1ll,
                                        finalState.keyboardIndex.has_value() ? static_cast<long long>(finalState.keyboardIndex.value()) : -1ll,
                                        refineCenter.x,
                                        refineCenter.y,
                                        popupRect.left,
                                        popupRect.top,
                                        popupRect.right - popupRect.left,
                                        popupRect.bottom - popupRect.top,
                                        refineRectDip.left,
                                        refineRectDip.top,
                                        refineRectDip.right,
                                        refineRectDip.bottom,
                                        finalState.renderCount);
            return;
        }

        static_cast<void>(SendCapturedMouseMessageForMenuSuite(popupHwnd, WM_LBUTTONDOWN, MK_LBUTTON, refineCenter));
        static_cast<void>(SendCapturedMouseMessageForMenuSuite(popupHwnd, WM_LBUTTONUP, 0, refineCenter));

        if (! WaitForWindowDestroyed(popupHwnd, std::chrono::milliseconds(800)))
        {
            driverFailure = "sent split-button menu item click closes the popup immediately";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), menuAnchor, items, ownerWindow.Host().GetTheme());
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(result == std::optional<int>{4202}, "sent split-button-style menu item click invokes immediately without a later activation poke");
}

constexpr UINT kMenuOwnerMessageFloodTestMessage    = WM_APP + 0x53Du;
constexpr UINT_PTR kMenuOwnerMessageFloodSubclassId = 0x53Du;

LRESULT CALLBACK MenuOwnerMessageFloodTestSubclassProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, UINT_PTR, DWORD_PTR) noexcept
{
    if (message == kMenuOwnerMessageFloodTestMessage)
    {
        Sleep(1);
        return 0;
    }

    return DefSubclassProc(hwnd, message, wParam, lParam);
}

void TestSplitButtonContextMenuOwnerMessageFloodDoesNotStarvePointerInput()
{
    using namespace DxUi;

    // Retain bounded routing evidence for remote failures without changing input, timeout or paint assertions.
    struct Trace final
    {
        std::array<std::array<wchar_t, 2048>, 32> rows{};
        size_t count = 0;
    };
    static thread_local Trace* activeTrace = nullptr;
    auto trace                             = std::make_unique<Trace>();
    const auto previousSink                = Diagnostics::sink;
    Trace* const previousTrace             = activeTrace;
    activeTrace                            = trace.get();
    Diagnostics::sink                      = [](std::wstring_view, std::wstring_view message) noexcept
    {
        // Preserve input evidence; repeated state probes/paint/teardown must not evict the failure's pointer route.
        if (! activeTrace || message.find(L"menu.") == std::wstring_view::npos ||
            (message.find(L"menu.pointer") == std::wstring_view::npos && message.find(L"WM_MOUSE") == std::wstring_view::npos &&
             message.find(L"menu.loop-start") == std::wstring_view::npos && message.find(L"menu.show-begin") == std::wstring_view::npos))
            return;
        auto& row           = activeTrace->rows[activeTrace->count++ % activeTrace->rows.size()];
        const size_t length = (std::min)(message.size(), row.size() - 1);
        std::copy_n(message.data(), length, row.data());
        row[length] = 0;
    };
    const auto restoreTrace = wil::scope_exit([&]() noexcept
    {
        Diagnostics::sink = previousSink;
        activeTrace       = previousTrace;
    });

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 140, 140, 460, 280, SWP_NOZORDER);
    if (! TryActivateDxUiTestWindow(ownerWindow.Hwnd()))
    {
        SkipDxUiTest("DxUi menu popup requires an interactive desktop for owner-message-flood routing");
        return;
    }

    Require(SetWindowSubclass(ownerWindow.Hwnd(), MenuOwnerMessageFloodTestSubclassProc, kMenuOwnerMessageFloodSubclassId, 0) != FALSE,
            "owner-message-flood validation subclasses the owner window");
    const auto restoreOwnerWndProc = wil::scope_exit([&]() noexcept
    {
        static_cast<void>(RemoveWindowSubclass(ownerWindow.Hwnd(), MenuOwnerMessageFloodTestSubclassProc, kMenuOwnerMessageFloodSubclassId));
        MSG drainMessage{};
        while (PeekMessageW(&drainMessage, ownerWindow.Hwnd(), kMenuOwnerMessageFloodTestMessage, kMenuOwnerMessageFloodTestMessage, PM_REMOVE) != FALSE)
        {
        }
    });

    const std::vector<MenuFlyoutItem> items{
        {.text = L"Find Now", .enabled = true, .commandId = 4201},
        {.text = L"Refine - Intersect with Found Items", .enabled = true, .commandId = 4202},
        {.text = L"Refine - Subtract from Found Items", .enabled = true, .commandId = 4203},
        {.text = L"Append to Found Items", .enabled = true, .commandId = 4204},
    };
    ownerWindow.PumpMessages();
    const POINT menuAnchor = ClientScreenPointForTest(ownerWindow.Hwnd(), 24, 60, "owner-message-flood menu anchor converts to screen coordinates");

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Find Now");
        if (! popupHwnd)
        {
            driverFailure = "owner-message-flood split-button popup opens";
            return;
        }

        ScopedMenuPointerFixture pointerFixture(popupHwnd);
        if (! pointerFixture.WaitForCapture())
        {
            driverFailure = "owner-message-flood popup establishes modal input capture before traffic starts";
            return;
        }

        ContextMenuPopupDebugState popupState{};
        D2D1_RECT_F refineRectDip{};
        if (! WaitForContextMenuPopupState(popupHwnd,
                                           [](const ContextMenuPopupDebugState& state) noexcept
        { return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f; },
                                           popupState) ||
            ! WaitForContextMenuPopupItemRect(popupHwnd, 1u, refineRectDip))
        {
            driverFailure = "owner-message-flood split-button popup exposes the Refine row";
            return;
        }

        POINT refineCenter{
            static_cast<LONG>(std::lround((refineRectDip.left + refineRectDip.right) * 0.5f * static_cast<float>(popupState.dpi) /
                                          static_cast<float>(USER_DEFAULT_SCREEN_DPI))),
            static_cast<LONG>(std::lround((refineRectDip.top + refineRectDip.bottom) * 0.5f * static_cast<float>(popupState.dpi) /
                                          static_cast<float>(USER_DEFAULT_SCREEN_DPI))),
        };
        if (ClientToScreen(popupHwnd, &refineCenter) == FALSE)
        {
            driverFailure = "owner-message-flood split-button Refine row converts to screen coordinates";
            return;
        }
        if (! pointerFixture.AlignCursor(refineCenter))
        {
            driverFailure = "owner-message-flood interactive fixture aligns the physical cursor";
            return;
        }
        static constexpr int kFloodMessageCount = 2000;
        for (int i = 0; i < kFloodMessageCount; ++i)
        {
            if (PostMessageW(ownerWindow.Hwnd(), kMenuOwnerMessageFloodTestMessage, 0, 0) == FALSE)
            {
                driverFailure = "owner-message-flood posts owner-window traffic";
                return;
            }
        }

        if (! PostCapturedMouseMessageForMenuSuite(popupHwnd, WM_MOUSEMOVE, 0, refineCenter))
        {
            driverFailure = "owner-message-flood posts popup mouse move";
            return;
        }

        ContextMenuPopupItemPaintDebugState paintState{};
        const auto hoverDeadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(800);
        bool hoverObserved       = false;
        const auto observeHover  = [&]() noexcept
        {
            ContextMenuPopupDebugState hoverState{};
            return DebugGetContextMenuPopupState(popupHwnd, hoverState) && hoverState.hoveredIndex == std::optional<size_t>{1u} &&
                   DebugGetContextMenuPopupItemPaint(popupHwnd, 1u, paintState) && paintState.usesHighlightFill;
        };
        do
        {
            hoverObserved = observeHover();
            if (hoverObserved)
            {
                break;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(25));
        } while (std::chrono::steady_clock::now() < hoverDeadline);
        if (! hoverObserved)
        {
            ContextMenuPopupDebugState finalState{};
            const bool stateRead = DebugGetContextMenuPopupState(popupHwnd, finalState);
            driverFailure = std::format("owner-window message flood does not starve popup hover highlight: state={} visible={} capture={} dpi={} hover={} "
                                        "fill={} renders={} point=({}, {})",
                                        stateRead,
                                        IsWindowVisible(popupHwnd) != FALSE,
                                        pointerFixture.HasCapture(),
                                        finalState.dpi,
                                        finalState.hoveredIndex.has_value() ? static_cast<int>(finalState.hoveredIndex.value()) : -1,
                                        paintState.usesHighlightFill,
                                        finalState.renderCount,
                                        refineCenter.x,
                                        refineCenter.y);
            return;
        }

        if (! PostCapturedMouseMessageForMenuSuite(popupHwnd, WM_LBUTTONDOWN, MK_LBUTTON, refineCenter) ||
            ! PostCapturedMouseMessageForMenuSuite(popupHwnd, WM_LBUTTONUP, 0, refineCenter))
        {
            driverFailure = "owner-message-flood posts popup item click";
            return;
        }

        if (! WaitForWindowDestroyed(popupHwnd, std::chrono::milliseconds(800)))
        {
            driverFailure = "owner-window message flood does not delay popup invocation";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), menuAnchor, items, ownerWindow.Host().GetTheme());
    driver.join();

    if (! driverFailure.empty())
    {
        std::fprintf(stderr, "MENU TRACE COUNT: %zu\n", trace->count);
        const size_t first = trace->count > trace->rows.size() ? trace->count - trace->rows.size() : 0;
        for (size_t i = first; i < trace->count; ++i)
            std::fprintf(stderr, "MENU TRACE: %ls\n", trace->rows[i % trace->rows.size()].data());
    }
    Require(driverFailure.empty(), driverFailure.c_str());
    Require(result == std::optional<int>{4202}, "owner-window message flood cannot delay popup pointer hover or invocation");
}

std::shared_ptr<DxUi::MenuFlyoutItem::BitmapIcon> CreateSyntheticMenuBitmapIcon(UINT sizePx)
{
    if (sizePx == 0u)
    {
        return {};
    }

    BITMAPINFO bmi{};
    bmi.bmiHeader.biSize        = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth       = static_cast<LONG>(sizePx);
    bmi.bmiHeader.biHeight      = -static_cast<LONG>(sizePx);
    bmi.bmiHeader.biPlanes      = 1;
    bmi.bmiHeader.biBitCount    = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    void* bits = nullptr;
    wil::unique_hdc_window screenDc{GetDC(nullptr)};
    wil::unique_hbitmap bitmap{CreateDIBSection(screenDc.get(), &bmi, DIB_RGB_COLORS, &bits, nullptr, 0)};
    if (! bitmap || ! bits)
    {
        return {};
    }

    const auto pixelCount = static_cast<size_t>(sizePx) * static_cast<size_t>(sizePx);
    auto* const pixels    = static_cast<uint32_t*>(bits);
    std::fill_n(pixels, pixelCount, 0xFF1F7AE0u);

    const UINT inset = sizePx > 6u ? 2u : 1u;
    for (UINT y = inset; y < (sizePx - inset); ++y)
    {
        for (UINT x = inset; x < (sizePx - inset); ++x)
        {
            pixels[static_cast<size_t>(y) * sizePx + x] = 0xFFFFFFFFu;
        }
    }

    return std::make_shared<DxUi::MenuFlyoutItem::BitmapIcon>(std::move(bitmap), sizePx, sizePx);
}

DxUi::WindowHostBitmapCapture CaptureMenuPopupBitmapForTheme(const DxUi::ThemePalette& theme, const std::vector<DxUi::MenuFlyoutItem>& items)
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    WindowHostBitmapCapture capture{};
    std::string driverFailure;
    // When a CI run fails here, the message says which material, how long the driver waited, and whether ContextMenu::Show had
    // returned by then: a menu that never opened, as against an owner thread still busy opening or painting it.
    const char* const material = theme.overlayMaterial == OverlayMaterial::Mica      ? "Mica"
                                 : theme.overlayMaterial == OverlayMaterial::MicaAlt ? "Mica Alt"
                                 : theme.overlayMaterial == OverlayMaterial::Acrylic ? "Acrylic"
                                                                                     : "Solid";
    std::atomic<bool> showReturned{false};
    const auto started   = std::chrono::steady_clock::now();
    const auto elapsedMs = [started] { return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - started).count(); };
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = std::format("menu popup window appears for material capture validation ({}: no popup after {} ms, and ContextMenu::Show {})",
                                        material,
                                        elapsedMs(),
                                        showReturned.load() ? "had already returned" : "had not returned");
            return;
        }
        const long long appearedMs = elapsedMs();

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        if (! WaitForContextMenuPopupBitmapCapture(popupHwnd, capture))
        {
            driverFailure = std::format(
                "menu popup bitmap capture succeeds for material validation ({}: popup after {} ms, no capture by {} ms)", material, appearedMs, elapsedMs());
            return;
        }
        std::cerr << "    [TRACE] material capture " << material << ": popup after " << appearedMs << " ms, captured after " << elapsedMs() << " ms\n"
                  << std::flush;
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    showReturned.store(true);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the material-capture menu with Escape returns no invoked command");
    return capture;
}

[[nodiscard]] RECT GetPrimaryMonitorWorkArea() noexcept
{
    MONITORINFO monitorInfo{};
    monitorInfo.cbSize     = sizeof(monitorInfo);
    const HMONITOR monitor = MonitorFromPoint(POINT{0, 0}, MONITOR_DEFAULTTOPRIMARY);
    if (monitor && GetMonitorInfoW(monitor, &monitorInfo) != FALSE)
    {
        return monitorInfo.rcWork;
    }

    return RECT{0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN)};
}

[[nodiscard]] RECT GetVirtualScreenBounds() noexcept
{
    const int left   = GetSystemMetrics(SM_XVIRTUALSCREEN);
    const int top    = GetSystemMetrics(SM_YVIRTUALSCREEN);
    const int width  = (std::max)(1, GetSystemMetrics(SM_CXVIRTUALSCREEN));
    const int height = (std::max)(1, GetSystemMetrics(SM_CYVIRTUALSCREEN));
    return RECT{left, top, left + width, top + height};
}

[[nodiscard]] RECT GetNearestMonitorWorkArea(POINT screenPoint) noexcept
{
    MONITORINFO monitorInfo{};
    monitorInfo.cbSize     = sizeof(monitorInfo);
    const HMONITOR monitor = MonitorFromPoint(screenPoint, MONITOR_DEFAULTTONEAREST);
    if (monitor && GetMonitorInfoW(monitor, &monitorInfo) != FALSE)
    {
        return monitorInfo.rcWork;
    }

    return GetPrimaryMonitorWorkArea();
}

void TestMenuKeyboardNavigationSkipsInfoRows()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<MenuFlyoutItem> items = {
        {.kind = MenuItemKind::Info, .text = L"Used Space:", .acceleratorText = L"561 GB"},
        {.kind = MenuItemKind::Standard, .text = L"Disk Properties...", .commandId = 3001},
        {.kind = MenuItemKind::Info, .text = L"Free Space:", .acceleratorText = L"1.27 TB"},
        {.kind = MenuItemKind::Standard, .text = L"Disk Cleanup...", .commandId = 3002},
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for info-row keyboard navigation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        ContextMenuPopupDebugState popupState{};
        PostMessageW(popupHwnd, WM_KEYDOWN, VK_DOWN, 0);
        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 1u;
        }, popupState))
        {
            driverFailure = "first VK_DOWN skips the leading info row and focuses the first actionable item";
            return;
        }

        PostMessageW(popupHwnd, WM_KEYDOWN, VK_DOWN, 0);
        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 3u;
        }, popupState))
        {
            driverFailure = "second VK_DOWN skips the middle info row and focuses the next actionable item";
            return;
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the info-row navigation menu with Escape returns no invoked command");
}

void TestMenuKeyboardRightArrowMatchesWindowsMenuLoop()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();
    ownerWindow.PumpMessages();
    DrainPendingMouseMessagesForMenuSuite();

    const std::vector<std::vector<MenuFlyoutItem>> rootMenus = {
        {
            {.text = L"A1", .commandId = 3101},
            {.text = L"A2", .commandId = 3102},
        },
        {
            {.text      = L"B1",
             .commandId = 3201,
             .children =
                 {
                     MenuFlyoutItem{.text = L"B11", .commandId = 3211},
                     MenuFlyoutItem{.text = L"B12", .commandId = 3212},
                 }},
            {.text = L"B2", .commandId = 3202},
        },
        {
            {.text = L"C1", .commandId = 3301},
            {.text = L"C2", .commandId = 3302},
            {.text = L"C3", .commandId = 3303},
        },
    };

    size_t activeRootIndex = 0u;
    ContextMenuSessionCallbacks sessionCallbacks{};
    sessionCallbacks.switchRootFromDirection = [&](bool forward) -> std::optional<ContextMenuRootSwitchRequest>
    {
        activeRootIndex = forward ? ((activeRootIndex + 1u) % rootMenus.size()) : ((activeRootIndex + rootMenus.size() - 1u) % rootMenus.size());

        ContextMenuRootSwitchRequest request{};
        request.screenPoint = POINT{180, 180};
        request.items       = rootMenus[activeRootIndex];
        return request;
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND aPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"A1");
        if (! aPopupHwnd)
        {
            driverFailure = "menu popup window appears for right-arrow root switching validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        ContextMenuPopupDebugState popupState{};
        PostMessageW(aPopupHwnd, WM_KEYDOWN, VK_HOME, 0);
        if (! WaitForContextMenuPopupState(aPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "Home selects the first A root item before directional switching";
            return;
        }

        PostMessageW(aPopupHwnd, WM_KEYDOWN, VK_DOWN, 0);
        if (! WaitForContextMenuPopupState(aPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 1u;
        }, popupState))
        {
            driverFailure = "Down selects A2 before directional switching";
            return;
        }

        PostMessageW(aPopupHwnd, WM_KEYDOWN, VK_RIGHT, 0);
        const HWND bPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"B1");
        if (! bPopupHwnd)
        {
            driverFailure = "Right arrow on A2 opens the B root popup";
            return;
        }

        if (! WaitForContextMenuPopupState(bPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "Right arrow on A2 focuses B1 in the next root popup";
            return;
        }

        PostMessageW(bPopupHwnd, WM_KEYDOWN, VK_RIGHT, 0);
        const HWND bSubmenuHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"B11");
        if (! bSubmenuHwnd)
        {
            driverFailure = "Right arrow on B1 opens the B submenu";
            return;
        }

        if (! WaitForContextMenuPopupState(bSubmenuHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "Right arrow on B1 focuses B11 in the submenu";
            return;
        }

        PostMessageW(bSubmenuHwnd, WM_KEYDOWN, VK_RIGHT, 0);
        const HWND cPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"C1");
        if (! cPopupHwnd)
        {
            driverFailure = "Right arrow on B11 switches from the leaf submenu to the C root popup";
            return;
        }

        if (! WaitForContextMenuPopupState(cPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "Right arrow on B11 focuses C1 after switching to the next root popup";
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, rootMenus[activeRootIndex], theme, sessionCallbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the right-arrow menu loop validation popup with Escape returns no invoked command");
}

void TestStationaryMouseDoesNotOverrideKeyboardRootSwitch()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 420, 260, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<std::vector<MenuFlyoutItem>> rootMenus = {
        {
            {.text = L"A1", .commandId = 3651},
            {.text = L"A2", .commandId = 3652},
        },
        {
            {.text = L"B1", .commandId = 3661},
            {.text = L"B2", .commandId = 3662},
        },
        {
            {.text = L"C1", .commandId = 3671},
            {.text = L"C2", .commandId = 3672},
        },
    };
    const std::array<POINT, 3> rootPopupPoints = {POINT{170, 180}, POINT{250, 180}, POINT{330, 180}};

    size_t activeRootIndex  = 0u;
    const auto buildRequest = [&](size_t rootIndex) -> ContextMenuRootSwitchRequest
    {
        ContextMenuRootSwitchRequest request{};
        request.screenPoint = rootPopupPoints[rootIndex];
        request.items       = rootMenus[rootIndex];
        return request;
    };

    ContextMenuSessionCallbacks sessionCallbacks{};
    sessionCallbacks.switchRootFromDirection = [&](bool forward) -> std::optional<ContextMenuRootSwitchRequest>
    {
        activeRootIndex = forward ? ((activeRootIndex + 1u) % rootMenus.size()) : ((activeRootIndex + rootMenus.size() - 1u) % rootMenus.size());
        return buildRequest(activeRootIndex);
    };
    sessionCallbacks.switchRootFromPointer = [&](POINT screenPoint) -> std::optional<ContextMenuRootSwitchRequest>
    {
        POINT clientPoint = screenPoint;
        if (ScreenToClient(ownerWindow.Hwnd(), &clientPoint) == FALSE)
        {
            return std::nullopt;
        }
        if (clientPoint.y < 0 || clientPoint.y >= 40)
        {
            return std::nullopt;
        }

        size_t hitIndex = rootMenus.size();
        if (clientPoint.x >= 40 && clientPoint.x < 120)
        {
            hitIndex = 0u;
        }
        else if (clientPoint.x >= 140 && clientPoint.x < 220)
        {
            hitIndex = 1u;
        }
        else if (clientPoint.x >= 240 && clientPoint.x < 320)
        {
            hitIndex = 2u;
        }

        if (hitIndex >= rootMenus.size() || hitIndex == activeRootIndex)
        {
            return std::nullopt;
        }

        activeRootIndex = hitIndex;
        return buildRequest(activeRootIndex);
    };

    DrainPendingMouseMessagesForMenuSuite();

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND aPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"A1");
        if (! aPopupHwnd)
        {
            driverFailure = "initial A popup opens before stationary-mouse keyboard switching validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        if (PostMessageW(ownerWindow.Hwnd(), WM_MOUSEMOVE, 0, MAKELPARAM(160, 16)) == FALSE)
        {
            driverFailure = "posting the initial B hover before stationary-mouse keyboard switching validation succeeds";
            return;
        }

        const HWND bPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"B1");
        if (! bPopupHwnd)
        {
            driverFailure = "initial owner mouse move switches from A to B before stationary-mouse keyboard switching validation";
            return;
        }

        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(
                bPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept { return state.rootPointerSwitchCount == 1u; }, popupState))
        {
            driverFailure = "initial B hover is processed before keyboard root switching validation";
            return;
        }

        if (! SendMenuKeyForMenuSuite(bPopupHwnd, VK_HOME))
        {
            driverFailure = "Home key is delivered before stationary-mouse keyboard switching validation";
            return;
        }
        if (! WaitForContextMenuPopupState(bPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "Home selects B1 before stationary-mouse keyboard switching validation";
            return;
        }

        if (! SendMenuKeyForMenuSuite(bPopupHwnd, VK_RIGHT))
        {
            driverFailure = "Right arrow key is delivered before stationary-mouse validation";
            return;
        }
        const HWND cPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"C1");
        if (! cPopupHwnd)
        {
            driverFailure = "Right arrow switches from B to C before stationary-mouse validation";
            return;
        }

        if (! WaitForContextMenuPopupState(cPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "switching from B to C focuses C1 before stationary-mouse validation";
            return;
        }

        if (PostMessageW(ownerWindow.Hwnd(), WM_MOUSEMOVE, 0, MAKELPARAM(160, 16)) == FALSE)
        {
            driverFailure = "posting the stationary B hover after switching to C succeeds";
            return;
        }
        if (WaitForWindowDestroyed(cPopupHwnd, std::chrono::milliseconds(120)))
        {
            driverFailure = "a stationary mouse over B does not pull keyboard navigation back from C";
            return;
        }

        if (! SendMenuKeyForMenuSuite(cPopupHwnd, VK_LEFT))
        {
            driverFailure = "Left arrow key is delivered before stationary-mouse previous-root validation";
            return;
        }
        const HWND bPopupAfterLeftHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"B1");
        if (! bPopupAfterLeftHwnd)
        {
            driverFailure = "Left arrow returns from C to B before stationary-mouse previous-root validation";
            return;
        }

        if (! SendMenuKeyForMenuSuite(bPopupAfterLeftHwnd, VK_LEFT))
        {
            driverFailure = "second Left arrow key is delivered before stationary-mouse previous-root validation";
            return;
        }
        const HWND aPopupAfterSecondLeftHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"A1");
        if (! aPopupAfterSecondLeftHwnd)
        {
            driverFailure = "a second Left arrow switches from B to A before stationary-mouse previous-root validation";
            return;
        }

        if (! WaitForContextMenuPopupState(aPopupAfterSecondLeftHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "switching from B to A focuses A1 before stationary-mouse previous-root validation";
            return;
        }

        if (PostMessageW(ownerWindow.Hwnd(), WM_MOUSEMOVE, 0, MAKELPARAM(160, 16)) == FALSE)
        {
            driverFailure = "posting the stationary B hover after switching to A succeeds";
            return;
        }
        if (WaitForWindowDestroyed(aPopupAfterSecondLeftHwnd, std::chrono::milliseconds(120)))
        {
            driverFailure = "a stationary mouse over B does not pull keyboard navigation back from A";
        }
    });

    const ThemePalette theme = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result =
        ContextMenu::Show(ownerWindow.Hwnd(), rootPopupPoints[activeRootIndex], rootMenus[activeRootIndex], theme, sessionCallbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the stationary-mouse keyboard switching validation popup with Escape returns no invoked command");
}

void TestMenuPointerOverSiblingRootSwitchesOpenMenu()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 420, 260, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<std::vector<MenuFlyoutItem>> rootMenus = {
        {
            {.text = L"View one", .commandId = 36701},
            {.text = L"View two", .commandId = 36702},
        },
        {
            {.text = L"Plugins one", .commandId = 36711},
            {.text = L"Plugins two", .commandId = 36712},
        },
    };
    const std::array<POINT, 2> rootPopupPoints = {POINT{270, 180}, POINT{190, 180}};

    size_t activeRootIndex  = 0u;
    const auto buildRequest = [&](size_t rootIndex) -> ContextMenuRootSwitchRequest
    {
        ContextMenuRootSwitchRequest request{};
        request.screenPoint = rootPopupPoints[rootIndex];
        request.items       = rootMenus[rootIndex];
        return request;
    };

    ContextMenuSessionCallbacks sessionCallbacks{};
    sessionCallbacks.switchRootFromPointer = [&](POINT screenPoint) -> std::optional<ContextMenuRootSwitchRequest>
    {
        POINT clientPoint = screenPoint;
        if (ScreenToClient(ownerWindow.Hwnd(), &clientPoint) == FALSE)
        {
            return std::nullopt;
        }
        if (clientPoint.y < 0 || clientPoint.y >= 40)
        {
            return std::nullopt;
        }

        size_t hitIndex = rootMenus.size();
        if (clientPoint.x >= 140 && clientPoint.x < 220)
        {
            hitIndex = 1u;
        }
        else if (clientPoint.x >= 240 && clientPoint.x < 320)
        {
            hitIndex = 0u;
        }

        if (hitIndex >= rootMenus.size() || hitIndex == activeRootIndex)
        {
            return std::nullopt;
        }

        activeRootIndex = hitIndex;
        return buildRequest(activeRootIndex);
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND viewPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"View one");
        if (! viewPopupHwnd)
        {
            driverFailure = "View root popup opens before pointer root-switch validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        POINT pluginsMenuClientPoint{180, 20};
        POINT pluginsMenuScreenPoint = pluginsMenuClientPoint;
        if (ClientToScreen(ownerWindow.Hwnd(), &pluginsMenuScreenPoint) == FALSE)
        {
            driverFailure = "Plugins root test point converts to screen coordinates";
            return;
        }

        RECT viewPopupRect{};
        if (GetWindowRect(viewPopupHwnd, &viewPopupRect) == FALSE)
        {
            driverFailure = "View root popup exposes a screen rect before pointer root-switch validation";
            return;
        }

        const LPARAM capturedMouseMovePoint = MAKELPARAM(pluginsMenuScreenPoint.x - viewPopupRect.left, pluginsMenuScreenPoint.y - viewPopupRect.top);
        PostMessageW(viewPopupHwnd, WM_MOUSEMOVE, 0, capturedMouseMovePoint);

        const HWND pluginsPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Plugins one");
        if (! pluginsPopupHwnd)
        {
            driverFailure = "moving the pointer from an open View root to the Plugins root opens the Plugins popup";
            return;
        }

        ContextMenuPopupDebugState pluginsPopupState{};
        if (! DebugGetContextMenuPopupState(pluginsPopupHwnd, pluginsPopupState) || pluginsPopupState.rootSwitchImmediateRenderCount == 0u ||
            pluginsPopupState.renderCount == 0u)
        {
            driverFailure = "root-switched Plugins popup is painted before the menu loop accepts another pointer move";
            return;
        }

        if (IsWindow(viewPopupHwnd) != FALSE)
        {
            driverFailure = "switching to the Plugins root closes the previous View popup";
        }
    });

    const ThemePalette theme = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result =
        ContextMenu::Show(ownerWindow.Hwnd(), rootPopupPoints[activeRootIndex], rootMenus[activeRootIndex], theme, sessionCallbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the pointer root-switch validation popup with Escape returns no invoked command");
}

void TestMenuPopupMouseMoveUsesDeliveredPointForRootSwitch()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::array<std::vector<MenuFlyoutItem>, 2> rootMenus = {
        std::vector<MenuFlyoutItem>{{.text = L"View one", .commandId = 36761}, {.text = L"View two", .commandId = 36762}},
        std::vector<MenuFlyoutItem>{{.text = L"Plugins one", .commandId = 36771}, {.text = L"Plugins two", .commandId = 36772}},
    };
    const std::array<POINT, 2> rootPopupPoints = {POINT{270, 180}, POINT{190, 180}};

    size_t activeRootIndex  = 0u;
    const auto buildRequest = [&](size_t rootIndex) -> ContextMenuRootSwitchRequest
    {
        ContextMenuRootSwitchRequest request{};
        request.screenPoint = rootPopupPoints[rootIndex];
        request.items       = rootMenus[rootIndex];
        return request;
    };

    ContextMenuSessionCallbacks sessionCallbacks{};
    sessionCallbacks.switchRootFromPointer = [&](POINT screenPoint) -> std::optional<ContextMenuRootSwitchRequest>
    {
        POINT clientPoint = screenPoint;
        if (ScreenToClient(ownerWindow.Hwnd(), &clientPoint) == FALSE || clientPoint.y < 0 || clientPoint.y >= 40)
        {
            return std::nullopt;
        }

        size_t hitIndex = rootMenus.size();
        if (clientPoint.x >= 140 && clientPoint.x < 220)
        {
            hitIndex = 1u;
        }
        else if (clientPoint.x >= 240 && clientPoint.x < 320)
        {
            hitIndex = 0u;
        }

        if (hitIndex >= rootMenus.size() || hitIndex == activeRootIndex)
        {
            return std::nullopt;
        }

        activeRootIndex = hitIndex;
        return buildRequest(activeRootIndex);
    };

    DrainPendingMouseMessagesForMenuSuite();

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND viewPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"View one");
        if (! viewPopupHwnd)
        {
            driverFailure = "View root popup opens before delivered root-switch validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        const POINT pluginsMenuScreenPoint =
            ClientScreenPointForTest(ownerWindow.Hwnd(), 180, 20, "Plugins delivered root-switch point converts to screen coordinates");
        if (! PostCapturedMouseMessageForMenuSuite(viewPopupHwnd, WM_MOUSEMOVE, 0, pluginsMenuScreenPoint))
        {
            driverFailure = "View popup receives delivered root-switch mouse move";
            return;
        }

        const HWND pluginsPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Plugins one");
        if (! pluginsPopupHwnd)
        {
            driverFailure = "popup mouse-move root switching must use the delivered lParam point even when the live cursor is elsewhere";
            return;
        }

        if (IsWindow(viewPopupHwnd) != FALSE)
        {
            driverFailure = "delivered root-switch closes the previous View popup";
        }
    });

    const ThemePalette theme = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result =
        ContextMenu::Show(ownerWindow.Hwnd(), rootPopupPoints[activeRootIndex], rootMenus[activeRootIndex], theme, sessionCallbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(activeRootIndex == 1u, "delivered root-switch validation records the accepted root index");
    Require(! result.has_value(), "closing the delivered root-switch validation popup with Escape returns no invoked command");
}

void TestMenuOwnerMouseMoveRoutesRootSwitchImmediately()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 420, 260, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::array<std::vector<MenuFlyoutItem>, 2> rootMenus = {
        std::vector<MenuFlyoutItem>{{.text = L"View one", .commandId = 36781}, {.text = L"View two", .commandId = 36782}},
        std::vector<MenuFlyoutItem>{{.text = L"Plugins one", .commandId = 36791}, {.text = L"Plugins two", .commandId = 36792}},
    };
    const std::array<POINT, 2> rootPopupPoints = {
        ClientScreenPointForTest(ownerWindow.Hwnd(), 270, 60, "owner-move View root popup point converts to screen coordinates"),
        ClientScreenPointForTest(ownerWindow.Hwnd(), 190, 60, "owner-move Plugins root popup point converts to screen coordinates"),
    };

    size_t activeRootIndex  = 0u;
    const auto buildRequest = [&](size_t rootIndex) -> ContextMenuRootSwitchRequest
    {
        ContextMenuRootSwitchRequest request{};
        request.screenPoint = rootPopupPoints[rootIndex];
        request.items       = rootMenus[rootIndex];
        return request;
    };

    ContextMenuSessionCallbacks sessionCallbacks{};
    sessionCallbacks.switchRootFromPointer = [&](POINT screenPoint) -> std::optional<ContextMenuRootSwitchRequest>
    {
        POINT clientPoint = screenPoint;
        if (ScreenToClient(ownerWindow.Hwnd(), &clientPoint) == FALSE || clientPoint.y < 0 || clientPoint.y >= 40)
        {
            return std::nullopt;
        }

        size_t hitIndex = rootMenus.size();
        if (clientPoint.x >= 140 && clientPoint.x < 220)
        {
            hitIndex = 1u;
        }
        else if (clientPoint.x >= 240 && clientPoint.x < 320)
        {
            hitIndex = 0u;
        }

        if (hitIndex >= rootMenus.size() || hitIndex == activeRootIndex)
        {
            return std::nullopt;
        }

        activeRootIndex = hitIndex;
        return buildRequest(activeRootIndex);
    };

    DrainPendingMouseMessagesForMenuSuite();

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND viewPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"View one");
        if (! viewPopupHwnd)
        {
            driverFailure = "View root popup opens before owner mouse-move root switching validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        if (PostMessageW(ownerWindow.Hwnd(), WM_MOUSEMOVE, 0, MousePointLParamForMenuSuite(180, 20)) == 0)
        {
            driverFailure = "owner window receives a mouse-move over the Plugins root while the menu loop is active";
            return;
        }

        const HWND pluginsPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Plugins one");
        if (! pluginsPopupHwnd)
        {
            driverFailure = "owner-window WM_MOUSEMOVE over a sibling root switches the open menu immediately";
            return;
        }

        ContextMenuPopupDebugState pluginsPopupState{};
        if (! DebugGetContextMenuPopupState(pluginsPopupHwnd, pluginsPopupState) || pluginsPopupState.rootSwitchImmediateRenderCount == 0u ||
            pluginsPopupState.renderCount == 0u)
        {
            driverFailure = "owner-window mouse-move root switch paints the replacement popup immediately";
            return;
        }

        if (IsWindow(viewPopupHwnd) != FALSE)
        {
            driverFailure = "owner-window mouse-move root switch closes the previous View popup";
        }
    });

    const ThemePalette theme = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result =
        ContextMenu::Show(ownerWindow.Hwnd(), rootPopupPoints[activeRootIndex], rootMenus[activeRootIndex], theme, sessionCallbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(activeRootIndex == 1u, "owner-window mouse-move root switch records the accepted root index");
    Require(! result.has_value(), "closing the owner-window mouse-move root switch popup with Escape returns no invoked command");
}

void TestMenuBarHoverMessageSwitchesRootWhenCursorOutsidePopup()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 420, 260, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::array<std::vector<MenuFlyoutItem>, 2> rootMenus = {
        std::vector<MenuFlyoutItem>{{.text = L"View one", .commandId = 36741}, {.text = L"View two", .commandId = 36742}},
        std::vector<MenuFlyoutItem>{{.text = L"Plugins one", .commandId = 36751}, {.text = L"Plugins two", .commandId = 36752}},
    };
    const std::array<POINT, 2> rootPopupPoints = {
        ClientScreenPointForTest(ownerWindow.Hwnd(), 270, 60, "View synthetic hover root popup point converts to screen coordinates"),
        ClientScreenPointForTest(ownerWindow.Hwnd(), 190, 60, "Plugins synthetic hover root popup point converts to screen coordinates"),
    };

    size_t activeRootIndex  = 0u;
    const auto buildRequest = [&](size_t rootIndex) -> ContextMenuRootSwitchRequest
    {
        ContextMenuRootSwitchRequest request{};
        request.screenPoint = rootPopupPoints[rootIndex];
        request.items       = rootMenus[rootIndex];
        return request;
    };

    std::atomic<int> pendingMenuBarHoverRootSwitch{-1};
    std::atomic<std::uintptr_t> pendingMenuBarHoverSequence{0u};
    ContextMenuSessionCallbacks sessionCallbacks{};
    sessionCallbacks.switchRootFromMenuBarHover = [&](size_t hoverIndex, std::uintptr_t sequence) -> std::optional<ContextMenuRootSwitchRequest>
    {
        const int expectedHoverIndex          = pendingMenuBarHoverRootSwitch.load(std::memory_order_acquire);
        const std::uintptr_t expectedSequence = pendingMenuBarHoverSequence.load(std::memory_order_acquire);
        if (expectedHoverIndex < 0 || static_cast<size_t>(expectedHoverIndex) != hoverIndex || expectedSequence != sequence)
        {
            return std::nullopt;
        }

        pendingMenuBarHoverRootSwitch.store(-1, std::memory_order_release);
        activeRootIndex = hoverIndex;
        return buildRequest(activeRootIndex);
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND viewPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"View one");
        if (! viewPopupHwnd)
        {
            driverFailure = "View root popup opens before direct synthetic menu-bar hover validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        pendingMenuBarHoverRootSwitch.store(1, std::memory_order_release);
        pendingMenuBarHoverSequence.store(2u, std::memory_order_release);
        if (! ContextMenu::PostMenuBarHover(viewPopupHwnd, 0u, 1u) || ! ContextMenu::PostMenuBarHover(viewPopupHwnd, 1u, 2u))
        {
            driverFailure = "View popup receives the direct synthetic menu-bar hover switch messages";
            return;
        }

        const HWND pluginsPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Plugins one");
        if (! pluginsPopupHwnd)
        {
            driverFailure = "direct synthetic menu-bar hover message switches from View to Plugins while cursor is outside the popup";
            return;
        }

        ContextMenuPopupDebugState pluginsPopupState{};
        if (! DebugGetContextMenuPopupState(pluginsPopupHwnd, pluginsPopupState) || pluginsPopupState.rootSwitchImmediateRenderCount == 0u ||
            pluginsPopupState.renderCount == 0u)
        {
            driverFailure = "synthetic menu-bar hover root switch paints the replacement Plugins popup immediately";
            return;
        }

        if (IsWindow(viewPopupHwnd) != FALSE)
        {
            driverFailure = "synthetic menu-bar hover root switch closes the previous View popup";
        }
    });

    const ThemePalette theme = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result =
        ContextMenu::Show(ownerWindow.Hwnd(), rootPopupPoints[activeRootIndex], rootMenus[activeRootIndex], theme, sessionCallbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(activeRootIndex == 1u, "direct synthetic menu-bar hover validation records the accepted root index");
    Require(! result.has_value(), "closing the direct synthetic menu-bar hover popup with Escape returns no invoked command");
}

void TestMenuBarHoverMessageSwitchesRootWhilePopupOverlapsMenuBar()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 420, 260, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::array<std::vector<MenuFlyoutItem>, 2> rootMenus = {
        std::vector<MenuFlyoutItem>{{.text = L"View one", .commandId = 36721}, {.text = L"View two", .commandId = 36722}},
        std::vector<MenuFlyoutItem>{{.text = L"Plugins one", .commandId = 36731}, {.text = L"Plugins two", .commandId = 36732}},
    };
    const std::array<POINT, 2> rootPopupPoints = {
        ClientScreenPointForTest(ownerWindow.Hwnd(), 90, 0, "View overlapping root popup point converts to screen coordinates"),
        ClientScreenPointForTest(ownerWindow.Hwnd(), 190, 0, "Plugins overlapping root popup point converts to screen coordinates"),
    };
    constexpr LONG kMainMenuStripHeightPx = 96;

    size_t activeRootIndex  = 0u;
    const auto buildRequest = [&](size_t rootIndex) -> ContextMenuRootSwitchRequest
    {
        ContextMenuRootSwitchRequest request{};
        request.screenPoint = rootPopupPoints[rootIndex];
        request.items       = rootMenus[rootIndex];
        return request;
    };

    ContextMenuSessionCallbacks sessionCallbacks{};
    std::atomic_bool pointerRootSwitchArmed{false};
    std::atomic<int> pendingMenuBarHoverRootSwitch{-1};
    std::atomic<std::uintptr_t> pendingMenuBarHoverSequence{0u};
    sessionCallbacks.switchRootFromPointer = [&](POINT screenPoint) -> std::optional<ContextMenuRootSwitchRequest>
    {
        if (! pointerRootSwitchArmed.load(std::memory_order_acquire))
        {
            return std::nullopt;
        }

        POINT clientPoint = screenPoint;
        if (ScreenToClient(ownerWindow.Hwnd(), &clientPoint) == FALSE || clientPoint.y < 0 || clientPoint.y >= kMainMenuStripHeightPx)
        {
            return std::nullopt;
        }
        if (activeRootIndex == 1u)
        {
            return std::nullopt;
        }

        activeRootIndex = 1u;
        return buildRequest(activeRootIndex);
    };
    sessionCallbacks.switchRootFromMenuBarHover = [&](size_t hoverIndex, std::uintptr_t sequence) -> std::optional<ContextMenuRootSwitchRequest>
    {
        const int expectedHoverIndex          = pendingMenuBarHoverRootSwitch.load(std::memory_order_acquire);
        const std::uintptr_t expectedSequence = pendingMenuBarHoverSequence.load(std::memory_order_acquire);
        if (expectedHoverIndex < 0 || static_cast<size_t>(expectedHoverIndex) != hoverIndex || expectedSequence != sequence)
        {
            return std::nullopt;
        }

        pendingMenuBarHoverRootSwitch.store(-1, std::memory_order_release);
        activeRootIndex = hoverIndex;
        return buildRequest(activeRootIndex);
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND viewPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"View one");
        if (! viewPopupHwnd)
        {
            driverFailure = "View root popup opens before overlapping-popup validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(viewPopupHwnd, [](const ContextMenuPopupDebugState&) noexcept { return true; }, popupState))
        {
            driverFailure = "overlapping View popup exposes debug state";
            return;
        }

        D2D1_RECT_F firstItemRectDip{};
        if (! WaitForContextMenuPopupItemRect(viewPopupHwnd, 0u, firstItemRectDip))
        {
            driverFailure = "overlapping View popup exposes its first item rect";
            return;
        }

        const float itemMidXDip = (firstItemRectDip.left + firstItemRectDip.right) * 0.5f;
        const float itemMidYDip = (firstItemRectDip.top + firstItemRectDip.bottom) * 0.5f;
        const POINT popupItemScreenPoint{
            popupState.surfaceRectPx.left + static_cast<LONG>(DipToPixelForPopup(itemMidXDip, popupState.dpi)),
            popupState.surfaceRectPx.top + static_cast<LONG>(DipToPixelForPopup(itemMidYDip, popupState.dpi)),
        };

        POINT ownerClientPoint = popupItemScreenPoint;
        if (ScreenToClient(ownerWindow.Hwnd(), &ownerClientPoint) == FALSE)
        {
            driverFailure = "overlapping popup sample point converts to owner client coordinates";
            return;
        }
        if (ownerClientPoint.y < 0 || ownerClientPoint.y >= kMainMenuStripHeightPx)
        {
            driverFailure = "overlapping popup sample point sits over the owner main-menu strip";
            return;
        }

        RECT popupWindowRect{};
        if (GetWindowRect(viewPopupHwnd, &popupWindowRect) == FALSE)
        {
            driverFailure = "overlapping View popup exposes a screen rect";
            return;
        }

        pointerRootSwitchArmed.store(true, std::memory_order_release);
        PostMessageW(viewPopupHwnd, WM_MOUSEMOVE, 0, MAKELPARAM(popupItemScreenPoint.x - popupWindowRect.left, popupItemScreenPoint.y - popupWindowRect.top));

        const HWND pluginsPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Plugins one", std::chrono::milliseconds(180));
        if (pluginsPopupHwnd)
        {
            driverFailure = "moving inside a frontmost popup must not switch the root menu underneath it";
            return;
        }

        pendingMenuBarHoverRootSwitch.store(1, std::memory_order_release);
        pendingMenuBarHoverSequence.store(1u, std::memory_order_release);
        if (! ContextMenu::PostMenuBarHover(viewPopupHwnd, 1u, 1u))
        {
            driverFailure = "overlapping popup can receive the synthetic menu-bar hover switch message";
            return;
        }
        const HWND pluginsPopupFromHoverHwnd =
            WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Plugins one", std::chrono::milliseconds(900));
        if (! pluginsPopupFromHoverHwnd)
        {
            driverFailure = "an explicit menu-bar hover message must switch root while a frontmost popup overlaps the menu strip";
            return;
        }

        if (IsWindow(viewPopupHwnd) != FALSE && IsWindowVisible(viewPopupHwnd) != FALSE)
        {
            driverFailure = "View popup should close after explicit menu-bar hover switches to the Plugins root";
        }
    });

    const ThemePalette theme = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result =
        ContextMenu::Show(ownerWindow.Hwnd(), rootPopupPoints[activeRootIndex], rootMenus[activeRootIndex], theme, sessionCallbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the overlapping popup validation with Escape returns no invoked command");
}

// DxUi's menu-bar hover message used to be WM_APP + 0x539, and a modal menu's loop took that value from any window of its
// thread. Registered now, an application message at that value posted to the owner while a modal menu runs reaches the
// owner's window procedure with its parameters, and the session hears no hover from it. The hover ContextMenu::PostMenuBarHover
// posts to that same window still reaches the session, and never the owner's procedure.
void TestModalMenuLeavesApplicationMessageAtFormerRootHoverValueToItsWindow()
{
    using namespace DxUi;
    constexpr UINT kFormerRootHoverValue = WM_APP + 0x539u;
    std::atomic<int> applicationMessages{0};
    std::atomic<bool> applicationParametersKept{false};
    std::atomic<int> hoverCalls{0};
    std::atomic<std::uintptr_t> lastHoverSequence{0u};

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 420, 260, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();
    ownerWindow.SetApplicationMessageHandler([&](UINT message, WPARAM wParam, LPARAM lParam, LRESULT& result)
    {
        if (message != kFormerRootHoverValue)
            return false;
        applicationParametersKept.store(wParam == 1u && lParam == 2, std::memory_order_release);
        applicationMessages.fetch_add(1, std::memory_order_acq_rel);
        result = 0;
        return true;
    });

    const std::vector<MenuFlyoutItem> items{{.text = L"Former value one", .commandId = 36931}, {.text = L"Former value two", .commandId = 36932}};
    ContextMenuSessionCallbacks sessionCallbacks{};
    sessionCallbacks.switchRootFromMenuBarHover = [&](size_t, std::uintptr_t sequence) -> std::optional<ContextMenuRootSwitchRequest>
    {
        lastHoverSequence.store(sequence, std::memory_order_release);
        hoverCalls.fetch_add(1, std::memory_order_acq_rel);
        return std::nullopt;
    };

    const auto waitFor = [](const auto& condition)
    {
        const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
        while (! condition())
        {
            if (std::chrono::steady_clock::now() >= deadline)
                return false;
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        return true;
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Former value one");
        if (! popupHwnd)
        {
            driverFailure = "the modal menu opens before the application posts its message at the former root-hover value";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });
        if (PostMessageW(ownerWindow.Hwnd(), kFormerRootHoverValue, 1u, 2) == FALSE)
        {
            driverFailure = "the application posts its message at the former root-hover value to the owner";
            return;
        }
        if (! waitFor([&] { return applicationMessages.load(std::memory_order_acquire) != 0; }))
        {
            driverFailure = "the owner's window procedure receives the application's message at the former root-hover value while the menu runs";
            return;
        }
        if (! applicationParametersKept.load(std::memory_order_acquire) || hoverCalls.load(std::memory_order_acquire) != 0)
        {
            driverFailure = "the application's message keeps its parameters, and the session hears no menu-bar hover from it";
            return;
        }

        if (! ContextMenu::PostMenuBarHover(ownerWindow.Hwnd(), 1u, 3u))
        {
            driverFailure = "ContextMenu::PostMenuBarHover posts the registered hover to the owner";
            return;
        }
        if (! waitFor([&] { return hoverCalls.load(std::memory_order_acquire) != 0; }) || lastHoverSequence.load(std::memory_order_acquire) != 3u ||
            applicationMessages.load(std::memory_order_acquire) != 1)
        {
            driverFailure = "the registered hover posted to the owner reaches the session, and never the owner's procedure";
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const POINT anchor              = ClientScreenPointForTest(ownerWindow.Hwnd(), 40, 40, "the former-value menu anchor converts to screen coordinates");
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), anchor, items, theme, sessionCallbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the former-value menu with Escape invokes no command");
}

void TestMenuRootSwitchUsesDeliveredOwnerMouseMoveAfterPopupSwitch()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::array<std::vector<MenuFlyoutItem>, 2> rootMenus = {
        std::vector<MenuFlyoutItem>{{.text = L"View one", .commandId = 36801}, {.text = L"View two", .commandId = 36802}},
        std::vector<MenuFlyoutItem>{{.text = L"Plugins one", .commandId = 36811}, {.text = L"Plugins two", .commandId = 36812}},
    };
    const std::array<POINT, 2> rootPopupPoints = {POINT{270, 180}, POINT{190, 180}};

    std::atomic<size_t> activeRootIndex{0u};
    const auto buildRequest = [&](size_t rootIndex) -> ContextMenuRootSwitchRequest
    {
        ContextMenuRootSwitchRequest request{};
        request.screenPoint = rootPopupPoints[rootIndex];
        request.items       = rootMenus[rootIndex];
        return request;
    };

    ContextMenuSessionCallbacks sessionCallbacks{};
    sessionCallbacks.switchRootFromPointer = [&](POINT screenPoint) -> std::optional<ContextMenuRootSwitchRequest>
    {
        POINT clientPoint = screenPoint;
        if (ScreenToClient(ownerWindow.Hwnd(), &clientPoint) == FALSE || clientPoint.y < 0 || clientPoint.y >= 40)
        {
            return std::nullopt;
        }

        size_t hitIndex = rootMenus.size();
        if (clientPoint.x >= 140 && clientPoint.x < 220)
        {
            hitIndex = 1u;
        }
        else if (clientPoint.x >= 240 && clientPoint.x < 320)
        {
            hitIndex = 0u;
        }

        if (hitIndex >= rootMenus.size() || hitIndex == activeRootIndex.load(std::memory_order_acquire))
        {
            return std::nullopt;
        }

        activeRootIndex.store(hitIndex, std::memory_order_release);
        return buildRequest(hitIndex);
    };

    DrainPendingMouseMessagesForMenuSuite();

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND viewPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"View one");
        if (! viewPopupHwnd)
        {
            driverFailure = "View root popup opens before delivered owner mouse-move validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        POINT pluginsMenuClientPoint{180, 20};
        POINT pluginsMenuScreenPoint = pluginsMenuClientPoint;
        if (ClientToScreen(ownerWindow.Hwnd(), &pluginsMenuScreenPoint) == FALSE)
        {
            driverFailure = "Plugins root test point converts to screen coordinates for delivered owner mouse-move validation";
            return;
        }

        POINT viewMenuClientPoint{280, 20};
        POINT viewMenuScreenPoint = viewMenuClientPoint;
        if (ClientToScreen(ownerWindow.Hwnd(), &viewMenuScreenPoint) == FALSE)
        {
            driverFailure = "View root delivered owner point converts to screen coordinates";
            return;
        }

        if (! PostCapturedMouseMessageForMenuSuite(viewPopupHwnd, WM_MOUSEMOVE, 0, pluginsMenuScreenPoint))
        {
            driverFailure = "View popup receives the delivered Plugins root-switch move";
            return;
        }

        const HWND pluginsPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Plugins one");
        if (! pluginsPopupHwnd)
        {
            driverFailure = "delivered popup move opens the Plugins popup before delivered owner mouse-move validation";
            return;
        }
        if (activeRootIndex.load(std::memory_order_acquire) != 1u)
        {
            driverFailure = "delivered popup move records the Plugins root as active before owner mouse-move validation";
            return;
        }

        POINT deliveredViewClientPoint = viewMenuScreenPoint;
        if (ScreenToClient(ownerWindow.Hwnd(), &deliveredViewClientPoint) == FALSE)
        {
            driverFailure = "View delivered owner point converts to owner client coordinates";
            return;
        }
        if (PostMessageW(ownerWindow.Hwnd(), WM_MOUSEMOVE, 0, MAKELPARAM(deliveredViewClientPoint.x, deliveredViewClientPoint.y)) == FALSE)
        {
            driverFailure = "owner receives the delivered View root-switch move";
            return;
        }

        const HWND deliveredViewPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"View one", std::chrono::milliseconds(900));
        if (! deliveredViewPopupHwnd)
        {
            driverFailure = "a fresh delivered owner View mouse-move should switch root after the Plugins popup opened";
            return;
        }

        if (activeRootIndex.load(std::memory_order_acquire) != 0u)
        {
            driverFailure = "fresh delivered owner View mouse-move should record the View root as active";
            return;
        }

        if (IsWindow(pluginsPopupHwnd) != FALSE && IsWindowVisible(pluginsPopupHwnd) != FALSE)
        {
            driverFailure = "Plugins popup should close after the fresh delivered owner View mouse-move message";
        }
    });

    const ThemePalette theme      = MakeAnimatedTestThemePalette(true);
    const size_t initialRootIndex = activeRootIndex.load(std::memory_order_acquire);
    const std::optional<int> result =
        ContextMenu::Show(ownerWindow.Hwnd(), rootPopupPoints[initialRootIndex], rootMenus[initialRootIndex], theme, sessionCallbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the delivered owner mouse-move validation popup with Escape returns no invoked command");
}

void TestMenuRootSwitchDoesNotPollCursorWhileIdle()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::array<std::vector<MenuFlyoutItem>, 2> rootMenus = {
        std::vector<MenuFlyoutItem>{{.text = L"View one", .commandId = 36901}, {.text = L"View two", .commandId = 36902}},
        std::vector<MenuFlyoutItem>{{.text = L"Plugins one", .commandId = 36911}, {.text = L"Plugins two", .commandId = 36912}},
    };
    const std::array<POINT, 2> rootPopupPoints = {POINT{270, 180}, POINT{190, 180}};

    size_t activeRootIndex  = 0u;
    const auto buildRequest = [&](size_t rootIndex) -> ContextMenuRootSwitchRequest
    {
        ContextMenuRootSwitchRequest request{};
        request.screenPoint = rootPopupPoints[rootIndex];
        request.items       = rootMenus[rootIndex];
        return request;
    };

    ContextMenuSessionCallbacks sessionCallbacks{};
    sessionCallbacks.switchRootFromPointer = [&](POINT screenPoint) -> std::optional<ContextMenuRootSwitchRequest>
    {
        POINT clientPoint = screenPoint;
        if (ScreenToClient(ownerWindow.Hwnd(), &clientPoint) == FALSE || clientPoint.y < 0 || clientPoint.y >= 40)
        {
            return std::nullopt;
        }

        size_t hitIndex = rootMenus.size();
        if (clientPoint.x >= 140 && clientPoint.x < 220)
        {
            hitIndex = 1u;
        }
        else if (clientPoint.x >= 240 && clientPoint.x < 320)
        {
            hitIndex = 0u;
        }

        if (hitIndex >= rootMenus.size() || hitIndex == activeRootIndex)
        {
            return std::nullopt;
        }

        activeRootIndex = hitIndex;
        return buildRequest(activeRootIndex);
    };

    DrainPendingMouseMessagesForMenuSuite();

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND viewPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"View one");
        if (! viewPopupHwnd)
        {
            driverFailure = "View root popup opens before idle cursor polling validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        const HWND pluginsPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Plugins one", std::chrono::milliseconds(180));
        if (pluginsPopupHwnd)
        {
            driverFailure = "waiting without a mouse-move message must not switch root menus by idle polling";
            return;
        }

        if (IsWindow(viewPopupHwnd) == FALSE)
        {
            driverFailure = "View popup remains alive when no mouse-move message is delivered";
        }
    });

    const ThemePalette theme = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result =
        ContextMenu::Show(ownerWindow.Hwnd(), rootPopupPoints[activeRootIndex], rootMenus[activeRootIndex], theme, sessionCallbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the idle cursor polling validation popup with Escape returns no invoked command");
}

void TestMenuHoveringSiblingClosesOpenSubmenuAfterDelay()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();
    DrainPendingMouseMessagesForMenuSuite();
    const std::vector<MenuFlyoutItem> items = {
        {.text      = L"B1",
         .commandId = 3681,
         .children =
             {
                 MenuFlyoutItem{.text = L"B11", .commandId = 36811},
                 MenuFlyoutItem{.text = L"B12", .commandId = 36812},
             }},
        {.text = L"B2", .commandId = 3682},
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND rootPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"B1");
        if (! rootPopupHwnd)
        {
            driverFailure = "menu popup window appears for delayed submenu-close validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        D2D1_RECT_F firstItemRectDip  = D2D1::RectF();
        D2D1_RECT_F secondItemRectDip = D2D1::RectF();
        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(rootPopupHwnd,
                                           [](const ContextMenuPopupDebugState& state) noexcept
        { return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f; },
                                           popupState) ||
            ! WaitForContextMenuPopupItemRect(rootPopupHwnd, 0u, firstItemRectDip) || ! WaitForContextMenuPopupItemRect(rootPopupHwnd, 1u, secondItemRectDip))
        {
            driverFailure = "menu popup exposes geometry for delayed submenu-close validation";
            return;
        }

        const float scale = static_cast<float>(popupState.dpi) / 96.0f;
        const LONG b1X    = static_cast<LONG>(std::lround(((firstItemRectDip.left + firstItemRectDip.right) * 0.5f) * scale));
        const LONG b1Y    = static_cast<LONG>(std::lround(((firstItemRectDip.top + firstItemRectDip.bottom) * 0.5f) * scale));
        const LONG b2X    = static_cast<LONG>(std::lround(((secondItemRectDip.left + secondItemRectDip.right) * 0.5f) * scale));
        const LONG b2Y    = static_cast<LONG>(std::lround(((secondItemRectDip.top + secondItemRectDip.bottom) * 0.5f) * scale));

        if (! SendSettledClientMouseMoveForMenuSuite(rootPopupHwnd, b1X, b1Y) ||
            ! WaitForContextMenuPopupState(rootPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.hoveredIndex.has_value() && state.hoveredIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "hovering B1 updates the root-popup hover target before delayed submenu close";
            return;
        }

        HWND submenuHwnd = nullptr;
        if (! WaitForSubmenuOpenAfterHoverForMenuSuite(ownerWindow.Hwnd(), rootPopupHwnd, 0u, L"B11", submenuHwnd, popupState))
        {
            driverFailure = "hovering B1 long enough opens its submenu before delayed close validation";
            return;
        }

        if (! SendSettledClientMouseMoveForMenuSuite(rootPopupHwnd, b2X, b2Y) ||
            ! WaitForContextMenuPopupState(rootPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.hoveredIndex.has_value() && state.hoveredIndex.value() == 1u;
        }, popupState))
        {
            driverFailure = "hovering B2 updates the root-popup hover target before delayed submenu close";
            return;
        }

        if (! WaitForSubmenuClosedAfterHoverForMenuSuite(rootPopupHwnd, submenuHwnd, popupState))
        {
            driverFailure = "hovering B2 long enough closes the already-open submenu from B1";
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the delayed submenu-close validation popup with Escape returns no invoked command");
}

void TestMenuHoveringSiblingWithChildrenReplacesOpenSubmenuAfterDelay()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();
    DrainPendingMouseMessagesForMenuSuite();
    const std::vector<MenuFlyoutItem> items = {
        {.text      = L"B1",
         .commandId = 3691,
         .children =
             {
                 MenuFlyoutItem{.text = L"B11", .commandId = 36911},
                 MenuFlyoutItem{.text = L"B12", .commandId = 36912},
             }},
        {.text      = L"B2",
         .commandId = 3692,
         .children =
             {
                 MenuFlyoutItem{.text = L"B21", .commandId = 36921},
                 MenuFlyoutItem{.text = L"B22", .commandId = 36922},
             }},
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND rootPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"B1");
        if (! rootPopupHwnd)
        {
            driverFailure = "menu popup window appears for delayed submenu-replacement validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        D2D1_RECT_F firstItemRectDip  = D2D1::RectF();
        D2D1_RECT_F secondItemRectDip = D2D1::RectF();
        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(rootPopupHwnd,
                                           [](const ContextMenuPopupDebugState& state) noexcept
        { return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f; },
                                           popupState) ||
            ! WaitForContextMenuPopupItemRect(rootPopupHwnd, 0u, firstItemRectDip) || ! WaitForContextMenuPopupItemRect(rootPopupHwnd, 1u, secondItemRectDip))
        {
            driverFailure = "menu popup exposes geometry for delayed submenu-replacement validation";
            return;
        }

        const float scale = static_cast<float>(popupState.dpi) / 96.0f;
        const LONG b1X    = static_cast<LONG>(std::lround(((firstItemRectDip.left + firstItemRectDip.right) * 0.5f) * scale));
        const LONG b1Y    = static_cast<LONG>(std::lround(((firstItemRectDip.top + firstItemRectDip.bottom) * 0.5f) * scale));
        const LONG b2X    = static_cast<LONG>(std::lround(((secondItemRectDip.left + secondItemRectDip.right) * 0.5f) * scale));
        const LONG b2Y    = static_cast<LONG>(std::lround(((secondItemRectDip.top + secondItemRectDip.bottom) * 0.5f) * scale));

        if (! SendSettledClientMouseMoveForMenuSuite(rootPopupHwnd, b1X, b1Y) ||
            ! WaitForContextMenuPopupState(rootPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.hoveredIndex.has_value() && state.hoveredIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "hovering B1 updates the root-popup hover target before delayed submenu replacement";
            return;
        }

        HWND firstSubmenuHwnd = nullptr;
        if (! WaitForSubmenuOpenAfterHoverForMenuSuite(ownerWindow.Hwnd(), rootPopupHwnd, 0u, L"B11", firstSubmenuHwnd, popupState))
        {
            driverFailure = "hovering B1 long enough opens its submenu before delayed replacement validation";
            return;
        }

        if (! SendSettledClientMouseMoveForMenuSuite(rootPopupHwnd, b2X, b2Y) ||
            ! WaitForContextMenuPopupState(rootPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.hoveredIndex.has_value() && state.hoveredIndex.value() == 1u;
        }, popupState))
        {
            driverFailure = "hovering B2 updates the root-popup hover target before delayed submenu replacement";
            return;
        }

        HWND replacementSubmenuHwnd = nullptr;
        if (! WaitForSubmenuOpenAfterHoverForMenuSuite(ownerWindow.Hwnd(), rootPopupHwnd, 1u, L"B21", replacementSubmenuHwnd, popupState))
        {
            driverFailure = "hovering B2 long enough opens B2's replacement submenu";
            return;
        }

        if (! WaitForWindowDestroyed(firstSubmenuHwnd, std::chrono::milliseconds(1200)))
        {
            driverFailure = "opening B2's submenu closes the older submenu from B1";
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the delayed submenu-replacement validation popup with Escape returns no invoked command");
}

// PeekMessageW runs the handlers of messages other threads sent to the menu's thread, and such a handler can close a submenu
// while the modal loop walks the popup chain to peek each popup's own paints and state probes. The loop must then peek only
// live popups. The hook closes the open submenu as such a handler would, from the loop's peek of the root popup's state probes:
// none is pending, so that peek finds nothing and the loop goes on to the next popup of the chain it started with. The driver
// posts no state probe from then until the loop has peeked again, which keeps that true.
void TestMenuModalLoopPeeksOnlyLivePopupsWhenAPeekClosesASubmenu()
{
    using namespace DxUi;

    struct PeekProbe
    {
        std::atomic<HWND> submenu{nullptr};
        std::atomic<bool> armed{false};
        std::atomic<bool> recording{true};
        bool fired = false; // The menu's thread only.
        wil::unique_event firedEvent{wil::EventOptions::ManualReset};
        wil::unique_event peekedAfterCloseEvent{wil::EventOptions::ManualReset}; // Set with the first peek recorded after the close.
        std::mutex mutex;
        std::vector<std::pair<HWND, bool>> peekedAfterClose; // Each window peeked after the close, and whether it was a window.
    } probe;
    probe.peekedAfterClose.reserve(4096u);

    const ContextMenuModalLoopPeekHook hook = [](void* context, HWND popupHwnd, UINT message) noexcept
    {
        auto& peekProbe = *static_cast<PeekProbe*>(context);
        if (peekProbe.fired)
        {
            const std::scoped_lock lock(peekProbe.mutex);
            if (peekProbe.recording.load(std::memory_order_acquire) && peekProbe.peekedAfterClose.size() < peekProbe.peekedAfterClose.capacity())
            {
                peekProbe.peekedAfterClose.emplace_back(popupHwnd, IsWindow(popupHwnd) != FALSE);
                peekProbe.peekedAfterCloseEvent.SetEvent();
            }
            return;
        }
        const HWND submenu = peekProbe.submenu.load(std::memory_order_acquire);
        if (message == WM_PAINT || ! peekProbe.armed.load(std::memory_order_acquire) || ! submenu || popupHwnd == submenu)
        {
            return;
        }
        peekProbe.fired = true;
        // Left in the submenu closes it, as a key another thread sent to it would.
        static_cast<void>(SendMessageW(submenu, WM_KEYDOWN, VK_LEFT, 0));
        peekProbe.firedEvent.SetEvent();
    };

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();
    DrainPendingMouseMessagesForMenuSuite();
    const std::vector<MenuFlyoutItem> items = {
        {.text      = L"P1",
         .commandId = 3801,
         .children =
             {
                 MenuFlyoutItem{.text = L"P11", .commandId = 38011},
                 MenuFlyoutItem{.text = L"P12", .commandId = 38012},
             }},
        {.text = L"P2", .commandId = 3802},
    };

    DebugSetContextMenuModalLoopPeekHookForTest(hook, &probe);
    const auto clearHook = wil::scope_exit([]() noexcept { DebugSetContextMenuModalLoopPeekHookForTest(nullptr, nullptr); });

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND rootPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"P1");
        if (! rootPopupHwnd)
        {
            driverFailure = "menu popup window appears for the chain-change peek validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            probe.recording.store(false, std::memory_order_release);
            DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd());
        });

        ContextMenuPopupDebugState popupState{};
        PostMessageW(rootPopupHwnd, WM_KEYDOWN, VK_HOME, 0);
        if (! WaitForContextMenuPopupState(rootPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "Home selects P1 before its submenu opens";
            return;
        }
        PostMessageW(rootPopupHwnd, WM_KEYDOWN, VK_RIGHT, 0);
        const HWND submenuHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"P11");
        if (! submenuHwnd)
        {
            driverFailure = "Right opens P1's submenu";
            return;
        }

        // No state probe is pending from here on, so the root popup's probe peek finds nothing when the hook closes the submenu.
        probe.submenu.store(submenuHwnd, std::memory_order_release);
        probe.armed.store(true, std::memory_order_release);
        PostMessageW(rootPopupHwnd, WM_NULL, 0, 0); // Wakes the modal loop; its next idle pass fires the hook.
        if (WaitForSingleObject(probe.firedEvent.get(), 5000u) != WAIT_OBJECT_0)
        {
            driverFailure = "the modal loop peeks the root popup's state probes while the submenu is open";
            return;
        }
        // The hook destroyed the submenu before it set the event, and the pass that fired it has yet to finish the root's probe
        // peek. A state probe posted now could be the message that peek removes: the root would answer it, and the recording
        // would end, before the loop's next pass peeks anything. Until that next pass has peeked, the root gets only a wake.
        PostMessageW(rootPopupHwnd, WM_NULL, 0, 0);
        if (WaitForSingleObject(probe.peekedAfterCloseEvent.get(), 5000u) != WAIT_OBJECT_0)
        {
            driverFailure = "the modal loop goes on peeking after a peek closed the submenu";
            return;
        }
        if (! WaitForWindowDestroyed(submenuHwnd, std::chrono::milliseconds(1200)))
        {
            driverFailure = "the key the hook sent closes the submenu";
            return;
        }
        // More passes of the loop, through the root popup's state probes: the root still answers.
        if (! WaitForContextMenuPopupState(rootPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f;
        }, popupState))
        {
            driverFailure = "the root popup still answers after a peek closed its submenu";
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "dismissing the chain-change peek validation returns no invoked command");
    const HWND closedSubmenu = probe.submenu.load(std::memory_order_acquire);
    const std::scoped_lock lock(probe.mutex);
    Require(! probe.peekedAfterClose.empty(), "the modal loop goes on peeking after a peek closed the submenu");
    for (const auto& [popupHwnd, wasWindow] : probe.peekedAfterClose)
    {
        Require(popupHwnd != closedSubmenu && wasWindow, "after a peek closed the submenu, the modal loop peeks only the popups still open");
    }
}

void TestMenuPointerInsideSubmenuAndParentItemCancelPendingCloseDelay()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();
    DrainPendingMouseMessagesForMenuSuite();
    const std::vector<MenuFlyoutItem> items = {
        {.text      = L"B1",
         .commandId = 3701,
         .children =
             {
                 MenuFlyoutItem{.text = L"B11", .commandId = 37011},
                 MenuFlyoutItem{.text = L"B12", .commandId = 37012},
             }},
        {.text = L"B2", .commandId = 3702},
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND rootPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"B1");
        if (! rootPopupHwnd)
        {
            driverFailure = "menu popup window appears for submenu hover-retention validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        D2D1_RECT_F firstItemRectDip  = D2D1::RectF();
        D2D1_RECT_F secondItemRectDip = D2D1::RectF();
        ContextMenuPopupDebugState rootState{};
        if (! WaitForContextMenuPopupState(rootPopupHwnd,
                                           [](const ContextMenuPopupDebugState& state) noexcept
        { return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f; },
                                           rootState) ||
            ! WaitForContextMenuPopupItemRect(rootPopupHwnd, 0u, firstItemRectDip) || ! WaitForContextMenuPopupItemRect(rootPopupHwnd, 1u, secondItemRectDip))
        {
            driverFailure = "root popup exposes geometry for submenu hover-retention validation";
            return;
        }

        const float rootScale = static_cast<float>(rootState.dpi) / 96.0f;
        const LONG b1X        = static_cast<LONG>(std::lround(((firstItemRectDip.left + firstItemRectDip.right) * 0.5f) * rootScale));
        const LONG b1Y        = static_cast<LONG>(std::lround(((firstItemRectDip.top + firstItemRectDip.bottom) * 0.5f) * rootScale));
        const LONG b2X        = static_cast<LONG>(std::lround(((secondItemRectDip.left + secondItemRectDip.right) * 0.5f) * rootScale));
        const LONG b2Y        = static_cast<LONG>(std::lround(((secondItemRectDip.top + secondItemRectDip.bottom) * 0.5f) * rootScale));

        if (! SendSettledClientMouseMoveForMenuSuite(rootPopupHwnd, b1X, b1Y) ||
            ! WaitForContextMenuPopupState(rootPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.hoveredIndex.has_value() && state.hoveredIndex.value() == 0u;
        }, rootState))
        {
            driverFailure = "hovering B1 updates the root-popup hover target before hover-retention validation";
            return;
        }

        HWND submenuHwnd = nullptr;
        if (! WaitForSubmenuOpenAfterHoverForMenuSuite(ownerWindow.Hwnd(), rootPopupHwnd, 0u, L"B11", submenuHwnd, rootState))
        {
            driverFailure = "hovering B1 long enough opens its submenu before hover-retention validation";
            return;
        }

        if (! SendSettledClientMouseMoveForMenuSuite(rootPopupHwnd, b2X, b2Y) ||
            ! WaitForContextMenuPopupState(rootPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.hoveredIndex.has_value() && state.hoveredIndex.value() == 1u;
        }, rootState))
        {
            driverFailure = "hovering B2 starts the delayed close path before entering the submenu";
            return;
        }
        if (! WaitForPendingSubmenuCloseTimerForMenuSuite(rootPopupHwnd, rootState))
        {
            driverFailure = "hovering B2 schedules the parent delayed-close timer before entering the submenu";
            return;
        }

        D2D1_RECT_F submenuItemRectDip = D2D1::RectF();
        ContextMenuPopupDebugState submenuState{};
        if (! WaitForContextMenuPopupState(submenuHwnd,
                                           [](const ContextMenuPopupDebugState& state) noexcept
        { return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f; },
                                           submenuState) ||
            ! WaitForContextMenuPopupItemRect(submenuHwnd, 0u, submenuItemRectDip))
        {
            driverFailure = "submenu exposes geometry before hover-retention validation";
            return;
        }

        const float submenuScale = static_cast<float>(submenuState.dpi) / 96.0f;
        const LONG submenuX      = static_cast<LONG>(std::lround(((submenuItemRectDip.left + submenuItemRectDip.right) * 0.5f) * submenuScale));
        const LONG submenuY      = static_cast<LONG>(std::lround(((submenuItemRectDip.top + submenuItemRectDip.bottom) * 0.5f) * submenuScale));
        if (! SendSettledClientMouseMoveForMenuSuite(submenuHwnd, submenuX, submenuY) ||
            ! WaitForContextMenuPopupState(submenuHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.hoveredIndex.has_value() && state.hoveredIndex.value() == 0u;
        }, submenuState))
        {
            driverFailure = "moving into an open submenu updates the submenu hover target";
            return;
        }

        if (! WaitForNoSubmenuHoverTimerForMenuSuite(rootPopupHwnd, rootState) || IsWindow(submenuHwnd) == FALSE)
        {
            driverFailure = "moving into an open submenu cancels the parent delayed-close timer";
            return;
        }

        if (! SendSettledClientMouseMoveForMenuSuite(rootPopupHwnd, b1X, b1Y) ||
            ! WaitForContextMenuPopupState(rootPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.hoveredIndex.has_value() && state.hoveredIndex.value() == 0u;
        }, rootState))
        {
            driverFailure = "moving from an open submenu back to its parent menu item updates root hover";
            return;
        }
        if (! WaitForNoSubmenuHoverTimerForMenuSuite(rootPopupHwnd, rootState) || IsWindow(submenuHwnd) == FALSE)
        {
            driverFailure = "moving from an open submenu back to its parent menu item keeps the submenu open";
            return;
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the submenu hover-retention validation popup with Escape returns no invoked command");
}

void TestMenuKeyboardTabExitsMenuLoop()
{
    RunMenuDismissalKeyScenario(WM_KEYDOWN,
                                VK_TAB,
                                "menu popup window appears for Tab dismissal validation",
                                "Tab dismisses the active menu popup chain",
                                "dismissing the menu popup with Tab preserves or restores focus to the previously focused control");
}

void TestMenuKeyboardF10ExitsMenuLoop()
{
    RunMenuDismissalKeyScenario(WM_SYSKEYDOWN,
                                VK_F10,
                                "menu popup window appears for F10 dismissal validation",
                                "F10 dismisses the active menu popup chain",
                                "dismissing the menu popup with F10 preserves or restores focus to the previously focused control");
}

void TestMenuKeyboardAltExitsMenuLoop()
{
    RunMenuDismissalKeyScenario(WM_SYSKEYDOWN,
                                VK_MENU,
                                "menu popup window appears for Alt dismissal validation",
                                "Alt dismisses the active menu popup chain",
                                "dismissing the menu popup with Alt preserves or restores focus to the previously focused control");
}

void TestMenuKeyboardLeftArrowMatchesWindowsMenuLoop()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<std::vector<MenuFlyoutItem>> rootMenus = {
        {
            {.text = L"A1", .commandId = 3401},
            {.text = L"A2", .commandId = 3402},
        },
        {
            {.text      = L"B1",
             .commandId = 3501,
             .children =
                 {
                     MenuFlyoutItem{.text = L"B11", .commandId = 3511},
                     MenuFlyoutItem{.text = L"B12", .commandId = 3512},
                 }},
            {.text = L"B2", .commandId = 3502},
        },
        {
            {.text = L"C1", .commandId = 3601},
            {.text = L"C2", .commandId = 3602},
        },
    };

    size_t activeRootIndex = 1u;
    ContextMenuSessionCallbacks sessionCallbacks{};
    sessionCallbacks.switchRootFromDirection = [&](bool forward) -> std::optional<ContextMenuRootSwitchRequest>
    {
        activeRootIndex = forward ? ((activeRootIndex + 1u) % rootMenus.size()) : ((activeRootIndex + rootMenus.size() - 1u) % rootMenus.size());

        ContextMenuRootSwitchRequest request{};
        request.screenPoint = POINT{180, 180};
        request.items       = rootMenus[activeRootIndex];
        return request;
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND bPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"B1");
        if (! bPopupHwnd)
        {
            driverFailure = "menu popup window appears for left-arrow menu loop validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        ContextMenuPopupDebugState popupState{};
        PostMessageW(bPopupHwnd, WM_KEYDOWN, VK_HOME, 0);
        if (! WaitForContextMenuPopupState(bPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "Home selects B1 before left-arrow submenu validation";
            return;
        }

        PostMessageW(bPopupHwnd, WM_KEYDOWN, VK_RIGHT, 0);
        const HWND bSubmenuHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"B11");
        if (! bSubmenuHwnd)
        {
            driverFailure = "Right arrow on B1 opens the B submenu before left-arrow validation";
            return;
        }

        if (! WaitForContextMenuPopupState(bSubmenuHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "Right arrow on B1 focuses B11 before left-arrow validation";
            return;
        }

        PostMessageW(bSubmenuHwnd, WM_KEYDOWN, VK_LEFT, 0);
        if (! WaitForWindowDestroyed(bSubmenuHwnd))
        {
            driverFailure = "Left arrow closes the active submenu before switching roots";
            return;
        }

        if (! WaitForContextMenuPopupState(bPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "closing the submenu restores keyboard focus to B1";
            return;
        }

        PostMessageW(bPopupHwnd, WM_KEYDOWN, VK_LEFT, 0);
        const HWND aPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"A1");
        if (! aPopupHwnd)
        {
            driverFailure = "a second Left arrow on B switches to the previous root popup";
            return;
        }

        if (! WaitForContextMenuPopupState(aPopupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.keyboardIndex.has_value() && state.keyboardIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "switching to the previous root popup focuses A1";
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, rootMenus[activeRootIndex], theme, sessionCallbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the left-arrow menu loop validation popup with Escape returns no invoked command");
}

void TestNativeMenuBarRestoresFocusAfterMenuDismiss()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 240, SWP_NOZORDER);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOW);
    ownerWindow.PumpMessages();

    wil::unique_hwnd focusedChild{CreateWindowExW(
        0, L"BUTTON", L"Pane", WS_CHILD | WS_VISIBLE | WS_TABSTOP, 12, 80, 120, 28, ownerWindow.Hwnd(), nullptr, GetModuleHandleW(nullptr), nullptr)};
    Require(focusedChild != nullptr, "focus-restoration validation creates a focusable child control");

    wil::unique_hmenu menu{CreateMenu()};
    Require(menu != nullptr, "focus-restoration validation creates a top-level native menu");

    wil::unique_hmenu filePopup{CreatePopupMenu()};
    Require(filePopup != nullptr, "focus-restoration validation creates a native popup menu");
    Require(AppendMenuW(filePopup.get(), MF_STRING, 3801u, L"&Open") != FALSE, "focus-restoration validation populates the native popup menu");
    Require(AppendMenuW(menu.get(), MF_POPUP, reinterpret_cast<UINT_PTR>(filePopup.get()), L"&File") != FALSE,
            "focus-restoration validation attaches the popup menu to the native menu bar");
    static_cast<void>(filePopup.release());

    NativeMenuBarHost menuBarHost;
    Require(menuBarHost.Attach(GetModuleHandleW(nullptr), ownerWindow.Hwnd(), menu.get()), "native menu bar host attaches for focus-restoration validation");
    ownerWindow.PumpMessages();

    if (! TryActivateDxUiTestWindow(ownerWindow.Hwnd()))
    {
        SkipDxUiTest("DxUi menu popup requires an interactive desktop for native menu-bar focus restoration");
        return;
    }
    static_cast<void>(SetFocus(focusedChild.get()));
    Require(WaitForFocusedWindow(focusedChild.get()), "focus-restoration validation starts with focus on the child control");

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "native menu bar opens a popup for focus-restoration validation";
            return;
        }

        PostMessageW(popupHwnd, WM_KEYDOWN, VK_TAB, 0);
        if (! WaitForWindowDestroyed(popupHwnd))
        {
            driverFailure = "Tab dismisses the native menu bar popup during focus-restoration validation";
        }
    });

    Require(menuBarHost.FocusFirstItem(), "native menu bar host enters menu mode for focus-restoration validation");
    static_cast<void>(SendMessageW(menuBarHost.GetHwnd(), WM_KEYDOWN, VK_DOWN, 0));
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(WaitForFocusedWindow(focusedChild.get()), "dismissing the native menu bar popup restores focus to the previously focused child control");
}

constexpr UINT kDestroyNativeMenuBarHostMessage    = WM_APP + 0x53Eu;
constexpr UINT_PTR kDestroyNativeMenuBarSubclassId = 0x53Eu;

struct DestroyNativeMenuBarHostState final
{
    DestroyNativeMenuBarHostState()                                                = default;
    DestroyNativeMenuBarHostState(const DestroyNativeMenuBarHostState&)            = delete;
    DestroyNativeMenuBarHostState(DestroyNativeMenuBarHostState&&)                 = delete;
    DestroyNativeMenuBarHostState& operator=(const DestroyNativeMenuBarHostState&) = delete;
    DestroyNativeMenuBarHostState& operator=(DestroyNativeMenuBarHostState&&)      = delete;

    std::unique_ptr<DxUi::NativeMenuBarHost>* menuBarHost = nullptr;
    std::atomic_bool destroyed                            = false;
};

LRESULT CALLBACK DestroyNativeMenuBarHostSubclassProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam, UINT_PTR, DWORD_PTR refData) noexcept
{
    if (message == kDestroyNativeMenuBarHostMessage)
    {
        auto* const state = reinterpret_cast<DestroyNativeMenuBarHostState*>(refData);
        if (state && state->menuBarHost)
        {
            state->menuBarHost->reset();
            state->destroyed.store(true, std::memory_order_release);
        }
        return 0;
    }

    return DefSubclassProc(hwnd, message, wParam, lParam);
}

void TestNativeMenuBarNestedPopupCanDestroyHostSafely()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 360, 240, SWP_NOZORDER);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOW);
    ownerWindow.PumpMessages();
    if (! TryActivateDxUiTestWindow(ownerWindow.Hwnd()))
    {
        SkipDxUiTest("DxUi native menu destruction proof requires an interactive desktop");
        return;
    }

    wil::unique_hmenu menu{CreateMenu()};
    Require(menu != nullptr, "native menu destruction proof creates a top-level menu");
    wil::unique_hmenu filePopup{CreatePopupMenu()};
    Require(filePopup != nullptr, "native menu destruction proof creates a popup menu");
    Require(AppendMenuW(filePopup.get(), MF_STRING, 3901u, L"&Open") != FALSE, "native menu destruction proof populates the popup");
    Require(AppendMenuW(menu.get(), MF_POPUP, reinterpret_cast<UINT_PTR>(filePopup.get()), L"&File") != FALSE,
            "native menu destruction proof attaches the popup to the menu bar");
    static_cast<void>(filePopup.release());

    auto menuBarHost = std::make_unique<NativeMenuBarHost>();
    Require(menuBarHost->Attach(GetModuleHandleW(nullptr), ownerWindow.Hwnd(), menu.get()), "native menu destruction proof attaches the menu bar host");
    ownerWindow.PumpMessages();

    DestroyNativeMenuBarHostState destroyState;
    destroyState.menuBarHost = &menuBarHost;
    Require(SetWindowSubclass(
                ownerWindow.Hwnd(), DestroyNativeMenuBarHostSubclassProc, kDestroyNativeMenuBarSubclassId, reinterpret_cast<DWORD_PTR>(&destroyState)) != FALSE,
            "native menu destruction proof subclasses the owner window");
    const auto removeSubclass = wil::scope_exit([&]() noexcept
    { static_cast<void>(RemoveWindowSubclass(ownerWindow.Hwnd(), DestroyNativeMenuBarHostSubclassProc, kDestroyNativeMenuBarSubclassId)); });

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });
        const HWND popupHwnd    = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Open");
        if (! popupHwnd)
        {
            driverFailure = "native menu popup opens before destroying its menu-bar host";
            return;
        }

        if (PostMessageW(ownerWindow.Hwnd(), kDestroyNativeMenuBarHostMessage, 0, 0) == FALSE)
        {
            driverFailure = "native menu destruction request posts to the owner";
            return;
        }

        const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(1500);
        while (! destroyState.destroyed.load(std::memory_order_acquire) && std::chrono::steady_clock::now() < deadline)
        {
            Sleep(5);
        }
        if (! destroyState.destroyed.load(std::memory_order_acquire))
        {
            driverFailure = "native menu-bar host is destroyed inside the nested popup loop";
            return;
        }

        if (IsWindow(popupHwnd) != FALSE)
        {
            SendMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
        }
    });

    const bool activated = menuBarHost->ActivateMnemonic(L'F');
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(activated, "native menu activation returns after its host is destroyed inside the popup loop");
    Require(destroyState.destroyed.load(std::memory_order_acquire) && ! menuBarHost,
            "native menu nested-loop proof destroys the menu-bar host without a stale post-loop dereference");
}

void TestMenuInfoRowsDoNotDismissOnClick()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<MenuFlyoutItem> items = {
        {.kind = MenuItemKind::Info, .text = L"Volume Label:", .acceleratorText = L"Home"},
        {.kind = MenuItemKind::Standard, .text = L"Disk Properties...", .commandId = 3001},
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for info-row click validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        D2D1_RECT_F infoRectDip = D2D1::RectF();
        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(popupHwnd,
                                           [](const ContextMenuPopupDebugState& state) noexcept
        { return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f; },
                                           popupState) ||
            ! WaitForContextMenuPopupItemRect(popupHwnd, 0u, infoRectDip))
        {
            driverFailure = "info-row popup exposes geometry and debug state";
            return;
        }

        const float scale       = static_cast<float>(popupState.dpi) / 96.0f;
        const LONG clientX      = static_cast<LONG>(std::lround(((infoRectDip.left + infoRectDip.right) * 0.5f) * scale));
        const LONG clientY      = static_cast<LONG>(std::lround(((infoRectDip.top + infoRectDip.bottom) * 0.5f) * scale));
        const LPARAM clickPoint = MAKELPARAM(clientX, clientY);

        if (! SendSettledClientMouseMoveForMenuSuite(popupHwnd, clientX, clientY))
        {
            driverFailure = "moving the pointer to the info row before clicking succeeds";
            return;
        }
        PostMessageW(popupHwnd, WM_LBUTTONDOWN, MK_LBUTTON, clickPoint);
        PostMessageW(popupHwnd, WM_LBUTTONUP, 0, clickPoint);

        std::this_thread::sleep_for(std::chrono::milliseconds(80));
        if (IsWindow(popupHwnd) == FALSE)
        {
            driverFailure = "clicking an info row does not dismiss the popup";
            return;
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "clicking an info row does not invoke a command");
}

void TestMenuPopupPositionClampsAcrossDpiMatrix()
{
    using namespace DxUi;

    const RECT virtualScreen    = GetVirtualScreenBounds();
    constexpr UINT kDpiMatrix[] = {96u, 120u, 144u, 168u, 192u};

    for (const UINT dpi : kDpiMatrix)
    {
        RECT popupRect{};
        const POINT topLeftAnchor{virtualScreen.left - 80, virtualScreen.top - 60};
        const RECT topLeftWorkArea = GetNearestMonitorWorkArea(topLeftAnchor);
        Require(DebugComputeContextMenuPopupPosition(
                    topLeftAnchor, 240.0f, 180.0f, dpi, false, nullptr, nullptr, ContextMenuRootHorizontalAlignment::Start, popupRect),
                std::format("root popup position resolves for {} DPI near the top-left edge", dpi).c_str());
        Require(popupRect.left == topLeftWorkArea.left, std::format("root popup clamps left to the work area at {} DPI", dpi).c_str());
        Require(popupRect.top == topLeftWorkArea.top, std::format("root popup clamps top to the work area at {} DPI", dpi).c_str());
        Require(popupRect.right <= topLeftWorkArea.right && popupRect.bottom <= topLeftWorkArea.bottom,
                std::format("root popup stays inside the work area after top-left clamping at {} DPI", dpi).c_str());

        popupRect = RECT{};
        const POINT bottomRightAnchor{virtualScreen.right + 80, virtualScreen.bottom + 60};
        const RECT bottomRightWorkArea = GetNearestMonitorWorkArea(bottomRightAnchor);
        Require(DebugComputeContextMenuPopupPosition(
                    bottomRightAnchor, 240.0f, 180.0f, dpi, false, nullptr, nullptr, ContextMenuRootHorizontalAlignment::Start, popupRect),
                std::format("root popup position resolves for {} DPI near the bottom-right edge", dpi).c_str());
        Require(popupRect.right == bottomRightWorkArea.right, std::format("root popup clamps right to the work area at {} DPI", dpi).c_str());
        Require(popupRect.bottom == bottomRightWorkArea.bottom, std::format("root popup clamps bottom to the work area at {} DPI", dpi).c_str());
        Require(popupRect.left >= bottomRightWorkArea.left && popupRect.top >= bottomRightWorkArea.top,
                std::format("root popup stays inside the work area after bottom-right clamping at {} DPI", dpi).c_str());
    }
}

void TestMenuPopupPositionSupportsRightAlignedRootAnchors()
{
    using namespace DxUi;

    const RECT workArea         = GetPrimaryMonitorWorkArea();
    constexpr UINT kDpiMatrix[] = {96u, 120u, 144u, 168u, 192u};

    for (const UINT dpi : kDpiMatrix)
    {
        RECT popupRect{};
        const int anchorRightPx = workArea.right - 24;
        Require(DebugComputeContextMenuPopupPosition(
                    POINT{anchorRightPx, workArea.top + 48}, 220.0f, 160.0f, dpi, false, nullptr, nullptr, ContextMenuRootHorizontalAlignment::End, popupRect),
                std::format("right-aligned root popup position resolves at {} DPI", dpi).c_str());
        Require(popupRect.right == anchorRightPx, std::format("right-aligned root popup keeps its visible right edge on the anchor at {} DPI", dpi).c_str());
        Require(popupRect.left >= workArea.left && popupRect.top >= workArea.top && popupRect.bottom <= workArea.bottom,
                std::format("right-aligned root popup still stays inside the work area at {} DPI", dpi).c_str());

        const int anchorLeftPx = workArea.left + 1;
        Require(DebugComputeContextMenuPopupPosition(
                    POINT{anchorLeftPx, workArea.top + 92}, 220.0f, 160.0f, dpi, false, nullptr, nullptr, ContextMenuRootHorizontalAlignment::End, popupRect),
                std::format("right-aligned root popup resolves near the left edge at {} DPI", dpi).c_str());
        Require(popupRect.left == anchorLeftPx,
                std::format("right-aligned root popup falls back to a start-aligned placement when trailing alignment would cross the left edge at {} DPI "
                            "(left={}, right={}, anchor={})",
                            dpi,
                            popupRect.left,
                            popupRect.right,
                            anchorLeftPx)
                    .c_str());
        Require(popupRect.right <= workArea.right && popupRect.top >= workArea.top && popupRect.bottom <= workArea.bottom,
                std::format("right-aligned root popup fallback still stays inside the work area at {} DPI", dpi).c_str());
    }
}

void TestMenuPopupPositionSupportsAboveRightAlignedRootAnchors()
{
    using namespace DxUi;

    const RECT workArea         = GetPrimaryMonitorWorkArea();
    constexpr UINT kDpiMatrix[] = {96u, 120u, 144u, 168u, 192u};

    for (const UINT dpi : kDpiMatrix)
    {
        RECT popupRect{};
        const int anchorRightPx = workArea.left + ((workArea.right - workArea.left) / 2);
        const int anchorTopPx   = workArea.bottom - 96;
        Require(DebugComputeContextMenuPopupPosition(POINT{anchorRightPx, anchorTopPx},
                                                     220.0f,
                                                     160.0f,
                                                     dpi,
                                                     false,
                                                     nullptr,
                                                     nullptr,
                                                     ContextMenuRootHorizontalAlignment::End,
                                                     ContextMenuRootVerticalPlacement::Above,
                                                     popupRect),
                std::format("above/right-aligned root popup position resolves at {} DPI", dpi).c_str());
        Require(popupRect.right == anchorRightPx,
                std::format("above/right-aligned root popup keeps its visible right edge on the anchor at {} DPI", dpi).c_str());
        Require(popupRect.bottom == anchorTopPx,
                std::format("above/right-aligned root popup keeps its visible bottom edge above the anchor at {} DPI", dpi).c_str());
        Require(popupRect.left >= workArea.left && popupRect.top >= workArea.top && popupRect.right <= workArea.right,
                std::format("above/right-aligned root popup stays inside the work area at {} DPI", dpi).c_str());
    }
}

void TestMenuInfoRowsUseMeasuredValueColumnWidth()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<MenuFlyoutItem> items = {
        {.kind = MenuItemKind::Info, .text = L"Total Space:", .acceleratorText = L"1.82 TB (1999377526784 bytes)"},
        {.kind = MenuItemKind::Info, .text = L"Free Space:", .acceleratorText = L"1.27 TB"},
        {.kind = MenuItemKind::Standard, .text = L"Disk Properties...", .commandId = 3001},
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for measured info-row column validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        ContextMenuPopupItemLayoutDebugState firstLayout{};
        ContextMenuPopupItemLayoutDebugState secondLayout{};
        if (! WaitForContextMenuPopupItemLayout(popupHwnd, 0u, firstLayout) || ! WaitForContextMenuPopupItemLayout(popupHwnd, 1u, secondLayout))
        {
            driverFailure = "info-row popup exposes measured text and value-column layout";
            return;
        }

        const float firstValueWidth  = firstLayout.acceleratorRectDip.right - firstLayout.acceleratorRectDip.left;
        const float secondValueWidth = secondLayout.acceleratorRectDip.right - secondLayout.acceleratorRectDip.left;
        if (firstValueWidth <= 120.5f || secondValueWidth <= 120.5f)
        {
            driverFailure = "info rows expand the measured value column beyond the old fixed-width accelerator slot";
            return;
        }

        if (std::fabs(firstLayout.acceleratorRectDip.left - secondLayout.acceleratorRectDip.left) > 0.5f ||
            std::fabs(firstLayout.acceleratorRectDip.right - secondLayout.acceleratorRectDip.right) > 0.5f)
        {
            driverFailure = "info rows share a stable aligned value column";
            return;
        }

        if (firstLayout.textRectDip.right > firstLayout.acceleratorRectDip.left || secondLayout.textRectDip.right > secondLayout.acceleratorRectDip.left)
        {
            driverFailure = "info-row labels stay separated from the right-aligned value column";
            return;
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the measured info-row layout menu with Escape returns no invoked command");
}

void TestMenuStandardRowsDeriveAndAlignShortcutColumnFromTabbedText()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<MenuFlyoutItem> items = {
        {.kind = MenuItemKind::Standard, .text = L"&Open\tCtrl+O", .commandId = 3001},
        {.kind = MenuItemKind::Standard, .text = L"E&xit\t  Alt+F4  ", .commandId = 3002},
        {.kind = MenuItemKind::Standard, .text = L"Preferences...", .commandId = 3003},
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for tabbed shortcut layout validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        ContextMenuPopupItemLayoutDebugState firstLayout{};
        ContextMenuPopupItemLayoutDebugState secondLayout{};
        if (! WaitForContextMenuPopupItemLayout(popupHwnd, 0u, firstLayout) || ! WaitForContextMenuPopupItemLayout(popupHwnd, 1u, secondLayout))
        {
            driverFailure = "standard rows expose shared shortcut-column layout";
            return;
        }

        const float firstShortcutWidth  = firstLayout.acceleratorRectDip.right - firstLayout.acceleratorRectDip.left;
        const float secondShortcutWidth = secondLayout.acceleratorRectDip.right - secondLayout.acceleratorRectDip.left;
        if (firstShortcutWidth <= 12.0f || secondShortcutWidth <= 12.0f)
        {
            driverFailure = "tabbed standard rows allocate a visible right-aligned shortcut column";
            return;
        }

        if (std::fabs(firstLayout.acceleratorRectDip.left - secondLayout.acceleratorRectDip.left) > 0.5f ||
            std::fabs(firstLayout.acceleratorRectDip.right - secondLayout.acceleratorRectDip.right) > 0.5f)
        {
            driverFailure = "tabbed standard rows share a stable aligned shortcut column";
            return;
        }

        if (firstLayout.textRectDip.right > firstLayout.acceleratorRectDip.left || secondLayout.textRectDip.right > secondLayout.acceleratorRectDip.left)
        {
            driverFailure = "tabbed standard row labels stay separated from the derived shortcut column";
            return;
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the tabbed standard-row layout menu with Escape returns no invoked command");
}

void TestMenuShortcutRowsReserveChevronLaneWhenAnySubmenuExists()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<MenuFlyoutItem> items = {
        {.kind = MenuItemKind::Standard, .text = L"&More", .children = {{.kind = MenuItemKind::Standard, .text = L"Child", .commandId = 3101}}},
        {.kind = MenuItemKind::Standard, .text = L"&Open\tCtrl+O", .commandId = 3102},
        {.kind = MenuItemKind::Standard, .text = L"E&xit\tAlt+F4", .commandId = 3103},
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for shared chevron-lane layout validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        ContextMenuPopupItemLayoutDebugState submenuLayout{};
        ContextMenuPopupItemLayoutDebugState firstShortcutLayout{};
        ContextMenuPopupItemLayoutDebugState secondShortcutLayout{};
        if (! WaitForContextMenuPopupItemLayout(popupHwnd, 0u, submenuLayout) || ! WaitForContextMenuPopupItemLayout(popupHwnd, 1u, firstShortcutLayout) ||
            ! WaitForContextMenuPopupItemLayout(popupHwnd, 2u, secondShortcutLayout))
        {
            driverFailure = "menu popup exposes chevron and shortcut row layout";
            return;
        }

        const float chevronWidthDip = submenuLayout.chevronRectDip.right - submenuLayout.chevronRectDip.left;
        if (chevronWidthDip <= 8.0f)
        {
            driverFailure = "submenu row exposes a visible chevron lane";
            return;
        }

        if (firstShortcutLayout.acceleratorRectDip.right > submenuLayout.chevronRectDip.left + 0.5f ||
            secondShortcutLayout.acceleratorRectDip.right > submenuLayout.chevronRectDip.left + 0.5f)
        {
            driverFailure = "plain shortcut rows reserve the submenu chevron lane";
            return;
        }

        if (std::fabs(firstShortcutLayout.acceleratorRectDip.left - secondShortcutLayout.acceleratorRectDip.left) > 0.5f ||
            std::fabs(firstShortcutLayout.acceleratorRectDip.right - secondShortcutLayout.acceleratorRectDip.right) > 0.5f)
        {
            driverFailure = "plain shortcut rows keep the shared shortcut column aligned";
            return;
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the shared chevron-lane layout menu with Escape returns no invoked command");
}

void TestMenuBitmapIconsReachPopupLayout()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    std::vector<MenuFlyoutItem> items;
    items.push_back(MenuFlyoutItem{.text = L"Downloads", .iconBitmap = CreateSyntheticMenuBitmapIcon(16u), .commandId = 3001});

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for bitmap-icon validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        ContextMenuPopupItemLayoutDebugState layout{};
        if (! WaitForContextMenuPopupItemLayout(popupHwnd, 0u, layout))
        {
            driverFailure = "menu popup exposes layout for bitmap-icon item";
            return;
        }

        if (! layout.hasBitmapIcon)
        {
            driverFailure = "bitmap icon payload is preserved for popup rendering";
            return;
        }

        if (layout.iconRectDip.left < (layout.itemRectDip.left + 3.5f))
        {
            driverFailure = "bitmap icon slot begins inside the hovered row instead of before it";
            return;
        }

        if (layout.iconRectDip.right > (layout.textRectDip.left - 6.0f))
        {
            driverFailure = "bitmap icon slot leaves spacing before the menu text column";
        }
    });

    const ThemePalette theme        = MakeAnimatedTestThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the bitmap-icon menu with Escape returns no invoked command");
}

void TestMenuPopupMaterialsProduceDistinctCaptures()
{
    using namespace DxUi;

    const std::vector<MenuFlyoutItem> items = {
        {.text = L"Open", .commandId = 3001},
        {.text = L"Rename", .commandId = 3002},
        {.kind = MenuItemKind::Separator},
        {.text = L"Properties", .commandId = 3003},
    };

    ThemePalette micaTheme    = MakeAnimatedTestThemePalette(true);
    micaTheme.overlayMaterial = OverlayMaterial::Mica;

    ThemePalette micaAltTheme    = micaTheme;
    micaAltTheme.overlayMaterial = OverlayMaterial::MicaAlt;

    ThemePalette acrylicTheme    = micaTheme;
    acrylicTheme.overlayMaterial = OverlayMaterial::Acrylic;

    const WindowHostBitmapCapture micaCapture    = CaptureMenuPopupBitmapForTheme(micaTheme, items);
    const WindowHostBitmapCapture micaAltCapture = CaptureMenuPopupBitmapForTheme(micaAltTheme, items);
    const WindowHostBitmapCapture acrylicCapture = CaptureMenuPopupBitmapForTheme(acrylicTheme, items);

    const BitmapComparisonStats micaVsMicaAlt = CompareWindowHostBitmapCapturesForTest(micaCapture, micaAltCapture, 4u);
    Require(micaVsMicaAlt.totalPixels > 0u, "menu material captures share the same geometry for comparison");
    Require(micaVsMicaAlt.DifferenceRatio() > 0.01, "Mica and Mica Alt popup materials produce visibly different menu captures");

    const BitmapComparisonStats micaVsAcrylic = CompareWindowHostBitmapCapturesForTest(micaCapture, acrylicCapture, 4u);
    Require(micaVsAcrylic.totalPixels > 0u, "menu acrylic capture shares the same geometry for comparison");
    Require(micaVsAcrylic.DifferenceRatio() > 0.01, "Mica and Acrylic popup materials produce visibly different menu captures");
}

void TestMenuRainbowHoverUsesSeededHighlightContrast()
{
    using namespace DxUi;

    ThemePalette theme    = MakeAnimatedTestThemePalette(true);
    theme.rainbowMode     = true;
    theme.overlayMaterial = OverlayMaterial::Solid;

    const std::vector<MenuFlyoutItem> items = {
        {.kind = MenuItemKind::Radio, .text = L"Rainbow", .checked = true, .commandId = 8051},
        {.kind = MenuItemKind::Radio, .text = L"Forest Mist", .checked = false, .commandId = 8052},
    };

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    ContextMenuPopupDebugState popupState{};
    ContextMenuPopupItemPaintDebugState paintState{};
    D2D1_RECT_F firstRowRectDip = D2D1::RectF();
    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for rainbow hover highlight validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        if (! WaitForContextMenuPopupItemRect(popupHwnd, 0u, firstRowRectDip))
        {
            driverFailure = "menu popup exposes row bounds for rainbow hover highlight validation";
            return;
        }

        const LONG hoverX = static_cast<LONG>(std::lround((firstRowRectDip.left + firstRowRectDip.right) * 0.5f));
        const LONG hoverY = static_cast<LONG>(std::lround((firstRowRectDip.top + firstRowRectDip.bottom) * 0.5f));
        if (! SendSettledClientMouseMoveForMenuSuite(popupHwnd, hoverX, hoverY))
        {
            driverFailure = "moving the pointer onto the rainbow row succeeds";
            return;
        }

        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.hoveredIndex.has_value() && state.hoveredIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "moving the pointer onto the rainbow row sets popup hover";
            return;
        }

        if (! WaitForContextMenuPopupItemPaint(popupHwnd, 0u, paintState))
        {
            driverFailure = "menu popup exposes hovered paint state for rainbow highlight validation";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the rainbow hover highlight validation menu with Escape returns no invoked command");

    const D2D1_COLOR_F expectedFill       = RainbowMenuSelectionTint(L"Rainbow", theme.dark);
    const D2D1_COLOR_F expectedForeground = ChooseContrastingTextColor(expectedFill);
    Require(paintState.hovered, "rainbow hover highlight paint state reports the row as hovered");
    Require(paintState.usesHighlightFill, "rainbow hover highlight paint state reports the highlight backplate");
    Require(paintState.usesRainbowHighlight, "rainbow hover highlight paint state reports the seeded rainbow backplate");
    RequireColorNear(paintState.fillColor, expectedFill, "rainbow hover highlight uses the stable seeded menu rainbow fill");
    RequireColorNear(paintState.compositeFillColor, expectedFill, "opaque rainbow hover highlight keeps its composite fill identical to the seeded color");
    RequireColorNear(paintState.textColor, expectedForeground, "rainbow hover highlight text uses the contrasting foreground");
    RequireColorNear(paintState.checkColor, expectedForeground, "rainbow hover highlight radio indicator uses the contrasting foreground");
}

void TestMenuHoverContrastAppliesToGlyphsAcrossThemes()
{
    using namespace DxUi;

    ThemePalette theme      = MakeAnimatedTestThemePalette(false);
    theme.rainbowMode       = false;
    theme.highContrast      = false;
    theme.overlayMaterial   = OverlayMaterial::Acrylic;
    theme.overlayBackground = D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f);
    theme.headerHovered     = D2D1::ColorF(0.0f, 0.0f, 0.0f, 1.0f);
    theme.accent            = D2D1::ColorF(0.0f, 0.0f, 0.0f, 1.0f);
    theme.text              = D2D1::ColorF(0.98f, 0.98f, 0.98f, 1.0f);
    theme.subduedText       = theme.text;

    const std::vector<MenuFlyoutItem> items = {
        {.text = L"Open With\tCtrl+Enter", .iconGlyph = L"\uE8A7", .commandId = 8151, .children = {MenuFlyoutItem{.text = L"Viewer", .commandId = 8152}}},
    };

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    ContextMenuPopupDebugState popupState{};
    ContextMenuPopupItemPaintDebugState paintState{};
    D2D1_RECT_F firstRowRectDip = D2D1::RectF();
    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for hover foreground contrast validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        if (! WaitForContextMenuPopupItemRect(popupHwnd, 0u, firstRowRectDip))
        {
            driverFailure = "menu popup exposes row bounds for hover foreground contrast validation";
            return;
        }

        const LONG hoverX = static_cast<LONG>(std::lround((firstRowRectDip.left + firstRowRectDip.right) * 0.5f));
        const LONG hoverY = static_cast<LONG>(std::lround((firstRowRectDip.top + firstRowRectDip.bottom) * 0.5f));
        if (! SendSettledClientMouseMoveForMenuSuite(popupHwnd, hoverX, hoverY))
        {
            driverFailure = "moving the pointer onto the contrast row succeeds";
            return;
        }

        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.hoveredIndex.has_value() && state.hoveredIndex.value() == 0u;
        }, popupState))
        {
            driverFailure = "moving the pointer onto the custom-theme row sets popup hover";
            return;
        }

        if (! WaitForContextMenuPopupItemPaint(popupHwnd, 0u, paintState))
        {
            driverFailure = "menu popup exposes hovered paint state for hover foreground contrast validation";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the hover foreground contrast validation menu with Escape returns no invoked command");

    const D2D1_COLOR_F expectedForeground = ChooseContrastingTextColor(paintState.compositeFillColor);
    RequireColorDifferent(theme.text, expectedForeground, "custom non-rainbow hover validation requires a foreground different from the base text token");
    Require(! paintState.usesRainbowHighlight, "non-rainbow hover validation keeps the shared highlight path out of rainbow mode");
    RequireColorNear(paintState.textColor, expectedForeground, "non-rainbow menu hover text uses the contrasting foreground");
    RequireColorNear(paintState.acceleratorColor, expectedForeground, "non-rainbow menu hover accelerator uses the contrasting foreground");
    RequireColorNear(paintState.iconColor, expectedForeground, "non-rainbow menu hover icon glyph uses the contrasting foreground");
    RequireColorNear(paintState.chevronColor, expectedForeground, "non-rainbow menu hover submenu chevron uses the contrasting foreground");
}

void TestMenuRainbowCheckedItemUsesAccentIndicator()
{
    using namespace DxUi;

    ThemePalette theme    = MakeAnimatedTestThemePalette(true);
    theme.rainbowMode     = true;
    theme.overlayMaterial = OverlayMaterial::Solid;

    const std::vector<MenuFlyoutItem> items = {
        {.kind = MenuItemKind::Radio, .text = L"Rainbow", .checked = true, .commandId = 8101},
        {.kind = MenuItemKind::Radio, .text = L"High Contrast", .checked = false, .commandId = 8102},
    };

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    WindowHostBitmapCapture capture{};
    ContextMenuPopupItemLayoutDebugState checkedLayout{};
    ContextMenuPopupItemLayoutDebugState uncheckedLayout{};
    ContextMenuPopupDebugState popupState{};
    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for rainbow checked-row validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState&) noexcept { return true; }, popupState))
        {
            driverFailure = "menu popup exposes debug state for rainbow checked-row validation";
            return;
        }
        if (! WaitForContextMenuPopupBitmapCapture(popupHwnd, capture))
        {
            driverFailure = "menu popup bitmap capture succeeds for rainbow checked-row validation";
            return;
        }
        if (! WaitForContextMenuPopupItemLayout(popupHwnd, 0u, checkedLayout))
        {
            driverFailure = "menu popup exposes checked-row layout for rainbow checked-row validation";
            return;
        }
        if (! WaitForContextMenuPopupItemLayout(popupHwnd, 1u, uncheckedLayout))
        {
            driverFailure = "menu popup exposes unchecked-row layout for rainbow checked-row validation";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the rainbow checked-row menu with Escape returns no invoked command");

    const float iconCenterXDip = (checkedLayout.iconRectDip.left + checkedLayout.iconRectDip.right) * 0.5f;
    const UINT sampleX         = (std::min)(capture.widthPx - 1u, DipToPixelForPopup(iconCenterXDip, popupState.dpi));
    const UINT checkedY =
        (std::min)(capture.heightPx - 1u, DipToPixelForPopup((checkedLayout.iconRectDip.top + checkedLayout.iconRectDip.bottom) * 0.5f, popupState.dpi));
    const UINT uncheckedY =
        (std::min)(capture.heightPx - 1u, DipToPixelForPopup((uncheckedLayout.iconRectDip.top + uncheckedLayout.iconRectDip.bottom) * 0.5f, popupState.dpi));

    Require(GetCapturePixelBgra(capture, sampleX, checkedY) != GetCapturePixelBgra(capture, sampleX, uncheckedY),
            "rainbow checked menu rows render an accent-colored check indicator distinct from unchecked rows");
}

void TestMenuCheckedRowsDoNotPaintSecondFullRowSelection()
{
    using namespace DxUi;

    ThemePalette theme    = MakeAnimatedTestThemePalette(true);
    theme.rainbowMode     = true;
    theme.overlayMaterial = OverlayMaterial::Solid;

    const std::vector<MenuFlyoutItem> uncheckedItems = {
        {.kind = MenuItemKind::Radio, .text = L"Rainbow", .checked = false, .commandId = 8201},
        {.kind = MenuItemKind::Radio, .text = L"Forest Mist", .checked = false, .commandId = 8202},
        {.kind = MenuItemKind::Radio, .text = L"Neon Tokyo", .checked = false, .commandId = 8203},
    };
    const std::vector<MenuFlyoutItem> checkedItems = {
        {.kind = MenuItemKind::Radio, .text = L"Rainbow", .checked = true, .commandId = 8201},
        {.kind = MenuItemKind::Radio, .text = L"Forest Mist", .checked = false, .commandId = 8202},
        {.kind = MenuItemKind::Radio, .text = L"Neon Tokyo", .checked = false, .commandId = 8203},
    };

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const auto captureTrailingPixel = [&](const std::vector<MenuFlyoutItem>& items, uint32_t& trailingPixel, std::string& failure) noexcept
    {
        WindowHostBitmapCapture capture{};
        D2D1_RECT_F firstRowRectDip = D2D1::RectF();
        D2D1_RECT_F hoverRowRectDip = D2D1::RectF();
        ContextMenuPopupDebugState popupState{};
        std::thread driver([&]
        {
            const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), failure);
            const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
            if (! popupHwnd)
            {
                failure = "menu popup window appears for checked-row selection validation";
                return;
            }

            const auto dismissPopup = wil::scope_exit([&]() noexcept
            {
                if (IsWindow(popupHwnd) != FALSE)
                {
                    PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
                }
            });

            if (! WaitForContextMenuPopupItemRect(popupHwnd, 0u, firstRowRectDip) || ! WaitForContextMenuPopupItemRect(popupHwnd, 1u, hoverRowRectDip))
            {
                failure = "menu popup exposes row bounds for checked-row selection validation";
                return;
            }

            const LONG hoverX = static_cast<LONG>(std::lround((hoverRowRectDip.left + hoverRowRectDip.right) * 0.5f));
            const LONG hoverY = static_cast<LONG>(std::lround((hoverRowRectDip.top + hoverRowRectDip.bottom) * 0.5f));
            if (! SendSettledClientMouseMoveForMenuSuite(popupHwnd, hoverX, hoverY))
            {
                failure = "moving the pointer to a plain row before checked-row selection capture succeeds";
                return;
            }

            if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
                return state.hoveredIndex.has_value() && state.hoveredIndex.value() == 1u;
            }, popupState))
            {
                failure = "moving the pointer to a plain row transfers popup hover there";
                return;
            }

            if (! WaitForContextMenuPopupBitmapCapture(popupHwnd, capture))
            {
                failure = "menu popup bitmap capture succeeds for checked-row selection validation";
            }
        });

        const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
        driver.join();

        if (! failure.empty())
        {
            return;
        }

        if (result.has_value())
        {
            failure = "closing the checked-row selection validation menu with Escape returns no invoked command";
            return;
        }

        const UINT sampleX = (std::min)(capture.widthPx - 1u, DipToPixelForPopup(firstRowRectDip.right - 18.0f, popupState.dpi));
        const UINT sampleY = (std::min)(capture.heightPx - 1u, DipToPixelForPopup((firstRowRectDip.top + firstRowRectDip.bottom) * 0.5f, popupState.dpi));
        trailingPixel      = GetCapturePixelBgra(capture, sampleX, sampleY);
    };

    uint32_t uncheckedTrailingPixel = 0u;
    uint32_t checkedTrailingPixel   = 0u;
    std::string driverFailure;
    captureTrailingPixel(uncheckedItems, uncheckedTrailingPixel, driverFailure);
    Require(driverFailure.empty(), driverFailure.c_str());
    captureTrailingPixel(checkedItems, checkedTrailingPixel, driverFailure);
    Require(driverFailure.empty(), driverFailure.c_str());

    Require(uncheckedTrailingPixel == checkedTrailingPixel,
            "checked menu rows do not paint a second full-width selection backplate when another row is hovered");
}

void TestMenuCheckedRowsDoNotPaintLeadingCheckedBox()
{
    using namespace DxUi;

    ThemePalette theme    = MakeAnimatedTestThemePalette(true);
    theme.overlayMaterial = OverlayMaterial::Solid;

    const std::vector<MenuFlyoutItem> uncheckedItems = {
        {.kind = MenuItemKind::Toggle, .text = L"Show Hidden Files", .checked = false, .commandId = 8301},
        {.kind = MenuItemKind::Toggle, .text = L"Show System Files", .checked = false, .commandId = 8302},
    };
    const std::vector<MenuFlyoutItem> checkedItems = {
        {.kind = MenuItemKind::Toggle, .text = L"Show Hidden Files", .checked = true, .commandId = 8301},
        {.kind = MenuItemKind::Toggle, .text = L"Show System Files", .checked = false, .commandId = 8302},
    };

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const auto captureLeadingPixel = [&](const std::vector<MenuFlyoutItem>& items, uint32_t& leadingPixel, std::string& failure) noexcept
    {
        WindowHostBitmapCapture capture{};
        ContextMenuPopupItemLayoutDebugState firstLayout{};
        D2D1_RECT_F hoverRowRectDip = D2D1::RectF();
        ContextMenuPopupDebugState popupState{};
        std::thread driver([&]
        {
            const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), failure);
            const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
            if (! popupHwnd)
            {
                failure = "menu popup window appears for checked-indicator box validation";
                return;
            }

            const auto dismissPopup = wil::scope_exit([&]() noexcept
            {
                if (IsWindow(popupHwnd) != FALSE)
                {
                    PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
                }
            });

            if (! WaitForContextMenuPopupItemLayout(popupHwnd, 0u, firstLayout) || ! WaitForContextMenuPopupItemRect(popupHwnd, 1u, hoverRowRectDip))
            {
                failure = "menu popup exposes leading indicator geometry for checked-indicator box validation";
                return;
            }

            const LONG hoverX = static_cast<LONG>(std::lround((hoverRowRectDip.left + hoverRowRectDip.right) * 0.5f));
            const LONG hoverY = static_cast<LONG>(std::lround((hoverRowRectDip.top + hoverRowRectDip.bottom) * 0.5f));
            if (! SendSettledClientMouseMoveForMenuSuite(popupHwnd, hoverX, hoverY))
            {
                failure = "moving the pointer away from the checked row before checked-indicator capture succeeds";
                return;
            }

            if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
                return state.hoveredIndex.has_value() && state.hoveredIndex.value() == 1u;
            }, popupState))
            {
                failure = "moving the pointer away from the checked row transfers popup hover to the plain row";
                return;
            }

            if (! WaitForContextMenuPopupBitmapCapture(popupHwnd, capture))
            {
                failure = "menu popup bitmap capture succeeds for checked-indicator box validation";
            }
        });

        const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
        driver.join();

        if (! failure.empty())
        {
            return;
        }

        if (result.has_value())
        {
            failure = "closing the checked-indicator box validation menu with Escape returns no invoked command";
            return;
        }

        const UINT sampleX = (std::min)(capture.widthPx - 1u, DipToPixelForPopup(firstLayout.iconRectDip.left + 2.0f, popupState.dpi));
        const UINT sampleY =
            (std::min)(capture.heightPx - 1u, DipToPixelForPopup((firstLayout.iconRectDip.top + firstLayout.iconRectDip.bottom) * 0.5f, popupState.dpi));
        leadingPixel = GetCapturePixelBgra(capture, sampleX, sampleY);
    };

    uint32_t uncheckedLeadingPixel = 0u;
    uint32_t checkedLeadingPixel   = 0u;
    std::string driverFailure;
    captureLeadingPixel(uncheckedItems, uncheckedLeadingPixel, driverFailure);
    Require(driverFailure.empty(), driverFailure.c_str());
    captureLeadingPixel(checkedItems, checkedLeadingPixel, driverFailure);
    Require(driverFailure.empty(), driverFailure.c_str());

    Require(uncheckedLeadingPixel == checkedLeadingPixel, "checked menu rows do not paint a rounded leading box behind the check indicator");
}

void TestMenuPopupCompositionHostUsesTransparentShadowMargins()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<MenuFlyoutItem> items = {
        {.text = L"Desktop", .commandId = 3001},
        {.text = L"Documents", .commandId = 3002},
        {.text = L"Downloads", .commandId = 3003},
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for composition shadow-margin validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        ContextMenuPopupDebugState popupState{};
        WindowHostBitmapCapture capture{};
        if (! WaitForContextMenuPopupState(popupHwnd,
                                           [](const ContextMenuPopupDebugState& state) noexcept
        { return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f; },
                                           popupState) ||
            ! WaitForContextMenuPopupBitmapCapture(popupHwnd, capture))
        {
            driverFailure = "composition popup exposes geometry and bitmap capture";
            return;
        }

        const double scale         = static_cast<double>(popupState.dpi) / 96.0;
        const UINT visibleWidthPx  = static_cast<UINT>((std::max)(1ll, std::llround(static_cast<double>(popupState.visibleWidthDip) * scale)));
        const UINT visibleHeightPx = static_cast<UINT>((std::max)(1ll, std::llround(static_cast<double>(popupState.visibleHeightDip) * scale)));
        if (capture.widthPx <= visibleWidthPx || capture.heightPx <= visibleHeightPx)
        {
            driverFailure = "composition popup capture includes transparent window margins outside the visible menu surface";
            return;
        }

        const uint8_t topLeftAlpha       = GetCapturePixelAlpha(capture, 0u, 0u);
        const uint8_t topRightAlpha      = GetCapturePixelAlpha(capture, capture.widthPx - 1u, 0u);
        const uint8_t centerAlpha        = GetCapturePixelAlpha(capture, capture.widthPx / 2u, capture.heightPx / 2u);
        const UINT visibleLeftPx         = static_cast<UINT>((std::max)(1ll, std::llround(10.0 * scale)));
        const UINT visibleTopPx          = static_cast<UINT>((std::max)(1ll, std::llround(8.0 * scale)));
        const UINT visibleCornerProbeX   = (std::min)(capture.widthPx - 1u, visibleLeftPx + 2u);
        const UINT visibleCornerProbeY   = (std::min)(capture.heightPx - 1u, visibleTopPx + 2u);
        const uint8_t visibleCornerAlpha = GetCapturePixelAlpha(capture, visibleCornerProbeX, visibleCornerProbeY);
        if (topLeftAlpha > 8u || topRightAlpha > 8u)
        {
            driverFailure = "composition popup keeps outer window corners transparent";
            return;
        }
        if (centerAlpha < 32u)
        {
            driverFailure = "composition popup keeps the menu surface itself visibly opaque inside the transparent window";
            return;
        }
        if (visibleCornerAlpha < 64u)
        {
            driverFailure = "composition popup keeps a RoundSmall-style near-corner body pixel inside the visible menu surface instead of clipping too deeply";
            return;
        }

        RECT popupRect{};
        if (GetWindowRect(popupHwnd, &popupRect) == FALSE)
        {
            driverFailure = "composition popup exposes a valid window rectangle for region validation";
            return;
        }

        const int popupWidthPx  = popupRect.right - popupRect.left;
        const int popupHeightPx = popupRect.bottom - popupRect.top;
        if (popupWidthPx <= 0 || popupHeightPx <= 0)
        {
            driverFailure = "composition popup keeps a positive-sized window rectangle";
            return;
        }

        wil::unique_hrgn windowRegion(CreateRectRgn(0, 0, 0, 0));
        if (! windowRegion)
        {
            driverFailure = "composition popup test can allocate a region handle";
            return;
        }

        if (GetWindowRgn(popupHwnd, windowRegion.get()) == ERROR)
        {
            driverFailure = "composition popup exposes a non-rectangular host window region";
            return;
        }

        if (PtInRegion(windowRegion.get(), 0, 0) != FALSE || PtInRegion(windowRegion.get(), popupWidthPx - 1, 0) != FALSE)
        {
            driverFailure = "composition popup window region clips the top window corners";
            return;
        }

        if (PtInRegion(windowRegion.get(), 1, popupHeightPx / 2) == FALSE || PtInRegion(windowRegion.get(), popupWidthPx - 2, popupHeightPx / 2) == FALSE ||
            PtInRegion(windowRegion.get(), popupWidthPx / 2, 1) == FALSE)
        {
            driverFailure = "composition popup window region keeps the outer host margins available for the popup shadow";
            return;
        }

        const int topShadowShoulderX = (std::max)(1, static_cast<int>(std::llround(3.0 * scale)));
        const int topShadowShoulderY = (std::max)(1, static_cast<int>(std::llround(8.0 * scale)));
        if (PtInRegion(windowRegion.get(), topShadowShoulderX, topShadowShoulderY) == FALSE ||
            PtInRegion(windowRegion.get(), popupWidthPx - 1 - topShadowShoulderX, topShadowShoulderY) == FALSE)
        {
            driverFailure =
                "composition popup window region preserves the thinner top shadow shoulder instead of over-rounding it to match the thicker bottom margin";
            return;
        }

        if (PtInRegion(windowRegion.get(), popupWidthPx / 2, popupHeightPx / 2) == FALSE)
        {
            driverFailure = "composition popup window region still contains the menu body";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, MakeAnimatedTestThemePalette(true));
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the composition-shadow menu with Escape returns no invoked command");
}

void TestMenuPopupWindowClassDoesNotUseNativeDropShadow()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<MenuFlyoutItem> items = {
        {.text = L"Open", .commandId = 4101},
        {.text = L"Copy", .commandId = 4102},
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for native-drop-shadow validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        const ULONG_PTR classStyle = GetClassLongPtrW(popupHwnd, GCL_STYLE);
        if ((classStyle & CS_DROPSHADOW) != 0u)
        {
            driverFailure = "composition popup window class does not opt into the native CS_DROPSHADOW effect";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, MakeAnimatedTestThemePalette(true));
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the native-drop-shadow validation menu with Escape returns no invoked command");
}

void TestMenuPopupAcrylicLightVisualBaseline()
{
    using namespace DxUi;

    ThemePalette theme    = MakeAnimatedTestThemePalette(false);
    theme.overlayMaterial = OverlayMaterial::Acrylic;

    const std::vector<MenuFlyoutItem> items = {
        {.text = L"Open", .commandId = 4201},
        {.text = L"Copy", .commandId = 4202},
        {.text = L"Move", .commandId = 4203},
        {.text = L"Properties", .commandId = 4204},
    };

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ownerWindow.Host().SetRoot(std::make_unique<StripedBackdropControl>(10));
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();
    DrainPendingMouseMessagesForMenuSuite();
    WindowHostBitmapCapture ownerBackdropCapture{};
    Require(ownerWindow.Host().DebugCaptureBitmap(ownerBackdropCapture), "acrylic visual-baseline owner backdrop renders before popup capture");
    const POINT menuPoint = ClientScreenPointForTest(ownerWindow.Hwnd(), 72, 48, "acrylic baseline popup anchor maps to screen coordinates");

    WindowHostBitmapCapture capture{};
    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for acrylic visual-baseline capture";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f && ! state.hoveredIndex.has_value();
        }, popupState))
        {
            driverFailure = "menu popup exposes unhovered acrylic geometry for visual-baseline capture";
            return;
        }

        POINT popupClientOrigin{menuPoint.x, menuPoint.y};
        if (ScreenToClient(ownerWindow.Hwnd(), &popupClientOrigin) == FALSE)
        {
            driverFailure = "acrylic visual-baseline popup origin maps to owner client coordinates";
            return;
        }

        const UINT surfaceWidthPx  = DipToPixelForPopup(popupState.visibleWidthDip, popupState.dpi);
        const UINT surfaceHeightPx = DipToPixelForPopup(popupState.visibleHeightDip, popupState.dpi);
        const RECT backdropCropRect{
            popupClientOrigin.x,
            popupClientOrigin.y,
            popupClientOrigin.x + static_cast<LONG>(surfaceWidthPx),
            popupClientOrigin.y + static_cast<LONG>(surfaceHeightPx),
        };
        const WindowHostBitmapCapture deterministicBackdrop = CropWindowHostBitmapCaptureForTest(ownerBackdropCapture, backdropCropRect);
        if (! DebugSetContextMenuPopupBackdropCapture(popupHwnd, deterministicBackdrop))
        {
            driverFailure = "menu popup accepts deterministic acrylic backdrop for visual-baseline capture";
            return;
        }

        if (! WaitForContextMenuPopupBitmapCapture(popupHwnd, capture))
        {
            driverFailure = "menu popup bitmap capture succeeds for acrylic visual-baseline capture";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), menuPoint, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the acrylic visual-baseline menu with Escape returns no invoked command");
    VerifyOrUpdateBaselineForTest("acrylic light menu popup baseline matches", L"menu_popup_acrylic_light.png", capture, 0.06, 10u);
}

void TestMenuPopupKeepsSystemBackdropDisabledForAppRenderedMaterials()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    ThemePalette theme    = MakeAnimatedTestThemePalette(true);
    theme.overlayMaterial = OverlayMaterial::Acrylic;

    const std::vector<MenuFlyoutItem> items = {
        {.text = L"Open", .commandId = 3001},
        {.text = L"Rename", .commandId = 3002},
        {.text = L"Properties", .commandId = 3003},
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for popup-backdrop validation";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f;
        }, popupState))
        {
            driverFailure = "menu popup exposes debug state for popup-backdrop validation";
            return;
        }

        if (popupState.usesSystemBackdrop)
        {
            driverFailure = "app-rendered popup materials keep the popup HWND free of DWM system backdrops";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the popup-backdrop validation menu with Escape returns no invoked command");
}

void TestMenuPopupSubmenuFlipsLeftNearRightEdge()
{
    using namespace DxUi;

    const RECT workArea   = GetPrimaryMonitorWorkArea();
    const RECT parentRect = {
        workArea.right - 220,
        workArea.top + 80,
        workArea.right - 24,
        workArea.top + 260,
    };
    const RECT parentItemRect = {
        workArea.right - 34,
        workArea.top + 112,
        workArea.right - 12,
        workArea.top + 146,
    };

    RECT popupRect{};
    Require(DebugComputeContextMenuPopupPosition(POINT{parentItemRect.right, parentItemRect.top},
                                                 200.0f,
                                                 160.0f,
                                                 144u,
                                                 true,
                                                 &parentRect,
                                                 &parentItemRect,
                                                 ContextMenuRootHorizontalAlignment::Start,
                                                 popupRect),
            "submenu popup position resolves near the right screen edge");
    Require(popupRect.right <= parentItemRect.left, "submenu popup flips to the left side when opening right would overflow the work area");
    Require(popupRect.left >= workArea.left && popupRect.top >= workArea.top && popupRect.bottom <= workArea.bottom,
            "flipped submenu popup remains fully inside the monitor work area");
}

void TestMenuMnemonicHonorsExplicitAmpersandLabels()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<MenuFlyoutItem> items = {
        {.text = L"Save && Close\tCtrl+S", .commandId = 3001},
        {.text = L"E&xit\tAlt+F4", .commandId = 3002},
        {.text = L"Rock &", .commandId = 3003},
    };
    std::wstring normalizedFirstItemText;
    const bool normalizedFirstItem = DebugGetContextMenuItemDisplayText(items[0], normalizedFirstItemText);
    if (! normalizedFirstItem || normalizedFirstItemText != L"Save & Close")
    {
        const std::string failure =
            std::format("menu item parser preserves escaped ampersands while stripping tabbed accelerator text actual='{}' codeUnits='{}'",
                        NarrowAsciiForFailureMessage(normalizedFirstItemText),
                        WideCodeUnitsForFailureMessage(normalizedFirstItemText));
        Require(false, failure.c_str());
    }

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Save & Close");
        if (! popupHwnd)
        {
            std::wstring popupFirstItemText;
            if (HWND fallbackPopupHwnd = FindOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
                fallbackPopupHwnd && DxUi::DebugGetContextMenuPopupItemText(fallbackPopupHwnd, 0u, popupFirstItemText))
            {
                driverFailure = std::format("menu popup window appears for explicit ampersand mnemonic validation actual='{}' codeUnits='{}'",
                                            NarrowAsciiForFailureMessage(popupFirstItemText),
                                            WideCodeUnitsForFailureMessage(popupFirstItemText));
            }
            else
            {
                driverFailure = "menu popup window appears for explicit ampersand mnemonic validation";
            }
            return;
        }

        std::wstring firstItemText;
        std::wstring secondItemText;
        std::wstring thirdItemText;
        if (! WaitForContextMenuPopupItemText(popupHwnd, 0u, firstItemText) || ! WaitForContextMenuPopupItemText(popupHwnd, 1u, secondItemText) ||
            ! WaitForContextMenuPopupItemText(popupHwnd, 2u, thirdItemText))
        {
            driverFailure = "menu popup exposes item text for explicit ampersand mnemonic validation";
            return;
        }

        if (firstItemText != L"Save & Close")
        {
            driverFailure = std::format("menu popup preserves escaped ampersands while stripping tabbed accelerator text actual='{}' codeUnits='{}'",
                                        NarrowAsciiForFailureMessage(firstItemText),
                                        WideCodeUnitsForFailureMessage(firstItemText));
            return;
        }

        if (secondItemText != L"Exit")
        {
            driverFailure = std::format("menu popup strips explicit ampersand markers from displayed item text actual='{}' codeUnits='{}'",
                                        NarrowAsciiForFailureMessage(secondItemText),
                                        WideCodeUnitsForFailureMessage(secondItemText));
            return;
        }

        if (thirdItemText != L"Rock &")
        {
            driverFailure = std::format("menu popup preserves a trailing literal ampersand in displayed item text actual='{}' codeUnits='{}'",
                                        NarrowAsciiForFailureMessage(thirdItemText),
                                        WideCodeUnitsForFailureMessage(thirdItemText));
            return;
        }

        if (! SendMenuKeyForMenuSuite(popupHwnd, 'X'))
        {
            driverFailure = "explicit ampersand mnemonic key is delivered to the popup";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, MakeAnimatedTestThemePalette(true));
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(result.has_value() && result.value() == 3002, "explicit ampersand mnemonic invokes the matching popup item");
}

void TestMenuOpeningPointerUpCanBeIgnoredOutsideVisibleSurface()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<MenuFlyoutItem> items = {
        {.text = L"Ignore Release", .commandId = 3001},
        {.text = L"Close", .commandId = 3002},
    };

    ContextMenuSessionCallbacks sessionCallbacks{};
    sessionCallbacks.ignoreInitialLeftButtonUp = true;

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Ignore Release");
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for initial pointer-up validation";
            return;
        }

        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f;
        }, popupState))
        {
            driverFailure = "menu popup exposes geometry for initial pointer-up validation";
            return;
        }

        PostMessageW(popupHwnd, WM_LBUTTONUP, 0, MAKELPARAM(1, 1));
        std::this_thread::sleep_for(std::chrono::milliseconds(80));

        if (IsWindow(popupHwnd) == FALSE)
        {
            driverFailure = "menu popup ignores the opening button-up before applying light-dismiss rules";
            return;
        }

        PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, MakeAnimatedTestThemePalette(true), sessionCallbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the initial pointer-up validation menu returns no invoked command");
}

void TestMenuShadowMarginMouseUpLightDismissesAfterInitialRelease()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const std::vector<MenuFlyoutItem> items = {
        {.text = L"Shadow Desktop", .commandId = 3001},
        {.text = L"Documents", .commandId = 3002},
        {.text = L"Downloads", .commandId = 3003},
    };

    std::string driverFailure;
    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Shadow Desktop");
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for shadow-margin light-dismiss validation";
            return;
        }

        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) noexcept {
            return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f;
        }, popupState))
        {
            driverFailure = "menu popup exposes geometry for shadow-margin light-dismiss validation";
            return;
        }

        PostMessageW(popupHwnd, WM_LBUTTONUP, 0, MAKELPARAM(1, 1));
        if (! WaitForWindowDestroyed(popupHwnd))
        {
            driverFailure = "menu popup treats transparent shadow margins as outside the visible menu surface for light-dismiss";
        }
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, MakeAnimatedTestThemePalette(true));
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "shadow-margin light-dismiss returns no invoked command");
}

void TestMenuAcrylicBackdropScenarioEmitsMetrics()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 96, 96, 480, 360, SWP_NOZORDER | SWP_NOACTIVATE);
    ownerWindow.Host().SetRoot(std::make_unique<StripedBackdropControl>(12));
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    UpdateWindow(ownerWindow.Hwnd());
    ownerWindow.PumpMessages();
    WindowHostBitmapCapture ownerBackdropBeforePopup{};
    Require(ownerWindow.Host().DebugCaptureBitmap(ownerBackdropBeforePopup), "owner backdrop renders before acrylic metric capture");
    const POINT menuPoint = ClientScreenPointForTest(ownerWindow.Hwnd(), 96, 72, "acrylic metric popup anchor maps to screen coordinates");

    ThemePalette theme    = MakeAnimatedTestThemePalette(true);
    theme.overlayMaterial = OverlayMaterial::Acrylic;

    const std::vector<MenuFlyoutItem> items = {
        {.text = L"Open", .commandId = 3001},
        {.text = L"Copy", .commandId = 3002},
        {.text = L"Move", .commandId = 3003},
    };

    std::string driverFailure;
    WindowHostBitmapCapture popupCapture{};
    uint64_t openToCaptureUs = 0u;
    const auto startedAt     = std::chrono::steady_clock::now();

    std::thread driver([&]
    {
        const DismissMenusIfDriverFails dismissOnFailure(ownerWindow.Hwnd(), driverFailure);
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "menu popup window appears for acrylic backdrop metric capture";
            return;
        }
        const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(
                popupHwnd, [](const ContextMenuPopupDebugState& state) { return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f; }, popupState))
        {
            driverFailure = "menu popup enables app-rendered backdrop blur for acrylic backdrop metric capture";
            return;
        }

        POINT popupClientOrigin{menuPoint.x, menuPoint.y};
        if (ScreenToClient(ownerWindow.Hwnd(), &popupClientOrigin) == FALSE)
        {
            driverFailure = "acrylic backdrop metric popup origin maps to owner client coordinates";
            return;
        }

        const UINT surfaceWidthPx  = DipToPixelForPopup(popupState.visibleWidthDip, popupState.dpi);
        const UINT surfaceHeightPx = DipToPixelForPopup(popupState.visibleHeightDip, popupState.dpi);
        const RECT backdropCropRect{
            popupClientOrigin.x,
            popupClientOrigin.y,
            popupClientOrigin.x + static_cast<LONG>(surfaceWidthPx),
            popupClientOrigin.y + static_cast<LONG>(surfaceHeightPx),
        };
        const WindowHostBitmapCapture deterministicBackdrop = CropWindowHostBitmapCaptureForTest(ownerBackdropBeforePopup, backdropCropRect);
        if (! DebugSetContextMenuPopupBackdropCapture(popupHwnd, deterministicBackdrop))
        {
            driverFailure = "menu popup accepts deterministic acrylic backdrop for metric capture";
            return;
        }

        if (! WaitForContextMenuPopupBitmapCapture(popupHwnd, popupCapture))
        {
            driverFailure = "menu popup bitmap capture succeeds for acrylic backdrop metric capture";
            return;
        }

        openToCaptureUs = DxUi::Debug::Perf::ElapsedUs(startedAt);
        PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
    });

    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), menuPoint, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "closing the acrylic backdrop metric menu with Escape returns no invoked command");
    Require(popupCapture.widthPx > 0u && popupCapture.heightPx > 0u && ! popupCapture.bgraPixels.empty(),
            "acrylic backdrop metric scenario captures the popup bitmap");

    const RECT opaqueBounds = FindOpaqueBoundsInCapture(popupCapture);
    Require(opaqueBounds.right > opaqueBounds.left && opaqueBounds.bottom > opaqueBounds.top, "acrylic backdrop metric scenario resolves opaque popup bounds");
    const RECT sampleRect = ComputeRightStripSampleRect(opaqueBounds);
    Require(sampleRect.right > sampleRect.left && sampleRect.bottom > sampleRect.top,
            "acrylic backdrop metric scenario resolves a valid right-strip sample region");

    std::this_thread::sleep_for(std::chrono::milliseconds(30));
    InvalidateRect(ownerWindow.Hwnd(), nullptr, FALSE);
    UpdateWindow(ownerWindow.Hwnd());
    ownerWindow.PumpMessages();
    WindowHostBitmapCapture ownerBackdropCapture{};
    Require(ownerWindow.Host().DebugCaptureBitmap(ownerBackdropCapture), "owner backdrop capture succeeds for acrylic metrics");
    POINT popupClientOrigin{menuPoint.x, menuPoint.y};
    Require(ScreenToClient(ownerWindow.Hwnd(), &popupClientOrigin) != FALSE, "popup origin maps to owner client coordinates for acrylic metrics");
    const RECT rawCaptureRect = {
        popupClientOrigin.x - opaqueBounds.left,
        popupClientOrigin.y - opaqueBounds.top,
        popupClientOrigin.x - opaqueBounds.left + static_cast<LONG>(popupCapture.widthPx),
        popupClientOrigin.y - opaqueBounds.top + static_cast<LONG>(popupCapture.heightPx),
    };
    const WindowHostBitmapCapture rawCapture = CropWindowHostBitmapCaptureForTest(ownerBackdropCapture, rawCaptureRect);
    Require(rawCapture.widthPx == popupCapture.widthPx && rawCapture.heightPx == popupCapture.heightPx,
            "raw backdrop capture matches the popup capture geometry for acrylic metrics");

    const uint64_t popupAdjacentDelta = ComputeAverageAdjacentRgbDelta(popupCapture, sampleRect);
    const uint64_t rawAdjacentDelta   = ComputeAverageAdjacentRgbDelta(rawCapture, sampleRect);
    const uint64_t popupVsRawDelta    = ComputeAverageAbsoluteRgbDeltaBetweenCaptures(popupCapture, rawCapture, sampleRect);
    const uint64_t popupVsSlabDelta   = ComputeAverageAbsoluteRgbDeltaToColor(popupCapture, sampleRect, ResolveExpectedAcrylicMenuSlabColor(theme));
    const uint64_t popupToRawDeltaPermille =
        rawAdjacentDelta == 0u ? 0u : static_cast<uint64_t>((popupAdjacentDelta * 1000u + (rawAdjacentDelta / 2u)) / rawAdjacentDelta);
    const uint64_t minStrongBlurDelta = rawAdjacentDelta <= 1u ? 48u : 56u;

    DxUi::Debug::Perf::EmitValue(L"dxui.menu.selftest.acrylic_popup_adjacent_rgb_delta", popupAdjacentDelta);
    DxUi::Debug::Perf::EmitValue(L"dxui.menu.selftest.acrylic_raw_adjacent_rgb_delta", rawAdjacentDelta);
    DxUi::Debug::Perf::EmitValue(L"dxui.menu.selftest.acrylic_popup_vs_raw_rgb_delta", popupVsRawDelta);
    DxUi::Debug::Perf::EmitValue(L"dxui.menu.selftest.acrylic_popup_vs_slab_rgb_delta", popupVsSlabDelta);
    DxUi::Debug::Perf::EmitValue(L"dxui.menu.selftest.acrylic_popup_to_raw_delta_permille", popupToRawDeltaPermille);

    Require(rawAdjacentDelta > 0u, "acrylic backdrop metric scenario records non-zero raw backdrop variance");
    Require(popupVsRawDelta > 0u, "acrylic backdrop metric scenario materially changes the captured backdrop sample");
    Require(popupAdjacentDelta < rawAdjacentDelta, "acrylic backdrop metric scenario blurs the popup backdrop below the raw screen variance");
    Require(popupVsRawDelta >= minStrongBlurDelta,
            "acrylic backdrop metric scenario applies a visibly strong blur instead of a barely-changed transparent tint");
    Require(popupVsSlabDelta >= 24u,
            "acrylic backdrop metric scenario stays visually tied to the captured raw backdrop instead of collapsing into an opaque tint");

    DxUi::Debug::Perf::Emit(L"dxui.menu.selftest.acrylic_open_to_capture_us",
                            L"",
                            openToCaptureUs,
                            static_cast<uint64_t>(popupCapture.widthPx),
                            static_cast<uint64_t>(popupCapture.heightPx),
                            S_OK);
}

void TestContextMenuShowAsyncKeepsOwnerPaintableWhileOpen()
{
    using namespace DxUi;

    const std::vector<MenuFlyoutItem> items = {
        {.text = L"Async One", .commandId = 7701},
        {.text = L"Async Two", .commandId = 7702},
    };

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 160, 160, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ownerWindow.Host().SetRoot(std::make_unique<StripedBackdropControl>(8));
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    InvalidateRect(ownerWindow.Hwnd(), nullptr, FALSE);
    UpdateWindow(ownerWindow.Hwnd());
    ownerWindow.PumpMessages();

    const POINT menuPoint = ClientScreenPointForTest(ownerWindow.Hwnd(), 72, 48, "async context menu anchor maps to screen coordinates");
    bool callbackInvoked  = false;
    std::optional<int> callbackResult;
    const bool shown = ContextMenu::ShowAsync(ownerWindow.Hwnd(),
                                              menuPoint,
                                              items,
                                              ownerWindow.Host().GetTheme(),
                                              [&](std::optional<int> commandId) noexcept
    {
        callbackInvoked = true;
        callbackResult  = commandId;
    });
    Require(shown, "async context menu show succeeds");
    Require(! callbackInvoked, "async context menu returns before any item is invoked");

    const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Async One");
    Require(popupHwnd != nullptr, "async context menu popup window appears");

    const uint64_t renderCountBefore = ownerWindow.Host().DebugGetRenderCount();
    InvalidateRect(ownerWindow.Hwnd(), nullptr, FALSE);
    UpdateWindow(ownerWindow.Hwnd());
    ownerWindow.PumpMessages();
    Require(ownerWindow.Host().DebugGetRenderCount() > renderCountBefore, "owner host repaints while async context menu is open");

    ContextMenuPopupDebugState popupState{};
    D2D1_RECT_F rowRectDip{};
    Require(WaitForContextMenuPopupState(popupHwnd,
                                         [](const ContextMenuPopupDebugState& state) noexcept
    { return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f; },
                                         popupState) &&
                WaitForContextMenuPopupItemRect(popupHwnd, 1u, rowRectDip),
            "async context menu exposes the second row geometry");

    POINT rowCenter{
        static_cast<LONG>(
            std::lround((rowRectDip.left + rowRectDip.right) * 0.5f * static_cast<float>(popupState.dpi) / static_cast<float>(USER_DEFAULT_SCREEN_DPI))),
        static_cast<LONG>(
            std::lround((rowRectDip.top + rowRectDip.bottom) * 0.5f * static_cast<float>(popupState.dpi) / static_cast<float>(USER_DEFAULT_SCREEN_DPI))),
    };
    Require(ClientToScreen(popupHwnd, &rowCenter) != FALSE, "async context menu row center maps to screen coordinates");

    static_cast<void>(SendCapturedMouseMessageForMenuSuite(popupHwnd, WM_LBUTTONDOWN, MK_LBUTTON, rowCenter));
    static_cast<void>(SendCapturedMouseMessageForMenuSuite(popupHwnd, WM_LBUTTONUP, 0, rowCenter));
    ownerWindow.PumpMessages();

    Require(callbackInvoked, "async context menu invokes callback after item click");
    Require(callbackResult == std::optional<int>{7702}, "async context menu callback receives invoked command");
    Require(WaitForWindowDestroyed(popupHwnd), "async context menu closes after item click");
}

void TestLargeMenuPaintsOnlyVisibleRowsWithCachedOffsets()
{
    using namespace DxUi;

    constexpr size_t kItemCount = 4096u;
    std::vector<MenuFlyoutItem> items;
    items.reserve(kItemCount);
    for (size_t i = 0; i < kItemCount; ++i)
    {
        items.push_back(MenuFlyoutItem{.text = std::format(L"Folder {:04}", i), .commandId = static_cast<int>(80'000u + i)});
    }

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 180, 180, 420, 300, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    ContextMenuSessionCallbacks callbacks{};
    callbacks.maxRootHeightDip        = 240.0f;
    callbacks.focusFirstNavigableItem = true;

    bool callbackInvoked   = false;
    const POINT menuPoint  = ClientScreenPointForTest(ownerWindow.Hwnd(), 64, 48, "large context menu anchor maps to screen coordinates");
    const auto openStarted = std::chrono::steady_clock::now();
    const bool shown       = ContextMenu::ShowAsync(
        ownerWindow.Hwnd(), menuPoint, items, ownerWindow.Host().GetTheme(), [&](std::optional<int>) noexcept { callbackInvoked = true; }, callbacks);
    const uint64_t openToFirstPaintUs = DxUi::Debug::Perf::ElapsedUs(openStarted);
    Require(shown, "large async context menu opens");
    Require(openToFirstPaintUs < 5'000'000u, "large context menu open-to-first-paint remains bounded");

    const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Folder 0000");
    Require(popupHwnd != nullptr, "large context menu popup window appears");

    ContextMenuPopupDebugState initialState{};
    Require(WaitForContextMenuPopupState(popupHwnd,
                                         [](const ContextMenuPopupDebugState& state) noexcept
    { return state.renderCount > 0u && state.lastPaintedItemCount > 0u; },
                                         initialState),
            "large context menu completes its first visible-row paint");
    Require(initialState.hasScrollbar, "large context menu uses a bounded viewport");
    Require(initialState.itemTexts.size() == kItemCount, "large context menu retains the immutable command model");
    Require(initialState.lastPaintedItemCount <= 32u, "large context menu first paint touches only viewport rows");

    const auto endStarted = std::chrono::steady_clock::now();
    SendMessageW(popupHwnd, WM_KEYDOWN, VK_END, 0);
    ownerWindow.PumpMessages();
    ContextMenuPopupDebugState endState{};
    Require(WaitForContextMenuPopupState(popupHwnd,
                                         [](const ContextMenuPopupDebugState& state) noexcept
    { return state.keyboardIndex == std::optional<size_t>{kItemCount - 1u} && state.scrollOffsetDip > 0.0f; },
                                         endState),
            "large context menu resolves the last row through cached offsets");
    const uint64_t endToVisibleUs = DxUi::Debug::Perf::ElapsedUs(endStarted);
    Require(endToVisibleUs < 1'000'000u, "large context menu End-to-visible latency remains bounded");
    Require(endState.lastPaintedItemCount <= 32u, "large context menu scrolled paint remains limited to viewport rows");

    D2D1_RECT_F lastRowRect{};
    Require(WaitForContextMenuPopupItemRect(popupHwnd, kItemCount - 1u, lastRowRect), "large context menu exposes last-row geometry");
    Require(lastRowRect.bottom > endState.viewportRectDip.top && lastRowRect.top < endState.viewportRectDip.bottom,
            "large context menu keeps the keyboard-selected last row inside the viewport");

    DxUi::Debug::Perf::Emit(L"dxui.menu.selftest.large_open_to_first_paint_us",
                            L"4096-items",
                            openToFirstPaintUs,
                            static_cast<uint64_t>(kItemCount),
                            static_cast<uint64_t>(initialState.lastPaintedItemCount),
                            S_OK);
    DxUi::Debug::Perf::Emit(L"dxui.menu.selftest.large_end_to_visible_us",
                            L"4096-items",
                            endToVisibleUs,
                            static_cast<uint64_t>(kItemCount),
                            static_cast<uint64_t>(endState.lastPaintedItemCount),
                            S_OK);

    PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
    const auto closeDeadline = std::chrono::steady_clock::now() + std::chrono::seconds(2);
    while (! callbackInvoked && std::chrono::steady_clock::now() < closeDeadline)
    {
        ownerWindow.PumpMessages();
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    Require(callbackInvoked, "large context menu closes through Escape");
    Require(WaitForWindowDestroyed(popupHwnd), "large context menu popup is destroyed after Escape");
}

void TestContextMenuRootMinimumWidthUsesAnchorAndAllowsContentExpansion()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 180, 180, 420, 280, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    constexpr float kAnchorWidthDip = 260.0f;
    ContextMenuSessionCallbacks callbacks{};
    callbacks.minRootWidthDip = kAnchorWidthDip;

    const auto measureMenuWidth = [&](std::wstring firstItemText, int commandId)
    {
        const std::vector<MenuFlyoutItem> items = {
            {.text = std::move(firstItemText), .commandId = commandId},
        };
        bool callbackInvoked  = false;
        const POINT menuPoint = ClientScreenPointForTest(ownerWindow.Hwnd(), 320, 72, "minimum-width context menu anchor maps to screen coordinates");
        Require(
            ContextMenu::ShowAsync(
                ownerWindow.Hwnd(), menuPoint, items, ownerWindow.Host().GetTheme(), [&](std::optional<int>) noexcept { callbackInvoked = true; }, callbacks),
            "minimum-width async context menu opens");

        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), items[0].text);
        Require(popupHwnd != nullptr, "minimum-width context menu popup window appears");
        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                SendMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        ContextMenuPopupDebugState popupState{};
        Require(
            WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) noexcept { return state.visibleWidthDip > 0.0f; }, popupState),
            "minimum-width context menu exposes its visible width");

        SendMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
        ownerWindow.PumpMessages();
        Require(callbackInvoked, "minimum-width context menu closes through Escape");
        Require(WaitForWindowDestroyed(popupHwnd), "minimum-width context menu window is destroyed after Escape");
        return popupState.visibleWidthDip;
    };

    const float shortMenuWidthDip = measureMenuWidth(L"Queue", 83'001);
    Require(shortMenuWidthDip >= kAnchorWidthDip - 1.0f, "short flyout is at least as wide as its invoking button");

    const float longMenuWidthDip = measureMenuWidth(L"A translated menu item that is substantially wider than the invoking selector button", 83'002);
    Require(longMenuWidthDip > kAnchorWidthDip + 1.0f, "long flyout content expands beyond the invoking button width");
}

void TestContextMenuShowAsyncSubmenuCloseKeepsSessionAlive()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 140, 140, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();
    DrainPendingMouseMessagesForMenuSuite();

    const std::vector<MenuFlyoutItem> items = {
        {.text      = L"S1",
         .commandId = 7901,
         .children =
             {
                 MenuFlyoutItem{.text = L"S11", .commandId = 79011},
                 MenuFlyoutItem{.text = L"S12", .commandId = 79012},
             }},
        {.text = L"S2", .commandId = 7902},
    };

    bool callbackInvoked = false;
    std::optional<int> callbackResult;
    const POINT menuPoint = ClientScreenPointForTest(ownerWindow.Hwnd(), 60, 40, "async submenu-close menu anchor maps to screen coordinates");
    Require(ContextMenu::ShowAsync(ownerWindow.Hwnd(),
                                   menuPoint,
                                   items,
                                   ownerWindow.Host().GetTheme(),
                                   [&](std::optional<int> commandId) noexcept
    {
        callbackInvoked = true;
        callbackResult  = commandId;
    }),
            "async submenu-close context menu opens");

    const HWND rootPopupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"S1");
    Require(rootPopupHwnd != nullptr, "async submenu-close root popup window appears");

    const auto dismissPopup = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(ownerWindow.Hwnd()); });

    ContextMenuPopupDebugState popupState{};
    D2D1_RECT_F firstItemRectDip  = D2D1::RectF();
    D2D1_RECT_F secondItemRectDip = D2D1::RectF();
    Require(WaitForContextMenuPopupState(rootPopupHwnd,
                                         [](const ContextMenuPopupDebugState& state) noexcept
    { return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f; },
                                         popupState) &&
                WaitForContextMenuPopupItemRect(rootPopupHwnd, 0u, firstItemRectDip) && WaitForContextMenuPopupItemRect(rootPopupHwnd, 1u, secondItemRectDip),
            "async submenu-close root popup exposes its geometry");

    const float scale = static_cast<float>(popupState.dpi) / 96.0f;
    const LONG s1X    = static_cast<LONG>(std::lround(((firstItemRectDip.left + firstItemRectDip.right) * 0.5f) * scale));
    const LONG s1Y    = static_cast<LONG>(std::lround(((firstItemRectDip.top + firstItemRectDip.bottom) * 0.5f) * scale));
    const LONG s2X    = static_cast<LONG>(std::lround(((secondItemRectDip.left + secondItemRectDip.right) * 0.5f) * scale));
    const LONG s2Y    = static_cast<LONG>(std::lround(((secondItemRectDip.top + secondItemRectDip.bottom) * 0.5f) * scale));

    // Hover the parent item until the deferred-open hover timer is pending, then
    // fire it so the submenu opens through the async WndProc timer path.
    Require(SendSettledClientMouseMoveForMenuSuite(rootPopupHwnd, s1X, s1Y) && WaitForContextMenuPopupState(rootPopupHwnd,
                                                                                                            [](const ContextMenuPopupDebugState& state) noexcept
    { return state.hoverTimerActive && state.hoverTimerPendingOpen; },
                                                                                                            popupState),
            "hovering the async parent item schedules the submenu open timer");
    Require(FirePendingSubmenuHoverTimerForMenuSuite(rootPopupHwnd), "async submenu open timer fires");
    ownerWindow.PumpMessages();
    const HWND submenuHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"S11");
    Require(submenuHwnd != nullptr, "async submenu opens after the hover timer fires");
    Require(! callbackInvoked, "async session stays open while the submenu is open");

    // Hover the sibling without children: this schedules the delayed close, and
    // firing it destroys the submenu window from inside the controller. That
    // controller-initiated destroy must not finalize the async session.
    Require(SendSettledClientMouseMoveForMenuSuite(rootPopupHwnd, s2X, s2Y) && WaitForContextMenuPopupState(rootPopupHwnd,
                                                                                                            [](const ContextMenuPopupDebugState& state) noexcept
    { return state.hoverTimerActive && state.hoverTimerPendingClose; },
                                                                                                            popupState),
            "hovering the async sibling item schedules the submenu close timer");
    Require(FirePendingSubmenuHoverTimerForMenuSuite(rootPopupHwnd), "async submenu close timer fires");
    ownerWindow.PumpMessages();

    Require(WaitForWindowDestroyed(submenuHwnd), "async submenu closes after the close timer fires");
    Require(IsWindow(rootPopupHwnd) != FALSE, "async root popup survives the controller-initiated submenu close");
    Require(! callbackInvoked, "async session does not finalize when its submenu closes");

    // The session is still interactive: clicking the sibling item delivers its command.
    const POINT siblingCenter = ClientScreenPointForTest(rootPopupHwnd, s2X, s2Y, "async sibling item maps to screen coordinates");
    static_cast<void>(SendCapturedMouseMessageForMenuSuite(rootPopupHwnd, WM_LBUTTONDOWN, MK_LBUTTON, siblingCenter));
    static_cast<void>(SendCapturedMouseMessageForMenuSuite(rootPopupHwnd, WM_LBUTTONUP, 0, siblingCenter));
    ownerWindow.PumpMessages();

    Require(callbackInvoked, "async context menu invokes the closed callback after the post-close click");
    Require(callbackResult == std::optional<int>{7902}, "async context menu delivers the sibling command after the submenu close");
    Require(WaitForWindowDestroyed(rootPopupHwnd), "async root popup closes after invoking the sibling command");
}

void TestMenuGraphicalSliderSupportsClickDragAndAnimation()
{
    using namespace DxUi;

    const auto makeSliderItems = []
    {
        MenuFlyoutItem slider{
            .kind            = MenuItemKind::Slider,
            .text            = L"Thumbnail size",
            .acceleratorText = L"Medium",
            .sliderStops =
                {
                    {.text = L"Small", .commandId = 8201},
                    {.text = L"Medium", .commandId = 8202},
                    {.text = L"Large", .commandId = 8203},
                    {.text = L"Extra Large", .commandId = 8204},
                },
            .sliderValue = 1u,
        };
        return std::vector<MenuFlyoutItem>{std::move(slider)};
    };

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 180, 180, 340, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    const auto openSlider = [&](bool& callbackInvoked, std::optional<int>& callbackResult)
    {
        const POINT menuPoint = ClientScreenPointForTest(ownerWindow.Hwnd(), 80, 56, "graphical slider context menu anchor maps to screen coordinates");
        Require(ContextMenu::ShowAsync(ownerWindow.Hwnd(),
                                       menuPoint,
                                       makeSliderItems(),
                                       ownerWindow.Host().GetTheme(),
                                       [&](std::optional<int> commandId) noexcept
        {
            callbackInvoked = true;
            callbackResult  = commandId;
        }),
                "graphical slider context menu opens asynchronously");
        const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"Thumbnail size");
        Require(popupHwnd != nullptr, "graphical slider popup window appears");
        return popupHwnd;
    };

    const auto sliderPoint = [](HWND popupHwnd, const ContextMenuPopupDebugState& state, const D2D1_RECT_F& rowRectDip, float stopPosition)
    {
        const float scale = static_cast<float>(state.dpi) / 96.0f;
        POINT point{
            static_cast<LONG>(std::lround(std::lerp(rowRectDip.left + 16.0f, rowRectDip.right - 16.0f, stopPosition / 3.0f) * scale)),
            static_cast<LONG>(std::lround((rowRectDip.top + 50.0f) * scale)),
        };
        Require(ClientToScreen(popupHwnd, &point) != FALSE, "graphical slider stop maps to screen coordinates");
        return point;
    };

    bool clickCallbackInvoked = false;
    std::optional<int> clickCallbackResult;
    const HWND clickPopup = openSlider(clickCallbackInvoked, clickCallbackResult);
    ContextMenuPopupDebugState clickState{};
    D2D1_RECT_F clickRowRectDip{};
    Require(DebugGetContextMenuPopupState(clickPopup, clickState) && DebugGetContextMenuPopupItemRect(clickPopup, 0u, clickRowRectDip),
            "graphical slider click exposes state and row geometry");
    Require(clickState.sliderStopVisualExtentsDip.size() == 1u && clickState.sliderStopVisualExtentsDip[0u].size() == 4u &&
                clickState.sliderStopVisualExtentsDip[0u][0u] < clickState.sliderStopVisualExtentsDip[0u][1u] &&
                clickState.sliderStopVisualExtentsDip[0u][1u] < clickState.sliderStopVisualExtentsDip[0u][2u] &&
                clickState.sliderStopVisualExtentsDip[0u][2u] < clickState.sliderStopVisualExtentsDip[0u][3u],
            "slider stops use progressively larger graphical thumbnail representations");

    const POINT largePoint = sliderPoint(clickPopup, clickState, clickRowRectDip, 2.0f);
    static_cast<void>(SendCapturedMouseMessageForMenuSuite(clickPopup, WM_LBUTTONDOWN, MK_LBUTTON, largePoint));
    Require(DebugGetContextMenuPopupState(clickPopup, clickState) && clickState.sliderDragging[0u] && clickState.sliderValues[0u] == 2u &&
                clickState.sliderTargetPositions[0u] == 2.0f && clickState.sliderAnimatedPositions[0u] < clickState.sliderTargetPositions[0u],
            "direct slider press previews the selected stop and starts an animated transition");
    static_cast<void>(SendCapturedMouseMessageForMenuSuite(clickPopup, WM_LBUTTONUP, 0, largePoint));
    ownerWindow.PumpMessages();
    Require(clickCallbackInvoked && clickCallbackResult == std::optional<int>{8203}, "direct slider click commits the selected stop on release");
    Require(WaitForWindowDestroyed(clickPopup), "direct slider click closes the popup after committing");

    bool dragCallbackInvoked = false;
    std::optional<int> dragCallbackResult;
    const HWND dragPopup = openSlider(dragCallbackInvoked, dragCallbackResult);
    ContextMenuPopupDebugState dragState{};
    D2D1_RECT_F dragRowRectDip{};
    Require(DebugGetContextMenuPopupState(dragPopup, dragState) && DebugGetContextMenuPopupItemRect(dragPopup, 0u, dragRowRectDip),
            "graphical slider drag exposes state and row geometry");
    const POINT smallPoint      = sliderPoint(dragPopup, dragState, dragRowRectDip, 0.0f);
    const POINT extraLargePoint = sliderPoint(dragPopup, dragState, dragRowRectDip, 3.0f);
    static_cast<void>(SendCapturedMouseMessageForMenuSuite(dragPopup, WM_LBUTTONDOWN, MK_LBUTTON, smallPoint));
    static_cast<void>(SendCapturedMouseMessageForMenuSuite(dragPopup, WM_MOUSEMOVE, MK_LBUTTON, extraLargePoint));
    Require(DebugGetContextMenuPopupState(dragPopup, dragState) && dragState.sliderDragging[0u] && dragState.sliderValues[0u] == 3u &&
                dragState.sliderTargetPositions[0u] == 3.0f && dragState.sliderAnimatedPositions[0u] < dragState.sliderTargetPositions[0u] &&
                dragState.itemAcceleratorTexts[0u] == L"Extra Large",
            "held pointer drag updates the live label and animates toward the graphical endpoint");
    static_cast<void>(SendCapturedMouseMessageForMenuSuite(dragPopup, WM_LBUTTONUP, 0, extraLargePoint));
    ownerWindow.PumpMessages();
    Require(dragCallbackInvoked && dragCallbackResult == std::optional<int>{8204}, "slider drag commits the final stop on release");
    Require(WaitForWindowDestroyed(dragPopup), "slider drag closes the popup after committing");
}

void TestContextMenuPopupRelayoutsOnDpiChanged()
{
    using namespace DxUi;

    const std::vector<MenuFlyoutItem> items = {
        {.text = L"DPI One", .acceleratorText = L"Ctrl+1", .commandId = 7801},
        {.text = L"DPI Two", .acceleratorText = L"Ctrl+2", .commandId = 7802},
        {.text = L"DPI Three", .acceleratorText = L"Ctrl+3", .commandId = 7803},
        {.text = L"DPI Four", .acceleratorText = L"Ctrl+4", .commandId = 7804},
    };

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 180, 180, 340, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    bool callbackInvoked = false;
    std::optional<int> callbackResult;
    const POINT menuPoint = ClientScreenPointForTest(ownerWindow.Hwnd(), 80, 56, "dpi context menu anchor maps to screen coordinates");
    Require(ContextMenu::ShowAsync(ownerWindow.Hwnd(),
                                   menuPoint,
                                   items,
                                   ownerWindow.Host().GetTheme(),
                                   [&](std::optional<int> commandId) noexcept
    {
        callbackInvoked = true;
        callbackResult  = commandId;
    }),
            "async context menu opens for DPI relayout validation");

    const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), L"DPI One");
    Require(popupHwnd != nullptr, "DPI relayout context menu popup window appears");

    const auto dismissPopup = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popupHwnd) != FALSE)
        {
            SendMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
        }
    });

    ContextMenuPopupDebugState initialState{};
    Require(WaitForContextMenuPopupState(popupHwnd,
                                         [](const ContextMenuPopupDebugState& state) noexcept
    { return state.dpi > 0u && state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f && ! state.hasScrollbar; },
                                         initialState),
            "DPI relayout popup exposes initial non-scrolling geometry");

    const UINT sourceDpi            = initialState.dpi == 0u ? USER_DEFAULT_SCREEN_DPI : initialState.dpi;
    const UINT targetDpi            = sourceDpi == 144u ? USER_DEFAULT_SCREEN_DPI : 144u;
    const int initialWindowWidthPx  = initialState.windowRectPx.right - initialState.windowRectPx.left;
    const int initialWindowHeightPx = initialState.windowRectPx.bottom - initialState.windowRectPx.top;
    RECT suggestedWindowRect{
        initialState.windowRectPx.left,
        initialState.windowRectPx.top,
        initialState.windowRectPx.left + MulDiv(initialWindowWidthPx, static_cast<int>(targetDpi), static_cast<int>(sourceDpi)),
        initialState.windowRectPx.top + MulDiv(initialWindowHeightPx, static_cast<int>(targetDpi), static_cast<int>(sourceDpi)),
    };

    SendMessageW(
        popupHwnd, WM_DPICHANGED, MAKEWPARAM(static_cast<WORD>(targetDpi), static_cast<WORD>(targetDpi)), reinterpret_cast<LPARAM>(&suggestedWindowRect));

    ContextMenuPopupDebugState relayoutState{};
    Require(WaitForContextMenuPopupState(popupHwnd,
                                         [targetDpi](const ContextMenuPopupDebugState& state) noexcept
    { return state.dpi == targetDpi && state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f && ! state.hasScrollbar; },
                                         relayoutState),
            "DPI relayout popup updates its debug DPI and visible geometry");

    const int surfaceWidthPx  = relayoutState.surfaceRectPx.right - relayoutState.surfaceRectPx.left;
    const int surfaceHeightPx = relayoutState.surfaceRectPx.bottom - relayoutState.surfaceRectPx.top;
    Require(surfaceWidthPx == static_cast<int>(DipToPixelForPopup(relayoutState.visibleWidthDip, targetDpi)),
            "DPI relayout popup surface width matches the new DPI scale");
    Require(surfaceHeightPx == static_cast<int>(DipToPixelForPopup(relayoutState.visibleHeightDip, targetDpi)),
            "DPI relayout popup surface height matches the new DPI scale");

    D2D1_RECT_F lastItemRectDip{};
    Require(WaitForContextMenuPopupItemRect(popupHwnd, items.size() - 1u, lastItemRectDip), "DPI relayout popup exposes the last item rect");
    Require(lastItemRectDip.bottom <= relayoutState.viewportRectDip.bottom + 0.5f, "DPI relayout keeps the last visible menu item inside the popup viewport");

    WindowHostBitmapCapture capture{};
    Require(WaitForContextMenuPopupBitmapCapture(popupHwnd, capture), "DPI relayout popup remains renderable");
    Require(capture.widthPx == static_cast<UINT>(relayoutState.windowRectPx.right - relayoutState.windowRectPx.left) &&
                capture.heightPx == static_cast<UINT>(relayoutState.windowRectPx.bottom - relayoutState.windowRectPx.top),
            "DPI relayout popup capture dimensions match the resized window rectangle");

    SendMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
    ownerWindow.PumpMessages();
    Require(callbackInvoked, "DPI relayout async popup closes through Escape");
    Require(! callbackResult.has_value(), "DPI relayout async popup closes without invoking a command");
    Require(WaitForWindowDestroyed(popupHwnd), "DPI relayout async popup window is destroyed after Escape");
}

void TestContextMenuDpiRelayoutConstrainsOversizedContentToWorkArea()
{
    using namespace DxUi;

    AttachedHostWindow ownerWindow;
    std::vector<MenuFlyoutItem> items;
    constexpr size_t kItemCount = 128u;
    items.reserve(kItemCount);
    for (size_t index = 0u; index < kItemCount; ++index)
    {
        items.push_back(MenuFlyoutItem{.text      = std::format(L"Oversized localized command label {} with deliberately wide content", index),
                                       .commandId = 7900 + static_cast<int>(index)});
    }

    ContextMenuSessionCallbacks callbacks{};
    callbacks.minRootWidthDip = 100000.0f;
    bool callbackInvoked      = false;
    const POINT menuPoint     = ClientScreenPointForTest(ownerWindow.Hwnd(), 40, 40, "oversized DPI menu anchor maps to screen coordinates");
    Require(ContextMenu::ShowAsync(
                ownerWindow.Hwnd(), menuPoint, items, ownerWindow.Host().GetTheme(), [&](std::optional<int>) noexcept { callbackInvoked = true; }, callbacks),
            "oversized DPI context menu opens");

    const HWND popupHwnd = WaitForOwnedContextMenuPopupWindowByFirstItemText(ownerWindow.Hwnd(), items.front().text);
    Require(popupHwnd != nullptr, "oversized DPI context menu popup appears");
    const auto dismissPopup = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popupHwnd) != FALSE)
        {
            SendMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
        }
    });

    ContextMenuPopupDebugState before{};
    Require(WaitForContextMenuPopupState(popupHwnd,
                                         [](const ContextMenuPopupDebugState& state) noexcept
    { return state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f && state.hasScrollbar; },
                                         before),
            "oversized DPI menu exposes bounded scrolling geometry");

    MONITORINFO monitorInfo{};
    monitorInfo.cbSize = sizeof(monitorInfo);
    Require(GetMonitorInfoW(MonitorFromWindow(popupHwnd, MONITOR_DEFAULTTONEAREST), &monitorInfo) != FALSE,
            "oversized DPI menu resolves its destination monitor work area");
    const UINT targetDpi = before.dpi == 192u ? 144u : 192u;
    RECT suggestedRect{monitorInfo.rcWork.left - 200, monitorInfo.rcWork.top - 200, monitorInfo.rcWork.right + 200, monitorInfo.rcWork.bottom + 200};
    SendMessageW(popupHwnd, WM_DPICHANGED, MAKEWPARAM(static_cast<WORD>(targetDpi), static_cast<WORD>(targetDpi)), reinterpret_cast<LPARAM>(&suggestedRect));

    ContextMenuPopupDebugState after{};
    Require(WaitForContextMenuPopupState(popupHwnd,
                                         [targetDpi](const ContextMenuPopupDebugState& state) noexcept
    { return state.dpi == targetDpi && state.hasScrollbar && state.visibleWidthDip > 0.0f && state.visibleHeightDip > 0.0f; },
                                         after),
            "oversized DPI menu relayout completes with a scrolling viewport");
    Require(after.surfaceRectPx.left >= monitorInfo.rcWork.left && after.surfaceRectPx.top >= monitorInfo.rcWork.top &&
                after.surfaceRectPx.right <= monitorInfo.rcWork.right && after.surfaceRectPx.bottom <= monitorInfo.rcWork.bottom,
            "DPI relayout caps both oversized extents and position to the destination work area");

    SendMessageW(popupHwnd, WM_KEYDOWN, VK_END, 0);
    ContextMenuPopupDebugState endState{};
    Require(WaitForContextMenuPopupState(popupHwnd,
                                         [](const ContextMenuPopupDebugState& state) noexcept
    { return state.keyboardIndex == std::optional<size_t>{kItemCount - 1u}; },
                                         endState),
            "oversized DPI menu keeps the final command keyboard-reachable");
    D2D1_RECT_F lastItemRect{};
    Require(WaitForContextMenuPopupItemRect(popupHwnd, kItemCount - 1u, lastItemRect),
            "oversized DPI menu exposes the final command layout after End navigation");
    Require(lastItemRect.top >= endState.viewportRectDip.top - 0.5f && lastItemRect.bottom <= endState.viewportRectDip.bottom + 0.5f,
            "oversized DPI menu scrolls the final command fully into the bounded viewport");

    SendMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
    ownerWindow.PumpMessages();
    Require(callbackInvoked, "oversized DPI menu closes through Escape");
    Require(WaitForWindowDestroyed(popupHwnd), "oversized DPI menu window is destroyed after Escape");
}

void TestDescribedMenuWrapsFrenchTextAndPreservesIdentity()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    const std::wstring leaf   = L"Sélection définitive pour impression et archivage — réunion familiale été 2026 && photographies originales";
    const std::wstring parent = L"D:\\Sauvegardes\\Archives photographiques personnelles de plusieurs générations\\";
    std::vector<MenuFlyoutItem> items{
        {.kind           = MenuItemKind::Radio,
         .text           = leaf,
         .checked        = true,
         .commandId      = 8911,
         .secondaryText  = parent + L"Exposition annuelle de la médiathèque",
         .accessibleName = L"Première destination complète 📷"},
        {.kind           = MenuItemKind::Radio,
         .text           = leaf,
         .commandId      = 8912,
         .secondaryText  = parent + L"Collection permanente du musée",
         .accessibleName = L"Deuxième destination complète 📷"},
        {.text = L"Commande indisponible", .enabled = false, .commandId = 8913, .secondaryText = L"Cette destination n’est plus accessible."}};
    std::optional<int> result;
    bool closed = false;
    ContextMenuSessionCallbacks callbacks{};
    callbacks.maxRootHeightDip = 170.0f;
    const HWND previousFocus   = GetFocus();
    const POINT anchor         = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "described menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(),
                                   anchor,
                                   items,
                                   owner.Host().GetTheme(),
                                   [&](std::optional<int> chosen) noexcept
    {
        result = chosen;
        closed = true;
    },
                                   callbacks),
            "described menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(
        owner.Hwnd(), L"Sélection définitive pour impression et archivage — réunion familiale été 2026 & photographies originales");
    Require(popup != nullptr, "described menu appears with literal ampersand");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    // ShowAsync deliberately activates its root popup for keyboard dispatch.
    // A no-activation fixture instead preserves its previous native focus.
    const HWND trackingFocus = GetFocus();
    Require(trackingFocus == popup || trackingFocus == previousFocus, "opening descriptions uses only the existing menu-session focus targets");
    ContextMenuPopupDebugState state{};
    Require(DebugGetContextMenuPopupState(popup, state), "described menu state available");
    Require(state.hasScrollbar && state.visibleHeightDip <= 170.5f, "described rows use a bounded scroll viewport");
    Require(state.itemSecondaryTexts[0] != state.itemSecondaryTexts[1], "repeated leaf names retain different complete parents");
    ContextMenuPopupItemLayoutDebugState layout{};
    Require(DebugGetContextMenuPopupItemLayout(popup, 0, layout), "described row geometry available");
    Require(layout.primaryLineCount > 1 && layout.secondaryLineCount > 1, "both long French fields wrap");
    Require(layout.textRectDip.bottom < layout.secondaryTextRectDip.top && layout.secondaryTextRectDip.bottom < layout.itemRectDip.bottom,
            "primary and parent text have separate complete regions inside row");
    const auto requireNativeWidths = [&]()
    {
        for (size_t index = 0; index < items.size(); ++index)
        {
            ContextMenuPopupItemLayoutDebugState row{};
            Require(DebugGetContextMenuPopupItemLayout(popup, index, row), "every described row exposes native text widths");
            const float availableWidth = row.textRectDip.right - row.textRectDip.left;
            Require(std::abs(row.primaryLayoutWidthDip - availableWidth) < 0.5f && std::abs(row.secondaryLayoutWidthDip - availableWidth) < 0.5f,
                    "shared native layouts retain the final row width without cumulative scrollbar subtraction");
        }
    };
    requireNativeWidths();
    const uint64_t preparationCount = state.descriptionPreparationCount;
    const uint64_t renderCount      = state.renderCount;
    for (int paint = 0; paint < 3; ++paint)
    {
        WindowHostBitmapCapture capture{};
        Require(DebugCaptureContextMenuPopupBitmap(popup, capture), "described menu captures through owned harness");
        if (paint == 0)
            Require(SaveWindowHostBitmapCaptureAsPngForTest(L".build/menu-description-test.png", capture), "described menu review capture is retained");
    }
    // The captures must really repaint the rows; otherwise the preparation count proves nothing.
    Require(DebugGetContextMenuPopupState(popup, state) && state.renderCount >= renderCount + 3u && state.lastPaintedItemCount > 0u,
            "each review capture repaints the described rows");
    Require(state.descriptionPreparationCount == preparationCount, "unchanged paints do not remeasure described text");
    SendMessageW(popup, WM_KEYDOWN, VK_END, 0);
    Require(DebugGetContextMenuPopupState(popup, state) && state.keyboardIndex == 1u, "End skips disabled row and targets exact second destination");
    Require(GetFocus() == trackingFocus, "logical menu navigation preserves the session's native focus");
    std::optional<ContextMenuPopupItemLayoutDebugState> first96DpiLayout;
    for (const UINT dpi : {192u, 96u, 144u, 96u})
    {
        RECT suggested = state.windowRectPx;
        SendMessageW(popup, WM_DPICHANGED, MAKEWPARAM(dpi, dpi), reinterpret_cast<LPARAM>(&suggested));
        Require(DebugGetContextMenuPopupState(popup, state) && state.dpi == dpi && state.keyboardIndex == 1u,
                "DPI relayout preserves exact keyboard destination");
        Require(DebugGetContextMenuPopupItemLayout(popup, 1, layout) && layout.secondaryLineCount > 1, "DPI relayout preserves complete parent wrapping");
        Require(layout.textRectDip.bottom < layout.secondaryTextRectDip.top && layout.secondaryTextRectDip.bottom < layout.itemRectDip.bottom,
                "DPI reflow keeps both complete text fields inside their row");
        requireNativeWidths();
        if (dpi == 96u)
        {
            if (first96DpiLayout)
            {
                const auto& first = *first96DpiLayout;
                Require(layout.primaryLineCount == first.primaryLineCount && layout.secondaryLineCount == first.secondaryLineCount &&
                            std::abs((layout.textRectDip.right - layout.textRectDip.left) - (first.textRectDip.right - first.textRectDip.left)) < 0.5f &&
                            std::abs((layout.itemRectDip.bottom - layout.itemRectDip.top) - (first.itemRectDip.bottom - first.itemRectDip.top)) < 0.5f,
                        "returning to the same DPI must not accumulate scrollbar narrowing or row growth");
            }
            first96DpiLayout = layout;
        }
    }
    SendMessageW(popup, WM_KEYDOWN, VK_RETURN, 0);
    owner.PumpMessages();
    Require(closed && result == 8912, "keyboard invokes exact second command despite identical leaf names");
    Require(WaitForWindowDestroyed(popup), "described menu closes after invocation");
}

void TestDescribedInfoRowPaintsItsDescription()
{
    using namespace DxUi;
    // An Info row with a description is measured taller for it, so it must also paint it (not leave the space blank).
    AttachedHostWindow owner;
    const std::wstring description = L"Across every volume in this library";
    std::vector<MenuFlyoutItem> items{{.text = L"Open volumes", .commandId = 9101, .secondaryText = description},
                                      {.kind = MenuItemKind::Info, .text = L"Used Space:", .acceleratorText = L"561 GB", .secondaryText = description}};
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "described info menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [](std::optional<int>) noexcept {}, ContextMenuSessionCallbacks{}),
            "described info menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), L"Open volumes");
    Require(popup != nullptr, "described info menu appears");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    ContextMenuPopupDebugState state{};
    WindowHostBitmapCapture capture{};
    ContextMenuPopupItemLayoutDebugState command{};
    ContextMenuPopupItemLayoutDebugState info{};
    Require(DebugGetContextMenuPopupState(popup, state) && DebugCaptureContextMenuPopupBitmap(popup, capture), "described info menu captures");
    Require(DebugGetContextMenuPopupItemLayout(popup, 0, command) && DebugGetContextMenuPopupItemLayout(popup, 1, info), "described rows expose geometry");
    const float scale    = static_cast<float>(state.dpi) / 96.0f;
    const auto inkInside = [&](const D2D1_RECT_F& rectDip)
    {
        const LONG left   = (std::max)(0L, static_cast<LONG>(std::ceil(rectDip.left * scale)));
        const LONG top    = (std::max)(0L, static_cast<LONG>(std::ceil(rectDip.top * scale)));
        const LONG right  = (std::min)(static_cast<LONG>(capture.widthPx), static_cast<LONG>(std::floor(rectDip.right * scale)));
        const LONG bottom = (std::min)(static_cast<LONG>(capture.heightPx), static_cast<LONG>(std::floor(rectDip.bottom * scale)));
        if (right <= left + 1 || bottom <= top)
            return size_t{0u};
        // The short description leaves the end of its first line empty: that pixel is the row background.
        const auto pixel = [&](LONG x, LONG y) { return &capture.bgraPixels[(static_cast<size_t>(y) * capture.widthPx + static_cast<size_t>(x)) * 4u]; };
        const uint8_t* background = pixel(right - 1, top);
        size_t ink                = 0u;
        for (LONG y = top; y < bottom; ++y)
            for (LONG x = left; x < right; ++x)
            {
                const uint8_t* value = pixel(x, y);
                const int difference = (std::max)({std::abs(value[0] - background[0]), std::abs(value[1] - background[1]), std::abs(value[2] - background[2])});
                ink += difference > 48 ? 1u : 0u;
            }
        return ink;
    };
    Require(inkInside(command.secondaryTextRectDip) > 20u, "a described command row paints its description");
    Require(inkInside(info.secondaryTextRectDip) > 20u, "a described Info row paints its description in its measured space");
}

void TestDescribedAsyncMenuRestoresFocusedOwnerChild()
{
    using namespace DxUi;
    // The ordinary NewControls lane remains nonactivating. The Menu lane owns
    // native focus qualification and its external desktop warning/restoration.
    if (! DxUiTestWindowsCanActivateFlag())
        return;
    AttachedHostWindow owner;
    ShowWindow(owner.Hwnd(), SW_SHOWNOACTIVATE);
    wil::unique_hwnd child(CreateWindowExW(
        0, L"EDIT", L"Menu owner input", WS_CHILD | WS_VISIBLE | WS_TABSTOP, 4, 4, 200, 28, owner.Hwnd(), nullptr, GetModuleHandleW(nullptr), nullptr));
    Require(bool(child), "async menu focus fixture creates its owned input");
    for (bool described : {false, true})
    {
        SetFocus(child.get());
        if (! WaitForFocusedWindow(child.get()))
        {
            SkipDxUiTest("DxUi async described-menu owner restoration requires an interactive desktop");
            return;
        }
        std::vector<MenuFlyoutItem> items{{.text = L"Première destination", .commandId = 89101}, {.text = L"Deuxième destination", .commandId = 89102}};
        if (described)
        {
            items[0].secondaryText = L"C:\\Photographies\\Archives familiales";
            items[1].secondaryText = L"D:\\Sauvegardes\\Collection du musée";
        }
        bool closed        = false;
        const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "focus fixture anchor maps to screen");
        Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [&](std::optional<int>) noexcept { closed = true; }),
                "focus fixture opens async menu");
        const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
        Require(popup != nullptr, "focus fixture identifies its owned menu");
        Require(WaitForFocusedWindow(popup), "plain and described async menus focus their keyboard-dispatch root");
        SendMessageW(popup, WM_KEYDOWN, VK_END, 0);
        ContextMenuPopupDebugState state{};
        Require(DebugGetContextMenuPopupState(popup, state) && state.keyboardIndex == 1u && GetFocus() == popup,
                "logical row navigation preserves native async-root focus");
        SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
        owner.PumpMessages();
        Require(closed && WaitForWindowDestroyed(popup) && WaitForFocusedWindow(child.get()),
                "plain and described async menus restore their original owner input on dismissal");
    }
}

void TestDescribedMenuAccessibilityInvokesAndDisconnects()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    std::vector<MenuFlyoutItem> items{{.kind           = MenuItemKind::Radio,
                                       .text           = L"Archives",
                                       .checked        = true,
                                       .commandId      = 8921,
                                       .secondaryText  = L"C:\\Famille\\Été",
                                       .accessibleName = L"C:\\Famille\\Été\\Archives"},
                                      {.kind           = MenuItemKind::Radio,
                                       .text           = L"Archives",
                                       .commandId      = 8922,
                                       .secondaryText  = L"D:\\Musée\\Été",
                                       .accessibleName = L"D:\\Musée\\Été\\Archives"}};
    std::optional<int> result;
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "accessible described menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [&](std::optional<int> chosen) noexcept { result = chosen; }),
            "accessible described menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), L"Archives");
    Require(popup != nullptr, "accessible described menu exists");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> root;
    root.attach(CreateWindowHostAccessibilityProvider(popup));
    Require(root != nullptr, "described menu publishes native UIA root");
    wil::com_ptr_nothrow<IRawElementProviderFragment> rootFragment;
    RequireSucceeded(root.query_to(rootFragment.put()), "menu root exposes fragment navigation");
    wil::com_ptr_nothrow<IRawElementProviderFragment> first;
    RequireSucceeded(rootFragment->Navigate(NavigateDirection_FirstChild, first.put()), "menu exposes first entry");
    Require(first != nullptr, "first menu entry exists");
    wil::com_ptr_nothrow<IRawElementProviderSimple> firstSimple;
    RequireSucceeded(first.query_to(firstSimple.put()), "checked menu entry exposes properties");
    wil::com_ptr_nothrow<IUnknown> checkedPattern;
    RequireSucceeded(firstSimple->GetPatternProvider(UIA_TogglePatternId, checkedPattern.put()), "checked menu entry provides Toggle state");
    wil::com_ptr_nothrow<IToggleProvider> checked;
    RequireSucceeded(checkedPattern.query_to(checked.put()), "checked menu entry exposes Toggle provider");
    ToggleState checkedState = ToggleState_Off;
    RequireSucceeded(checked->get_ToggleState(&checkedState), "checked menu state is readable");
    Require(checkedState == ToggleState_On, "UIA acknowledges the displayed radio selection");
    wil::com_ptr_nothrow<IRawElementProviderFragment> second;
    RequireSucceeded(first->Navigate(NavigateDirection_NextSibling, second.put()), "menu exposes second entry");
    Require(second != nullptr, "second menu entry exists");
    const HWND nativeFocus = GetFocus();
    RequireSucceeded(second->SetFocus(), "screen reader can focus a described row");
    owner.PumpMessages();
    ContextMenuPopupDebugState focusedState{};
    Require(GetFocus() == nativeFocus && DebugGetContextMenuPopupState(popup, focusedState) && focusedState.keyboardIndex == 1u,
            "UIA focus tracks the exact row without changing native menu-session focus");
    wil::com_ptr_nothrow<IRawElementProviderSimple> simple;
    RequireSucceeded(second.query_to(simple.put()), "menu entry exposes properties");
    wil::unique_variant name;
    RequireSucceeded(simple->GetPropertyValue(UIA_NamePropertyId, &name), "full menu identity is available");
    Require(name.vt == VT_BSTR && items[1].accessibleName == name.bstrVal, "UIA distinguishes repeated leaf using exact full identity");
    wil::unique_variant type;
    RequireSucceeded(simple->GetPropertyValue(UIA_ControlTypePropertyId, &type), "menu role is available");
    Require(type.vt == VT_I4 && type.lVal == UIA_MenuItemControlTypeId, "described command exposes MenuItem role");
    wil::com_ptr_nothrow<IUnknown> pattern;
    RequireSucceeded(simple->GetPatternProvider(UIA_InvokePatternId, pattern.put()), "menu item provides Invoke");
    wil::com_ptr_nothrow<IInvokeProvider> invoke;
    RequireSucceeded(pattern.query_to(invoke.put()), "menu item exposes Invoke provider");
    RequireSucceeded(invoke->Invoke(), "menu command invoke is queued safely");
    owner.PumpMessages();
    Require(result == 8922 && WaitForWindowDestroyed(popup), "UIA invokes exact selected destination and closes popup");
    Require(invoke->Invoke() == UIA_E_ELEMENTNOTAVAILABLE, "retained menu provider disconnects after teardown");
}

void TestDescribedMenuPointerAndCancelledQueuedInvoke()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    const std::vector<MenuFlyoutItem> items{
        {.text = L"Archives familiales", .commandId = 8931, .secondaryText = L"D:\\Photographies\\Réunion annuelle de toutes les générations"}};
    std::optional<int> result;
    const auto open = [&]()
    {
        result.reset();
        const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "pointer menu anchor maps to screen");
        Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [&](std::optional<int> chosen) noexcept { result = chosen; }),
                "pointer menu opens");
        const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
        Require(popup != nullptr, "pointer menu exists");
        return popup;
    };
    HWND popup         = open();
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    ContextMenuPopupItemLayoutDebugState layout{};
    ContextMenuPopupDebugState state{};
    Require(DebugGetContextMenuPopupItemLayout(popup, 0, layout) && DebugGetContextMenuPopupState(popup, state), "pointer menu exposes geometry");
    const auto x = static_cast<short>(DipToPixelForPopup((layout.secondaryTextRectDip.left + layout.secondaryTextRectDip.right) * 0.5f, state.dpi));
    const auto y = static_cast<short>(DipToPixelForPopup((layout.secondaryTextRectDip.top + layout.secondaryTextRectDip.bottom) * 0.5f, state.dpi));
    SendMessageW(popup, WM_LBUTTONDOWN, MK_LBUTTON, MAKELPARAM(x, y));
    SendMessageW(popup, WM_LBUTTONUP, 0, MAKELPARAM(x, y));
    owner.PumpMessages();
    Require(result == 8931 && WaitForWindowDestroyed(popup), "clicking description invokes its whole row");

    popup = open();
    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> root;
    root.attach(CreateWindowHostAccessibilityProvider(popup));
    Require(root != nullptr, "queued-action menu exposes root");
    wil::com_ptr_nothrow<IRawElementProviderFragment> rootFragment;
    RequireSucceeded(root.query_to(rootFragment.put()), "queued-action root navigates");
    wil::com_ptr_nothrow<IRawElementProviderFragment> item;
    RequireSucceeded(rootFragment->Navigate(NavigateDirection_FirstChild, item.put()), "queued-action item available");
    Require(item != nullptr, "queued-action item exists");
    wil::com_ptr_nothrow<IRawElementProviderSimple> simple;
    RequireSucceeded(item.query_to(simple.put()), "queued-action item has properties");
    wil::com_ptr_nothrow<IUnknown> pattern;
    RequireSucceeded(simple->GetPatternProvider(UIA_InvokePatternId, pattern.put()), "queued-action item supports invoke");
    wil::com_ptr_nothrow<IInvokeProvider> invoke;
    RequireSucceeded(pattern.query_to(invoke.put()), "queued-action invoke acquired");
    RequireSucceeded(invoke->Invoke(), "action queues before cancellation");
    // A message posted to a destroyed HWND cannot reach another popup unless the handle value is
    // reused, so the replacement check below cannot fail by itself. Observe the popup-owned payload
    // instead: WM_NCDESTROY must release it undispatched.
    const HWND cancelledPopup = popup;
    Require(CountQueuedPayloadsForMenuSuite(cancelledPopup) >= 1u, "the UIA invoke waits as a popup-owned payload");
    SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    Require(WaitForWindowDestroyed(popup) && ! result, "Escape cancels the queued action before dispatch");
    Require(CountQueuedPayloadsForMenuSuite(cancelledPopup) == 0u, "destroying the popup releases its queued action");
    popup = open();
    owner.PumpMessages();
    Require(IsWindow(popup) && ! result, "a replacement popup opens without running the cancelled action");
    Require(invoke->Invoke() == UIA_E_ELEMENTNOTAVAILABLE, "old provider cannot act on replacement popup");
}

void TestDescribedMenuSubmenuKeepsSessionAndIdentity()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    const std::vector<MenuFlyoutItem> items{
        {.text          = L"Archives",
         .commandId     = 8941,
         .children      = {{.text = L"Réunion familiale", .commandId = 89411, .secondaryText = L"C:\\Photographies\\Archives de toutes les générations"}},
         .secondaryText = L"C:\\Photographies\\Archives de toutes les générations"},
        {.text = L"Archives", .commandId = 8942, .secondaryText = L"D:\\Sauvegardes\\Collection de photographies déjà présentes"}};
    std::optional<int> result;
    bool closed        = false;
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "described submenu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(),
                                   anchor,
                                   items,
                                   owner.Host().GetTheme(),
                                   [&](std::optional<int> chosen) noexcept
    {
        result = chosen;
        closed = true;
    }),
            "described submenu session opens");
    const auto dismiss = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(owner.Hwnd()); });
    const HWND popup   = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), L"Archives");
    Require(popup != nullptr, "described parent menu exists");
    const HWND nativeFocus = GetFocus();
    SendMessageW(popup, WM_KEYDOWN, VK_HOME, 0);
    SendMessageW(popup, WM_KEYDOWN, VK_RIGHT, 0);
    const HWND child = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), L"Réunion familiale");
    Require(child != nullptr && ! closed, "Right opens a measured described submenu without choosing the parent");
    ContextMenuPopupItemLayoutDebugState layout{};
    Require(DebugGetContextMenuPopupItemLayout(child, 0, layout) && layout.secondaryLineCount > 0, "submenu prepares its description independently");
    SendMessageW(child, WM_KEYDOWN, VK_LEFT, 0);
    Require(WaitForWindowDestroyed(child) && IsWindow(popup) && ! closed, "Left closes only the described submenu");
    Require(GetFocus() == nativeFocus, "described submenu navigation preserves native focus");
    SendMessageW(popup, WM_KEYDOWN, VK_END, 0);
    SendMessageW(popup, WM_KEYDOWN, VK_RETURN, 0);
    owner.PumpMessages();
    Require(closed && result == 8942 && WaitForWindowDestroyed(popup), "return from submenu preserves the exact sibling command");
}

void TestDescribedPointerMenuActivationSelectsNoRow()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    const std::vector<MenuFlyoutItem> items{{.text = L"Archives familiales", .commandId = 8951, .secondaryText = L"C:\\Photographies\\Archives familiales"},
                                            {.text = L"Collection du musée", .commandId = 8952, .secondaryText = L"D:\\Sauvegardes\\Collection du musée"}};
    std::optional<int> result;
    bool closed        = false;
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "pointer-opened described menu anchor maps to screen");
    // focusFirstNavigableItem stays false, as for a context menu invoked by the pointer.
    Require(ContextMenu::ShowAsync(owner.Hwnd(),
                                   anchor,
                                   items,
                                   owner.Host().GetTheme(),
                                   [&](std::optional<int> chosen) noexcept
    {
        result = chosen;
        closed = true;
    }),
            "pointer-opened described menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "pointer-opened described menu appears");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    // In the activating lane ShowAsync gives its root native focus synchronously. That
    // activation must not choose a row, and nothing here pumps a pointer move that could reset one.
    ContextMenuPopupDebugState state{};
    Require(DebugGetContextMenuPopupState(popup, state) && ! state.keyboardIndex.has_value(), "activating a pointer-opened described menu selects no row");
    if (! state.hoveredIndex.has_value())
    {
        SendMessageW(popup, WM_KEYDOWN, VK_RETURN, 0);
        Require(! closed && IsWindow(popup), "Enter without a keyboard or pointer row invokes nothing");
        SendMessageW(popup, WM_KEYDOWN, VK_DOWN, 0);
        Require(DebugGetContextMenuPopupState(popup, state) && state.keyboardIndex == 0u, "the first Down selects the first described row");
    }
    SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    owner.PumpMessages();
    Require(closed && ! result && WaitForWindowDestroyed(popup), "dismissing the pointer-opened described menu returns no command");
}

void TestDescribedMenuScrollRepublishesAccessibleGeometry()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    std::vector<MenuFlyoutItem> items;
    for (int index = 0; index < 8; ++index)
    {
        items.push_back(MenuFlyoutItem{
            .text = std::format(L"Destination {}", index), .commandId = 8960 + index, .secondaryText = std::format(L"D:\\Sauvegardes\\Collection {}", index)});
    }
    ContextMenuSessionCallbacks callbacks{};
    callbacks.maxRootHeightDip = 170.0f;
    const POINT anchor         = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "scrolled described menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [](std::optional<int>) noexcept {}, callbacks),
            "scrolled described menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "scrolled described menu appears");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> root;
    root.attach(CreateWindowHostAccessibilityProvider(popup));
    Require(root != nullptr, "scrolled described menu publishes a UIA root");
    ContextMenuPopupDebugState state{};
    Require(DebugGetContextMenuPopupState(popup, state) && state.hasScrollbar && state.scrollOffsetDip == 0.0f,
            "described rows start at the top of a bounded viewport");

    // Three wheel notches toward the user move the rows without changing logical focus; nothing
    // is pumped. The signed delta travels in the high word, so 0x10000 - WHEEL_DELTA encodes -1 notch.
    const WPARAM wheelTowardUser = MAKEWPARAM(0, static_cast<WORD>(0x10000 - WHEEL_DELTA));
    const LPARAM wheelPoint =
        MAKELPARAM((state.surfaceRectPx.left + state.surfaceRectPx.right) / 2, (state.surfaceRectPx.top + state.surfaceRectPx.bottom) / 2);
    for (int notch = 0; notch < 3; ++notch)
        SendMessageW(popup, WM_MOUSEWHEEL, wheelTowardUser, wheelPoint);
    Require(DebugGetContextMenuPopupState(popup, state) && state.scrollOffsetDip > 60.0f && ! state.keyboardIndex.has_value(),
            "the wheel scrolls described rows without selecting one");

    std::optional<size_t> row;
    D2D1_RECT_F rowDip{};
    for (size_t index = 1; index < items.size() && ! row.has_value(); ++index)
    {
        D2D1_RECT_F candidate{};
        if (DebugGetContextMenuPopupItemRect(popup, index, candidate) && candidate.top >= state.viewportRectDip.top &&
            candidate.bottom <= state.viewportRectDip.bottom)
        {
            row    = index;
            rowDip = candidate;
        }
    }
    Require(row.has_value(), "a described row is fully visible after scrolling");
    RECT windowRect{};
    Require(GetWindowRect(popup, &windowRect) != FALSE, "scrolled popup exposes its window origin");
    const double expectedLeft   = static_cast<double>(windowRect.left) + static_cast<double>(DipToPixelForPopup(rowDip.left, state.dpi));
    const double expectedTop    = static_cast<double>(windowRect.top) + static_cast<double>(DipToPixelForPopup(rowDip.top, state.dpi));
    const double expectedRight  = static_cast<double>(windowRect.left) + static_cast<double>(DipToPixelForPopup(rowDip.right, state.dpi));
    const double expectedBottom = static_cast<double>(windowRect.top) + static_cast<double>(DipToPixelForPopup(rowDip.bottom, state.dpi));

    wil::com_ptr_nothrow<IRawElementProviderFragment> hit;
    RequireSucceeded(root->ElementProviderFromPoint((expectedLeft + expectedRight) * 0.5, (expectedTop + expectedBottom) * 0.5, hit.put()),
                     "UIA hit-tests the scrolled row");
    Require(hit != nullptr, "UIA hit testing finds a described row after scrolling");
    wil::com_ptr_nothrow<IRawElementProviderSimple> hitSimple;
    RequireSucceeded(hit.query_to(hitSimple.put()), "the hit row exposes properties");
    wil::unique_variant automationId;
    RequireSucceeded(hitSimple->GetPropertyValue(UIA_AutomationIdPropertyId, &automationId), "the hit row exposes its automation id");
    Require(automationId.vt == VT_BSTR && std::format(L"menu.item.{}", *row) == automationId.bstrVal, "UIA hit testing follows the scrolled row geometry");
    UiaRect bounds{};
    RequireSucceeded(hit->get_BoundingRectangle(&bounds), "the hit row exposes its bounds");
    Require(std::abs(bounds.left - expectedLeft) <= 1.0 && std::abs(bounds.top - expectedTop) <= 1.0 &&
                std::abs(bounds.left + bounds.width - expectedRight) <= 1.0 && std::abs(bounds.top + bounds.height - expectedBottom) <= 1.0,
            "UIA bounds follow the scrolled row geometry");
}

// A menu without descriptions exposes its rows as a described menu does: role, state, exact name and geometry, a logical
// UIA focus that leaves native focus alone, and an Invoke queued to the popup that expires with it.
void TestPlainMenuAccessibilityInvokesAndDisconnects()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    const std::vector<MenuFlyoutItem> items{
        {.kind           = MenuItemKind::Radio,
         .text           = L"Première destination",
         .checked        = true,
         .commandId      = 8991,
         .accessibleName = L"C:\\Famille\\Été\\Première destination"},
        {.text = L"Indisponible", .enabled = false, .commandId = 8992},
        {.kind = MenuItemKind::Info, .text = L"Information seulement"},
        {.kind = MenuItemKind::Radio, .text = L"Deuxième destination", .commandId = 8994, .accessibleName = L"D:\\Musée\\Été\\Deuxième destination"}};
    const ContextMenuResourceDebugState before = DebugGetContextMenuResources();
    int callbacks                              = 0;
    std::optional<int> result;
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "plain accessible menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(),
                                   anchor,
                                   items,
                                   owner.Host().GetTheme(),
                                   [&](std::optional<int> chosen) noexcept
    {
        ++callbacks;
        result = chosen;
    }),
            "plain accessible menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "plain accessible menu exists");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    ContextMenuPopupDebugState state{};
    Require(DebugGetContextMenuPopupState(popup, state) && state.descriptionPreparationCount == 0u &&
                std::all_of(state.itemSecondaryTexts.begin(), state.itemSecondaryTexts.end(), [](const std::wstring& text) noexcept { return text.empty(); }),
            "the plain menu prepares no description");
    Require(DebugGetContextMenuResources().accessibilityRecords >= before.accessibilityRecords + items.size(), "every row of the open plain menu is published");

    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> root;
    root.attach(CreateWindowHostAccessibilityProvider(popup));
    Require(root != nullptr, "plain menu publishes its native UIA root");
    wil::com_ptr_nothrow<IRawElementProviderFragment> rootFragment;
    RequireSucceeded(root.query_to(rootFragment.put()), "plain menu root exposes fragment navigation");
    const auto reach = [](IRawElementProviderFragment* from, NavigateDirection direction, const char* expectation)
    {
        wil::com_ptr_nothrow<IRawElementProviderFragment> row;
        RequireSucceeded(from->Navigate(direction, row.put()), expectation);
        Require(row != nullptr, expectation);
        wil::com_ptr_nothrow<IRawElementProviderSimple> simple;
        RequireSucceeded(row.query_to(simple.put()), expectation);
        return std::pair{row, simple};
    };

    const auto [checkedRow, checkedSimple] = reach(rootFragment.get(), NavigateDirection_FirstChild, "the checked radio row is the first child");
    wil::com_ptr_nothrow<IUnknown> togglePattern;
    RequireSucceeded(checkedSimple->GetPatternProvider(UIA_TogglePatternId, togglePattern.put()), "the radio row provides Toggle");
    wil::com_ptr_nothrow<IToggleProvider> toggle;
    RequireSucceeded(togglePattern.query_to(toggle.put()), "the radio row exposes its Toggle provider");
    ToggleState checked = ToggleState_Off;
    RequireSucceeded(toggle->get_ToggleState(&checked), "the radio row's state is readable");
    Require(checked == ToggleState_On, "UIA acknowledges the displayed radio selection of a plain menu");

    const auto [disabledRow, disabledSimple] = reach(checkedRow.get(), NavigateDirection_NextSibling, "the disabled command follows");
    wil::unique_variant enabled;
    RequireSucceeded(disabledSimple->GetPropertyValue(UIA_IsEnabledPropertyId, &enabled), "the disabled command's state is readable");
    Require(enabled.vt == VT_BOOL && enabled.boolVal == VARIANT_FALSE, "UIA reports the disabled command as disabled");
    wil::com_ptr_nothrow<IUnknown> disabledPattern;
    RequireSucceeded(disabledSimple->GetPatternProvider(UIA_InvokePatternId, disabledPattern.put()), "the disabled command's Invoke lookup succeeds");
    wil::com_ptr_nothrow<IInvokeProvider> disabledInvoke;
    Require(disabledPattern != nullptr && SUCCEEDED(disabledPattern.query_to(disabledInvoke.put())), "the disabled command keeps its Invoke pattern");
    Require(FAILED(disabledInvoke->Invoke()), "invoking the disabled command fails");
    owner.PumpMessages();
    Require(callbacks == 0 && IsWindow(popup), "the disabled command neither runs nor closes the menu");

    const auto [infoRow, infoSimple] = reach(disabledRow.get(), NavigateDirection_NextSibling, "the information row follows");
    wil::com_ptr_nothrow<IUnknown> infoPattern;
    RequireSucceeded(infoSimple->GetPatternProvider(UIA_InvokePatternId, infoPattern.put()), "the information row's Invoke lookup succeeds");
    Require(! infoPattern, "an information row is not a command");

    const auto [targetRow, targetSimple] = reach(infoRow.get(), NavigateDirection_NextSibling, "the second radio row follows");
    wil::unique_variant name;
    RequireSucceeded(targetSimple->GetPropertyValue(UIA_NamePropertyId, &name), "the row's name is readable");
    Require(name.vt == VT_BSTR && items[3].accessibleName == name.bstrVal, "UIA names the row with its exact accessible name");
    wil::unique_variant type;
    RequireSucceeded(targetSimple->GetPropertyValue(UIA_ControlTypePropertyId, &type), "the row's role is readable");
    Require(type.vt == VT_I4 && type.lVal == UIA_MenuItemControlTypeId, "a plain command row has the MenuItem role");
    D2D1_RECT_F rowDip{};
    RECT windowRect{};
    Require(DebugGetContextMenuPopupItemRect(popup, 3u, rowDip) && GetWindowRect(popup, &windowRect) != FALSE, "the row exposes its retained geometry");
    UiaRect bounds{};
    RequireSucceeded(targetRow->get_BoundingRectangle(&bounds), "the row exposes its bounds");
    const double expectedLeft   = static_cast<double>(windowRect.left) + static_cast<double>(DipToPixelForPopup(rowDip.left, state.dpi));
    const double expectedTop    = static_cast<double>(windowRect.top) + static_cast<double>(DipToPixelForPopup(rowDip.top, state.dpi));
    const double expectedRight  = static_cast<double>(windowRect.left) + static_cast<double>(DipToPixelForPopup(rowDip.right, state.dpi));
    const double expectedBottom = static_cast<double>(windowRect.top) + static_cast<double>(DipToPixelForPopup(rowDip.bottom, state.dpi));
    Require(std::abs(bounds.left - expectedLeft) <= 1.0 && std::abs(bounds.top - expectedTop) <= 1.0 &&
                std::abs(bounds.left + bounds.width - expectedRight) <= 1.0 && std::abs(bounds.top + bounds.height - expectedBottom) <= 1.0,
            "UIA bounds are the row's retained geometry at the popup's DPI");

    const HWND nativeFocus = GetFocus();
    RequireSucceeded(targetRow->SetFocus(), "a screen reader can focus a plain row");
    owner.PumpMessages();
    Require(DebugGetContextMenuPopupState(popup, state) && state.keyboardIndex == 3u && GetFocus() == nativeFocus,
            "UIA focus chooses the exact row and leaves native menu-session focus alone");
    wil::com_ptr_nothrow<IUnknown> pattern;
    RequireSucceeded(targetSimple->GetPatternProvider(UIA_InvokePatternId, pattern.put()), "the row provides Invoke");
    wil::com_ptr_nothrow<IInvokeProvider> invoke;
    RequireSucceeded(pattern.query_to(invoke.put()), "the row exposes its Invoke provider");
    RequireSucceeded(invoke->Invoke(), "the command is queued");
    Require(callbacks == 0 && IsWindow(popup), "the queued command waits for the popup's dispatch");
    owner.PumpMessages();
    Require(callbacks == 1 && result == 8994 && WaitForWindowDestroyed(popup), "UIA invokes exactly the chosen plain command, once");
    Require(invoke->Invoke() == UIA_E_ELEMENTNOTAVAILABLE, "a retained plain-menu provider disconnects with its popup");
    Require(DebugGetContextMenuResources() == before, "the closed plain menu returns every popup and record it held");
}

// A long menu without descriptions keeps the rows its viewport cuts off as UI Automation elements, offscreen and without a
// rectangle, until UIA focus scrolls one into view, which republishes the geometry of every row.
void TestPlainMenuAccessibilityScrollsFocusedRow()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    constexpr size_t rowCount = 128u;
    std::vector<MenuFlyoutItem> items;
    items.reserve(rowCount);
    for (size_t index = 0u; index < rowCount; ++index)
        items.push_back(MenuFlyoutItem{.text = std::format(L"Destination {}", index), .commandId = static_cast<int>(9700u + index)});
    ContextMenuSessionCallbacks callbacks{};
    callbacks.maxRootHeightDip = 300.0f;
    bool closed                = false;
    const POINT anchor         = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "long plain menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [&](std::optional<int>) noexcept { closed = true; }, callbacks),
            "long plain menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "long plain menu appears");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> root;
    root.attach(CreateWindowHostAccessibilityProvider(popup));
    Require(root != nullptr, "long plain menu publishes its native UIA root");
    wil::com_ptr_nothrow<IRawElementProviderFragment> rootFragment;
    RequireSucceeded(root.query_to(rootFragment.put()), "long plain menu root navigates");
    const auto offscreen = [](const wil::com_ptr_nothrow<IRawElementProviderFragment>& row, const char* expectation)
    {
        wil::com_ptr_nothrow<IRawElementProviderSimple> simple;
        RequireSucceeded(row.query_to(simple.put()), expectation);
        wil::unique_variant value;
        RequireSucceeded(simple->GetPropertyValue(UIA_IsOffscreenPropertyId, &value), expectation);
        Require(value.vt == VT_BOOL, expectation);
        return value.boolVal == VARIANT_TRUE;
    };
    wil::com_ptr_nothrow<IRawElementProviderFragment> first;
    RequireSucceeded(rootFragment->Navigate(NavigateDirection_FirstChild, first.put()), "the first row is a child");
    wil::com_ptr_nothrow<IRawElementProviderFragment> last;
    RequireSucceeded(rootFragment->Navigate(NavigateDirection_LastChild, last.put()), "the last row is a child although the viewport cuts it off");
    Require(first != nullptr && last != nullptr, "the long menu exposes its first and last rows");
    wil::com_ptr_nothrow<IRawElementProviderSimple> lastSimple;
    RequireSucceeded(last.query_to(lastSimple.put()), "the last row exposes properties");
    wil::unique_variant name;
    RequireSucceeded(lastSimple->GetPropertyValue(UIA_NamePropertyId, &name), "the last row's name is readable");
    Require(name.vt == VT_BSTR && std::wstring_view(name.bstrVal, SysStringLen(name.bstrVal)) == L"Destination 127", "the last child is the last row");
    UiaRect bounds{};
    RequireSucceeded(last->get_BoundingRectangle(&bounds), "the cut-off row's bounds are readable");
    Require(offscreen(last, "the cut-off row's offscreen state is readable") && (bounds.width <= 0.0 || bounds.height <= 0.0),
            "a row the viewport cuts off is offscreen, without a rectangle");
    Require(! offscreen(first, "the first row's offscreen state is readable"), "the first row is on screen");

    const HWND nativeFocus = GetFocus();
    RequireSucceeded(last->SetFocus(), "UIA can focus the cut-off row");
    owner.PumpMessages();
    ContextMenuPopupDebugState state{};
    Require(DebugGetContextMenuPopupState(popup, state) && state.keyboardIndex == rowCount - 1u && state.scrollOffsetDip > 0.0f,
            "UIA focus selects the last row and scrolls it into view");
    RequireSucceeded(last->get_BoundingRectangle(&bounds), "the revealed row's bounds are readable");
    Require(! offscreen(last, "the revealed row's offscreen state is readable") && bounds.width > 0.0 && bounds.height > 0.0,
            "the revealed row is on screen, with its rectangle");
    Require(offscreen(first, "the first row's offscreen state is readable again"),
            "scrolling to the last row leaves the first one offscreen, still an element");
    Require(GetFocus() == nativeFocus && ! closed, "UIA focus keeps native focus and invokes nothing");
    SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    owner.PumpMessages();
    Require(closed && WaitForWindowDestroyed(popup), "the long plain menu closes");
}

// At 125%/175%, whole-device-pixel sizing can leave a plain popup less than half a pixel
// shorter than its content. That rounding slack is not a scroll range.
void TestPlainMenuFractionalDpiRoundingDoesNotCreateScrollbar()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    const UINT dpi = GetDpiForWindow(owner.Hwnd());
    if (dpi != 120u && dpi != 168u)
    {
        SkipDxUiTest("plain-menu half-pixel layout case requires a 125% or 175% monitor");
        return;
    }

    ThemePalette theme = owner.Host().GetTheme();
    theme.density      = Density::Standard;
    owner.Host().SetTheme(theme);
    const size_t separators = dpi == 120u ? 3u : 1u;
    std::vector<MenuFlyoutItem> items{{.text = L"Rounding slack", .commandId = 9191}};
    for (size_t index = 0u; index < separators; ++index)
        items.push_back(MenuFlyoutItem{.kind = MenuItemKind::Separator});

    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "fractional-DPI plain menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, theme, [](std::optional<int>) noexcept {}), "fractional-DPI plain menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "fractional-DPI plain menu appears");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    ContextMenuPopupDebugState state{};
    Require(DebugGetContextMenuPopupState(popup, state) && state.dpi == dpi, "plain menu reports the target fractional DPI");
    const float roundingSlackDip = 0.5f * 96.0f / static_cast<float>(dpi);
    Require(state.contentHeightDip > state.visibleHeightDip && state.contentHeightDip - state.visibleHeightDip <= roundingSlackDip,
            "the fixture reaches the sub-half-pixel content overflow caused by whole-pixel sizing");
    Require(! state.hasScrollbar && state.scrollOffsetDip == 0.0f,
            "plain-menu rounding slack does not reserve a scrollbar lane or create fractional scroll range");
}

void TestPlainMenuPointerMoveClearsLogicalFocusAndRefreshesAccessibility()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    const std::vector<MenuFlyoutItem> items{{.text = L"Pointer row", .commandId = 9192}, {.text = L"UIA row", .commandId = 9193}};
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "pointer-focus menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [](std::optional<int>) noexcept {}), "pointer-focus plain menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "pointer-focus plain menu appears");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });

    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> root;
    root.attach(CreateWindowHostAccessibilityProvider(popup));
    Require(root != nullptr, "pointer-focus menu publishes its UIA root");
    wil::com_ptr_nothrow<IRawElementProviderFragment> rootFragment;
    RequireSucceeded(root.query_to(rootFragment.put()), "pointer-focus menu root supports navigation");
    wil::com_ptr_nothrow<IRawElementProviderFragment> pointerRow;
    RequireSucceeded(rootFragment->Navigate(NavigateDirection_FirstChild, pointerRow.put()), "the pointer row is the first child");
    wil::com_ptr_nothrow<IRawElementProviderFragment> focusedRow;
    RequireSucceeded(pointerRow->Navigate(NavigateDirection_NextSibling, focusedRow.put()), "the UIA row follows the pointer row");
    wil::com_ptr_nothrow<IRawElementProviderSimple> focusedSimple;
    RequireSucceeded(focusedRow.query_to(focusedSimple.put()), "the UIA row exposes focus properties");

    D2D1_RECT_F rowRect{};
    ContextMenuPopupDebugState state{};
    Require(DebugGetContextMenuPopupItemRect(popup, 0u, rowRect) && DebugGetContextMenuPopupState(popup, state),
            "the pointer row exposes popup-relative geometry");
    const LONG x = static_cast<LONG>(DipToPixelForPopup((rowRect.left + rowRect.right) * 0.5f, state.dpi));
    const LONG y = static_cast<LONG>(DipToPixelForPopup((rowRect.top + rowRect.bottom) * 0.5f, state.dpi));
    Require(SendSettledClientMouseMoveForMenuSuite(popup, x, y), "a delivered move hovers the first row");
    Require(DebugGetContextMenuPopupState(popup, state) && state.hoveredIndex == 0u, "the first row is hovered");

    RequireSucceeded(focusedRow->SetFocus(), "UIA focuses the second menu row");
    owner.PumpMessages();
    Require(DebugGetContextMenuPopupState(popup, state) && state.keyboardIndex == 1u && ! state.hoveredIndex.has_value(),
            "UIA focus selects the second row logically and clears the stale pointer hover");
    ContextMenuPopupItemPaintDebugState rowPaint{};
    Require(DebugGetContextMenuPopupItemPaint(popup, 1u, rowPaint) && rowPaint.usesHighlightFill,
            "the UIA-focused row remains visibly highlighted after the prior hover is cleared");
    wil::unique_variant hasFocus;
    RequireSucceeded(focusedSimple->GetPropertyValue(UIA_HasKeyboardFocusPropertyId, &hasFocus), "the UIA row focus property is readable");
    Require(hasFocus.vt == VT_BOOL && hasFocus.boolVal == VARIANT_TRUE, "the UIA snapshot reports the focused row");

    Require(SendSettledClientMouseMoveForMenuSuite(popup, x, y), "a stationary pointer event is delivered after UIA focus");
    Require(DebugGetContextMenuPopupState(popup, state) && state.keyboardIndex == 1u && ! state.hoveredIndex.has_value(),
            "a stationary pointer preserves the row UIA focused");
    Require(SendSettledClientMouseMoveForMenuSuite(popup, x + 1, y), "a later pointer movement returns to the original pointer row");
    Require(DebugGetContextMenuPopupState(popup, state) && state.hoveredIndex == 0u && ! state.keyboardIndex.has_value(),
            "the delivered pointer restores hover and clears the UIA keyboard row");
    hasFocus.reset();
    RequireSucceeded(focusedSimple->GetPropertyValue(UIA_HasKeyboardFocusPropertyId, &hasFocus), "the UIA focus property refreshes after pointer movement");
    Require(hasFocus.vt == VT_BOOL && hasFocus.boolVal == VARIANT_FALSE, "the UIA snapshot no longer reports stale keyboard focus");
    Require(DebugGetContextMenuPopupItemPaint(popup, 1u, rowPaint) && ! rowPaint.usesHighlightFill,
            "the row that lost logical focus is repainted without its former highlight");
}

void TestPlainMenuWheelReconcilesHoverAndCancelsMovedSubmenuTimer()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    std::vector<MenuFlyoutItem> children{{.text = L"Child command", .commandId = 9194}};
    std::vector<MenuFlyoutItem> items{{.text = L"Submenu row", .children = children}, {.text = L"Next row", .commandId = 9195}};
    for (int index = 0; index < 12; ++index)
        items.push_back(MenuFlyoutItem{.text = std::format(L"Extra row {}", index), .commandId = 9200 + index});
    ContextMenuSessionCallbacks callbacks{};
    callbacks.maxRootHeightDip = 140.0f;
    const POINT anchor         = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "wheel menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [](std::optional<int>) noexcept {}, callbacks),
            "scrollable plain menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "scrollable plain menu appears");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });

    ContextMenuPopupDebugState state{};
    D2D1_RECT_F rowRect{};
    RECT windowRect{};
    Require(DebugGetContextMenuPopupState(popup, state) && state.hasScrollbar && DebugGetContextMenuPopupItemRect(popup, 0u, rowRect) &&
                GetWindowRect(popup, &windowRect) != FALSE,
            "the submenu row has scrollable geometry");
    const LONG x = static_cast<LONG>(DipToPixelForPopup((rowRect.left + rowRect.right) * 0.5f, state.dpi));
    const LONG y = static_cast<LONG>(DipToPixelForPopup((rowRect.top + rowRect.bottom) * 0.5f, state.dpi));
    Require(SendSettledClientMouseMoveForMenuSuite(popup, x, y), "a delivered move hovers the submenu row");
    Require(DebugGetContextMenuPopupState(popup, state) && state.hoveredIndex == 0u && state.hoverTimerPendingOpen && state.hoverTimerItemIndex == 0u,
            "hover starts the first row's submenu timer");

    const POINT screenPoint{windowRect.left + x, windowRect.top + y};
    const WPARAM wheelTowardUser = MAKEWPARAM(0, static_cast<WORD>(0x10000 - WHEEL_DELTA));
    SendMessageW(popup, WM_MOUSEWHEEL, wheelTowardUser, MousePointLParamForMenuSuite(screenPoint.x, screenPoint.y));
    Require(DebugGetContextMenuPopupState(popup, state) && state.scrollOffsetDip > 0.0f && state.hoveredIndex == 1u && ! state.hoverTimerActive,
            "wheel scrolling retargets hover to the row now under the stationary pointer and cancels the moved submenu timer");
}

void TestOpeningSubmenuEdgeScrollRepaintsParentAccessibilityBounds()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    std::vector<MenuFlyoutItem> children{{.text = L"Edge child", .commandId = 9196}};
    std::vector<MenuFlyoutItem> items{{.text = L"Edge submenu", .children = children}};
    for (int index = 0; index < 14; ++index)
        items.push_back(MenuFlyoutItem{.text = std::format(L"Edge filler {}", index), .commandId = 9300 + index});
    ContextMenuSessionCallbacks callbacks{};
    callbacks.maxRootHeightDip = 140.0f;
    const POINT anchor         = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "edge-scroll menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [](std::optional<int>) noexcept {}, callbacks),
            "edge-scroll plain menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "edge-scroll plain menu appears");
    const auto dismiss = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(owner.Hwnd()); });

    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> root;
    root.attach(CreateWindowHostAccessibilityProvider(popup));
    Require(root != nullptr, "edge-scroll menu publishes a UIA root");
    wil::com_ptr_nothrow<IRawElementProviderFragment> rootFragment;
    RequireSucceeded(root.query_to(rootFragment.put()), "edge-scroll menu root supports row navigation");
    wil::com_ptr_nothrow<IRawElementProviderFragment> firstRow;
    RequireSucceeded(rootFragment->Navigate(NavigateDirection_FirstChild, firstRow.put()), "the submenu row is the first UIA child");

    ContextMenuPopupDebugState state{};
    D2D1_RECT_F rowRect{};
    RECT windowRect{};
    Require(DebugGetContextMenuPopupState(popup, state) && DebugGetContextMenuPopupItemRect(popup, 0u, rowRect) && GetWindowRect(popup, &windowRect) != FALSE,
            "edge-scroll parent exposes the first row geometry");
    const LONG x         = static_cast<LONG>(DipToPixelForPopup((rowRect.left + rowRect.right) * 0.5f, state.dpi));
    const LONG originalY = static_cast<LONG>(DipToPixelForPopup((rowRect.top + rowRect.bottom) * 0.5f, state.dpi));
    const POINT screenPoint{windowRect.left + x, windowRect.top + originalY};
    const WPARAM halfNotchTowardUser = MAKEWPARAM(0, static_cast<WORD>(0x10000 - (WHEEL_DELTA / 2)));
    SendMessageW(popup, WM_MOUSEWHEEL, halfNotchTowardUser, MousePointLParamForMenuSuite(screenPoint.x, screenPoint.y));
    Require(DebugGetContextMenuPopupState(popup, state) && state.scrollOffsetDip > 0.0f && state.scrollOffsetDip < 24.0f,
            "a half-notch leaves the first submenu row partially visible");
    Require(DebugGetContextMenuPopupItemRect(popup, 0u, rowRect), "the partially visible submenu row remains addressable");
    const LONG partialY = static_cast<LONG>(DipToPixelForPopup((rowRect.top + rowRect.bottom) * 0.5f, state.dpi));
    Require(SendSettledClientMouseMoveForMenuSuite(popup, x, partialY), "a delivered move hovers the partially visible first row");
    Require(DebugGetContextMenuPopupState(popup, state) && state.hoveredIndex == 0u && state.hoverTimerPendingOpen,
            "the partially visible submenu row starts its delayed open");

    UiaRect before{};
    RequireSucceeded(firstRow->get_BoundingRectangle(&before), "the partially visible UIA row exposes clipped bounds");
    Require(FirePendingSubmenuHoverTimerForMenuSuite(popup), "the pending submenu timer opens the child");
    owner.PumpMessages();
    Require(FindOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), L"Edge child") != nullptr, "the edge submenu child is visible after its hover timer");
    Require(DebugGetContextMenuPopupState(popup, state) && state.scrollOffsetDip == 0.0f, "opening the edge submenu reveals the parent menu padding");
    UiaRect after{};
    RequireSucceeded(firstRow->get_BoundingRectangle(&after), "the parent UIA row exposes bounds after edge reveal");
    Require(after.top < before.top || after.height > before.height, "parent repaint republishes the row's edge-revealed bounds");
}

// The native focus a popup receives selects no row, plain or described: the first Down chooses the first command, and
// focus that comes back keeps the row chosen and acknowledges it again to UI Automation.
void TestMenuNativeFocusSelectsNoRowAndRestoresTheChosenOne()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    for (const bool described : {false, true})
    {
        std::vector<MenuFlyoutItem> items{{.kind = MenuItemKind::Info, .text = L"Information sur la sélection"},
                                          {.text = L"Première commande", .commandId = 8995},
                                          {.kind = MenuItemKind::Info, .text = L"Autre information"},
                                          {.text = L"Deuxième commande", .commandId = 8996}};
        if (described)
            items[1].secondaryText = L"Une description ne choisit pas la commande.";
        bool closed        = false;
        const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "native focus menu anchor maps to screen");
        Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [&](std::optional<int>) noexcept { closed = true; }),
                "native focus menu opens");
        const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
        Require(popup != nullptr, "native focus menu appears");
        const auto dismiss     = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popup))
                SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
        });
        const HWND nativeFocus = GetFocus();
        // An owned move outside the client area, which moves no cursor, so that no row starts hovered.
        SendMessageW(popup, WM_MOUSEMOVE, 0, MAKELPARAM(-20, -20));
        SendMessageW(popup, WM_SETFOCUS, 0, 0);
        ContextMenuPopupDebugState state{};
        Require(DebugGetContextMenuPopupState(popup, state) && ! state.keyboardIndex.has_value() && ! state.hoveredIndex.has_value() &&
                    GetFocus() == nativeFocus,
                "native focus selects no row of a plain or described menu");
        SendMessageW(popup, WM_KEYDOWN, VK_DOWN, 0);
        Require(DebugGetContextMenuPopupState(popup, state) && state.keyboardIndex == 1u && GetFocus() == nativeFocus,
                "the first Down selects the first command");
        SendMessageW(popup, WM_KILLFOCUS, reinterpret_cast<WPARAM>(owner.Hwnd()), 0);
        SendMessageW(popup, WM_SETFOCUS, 0, 0);
        Require(DebugGetContextMenuPopupState(popup, state) && state.keyboardIndex == 1u && GetFocus() == nativeFocus,
                "native focus that comes back keeps the chosen row");
        wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> root;
        root.attach(CreateWindowHostAccessibilityProvider(popup));
        Require(root != nullptr, "native focus menu publishes its UIA root");
        wil::com_ptr_nothrow<IRawElementProviderFragment> focused;
        RequireSucceeded(root->GetFocus(focused.put()), "UIA reads the menu's focus");
        Require(focused != nullptr, "the chosen row is UIA's focus again");
        wil::com_ptr_nothrow<IRawElementProviderSimple> focusedSimple;
        RequireSucceeded(focused.query_to(focusedSimple.put()), "the focused row exposes properties");
        wil::unique_variant hasFocus;
        RequireSucceeded(focusedSimple->GetPropertyValue(UIA_HasKeyboardFocusPropertyId, &hasFocus), "the focused row's focus state is readable");
        wil::unique_variant automationId;
        RequireSucceeded(focusedSimple->GetPropertyValue(UIA_AutomationIdPropertyId, &automationId), "the focused row's automation id is readable");
        Require(hasFocus.vt == VT_BOOL && hasFocus.boolVal == VARIANT_TRUE && automationId.vt == VT_BSTR &&
                    std::wstring_view(automationId.bstrVal) == L"menu.item.1",
                "the restored focus is the chosen row's");
        SendMessageW(popup, WM_KEYDOWN, VK_DOWN, 0);
        Require(DebugGetContextMenuPopupState(popup, state) && state.keyboardIndex == 3u && GetFocus() == nativeFocus && ! closed,
                "the next Down skips the information row and invokes nothing");
        SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
        owner.PumpMessages();
        Require(closed && WaitForWindowDestroyed(popup), "native focus menu closes");
    }
}

void TestDescribedSubmenuSliderFocusKeepsSessionFocus()
{
    using namespace DxUi;
    // Native focus ownership needs the activating Menu lane; the nonactivating lane blocks focus changes.
    if (! DxUiTestWindowsCanActivateFlag())
        return;
    AttachedHostWindow owner;
    SetWindowPos(owner.Hwnd(), nullptr, 120, 120, 360, 220, SWP_NOZORDER);
    if (! TryActivateDxUiTestWindow(owner.Hwnd()))
    {
        SkipDxUiTest("DxUi described submenu focus retention requires an interactive desktop");
        return;
    }
    // Modal and asynchronous sessions both activate their root popup, so explicit focus of a root row
    // cannot move Win32 focus. A submenu never activates: a native transfer for its focusable slider
    // row, which is not a MenuItem command, would activate it and deactivate the root, which ends an
    // asynchronous session while the provider call is still running.
    const std::vector<MenuFlyoutItem> items{{.text      = L"Affichage",
                                             .commandId = 8971,
                                             .children = {{.text = L"Archives", .commandId = 89711, .secondaryText = L"C:\\Photographies\\Archives familiales"},
                                                          {.kind        = MenuItemKind::Slider,
                                                           .text        = L"Zoom",
                                                           .sliderStops = {{.text = L"Petit", .commandId = 89712}, {.text = L"Grand", .commandId = 89713}}}},
                                             .secondaryText = L"Options de la galerie"}};
    bool closed        = false;
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 24, 60, "described submenu slider anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [&](std::optional<int>) noexcept { closed = true; }),
            "described submenu slider session opens");
    const auto dismiss = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(owner.Hwnd()); });
    const HWND popup   = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), L"Affichage");
    Require(popup != nullptr && WaitForFocusedWindow(popup), "the asynchronous root popup takes native keyboard focus");
    SendMessageW(popup, WM_KEYDOWN, VK_HOME, 0);
    SendMessageW(popup, WM_KEYDOWN, VK_RIGHT, 0);
    const HWND child = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), L"Archives");
    Require(child != nullptr && ! closed && GetFocus() == popup, "the described submenu opens without taking native focus");
    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> root;
    root.attach(CreateWindowHostAccessibilityProvider(child));
    Require(root != nullptr, "the described submenu publishes a UIA root");
    wil::com_ptr_nothrow<IRawElementProviderFragment> rootFragment;
    RequireSucceeded(root.query_to(rootFragment.put()), "the described submenu root navigates");
    wil::com_ptr_nothrow<IRawElementProviderFragment> command;
    RequireSucceeded(rootFragment->Navigate(NavigateDirection_FirstChild, command.put()), "the described submenu exposes its command row");
    Require(command != nullptr, "the described submenu command row exists");
    wil::com_ptr_nothrow<IRawElementProviderFragment> slider;
    RequireSucceeded(command->Navigate(NavigateDirection_NextSibling, slider.put()), "the described submenu exposes its slider row");
    Require(slider != nullptr, "the described submenu slider row exists");
    RequireSucceeded(slider->SetFocus(), "a screen reader can focus the submenu slider row");
    owner.PumpMessages();
    Require(! closed && IsWindow(popup) && IsWindow(child), "UIA focus of a submenu slider row keeps the asynchronous session open");
    Require(GetFocus() == popup, "UIA focus of a submenu slider row keeps native focus on the root popup");
    ContextMenuPopupDebugState state{};
    Require(DebugGetContextMenuPopupState(child, state) && state.keyboardIndex == 1u, "UIA focus tracks the submenu slider row logically");
    // Focusing the submenu popup itself (its root fragment) must not activate it either: activation would deactivate
    // the root popup and dismiss the whole asynchronous session.
    RequireSucceeded(rootFragment->SetFocus(), "a screen reader can focus the described submenu root");
    owner.PumpMessages();
    Require(! closed && IsWindow(popup) && IsWindow(child) && GetFocus() == popup,
            "UIA focus of a submenu root keeps the asynchronous session and native focus on the root popup");
}

class MenuRowFocusObserver final : public Microsoft::WRL::RuntimeClass<Microsoft::WRL::RuntimeClassFlags<Microsoft::WRL::ClassicCom>,
                                                                       IUIAutomationFocusChangedEventHandler,
                                                                       Microsoft::WRL::FtmBase>
{
public:
    std::atomic<unsigned int> firstRow{0};
    std::atomic<unsigned int> secondRow{0};
    HRESULT STDMETHODCALLTYPE HandleFocusChangedEvent(IUIAutomationElement* sender) noexcept override
    {
        // The name is cached with the event, so the handler never calls back into the provider's thread.
        wil::unique_bstr name;
        if (! sender || FAILED(sender->get_CachedName(name.put())) || ! name)
            return S_OK;
        const std::wstring_view rowName(name.get(), SysStringLen(name.get()));
        if (rowName == L"Première destination")
            firstRow.fetch_add(1);
        else if (rowName == L"Deuxième destination")
            secondRow.fetch_add(1);
        return S_OK;
    }
};

// Live bytes in every process heap: what the process still holds, independent of how much the heaps keep committed.
[[nodiscard, maybe_unused]] uint64_t MeasureLiveHeapBytesForMenuSuite()
{
    std::array<HANDLE, 128> heaps{};
    const DWORD count = GetProcessHeaps(static_cast<DWORD>(heaps.size()), heaps.data());
    Require(count > 0u && count <= heaps.size(), "enumerate the process heaps");
    uint64_t busy = 0u;
    for (DWORD index = 0u; index < count; ++index)
    {
        if (! HeapLock(heaps[index]))
            continue;
        const auto unlock = wil::scope_exit([&] { HeapUnlock(heaps[index]); });
        PROCESS_HEAP_ENTRY entry{};
        while (HeapWalk(heaps[index], &entry))
            if ((entry.wFlags & PROCESS_HEAP_ENTRY_BUSY) != 0u)
                busy += entry.cbData;
    }
    return busy;
}

// A described menu retains shaped layouts and accessibility proxies for every row while it is open; closing it must
// return them, even while a UI Automation client still holds one of its elements. DxUi's own live resources are counted
// exactly, so the check holds on every renderer and allocator. The process heap is printed for diagnosis only: a software
// renderer's surfaces and caches share it and swing by up to about 3 MB between identical open/close cycles.
void TestDescribedMenuReleasesItsMemoryWhenItCloses()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    std::vector<MenuFlyoutItem> items;
    for (int index = 0; index < 200; ++index)
        items.push_back(MenuFlyoutItem{.kind          = MenuItemKind::Standard,
                                       .text          = std::format(L"Archives photographiques {}", index),
                                       .commandId     = 9400 + index,
                                       .secondaryText = std::format(L"D:\\Sauvegardes\\Collection déjà présente\\Génération {}", index)});
    ContextMenuSessionCallbacks callbacks{};
    callbacks.maxRootHeightDip = 300.0f;
    struct Sample
    {
        ContextMenuResourceDebugState resources;
        uint64_t heapBytes = 0u; // Diagnostic only; AddressSanitizer serves allocations from pools a process-heap walk cannot see.
    };
    const auto sample = []
    {
        Sample taken{DebugGetContextMenuResources()};
#if ! defined(__SANITIZE_ADDRESS__)
        taken.heapBytes = MeasureLiveHeapBytesForMenuSuite();
#endif
        return taken;
    };
    const auto openAndClose = [&](bool holdElements, Sample* open)
    {
        bool closed        = false;
        const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "released menu anchor maps to screen");
        Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [&](std::optional<int>) noexcept { closed = true; }, callbacks),
                "described menu opens");
        const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
        Require(popup != nullptr, "described menu appears");
        WindowHostBitmapCapture capture{};
        Require(DebugCaptureContextMenuPopupBitmap(popup, capture), "described menu paints its rows");
        capture = {};
        std::vector<wil::com_ptr_nothrow<IRawElementProviderFragment>> heldRows;
        if (holdElements)
        {
            wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> root;
            root.attach(CreateWindowHostAccessibilityProvider(popup));
            wil::com_ptr_nothrow<IRawElementProviderFragment> row;
            Require(root && SUCCEEDED(root.query_to(row.put())), "a UI Automation client reaches the described menu");
            for (NavigateDirection direction = NavigateDirection_FirstChild; heldRows.size() < 8u; direction = NavigateDirection_NextSibling)
            {
                wil::com_ptr_nothrow<IRawElementProviderFragment> next;
                Require(SUCCEEDED(row->Navigate(direction, next.put())) && next, "a UI Automation client holds several described rows");
                heldRows.push_back(next);
                row = std::move(next);
            }
        }
        if (open)
            *open = sample();
        SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
        owner.PumpMessages();
        Require(closed && WaitForWindowDestroyed(popup, std::chrono::milliseconds(2000)), "described menu closes");
        owner.PumpMessages();
        return heldRows; // The caller keeps the elements past the close, as a screen reader may.
    };
    // Warm the fonts, the formats and the accessibility machinery once, so later samples see only the menu.
    static_cast<void>(openAndClose(true, nullptr));
    const Sample before = sample();
    Sample open;
    const auto heldRows = openAndClose(true, &open);
    const Sample closed = sample();
    const auto describe = [](const Sample& taken)
    {
        return std::format("{} popups, {} row layouts, {} accessibility records, {} heap bytes",
                           taken.resources.popups,
                           taken.resources.rowLayouts,
                           taken.resources.accessibilityRecords,
                           taken.heapBytes);
    };
    std::cout << "Described menu resources before: " << describe(before) << "; open: " << describe(open) << "; closed: " << describe(closed)
              << " (row elements still held " << heldRows.size() << "; heap bytes are diagnostic only)\n";
    Require(open.resources.popups > before.resources.popups, "an open described menu has a popup");
    Require(open.resources.rowLayouts >= before.resources.rowLayouts + items.size(), "a 200-row described menu holds a text layout per row while open");
    Require(open.resources.accessibilityRecords >= before.resources.accessibilityRecords + items.size(),
            "a 200-row described menu publishes an accessibility record per row while open");
    // Held elements must not pin what the menu held: everything is back to its value before the menu opened.
    Require(closed.resources.popups == before.resources.popups, "closing the described menu returns its popup, although a client still holds row elements");
    Require(closed.resources.rowLayouts == before.resources.rowLayouts,
            "closing the described menu returns its text layouts, although a client still holds row elements");
    Require(closed.resources.accessibilityRecords == before.resources.accessibilityRecords,
            "closing the described menu returns its accessibility records, although a client still holds row elements");
}

void TestDescribedMenuRaisesFocusChangesForKeyboardRows()
{
    using namespace DxUi;
    // Win32 focus stays on the session's root popup, so no system focus event reports a row change: the popup raises
    // UIA focus changes itself, or a screen reader cannot follow keyboard navigation through described rows.
    constexpr ULONGLONG kClientSetupAllowanceMs = 20000;
    constexpr ULONGLONG kNotificationDeadlineMs = 3000;
    AttachedHostWindow owner;
    wil::com_ptr_nothrow<MenuRowFocusObserver> observer;
    observer.attach(Microsoft::WRL::Make<MenuRowFocusObserver>().Detach());
    Require(observer != nullptr, "allocate the menu row focus observer");
    wil::unique_event stop(CreateEventW(nullptr, TRUE, FALSE, nullptr));
    Require(bool(stop), "create the UIA client stop event");
    std::atomic<bool> ready{false};
    std::atomic<bool> finished{false};
    std::atomic<HRESULT> setup{E_PENDING};
    std::atomic<const char*> setupStage{"initialize COM"};
    std::jthread client([&]
    {
        const HRESULT initialized = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        const auto uninitialize   = wil::scope_exit([&]
        {
            if (SUCCEEDED(initialized))
                CoUninitialize();
        });
        wil::com_ptr_nothrow<IUIAutomation> automation;
        wil::com_ptr_nothrow<IUIAutomationCacheRequest> cache;
        HRESULT hr = initialized;
        if (SUCCEEDED(hr))
        {
            setupStage.store("create UIA client");
            hr = CreateFocusAutomationClient(automation.put());
        }
        if (SUCCEEDED(hr))
        {
            setupStage.store("create cache request");
            hr = automation->CreateCacheRequest(cache.put());
        }
        if (SUCCEEDED(hr))
        {
            setupStage.store("cache row names");
            hr = cache->AddProperty(UIA_NamePropertyId);
        }
        if (SUCCEEDED(hr))
        {
            setupStage.store("subscribe focus changes");
            hr = automation->AddFocusChangedEventHandler(cache.get(), observer.get());
        }
        setup.store(hr);
        ready.store(true);
        if (SUCCEEDED(hr))
        {
            static_cast<void>(WaitForSingleObject(stop.get(), 15000));
            static_cast<void>(automation->RemoveFocusChangedEventHandler(observer.get()));
        }
        finished.store(true);
    });
    const auto waitUntil = [&](ULONGLONG timeoutMs, const auto& predicate)
    {
        const auto deadline = GetTickCount64() + timeoutMs;
        while (! predicate() && GetTickCount64() < deadline)
        {
            owner.PumpMessages();
            Sleep(1);
        }
        return predicate();
    };
    const auto stopClient = wil::scope_exit([&]() noexcept
    {
        SetEvent(stop.get());
        // The jthread joins after this without pumping, and the client's teardown may need this thread's providers to answer:
        // wait for it here, pumping, as long as its setup was allowed, and fail instead of hanging in the join.
        Require(waitUntil(kClientSetupAllowanceMs, [&] { return finished.load(); }), "the UIA focus client thread ends");
    });
    const bool subscribed = waitUntil(kClientSetupAllowanceMs, [&] { return ready.load(); });
    std::cout << std::format("    [UIA] setup ready={} stage={} HRESULT=0x{:08X}\n", subscribed, setupStage.load(), static_cast<unsigned long>(setup.load()));
    Require(subscribed && SUCCEEDED(setup.load()), "subscribe UIA focus changes");

    const std::vector<MenuFlyoutItem> items{
        {.text = L"Première", .commandId = 9201, .secondaryText = L"Archives familiales", .accessibleName = L"Première destination"},
        {.text = L"Deuxième", .commandId = 9202, .secondaryText = L"Collection du musée", .accessibleName = L"Deuxième destination"}};
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "described focus menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [](std::optional<int>) noexcept {}), "described focus menu opens");
    const auto dismiss = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(owner.Hwnd()); });
    const HWND popup   = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), L"Première");
    Require(popup != nullptr, "described focus menu appears");
    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> root;
    root.attach(CreateWindowHostAccessibilityProvider(popup));
    Require(root != nullptr, "described focus menu publishes its UIA root");
    wil::com_ptr_nothrow<IRawElementProviderFragment> rootFragment;
    RequireSucceeded(root.query_to(rootFragment.put()), "described focus menu root supports row navigation");
    wil::com_ptr_nothrow<IRawElementProviderFragment> firstRow;
    RequireSucceeded(rootFragment->Navigate(NavigateDirection_FirstChild, firstRow.put()), "the first described row is reachable");
    wil::com_ptr_nothrow<IRawElementProviderFragment> secondRow;
    RequireSucceeded(firstRow->Navigate(NavigateDirection_NextSibling, secondRow.put()), "the second described row is reachable");
    ContextMenuPopupDebugState state{};
    const auto requireRow = [&](size_t row, const char* context)
    {
        const bool alive = IsWindow(popup) != FALSE && DebugGetContextMenuPopupState(popup, state);
        if (! alive || state.keyboardIndex != row)
            std::cerr << "    [MENU] popupAlive=" << alive << " keyboardIndex=" << (state.keyboardIndex ? static_cast<long long>(*state.keyboardIndex) : -1)
                      << '\n';
        Require(alive && state.keyboardIndex == row, context);
    };
    // UIA SetFocus changes the menu's logical row while native focus stays on the popup. The posted focus
    // synchronization must announce that row too, then keyboard navigation continues to announce each target.
    unsigned int before = observer->secondRow.load();
    RequireSucceeded(secondRow->SetFocus(), "UIA can focus the second described row");
    requireRow(1u, "UIA SetFocus chooses the exact second described row");
    Require(waitUntil(kNotificationDeadlineMs, [&] { return observer->secondRow.load() > before; }),
            "a UIA client receives a focus change for the row SetFocus chose");
    before = observer->firstRow.load();
    SendMessageW(popup, WM_KEYDOWN, VK_HOME, 0);
    requireRow(0u, "the keyboard reaches the first described row");
    Require(waitUntil(kNotificationDeadlineMs, [&] { return observer->firstRow.load() > before; }),
            "a UIA client receives a focus change for the first described row");
    before = observer->secondRow.load();
    SendMessageW(popup, WM_KEYDOWN, VK_DOWN, 0);
    requireRow(1u, "the keyboard reaches the second described row");
    Require(waitUntil(kNotificationDeadlineMs, [&] { return observer->secondRow.load() > before; }),
            "a UIA client receives a focus change for the described row the keyboard reached");
}

// Win32 focus stays on a host window while Tab moves focus between its controls, so the host raises the UIA focus
// change itself or a screen reader stays silent. It runs in this activating suite because the window must hold focus.
void TestWindowHostTabRaisesAutomationFocusChanges()
{
    using namespace DxUi;
    AttachedHostWindow window;
    auto root       = std::make_unique<Panel>();
    auto* rootPanel = root.get();
    auto* first     = root->AddChild<Button>(L"Premier bouton");
    auto* second    = root->AddChild<Button>(L"Second bouton");
    first->SetBounds(D2D1::RectF(8.0f, 8.0f, 200.0f, 40.0f));
    second->SetBounds(D2D1::RectF(8.0f, 48.0f, 200.0f, 80.0f));
    window.Host().SetRoot(std::move(root));
    FocusEventClient client(window, window.Hwnd());
    const uint64_t announcedBefore = window.Host().DebugGetFocusAnnouncementCount();
    if (! TryActivateDxUiTestWindow(window.Hwnd()))
    {
        SkipDxUiTest("DxUi window-host UIA focus changes require an interactive desktop");
        return;
    }
    // Activation focuses the first button. Windows reports the window's new focus itself and UI Automation asks the
    // fragment root which element has it, so the client hears that button while the host adds no second event.
    Require(GetFocus() == window.Hwnd() && window.Host().GetFocusControl() == first, "activation focuses the first button");
    Require(client.WaitUntil(FocusEventClient::kNotificationDeadlineMs, [&] { return client.Count(L"Premier bouton") >= 1u; }),
            "a UIA client hears the control the window's activation focused");
    Require(window.Host().DebugGetFocusAnnouncementCount() == announcedBefore, "the host adds no announcement to the window's own focus event");

    SendMessageW(window.Hwnd(), WM_KEYDOWN, VK_TAB, 0);
    Require(window.Host().GetFocusControl() == second, "Tab moves focus to the second button");
    Require(client.WaitUntil(FocusEventClient::kNotificationDeadlineMs, [&] { return client.Count(L"Second bouton") >= 1u; }),
            "a UIA client receives a focus change for the control Tab reached");
    Require(window.Host().DebugGetFocusAnnouncementCount() == announcedBefore + 1u, "the host announces a focus move inside its focused window once");
    std::cout << "Window-host Tab focus change reached the UIA client (" << client.Count(L"Second bouton") << " event(s))\n";

    // With no control focused the window itself has focus, as GetFocus reports it, and a client hears the window by
    // its title. (The test window's class skips DefWindowProc at creation, so the title is set here.)
    Require(SetWindowTextW(window.Hwnd(), L"Essai de focus") != FALSE, "title the test window");
    window.Host().SetFocusControl(nullptr);
    const bool heardWindow = client.WaitUntil(FocusEventClient::kNotificationDeadlineMs, [&] { return client.Count(L"Essai de focus") >= 1u; });
    if (! heardWindow)
        client.PrintNames();
    Require(heardWindow, "a UIA client hears the window when no control has focus");

    // Removing the focused control (its panel clears its children) drops its focus at the host's next message, which
    // publishes it: the client hears the window then.
    window.Host().SetFocusControl(first);
    Require(client.WaitUntil(FocusEventClient::kNotificationDeadlineMs, [&] { return client.LastName() == L"Premier bouton"; }),
            "the client hears the first button again");
    client.Settle(); // UI Automation may deliver an earlier window event a second time; count only what follows.
    const size_t windowHeard = client.Count(L"Essai de focus");
    rootPanel->ClearChildren();
    Require(PostMessageW(window.Hwnd(), WM_NULL, 0, 0) != FALSE, "queue a message for the host");
    Require(client.WaitUntil(FocusEventClient::kNotificationDeadlineMs, [&] { return client.Count(L"Essai de focus") > windowHeard; }),
            "a UIA client hears the window once the focused control is removed");
    Require(window.Host().GetFocusControl() == nullptr, "the removed control no longer has focus");
}

// Arrow keys move focus between a tree's items while the tree control keeps it: the host announces the item, as
// GetFocus reports it, so a screen reader reads the row the keyboard reached rather than the whole tree again.
void TestWindowHostTreeArrowAnnouncesTheFocusedItem()
{
    using namespace DxUi;
    MutableTreeModel model;
    model.SetVisibleItems({TreeItemData{.id = 71u, .text = L"Alpha"}, TreeItemData{.id = 72u, .text = L"Beta"}});
    AttachedHostWindow window;
    auto root  = std::make_unique<Panel>();
    auto* tree = root->AddChild<Tree>();
    tree->SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 120.0f));
    tree->SetModel(&model);
    tree->SetSelectedItemId(71u);
    root->AddChild<Button>(L"Après")->SetBounds(D2D1::RectF(0.0f, 128.0f, 120.0f, 160.0f));
    window.Host().SetRoot(std::move(root));
    if (! TryActivateDxUiTestWindow(window.Hwnd()))
    {
        SkipDxUiTest("DxUi tree item UIA focus changes require an interactive desktop");
        return;
    }
    window.Host().SetFocusControl(tree);
    Require(window.Host().GetFocusControl() == tree, "the tree has focus");

    FocusEventClient client(window, window.Hwnd());
    SendMessageW(window.Hwnd(), WM_KEYDOWN, VK_DOWN, 0);
    Require(tree->GetSelectedItemId() == std::optional<uint64_t>{72u}, "Down moves the tree to its second item");
    Require(client.WaitUntil(FocusEventClient::kNotificationDeadlineMs, [&] { return client.Count(L"Beta") >= 1u; }),
            "a UIA client receives a focus change naming the tree item the keyboard reached");
}

// The same in a window the tree fills: the window's element stands for the tree and parents its items, so the focus change the
// host raises for the item the keyboard reached is raised on an element a client reaches from the window, which UI Automation
// delivers. (A window's only control had its items beside no element of the window's, and the event raised on them was lost.)
void TestWindowHostSingleTreeArrowAnnouncesTheFocusedItem()
{
    using namespace DxUi;
    MutableTreeModel model;
    model.SetVisibleItems({TreeItemData{.id = 71u, .text = L"Alpha"}, TreeItemData{.id = 72u, .text = L"Beta"}});
    AttachedHostWindow window;
    auto control = std::make_unique<Tree>();
    control->SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 120.0f));
    control->SetModel(&model);
    control->SetSelectedItemId(71u);
    Tree* const tree = control.get();
    window.Host().SetRoot(std::move(control));
    if (! TryActivateDxUiTestWindow(window.Hwnd()))
    {
        SkipDxUiTest("DxUi single-control tree item UIA focus changes require an interactive desktop");
        return;
    }
    window.Host().SetFocusControl(tree);
    Require(window.Host().GetFocusControl() == tree, "the tree has focus");

    FocusEventClient client(window, window.Hwnd());
    SendMessageW(window.Hwnd(), WM_KEYDOWN, VK_DOWN, 0);
    Require(tree->GetSelectedItemId() == std::optional<uint64_t>{72u}, "Down moves the tree to its second item");
    Require(client.WaitUntil(FocusEventClient::kNotificationDeadlineMs, [&] { return client.Count(L"Beta") >= 1u; }),
            "a UIA client receives a focus change naming the item of a tree that fills its window");
}

// Likewise for the rows of a grid that fills its window.
void TestWindowHostSingleGridArrowAnnouncesTheFocusedRow()
{
    using namespace DxUi;
    MultiRowGridModel model(3u);
    AttachedHostWindow window;
    auto control = std::make_unique<Grid>();
    control->SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 160.0f));
    control->SetModel(&model);
    Grid* const grid = control.get();
    window.Host().SetRoot(std::move(control));
    if (! TryActivateDxUiTestWindow(window.Hwnd()))
    {
        SkipDxUiTest("DxUi single-control grid row UIA focus changes require an interactive desktop");
        return;
    }
    window.Host().SetFocusControl(grid);
    Require(window.Host().GetFocusControl() == grid && grid->RequestSelectRow(0u, 0u), "the grid has focus and its first row is selected");

    FocusEventClient client(window, window.Hwnd());
    SendMessageW(window.Hwnd(), WM_KEYDOWN, VK_DOWN, 0);
    Require(grid->GetPrimarySelectedRow() == std::optional<size_t>{1u}, "Down moves the grid to its second row");
    Require(client.WaitUntil(FocusEventClient::kNotificationDeadlineMs, [&] { return client.Count(L"Row 01") >= 1u; }),
            "a UIA client receives a focus change naming the row of a grid that fills its window");
}

// An element's SetFocus in an inactive window focuses that element only: the host moves its logical focus before the
// window takes Win32 focus, so the activation neither focuses nor announces the window's first control on the way.
// (UIA's own client path first focuses the hosting window, which announces the window's current focus as a dialog's
// activation does; this provider call is what follows it, or what runs when that window focus did not happen.)
void TestWindowHostElementSetFocusAnnouncesOnlyThatElement()
{
    using namespace DxUi;
    AttachedHostWindow window;
    auto root    = std::make_unique<Panel>();
    auto* first  = root->AddChild<Button>(L"Premier bouton");
    auto* second = root->AddChild<Button>(L"Second bouton");
    first->SetBounds(D2D1::RectF(8.0f, 8.0f, 200.0f, 40.0f));
    second->SetBounds(D2D1::RectF(8.0f, 48.0f, 200.0f, 80.0f));
    window.Host().SetRoot(std::move(root));
    AttachedHostWindow elsewhere;
    elsewhere.Host().SetRoot(std::make_unique<Button>(L"Ailleurs"));
    if (! TryActivateDxUiTestWindow(window.Hwnd()) || ! TryActivateDxUiTestWindow(elsewhere.Hwnd()))
    {
        SkipDxUiTest("DxUi element SetFocus announcements require an interactive desktop");
        return;
    }
    // Activation focused the window's first control; a window a client reaches has usually lost that focus.
    window.Host().SetFocusControl(nullptr);
    Require(GetFocus() == elsewhere.Hwnd() && window.Host().GetFocusControl() == nullptr, "the window is inactive with no focused control");

    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> rootProvider;
    rootProvider.attach(CreateWindowHostAccessibilityProvider(window.Hwnd()));
    Require(rootProvider != nullptr, "the window exposes its fragment root");
    wil::com_ptr_nothrow<IRawElementProviderFragment> rootFragment;
    RequireSucceeded(rootProvider.query_to(rootFragment.put()), "the fragment root navigates");
    wil::com_ptr_nothrow<IRawElementProviderFragment> firstElement;
    RequireSucceeded(rootFragment->Navigate(NavigateDirection_FirstChild, firstElement.put()), "reach the first button's element");
    Require(firstElement != nullptr, "the first button has an element");
    wil::com_ptr_nothrow<IRawElementProviderFragment> secondElement;
    RequireSucceeded(firstElement->Navigate(NavigateDirection_NextSibling, secondElement.put()), "reach the second button's element");
    Require(secondElement != nullptr, "the second button has an element");

    FocusEventClient client(window, window.Hwnd());
    RequireSucceeded(secondElement->SetFocus(), "the second button's element takes focus");
    Require(window.Host().GetFocusControl() == second && GetFocus() == window.Hwnd(), "the second button has focus in the now focused window");
    Require(client.WaitUntil(FocusEventClient::kNotificationDeadlineMs, [&] { return client.Count(L"Second bouton") >= 1u; }),
            "a client hears the element that took focus");
    client.Settle();
    Require(client.Count(L"Premier bouton") == 0u, "a client never hears the first control, which never had focus");

    // The same request through UIA: it focuses the hosting window first, so a client may hear that window's current
    // focus on the way, but the element it asked for is the one it hears last.
    Require(TryActivateDxUiTestWindow(elsewhere.Hwnd()), "the other window is active again");
    window.Host().SetFocusControl(nullptr);
    const size_t heardBefore = client.Count(L"Second bouton");
    RequireSucceeded(client.FocusElementNamed(L"Second bouton"), "a UIA client focuses the second button");
    Require(window.Host().GetFocusControl() == second, "the second button has focus again");
    Require(client.WaitUntil(FocusEventClient::kNotificationDeadlineMs, [&] { return client.Count(L"Second bouton") > heardBefore; }),
            "the UIA client hears the element it focused");
    client.Settle();
    Require(client.LastName() == L"Second bouton", "the element a UIA client focused is the last one it hears");
}

// Two buttons in a window, another window to take the foreground from it and a UI Automation client that hears focus:
// what the tests of the click that activates a window play. The click is played as Windows plays it (the window is
// activated, then its button-down arrives before the message loop turns) without real input. A scenario is one attempt of
// RunUntilForegroundHeld, with windows of its own: another application that takes the foreground from one of them
// explains any failure, so its expectations record the first that fails instead of ending the test, and the attempt that
// kept the foreground decides it (FinishActivatingClickTest).
class ActivatingClickScenario final
{
public:
    ActivatingClickScenario()
    {
        auto root = std::make_unique<DxUi::Panel>();
        first     = root->AddChild<DxUi::Button>(L"Premier bouton");
        second    = root->AddChild<DxUi::Button>(L"Second bouton");
        first->SetBounds(D2D1::RectF(8.0f, 8.0f, 200.0f, 40.0f));
        second->SetBounds(D2D1::RectF(8.0f, 48.0f, 200.0f, 80.0f));
        window.Host().SetRoot(std::move(root));
        elsewhere.Host().SetRoot(std::make_unique<DxUi::Button>(L"Ailleurs"));
    }

    // False without an interactive desktop.
    [[nodiscard]] bool ActivateForTheFirstTime() const
    {
        return TryActivateDxUiTestWindow(elsewhere.Hwnd()) && TryActivateDxUiTestWindow(window.Hwnd());
    }

    // An activation alone: the system's event is the only report, and this is how often the client hears one.
    [[nodiscard]] size_t HearAnActivation()
    {
        Expect(GetFocus() == window.Hwnd() && window.Host().GetFocusControl() == first, "activation focuses the first button");
        Expect(Hears([&] { return client.Count(L"Premier bouton") >= 1u; }), "a UIA client hears the control an activation focused");
        client.Settle();
        return client.Count(L"Premier bouton");
    }

    // Another window takes the foreground and this window's focus is cleared, so that its next activation focuses the
    // first button on the way.
    void TakeTheForegroundAway()
    {
        Expect(TryActivateDxUiTestWindow(elsewhere.Hwnd()), "another window takes the foreground");
        window.Host().SetFocusControl(nullptr);
        client.Settle();
    }

    // The button-down and button-up at the center of the control, without a message pumped in between.
    void Click(const DxUi::Control& control)
    {
        const D2D1_RECT_F bounds = control.GetBounds();
        const LPARAM point       = MAKELPARAM(static_cast<WORD>(std::lround(window.Host().DipsToPixels((bounds.left + bounds.right) / 2.0f))),
                                              static_cast<WORD>(std::lround(window.Host().DipsToPixels((bounds.top + bounds.bottom) / 2.0f))));
        SendMessageW(window.Hwnd(), WM_LBUTTONDOWN, MK_LBUTTON, point);
        SendMessageW(window.Hwnd(), WM_LBUTTONUP, 0, point);
    }

    // Records the first expectation that fails, naming what the client heard, and returns the condition: the test fails on
    // it only when the attempt kept the foreground.
    bool Expect(bool condition, const char* message)
    {
        if (! condition && _failure.empty())
        {
            client.PrintNames();
            _failure = message;
        }
        return condition;
    }

    // Waits until the client hears what `predicate` looks for, unless the attempt has failed already or another application
    // took the foreground from one of its windows: a host whose window lost the foreground announces nothing, and waiting
    // for each announcement of a lost attempt would only delay the next one.
    template <typename Predicate> [[nodiscard]] bool Hears(const Predicate& predicate) const
    {
        return _failure.empty() && ! Foreground().lost && client.WaitUntil(FocusEventClient::kNotificationDeadlineMs, predicate);
    }

    // Another window of the test whose foreground this attempt answers for as well.
    void Watch(const AttachedHostWindow& other)
    {
        _watched.push_back(&other);
    }

    // What this attempt found about the foreground of its windows, which are new with it, so any loss is this attempt's.
    [[nodiscard]] ForegroundAttempt Foreground() const
    {
        ForegroundAttempt result{};
        const auto note = [&](const AttachedHostWindow& watched)
        {
            if (watched.ForegroundLossCount() == 0u)
                return;
            result.lost          = true;
            result.thiefThreadId = watched.LastForegroundThiefThreadId();
        };
        note(window);
        note(elsewhere);
        for (const AttachedHostWindow* watched : _watched)
            note(*watched);
        return result;
    }

    [[nodiscard]] const std::string& Failure() const noexcept
    {
        return _failure;
    }

    AttachedHostWindow window;
    AttachedHostWindow elsewhere;
    DxUi::Button* first  = nullptr;
    DxUi::Button* second = nullptr;
    FocusEventClient client{window, window.Hwnd()}; // After the window it pumps.

private:
    std::string _failure;
    std::vector<const AttachedHostWindow*> _watched;
};

// Plays a test of the click that activates a window as attempts of RunUntilForegroundHeld. `play(scenario, desktop)` plays
// one attempt on a new scenario, clears `desktop` when no window could be activated at all, and returns
// scenario.Foreground() while the windows it watches are alive. The test is skipped without an interactive desktop (an
// attempt that kept the foreground but activated nothing), or naming who took the foreground in every attempt; otherwise
// it fails on the first expectation that failed in the attempt that kept it.
template <typename Play> void PlayActivatingClickTest(const char* noDesktopReason, const char* what, Play&& play)
{
    bool desktop = true;
    std::string failure;
    const ForegroundRunResult run = RunUntilForegroundHeld([&]
    {
        ActivatingClickScenario scenario;
        desktop                            = true;
        const ForegroundAttempt foreground = play(scenario, desktop);
        failure                            = scenario.Failure();
        return foreground;
    });
    if (run.held && ! desktop)
    {
        SkipDxUiTest(noDesktopReason);
        return;
    }
    if (! ForegroundHeldOrSkip(run, what))
        return;
    Require(failure.empty(), failure.c_str());
}

// UI Automation answers the first focus event of a window it has not seen with a call of the fragment root's GetFocus, and
// its later ones by asking the window's root element whether it has the keyboard focus, which reports nothing while the
// focus is inside a control. The click that activates a window moves focus before UI Automation has acted on the event (it
// sets its control after the window's WM_SETFOCUS, in the same turn of its message loop), so for a window UI Automation
// has seen nothing else reports the clicked control and the host must announce it: a client hears it once, as it hears any
// control the host announces, and last.
void TestWindowHostClickThatActivatesAWindowUiAutomationHasAskedBeforeAnnouncesTheClickedControlOnce()
{
    using namespace DxUi;
    PlayActivatingClickTest("DxUi click activation announcements require an interactive desktop",
                            "a click that activates a window UI Automation has asked before",
                            [](ActivatingClickScenario& scenario, bool& desktop)
    {
        if (! scenario.ActivateForTheFirstTime())
        {
            desktop = false;
            return scenario.Foreground();
        }
        ControlHost& host = scenario.window.Host();
        // The window's first activation: UI Automation asks its fragment root for the focus, and knows the window from then on.
        static_cast<void>(scenario.HearAnActivation());
        scenario.Expect(DebugGetAccessibilityFocusResolutionCountForTest(scenario.window.Hwnd()) >= 1u,
                        "UI Automation asked the window's fragment root for its focus");

        // How often a client hears a focus event the host raises, from moves in the active window.
        const size_t secondHeardBefore            = scenario.client.Count(L"Second bouton");
        const uint64_t announcedBeforeCalibrating = host.DebugGetFocusAnnouncementCount();
        host.SetFocusControl(scenario.second);
        scenario.Expect(host.DebugGetFocusAnnouncementCount() == announcedBeforeCalibrating + 1u, "the host announces a move in the active window once");
        scenario.Expect(scenario.Hears([&] { return scenario.client.Count(L"Second bouton") > secondHeardBefore; }),
                        "a UIA client hears a control the host announces");
        scenario.client.Settle();
        const size_t heardPerHostEvent = scenario.client.Count(L"Second bouton") - secondHeardBefore;
        const size_t firstHeardBefore  = scenario.client.Count(L"Premier bouton");
        host.SetFocusControl(scenario.first);
        scenario.Expect(scenario.Hears([&] { return scenario.client.Count(L"Premier bouton") > firstHeardBefore; }),
                        "a UIA client hears the control the host announces next");
        scenario.client.Settle();

        // Another window takes the foreground and the click reaches this one: activation first, then the button-down, with no
        // message pumped in between.
        scenario.TakeTheForegroundAway();
        const size_t secondHeardAtClick = scenario.client.Count(L"Second bouton");
        const uint64_t announcedBefore  = host.DebugGetFocusAnnouncementCount();
        const uint64_t leftBefore       = host.DebugGetFocusMovesLeftToSystemCount();
        scenario.Expect(TryActivateDxUiTestWindow(scenario.window.Hwnd()) && GetFocus() == scenario.window.Hwnd(), "the click activates the window");
        scenario.Expect(host.GetFocusControl() == scenario.first, "the activation focuses the first button on the way");
        scenario.Expect(host.DebugIsInFocusGainTurn(), "the activation's turn is still running when the click arrives");
        scenario.Click(*scenario.second);
        scenario.Expect(host.GetFocusControl() == scenario.second, "the click focuses the clicked button");
        scenario.Expect(host.DebugGetFocusMovesLeftToSystemCount() == leftBefore,
                        "the host leaves nothing to an event UI Automation answers from what it knows of the window");
        scenario.Expect(host.DebugGetFocusAnnouncementCount() == announcedBefore + 1u, "the host announces the click once");
        scenario.Expect(scenario.Hears([&] { return scenario.client.Count(L"Second bouton") > secondHeardAtClick; }), "a UIA client hears the clicked button");
        scenario.client.Settle();
        scenario.Expect(scenario.client.Count(L"Second bouton") - secondHeardAtClick == heardPerHostEvent,
                        "a client hears the clicked button once, as it hears any control the host announces");
        scenario.Expect(scenario.client.LastName() == L"Second bouton", "the clicked button is the last control the client hears");
        return scenario.Foreground();
    });
}

// A window UI Automation has seen answers its later focus events from the root element's keyboard-focus property, which
// reports nothing while the focus is inside a control, so activating such a window again (Alt+Tab back to it) is reported
// by nothing but the host: it announces the control the activation restored, or the one it focused, once the turn of the
// gain ends, and a client hears that control once, as it hears any control the host announces.
void TestWindowHostReactivatingAWindowUiAutomationHasSeenAnnouncesItsFocusedControlOnce()
{
    using namespace DxUi;
    PlayActivatingClickTest("DxUi reactivation announcements require an interactive desktop",
                            "the reactivation of a window UI Automation has seen",
                            [](ActivatingClickScenario& scenario, bool& desktop)
    {
        if (! scenario.ActivateForTheFirstTime())
        {
            desktop = false;
            return scenario.Foreground();
        }
        ControlHost& host = scenario.window.Host();
        static_cast<void>(scenario.HearAnActivation());
        scenario.Expect(DebugGetAccessibilityFocusResolutionCountForTest(scenario.window.Hwnd()) >= 1u,
                        "UI Automation asked the window's fragment root for its focus");

        // How often a client hears a focus event the host raises, from a move in the active window.
        const size_t secondHeardBefore = scenario.client.Count(L"Second bouton");
        host.SetFocusControl(scenario.second);
        scenario.Expect(scenario.Hears([&] { return scenario.client.Count(L"Second bouton") > secondHeardBefore; }),
                        "a UIA client hears a control the host announces");
        scenario.client.Settle();
        const size_t heardPerHostEvent = scenario.client.Count(L"Second bouton") - secondHeardBefore;

        // Another window takes the foreground while the second button keeps its logical focus, and the window comes back.
        scenario.Expect(TryActivateDxUiTestWindow(scenario.elsewhere.Hwnd()), "another window takes the foreground");
        scenario.client.Settle();
        const size_t secondHeardAtReturn = scenario.client.Count(L"Second bouton");
        const size_t firstHeardAtReturn  = scenario.client.Count(L"Premier bouton");
        const uint64_t announcedBefore   = host.DebugGetFocusAnnouncementCount();
        scenario.Expect(TryActivateDxUiTestWindow(scenario.window.Hwnd()) && GetFocus() == scenario.window.Hwnd(), "the window is activated again");
        scenario.Expect(host.GetFocusControl() == scenario.second, "the activation restores the second button");
        scenario.window.PumpMessages();
        scenario.Expect(host.DebugGetFocusAnnouncementCount() == announcedBefore + 1u, "the host announces the restored button once the gain's turn ends");
        scenario.Expect(scenario.Hears([&] { return scenario.client.Count(L"Second bouton") > secondHeardAtReturn; }),
                        "a UIA client hears the restored button");
        scenario.client.Settle();
        scenario.Expect(scenario.client.Count(L"Second bouton") - secondHeardAtReturn == heardPerHostEvent,
                        "a client hears the restored button once, as it hears any control the host announces");
        scenario.Expect(scenario.client.Count(L"Premier bouton") == firstHeardAtReturn, "and no other control of the window");
        scenario.Expect(scenario.client.LastName() == L"Second bouton", "the restored button is the last control the client hears");

        // A window whose focus was cleared: the activation focuses the first button on the way, announced the same way.
        scenario.TakeTheForegroundAway();
        const size_t firstHeardBefore = scenario.client.Count(L"Premier bouton");
        const uint64_t announcedAgain = host.DebugGetFocusAnnouncementCount();
        scenario.Expect(TryActivateDxUiTestWindow(scenario.window.Hwnd()) && GetFocus() == scenario.window.Hwnd(), "the window is activated once more");
        scenario.Expect(host.GetFocusControl() == scenario.first, "the activation focuses the first button");
        scenario.window.PumpMessages();
        scenario.Expect(host.DebugGetFocusAnnouncementCount() == announcedAgain + 1u, "the host announces the button the activation focused");
        scenario.Expect(scenario.Hears([&] { return scenario.client.Count(L"Premier bouton") > firstHeardBefore; }),
                        "a UIA client hears the button the activation focused");
        scenario.client.Settle();
        scenario.Expect(scenario.client.Count(L"Premier bouton") - firstHeardBefore == heardPerHostEvent,
                        "a client hears the button the activation focused once");
        return scenario.Foreground();
    });
}

// For a window UI Automation has not seen, the call of the fragment root's GetFocus that answers the first focus event
// reads the snapshot when it runs. When it has not got as far as counting itself by the time the click moves focus, it reads
// the clicked control: the host adds no announcement, and the client hears the clicked control once, as it hears the control
// of a first activation, and never the control the activation focused on the way. The test gate holds the call before it
// counts itself, which is how a slow UI Automation looks from the window.
void TestWindowHostClickThatActivatesAWindowUiAutomationHasNotSeenLeavesTheClickedControlToItsFirstGetFocus()
{
    using namespace DxUi;
    PlayActivatingClickTest("DxUi click activation announcements require an interactive desktop",
                            "a click that activates a window UI Automation has not seen",
                            [](ActivatingClickScenario& scenario, bool& desktop)
    {
        // A window like the one under test, to learn how often a client hears the answer to a first activation.
        AttachedHostWindow reference;
        auto referenceTree   = std::make_unique<Panel>();
        auto* referenceFirst = referenceTree->AddChild<Button>(L"Etalon un");
        referenceFirst->SetBounds(D2D1::RectF(8.0f, 8.0f, 200.0f, 40.0f));
        referenceTree->AddChild<Button>(L"Etalon deux")->SetBounds(D2D1::RectF(8.0f, 48.0f, 200.0f, 80.0f));
        reference.Host().SetRoot(std::move(referenceTree));
        scenario.Watch(reference);
        if (! TryActivateDxUiTestWindow(scenario.elsewhere.Hwnd()))
        {
            desktop = false;
            return scenario.Foreground();
        }
        scenario.client.Settle();
        scenario.Expect(TryActivateDxUiTestWindow(reference.Hwnd()) && GetFocus() == reference.Hwnd() && reference.Host().GetFocusControl() == referenceFirst,
                        "the reference window's first activation focuses its first button");
        scenario.Expect(scenario.Hears([&] { return scenario.client.Count(L"Etalon un") >= 1u; }), "a UIA client hears the control a first activation focused");
        scenario.client.Settle();
        const size_t heardPerSystemEvent = scenario.client.Count(L"Etalon un");
        scenario.Expect(TryActivateDxUiTestWindow(scenario.elsewhere.Hwnd()), "another window takes the foreground");
        scenario.client.Settle();

        ControlHost& host              = scenario.window.Host();
        const size_t firstHeardBefore  = scenario.client.Count(L"Premier bouton");
        const size_t secondHeardBefore = scenario.client.Count(L"Second bouton");
        const uint64_t announcedBefore = host.DebugGetFocusAnnouncementCount();
        const uint64_t leftBefore      = host.DebugGetFocusMovesLeftToSystemCount();
        wil::unique_event entered(CreateEventW(nullptr, TRUE, FALSE, nullptr));
        wil::unique_event release(CreateEventW(nullptr, TRUE, FALSE, nullptr));
        scenario.Expect(entered && release, "create the gate events");
        DebugSetAccessibilityFocusResolutionGateForTest(scenario.window.Hwnd(), entered.get(), release.get());
        const auto clearGate = wil::scope_exit([&]() noexcept
        {
            static_cast<void>(SetEvent(release.get()));
            DebugSetAccessibilityFocusResolutionGateForTest(nullptr, nullptr, nullptr);
        });

        // The click reaches the window's first activation: activation first, then the button-down before the loop turns,
        // with UI Automation's call held. Nothing has asked the fragment root for the focus.
        scenario.Expect(TryActivateDxUiTestWindow(scenario.window.Hwnd()) && GetFocus() == scenario.window.Hwnd(), "the click activates the window");
        scenario.Expect(host.GetFocusControl() == scenario.first, "the activation focuses the first button on the way");
        scenario.Expect(host.DebugIsInFocusGainTurn(), "the activation's turn is still running when the click arrives");
        scenario.Click(*scenario.second);
        scenario.Expect(host.GetFocusControl() == scenario.second, "the click focuses the clicked button");
        scenario.Expect(host.DebugGetFocusAnnouncementCount() == announcedBefore, "the host adds no announcement to an event that nothing has answered");
        scenario.Expect(host.DebugGetFocusMovesLeftToSystemCount() == leftBefore + 1u, "the host leaves the click's move to that event");

        // UI Automation reaches the gate when it does, before or after the click; released, its call reads the clicked
        // control.
        scenario.Expect(scenario.Hears([&] { return WaitForSingleObject(entered.get(), 0) == WAIT_OBJECT_0; }),
                        "UI Automation asks the fragment root for the focus to answer the window's first focus event");
        scenario.Expect(SetEvent(release.get()) != FALSE, "release the held call");
        scenario.Expect(scenario.Hears([&] { return scenario.client.Count(L"Second bouton") > secondHeardBefore; }), "a UIA client hears the clicked button");
        scenario.client.Settle();
        scenario.Expect(scenario.client.Count(L"Second bouton") - secondHeardBefore == heardPerSystemEvent,
                        "a client hears the clicked button as often as it hears the control of a first activation");
        scenario.Expect(scenario.client.Count(L"Premier bouton") == firstHeardBefore, "a client never hears the button the activation focused on the way");
        scenario.Expect(host.DebugGetFocusAnnouncementCount() == announcedBefore, "the host announced nothing while it left the move to the system's event");
        return scenario.Foreground();
    });
}

// Focus that moves in a window which has just lost the foreground is not announced. Until its thread processes the
// deactivation, Win32 still reports that window as focused (GetFocus), as when a queued message moves focus right after
// the user switched to another application. A screen reader follows the foreground, so the host announces only while
// its window holds the foreground's keyboard focus.
void TestWindowHostThatLostTheForegroundAnnouncesNoFocusChange()
{
    using namespace DxUi;
    AttachedHostWindow window;
    auto root    = std::make_unique<Panel>();
    auto* first  = root->AddChild<Button>(L"Premier bouton");
    auto* second = root->AddChild<Button>(L"Second bouton");
    first->SetBounds(D2D1::RectF(8.0f, 8.0f, 200.0f, 40.0f));
    second->SetBounds(D2D1::RectF(8.0f, 48.0f, 200.0f, 80.0f));
    window.Host().SetRoot(std::move(root));
    if (! TryActivateDxUiTestWindow(window.Hwnd()))
    {
        SkipDxUiTest("DxUi foreground focus announcements require an interactive desktop");
        return;
    }
    window.Host().SetFocusControl(first);

    FocusEventClient client(window, window.Hwnd());
    // The window that takes the foreground belongs to another thread, which activates it as another application's
    // would: this thread only learns of its deactivation when it next processes messages.
    wil::unique_event foregroundReady(CreateEventW(nullptr, TRUE, FALSE, nullptr));
    wil::unique_event foregroundStop(CreateEventW(nullptr, TRUE, FALSE, nullptr));
    Require(foregroundReady && foregroundStop, "create the foreground thread events");
    std::atomic<HWND> foreground{nullptr};
    std::jthread foregroundThread([&]
    {
        static constexpr wchar_t kClassName[] = L"DxUiTests.ForegroundThreadWindow";
        WNDCLASSEXW windowClass{};
        windowClass.cbSize        = sizeof(windowClass);
        windowClass.lpfnWndProc   = DefWindowProcW;
        windowClass.hInstance     = GetModuleHandleW(nullptr);
        windowClass.lpszClassName = kClassName;
        static_cast<void>(RegisterClassExW(&windowClass));
        wil::unique_hwnd hwnd(CreateWindowExW(
            0u, kClassName, L"DxUiTests foreground", WS_OVERLAPPED | WS_VISIBLE, -32000, -32000, 200, 120, nullptr, nullptr, windowClass.hInstance, nullptr));
        static_cast<void>(SetForegroundWindow(hwnd.get()));
        foreground.store(hwnd.get());
        SetEvent(foregroundReady.get());
        const HANDLE stopHandle = foregroundStop.get();
        while (MsgWaitForMultipleObjects(1u, &stopHandle, FALSE, 30000u, QS_ALLINPUT) == WAIT_OBJECT_0 + 1u)
        {
            MSG message{};
            while (PeekMessageW(&message, nullptr, 0u, 0u, PM_REMOVE) != FALSE)
            {
                TranslateMessage(&message);
                DispatchMessageW(&message);
            }
        }
    });
    const auto stopForeground = wil::scope_exit([&]() noexcept { SetEvent(foregroundStop.get()); });
    Require(WaitForSingleObject(foregroundReady.get(), 5000u) == WAIT_OBJECT_0 && foreground.load() != nullptr, "create a window on another thread");

    // No pumping here: this thread must not process its deactivation before the focus move below.
    const ULONGLONG foregroundDeadline = GetTickCount64() + 2000u;
    while (GetForegroundWindow() != foreground.load() && GetTickCount64() < foregroundDeadline)
        Sleep(10);
    if (GetForegroundWindow() != foreground.load() || GetFocus() != window.Hwnd())
    {
        std::cerr << "    [FOCUS] foreground=" << (GetForegroundWindow() == foreground.load()) << " threadFocus=" << (GetFocus() == window.Hwnd()) << '\n';
        SkipDxUiTest("DxUi foreground focus announcements need the other thread's window in the foreground");
        return;
    }

    window.Host().SetFocusControl(second);
    Require(window.Host().GetFocusControl() == second, "focus moves to the second button after the window lost the foreground");
    client.Settle();
    Require(client.Count(L"Second bouton") == 0u, "a window that lost the foreground announces no focus change");

    Require(TryActivateDxUiTestWindow(window.Hwnd()), "the window returns to the foreground");
    client.Settle(); // The message loop turns and the activation's own event is resolved: the move below is the host's to announce.
    window.Host().SetFocusControl(first);
    Require(client.WaitUntil(FocusEventClient::kNotificationDeadlineMs, [&] { return client.Count(L"Premier bouton") >= 1u; }),
            "the same window in the foreground announces its focus change");
}

// While the menu holds capture Windows sends no WM_SETCURSOR, so a cursor the window had set (a resize or text cursor)
// would stay over the menu. The menu shows the arrow over its popups and lets a window of its thread under the pointer
// choose its own cursor outside them.
void TestMenuPointerCursorIsArrowOverPopupsAndTheWindowsOwnOutside()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    SetWindowPos(owner.Hwnd(), nullptr, 100, 100, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(owner.Hwnd(), SW_SHOWNOACTIVATE);
    owner.PumpMessages();
    // A window of this thread whose class cursor is the text cursor, below the owner and clear of the menu.
    static constexpr wchar_t kTextWindowClass[] = L"DxUiTests.MenuCursorTextWindow";
    WNDCLASSEXW textClass{};
    textClass.cbSize        = sizeof(textClass);
    textClass.lpfnWndProc   = DefWindowProcW;
    textClass.hInstance     = GetModuleHandleW(nullptr);
    textClass.hCursor       = LoadCursorW(nullptr, IDC_IBEAM);
    textClass.lpszClassName = kTextWindowClass;
    Require(RegisterClassExW(&textClass) != 0 || GetLastError() == ERROR_CLASS_ALREADY_EXISTS, "register the text-cursor window class");
    wil::unique_hwnd textWindow(CreateWindowExW(
        WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW, kTextWindowClass, L"", WS_POPUP | WS_VISIBLE, 100, 520, 240, 120, nullptr, nullptr, textClass.hInstance, nullptr));
    Require(textWindow != nullptr, "create the text-cursor window");
    owner.PumpMessages();

    const HCURSOR arrow      = LoadCursorW(nullptr, IDC_ARROW);
    const HCURSOR textCursor = LoadCursorW(nullptr, IDC_IBEAM);
    const HCURSOR resize     = LoadCursorW(nullptr, IDC_SIZEWE);
    const std::vector<MenuFlyoutItem> items{{.text = L"Ouvrir", .commandId = 9301}, {.text = L"Fermer", .commandId = 9302}};
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "cursor menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [](std::optional<int>) noexcept {}), "cursor menu opens");
    const auto dismiss = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(owner.Hwnd()); });
    const HWND popup   = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), L"Ouvrir");
    Require(popup != nullptr, "cursor menu appears");
    owner.PumpMessages();

    RECT popupRect{};
    RECT textRect{};
    Require(GetWindowRect(popup, &popupRect) != FALSE && GetWindowRect(textWindow.get(), &textRect) != FALSE, "read the menu and text window rectangles");
    const POINT overMenu{(popupRect.left + popupRect.right) / 2, popupRect.top + 14};
    const POINT overText{(textRect.left + textRect.right) / 2, (textRect.top + textRect.bottom) / 2};
    if (WindowFromPoint(overMenu) != popup || WindowFromPoint(overText) != textWindow.get())
    {
        SkipDxUiTest("another window covers the menu cursor test windows");
        return;
    }
    SetCursor(resize); // The window's own cursor when the pointer reaches the menu.
    static_cast<void>(SendCapturedMouseMessageForMenuSuite(popup, WM_MOUSEMOVE, 0, overMenu));
    Require(GetCursor() == arrow, "the arrow shows over the menu whatever cursor the window had set");
    static_cast<void>(SendCapturedMouseMessageForMenuSuite(popup, WM_MOUSEMOVE, 0, overText));
    owner.PumpMessages(); // The forward is posted, so no window's WM_SETCURSOR runs inside a menu handler.
    Require(GetCursor() == textCursor, "outside the menu the window under the pointer chooses its own cursor");
    static_cast<void>(SendCapturedMouseMessageForMenuSuite(popup, WM_MOUSEMOVE, 0, overMenu));
    Require(GetCursor() == arrow, "the arrow shows again when the pointer returns to the menu");
    std::cout << "Menu pointer cursor: the arrow over the menu, the window's own cursor outside it\n";
}

// Opening a menu chooses the cursor at the pointer at once: the window under it keeps its own cursor, where a cursor
// set before the menu took capture (a resize cursor at the owner's edge) would otherwise stay, since a captured pointer
// sends no WM_SETCURSOR. Closing lets that window choose again after the arrow shown over the menu. The physical
// cursor is placed over that window for the test and restored afterwards.
//
// The menu activates its popup, and an application that takes the foreground from it dismisses the menu as designed:
// the desktop application hosting a developer's session takes it back tens of milliseconds after a test window
// activates, and under AddressSanitizer that can land before the test has read the popup. Each attempt therefore plays
// the whole sequence with windows of its own under RunUntilForegroundHeld and records its first failed expectation; the
// attempt whose owner kept the foreground decides, so a regression still fails, and every attempt puts the cursor back.
void TestMenuChoosesTheCursorWhenItOpensAndCloses()
{
    using namespace DxUi;
    if (! DxUiTestWindowsCanActivateFlag())
    {
        SkipDxUiTest("the menu open-and-close cursor test moves the physical pointer and is limited to the interactive Menu lane");
        return;
    }

    static constexpr wchar_t kTextWindowClass[] = L"DxUiTests.MenuCursorTextWindow";
    WNDCLASSEXW textClass{};
    textClass.cbSize        = sizeof(textClass);
    textClass.lpfnWndProc   = DefWindowProcW;
    textClass.hInstance     = GetModuleHandleW(nullptr);
    textClass.hCursor       = LoadCursorW(nullptr, IDC_IBEAM);
    textClass.lpszClassName = kTextWindowClass;
    Require(RegisterClassExW(&textClass) != 0 || GetLastError() == ERROR_CLASS_ALREADY_EXISTS, "register the text-cursor window class");

    std::string skip;
    std::string failure;
    const ForegroundRunResult run = RunUntilForegroundHeld([&]() -> ForegroundAttempt
    {
        failure.clear();
        AttachedHostWindow owner;
        SetWindowPos(owner.Hwnd(), nullptr, 100, 100, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
        ShowWindow(owner.Hwnd(), SW_SHOWNOACTIVATE);
        owner.PumpMessages();
        wil::unique_hwnd textWindow(CreateWindowExW(WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW,
                                                    kTextWindowClass,
                                                    L"",
                                                    WS_POPUP | WS_VISIBLE,
                                                    100,
                                                    520,
                                                    240,
                                                    120,
                                                    nullptr,
                                                    nullptr,
                                                    textClass.hInstance,
                                                    nullptr));
        Require(textWindow != nullptr, "create the text-cursor window");
        // The physical cursor must meet this window, whatever else is on the desktop; it is never activated.
        Require(SetWindowPos(textWindow.get(), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE) != FALSE, "raise the text-cursor window");
        owner.PumpMessages();
        RECT textRect{};
        Require(GetWindowRect(textWindow.get(), &textRect) != FALSE, "read the text-cursor window rectangle");
        const POINT overText{(textRect.left + textRect.right) / 2, (textRect.top + textRect.bottom) / 2};
        if (WindowFromPoint(overText) != textWindow.get())
        {
            skip = "another window covers the menu cursor test window";
            return ForegroundAttempt{};
        }
        ScopedMenuPointerFixture pointer(owner.Hwnd());
        if (! pointer.AlignCursor(overText))
        {
            skip = "the menu open-and-close cursor test places the physical cursor";
            return ForegroundAttempt{};
        }
        // Let the moves the placement generated arrive before the owner's own cursor is set.
        for (int round = 0; round < 5; ++round)
        {
            owner.PumpMessages();
            Sleep(10);
        }

        // The owner is new with this attempt, so a foreground it lost was lost during it. An attempt whose expectation failed
        // also says who held the foreground then, so a failure that no takeover explains shows what the test saw.
        const auto finish = [&]
        {
            if (! failure.empty())
            {
                const HWND holder = GetForegroundWindow();
                std::cerr << "    [MENU CURSOR] " << failure << "; the owner lost the foreground " << owner.ForegroundLossCount() << " time(s), and "
                          << (holder ? DescribeThreadProcessForTest(GetWindowThreadProcessId(holder, nullptr)) : std::string("no window")) << " holds it\n"
                          << std::flush;
            }
            return ForegroundAttempt{owner.ForegroundLossCount() != 0u, owner.LastForegroundThiefThreadId()};
        };
        const auto expect = [&](bool condition, const char* message)
        {
            if (! condition && failure.empty())
                failure = message;
            return condition;
        };
        const HCURSOR arrow      = LoadCursorW(nullptr, IDC_ARROW);
        const HCURSOR textCursor = LoadCursorW(nullptr, IDC_IBEAM);
        SetCursor(LoadCursorW(nullptr, IDC_SIZEWE));
        const std::vector<MenuFlyoutItem> items{{.text = L"Ouvrir", .commandId = 9311}, {.text = L"Fermer", .commandId = 9312}};
        const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "cursor menu anchor maps to screen");
        bool closed        = false;
        if (! expect(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [&closed](std::optional<int>) noexcept { closed = true; }),
                     "cursor menu opens"))
            return finish();
        const auto dismiss = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(owner.Hwnd()); });
        const HWND popup   = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), L"Ouvrir");
        if (! expect(popup != nullptr, "cursor menu appears"))
            return finish();
        owner.PumpMessages(); // The forward is posted.
        expect(GetCursor() == textCursor, "an opening menu lets the window under the pointer choose its cursor");

        RECT popupRect{};
        if (! expect(GetWindowRect(popup, &popupRect) != FALSE, "read the menu popup rectangle"))
            return finish();
        const POINT overMenu{(popupRect.left + popupRect.right) / 2, popupRect.top + 14};
        static_cast<void>(SendCapturedMouseMessageForMenuSuite(popup, WM_MOUSEMOVE, 0, overMenu));
        expect(GetCursor() == arrow, "the arrow shows over the open menu");
        SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
        owner.PumpMessages();
        expect(closed && WaitForWindowDestroyed(popup, std::chrono::milliseconds(2000)), "the cursor menu closes");
        owner.PumpMessages();
        expect(GetCursor() == textCursor, "a closing menu lets the window under the pointer choose its cursor again");
        return finish();
    });
    if (! skip.empty())
    {
        SkipDxUiTest(skip.c_str());
        return;
    }
    if (! ForegroundHeldOrSkip(run, "the menu open-and-close cursor test"))
        return;
    Require(failure.empty(), failure.c_str());
}

// A window under the pointer may close the menu from its WM_SETCURSOR handling (focus-follows-mouse activation,
// Escape sent to the popup). The menu forwards the cursor outside its own handlers, so nothing the close frees is
// touched afterwards; AddressSanitizer reports a use after free if the forward runs inside pointer routing.
HWND g_menuClosingCursorPopup = nullptr;

LRESULT CALLBACK MenuClosingCursorWindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    if (message == WM_SETCURSOR && g_menuClosingCursorPopup && IsWindow(g_menuClosingCursorPopup) != FALSE)
    {
        const HWND popup         = g_menuClosingCursorPopup;
        g_menuClosingCursorPopup = nullptr;
        static_cast<void>(SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0));
        SetCursor(LoadCursorW(nullptr, IDC_HAND));
        return TRUE;
    }
    return DefWindowProcW(hwnd, message, wParam, lParam);
}

void TestMenuSurvivesAWindowClosingItFromSetCursor()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    SetWindowPos(owner.Hwnd(), nullptr, 100, 100, 360, 240, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(owner.Hwnd(), SW_SHOWNOACTIVATE);
    owner.PumpMessages();
    static constexpr wchar_t kClosingWindowClass[] = L"DxUiTests.MenuClosingCursorWindow";
    WNDCLASSEXW closingClass{};
    closingClass.cbSize        = sizeof(closingClass);
    closingClass.lpfnWndProc   = MenuClosingCursorWindowProc;
    closingClass.hInstance     = GetModuleHandleW(nullptr);
    closingClass.lpszClassName = kClosingWindowClass;
    Require(RegisterClassExW(&closingClass) != 0 || GetLastError() == ERROR_CLASS_ALREADY_EXISTS, "register the menu-closing window class");
    // Topmost, so an application that takes the foreground back while the suite runs (the desktop application hosting a
    // developer's session does) cannot cover it: covered, the window would never be under the pointer and the test would
    // only ever skip.
    wil::unique_hwnd closingWindow(CreateWindowExW(WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
                                                   kClosingWindowClass,
                                                   L"",
                                                   WS_POPUP | WS_VISIBLE,
                                                   100,
                                                   520,
                                                   240,
                                                   120,
                                                   nullptr,
                                                   nullptr,
                                                   closingClass.hInstance,
                                                   nullptr));
    Require(closingWindow != nullptr, "create the menu-closing window");
    owner.PumpMessages();

    bool closed = false;
    const std::vector<MenuFlyoutItem> items{{.text = L"Copier", .commandId = 9311}, {.text = L"Coller", .commandId = 9312}};
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "closing-cursor menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [&](std::optional<int>) noexcept { closed = true; }),
            "closing-cursor menu opens");
    const auto dismiss = wil::scope_exit([&]() noexcept { DismissOwnedContextMenuPopupChain(owner.Hwnd()); });
    const HWND popup   = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), L"Copier");
    Require(popup != nullptr, "closing-cursor menu appears");
    owner.PumpMessages();
    RECT closingRect{};
    Require(GetWindowRect(closingWindow.get(), &closingRect) != FALSE, "read the menu-closing window rectangle");
    const POINT overClosing{(closingRect.left + closingRect.right) / 2, (closingRect.top + closingRect.bottom) / 2};
    if (const HWND covering = WindowFromPoint(overClosing); covering != closingWindow.get())
    {
        wchar_t className[128]{};
        static_cast<void>(GetClassNameW(covering, className, static_cast<int>(std::size(className))));
        const DWORD thread       = covering ? GetWindowThreadProcessId(covering, nullptr) : 0u;
        const std::string reason = std::format("another window covers the menu-closing window: class '{}' of {}{}",
                                               NarrowAsciiForFailureMessage(className),
                                               DescribeThreadProcessForTest(thread),
                                               thread == GetCurrentThreadId() ? ", this test's own thread" : "");
        SkipDxUiTest(reason.c_str());
        return;
    }
    g_menuClosingCursorPopup = popup;
    static_cast<void>(SendCapturedMouseMessageForMenuSuite(popup, WM_MOUSEMOVE, 0, overClosing));
    owner.PumpMessages();
    g_menuClosingCursorPopup = nullptr;
    Require(closed && WaitForWindowDestroyed(popup, std::chrono::milliseconds(2000)), "the window's WM_SETCURSOR handling closes the menu cleanly");
}

void TestMenuItemRoleOutsideMenuPopupTransfersNativeFocus()
{
    using namespace DxUi;
    // Native focus transfer needs the activating Menu lane; the nonactivating lane blocks it.
    if (! DxUiTestWindowsCanActivateFlag())
        return;
    AttachedHostWindow other;
    AttachedHostWindow window;
    SetWindowPos(other.Hwnd(), nullptr, 120, 120, 320, 200, SWP_NOZORDER);
    SetWindowPos(window.Hwnd(), nullptr, 480, 120, 320, 200, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(window.Hwnd(), SW_SHOWNOACTIVATE);
    // An ordinary host may use the public MenuItem role; only native menu popups keep focus away.
    auto root = std::make_unique<Panel>();
    for (int index = 0; index < 2; ++index)
    {
        auto* recent    = root->AddChild<Label>(std::format(L"Dossier récent {}", index));
        const float top = 8.0f + 32.0f * static_cast<float>(index);
        recent->SetBounds(D2D1::RectF(8.0f, top, 240.0f, top + 28.0f));
        recent->SetFocusable(true);
        recent->SetAccessibilityRole(AccessibilityRole::MenuItem);
    }
    window.Host().SetRoot(std::move(root));
    if (! TryActivateDxUiTestWindow(other.Hwnd()))
    {
        SkipDxUiTest("DxUi MenuItem-role native focus transfer requires an interactive desktop");
        return;
    }
    wil::com_ptr_nothrow<IRawElementProviderFragmentRoot> provider;
    provider.attach(CreateWindowHostAccessibilityProvider(window.Hwnd()));
    Require(provider != nullptr, "ordinary MenuItem-role host publishes a UIA root");
    wil::com_ptr_nothrow<IRawElementProviderFragment> rootFragment;
    RequireSucceeded(provider.query_to(rootFragment.put()), "ordinary MenuItem-role root navigates");
    wil::com_ptr_nothrow<IRawElementProviderFragment> entry;
    RequireSucceeded(rootFragment->Navigate(NavigateDirection_FirstChild, entry.put()), "ordinary MenuItem-role entry is available");
    Require(entry != nullptr, "ordinary MenuItem-role entry exists");
    RequireSucceeded(entry->SetFocus(), "a screen reader can focus an ordinary MenuItem-role entry");
    Require(GetFocus() == window.Hwnd() && window.Host().GetFocusControl() != nullptr,
            "UIA focus of a MenuItem-role control outside a native menu popup transfers native focus");
}

void TestDescribedMenuFractionalDpiKeepsLaneAndWidths()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    const std::vector<MenuFlyoutItem> items{{.text = L"Archives familiales", .commandId = 8981, .secondaryText = L"C:\\Photographies\\Archives familiales"},
                                            {.text = L"Collection du musée", .commandId = 8982, .secondaryText = L"D:\\Sauvegardes\\Collection du musée"}};
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "fractional DPI described menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [](std::optional<int>) noexcept {}),
            "fractional DPI described menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "fractional DPI described menu appears");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    ContextMenuPopupDebugState state{};
    Require(DebugGetContextMenuPopupState(popup, state) && ! state.hasScrollbar, "two described rows fit without a scrollbar");
    // Described rows are whole DIPs tall. Pick a DPI whose whole-pixel viewport rounds below that
    // content (a remainder under half a pixel), as 125% does for content of 4n + 1 DIPs. Prefer
    // the common 125% and 175% scales, then any synthetic DPI.
    const long contentDip = std::lround(state.contentHeightDip);
    Require(std::abs(state.contentHeightDip - static_cast<float>(contentDip)) < 0.01f, "described content height is whole DIPs");
    const auto roundsBelowContent = [contentDip](UINT dpi) noexcept
    {
        const long remainder = (contentDip * static_cast<long>(dpi)) % 96L;
        return remainder > 0L && remainder < 48L;
    };
    UINT roundedDownDpi = roundsBelowContent(120u) ? 120u : (roundsBelowContent(168u) ? 168u : 0u);
    for (UINT dpi = 97u; dpi < 240u && roundedDownDpi == 0u; ++dpi)
    {
        if (roundsBelowContent(dpi))
            roundedDownDpi = dpi;
    }
    if (roundedDownDpi == 0u)
    {
        SkipDxUiTest("DxUi fractional DPI menu probe found no DPI that rounds this content height down");
        return;
    }
    RECT suggested = state.windowRectPx;
    SendMessageW(popup, WM_DPICHANGED, MAKEWPARAM(roundedDownDpi, roundedDownDpi), reinterpret_cast<LPARAM>(&suggested));
    Require(DebugGetContextMenuPopupState(popup, state) && state.dpi == roundedDownDpi &&
                std::abs(state.contentHeightDip - static_cast<float>(contentDip)) < 0.01f,
            "fractional DPI reflow keeps the described content height");
    Require(! state.hasScrollbar, "whole-pixel rounding of fitting described rows reserves no scrollbar lane");
    for (size_t index = 0; index < items.size(); ++index)
    {
        ContextMenuPopupItemLayoutDebugState row{};
        Require(DebugGetContextMenuPopupItemLayout(popup, index, row), "fractional DPI row exposes native text widths");
        const float availableWidth = row.textRectDip.right - row.textRectDip.left;
        Require(std::abs(row.primaryLayoutWidthDip - availableWidth) < 0.5f && std::abs(row.secondaryLayoutWidthDip - availableWidth) < 0.5f,
                "fractional DPI layouts match the painted text width");
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// One layout per described row. A row's label and description are paragraphs of one DirectWrite layout, which costs one
// layout's shaping storage where two separate layouts cost two. These tests hold it to what two separate layouts drew: the
// gap between the fields, each field's size and wrapping, its color in every row state, its tab stops and its color glyphs.
// ---------------------------------------------------------------------------------------------------------------------

// What a scan of one field's ink found. A pixel over its row's background is that background plus its coverage times the step
// from the background to the foreground, so the coverage reads along the expected foreground whatever gradient lies under it.
struct DescribedFieldInk
{
    size_t inkPixels       = 0u;
    double strongest       = 0.0; // The 99th percentile of the coverage along the expected foreground: near 1 in the right color.
    double total           = 0.0; // The sum of the coverage of every pixel of the field.
    size_t chromaticPixels = 0u;  // Pixels whose channels differ much: colored glyphs, never the neutral theme text.
};

[[nodiscard]] DescribedFieldInk ScanDescribedFieldInk(
    const DxUi::WindowHostBitmapCapture& capture, const D2D1_RECT_F& fieldDip, UINT dpi, const D2D1_COLOR_F& foreground, LONG backgroundXPx)
{
    const auto toPixel = [dpi](float dip) { return static_cast<LONG>(DipToPixelForPopup(dip, dpi)); };
    const LONG left    = (std::max)(0L, toPixel(fieldDip.left));
    const LONG right   = (std::min)(static_cast<LONG>(capture.widthPx), toPixel(fieldDip.right));
    const LONG top     = (std::max)(0L, toPixel(fieldDip.top));
    const LONG bottom  = (std::min)(static_cast<LONG>(capture.heightPx), toPixel(fieldDip.bottom));
    Require(right > left && bottom > top && backgroundXPx >= 0 && backgroundXPx < static_cast<LONG>(capture.widthPx),
            "a described field's scan window lies in the capture");
    const auto pixel       = [&](LONG x, LONG y) { return &capture.bgraPixels[(static_cast<size_t>(y) * capture.widthPx + static_cast<size_t>(x)) * 4u]; };
    const double target[3] = {foreground.b * 255.0, foreground.g * 255.0, foreground.r * 255.0};
    DescribedFieldInk ink;
    std::vector<double> coverages;
    for (LONG y = top; y < bottom; ++y)
    {
        const uint8_t* background = pixel(backgroundXPx, y);
        double step[3]{};
        double stepLengthSquared = 0.0;
        for (int channel = 0; channel < 3; ++channel)
        {
            step[channel] = target[channel] - static_cast<double>(background[channel]);
            stepLengthSquared += step[channel] * step[channel];
        }
        if (stepLengthSquared < 64.0)
            continue; // The foreground is indistinguishable from what lies under it.
        for (LONG x = left; x < right; ++x)
        {
            const uint8_t* value = pixel(x, y);
            double largest       = 0.0;
            double along         = 0.0;
            for (int channel = 0; channel < 3; ++channel)
            {
                const double delta = static_cast<double>(value[channel]) - static_cast<double>(background[channel]);
                largest            = (std::max)(largest, std::abs(delta));
                along += delta * step[channel];
            }
            // The total counts every pixel of the field, so two rows that differ only in opacity compare exactly; the rest of
            // the statistics cover the pixels that are clearly ink.
            ink.total += along / stepLengthSquared;
            if (largest <= 20.0)
                continue;
            ++ink.inkPixels;
            coverages.push_back(along / stepLengthSquared);
            if ((std::max)({value[0], value[1], value[2]}) - (std::min)({value[0], value[1], value[2]}) > 40)
                ++ink.chromaticPixels;
        }
    }
    if (! coverages.empty())
    {
        std::sort(coverages.begin(), coverages.end());
        ink.strongest = coverages[(coverages.size() - 1u) * 99u / 100u];
    }
    return ink;
}

[[nodiscard]] LONG DescribedRowBackgroundColumnPx(const D2D1_RECT_F& itemRectDip, UINT dpi)
{
    // The row's right end holds no text when its text is short: what lies there is the row's background, scanline by scanline.
    return static_cast<LONG>(DipToPixelForPopup(itemRectDip.right - 14.0f, dpi));
}

// A popup that opens under the physical cursor hovers the row beneath it, and the system may synthesize a pointer move for
// the cursor at any message turn. Park the popup's pointer in its shadow margin, outside every row, and capture before any
// message is pumped, so the state a pixel test scans is the one it names.
void ParkDescribedPopupPointerOutsideRows(HWND popup)
{
    Require(SendSettledClientMouseMoveForMenuSuite(popup, 2, 2), "the popup's pointer parks in its margin");
    DxUi::ContextMenuPopupDebugState state{};
    Require(DxUi::DebugGetContextMenuPopupState(popup, state) && ! state.hoveredIndex.has_value(), "no row is hovered while the pointer is parked");
}

void TestDescribedRowsHoldOneLayoutEach()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    // Described rows of every kind beside plain ones. The last two described rows repeat both fields exactly, and each still
    // holds a layout of its own.
    const std::vector<MenuFlyoutItem> items{
        {.text = L"Archives familiales", .commandId = 9601, .secondaryText = L"C:\\Photographies\\Archives familiales"},
        {.kind = MenuItemKind::Radio, .text = L"Archives familiales", .commandId = 9602, .secondaryText = L"D:\\Sauvegardes\\Archives familiales"},
        {.kind = MenuItemKind::Separator},
        {.kind = MenuItemKind::Info, .text = L"Espace utilisé :", .acceleratorText = L"561 Go", .secondaryText = L"Sur tous les volumes"},
        {.kind = MenuItemKind::Toggle, .text = L"Collection du musée", .commandId = 9603, .secondaryText = L"D:\\Sauvegardes\\Collection du musée"},
        {.kind = MenuItemKind::Toggle, .text = L"Collection du musée", .commandId = 9604, .secondaryText = L"D:\\Sauvegardes\\Collection du musée"},
        {.text = L"Commande simple", .commandId = 9605}};
    constexpr size_t describedRows             = 5u;
    const ContextMenuResourceDebugState before = DebugGetContextMenuResources();
    bool closed                                = false;
    const POINT anchor                         = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "layout count menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [&](std::optional<int>) noexcept { closed = true; }),
            "layout count menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "layout count menu appears");
    const ContextMenuResourceDebugState open = DebugGetContextMenuResources();
    Require(open.popups == before.popups + 1u, "the menu has one popup");
    Require(open.rowLayouts == before.rowLayouts + describedRows,
            "each described row holds one layout for its label and its description, and rows without a description hold none");
    SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    owner.PumpMessages();
    Require(closed && WaitForWindowDestroyed(popup), "layout count menu closes");
    Require(DebugGetContextMenuResources() == before, "closing the menu returns its layouts");
}

void TestDescribedRowDescriptionStartsAGapBelowTheLabelAsSeparateLayoutsPlaceIt()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    auto* factory     = owner.Host().GetWriteFactory();
    auto* bodyFormat  = owner.Host().GetTextFormat(FontRole::Body);
    auto* smallFormat = owner.Host().GetTextFormat(FontRole::Small);
    Require(factory && bodyFormat && smallFormat, "gap test has native text services");
    // What a separate layout measures for one field at a width: the contract the row's single layout keeps.
    const auto measureField = [&](std::wstring_view text, IDWriteTextFormat* format, float widthDip)
    {
        wil::com_ptr<IDWriteTextLayout> reference;
        Require(SUCCEEDED(factory->CreateTextLayout(text.data(), static_cast<UINT32>(text.size()), format, widthDip, 1000000.0f, reference.put())),
                "gap test creates a separate layout");
        const DWRITE_TRIMMING trimming{DWRITE_TRIMMING_GRANULARITY_NONE, 0, 0};
        Require(SUCCEEDED(reference->SetWordWrapping(DWRITE_WORD_WRAPPING_EMERGENCY_BREAK)) &&
                    SUCCEEDED(reference->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_NEAR)) &&
                    SUCCEEDED(reference->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING)) && SUCCEEDED(reference->SetTrimming(&trimming, nullptr)),
                "gap test gives the separate layout the row's text policy");
        DWRITE_TEXT_METRICS metrics{};
        Require(SUCCEEDED(reference->GetMetrics(&metrics)), "gap test measures the separate layout");
        return metrics;
    };
    const std::vector<MenuFlyoutItem> items{
        {.text = L"Documents", .commandId = 9611, .secondaryText = L"C:\\Users\\Eric\\Documents"},
        {.kind          = MenuItemKind::Radio,
         .text          = L"Sélection définitive pour impression et archivage — réunion familiale été 2026 && photographies originales",
         .checked       = true,
         .commandId     = 9612,
         .secondaryText = L"D:\\Sauvegardes\\Archives photographiques personnelles de plusieurs générations\\Exposition annuelle de la médiathèque"},
        {.text = L"Première ligne du libellé\nDeuxième ligne du libellé", .commandId = 9613, .secondaryText = L"Un paragraphe\nDeux paragraphes\r\nTrois"},
        {.text = L"", .commandId = 9614, .secondaryText = L"Description sans libellé"},
        {.text          = L"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
         .commandId     = 9615,
         .secondaryText = L"BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB"},
        {.kind = MenuItemKind::Info, .text = L"Espace utilisé :", .acceleratorText = L"561 Go", .secondaryText = L"Sur tous les volumes de cette bibliothèque"},
        {.text            = L"Copier vers Documents",
         .acceleratorText = L"Ctrl+D",
         .commandId       = 9616,
         .secondaryText   = L"Un raccourci réserve sa colonne et resserre le texte"},
        {.text = L"Ligne d’écriture", .commandId = 9617, .secondaryText = L"Fin de ligne\n"}};
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "gap test menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [](std::optional<int>) noexcept {}, ContextMenuSessionCallbacks{}),
            "gap test menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "gap test menu appears");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    ContextMenuPopupDebugState state{};
    Require(DebugGetContextMenuPopupState(popup, state), "gap test popup state");
    std::vector<UINT> dpis{state.dpi, 96u, 144u, 192u, 120u, state.dpi};
    for (const UINT dpi : dpis)
    {
        if (state.dpi != dpi)
        {
            RECT suggested = state.windowRectPx;
            SendMessageW(popup, WM_DPICHANGED, MAKEWPARAM(dpi, dpi), reinterpret_cast<LPARAM>(&suggested));
            Require(DebugGetContextMenuPopupState(popup, state) && state.dpi == dpi, "gap test applies the DPI");
        }
        for (size_t index = 0; index < items.size(); ++index)
        {
            ContextMenuPopupItemLayoutDebugState row{};
            Require(DebugGetContextMenuPopupItemLayout(popup, index, row), "gap test row geometry available");
            // The label is what the row's own text says once a doubled ampersand is one.
            std::wstring label = items[index].text;
            if (const size_t doubled = label.find(L"&&"); doubled != std::wstring::npos)
                label.erase(doubled, 1u);
            const float width                   = row.primaryLayoutWidthDip;
            const DWRITE_TEXT_METRICS primary   = measureField(label, bodyFormat, width);
            const DWRITE_TEXT_METRICS secondary = measureField(items[index].secondaryText, smallFormat, width);
            const float labelHeight             = std::ceil(primary.height);
            const float descriptionHeight       = std::ceil(secondary.height);
            const std::string where             = std::format("row {} at {} DPI", index, dpi);
            RequireFloatNear(
                row.textRectDip.bottom - row.textRectDip.top, labelHeight, 0.001f, ("the label keeps its separate layout's height: " + where).c_str());
            RequireFloatNear(row.secondaryTextRectDip.bottom - row.secondaryTextRectDip.top,
                             descriptionHeight,
                             0.001f,
                             ("the description keeps its separate layout's height: " + where).c_str());
            Require(row.primaryLineCount == primary.lineCount && row.secondaryLineCount == secondary.lineCount,
                    ("both fields wrap into the lines their separate layouts wrap into: " + where).c_str());
            RequireFloatNear(row.secondaryLayoutWidthDip, row.primaryLayoutWidthDip, 0.001f, ("both fields wrap at one width: " + where).c_str());
            // The description starts a fixed 3 DIP gap below the label's height rounded up to whole DIPs, where it was drawn.
            RequireFloatNear(
                row.descriptionOffsetDip, labelHeight + 3.0f, 0.001f, ("the layout starts the description a gap below the label: " + where).c_str());
            RequireFloatNear(row.secondaryTextRectDip.top - row.textRectDip.top,
                             row.descriptionOffsetDip,
                             0.001f,
                             ("the layout and the row geometry agree on the gap: " + where).c_str());
            RequireFloatNear(row.itemRectDip.bottom - row.itemRectDip.top,
                             16.0f + labelHeight + 3.0f + descriptionHeight,
                             0.001f,
                             ("the row is padded around both fields and their gap: " + where).c_str());
        }
    }
}

void TestDescribedRowPaintsEachFieldInItsOwnColor()
{
    using namespace DxUi;
    for (const bool dark : {false, true})
    {
        AttachedHostWindow owner;
        ThemePalette theme  = MakeDefaultThemePalette(dark);
        theme.reducedMotion = true;
        // The first two rows say the same in every field; only the second is disabled. The third holds color glyphs.
        const std::vector<MenuFlyoutItem> items{
            {.text = L"Archives familiales", .commandId = 9621, .secondaryText = L"C:\\Photographies\\Archives"},
            {.text = L"Archives familiales", .enabled = false, .commandId = 9622, .secondaryText = L"C:\\Photographies\\Archives"},
            {.text = L"Photos \U0001F3A8", .commandId = 9623, .secondaryText = L"Fête \U0001F389 annuelle"}};
        bool closed        = false;
        const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "color menu anchor maps to screen");
        Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, theme, [&](std::optional<int>) noexcept { closed = true; }, ContextMenuSessionCallbacks{}),
                "color menu opens");
        const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
        Require(popup != nullptr, "color menu appears");
        const auto dismiss = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popup))
                SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
        });
        ContextMenuPopupDebugState state{};
        Require(DebugGetContextMenuPopupState(popup, state), "color menu popup state");
        std::array<ContextMenuPopupItemLayoutDebugState, 3> rows{};
        for (size_t index = 0; index < rows.size(); ++index)
            Require(DebugGetContextMenuPopupItemLayout(popup, index, rows[index]), "color menu row geometry available");
        const auto scan = [&](const WindowHostBitmapCapture& capture, size_t index, bool description, const D2D1_COLOR_F& foreground)
        {
            return ScanDescribedFieldInk(capture,
                                         description ? rows[index].secondaryTextRectDip : rows[index].textRectDip,
                                         state.dpi,
                                         foreground,
                                         DescribedRowBackgroundColumnPx(rows[index].itemRectDip, state.dpi));
        };
        const std::string themeName = dark ? "dark " : "light ";
        const auto requireColor     = [&](const DescribedFieldInk& ink, const char* what)
        {
            const std::string message = themeName + what;
            Require(ink.inkPixels > 30u, (message + " has ink").c_str());
            Require(ink.strongest > 0.85 && ink.strongest < 1.06, (message + " is drawn in its expected color").c_str());
        };

        WindowHostBitmapCapture capture{};
        ParkDescribedPopupPointerOutsideRows(popup);
        Require(DebugCaptureContextMenuPopupBitmap(popup, capture), "color menu captures");
        requireColor(scan(capture, 0, false, theme.text), "label of an enabled row");
        requireColor(scan(capture, 0, true, theme.subduedText), "description of an enabled row");
        // A disabled row draws the same fields at 40% opacity, each in its own color: the two rows differ by that factor alone.
        for (const bool description : {false, true})
        {
            const D2D1_COLOR_F& color        = description ? theme.subduedText : theme.text;
            const DescribedFieldInk enabled  = scan(capture, 0, description, color);
            const DescribedFieldInk disabled = scan(capture, 1, description, color);
            Require(enabled.total > 0.0 && std::abs(disabled.total / enabled.total - 0.4) < 0.04,
                    (themeName + (description ? "description" : "label") + " of a disabled row keeps its color at 40% opacity").c_str());
        }
        // Color glyphs draw as color in both fields, as in plain rows, and plain text stays neutral.
        Require(scan(capture, 2, false, theme.text).chromaticPixels > 12u && scan(capture, 2, true, theme.subduedText).chromaticPixels > 12u,
                (themeName + "color glyphs are drawn in color in both fields").c_str());
        Require(scan(capture, 0, false, theme.text).chromaticPixels == 0u && scan(capture, 0, true, theme.subduedText).chromaticPixels == 0u,
                (themeName + "plain text stays in its theme colors").c_str());

        // Hovering a row gives both its fields the contrast color of its highlight; the rows beside it keep theirs.
        bool hovered = false;
        for (int attempt = 0; attempt < 5 && ! hovered; ++attempt)
        {
            const LONG x = static_cast<LONG>(DipToPixelForPopup((rows[0].itemRectDip.left + rows[0].itemRectDip.right) * 0.5f, state.dpi));
            const LONG y = static_cast<LONG>(DipToPixelForPopup((rows[0].itemRectDip.top + rows[0].itemRectDip.bottom) * 0.5f, state.dpi));
            Require(SendSettledClientMouseMoveForMenuSuite(popup, x, y), "color menu hovers its first row");
            ContextMenuPopupDebugState hoverState{};
            hovered = DebugGetContextMenuPopupState(popup, hoverState) && hoverState.hoveredIndex == std::optional<size_t>{0u};
        }
        Require(hovered, "color menu hover takes effect");
        ContextMenuPopupItemPaintDebugState paint{};
        Require(DebugGetContextMenuPopupItemPaint(popup, 0, paint) && paint.hovered && paint.usesHighlightFill, "the hovered row has a highlight");
        WindowHostBitmapCapture hoverCapture{};
        Require(DebugCaptureContextMenuPopupBitmap(popup, hoverCapture), "color menu captures the hover");
        requireColor(scan(hoverCapture, 0, false, paint.textColor), "label of a hovered row");
        requireColor(scan(hoverCapture, 0, true, paint.acceleratorColor), "description of a hovered row");
        requireColor(scan(hoverCapture, 2, false, theme.text), "label of a row beside the hovered one");
        requireColor(scan(hoverCapture, 2, true, theme.subduedText), "description of a row beside the hovered one");
        SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
        owner.PumpMessages();
        Require(closed && WaitForWindowDestroyed(popup), "color menu closes");
    }
}

void TestDescribedRowDescriptionKeepsTheSmallFontTabStops()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    auto* bodyFormat  = owner.Host().GetTextFormat(FontRole::Body);
    auto* smallFormat = owner.Host().GetTextFormat(FontRole::Small);
    Require(bodyFormat && smallFormat, "tab stop test has text formats");
    const float smallTabStop = smallFormat->GetIncrementalTabStop();
    Require(std::abs(smallTabStop - bodyFormat->GetIncrementalTabStop()) > 4.0f, "the small and body formats have tab stops a scan can tell apart");
    const std::vector<MenuFlyoutItem> items{{.text = L"Destination", .commandId = 9631, .secondaryText = L"x\ty"}};
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "tab stop menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, owner.Host().GetTheme(), [](std::optional<int>) noexcept {}, ContextMenuSessionCallbacks{}),
            "tab stop menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "tab stop menu appears");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    ContextMenuPopupDebugState state{};
    ContextMenuPopupItemLayoutDebugState row{};
    WindowHostBitmapCapture capture{};
    Require(DebugGetContextMenuPopupState(popup, state) && DebugGetContextMenuPopupItemLayout(popup, 0, row) &&
                DebugCaptureContextMenuPopupBitmap(popup, capture),
            "tab stop menu captures");
    // The description's two glyphs are a tab stop apart: the second starts where the first does, plus the small font's tab stop.
    const LONG backgroundX = DescribedRowBackgroundColumnPx(row.itemRectDip, state.dpi);
    const auto toPixel     = [&](float dip) { return static_cast<LONG>(DipToPixelForPopup(dip, state.dpi)); };
    std::vector<LONG> inkColumns;
    for (LONG x = toPixel(row.secondaryTextRectDip.left); x < toPixel(row.secondaryTextRectDip.right); ++x)
    {
        bool ink = false;
        for (LONG y = toPixel(row.secondaryTextRectDip.top); y < toPixel(row.secondaryTextRectDip.bottom) && ! ink; ++y)
        {
            const auto pixel = [&](LONG px) { return &capture.bgraPixels[(static_cast<size_t>(y) * capture.widthPx + static_cast<size_t>(px)) * 4u]; };
            for (int channel = 0; channel < 3; ++channel)
                ink = ink || std::abs(static_cast<int>(pixel(x)[channel]) - static_cast<int>(pixel(backgroundX)[channel])) > 30;
        }
        if (ink)
            inkColumns.push_back(x);
    }
    Require(! inkColumns.empty(), "the description is drawn");
    LONG secondStart = -1;
    for (size_t index = 1; index < inkColumns.size(); ++index)
    {
        if (inkColumns[index] - inkColumns[index - 1u] > toPixel(6.0f))
        {
            secondStart = inkColumns[index];
            break;
        }
    }
    Require(secondStart >= 0, "the description's two glyphs are drawn a tab apart");
    const LONG expected = inkColumns.front() + toPixel(smallTabStop);
    Require(std::abs(static_cast<int>(secondStart - expected)) <= toPixel(2.0f) + 1,
            "the description's tab stops are the small font's, as in a layout of its own");
}

void TestBodyAndSmallFormatsAgreeOnWhatOneRowLayoutHoldsForAllItsText()
{
    using namespace DxUi;
    // A described row is one layout made from the body format, so every property a layout holds for all its text must be the
    // body format's for the description too: the host must create its small format like its body format in all of them.
    AttachedHostWindow owner;
    auto* bodyFormat  = owner.Host().GetTextFormat(FontRole::Body);
    auto* smallFormat = owner.Host().GetTextFormat(FontRole::Small);
    Require(bodyFormat && smallFormat, "policy test has text formats");
    Require(bodyFormat->GetTextAlignment() == smallFormat->GetTextAlignment() && bodyFormat->GetParagraphAlignment() == smallFormat->GetParagraphAlignment(),
            "the body and small formats align alike");
    Require(bodyFormat->GetWordWrapping() == smallFormat->GetWordWrapping(), "the body and small formats wrap alike");
    Require(bodyFormat->GetReadingDirection() == smallFormat->GetReadingDirection() && bodyFormat->GetFlowDirection() == smallFormat->GetFlowDirection(),
            "the body and small formats read in one direction");
    DWRITE_LINE_SPACING_METHOD bodyMethod{}, smallMethod{};
    float bodySpacing = 0.0f, smallSpacing = 0.0f, bodyBaseline = 0.0f, smallBaseline = 0.0f;
    Require(SUCCEEDED(bodyFormat->GetLineSpacing(&bodyMethod, &bodySpacing, &bodyBaseline)) &&
                SUCCEEDED(smallFormat->GetLineSpacing(&smallMethod, &smallSpacing, &smallBaseline)),
            "both formats report their line spacing");
    Require(bodyMethod == smallMethod && bodySpacing == smallSpacing && bodyBaseline == smallBaseline, "the body and small formats space their lines alike");
    DWRITE_TRIMMING bodyTrimming{}, smallTrimming{};
    wil::com_ptr<IDWriteInlineObject> bodyEllipsis, smallEllipsis;
    Require(SUCCEEDED(bodyFormat->GetTrimming(&bodyTrimming, bodyEllipsis.put())) && SUCCEEDED(smallFormat->GetTrimming(&smallTrimming, smallEllipsis.put())),
            "both formats report their trimming");
    Require(bodyTrimming.granularity == smallTrimming.granularity && bodyTrimming.delimiter == smallTrimming.delimiter &&
                bodyTrimming.delimiterCount == smallTrimming.delimiterCount,
            "the body and small formats trim alike");
}

void TestDescribedMenuDrawsItsDescriptionAgainAfterDeviceLoss()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    ThemePalette theme  = MakeDefaultThemePalette(false);
    theme.reducedMotion = true;
    const std::vector<MenuFlyoutItem> items{
        {.text = L"Archives familiales", .commandId = 9641, .secondaryText = L"C:\\Photographies\\Archives"},
        {.text = L"Collection du musée", .enabled = false, .commandId = 9642, .secondaryText = L"D:\\Sauvegardes\\Collection"}};
    bool closed        = false;
    const POINT anchor = ClientScreenPointForTest(owner.Hwnd(), 20, 20, "device loss menu anchor maps to screen");
    Require(ContextMenu::ShowAsync(owner.Hwnd(), anchor, items, theme, [&](std::optional<int>) noexcept { closed = true; }, ContextMenuSessionCallbacks{}),
            "device loss menu opens");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), items.front().text);
    Require(popup != nullptr, "device loss menu appears");
    const auto dismiss = wil::scope_exit([&]() noexcept
    {
        if (IsWindow(popup))
            SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    });
    ContextMenuPopupDebugState state{};
    std::array<ContextMenuPopupItemLayoutDebugState, 2> rows{};
    Require(DebugGetContextMenuPopupState(popup, state) && DebugGetContextMenuPopupItemLayout(popup, 0, rows[0]) &&
                DebugGetContextMenuPopupItemLayout(popup, 1, rows[1]),
            "device loss menu geometry available");
    const auto describe = [&](const WindowHostBitmapCapture& capture, size_t index)
    {
        const LONG background = DescribedRowBackgroundColumnPx(rows[index].itemRectDip, state.dpi);
        return std::pair{ScanDescribedFieldInk(capture, rows[index].textRectDip, state.dpi, theme.text, background),
                         ScanDescribedFieldInk(capture, rows[index].secondaryTextRectDip, state.dpi, theme.subduedText, background)};
    };
    WindowHostBitmapCapture before{};
    ParkDescribedPopupPointerOutsideRows(popup);
    Require(DebugCaptureContextMenuPopupBitmap(popup, before), "device loss menu captures before the loss");
    const auto beforeInk = describe(before, 0);
    Require(beforeInk.first.inkPixels > 30u && beforeInk.second.inkPixels > 30u && beforeInk.second.strongest > 0.85 && beforeInk.second.strongest < 1.06,
            "the description is drawn before the device is lost");

    Require(DebugSimulateContextMenuPopupDeviceLoss(popup), "the popup's device is lost");
    WindowHostBitmapCapture after{};
    ParkDescribedPopupPointerOutsideRows(popup);
    Require(DebugCaptureContextMenuPopupBitmap(popup, after), "device loss menu captures after the loss");
    // The layouts carried the old device's brush. Drawing again needs the new device's, and nothing else changes on screen.
    const BitmapComparisonStats drawn = CompareWindowHostBitmapCapturesForTest(after, before, 4u);
    Require(drawn.totalPixels > 0u && drawn.differingPixels == 0u, "the menu draws as before with the recreated device, descriptions included");
    const auto afterInk = describe(after, 0);
    Require(afterInk.second.inkPixels > 30u && afterInk.second.strongest > 0.85 && afterInk.second.strongest < 1.06,
            "the description is drawn in its color after the device is lost");
    Require(describe(after, 1).second.inkPixels > 30u, "the disabled row's description is drawn after the device is lost");
    SendMessageW(popup, WM_KEYDOWN, VK_ESCAPE, 0);
    owner.PumpMessages();
    Require(closed && WaitForWindowDestroyed(popup), "device loss menu closes");
}

} // namespace

void RunMenuDescriptionTests()
{
    DXUI_RUN_TEST(TestDescribedInfoRowPaintsItsDescription);
    DXUI_RUN_TEST(TestDescribedMenuRaisesFocusChangesForKeyboardRows);
    DXUI_RUN_TEST(TestDescribedMenuReleasesItsMemoryWhenItCloses);
    DXUI_RUN_TEST(TestWindowHostTabRaisesAutomationFocusChanges);
    DXUI_RUN_TEST(TestWindowHostTreeArrowAnnouncesTheFocusedItem);
    DXUI_RUN_TEST(TestWindowHostSingleTreeArrowAnnouncesTheFocusedItem);
    DXUI_RUN_TEST(TestWindowHostSingleGridArrowAnnouncesTheFocusedRow);
    DXUI_RUN_TEST(TestWindowHostElementSetFocusAnnouncesOnlyThatElement);
    DXUI_RUN_TEST(TestWindowHostClickThatActivatesAWindowUiAutomationHasAskedBeforeAnnouncesTheClickedControlOnce);
    DXUI_RUN_TEST(TestWindowHostClickThatActivatesAWindowUiAutomationHasNotSeenLeavesTheClickedControlToItsFirstGetFocus);
    DXUI_RUN_TEST(TestWindowHostReactivatingAWindowUiAutomationHasSeenAnnouncesItsFocusedControlOnce);
    DXUI_RUN_TEST(TestWindowHostThatLostTheForegroundAnnouncesNoFocusChange);
    DXUI_RUN_TEST(TestMenuPointerCursorIsArrowOverPopupsAndTheWindowsOwnOutside);
    DXUI_RUN_TEST(TestMenuChoosesTheCursorWhenItOpensAndCloses);
    DXUI_RUN_TEST(TestMenuSurvivesAWindowClosingItFromSetCursor);
    DXUI_RUN_TEST(TestDescribedAsyncMenuRestoresFocusedOwnerChild);
    DXUI_RUN_TEST(TestDescribedMenuWrapsFrenchTextAndPreservesIdentity);
    DXUI_RUN_TEST(TestDescribedMenuAccessibilityInvokesAndDisconnects);
    DXUI_RUN_TEST(TestDescribedMenuPointerAndCancelledQueuedInvoke);
    DXUI_RUN_TEST(TestDescribedMenuSubmenuKeepsSessionAndIdentity);
    DXUI_RUN_TEST(TestDescribedPointerMenuActivationSelectsNoRow);
    DXUI_RUN_TEST(TestDescribedMenuScrollRepublishesAccessibleGeometry);
    DXUI_RUN_TEST(TestPlainMenuAccessibilityInvokesAndDisconnects);
    DXUI_RUN_TEST(TestPlainMenuAccessibilityScrollsFocusedRow);
    DXUI_RUN_TEST(TestPlainMenuFractionalDpiRoundingDoesNotCreateScrollbar);
    DXUI_RUN_TEST(TestPlainMenuPointerMoveClearsLogicalFocusAndRefreshesAccessibility);
    DXUI_RUN_TEST(TestPlainMenuWheelReconcilesHoverAndCancelsMovedSubmenuTimer);
    DXUI_RUN_TEST(TestOpeningSubmenuEdgeScrollRepaintsParentAccessibilityBounds);
    DXUI_RUN_TEST(TestMenuNativeFocusSelectsNoRowAndRestoresTheChosenOne);
    DXUI_RUN_TEST(TestDescribedSubmenuSliderFocusKeepsSessionFocus);
    DXUI_RUN_TEST(TestMenuItemRoleOutsideMenuPopupTransfersNativeFocus);
    DXUI_RUN_TEST(TestDescribedMenuFractionalDpiKeepsLaneAndWidths);
    DXUI_RUN_TEST(TestDescribedRowsHoldOneLayoutEach);
    DXUI_RUN_TEST(TestDescribedRowDescriptionStartsAGapBelowTheLabelAsSeparateLayoutsPlaceIt);
    DXUI_RUN_TEST(TestDescribedRowPaintsEachFieldInItsOwnColor);
    DXUI_RUN_TEST(TestDescribedRowDescriptionKeepsTheSmallFontTabStops);
    DXUI_RUN_TEST(TestBodyAndSmallFormatsAgreeOnWhatOneRowLayoutHoldsForAllItsText);
    DXUI_RUN_TEST(TestDescribedMenuDrawsItsDescriptionAgainAfterDeviceLoss);
    DXUI_RUN_TEST(TestModalMenuDispatchesUnrelatedTimerWithSubmenuId);
    DXUI_RUN_TEST(TestMenuDriverThatFailsBeforeItsPopupComesUpStillClosesTheMenu);
}

#include "DxUi.Tests.MenuResources.h"

void RunMenuTests()
{
    // Also exercise described rows with real native focus; the nonactivating
    // NewControls lane cannot alone detect a popup stealing Win32 focus.
    RunMenuDescriptionTests();
    // Every menu test starts with a stopped animation dispatcher.
    const auto runTest = [](const char* name, void (*fn)())
    {
        if (RunDxUiTest(name, fn))
            DxUi::Ui::AnimationDispatcher::GetInstance().Shutdown();
    };

    runTest("TestPointerInputEventMouseMoveUsesDeliveredPoint", TestPointerInputEventMouseMoveUsesDeliveredPoint);
    runTest("TestPointerInputEventButtonUsesDeliveredPointAndFlags", TestPointerInputEventButtonUsesDeliveredPointAndFlags);
    runTest("TestPointerInputEventWheelUsesDeliveredScreenPoint", TestPointerInputEventWheelUsesDeliveredScreenPoint);
    runTest("TestContextMenuDebugStateProbeBoundsWedgedWindowThread", TestContextMenuDebugStateProbeBoundsWedgedWindowThread);
    runTest("TestContextMenuDebugCaptureBoundsWedgedWindowThread", TestContextMenuDebugCaptureBoundsWedgedWindowThread);
    runTest("TestContextMenuShowAsyncKeepsOwnerPaintableWhileOpen", TestContextMenuShowAsyncKeepsOwnerPaintableWhileOpen);
    runTest("TestContextMenuRootMinimumWidthUsesAnchorAndAllowsContentExpansion", TestContextMenuRootMinimumWidthUsesAnchorAndAllowsContentExpansion);
    runTest("TestLargeMenuPaintsOnlyVisibleRowsWithCachedOffsets", TestLargeMenuPaintsOnlyVisibleRowsWithCachedOffsets);
    runTest("TestContextMenuShowAsyncSubmenuCloseKeepsSessionAlive", TestContextMenuShowAsyncSubmenuCloseKeepsSessionAlive);
    runTest("TestMenuGraphicalSliderSupportsClickDragAndAnimation", TestMenuGraphicalSliderSupportsClickDragAndAnimation);
    runTest("TestModalMenuDismissesOnSentCancellationAndDeactivation", TestModalMenuDismissesOnSentCancellationAndDeactivation);
    runTest("TestMenuMnemonicHonorsExplicitAmpersandLabels", TestMenuMnemonicHonorsExplicitAmpersandLabels);
    runTest("TestMenuOpeningPointerUpCanBeIgnoredOutsideVisibleSurface", TestMenuOpeningPointerUpCanBeIgnoredOutsideVisibleSurface);
    runTest("TestEmbeddedViewerContextMenuNativeConversionFiltersStandaloneCommands", TestEmbeddedViewerContextMenuNativeConversionFiltersStandaloneCommands);
    runTest("TestMenuShadowMarginMouseUpLightDismissesAfterInitialRelease", TestMenuShadowMarginMouseUpLightDismissesAfterInitialRelease);
    runTest("TestSplitButtonContextMenuSentMouseMessagesHoverAndInvokeImmediately", TestSplitButtonContextMenuSentMouseMessagesHoverAndInvokeImmediately);
    runTest("TestSplitButtonContextMenuOwnerMessageFloodDoesNotStarvePointerInput", TestSplitButtonContextMenuOwnerMessageFloodDoesNotStarvePointerInput);
    runTest("TestMenuKeyboardNavigationSkipsInfoRows", TestMenuKeyboardNavigationSkipsInfoRows);
    runTest("TestMenuKeyboardRightArrowMatchesWindowsMenuLoop", TestMenuKeyboardRightArrowMatchesWindowsMenuLoop);
    runTest("TestStationaryMouseDoesNotOverrideKeyboardRootSwitch", TestStationaryMouseDoesNotOverrideKeyboardRootSwitch);
    runTest("TestMenuPointerOverSiblingRootSwitchesOpenMenu", TestMenuPointerOverSiblingRootSwitchesOpenMenu);
    runTest("TestMenuPopupMouseMoveUsesDeliveredPointForRootSwitch", TestMenuPopupMouseMoveUsesDeliveredPointForRootSwitch);
    runTest("TestMenuOwnerMouseMoveRoutesRootSwitchImmediately", TestMenuOwnerMouseMoveRoutesRootSwitchImmediately);
    runTest("TestMenuBarHoverMessageSwitchesRootWhenCursorOutsidePopup", TestMenuBarHoverMessageSwitchesRootWhenCursorOutsidePopup);
    runTest("TestMenuBarHoverMessageSwitchesRootWhilePopupOverlapsMenuBar", TestMenuBarHoverMessageSwitchesRootWhilePopupOverlapsMenuBar);
    runTest("TestModalMenuLeavesApplicationMessageAtFormerRootHoverValueToItsWindow", TestModalMenuLeavesApplicationMessageAtFormerRootHoverValueToItsWindow);
    runTest("TestMenuRootSwitchUsesDeliveredOwnerMouseMoveAfterPopupSwitch", TestMenuRootSwitchUsesDeliveredOwnerMouseMoveAfterPopupSwitch);
    runTest("TestMenuRootSwitchDoesNotPollCursorWhileIdle", TestMenuRootSwitchDoesNotPollCursorWhileIdle);
    runTest("TestMenuHoveringSiblingClosesOpenSubmenuAfterDelay", TestMenuHoveringSiblingClosesOpenSubmenuAfterDelay);
    runTest("TestMenuHoveringSiblingWithChildrenReplacesOpenSubmenuAfterDelay", TestMenuHoveringSiblingWithChildrenReplacesOpenSubmenuAfterDelay);
    runTest("TestMenuModalLoopPeeksOnlyLivePopupsWhenAPeekClosesASubmenu", TestMenuModalLoopPeeksOnlyLivePopupsWhenAPeekClosesASubmenu);
    runTest("TestMenuPointerInsideSubmenuAndParentItemCancelPendingCloseDelay", TestMenuPointerInsideSubmenuAndParentItemCancelPendingCloseDelay);
    runTest("TestMenuKeyboardTabExitsMenuLoop", TestMenuKeyboardTabExitsMenuLoop);
    runTest("TestMenuKeyboardF10ExitsMenuLoop", TestMenuKeyboardF10ExitsMenuLoop);
    runTest("TestMenuKeyboardAltExitsMenuLoop", TestMenuKeyboardAltExitsMenuLoop);
    runTest("TestMenuKeyboardLeftArrowMatchesWindowsMenuLoop", TestMenuKeyboardLeftArrowMatchesWindowsMenuLoop);
    runTest("TestNativeMenuBarRestoresFocusAfterMenuDismiss", TestNativeMenuBarRestoresFocusAfterMenuDismiss);
    runTest("TestNativeMenuBarNestedPopupCanDestroyHostSafely", TestNativeMenuBarNestedPopupCanDestroyHostSafely);
    runTest("TestMenuInfoRowsDoNotDismissOnClick", TestMenuInfoRowsDoNotDismissOnClick);
    runTest("TestMenuPopupPositionClampsAcrossDpiMatrix", TestMenuPopupPositionClampsAcrossDpiMatrix);
    runTest("TestMenuPopupPositionSupportsRightAlignedRootAnchors", TestMenuPopupPositionSupportsRightAlignedRootAnchors);
    runTest("TestMenuPopupPositionSupportsAboveRightAlignedRootAnchors", TestMenuPopupPositionSupportsAboveRightAlignedRootAnchors);
    runTest("TestMenuInfoRowsUseMeasuredValueColumnWidth", TestMenuInfoRowsUseMeasuredValueColumnWidth);
    runTest("TestMenuStandardRowsDeriveAndAlignShortcutColumnFromTabbedText", TestMenuStandardRowsDeriveAndAlignShortcutColumnFromTabbedText);
    runTest("TestMenuShortcutRowsReserveChevronLaneWhenAnySubmenuExists", TestMenuShortcutRowsReserveChevronLaneWhenAnySubmenuExists);
    runTest("TestMenuBitmapIconsReachPopupLayout", TestMenuBitmapIconsReachPopupLayout);
    runTest("TestMenuPopupMaterialsProduceDistinctCaptures", TestMenuPopupMaterialsProduceDistinctCaptures);
    runTest("TestMenuRainbowHoverUsesSeededHighlightContrast", TestMenuRainbowHoverUsesSeededHighlightContrast);
    runTest("TestMenuHoverContrastAppliesToGlyphsAcrossThemes", TestMenuHoverContrastAppliesToGlyphsAcrossThemes);
    runTest("TestMenuRainbowCheckedItemUsesAccentIndicator", TestMenuRainbowCheckedItemUsesAccentIndicator);
    runTest("TestMenuCheckedRowsDoNotPaintSecondFullRowSelection", TestMenuCheckedRowsDoNotPaintSecondFullRowSelection);
    runTest("TestMenuCheckedRowsDoNotPaintLeadingCheckedBox", TestMenuCheckedRowsDoNotPaintLeadingCheckedBox);
    runTest("TestMenuPopupCompositionHostUsesTransparentShadowMargins", TestMenuPopupCompositionHostUsesTransparentShadowMargins);
    runTest("TestMenuPopupWindowClassDoesNotUseNativeDropShadow", TestMenuPopupWindowClassDoesNotUseNativeDropShadow);
    runTest("TestMenuPopupSubmenuFlipsLeftNearRightEdge", TestMenuPopupSubmenuFlipsLeftNearRightEdge);
    runTest("TestMenuPopupAcrylicLightVisualBaseline", TestMenuPopupAcrylicLightVisualBaseline);
    runTest("TestMenuPopupKeepsSystemBackdropDisabledForAppRenderedMaterials", TestMenuPopupKeepsSystemBackdropDisabledForAppRenderedMaterials);
    runTest("TestMenuAcrylicBackdropScenarioEmitsMetrics", TestMenuAcrylicBackdropScenarioEmitsMetrics);
    runTest("TestSplitButtonContextMenuSentMouseMessagesHoverAndOutsideDismiss", TestSplitButtonContextMenuSentMouseMessagesHoverAndOutsideDismiss);
    runTest("TestContextMenuPopupRelayoutsOnDpiChanged", TestContextMenuPopupRelayoutsOnDpiChanged);
    runTest("TestContextMenuDpiRelayoutConstrainsOversizedContentToWorkArea", TestContextMenuDpiRelayoutConstrainsOversizedContentToWorkArea);
}

// Separate process suite: std::exit deliberately keeps stack-owned windows alive
// while CRT thread-local menu controllers are destroyed. Ordinary scope teardown
// closes the owner first and cannot exercise this lifetime boundary.
void RunMenuExitLifetimeTests()
{
    using namespace DxUi;
    AttachedHostWindow owner;
    const ThemePalette theme = owner.Host().GetTheme();
    std::vector<MenuFlyoutItem> items{
        {.kind = MenuItemKind::Standard, .text = L"Archives", .commandId = 9300},
    };
    bool onClosedCalled = false;
    bool reopened       = false;
    Require(ContextMenu::ShowAsync(owner.Hwnd(),
                                   POINT{100, 100},
                                   items,
                                   theme,
                                   [&](std::optional<int>) noexcept
    {
        onClosedCalled = true;
        reopened       = ContextMenu::ShowAsync(owner.Hwnd(), POINT{100, 100}, items, theme, [](std::optional<int>) noexcept {});
    }),
            "exit lifetime fixture opens an asynchronous menu");
    const HWND popup = WaitForOwnedContextMenuPopupWindowByFirstItemText(owner.Hwnd(), L"Archives");
    Require(popup && GetCapture() == popup, "exit lifetime fixture leaves a live menu owning capture");
    ShutdownAllWindowHostsForProcessExit();
    Require(! onClosedCalled, "process-exit shutdown suppresses async menu close callbacks");
    Require(! reopened, "process-exit shutdown prevents callbacks from reopening async menus");
    Require(IsWindow(popup) == FALSE, "process-exit shutdown destroys the active popup");
    Require(GetCapture() != popup, "process-exit shutdown releases popup capture");
    Require(! ContextMenu::ShowAsync(owner.Hwnd(), POINT{100, 100}, items, theme, [](std::optional<int>) noexcept {}),
            "process-exit shutdown keeps async menus closed through the host sweep");
    std::cerr << "[EXIT] MenuExitLifetime: active menu is dismissed before the process-exit host sweep\n" << std::flush;
    std::exit(0);
}
