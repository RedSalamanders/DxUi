#include "Controls.Tests.DxUiTestHelpers.h"

#include <chrono>
#include <cmath>
#include <fstream>
#include <limits>
#include <memory>
#include <string>
#include <thread>

void RunMenuDescriptionTests();

namespace
{

template <typename TPredicate>
bool WaitForContextMenuPopupState(HWND popupHwnd,
                                  TPredicate&& predicate,
                                  DxUi::ContextMenuPopupDebugState& outState,
                                  std::chrono::milliseconds timeout = std::chrono::milliseconds(800))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (DxUi::DebugGetContextMenuPopupState(popupHwnd, outState) && predicate(outState))
        {
            return true;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return false;
}

HWND FindOwnedContextMenuPopupWindow(HWND ownerHwnd)
{
    HWND popupHwnd = nullptr;
    while ((popupHwnd = FindWindowExW(nullptr, popupHwnd, L"DxUi_ContextMenu", nullptr)) != nullptr)
    {
        if (GetWindow(popupHwnd, GW_OWNER) == ownerHwnd)
        {
            return popupHwnd;
        }
    }

    return nullptr;
}

HWND WaitForOwnedContextMenuPopupWindow(HWND ownerHwnd, std::chrono::milliseconds timeout = std::chrono::milliseconds(800))
{
    const auto deadline = std::chrono::steady_clock::now() + timeout;
    do
    {
        if (HWND popupHwnd = FindOwnedContextMenuPopupWindow(ownerHwnd))
        {
            return popupHwnd;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    } while (std::chrono::steady_clock::now() < deadline);

    return nullptr;
}

[[nodiscard]] D2D1_POINT_2F RectCenter(const D2D1_RECT_F& rect) noexcept
{
    return D2D1::Point2F((rect.left + rect.right) * 0.5f, (rect.top + rect.bottom) * 0.5f);
}

// ---------------------------------------------------------------------------
// Button variant
// ---------------------------------------------------------------------------

void TestButtonVariantDefaultIsStandard()
{
    using namespace DxUi;

    Button button(L"OK");
    Require(button.GetVariant() == ButtonVariant::Standard, "button variant defaults to Standard");
}

void TestButtonVariantRoundtripsAllValues()
{
    using namespace DxUi;

    Button button(L"Action");
    constexpr ButtonVariant variants[] = {
        ButtonVariant::Standard,
        ButtonVariant::DropDown,
        ButtonVariant::Selector,
        ButtonVariant::Split,
        ButtonVariant::Hyperlink,
        ButtonVariant::IconOnly,
        ButtonVariant::Disclosure,
        ButtonVariant::Repeat,
    };

    for (const auto variant : variants)
    {
        button.SetVariant(variant);
        Require(button.GetVariant() == variant, "button variant roundtrips the assigned value");
    }
}

void TestButtonVariantPaintPathsHandleMissingDeviceContext()
{
    using namespace DxUi;

    WindowHost host;
    auto root                          = std::make_unique<Panel>();
    constexpr ButtonVariant variants[] = {
        ButtonVariant::Standard,
        ButtonVariant::DropDown,
        ButtonVariant::Selector,
        ButtonVariant::Split,
        ButtonVariant::Hyperlink,
        ButtonVariant::IconOnly,
        ButtonVariant::Disclosure,
        ButtonVariant::Repeat,
    };

    for (const auto variant : variants)
    {
        auto* button = root->AddChild<Button>(L"Test");
        button->SetBounds(D2D1::RectF(0.0f, 0.0f, 120.0f, 28.0f));
        button->SetVariant(variant);
    }

    host.SetRoot(std::move(root));

    auto children = static_cast<Panel*>(host.GetRoot())->GetChildren();
    for (const auto& child : children)
    {
        child->Paint(host);
    }

    Require(true, "button variant paint paths tolerate a missing device context");
}

void TestButtonDisclosureChevronAnimatesAndHonorsReducedMotion()
{
    using namespace DxUi;

    WindowHost host;
    ThemePalette palette{};
    palette.reducedMotion = false;
    host.SetTheme(palette);

    auto root    = std::make_unique<Panel>();
    auto* button = root->AddChild<Button>();
    button->SetBounds(D2D1::RectF(0.0f, 0.0f, 32.0f, 28.0f));
    button->SetDisclosureExpanded(false);
    host.SetRoot(std::move(root));

    const DisclosureChevronVisualState collapsedVisual = ResolveDisclosureChevronVisualState(button->DebugGetDisclosureAnimationProgress());
    Require(collapsedVisual.direction == ChevronDirection::Right && collapsedVisual.rotationDegrees == 0.0f,
            "collapsed disclosure button starts with a crisp right-facing Fluent chevron");
    Require(button->DebugGetDisclosureAnimationProgress() == 0.0f, "collapsed disclosure button starts at the collapsed animation endpoint");
    const uint64_t animationStart = GetTickCount64();
    button->SetDisclosureExpanded(true);
    Require(button->DebugIsDisclosureAnimationActive(), "disclosure button starts a bounded expand rotation");
    static_cast<void>(button->Tick(host, animationStart));
    Require(button->DebugGetDisclosureAnimationProgress() == 0.0f, "the first tick shows where the rotation starts");
    static_cast<void>(button->Tick(host, animationStart + 100u));
    Require(button->DebugGetDisclosureAnimationProgress() > 0.0f && button->DebugGetDisclosureAnimationProgress() < 1.0f,
            "disclosure button exposes an intermediate right-to-down rotation");
    const DisclosureChevronVisualState intermediateVisual = ResolveDisclosureChevronVisualState(0.5f);
    Require(intermediateVisual.direction == ChevronDirection::Right && intermediateVisual.rotationDegrees == 45.0f,
            "disclosure animation rotates the right glyph clockwise toward down");
    static_cast<void>(button->Tick(host, animationStart + 200u));
    static_cast<void>(button->Tick(host, animationStart + 300u));
    Require(! button->DebugIsDisclosureAnimationActive() && button->DebugGetDisclosureAnimationProgress() == 1.0f,
            "expanded disclosure button completes with its Fluent chevron pointing down");
    const DisclosureChevronVisualState expandedVisual = ResolveDisclosureChevronVisualState(button->DebugGetDisclosureAnimationProgress());
    Require(expandedVisual.direction == ChevronDirection::Down && expandedVisual.rotationDegrees == 0.0f,
            "expanded disclosure button uses the native down glyph without a residual transform");

    const DisclosureChevronVisualState leftCollapsedVisual    = ResolveDisclosureChevronVisualState(0.0f, ChevronDirection::Left);
    const DisclosureChevronVisualState leftIntermediateVisual = ResolveDisclosureChevronVisualState(0.5f, ChevronDirection::Left);
    const DisclosureChevronVisualState leftExpandedVisual     = ResolveDisclosureChevronVisualState(1.0f, ChevronDirection::Left);
    Require(leftCollapsedVisual.direction == ChevronDirection::Left && leftCollapsedVisual.rotationDegrees == 0.0f,
            "trailing-edge disclosures can rest as a crisp left-facing chevron");
    Require(leftIntermediateVisual.direction == ChevronDirection::Left && leftIntermediateVisual.rotationDegrees == -45.0f,
            "trailing-edge disclosures take the short counter-clockwise path from left to down");
    Require(leftExpandedVisual.direction == ChevronDirection::Down && leftExpandedVisual.rotationDegrees == 0.0f,
            "both collapsed orientations converge on the same crisp expanded down glyph");

    const DisclosureChevronVisualState unsupportedCollapsedVisual = ResolveDisclosureChevronVisualState(0.0f, ChevronDirection::Down);
    Require(unsupportedCollapsedVisual.direction == ChevronDirection::Right && unsupportedCollapsedVisual.rotationDegrees == 0.0f,
            "disclosure collapsed direction is constrained to the supported left/right choices");

    palette.reducedMotion = true;
    host.SetTheme(palette);
    button->SetDisclosureExpanded(false);
    Require(! button->DebugIsDisclosureAnimationActive() && button->DebugGetDisclosureAnimationProgress() == 0.0f,
            "reduced motion snaps disclosure chevrons directly to the collapsed state");
}

// A disclosure changed while its panel is hidden receives no animation ticks. When the panel shows again the chevron
// rotates from where it rested, instead of keeping its old orientation or jumping to the end of an elapsed rotation.
void TestButtonDisclosureChevronAnimatesAfterAHiddenChange()
{
    using namespace DxUi;

    WindowHost host;
    ThemePalette palette{};
    palette.reducedMotion = false;
    host.SetTheme(palette);

    auto root    = std::make_unique<Panel>();
    auto* holder = root->AddChild<Panel>();
    auto* button = holder->AddChild<Button>();
    holder->SetBounds(D2D1::RectF(0.0f, 0.0f, 64.0f, 40.0f));
    button->SetBounds(D2D1::RectF(0.0f, 0.0f, 32.0f, 28.0f));
    button->SetDisclosureExpanded(false);
    host.SetRoot(std::move(root));

    holder->SetVisible(false);
    button->SetDisclosureExpanded(true);
    const uint64_t hiddenAt = GetTickCount64();
    static_cast<void>(host.DebugAnimationTickForTest(hiddenAt + 1000u));
    Require(button->DebugGetDisclosureAnimationProgress() == 0.0f, "a disclosure in a hidden panel keeps its chevron at rest");
    Require(! host.DebugHasActiveAnimationSubscription(), "a disclosure in a hidden panel keeps no animation ticking");

    holder->SetVisible(true);
    button->Paint(host); // The next paint resumes the pending rotation's ticks.
    Require(host.DebugHasActiveAnimationSubscription(), "painting the shown button resumes its rotation's ticks");
    const uint64_t shownAt = hiddenAt + 5000u;
    static_cast<void>(button->Tick(host, shownAt));
    Require(button->DebugIsDisclosureAnimationActive() && button->DebugGetDisclosureAnimationProgress() == 0.0f,
            "showing the panel starts the rotation from rest rather than from an elapsed clock");
    static_cast<void>(button->Tick(host, shownAt + 100u));
    Require(button->DebugGetDisclosureAnimationProgress() > 0.0f && button->DebugGetDisclosureAnimationProgress() < 1.0f,
            "the chevron rotates after the panel shows");
    static_cast<void>(button->Tick(host, shownAt + 200u));
    static_cast<void>(button->Tick(host, shownAt + 300u));
    Require(! button->DebugIsDisclosureAnimationActive() && button->DebugGetDisclosureAnimationProgress() == 1.0f,
            "the rotation completes with the chevron pointing down");
}

// Ticks that stop mid-rotation (the button was hidden, or the thread stalled) pause the rotation: the next tick
// resumes it where it was instead of jumping to the end of the time that passed.
void TestButtonDisclosureChevronPausesAcrossATickGap()
{
    using namespace DxUi;

    WindowHost host;
    ThemePalette palette{};
    palette.reducedMotion = false;
    host.SetTheme(palette);
    auto root    = std::make_unique<Panel>();
    auto* button = root->AddChild<Button>();
    button->SetBounds(D2D1::RectF(0.0f, 0.0f, 32.0f, 28.0f));
    button->SetDisclosureExpanded(false);
    host.SetRoot(std::move(root));

    button->SetDisclosureExpanded(true);
    const uint64_t start = GetTickCount64();
    static_cast<void>(button->Tick(host, start));
    static_cast<void>(button->Tick(host, start + 60u));
    const float beforeGap = button->DebugGetDisclosureAnimationProgress();
    Require(beforeGap > 0.0f && beforeGap < 1.0f, "the rotation is under way before the gap");
    static_cast<void>(button->Tick(host, start + 60u + 5000u));
    const float afterGap = button->DebugGetDisclosureAnimationProgress();
    Require(button->DebugIsDisclosureAnimationActive() && afterGap > beforeGap && afterGap < 1.0f,
            "a five-second gap advances the rotation one bounded step, not to its end");
}

void TestButtonChromeLayoutDifferentiatesSelectorDropDownAndSplit()
{
    using namespace DxUi;

    const D2D1_RECT_F bounds = D2D1::RectF(10.0f, 20.0f, 130.0f, 52.0f);

    const ButtonChromeLayout dropDown = ComputeButtonChromeLayout(bounds, ButtonVariant::DropDown, 1.0f);
    Require(dropDown.hasChevron, "drop-down button chrome exposes a chevron slot");
    Require(! dropDown.hasDivider, "drop-down button chrome does not draw a split divider");
    RequireFloatNear(dropDown.chevronRect.left, 110.0f, 0.001f, "drop-down button chrome uses the standard 20-DIP chevron slot");
    RequireFloatNear(dropDown.textRect.right, 110.0f, 0.001f, "drop-down button text ends before the chevron slot");

    const ButtonChromeLayout selector = ComputeButtonChromeLayout(bounds, ButtonVariant::Selector, 1.0f);
    Require(selector.hasChevron, "selector button chrome exposes a chevron slot");
    Require(! selector.hasDivider, "selector button chrome keeps one whole-surface action without a divider");
    RequireFloatNear(selector.chevronRect.left, 106.0f, 0.001f, "selector button chrome uses a relaxed 24-DIP chevron lane");
    RequireFloatNear(selector.textRect.left, 34.0f, 0.001f, "selector button balances the chevron with an equal leading lane");
    RequireFloatNear(selector.textRect.right, 106.0f, 0.001f, "selector button current value ends before the chevron lane");

    const ButtonChromeLayout split = ComputeButtonChromeLayout(bounds, ButtonVariant::Split, 1.0f);
    Require(split.hasChevron, "split button chrome exposes a chevron slot");
    Require(split.hasDivider, "split button chrome draws a split divider");
    RequireFloatNear(split.dividerX, 98.0f, 0.001f, "split button chrome uses the standard 32-DIP drop-down segment");
    RequireFloatNear(split.chevronRect.left, split.dividerX, 0.001f, "split button chevron starts at the divider");

    const ButtonChromeLayout scaledDropDown = ComputeButtonChromeLayout(bounds, ButtonVariant::DropDown, 1.5f);
    RequireFloatNear(scaledDropDown.chevronRect.left, 100.0f, 0.001f, "drop-down chrome scales the chevron slot with DPI");

    const ButtonChromeLayout scaledSelector = ComputeButtonChromeLayout(bounds, ButtonVariant::Selector, 1.5f);
    RequireFloatNear(scaledSelector.chevronRect.left, 94.0f, 0.001f, "selector chrome scales its chevron lane with DPI");
    RequireFloatNear(scaledSelector.textRect.left, 46.0f, 0.001f, "selector chrome keeps its value optically centered at scaled DPI");
}

void TestSelectorButtonChromeUsesStableCurrentValueTreatment()
{
    using namespace DxUi;

    const ThemePalette theme = MakeDefaultThemePalette(true);
    ButtonChromeDrawSpec spec{};
    spec.variant = ButtonVariant::Selector;
    spec.enabled = true;

    const ButtonChromeResolvedStyle idle = ResolveButtonChromeResolvedStyle(theme, spec);
    Require(! idle.showBorder, "selector chrome stays flat at rest instead of looking like a combo box or nested chevron button");
    RequireFloatNear(idle.cornerRadiusDip, 6.0f, 0.001f, "selector chrome uses the shared relaxed corner radius");
    RequireFloatNear(idle.textOffsetXDip, 0.0f, 0.001f, "selector value does not shift horizontally at rest");
    RequireFloatNear(idle.chevron.r, theme.subduedText.r, 0.001f, "selector chevron is quieter than the current value at rest");

    spec.hovered                              = true;
    spec.hoverStrength                        = 0.5f;
    const ButtonChromeResolvedStyle halfHover = ResolveButtonChromeResolvedStyle(theme, spec);
    Require(halfHover.showBorder, "selector hover animation introduces shared button feedback across the whole click target");
    RequireFloatNear(halfHover.chevron.r,
                     theme.subduedText.r + ((halfHover.text.r - theme.subduedText.r) * 0.5f),
                     0.001f,
                     "selector hover animation gradually emphasizes the chevron glyph");

    spec.pressed                            = true;
    const ButtonChromeResolvedStyle pressed = ResolveButtonChromeResolvedStyle(theme, spec);
    RequireFloatNear(pressed.textOffsetXDip, 0.0f, 0.001f, "selector value remains stable while pressed");
    RequireFloatNear(pressed.textOffsetYDip, 0.0f, 0.001f, "selector value does not jump vertically while pressed");
    RequireFloatNear(pressed.chevron.r, pressed.text.r, 0.001f, "selector chevron gains full emphasis while its choices are invoked");
}

void TestButtonChromeCustomStylePreservesOverlayMetrics()
{
    using namespace DxUi;

    ButtonChromeDrawSpec spec{};
    spec.bounds      = D2D1::RectF(10.0f, 12.0f, 110.0f, 44.0f);
    spec.text        = L"Close";
    spec.customStyle = ButtonChromeCustomStyle{
        .fill            = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f),
        .border          = D2D1::ColorF(0.2f, 0.3f, 0.4f, 1.0f),
        .focus           = D2D1::ColorF(0.1f, 0.6f, 0.9f, 1.0f),
        .text            = D2D1::ColorF(0.7f, 0.8f, 0.9f, 1.0f),
        .showFill        = false,
        .showBorder      = true,
        .showFocus       = true,
        .cornerRadiusDip = 6.0f,
        .borderStrokeDip = 1.0f,
        .focusOutsetDip  = 2.0f,
        .focusStrokeDip  = 2.0f,
    };

    const ButtonChromeResolvedStyle resolved = ResolveButtonChromeResolvedStyle(MakeDefaultThemePalette(false), spec);
    Require(! resolved.showFill, "custom overlay button chrome can suppress the fill while preserving a paintable border");
    Require(resolved.showBorder, "custom overlay button chrome keeps the border visible");
    Require(resolved.showFocus, "custom overlay button chrome keeps the focus ring visible");
    RequireFloatNear(resolved.cornerRadiusDip, 6.0f, 0.001f, "custom overlay button chrome preserves the current overlay corner radius");
    RequireFloatNear(resolved.focusOutsetDip, 2.0f, 0.001f, "custom overlay button chrome preserves the current overlay focus outset");
    RequireFloatNear(resolved.focusStrokeDip, 2.0f, 0.001f, "custom overlay button chrome preserves the current overlay focus stroke");
    RequireFloatNear(resolved.text.r, 0.7f, 0.001f, "custom overlay button chrome preserves caller-provided text color");
}

void TestHyperlinkButtonClickInvokesCallback()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* button = root->AddChild<Button>(L"Learn more");
    button->SetBounds(D2D1::RectF(0.0f, 0.0f, 120.0f, 28.0f));
    button->SetVariant(ButtonVariant::Hyperlink);

    size_t clickCount = 0u;
    button->SetOnClick([&] { ++clickCount; });

    host.SetRoot(std::move(root));

    Require(button->OnMouseDown(host, D2D1::Point2F(60.0f, 14.0f), false, 0), "hyperlink button handles mouse-down");
    Require(button->OnMouseUp(host, D2D1::Point2F(60.0f, 14.0f), false, 0), "hyperlink button handles mouse-up");
    Require(clickCount == 1u, "hyperlink button click invokes callback");
}

void TestDropDownButtonKeyboardActivationInvokesDropDownCallback()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* button = root->AddChild<Button>(L"Options");
    button->SetBounds(D2D1::RectF(0.0f, 0.0f, 120.0f, 28.0f));
    button->SetVariant(ButtonVariant::DropDown);

    size_t dropDownOpenCount = 0u;
    button->SetOnDropDownClick([&] { ++dropDownOpenCount; });

    host.SetRoot(std::move(root));

    Require(button->OnKeyDown(host, VK_RETURN, 0), "drop-down button handles Enter activation");
    Require(dropDownOpenCount == 1u, "drop-down button Enter activation opens the drop-down callback");
    Require(button->OnKeyDown(host, VK_SPACE, 0), "drop-down button handles Space activation");
    Require(dropDownOpenCount == 2u, "drop-down button Space activation opens the drop-down callback");
}

void TestSelectorButtonUsesOneWholeSurfaceFlyoutAction()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* button = root->AddChild<Button>(L"Parallel");
    button->SetBounds(D2D1::RectF(0.0f, 0.0f, 120.0f, 28.0f));
    button->SetVariant(ButtonVariant::Selector);

    size_t clickCount  = 0u;
    size_t flyoutCount = 0u;
    button->SetOnClick([&] { ++clickCount; });
    button->SetOnDropDownClick([&] { ++flyoutCount; });
    host.SetRoot(std::move(root));

    Require(button->OnMouseDown(host, D2D1::Point2F(8.0f, 14.0f), false, 0), "selector handles mouse-down on its value area");
    Require(button->OnMouseUp(host, D2D1::Point2F(8.0f, 14.0f), false, 0), "selector handles mouse-up on its value area");
    Require(button->OnMouseDown(host, D2D1::Point2F(112.0f, 14.0f), false, 0), "selector handles mouse-down on its chevron area");
    Require(button->OnMouseUp(host, D2D1::Point2F(112.0f, 14.0f), false, 0), "selector handles mouse-up on its chevron area");
    Require(flyoutCount == 2u, "selector opens the same flyout from both the value and chevron areas");
    Require(clickCount == 0u, "selector never exposes a separate primary button action");
}

void TestButtonSuppressesTooltipThatRepeatsVisibleLabel()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* button = root->AddChild<Button>(L"Clear completed");
    button->SetBounds(D2D1::RectF(0.0f, 0.0f, 140.0f, 32.0f));
    button->SetTooltipText(L"Clear completed");
    host.SetRoot(std::move(root));

    Require(! button->OnMouseMove(host, D2D1::Point2F(70.0f, 16.0f), 0), "button tooltip hover does not consume pointer input");
    Require(! host.HasTooltip(), "button suppresses a tooltip that only repeats its visible label");

    button->SetTooltipText(L"Remove every finished operation from this list");
    Require(! button->OnMouseMove(host, D2D1::Point2F(70.0f, 16.0f), 0), "supplemental button tooltip hover does not consume pointer input");
    Require(host.DebugGetPendingTooltipText() == L"Remove every finished operation from this list",
            "supplemental button tooltip uses the shared delayed-show path");
    static_cast<void>(host.DebugAdvanceTooltipDelayForTest());
    Require(host.GetTooltipText() == L"Remove every finished operation from this list",
            "button retains a tooltip when it provides information beyond the visible label");
}

void TestNonInteractiveControlCanHostSupplementalTooltip()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* region = root->AddChild<Label>();
    region->SetBounds(D2D1::RectF(0.0f, 0.0f, 48.0f, 22.0f));
    region->SetTooltipText(L"Completed with partial results or warnings: 3");
    host.SetRoot(std::move(root));

    Require(! region->OnMouseMove(host, D2D1::Point2F(24.0f, 11.0f), 0), "noninteractive tooltip region does not consume pointer input");
    Require(host.DebugGetPendingTooltipText() == L"Completed with partial results or warnings: 3",
            "noninteractive tooltip region uses the shared delayed-show path");
    static_cast<void>(host.DebugAdvanceTooltipDelayForTest());
    Require(host.GetTooltipText() == L"Completed with partial results or warnings: 3",
            "any retained control can expose supplemental tooltip information without becoming a button");
    Require(! region->OnMouseLeave(host), "noninteractive tooltip region leave does not consume pointer input");
    Require(! host.HasTooltip(), "noninteractive tooltip region clears its tooltip on pointer leave");
}

void TestDropDownButtonMnemonicInvokesDropDownCallback()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* button = root->AddChild<Button>(L"Options");
    button->SetBounds(D2D1::RectF(0.0f, 0.0f, 120.0f, 28.0f));
    button->SetVariant(ButtonVariant::DropDown);

    size_t dropDownOpenCount = 0u;
    button->SetOnDropDownClick([&] { ++dropDownOpenCount; });

    host.SetRoot(std::move(root));

    Require(button->OnMnemonic(host), "drop-down button mnemonic is handled");
    Require(dropDownOpenCount == 1u, "drop-down button mnemonic opens the drop-down callback");
    Require(host.GetFocusControl() == button, "drop-down button mnemonic keeps focus on the button");
}

void TestDropDownButtonCallbackCanReplaceRootSafely()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* button = root->AddChild<Button>(L"Options");
    button->SetBounds(D2D1::RectF(0.0f, 0.0f, 120.0f, 28.0f));
    button->SetVariant(ButtonVariant::DropDown);

    bool dropDownOpened = false;
    button->SetOnDropDownClick([&]
    {
        dropDownOpened = true;
        host.SetRoot(std::make_unique<Panel>());
    });

    host.SetRoot(std::move(root));

    Require(button->OnKeyDown(host, VK_RETURN, 0), "drop-down button handles keyboard activation before replacing the root");
    Require(dropDownOpened, "drop-down callback runs before replacing the root");
    Require(host.GetRoot() != nullptr, "drop-down callback can replace the host root safely");
}

void TestButtonMouseClickReleasesHostCaptureBeforeCallback()
{
    using namespace DxUi;

    AttachedHostWindow window;
    auto root    = std::make_unique<Panel>();
    auto* button = root->AddChild<Button>(L"Open");
    button->SetBounds(D2D1::RectF(0.0f, 0.0f, 120.0f, 28.0f));

    bool callbackInvoked                   = false;
    bool callbackObservedHostStillCaptured = false;
    button->SetOnClick([&]
    {
        callbackInvoked                   = true;
        callbackObservedHostStillCaptured = GetCapture() == window.Hwnd();
    });
    window.Host().SetRoot(std::move(root));

    bool handled = false;
    static_cast<void>(window.Host().HandleMessage(window.Hwnd(), WM_LBUTTONDOWN, MK_LBUTTON, MAKELPARAM(48, 14), handled));
    Require(handled, "button capture handoff test handles the pointer down");
    Require(GetCapture() == window.Hwnd(), "button capture handoff test captures the host during pointer down");

    handled = false;
    static_cast<void>(window.Host().HandleMessage(window.Hwnd(), WM_LBUTTONUP, 0, MAKELPARAM(48, 14), handled));
    Require(handled, "button capture handoff test handles the pointer up");
    Require(callbackInvoked, "button capture handoff test invokes the click callback");
    Require(! callbackObservedHostStillCaptured, "button releases host capture before invoking the click callback");
}

void TestSplitButtonDropDownMouseClickReleasesHostCaptureBeforeCallback()
{
    using namespace DxUi;

    AttachedHostWindow window;
    auto root    = std::make_unique<Panel>();
    auto* button = root->AddChild<Button>(L"Open");
    button->SetBounds(D2D1::RectF(0.0f, 0.0f, 120.0f, 28.0f));
    button->SetVariant(ButtonVariant::Split);

    bool callbackInvoked                   = false;
    bool callbackObservedHostStillCaptured = false;
    button->SetOnDropDownClick([&]
    {
        callbackInvoked                   = true;
        callbackObservedHostStillCaptured = GetCapture() == window.Hwnd();
    });
    window.Host().SetRoot(std::move(root));

    bool handled = false;
    static_cast<void>(window.Host().HandleMessage(window.Hwnd(), WM_LBUTTONDOWN, MK_LBUTTON, MAKELPARAM(108, 14), handled));
    Require(handled, "split-button capture handoff test handles the pointer down");
    Require(GetCapture() == window.Hwnd(), "split-button capture handoff test captures the host during pointer down");

    handled = false;
    static_cast<void>(window.Host().HandleMessage(window.Hwnd(), WM_LBUTTONUP, 0, MAKELPARAM(108, 14), handled));
    Require(handled, "split-button capture handoff test handles the pointer up");
    Require(callbackInvoked, "split-button capture handoff test invokes the drop-down callback");
    Require(! callbackObservedHostStillCaptured, "split button releases host capture before invoking the drop-down callback");
}

void TestButtonMouseLeaveClearsPressedState()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* button = root->AddChild<ExposedButton>(L"Apply");
    button->SetBounds(D2D1::RectF(0.0f, 0.0f, 120.0f, 28.0f));
    host.SetRoot(std::move(root));

    button->SetPressed(true);
    Require(button->IsPressed(), "button test starts pressed");
    button->OnMouseLeave(host);
    Require(! button->IsPressed(), "button mouse-leave clears pressed state");
}

// ---------------------------------------------------------------------------
// Checkbox indeterminate
// ---------------------------------------------------------------------------

void TestCheckboxIndeterminateDefaultIsFalse()
{
    using namespace DxUi;

    Checkbox checkbox(L"Select all");
    Require(! checkbox.IsIndeterminate(), "checkbox indeterminate defaults to false");
}

void TestCheckboxIndeterminateRoundtrips()
{
    using namespace DxUi;

    Checkbox checkbox(L"Select all");
    checkbox.SetIndeterminate(true);
    Require(checkbox.IsIndeterminate(), "checkbox indeterminate roundtrips to true");

    checkbox.SetIndeterminate(false);
    Require(! checkbox.IsIndeterminate(), "checkbox indeterminate roundtrips back to false");
}

void TestCheckboxIndeterminatePaintHandlesMissingDeviceContext()
{
    using namespace DxUi;

    WindowHost host;
    auto root      = std::make_unique<Panel>();
    auto* checkbox = root->AddChild<Checkbox>(L"Select all");
    checkbox->SetBounds(D2D1::RectF(0.0f, 0.0f, 220.0f, 32.0f));
    checkbox->SetIndeterminate(true);
    host.SetRoot(std::move(root));

    checkbox->Paint(host);
    Require(true, "checkbox indeterminate paint path tolerates a missing device context");
}

// ---------------------------------------------------------------------------
// RadioButton + RadioButtons
// ---------------------------------------------------------------------------

void TestRadioButtonsAddItemCreatesChildren()
{
    using namespace DxUi;

    WindowHost host;
    auto root   = std::make_unique<Panel>();
    auto* group = root->AddChild<RadioButtons>();
    group->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 120.0f));

    auto* itemA = group->AddItem(L"Alpha");
    auto* itemB = group->AddItem(L"Beta");
    auto* itemC = group->AddItem(L"Gamma");

    host.SetRoot(std::move(root));

    Require(itemA != nullptr, "radio buttons add-item returns a non-null radio button");
    Require(itemB != nullptr, "radio buttons add-item returns a second non-null radio button");
    Require(itemC != nullptr, "radio buttons add-item returns a third non-null radio button");
    Require(group->GetSelectedIndex() == -1, "radio buttons default selection is -1");
}

void TestRadioButtonsSetSelectedIndexUpdatesState()
{
    using namespace DxUi;

    WindowHost host;
    auto root   = std::make_unique<Panel>();
    auto* group = root->AddChild<RadioButtons>();
    group->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 120.0f));
    group->AddItem(L"Alpha");
    group->AddItem(L"Beta");
    host.SetRoot(std::move(root));

    group->SetSelectedIndex(1);
    Require(group->GetSelectedIndex() == 1, "radio buttons set-selected-index updates the selection");

    group->SetSelectedIndex(0);
    Require(group->GetSelectedIndex() == 0, "radio buttons set-selected-index can change to a different item");
}

void TestRadioButtonClickSelectsAndDeselectsOthers()
{
    using namespace DxUi;

    WindowHost host;
    auto root   = std::make_unique<Panel>();
    auto* group = root->AddChild<RadioButtons>();
    group->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 120.0f));

    auto* itemA = group->AddItem(L"Alpha");
    auto* itemB = group->AddItem(L"Beta");
    itemA->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 32.0f));
    itemB->SetBounds(D2D1::RectF(0.0f, 36.0f, 200.0f, 68.0f));

    int lastSelectedIndex = -1;
    size_t callbackCount  = 0u;
    group->SetOnSelectionChanged([&](int index)
    {
        lastSelectedIndex = index;
        ++callbackCount;
    });

    host.SetRoot(std::move(root));

    Require(itemA->OnMouseDown(host, D2D1::Point2F(16.0f, 16.0f), false, 0), "radio button A handles mouse-down");
    Require(itemA->OnMouseUp(host, D2D1::Point2F(16.0f, 16.0f), false, 0), "radio button A handles mouse-up");
    Require(itemA->IsChecked(), "radio button A is checked after click");
    Require(group->GetSelectedIndex() == 0, "radio buttons group reports index 0 after clicking A");
    Require(callbackCount == 1u, "radio buttons fires one selection-changed callback");
    Require(lastSelectedIndex == 0, "radio buttons callback reports index 0");

    Require(itemB->OnMouseDown(host, D2D1::Point2F(16.0f, 52.0f), false, 0), "radio button B handles mouse-down");
    Require(itemB->OnMouseUp(host, D2D1::Point2F(16.0f, 52.0f), false, 0), "radio button B handles mouse-up");
    Require(itemB->IsChecked(), "radio button B is checked after click");
    Require(! itemA->IsChecked(), "radio button A is deselected after clicking B");
    Require(group->GetSelectedIndex() == 1, "radio buttons group reports index 1 after clicking B");
    Require(callbackCount == 2u, "radio buttons fires two selection-changed callbacks total");
}

void TestRadioButtonSelectionChangedCanReplaceRootSafely()
{
    using namespace DxUi;

    WindowHost host;
    auto root   = std::make_unique<Panel>();
    auto* group = root->AddChild<RadioButtons>();
    group->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 120.0f));

    auto* item = group->AddItem(L"Beta");
    item->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 32.0f));

    size_t selectionChangedCount = 0u;
    size_t itemSelectedCount     = 0u;
    group->SetOnSelectionChanged([&](int)
    {
        ++selectionChangedCount;
        host.SetRoot(std::make_unique<Panel>());
    });
    item->SetOnSelected([&] { ++itemSelectedCount; });

    host.SetRoot(std::move(root));

    Require(item->OnMouseDown(host, D2D1::Point2F(16.0f, 16.0f), false, 0), "radio button handles mouse-down before root replacement");
    Require(item->OnMouseUp(host, D2D1::Point2F(16.0f, 16.0f), false, 0), "radio button survives root replacement during group selection callback");
    Require(selectionChangedCount == 1u, "radio group selection callback ran before replacing the root");
    Require(itemSelectedCount == 0u, "destroyed radio button does not invoke its item-selected callback after root replacement");
    Require(host.GetRoot() != nullptr, "radio group selection callback can replace the host root safely");
}

void TestRadioButtonPaintHandlesMissingDeviceContext()
{
    using namespace DxUi;

    WindowHost host;
    auto root   = std::make_unique<Panel>();
    auto* group = root->AddChild<RadioButtons>();
    group->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 80.0f));
    auto* item = group->AddItem(L"Option");
    item->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 32.0f));
    item->SetChecked(true);
    host.SetRoot(std::move(root));

    group->Paint(host);
    item->Paint(host);
    Require(true, "radio button paint paths tolerate a missing device context");
}

// ---------------------------------------------------------------------------
// ProgressBar
// ---------------------------------------------------------------------------

void TestProgressBarDefaultState()
{
    using namespace DxUi;

    ProgressBar bar;
    RequireFloatNear(static_cast<float>(bar.GetValue()), 0.0f, 0.0001f, "progress bar defaults to value 0");
    RequireFloatNear(static_cast<float>(bar.GetMinimum()), 0.0f, 0.0001f, "progress bar defaults to minimum 0");
    RequireFloatNear(static_cast<float>(bar.GetMaximum()), 100.0f, 0.0001f, "progress bar defaults to maximum 100");
    Require(! bar.IsIndeterminate(), "progress bar defaults to determinate");
}

void TestProgressBarValueRoundtrips()
{
    using namespace DxUi;

    ProgressBar bar;
    bar.SetValue(42.5);
    RequireFloatNear(static_cast<float>(bar.GetValue()), 42.5f, 0.0001f, "progress bar value roundtrips");
}

void TestProgressBarRangeRoundtrips()
{
    using namespace DxUi;

    ProgressBar bar;
    bar.SetMinimum(10.0);
    bar.SetMaximum(200.0);
    RequireFloatNear(static_cast<float>(bar.GetMinimum()), 10.0f, 0.0001f, "progress bar minimum roundtrips");
    RequireFloatNear(static_cast<float>(bar.GetMaximum()), 200.0f, 0.0001f, "progress bar maximum roundtrips");
}

void TestProgressBarIndeterminateRoundtrips()
{
    using namespace DxUi;

    ProgressBar bar;
    bar.SetIndeterminate(true);
    Require(bar.IsIndeterminate(), "progress bar indeterminate roundtrips to true");
    bar.SetIndeterminate(false);
    Require(! bar.IsIndeterminate(), "progress bar indeterminate roundtrips back to false");
}

void TestPageIndicatorDefaultState()
{
    using namespace DxUi;

    PageIndicator indicator;
    Require(indicator.GetPageCount() == 0u, "page indicator defaults to zero pages");
    Require(indicator.GetSelectedIndex() == 0u, "page indicator defaults to selected index 0");
    Require(indicator.GetHitBounds().right <= indicator.GetHitBounds().left, "page indicator is not hittable with zero pages");
}

void TestPageIndicatorPageCountAndSelectionRoundtrip()
{
    using namespace DxUi;

    PageIndicator indicator;
    indicator.SetPageCount(5);
    Require(indicator.GetPageCount() == 5u, "page indicator page count roundtrips");
    indicator.SetSelectedIndex(3);
    Require(indicator.GetSelectedIndex() == 3u, "page indicator selected index roundtrips");
    indicator.SetSelectedIndex(8);
    Require(indicator.GetSelectedIndex() == 4u, "page indicator clamps selected index to the last page");
    indicator.SetPageCount(2);
    Require(indicator.GetSelectedIndex() == 1u, "page indicator clamps selection when page count shrinks");
    indicator.SetPageCount(PageIndicator::kMaximumPages + 4);
    Require(indicator.GetPageCount() == PageIndicator::kMaximumPages, "page indicator caps page count");
}

void TestPageIndicatorClickSelectsPage()
{
    using namespace DxUi;

    WindowHost host;
    auto root       = std::make_unique<Panel>();
    auto* indicator = root->AddChild<PageIndicator>();
    indicator->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, PageIndicator::kStripHeightDip));
    indicator->SetPageCount(4);
    uint32_t selected = UINT32_MAX;
    size_t callbacks  = 0u;
    indicator->SetOnSelected([&](uint32_t index)
    {
        selected = index;
        ++callbacks;
    });
    host.SetRoot(std::move(root));

    const D2D1_POINT_2F third = indicator->DotCenter(2);
    Require(indicator->HitPageIndex(third) == 2u, "page indicator hit-tests the third dot");
    Require(indicator->OnMouseDown(host, third, false, 0), "page indicator handles mouse-down on a dot");
    Require(indicator->OnMouseUp(host, third, false, 0), "page indicator handles mouse-up on a dot");
    Require(indicator->GetSelectedIndex() == 2u, "page indicator selects the clicked page");
    Require(callbacks == 1u && selected == 2u, "page indicator click fires one selection callback");
}

void TestPageIndicatorKeyboardNavigatesAndStopsAtEnds()
{
    using namespace DxUi;

    WindowHost host;
    auto root       = std::make_unique<Panel>();
    auto* indicator = root->AddChild<PageIndicator>();
    indicator->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, PageIndicator::kStripHeightDip));
    indicator->SetPageCount(3);
    uint32_t selected = 0;
    indicator->SetOnSelected([&](uint32_t index) { selected = index; });
    host.SetRoot(std::move(root));

    Require(indicator->OnKeyDown(host, VK_RIGHT, 0), "page indicator handles Right");
    Require(indicator->GetSelectedIndex() == 1u && selected == 1u, "page indicator Right advances one page");
    Require(indicator->OnKeyDown(host, VK_END, 0), "page indicator handles End");
    Require(indicator->GetSelectedIndex() == 2u, "page indicator End selects the last page");
    Require(indicator->OnKeyDown(host, VK_RIGHT, 0), "page indicator consumes Right at the last page");
    Require(indicator->GetSelectedIndex() == 2u, "page indicator does not wrap past the last page");
    Require(indicator->OnKeyDown(host, VK_HOME, 0), "page indicator handles Home");
    Require(indicator->GetSelectedIndex() == 0u, "page indicator Home selects the first page");
    Require(indicator->OnKeyDown(host, VK_LEFT, 0), "page indicator consumes Left at the first page");
    Require(indicator->GetSelectedIndex() == 0u, "page indicator does not wrap before the first page");
}

void TestPageIndicatorSetSelectedIndexDoesNotFireCallback()
{
    using namespace DxUi;

    PageIndicator indicator;
    indicator.SetPageCount(4);
    size_t callbacks = 0u;
    indicator.SetOnSelected([&](uint32_t) { ++callbacks; });
    indicator.SetSelectedIndex(2);
    Require(indicator.GetSelectedIndex() == 2u, "page indicator SetSelectedIndex updates selection");
    Require(callbacks == 0u, "page indicator SetSelectedIndex does not notify OnSelected");
}

void TestPageIndicatorSinglePageIsNotHittable()
{
    using namespace DxUi;

    PageIndicator indicator;
    indicator.SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, PageIndicator::kStripHeightDip));
    indicator.SetPageCount(1);
    Require(indicator.HitPageIndex(D2D1::Point2F(100.0f, 10.0f)) == UINT32_MAX, "a single page has no hittable dots");
    Require(indicator.GetHitBounds().right <= indicator.GetHitBounds().left, "a single page is excluded from hit testing");
}

void TestPageIndicatorPaintHandlesMissingDeviceContext()
{
    using namespace DxUi;

    WindowHost host;
    auto root       = std::make_unique<Panel>();
    auto* indicator = root->AddChild<PageIndicator>();
    indicator->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, PageIndicator::kStripHeightDip));
    indicator->SetPageCount(3);
    indicator->SetSelectedIndex(1);
    host.SetRoot(std::move(root));
    indicator->Paint(host);
    Require(true, "page indicator paint path tolerates a missing device context");
}

void TestPageIndicatorSelectionCallbackCanReplaceRootSafely()
{
    using namespace DxUi;

    WindowHost host;
    auto root       = std::make_unique<Panel>();
    auto* indicator = root->AddChild<PageIndicator>();
    indicator->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, PageIndicator::kStripHeightDip));
    indicator->SetPageCount(3);
    size_t callbacks = 0u;
    indicator->SetOnSelected([&](uint32_t)
    {
        ++callbacks;
        host.SetRoot(std::make_unique<Panel>());
    });
    host.SetRoot(std::move(root));

    const D2D1_POINT_2F second = indicator->DotCenter(1);
    Require(indicator->OnMouseDown(host, second, false, 0), "page indicator handles mouse-down before root replacement");
    Require(indicator->OnMouseUp(host, second, false, 0), "page indicator survives root replacement during selection callback");
    Require(callbacks == 1u, "page indicator selection callback ran before replacing the root");
    Require(host.GetRoot() != nullptr, "page indicator selection callback can replace the host root safely");
}

void TestProgressBarExplicitTrackHeightRoundtrips()
{
    using namespace DxUi;
    ProgressBar bar;
    Require(bar.GetTrackHeightDip() == 0.0f, "progress bar uses its default determinate/indeterminate track heights initially");
    bar.SetTrackHeightDip(10.0f);
    Require(bar.GetTrackHeightDip() == 10.0f, "progress bar accepts an emphasized host-owned track height");
    bar.SetTrackHeightDip(-1.0f);
    Require(bar.GetTrackHeightDip() == 0.0f, "negative progress track height restores the default policy");
}

void TestProgressBarIndeterminateRequestsAnimationWhenAttached()
{
    using namespace DxUi;

    WindowHost host;
    EnableMotionForTest(host);
    auto root = std::make_unique<Panel>();
    auto* bar = root->AddChild<ProgressBar>();
    host.SetRoot(std::move(root));

    bar->SetIndeterminate(true);
    Require(host.DebugHasActiveAnimationSubscription(), "indeterminate progress bar requests animation when attached to a host");
}

void TestProgressBarPaintHandlesMissingDeviceContext()
{
    using namespace DxUi;

    WindowHost host;
    auto root = std::make_unique<Panel>();
    auto* bar = root->AddChild<ProgressBar>();
    bar->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 4.0f));
    bar->SetValue(50.0);
    host.SetRoot(std::move(root));

    bar->Paint(host);
    Require(true, "progress bar determinate paint tolerates a missing device context");

    bar->SetIndeterminate(true);
    bar->Paint(host);
    Require(true, "progress bar indeterminate paint tolerates a missing device context");
}

void TestProgressBarDisabledIndeterminateStateDoesNotAnimateUntilReenabled()
{
    using namespace DxUi;

    WindowHost host;
    EnableMotionForTest(host);
    auto root = std::make_unique<Panel>();
    auto* bar = root->AddChild<ProgressBar>();
    bar->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 6.0f));
    host.SetRoot(std::move(root));

    bar->SetEnabled(false);
    bar->SetIndeterminate(true);
    Require(! host.DebugHasActiveAnimationSubscription(), "disabled indeterminate progress bar does not request animation on state change");
    bar->Paint(host);
    Require(! host.DebugHasActiveAnimationSubscription(), "disabled indeterminate progress bar paint stays idle");
    Require(! bar->Tick(host, 100u), "disabled indeterminate progress bar tick does not continue animation");

    bar->SetEnabled(true);
    bar->Paint(host);
    Require(host.DebugHasActiveAnimationSubscription(), "re-enabled indeterminate progress bar requests animation during paint");
}

void TestProgressBarReducedMotionRestsIndeterminateSegment()
{
    using namespace DxUi;

    WindowHost host;
    ThemePalette theme  = MakeDefaultThemePalette(false);
    theme.reducedMotion = true;
    host.SetTheme(theme);
    auto root = std::make_unique<Panel>();
    auto* bar = root->AddChild<ProgressBar>();
    bar->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 6.0f));
    host.SetRoot(std::move(root));

    bar->SetIndeterminate(true);
    Require(! host.DebugHasActiveAnimationSubscription(), "reduced-motion indeterminate progress bar requests no animation on state change");
    bar->Paint(host);
    Require(! host.DebugHasActiveAnimationSubscription(), "reduced-motion indeterminate progress bar paint stays idle");
    Require(! bar->Tick(host, 1000u) && ! bar->Tick(host, 1500u), "reduced-motion indeterminate progress bar ticks do not animate");

    // Whatever ticks arrive, the segment rests as the centered 40% of the 4 DIP track.
    const D2D1_RECT_F resting = bar->DebugGetIndeterminateSegmentRect(host.GetTheme());
    RequireFloatNear(resting.left, 60.0f, 0.01f, "reduced-motion indeterminate segment starts at 30% of the track");
    RequireFloatNear(resting.right, 140.0f, 0.01f, "reduced-motion indeterminate segment ends at 70% of the track");
    RequireFloatNear(resting.top, 1.0f, 0.01f, "reduced-motion indeterminate segment stays on the centered track");
    RequireFloatNear(resting.bottom, 5.0f, 0.01f, "reduced-motion indeterminate segment keeps the 4 DIP track height");

    theme.reducedMotion = false;
    host.SetTheme(theme);
    bar->Paint(host);
    Require(host.DebugHasActiveAnimationSubscription(), "restored motion requests indeterminate animation during paint");
    Require(bar->Tick(host, 2000u), "restored motion ticks the indeterminate segment again");
}

void TestProgressBarIndeterminateTickSurvivesClockReset()
{
    using namespace DxUi;

    WindowHost host;
    EnableMotionForTest(host);
    auto root = std::make_unique<Panel>();
    auto* bar = root->AddChild<ProgressBar>();
    bar->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 6.0f));
    host.SetRoot(std::move(root));
    bar->SetIndeterminate(true);
    const ThemePalette& theme = host.GetTheme();

    Require(bar->Tick(host, 5'000'000u), "the first tick seeds the indeterminate loop");
    Require(bar->DebugGetIndeterminateSegmentRect(theme).right <= 0.0f, "a seeded loop starts with the segment before the track");
    Require(bar->Tick(host, 5'000'500u), "a quarter loop advances the indeterminate segment");
    RequireFloatNear(bar->DebugGetIndeterminateSegmentRect(theme).right, 70.0f, 0.01f, "a quarter loop shows the segment's leading 70 DIP");

    // A tick clock that restarts behind the previous tick re-seeds instead of wrapping to a huge elapsed time.
    Require(bar->Tick(host, 300u), "a backwards tick keeps the indeterminate loop running");
    RequireFloatNear(bar->DebugGetIndeterminateSegmentRect(theme).right, 70.0f, 0.01f, "a backwards tick leaves the segment in place");
    Require(bar->Tick(host, 800u), "the re-seeded loop advances from the new clock");
    const D2D1_RECT_F centered = bar->DebugGetIndeterminateSegmentRect(theme);
    RequireFloatNear(centered.left, 60.0f, 0.01f, "half a loop centers the segment's leading edge");
    RequireFloatNear(centered.right, 140.0f, 0.01f, "half a loop centers the segment's trailing edge");

    // Whole loops drop out of any gap, however long.
    Require(bar->Tick(host, 800u + (uint64_t{2000u} * 1'000'000'000'000u) + 500u), "a very long gap keeps the loop running");
    const D2D1_RECT_F late = bar->DebugGetIndeterminateSegmentRect(theme);
    RequireFloatNear(late.left, 130.0f, 0.01f, "a very long gap advances only by its remainder");
    RequireFloatNear(late.right, 200.0f, 0.01f, "the segment clips at the end of the track");

    // An empty bar has nothing to sweep and must not keep the frame loop (and a whole-view preparation) alive.
    bar->SetBounds(D2D1::RectF(0.0f, 0.0f, 0.0f, 0.0f));
    Require(! bar->Tick(host, 900'000u), "an empty indeterminate bar requests no further ticks");
    bar->SetBounds(D2D1::RectF(0.0f, 0.0f, 200.0f, 6.0f));
    Require(bar->Tick(host, 901'000u), "the bar ticks again once it has bounds");

    // Like Slider, non-finite values never reach UI Automation.
    bar->SetIndeterminate(false);
    bar->SetMinimum(0.0);
    bar->SetMaximum(100.0);
    bar->SetValue(40.0);
    bar->SetValue(std::numeric_limits<double>::quiet_NaN());
    bar->SetMaximum(std::numeric_limits<double>::infinity());
    bar->SetMinimum(-std::numeric_limits<double>::infinity());
    Require(bar->GetValue() == 40.0 && bar->GetMaximum() == 100.0 && bar->GetMinimum() == 0.0, "a progress bar rejects non-finite values");
}

void TestSliderSmallestStepStillMoves()
{
    using namespace DxUi;

    // "Same target" absorbs floating noise, not a real step: the smallest allowed step must change the value.
    Slider slider;
    slider.SetMinimum(0.0);
    slider.SetMaximum(1.0);
    slider.SetStep(0.0001);
    slider.SetValue(0.3);
    slider.SetValue(0.30009);
    RequireFloatNear(static_cast<float>(slider.GetValue()), 0.30009f, 0.000001f, "a change smaller than the old tolerance is kept for a fine step");
    slider.SetValue(0.30019);
    RequireFloatNear(static_cast<float>(slider.GetValue()), 0.30019f, 0.000001f, "one smallest step moves the value");
}

// ---------------------------------------------------------------------------
// Slider
// ---------------------------------------------------------------------------

void TestSliderDefaultState()
{
    using namespace DxUi;

    Slider slider;
    Require(slider.GetOrientation() == SliderOrientation::Horizontal, "slider defaults to horizontal orientation");
    RequireFloatNear(static_cast<float>(slider.GetMinimum()), 0.0f, 0.0001f, "slider defaults to minimum 0");
    RequireFloatNear(static_cast<float>(slider.GetMaximum()), 100.0f, 0.0001f, "slider defaults to maximum 100");
    RequireFloatNear(static_cast<float>(slider.GetValue()), 0.0f, 0.0001f, "slider defaults to value 0");
    RequireFloatNear(static_cast<float>(slider.GetStep()), 1.0f, 0.0001f, "slider defaults to a unit keyboard step");
    RequireFloatNear(static_cast<float>(slider.GetLargeStep()), 10.0f, 0.0001f, "slider defaults to a page-sized keyboard step");
}

void TestSliderTouchFriendlyGeometry()
{
    using namespace DxUi;

    Slider slider;
    slider.SetBounds(D2D1::RectF(0.0f, 0.0f, 220.0f, 48.0f));
    slider.SetValue(50.0);
    const D2D1_RECT_F track = slider.DebugGetTrackRect();
    const D2D1_RECT_F thumb = slider.DebugGetThumbRect();
    const D2D1_RECT_F halo  = slider.DebugGetHaloRect();
    const D2D1_RECT_F hit   = slider.GetHitBounds();
    RequireFloatNear(track.bottom - track.top, 6.0f, 0.01f, "slider track is 6 DIP thick");
    RequireFloatNear(thumb.right - thumb.left, 14.0f, 0.01f, "slider accent thumb stays clearly visible at rest");
    RequireFloatNear(halo.right - halo.left, 24.0f, 0.01f, "slider chrome disc is 24 DIP");
    Require(track.left >= 11.5f && (220.0f - track.right) >= 11.5f, "slider track insets leave room for the inner thumb");
    RequireFloatNear(hit.bottom - hit.top, 48.0f, 0.01f, "slider pointer band is 48 DIP in a 48 DIP control");
    RequireFloatNear((hit.top + hit.bottom) * 0.5f, 24.0f, 0.01f, "slider pointer band stays centered on the track");
    Require((halo.right - halo.left) + 0.5f < (hit.bottom - hit.top), "painted halo stays smaller than the unpainted fat-finger hit band");
}

void TestSliderTallControlDoesNotHitFarFromTrack()
{
    using namespace DxUi;

    Slider slider;
    slider.SetBounds(D2D1::RectF(0.0f, 0.0f, 220.0f, 120.0f));
    const D2D1_RECT_F hit = slider.GetHitBounds();
    RequireFloatNear(hit.bottom - hit.top, 48.0f, 0.01f, "tall slider keeps a 48 DIP pointer band");
    RequireFloatNear((hit.top + hit.bottom) * 0.5f, 60.0f, 0.01f, "tall slider pointer band stays centered on the track");
    Require(hit.top > 8.0f && hit.bottom < 112.0f, "tall slider leaves padding outside the pointer band");
}

void TestSliderThumbGrabDoesNotSeekWhenContactHitsTouchHalo()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* slider = root->AddChild<Slider>();
    slider->SetBounds(D2D1::RectF(0.0f, 0.0f, 220.0f, 48.0f));
    slider->SetMinimum(0.0);
    slider->SetMaximum(100.0);
    slider->SetValue(50.0);
    host.SetRoot(std::move(root));

    const D2D1_RECT_F thumb    = slider->DebugGetThumbRect();
    const D2D1_POINT_2F center = D2D1::Point2F((thumb.left + thumb.right) * 0.5f, (thumb.top + thumb.bottom) * 0.5f);
    Require(slider->OnMouseDown(host, D2D1::Point2F(center.x + 10.0f, center.y), false, 0), "slider accepts a press on the thumb halo");
    RequireFloatNear(
        static_cast<float>(slider->GetValue()), 50.0f, 0.05f, "a finger-sized contact on the thumb drags from the current value instead of seeking");
    Require(slider->OnMouseUp(host, D2D1::Point2F(center.x + 10.0f, center.y), false, 0), "slider completes the thumb grab");
    RequireFloatNear(static_cast<float>(slider->GetValue()), 50.0f, 0.05f, "releasing a thumb grab without travel keeps the value");

    Require(slider->OnMouseDown(host, D2D1::Point2F(20.0f, center.y), false, 0), "slider accepts a track tap away from the thumb");
    Require(slider->GetValue() < 15.0, "a tap on the track away from the thumb still seeks");
    Require(slider->OnMouseUp(host, D2D1::Point2F(20.0f, center.y), false, 0), "slider completes the track tap");
}

void TestSliderKeyboardAndPointerInputUpdatesValue()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* slider = root->AddChild<Slider>();
    slider->SetBounds(D2D1::RectF(0.0f, 0.0f, 220.0f, 48.0f));
    slider->SetMinimum(0.0);
    slider->SetMaximum(10.0);
    slider->SetValue(5.0);
    slider->SetStep(1.0);
    slider->SetLargeStep(4.0);

    size_t callbackCount = 0u;
    double lastValue     = -1.0;
    slider->SetOnValueChanged([&](double value)
    {
        ++callbackCount;
        lastValue = value;
    });

    host.SetRoot(std::move(root));
    host.SetFocusControl(slider);

    Require(slider->OnKeyDown(host, VK_RIGHT, 0), "slider handles right-arrow input");
    RequireFloatNear(static_cast<float>(slider->GetValue()), 6.0f, 0.0001f, "slider right-arrow advances by the configured step");
    Require(callbackCount == 1u && lastValue == 6.0, "slider right-arrow fires the value-changed callback");

    Require(slider->OnKeyDown(host, VK_PRIOR, 0), "slider handles page-up input");
    RequireFloatNear(static_cast<float>(slider->GetValue()), 10.0f, 0.0001f, "slider page-up clamps to the configured maximum");
    Require(callbackCount == 2u && lastValue == 10.0, "slider page-up fires the value-changed callback");

    Require(slider->OnMouseDown(host, D2D1::Point2F(10.0f, 24.0f), false, 0), "slider handles pointer press");
    Require(slider->OnMouseUp(host, D2D1::Point2F(10.0f, 24.0f), false, 0), "slider handles pointer release");
    RequireFloatNear(static_cast<float>(slider->GetValue()), 0.0f, 0.0001f, "slider pointer input maps the far-left track edge to the minimum value");
    Require(callbackCount >= 3u && lastValue == 0.0, "slider pointer input fires the value-changed callback");
}

void TestSliderVerticalAndRightToLeftGeometryMirrors()
{
    using namespace DxUi;

    Slider horizontal;
    horizontal.SetBounds(D2D1::RectF(0.0f, 0.0f, 220.0f, 32.0f));
    horizontal.SetValue(25.0);
    const D2D1_RECT_F ltrThumbRect = horizontal.DebugGetThumbRect();

    horizontal.SetFlowDirection(FlowDirection::RightToLeft);
    const D2D1_RECT_F rtlThumbRect = horizontal.DebugGetThumbRect();
    Require(((rtlThumbRect.left + rtlThumbRect.right) * 0.5f) > ((ltrThumbRect.left + ltrThumbRect.right) * 0.5f),
            "slider right-to-left flow direction mirrors the horizontal thumb position");

    Slider vertical;
    vertical.SetOrientation(SliderOrientation::Vertical);
    vertical.SetBounds(D2D1::RectF(0.0f, 0.0f, 32.0f, 220.0f));
    vertical.SetValue(75.0);
    const D2D1_RECT_F verticalThumbRect = vertical.DebugGetThumbRect();
    Require(((verticalThumbRect.top + verticalThumbRect.bottom) * 0.5f) < 110.0f, "vertical slider maps higher values toward the top of the track");
}

void TestSliderPaintHandlesMissingDeviceContext()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* slider = root->AddChild<Slider>();
    slider->SetBounds(D2D1::RectF(0.0f, 0.0f, 220.0f, 32.0f));
    slider->SetValue(60.0);
    slider->SetTickMarks({0.0, 25.0, 50.0, 75.0, 100.0});
    host.SetRoot(std::move(root));

    slider->Paint(host);
    Require(true, "slider paint path tolerates a missing device context");
}

void TestSliderSetValueSnapsDisplayedPosition()
{
    using namespace DxUi;

    Slider slider;
    slider.SetBounds(D2D1::RectF(0.0f, 0.0f, 220.0f, 48.0f));
    slider.SetValue(40.0);
    RequireFloatNear(static_cast<float>(slider.DebugGetDisplayedValue()), 40.0f, 0.0001f, "SetValue snaps the painted thumb to the model value");
    slider.SetValue(80.0);
    RequireFloatNear(static_cast<float>(slider.DebugGetDisplayedValue()), 80.0f, 0.0001f, "a later SetValue keeps the painted thumb in lockstep");
}

void TestSliderAcknowledgementStopsPendingAnimation()
{
    using namespace DxUi;
    WindowHost host;
    auto theme          = host.GetTheme();
    theme.reducedMotion = false;
    host.SetTheme(theme);
    auto root    = std::make_unique<Panel>();
    auto* slider = root->AddChild<Slider>();
    slider->SetBounds(D2D1::RectF(0, 0, 220, 48));
    slider->SetValue(20);
    size_t commits = 0;
    slider->SetOnChange([&](SliderChange change) { commits += change.phase == SliderChangePhase::Commit ? 1u : 0u; });
    host.SetRoot(std::move(root));
    Require(slider->RequestValue(host, 80), "accessible or keyboard-style request accepts a new target");
    Require(slider->DebugGetDisplayedValue() < 80, "accepted target initially has a pending visual transition");
    slider->SetValue(80);
    RequireFloatNear(static_cast<float>(slider->DebugGetDisplayedValue()), 80, 0.0001f, "acknowledgement of the same accepted target snaps the painted thumb");
    Require(commits == 1 && ! slider->Tick(host, GetTickCount64() + 500), "silent acknowledgement emits no extra commit and leaves no slider animation work");
}

void TestSliderRejectsNonFiniteRangeAndSteps()
{
    using namespace DxUi;
    Slider slider;
    slider.SetValue(45);
    for (double invalid : {std::numeric_limits<double>::quiet_NaN(), std::numeric_limits<double>::infinity(), -std::numeric_limits<double>::infinity()})
    {
        slider.SetMinimum(invalid);
        slider.SetMaximum(invalid);
        slider.SetStep(invalid);
        slider.SetLargeStep(invalid);
        slider.SetValue(invalid);
        Require(slider.GetMinimum() == 0 && slider.GetMaximum() == 100 && slider.GetStep() == 1 && slider.GetLargeStep() == 10 && slider.GetValue() == 45,
                "invalid scalar input preserves the last usable slider configuration");
    }
    slider.SetMinimum(-std::numeric_limits<double>::max());
    slider.SetMaximum(std::numeric_limits<double>::max());
    Require(slider.GetMaximum() == 100, "overflowing range span is rejected before it can corrupt pointer mapping");
}

void TestSliderRangeAndStepSettersKeepDependentValuesValid()
{
    using namespace DxUi;

    Slider slider;
    slider.SetTickMarks({10.0, 50.0, 90.0});
    slider.SetMinimum(30.0);
    slider.SetMaximum(60.0);
    const std::span<const double> ticks = slider.GetTickMarks();
    Require(ticks.size() == 3u && ticks[0] == 30.0 && ticks[1] == 50.0 && ticks[2] == 60.0,
            "changing the slider range reclamps existing tick marks in sorted order");

    Slider stepFirst;
    stepFirst.SetStep(25.0);
    stepFirst.SetLargeStep(40.0);
    Require(stepFirst.GetLargeStep() >= stepFirst.GetStep(), "setting the small step before the large step preserves large-step ordering");

    Slider largeFirst;
    largeFirst.SetLargeStep(40.0);
    largeFirst.SetStep(25.0);
    Require(largeFirst.GetLargeStep() == stepFirst.GetLargeStep() && largeFirst.GetLargeStep() >= largeFirst.GetStep(),
            "setting the large step before the small step produces the same valid large step");
    largeFirst.SetStep(45.0);
    Require(largeFirst.GetLargeStep() >= largeFirst.GetStep(), "raising the small step keeps the large step at least as large");
}

void TestSliderOffCenterGrabAndCancel()
{
    using namespace DxUi;
    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* slider = root->AddChild<Slider>();
    slider->SetBounds(D2D1::RectF(0, 0, 220, 48));
    slider->SetValue(50);
    size_t commits = 0, cancels = 0;
    slider->SetOnChange([&](SliderChange change)
    {
        commits += change.phase == SliderChangePhase::Commit ? 1u : 0u;
        cancels += change.phase == SliderChangePhase::Cancel ? 1u : 0u;
    });
    host.SetRoot(std::move(root));
    Require(slider->OnMouseDown(host, D2D1::Point2F(118, 40), false, 0), "finger grab accepts offset on both axes");
    Require(slider->GetValue() == 50, "off-center finger grab does not jump the value");
    Require(slider->OnMouseMove(host, D2D1::Point2F(260, 60), 0), "captured drag continues outside slider bounds");
    Require(slider->GetValue() == 100, "captured drag clamps to the endpoint");
    slider->OnCaptureLost(host);
    host.ReleaseMouseCapture();
    Require(! slider->OnMouseUp(host, D2D1::Point2F(260, 60), false, 0) && slider->GetValue() == 50 && commits == 0 && cancels == 1,
            "capture cancellation restores the draft and late release cannot commit it");
}

// ---------------------------------------------------------------------------
// Toolbar
// ---------------------------------------------------------------------------

void TestToolbarAddButtonCreatesChildren()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<Panel>();
    auto* toolbar = root->AddChild<Toolbar>();
    toolbar->SetBounds(D2D1::RectF(0.0f, 0.0f, 320.0f, 40.0f));

    auto* btn = toolbar->AddButton(L"Copy", L"\xE8C8");
    auto* tog = toolbar->AddToggleButton(L"Bold", L"\xE8DD");
    toolbar->AddSeparator();

    host.SetRoot(std::move(root));

    Require(btn != nullptr, "toolbar add-button returns a non-null button");
    Require(tog != nullptr, "toolbar add-toggle-button returns a non-null toggle");
    Require(btn->GetVariant() == ButtonVariant::IconOnly, "toolbar add-button configures icon glyph buttons as icon-only");
    Require(tog->GetVariant() == ButtonVariant::IconOnly, "toolbar add-toggle-button configures icon glyph toggles as icon-only");
}

void TestToolbarButtonHoverShowsTooltip()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<Panel>();
    auto* toolbar = root->AddChild<Toolbar>();
    toolbar->SetBounds(D2D1::RectF(0.0f, 0.0f, 320.0f, 40.0f));

    auto* btn = toolbar->AddButton(L"Copy", L"\xE8C8");
    btn->SetBounds(D2D1::RectF(4.0f, 4.0f, 36.0f, 36.0f));
    host.SetRoot(std::move(root));

    Require(! host.HasTooltip(), "toolbar button hover test starts without an active tooltip");
    Require(! btn->OnMouseMove(host, D2D1::Point2F(20.0f, 20.0f), 0), "toolbar button hover handling does not consume the pointer event");
    Require(host.DebugGetPendingTooltipText() == L"Copy", "toolbar button hover schedules the configured tooltip through the shared delay");
    static_cast<void>(host.DebugAdvanceTooltipDelayForTest());
    Require(host.HasTooltip(), "toolbar button hover shows the configured tooltip");
    Require(host.GetTooltipText() == L"Copy", "toolbar button hover uses the toolbar tooltip text");
    Require(! btn->OnMouseLeave(host), "toolbar button mouse-leave does not need to consume the event");
    Require(! host.HasTooltip(), "toolbar button mouse-leave clears the tooltip");
}

void TestToolbarButtonClickFiresCallback()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<Panel>();
    auto* toolbar = root->AddChild<Toolbar>();
    toolbar->SetBounds(D2D1::RectF(0.0f, 0.0f, 320.0f, 40.0f));

    auto* btn = toolbar->AddButton(L"Copy", L"\xE8C8");
    btn->SetBounds(D2D1::RectF(4.0f, 4.0f, 36.0f, 36.0f));

    size_t clickCount = 0u;
    btn->SetOnClick([&] { ++clickCount; });

    host.SetRoot(std::move(root));

    Require(btn->OnMouseDown(host, D2D1::Point2F(20.0f, 20.0f), false, 0), "toolbar button handles mouse-down");
    Require(btn->OnMouseUp(host, D2D1::Point2F(20.0f, 20.0f), false, 0), "toolbar button handles mouse-up");
    Require(clickCount == 1u, "toolbar button click fires callback");
}

void TestToolbarPaintHandlesMissingDeviceContext()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<Panel>();
    auto* toolbar = root->AddChild<Toolbar>();
    toolbar->SetBounds(D2D1::RectF(0.0f, 0.0f, 320.0f, 40.0f));
    toolbar->AddButton(L"Action", L"\xE710");
    host.SetRoot(std::move(root));

    toolbar->Paint(host);
    Require(true, "toolbar paint path tolerates a missing device context");
}

// ---------------------------------------------------------------------------
// MenuBar
// ---------------------------------------------------------------------------

void TestMenuBarSetItemsRoundtrips()
{
    using namespace DxUi;

    MenuBar menuBar;
    menuBar.SetItems({
        MenuBarItem{.text = L"File", .mnemonic = L'F', .enabled = true},
        MenuBarItem{.text = L"View", .mnemonic = L'V', .enabled = true},
    });

    const auto items = menuBar.GetItems();
    Require(items.size() == 2u, "menu bar reports the configured top-level item count");
    Require(items[0].text == L"File", "menu bar preserves the first top-level label");
    Require(items[1].mnemonic == L'V', "menu bar preserves the configured mnemonic");
}

void TestMenuBarClickInvokesOpenCallback()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<MenuBar>();
    auto* menuBar = root.get();
    menuBar->SetItems({
        MenuBarItem{.text = L"File", .mnemonic = L'F', .enabled = true},
        MenuBarItem{.text = L"Edit", .mnemonic = L'E', .enabled = true},
    });

    size_t openedIndex = std::numeric_limits<size_t>::max();
    POINT openedPoint{};
    bool keyboardInvoke = true;
    menuBar->SetOnOpenItem([&](size_t index, POINT screenPoint, bool keyboardInvocation)
    {
        openedIndex    = index;
        openedPoint    = screenPoint;
        keyboardInvoke = keyboardInvocation;
    });
    host.SetRoot(std::move(root));
    menuBar->SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 32.0f));

    Require(menuBar->OnMouseMove(host, D2D1::Point2F(18.0f, 16.0f), 0), "menu bar hover updates the active top-level item");
    Require(menuBar->OnMouseDown(host, D2D1::Point2F(18.0f, 16.0f), false, 0), "menu bar handles left-button down on the first item");
    Require(menuBar->OnMouseUp(host, D2D1::Point2F(18.0f, 16.0f), false, 0), "menu bar handles left-button up on the pressed item");
    Require(openedIndex == 0u, "menu bar click opens the matching top-level menu");
    Require(! keyboardInvoke, "menu bar mouse click reports pointer invocation");
    Require(openedPoint.y >= 28, "menu bar click anchors the popup from the bottom edge of the active item");
}

void TestMenuBarHoverMoveCallbackCanRetireRoot()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<Panel>();
    auto* menuBar = root->AddChild<MenuBar>();
    menuBar->SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 32.0f));
    menuBar->SetItems({MenuBarItem{.text = L"File", .mnemonic = L'F', .enabled = true}});
    host.SetRoot(std::move(root));

    auto callbackText = std::make_shared<std::wstring>(L"menu move survives root retirement");
    std::wstring captureAfterRetirement;
    std::optional<size_t> hoveredAfterRetirement;
    size_t callbackCount = 0u;
    menuBar->SetOnHoverChanged([&, callbackText = std::move(callbackText)](std::optional<size_t> index)
    {
        ++callbackCount;
        host.SetRoot(std::make_unique<Panel>());
        hoveredAfterRetirement = index;
        captureAfterRetirement = *callbackText;
    });

    Require(menuBar->OnMouseMove(host, D2D1::Point2F(12.0f, 12.0f), 0u), "MenuBar handles the logical hover move");
    Require(callbackCount == 1u && hoveredAfterRetirement == 0u, "MenuBar reports the hovered item before root retirement");
    Require(captureAfterRetirement == L"menu move survives root retirement", "the hover-move callback capture remains readable after root retirement");
    Require(host.GetRoot() != nullptr, "the replacement root survives the MenuBar hover-move callback");
}

void TestMenuBarHoverLeaveCallbackCanRetireRoot()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<Panel>();
    auto* menuBar = root->AddChild<MenuBar>();
    menuBar->SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 32.0f));
    menuBar->SetItems({MenuBarItem{.text = L"File", .mnemonic = L'F', .enabled = true}});
    host.SetRoot(std::move(root));
    Require(menuBar->OnMouseMove(host, D2D1::Point2F(12.0f, 12.0f), 0u), "MenuBar starts hovered before the leave callback is installed");

    auto callbackText = std::make_shared<std::wstring>(L"menu leave survives root retirement");
    std::wstring captureAfterRetirement;
    bool reportedClear   = false;
    size_t callbackCount = 0u;
    menuBar->SetOnHoverChanged([&, callbackText = std::move(callbackText)](std::optional<size_t> index)
    {
        ++callbackCount;
        reportedClear = ! index.has_value();
        host.SetRoot(std::make_unique<Panel>());
        captureAfterRetirement = *callbackText;
    });

    Require(menuBar->OnMouseLeave(host), "MenuBar handles the logical hover leave");
    Require(callbackCount == 1u && reportedClear, "MenuBar reports cleared hover before root retirement");
    Require(captureAfterRetirement == L"menu leave survives root retirement", "the hover-leave callback capture remains readable after root retirement");
    Require(host.GetRoot() != nullptr, "the replacement root survives the MenuBar hover-leave callback");
}

void TestMenuBarHoverCallbackCanReplaceItself()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<Panel>();
    auto* menuBar = root->AddChild<MenuBar>();
    menuBar->SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 32.0f));
    menuBar->SetItems({MenuBarItem{.text = L"File", .mnemonic = L'F', .enabled = true}});
    host.SetRoot(std::move(root));

    auto callbackText = std::make_shared<std::wstring>(L"menu callback survives replacement");
    std::wstring captureAfterReplacement;
    size_t originalCount    = 0u;
    size_t replacementCount = 0u;
    menuBar->SetOnHoverChanged([&, callbackText = std::move(callbackText)](std::optional<size_t>)
    {
        ++originalCount;
        menuBar->SetOnHoverChanged([&](std::optional<size_t>) { ++replacementCount; });
        captureAfterReplacement = *callbackText;
    });

    Require(menuBar->OnMouseMove(host, D2D1::Point2F(12.0f, 12.0f), 0u), "MenuBar delivers the first hover change");
    Require(originalCount == 1u, "the original MenuBar hover callback runs once before replacing itself");
    Require(captureAfterReplacement == L"menu callback survives replacement", "the hover callback capture remains readable after self-replacement");
    Require(menuBar->OnMouseLeave(host), "MenuBar delivers the hover leave to the replacement callback");
    Require(replacementCount == 1u, "the replacement MenuBar hover callback remains installed");
}

void TestMenuBarMouseOpenReleasesHostCaptureBeforeCallback()
{
    using namespace DxUi;

    AttachedHostWindow window;
    auto root     = std::make_unique<MenuBar>();
    auto* menuBar = root.get();
    menuBar->SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 32.0f));
    menuBar->SetItems({
        MenuBarItem{.text = L"View", .mnemonic = L'V', .enabled = true},
        MenuBarItem{.text = L"Plugins", .mnemonic = L'P', .enabled = true},
    });

    bool callbackInvoked                   = false;
    bool callbackObservedHostStillCaptured = false;
    menuBar->SetOnOpenItem([&](size_t, POINT, bool)
    {
        callbackInvoked                   = true;
        callbackObservedHostStillCaptured = GetCapture() == window.Hwnd();
    });
    window.Host().SetRoot(std::move(root));

    bool handled = false;
    static_cast<void>(window.Host().HandleMessage(window.Hwnd(), WM_LBUTTONDOWN, MK_LBUTTON, MAKELPARAM(24, 16), handled));
    Require(handled, "menu bar mouse-open capture test handles the pointer down");
    Require(GetCapture() == window.Hwnd(), "menu bar mouse-open capture test captures the host during pointer down");

    handled = false;
    static_cast<void>(window.Host().HandleMessage(window.Hwnd(), WM_LBUTTONUP, 0, MAKELPARAM(24, 16), handled));
    Require(handled, "menu bar mouse-open capture test handles the pointer up");
    Require(callbackInvoked, "menu bar mouse-open capture test invokes the open callback");
    Require(! callbackObservedHostStillCaptured, "menu bar releases host capture before opening the modal popup");
}

void TestMenuBarKeyboardNavigationOpensSelectedItem()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<MenuBar>();
    auto* menuBar = root.get();
    menuBar->SetItems({
        MenuBarItem{.text = L"File", .mnemonic = L'F', .enabled = true},
        MenuBarItem{.text = L"Edit", .mnemonic = L'E', .enabled = true},
        MenuBarItem{.text = L"View", .mnemonic = L'V', .enabled = true},
    });

    size_t openedIndex  = std::numeric_limits<size_t>::max();
    bool keyboardInvoke = false;
    menuBar->SetOnOpenItem([&](size_t index, POINT, bool keyboardInvocation)
    {
        openedIndex    = index;
        keyboardInvoke = keyboardInvocation;
    });
    host.SetRoot(std::move(root));
    menuBar->SetBounds(D2D1::RectF(0.0f, 0.0f, 320.0f, 32.0f));

    host.SetFocusControl(menuBar);
    Require(menuBar->OnKeyDown(host, VK_RIGHT, 0), "menu bar handles right-arrow navigation");
    Require(menuBar->GetSelectedIndex().has_value() && menuBar->GetSelectedIndex().value() == 1u, "menu bar right-arrow advances the selected top-level menu");
    Require(menuBar->OnKeyDown(host, VK_RETURN, 0), "menu bar handles Enter on the selected top-level menu");
    Require(openedIndex == 1u, "menu bar Enter opens the selected top-level menu");
    Require(keyboardInvoke, "menu bar keyboard activation reports keyboard invocation");
}

void TestMenuBarMnemonicOpensMatchingItem()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<MenuBar>();
    auto* menuBar = root.get();
    menuBar->SetItems({
        MenuBarItem{.text = L"File", .mnemonic = L'F', .enabled = true},
        MenuBarItem{.text = L"Help", .mnemonic = L'H', .enabled = true},
    });

    size_t openedIndex = std::numeric_limits<size_t>::max();
    menuBar->SetOnOpenItem([&](size_t index, POINT, bool) { openedIndex = index; });
    host.SetRoot(std::move(root));
    menuBar->SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 32.0f));

    Require(menuBar->ActivateMnemonic(host, L'h'), "menu bar activates the matching top-level item by mnemonic");
    Require(openedIndex == 1u, "menu bar mnemonic opens the expected top-level menu");
}

void TestFlowDirectionInheritanceRoundtrips()
{
    using namespace DxUi;

    Panel root;
    auto* child = root.AddChild<Button>(L"Child");

    root.SetFlowDirection(FlowDirection::RightToLeft);
    Require(child->GetFlowDirection() == FlowDirection::RightToLeft, "child control inherits right-to-left flow direction from its parent");

    child->SetFlowDirection(FlowDirection::LeftToRight);
    Require(child->HasExplicitFlowDirection(), "child control records explicit flow direction overrides");
    Require(child->GetFlowDirection() == FlowDirection::LeftToRight, "child control can override inherited flow direction");

    child->ClearFlowDirection();
    Require(! child->HasExplicitFlowDirection(), "child control clears explicit flow direction overrides");
    Require(child->GetFlowDirection() == FlowDirection::RightToLeft, "child control falls back to inherited flow direction after clearing the override");
}

void TestHorizontalStackPanelRelayoutsWhenFlowDirectionChanges()
{
    using namespace DxUi;

    StackPanel stack;
    stack.SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 40.0f));
    stack.SetOrientation(StackOrientation::Horizontal);
    stack.SetGap(8.0f);

    auto* first  = stack.AddChild<Button>(L"One");
    auto* second = stack.AddChild<Button>(L"Two");
    stack.SetChildExtent(first, 70.0f);
    stack.SetChildExtent(second, 90.0f);
    stack.ApplyLayout();

    const D2D1_RECT_F ltrFirstRect  = first->GetBounds();
    const D2D1_RECT_F ltrSecondRect = second->GetBounds();
    Require(ltrFirstRect.left < ltrSecondRect.left, "horizontal stack panel lays out left-to-right by default");

    stack.SetFlowDirection(FlowDirection::RightToLeft);
    const D2D1_RECT_F rtlFirstRect  = first->GetBounds();
    const D2D1_RECT_F rtlSecondRect = second->GetBounds();
    Require(rtlFirstRect.left > rtlSecondRect.left, "horizontal stack panel mirrors child order when switched to right-to-left flow direction");
}

void TestMenuBarRightToLeftMirrorsItemOrderAndArrowKeys()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<MenuBar>();
    auto* menuBar = root.get();
    menuBar->SetItems({
        MenuBarItem{.text = L"File", .mnemonic = L'F', .enabled = true},
        MenuBarItem{.text = L"Edit", .mnemonic = L'E', .enabled = true},
        MenuBarItem{.text = L"View", .mnemonic = L'V', .enabled = true},
    });
    host.SetRoot(std::move(root));
    menuBar->SetBounds(D2D1::RectF(0.0f, 0.0f, 320.0f, 32.0f));
    menuBar->SetFlowDirection(FlowDirection::RightToLeft);
    menuBar->SetSelectedIndex(1u);

    RECT fileRect{};
    RECT editRect{};
    Require(menuBar->TryGetItemScreenRect(host, 0u, fileRect), "right-to-left menu bar exposes the first item rect");
    Require(menuBar->TryGetItemScreenRect(host, 1u, editRect), "right-to-left menu bar exposes the second item rect");
    Require(fileRect.left > editRect.left, "right-to-left menu bar places the first item visually to the right of the next item");

    Require(menuBar->OnKeyDown(host, VK_RIGHT, 0), "right-to-left menu bar handles right-arrow navigation");
    Require(menuBar->GetSelectedIndex().has_value() && menuBar->GetSelectedIndex().value() == 0u,
            "right-to-left menu bar right-arrow moves to the visually previous top-level item");
    Require(menuBar->OnKeyDown(host, VK_LEFT, 0), "right-to-left menu bar handles left-arrow navigation");
    Require(menuBar->GetSelectedIndex().has_value() && menuBar->GetSelectedIndex().value() == 1u,
            "right-to-left menu bar left-arrow moves to the visually next top-level item");
}

void TestMenuBarCompactDensityKeepsUsableItemHeight()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<MenuBar>();
    auto* menuBar = root.get();
    menuBar->SetItems({
        MenuBarItem{.text = L"Plugins", .mnemonic = L'P', .enabled = true},
        MenuBarItem{.text = L"View", .mnemonic = L'V', .enabled = true},
    });
    host.SetRoot(std::move(root));

    ThemePalette theme = MakeDefaultThemePalette(true);
    theme.density      = Density::Compact;
    host.SetTheme(theme);

    menuBar->SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 24.0f));

    Require(ResolveMenuBarFontRole(theme) == FontRole::Small,
            "compact menu bar uses the shared small-font contract to preserve descenders inside the shared 24 DIP height");
    RECT pluginsRect{};
    Require(menuBar->TryGetItemScreenRect(host, 0u, pluginsRect), "compact menu bar exposes the first item rect");
    Require((pluginsRect.bottom - pluginsRect.top) >= 18, "compact menu bar keeps enough vertical room for descenders inside the shared 24 DIP height");
}

// ---------------------------------------------------------------------------
// TabControl
// ---------------------------------------------------------------------------

void TestTabControlSelectionShowsOnlyTheActivePage()
{
    using namespace DxUi;

    WindowHost host;
    auto root        = std::make_unique<Panel>();
    auto* tabControl = root->AddChild<TabControl>();
    tabControl->SetBounds(D2D1::RectF(0.0f, 0.0f, 360.0f, 200.0f));

    auto* firstPage  = tabControl->AddTab<Label>(L"Home", L"First page");
    auto* secondPage = tabControl->AddTab<Label>(L"View", L"Second page");
    host.SetRoot(std::move(root));

    Require(tabControl->GetSelectedIndex().has_value() && tabControl->GetSelectedIndex().value() == 0u, "tab control selects the first added tab by default");
    Require(tabControl->GetSelectedPage() == firstPage, "tab control returns the first page as the selected page");
    Require(firstPage->IsVisible() && ! secondPage->IsVisible(), "tab control only shows the selected page");

    tabControl->SetSelectedIndex(1u);
    Require(tabControl->GetSelectedPage() == secondPage, "tab control updates the selected page when the selected index changes");
    Require(! firstPage->IsVisible() && secondPage->IsVisible(), "tab control hides the old page and shows the newly selected page");
    Require(secondPage->GetBounds().top > tabControl->GetBounds().top, "tab control places the selected page below the header strip");
}

void TestTabControlHiddenTabsKeepStableIndicesAndLeaveTheHeader()
{
    using namespace DxUi;

    WindowHost host;
    auto root        = std::make_unique<Panel>();
    auto* tabControl = root->AddChild<TabControl>();
    tabControl->SetBounds(D2D1::RectF(0.0f, 0.0f, 360.0f, 200.0f));

    auto* folderPage   = tabControl->AddTab<Label>(L"Folder", L"Folder page");
    auto* previewPage  = tabControl->AddTab<Label>(L"Preview", L"Preview page");
    auto* terminalPage = tabControl->AddTab<Label>(L"Terminal", L"Terminal page");
    tabControl->SetTabClosable(1u, true);
    tabControl->SetTabClosable(2u, true);
    host.SetRoot(std::move(root));

    tabControl->SetTabVisible(1u, false);
    const auto hasArea = [](const D2D1_RECT_F& rect) noexcept { return rect.right > rect.left && rect.bottom > rect.top; };
    Require(tabControl->GetTabCount() == 3u && tabControl->GetVisibleTabCount() == 2u,
            "hiding a tab preserves stable model indices while reducing the visible header count");
    Require(! tabControl->IsTabVisible(1u) && tabControl->IsTabVisible(2u), "tab visibility is reported by stable model index");
    Require(! hasArea(tabControl->DebugGetTabRect(1u)) && hasArea(tabControl->DebugGetTabRect(2u)),
            "a hidden tab has no interactive header geometry while later visible tabs retain geometry");
    Require(! previewPage->IsVisible(), "a hidden tab page cannot remain visible");

    tabControl->SetSelectedIndex(2u);
    Require(tabControl->GetSelectedPage() == terminalPage && terminalPage->IsVisible() && ! folderPage->IsVisible(),
            "a visible tab after a hidden stable index remains directly selectable");
    Require(tabControl->OnKeyDown(host, VK_LEFT, 0), "keyboard navigation handles a visible set containing a hidden tab");
    Require(tabControl->GetSelectedIndex().has_value() && tabControl->GetSelectedIndex().value() == 0u, "keyboard navigation skips a hidden tab");

    tabControl->SetTabVisible(0u, false);
    Require(tabControl->GetSelectedIndex().has_value() && tabControl->GetSelectedIndex().value() == 2u && terminalPage->IsVisible(),
            "hiding the selected tab falls back to another visible stable index");

    tabControl->RemoveTab(2u);
    Require(! tabControl->GetSelectedIndex().has_value() && tabControl->GetSelectedPage() == nullptr,
            "removing the last visible tab clears selection instead of selecting a hidden page");

    auto* searchPage = tabControl->AddTab<Label>(L"Search", L"Search page");
    Require(tabControl->GetSelectedIndex().has_value() && tabControl->GetSelectedIndex().value() == 2u && tabControl->GetSelectedPage() == searchPage,
            "adding a visible tab after hidden pages selects the new stable index");
}

void TestTabControlCloseButtonRemovesTabsAndInvokesCallback()
{
    using namespace DxUi;

    WindowHost host;
    auto root        = std::make_unique<Panel>();
    auto* tabControl = root->AddChild<TabControl>();
    tabControl->SetBounds(D2D1::RectF(0.0f, 0.0f, 360.0f, 200.0f));
    tabControl->AddTab<Label>(L"Home", L"Page 0");
    tabControl->AddTab<Label>(L"View", L"Page 1");
    tabControl->AddTab<Label>(L"Help", L"Page 2");
    tabControl->SetTabClosable(1u, true);
    tabControl->SetSelectedIndex(1u);

    size_t closedIndex = std::numeric_limits<size_t>::max();
    size_t closeCount  = 0u;
    tabControl->SetOnTabClosed([&](size_t index)
    {
        closedIndex = index;
        ++closeCount;
    });

    host.SetRoot(std::move(root));

    const D2D1_RECT_F closeRect = tabControl->DebugGetCloseButtonRect(1u);
    RequireRectHasArea(closeRect, "tab control exposes close button geometry for closable tabs");
    const D2D1_POINT_2F closePoint = RectCenter(closeRect);

    Require(tabControl->OnMouseDown(host, closePoint, false, 0), "tab control handles close-button press");
    Require(tabControl->OnMouseUp(host, closePoint, false, 0), "tab control handles close-button release");
    Require(closeCount == 1u && closedIndex == 1u, "tab control invokes the close callback with the closed tab index");
    Require(tabControl->GetTabCount() == 2u, "tab control removes the closed tab");
}

void TestTabControlRemoveResolvesRequestedPageAfterFocusCallbackReordersSiblings()
{
    using namespace DxUi;

    WindowHost host;
    auto root                               = std::make_unique<Panel>();
    auto* tabControl                        = root->AddChild<TabControl>();
    auto* firstPage                         = tabControl->AddTab<Label>(L"First", L"First page");
    auto* targetPage                        = tabControl->AddTab<Panel>(L"Target");
    auto* focus                             = targetPage->AddChild<Button>(L"Focused child");
    auto* lastPage                          = tabControl->AddTab<Label>(L"Last", L"Last page");
    const std::weak_ptr<int> targetLifetime = GetControlLifetimeToken(*targetPage);
    host.SetRoot(std::move(root));
    tabControl->SetSelectedIndex(1u);
    host.SetFocusControl(focus);

    bool siblingRemoved = false;
    host.SetOnFocusChanged([&](Control* focused)
    {
        if (focused == tabControl && ! siblingRemoved)
        {
            siblingRemoved = true;
            tabControl->RemoveTab(0u);
        }
    });

    tabControl->RemoveTab(1u);

    Require(siblingRemoved, "removing a focused page allows the focus callback to change sibling indices");
    Require(tabControl->GetTabCount() == 1u && tabControl->GetTabTitle(0u) == L"Last" && tabControl->GetSelectedPage() == lastPage,
            "RemoveTab removes the originally requested page after its index shifts");
    Require(firstPage != lastPage && targetLifetime.expired(), "removal destroys the originally requested page after preserving the surviving sibling");
}

void TestTabControlSelectionReportsResolvedIndexAfterFocusCallbackRemovesSibling()
{
    using namespace DxUi;

    WindowHost host;
    auto root        = std::make_unique<Panel>();
    auto* tabControl = root->AddChild<TabControl>();
    auto* firstPage  = tabControl->AddTab<Panel>(L"First");
    auto* focus      = firstPage->AddChild<Button>(L"Focused child");
    auto* targetPage = tabControl->AddTab<Label>(L"Target", L"Target page");
    tabControl->AddTab<Label>(L"Last", L"Last page");
    host.SetRoot(std::move(root));
    host.SetFocusControl(focus);

    bool siblingRemoved  = false;
    size_t notifiedIndex = std::numeric_limits<size_t>::max();
    tabControl->SetOnSelectionChanged([&](size_t index) { notifiedIndex = index; });
    host.SetOnFocusChanged([&](Control* focused)
    {
        if (focused == tabControl && ! siblingRemoved)
        {
            siblingRemoved = true;
            tabControl->RemoveTab(0u);
        }
    });

    Require(tabControl->OnKeyDown(host, VK_RIGHT, 0u), "keyboard selection handles moving to the next tab");

    Require(siblingRemoved, "selection focus callback removes a sibling before selection notification");
    Require(tabControl->GetSelectedIndex() == 0u && tabControl->GetSelectedPage() == targetPage,
            "selection remains attached to the requested page after its index shifts");
    Require(notifiedIndex == 0u, "selection callback receives the requested page's current index");
}

void TestTabControlCloseReportsResolvedIndexAfterCloseCallbackRemovesSibling()
{
    using namespace DxUi;

    WindowHost host;
    auto root        = std::make_unique<Panel>();
    auto* tabControl = root->AddChild<TabControl>();
    tabControl->SetBounds(D2D1::RectF(0.0f, 0.0f, 360.0f, 200.0f));
    tabControl->AddTab<Label>(L"First", L"First page");
    auto* targetPage                        = tabControl->AddTab<Label>(L"Target", L"Target page");
    auto* lastPage                          = tabControl->AddTab<Label>(L"Last", L"Last page");
    const std::weak_ptr<int> targetLifetime = GetControlLifetimeToken(*targetPage);
    tabControl->SetTabClosable(1u, true);
    tabControl->SetSelectedIndex(1u);
    host.SetRoot(std::move(root));

    bool siblingRemoved   = false;
    size_t requestedIndex = std::numeric_limits<size_t>::max();
    size_t closedIndex    = std::numeric_limits<size_t>::max();
    tabControl->SetOnTabCloseRequested([&](size_t index)
    {
        requestedIndex = index;
        siblingRemoved = true;
        tabControl->RemoveTab(0u);
        return false;
    });
    tabControl->SetOnTabClosed([&](size_t index) { closedIndex = index; });

    const D2D1_POINT_2F closePoint = RectCenter(tabControl->DebugGetCloseButtonRect(1u));
    Require(tabControl->OnMouseDown(host, closePoint, false, 0u), "tab control handles close press before callback mutation");
    Require(tabControl->OnMouseUp(host, closePoint, false, 0u), "tab control handles close release after callback mutation");

    Require(siblingRemoved && tabControl->GetTabCount() == 1u && tabControl->GetSelectedPage() == lastPage,
            "closing a tab removes the original page even when the request callback shifts its index");
    Require(targetLifetime.expired() && requestedIndex == 1u && closedIndex == 0u, "close callbacks report request-time and resolved target indices");
}

void TestTabControlOverflowButtonsAndWheelScroll()
{
    using namespace DxUi;

    WindowHost host;
    auto root        = std::make_unique<Panel>();
    auto* tabControl = root->AddChild<TabControl>();
    tabControl->SetBounds(D2D1::RectF(0.0f, 0.0f, 220.0f, 180.0f));

    for (size_t index = 0u; index < 7u; ++index)
    {
        tabControl->AddTab<Label>(std::format(L"Long tab {}", index), std::format(L"Page {}", index));
    }

    host.SetRoot(std::move(root));

    Require(tabControl->DebugHasOverflowButtons(), "tab control shows overflow buttons when the header strip is narrower than the total tab width");
    const float initialOffset = tabControl->DebugGetHeaderScrollOffsetDip();
    Require(tabControl->OnMouseWheel(host, D2D1::Point2F(40.0f, 16.0f), -static_cast<float>(WHEEL_DELTA), 0),
            "tab control handles mouse-wheel scrolling over the header strip");
    Require(tabControl->DebugGetHeaderScrollOffsetDip() > initialOffset, "tab control wheel scrolling advances the header scroll offset");

    const float offsetAfterWheel = tabControl->DebugGetHeaderScrollOffsetDip();
    const D2D1_RECT_F backRect   = tabControl->DebugGetBackButtonRect();
    RequireRectHasArea(backRect, "tab control exposes the back overflow button geometry");
    Require(tabControl->OnMouseDown(host, RectCenter(backRect), false, 0), "tab control handles back-button press");
    Require(tabControl->DebugGetHeaderScrollOffsetDip() < offsetAfterWheel, "tab control back overflow button scrolls toward earlier tabs");
}

void TestTabControlHeaderDividerExposesPaintableGeometry()
{
    using namespace DxUi;

    WindowHost host;
    auto root        = std::make_unique<Panel>();
    auto* tabControl = root->AddChild<TabControl>();
    tabControl->SetBounds(D2D1::RectF(0.0f, 0.0f, 360.0f, 180.0f));
    tabControl->AddTab<Label>(L"Folder", L"Folder page");
    tabControl->AddTab<Label>(L"Preview", L"Preview page");
    host.SetRoot(std::move(root));

    const D2D1_RECT_F dividerRect = tabControl->DebugGetHeaderDividerRect();
    RequireRectHasArea(dividerRect, "tab control header divider exposes non-empty debug geometry");
    Require(tabControl->DebugHasHeaderDivider(), "tab control header divider debug state tracks a paintable divider segment");
}

void TestTabControlKeyboardNavigationHonorsRightToLeft()
{
    using namespace DxUi;

    WindowHost host;
    auto root        = std::make_unique<Panel>();
    auto* tabControl = root->AddChild<TabControl>();
    tabControl->SetBounds(D2D1::RectF(0.0f, 0.0f, 320.0f, 180.0f));
    tabControl->AddTab<Label>(L"One", L"Page 0");
    tabControl->AddTab<Label>(L"Two", L"Page 1");
    tabControl->AddTab<Label>(L"Three", L"Page 2");
    host.SetRoot(std::move(root));

    tabControl->SetSelectedIndex(1u);
    tabControl->SetFlowDirection(FlowDirection::RightToLeft);
    host.SetFocusControl(tabControl);

    Require(tabControl->OnKeyDown(host, VK_RIGHT, 0), "right-to-left tab control handles right-arrow navigation");
    Require(tabControl->GetSelectedIndex().has_value() && tabControl->GetSelectedIndex().value() == 0u,
            "right-to-left tab control right-arrow moves to the visually previous tab");
    Require(tabControl->OnKeyDown(host, VK_LEFT, 0), "right-to-left tab control handles left-arrow navigation");
    Require(tabControl->GetSelectedIndex().has_value() && tabControl->GetSelectedIndex().value() == 1u,
            "right-to-left tab control left-arrow moves to the visually next tab");
}

// ---------------------------------------------------------------------------
// Oversized Context Menus
// ---------------------------------------------------------------------------

void TestContextMenuPopupScrollsOversizedContent()
{
    using namespace DxUi;
    constexpr size_t kOversizedMenuItemCount = 80u;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 120, 120, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    std::vector<MenuFlyoutItem> items;
    for (size_t index = 0u; index < kOversizedMenuItemCount; ++index)
    {
        items.push_back(MenuFlyoutItem{
            .kind      = MenuItemKind::Standard,
            .text      = std::format(L"Item {:02}", index),
            .commandId = static_cast<int>(1000u + index),
        });
    }

    std::string driverFailure;
    std::thread driver([&]
    {
        HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "oversized context menu popup window appears";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) {
            return state.hasScrollbar && state.contentHeightDip > state.visibleHeightDip && state.renderCount > 0u;
        }, popupState))
        {
            driverFailure = "oversized context menu exposes scrollbar state after its initial frame renders";
            return;
        }

        const float initialOffset = popupState.scrollOffsetDip;
        PostMessageW(popupHwnd, WM_KEYDOWN, VK_END, 0);
        if (! WaitForContextMenuPopupState(popupHwnd, [initialOffset](const ContextMenuPopupDebugState& state) {
            return state.keyboardIndex.has_value() && state.scrollOffsetDip > initialOffset;
        }, popupState))
        {
            driverFailure = "oversized context menu keyboard navigation scrolls to keep the last item visible";
            return;
        }

        D2D1_RECT_F lastItemRect = D2D1::RectF();
        if (! DebugGetContextMenuPopupItemRect(popupHwnd, kOversizedMenuItemCount - 1u, lastItemRect))
        {
            driverFailure = "oversized context menu exposes the last item geometry after keyboard scrolling";
            return;
        }

        if (lastItemRect.top < popupState.viewportRectDip.top || lastItemRect.bottom > popupState.viewportRectDip.bottom)
        {
            driverFailure = "oversized context menu keeps the keyboard-targeted item inside the visible viewport";
            return;
        }

        if (std::fabs(popupState.scrollOffsetDip - (popupState.contentHeightDip - popupState.visibleHeightDip)) > 0.01f)
        {
            driverFailure = "oversized context menu End scrolls the menu's bottom padding into view with the last item";
            return;
        }

        const float endOffset = popupState.scrollOffsetDip;
        RECT popupRect{};
        GetWindowRect(popupHwnd, &popupRect);
        const int wheelX = popupRect.left + 24;
        const int wheelY = popupRect.top + 24;
        PostMessageW(popupHwnd, WM_MOUSEWHEEL, MAKEWPARAM(0, static_cast<WORD>(WHEEL_DELTA)), MAKELPARAM(wheelX, wheelY));
        if (! WaitForContextMenuPopupState(
                popupHwnd, [endOffset](const ContextMenuPopupDebugState& state) { return state.scrollOffsetDip < endOffset; }, popupState))
        {
            driverFailure = "oversized context menu mouse wheel scrolls back toward earlier items";
            return;
        }

        PostMessageW(popupHwnd, WM_KEYDOWN, VK_HOME, 0);
        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) {
            return state.keyboardIndex == std::optional<size_t>{0u} && state.scrollOffsetDip == 0.0f;
        }, popupState))
        {
            driverFailure = "oversized context menu Home scrolls the menu's top padding into view with the first item";
            return;
        }
    });

    const ThemePalette theme        = MakeDefaultThemePalette(true);
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{180, 180}, items, theme);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "dismissing the oversized context menu returns no invoked command");
}

void TestContextMenuPopupHonorsSessionMaxRootHeight()
{
    using namespace DxUi;
    constexpr size_t kOversizedMenuItemCount = 48u;
    constexpr float kMaxRootHeightDip        = 180.0f;

    AttachedHostWindow ownerWindow;
    SetWindowPos(ownerWindow.Hwnd(), nullptr, 160, 160, 320, 220, SWP_NOZORDER | SWP_NOACTIVATE);
    ShowWindow(ownerWindow.Hwnd(), SW_SHOWNOACTIVATE);
    ownerWindow.PumpMessages();

    std::vector<MenuFlyoutItem> items;
    for (size_t index = 0u; index < kOversizedMenuItemCount; ++index)
    {
        items.push_back(MenuFlyoutItem{
            .kind      = MenuItemKind::Standard,
            .text      = std::format(L"Capped item {:02}", index),
            .commandId = static_cast<int>(2000u + index),
        });
    }

    std::string driverFailure;
    std::thread driver([&]
    {
        HWND popupHwnd = WaitForOwnedContextMenuPopupWindow(ownerWindow.Hwnd());
        if (! popupHwnd)
        {
            driverFailure = "capped context menu popup window appears";
            return;
        }

        const auto dismissPopup = wil::scope_exit([&]() noexcept
        {
            if (IsWindow(popupHwnd) != FALSE)
            {
                PostMessageW(popupHwnd, WM_KEYDOWN, VK_ESCAPE, 0);
            }
        });

        ContextMenuPopupDebugState popupState{};
        if (! WaitForContextMenuPopupState(popupHwnd, [](const ContextMenuPopupDebugState& state) {
            return state.hasScrollbar && state.contentHeightDip > state.visibleHeightDip && state.renderCount > 0u;
        }, popupState))
        {
            driverFailure = "capped context menu exposes scrollbar state after its initial frame renders";
            return;
        }

        if (popupState.visibleHeightDip > kMaxRootHeightDip + 1.0f)
        {
            driverFailure = "capped context menu keeps visible height within the session maximum";
            return;
        }
    });

    const ThemePalette theme = MakeDefaultThemePalette(true);
    ContextMenuSessionCallbacks callbacks{};
    callbacks.maxRootHeightDip      = kMaxRootHeightDip;
    callbacks.rootVerticalPlacement = ContextMenuRootVerticalPlacement::Above;
    const std::optional<int> result = ContextMenu::Show(ownerWindow.Hwnd(), POINT{220, 220}, items, theme, callbacks);
    driver.join();

    Require(driverFailure.empty(), driverFailure.c_str());
    Require(! result.has_value(), "dismissing the capped oversized context menu returns no invoked command");
}

// ---------------------------------------------------------------------------
// StatusStrip
// ---------------------------------------------------------------------------

void TestStatusStripTextRoundtrips()
{
    using namespace DxUi;

    StatusStrip strip(L"Ready");
    Require(strip.GetText() == L"Ready", "status strip text roundtrips from constructor");

    strip.SetText(L"Loading...");
    Require(strip.GetText() == L"Loading...", "status strip set-text roundtrips");
}

void TestStatusStripMultiSectionSetup()
{
    using namespace DxUi;

    StatusStrip strip;
    strip.SetSections({
        StatusStrip::Section{.text = L"Ready", .widthDip = 0.0f},
        StatusStrip::Section{.text = L"Ln 1, Col 1", .widthDip = 120.0f},
        StatusStrip::Section{.text = L"UTF-8", .widthDip = 80.0f},
    });

    Require(strip.GetSectionCount() == 3u, "status strip reports correct section count");

    strip.SetSectionText(1u, L"Ln 42, Col 10");
    Require(strip.GetSectionCount() == 3u, "status strip section count unchanged after set-section-text");
}

void TestStatusStripRightAlignedLeadingEllipsisSections()
{
    using namespace DxUi;

    StatusStrip strip;
    strip.SetSections({
        StatusStrip::Section{.text            = L"Completed with scan: 1872 matches, 2416 files scanned",
                             .widthDip        = 120.0f,
                             .alignment       = DWRITE_TEXT_ALIGNMENT_TRAILING,
                             .leadingEllipsis = true},
    });

    Require(strip.GetSectionCount() == 1u, "status strip leading-ellipsis section is retained");
    Require(strip.GetSectionAlignment(0u) == DWRITE_TEXT_ALIGNMENT_TRAILING, "status strip stores trailing section alignment");
    Require(strip.GetSectionLeadingEllipsis(0u), "status strip stores leading-ellipsis section trim mode");

    const std::wstring displayText = StatusStrip::DebugElideLeadingForWidth(nullptr, strip.GetSectionText(0u), FontRole::Small, 96.0f, 22.0f);
    Require(displayText.starts_with(L"..."), "status strip leading ellipsis starts with dots when clipped");
    Require(displayText.ends_with(L"scanned"), "status strip leading ellipsis preserves the message tail");
}

void TestStatusStripBlendWithWindowBackgroundRoundtrips()
{
    using namespace DxUi;

    StatusStrip strip;
    Require(! strip.GetBlendWithWindowBackground(), "status strip defaults to drawing its own background");

    strip.SetBlendWithWindowBackground(true);
    Require(strip.GetBlendWithWindowBackground(), "status strip stores blend-with-window-background mode");

    strip.SetBlendWithWindowBackground(false);
    Require(! strip.GetBlendWithWindowBackground(), "status strip clears blend-with-window-background mode");
}

void TestStatusStripPaintHandlesMissingDeviceContext()
{
    using namespace DxUi;

    WindowHost host;
    auto root   = std::make_unique<Panel>();
    auto* strip = root->AddChild<StatusStrip>(L"Ready");
    strip->SetBounds(D2D1::RectF(0.0f, 0.0f, 400.0f, 22.0f));
    strip->SetSections({
        StatusStrip::Section{.text = L"Ready", .widthDip = 0.0f},
        StatusStrip::Section{.text = L"UTF-8", .widthDip = 80.0f},
    });
    host.SetRoot(std::move(root));

    strip->Paint(host);
    Require(true, "status strip multi-section paint tolerates a missing device context");
}

void TestTagPickerAddsRemovesAndDedupesOptions()
{
    using namespace DxUi;

    TagPicker picker;
    picker.SetBounds(D2D1::RectF(0.0f, 0.0f, 360.0f, 36.0f));
    picker.SetOptions(L"All owners", {L"FileSystem", L"FileSystem", L"ViewerText"});

    size_t changedCount = 0u;
    picker.SetOnSelectionChanged([&changedCount](std::span<const std::wstring>) { ++changedCount; });

    Require(picker.GetOptions().size() == 2u, "tag picker dedupes duplicate options");
    Require(picker.SelectOption(L"All owners"), "tag picker accepts the all-option command");
    Require(picker.GetSelectedValues().size() == 2u, "tag picker all-option selects every deduped option");
    Require(picker.GetDisplayTagCount() == 1u, "tag picker collapses an all-selection into one display tag");
    Require(picker.GetDisplayTagText(0u) == L"All owners", "tag picker all-selection tag uses the configured all label");

    Require(picker.RemoveDisplayTag(0u), "tag picker removes the all-selection tag");
    Require(picker.GetSelectedValues().empty(), "removing the all tag clears selected options");
    Require(picker.SelectOption(L"ViewerText"), "tag picker selects an individual option");
    Require(picker.GetSelectedValues().size() == 1u && picker.GetSelectedValues().front() == L"ViewerText", "tag picker stores individual selected option");

    picker.SetInputText(L"file");
    Require(picker.CommitInput(), "tag picker commits the best suggestion from typed input");
    Require(picker.GetSelectedValues().size() == 2u, "typed suggestion commit adds the matching option tag");
    Require(changedCount >= 4u, "tag picker notifies selection changes");
}

void TestTagPickerSelectCallbackCanRetireRootAndReadSelectionAndCapture()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* picker = root->AddChild<TagPicker>();
    picker->SetOptions(L"All", {L"Alpha", L"Beta"});
    host.SetRoot(std::move(root));

    auto callbackText = std::make_shared<std::wstring>(L"selection callback survives root retirement");
    std::vector<std::wstring> selectedAfterRetirement;
    std::wstring captureAfterRetirement;
    bool callbackObservedRetiredRoot = false;
    size_t callbackCount             = 0u;
    picker->SetOnSelectionChanged([&, callbackText = std::move(callbackText)](std::span<const std::wstring> selected)
    {
        ++callbackCount;
        host.SetRoot(std::make_unique<Panel>());
        callbackObservedRetiredRoot = true;
        captureAfterRetirement      = *callbackText;
        selectedAfterRetirement.assign(selected.begin(), selected.end());
    });

    const bool selected = picker->SelectOption(L"Beta");
    Require(selected, "TagPicker accepts the option before its callback retires the root");
    Require(callbackCount == 1u && callbackObservedRetiredRoot, "TagPicker selection callback retires the original root exactly once");
    Require(captureAfterRetirement == L"selection callback survives root retirement", "the callback capture remains readable after root retirement");
    Require(selectedAfterRetirement == std::vector<std::wstring>{L"Beta"}, "the callback selection span remains valid after TagPicker destruction");
    Require(host.GetRoot() != nullptr, "the replacement root survives the selection callback");
}

void TestTagPickerRemoveCallbackCanRetireRootAndReadSelectionAndCapture()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* picker = root->AddChild<TagPicker>();
    picker->SetOptions(L"All", {L"Alpha", L"Beta", L"Gamma"});
    Require(picker->SelectOption(L"Alpha") && picker->SelectOption(L"Beta"), "TagPicker starts with two distinct display tags");
    host.SetRoot(std::move(root));

    auto callbackText = std::make_shared<std::wstring>(L"remove callback survives root retirement");
    std::vector<std::wstring> selectedAfterRetirement{L"unexpected"};
    std::wstring captureAfterRetirement;
    bool callbackObservedRetiredRoot = false;
    size_t callbackCount             = 0u;
    picker->SetOnSelectionChanged([&, callbackText = std::move(callbackText)](std::span<const std::wstring> selected)
    {
        ++callbackCount;
        host.SetRoot(std::make_unique<Panel>());
        callbackObservedRetiredRoot = true;
        captureAfterRetirement      = *callbackText;
        selectedAfterRetirement.assign(selected.begin(), selected.end());
    });

    const bool removed = picker->RemoveDisplayTag(0u);
    Require(removed, "TagPicker removes the display tag before its callback retires the root");
    Require(callbackCount == 1u && callbackObservedRetiredRoot, "TagPicker removal callback retires the original root exactly once");
    Require(captureAfterRetirement == L"remove callback survives root retirement", "the removal callback capture remains readable after root retirement");
    Require(selectedAfterRetirement == std::vector<std::wstring>{L"Beta"}, "the remaining callback selection span stays readable after TagPicker destruction");
    Require(host.GetRoot() != nullptr, "the replacement root survives the removal callback");
}

void TestTagPickerSelectionCallbackCanReplaceItself()
{
    using namespace DxUi;

    WindowHost host;
    auto root    = std::make_unique<Panel>();
    auto* picker = root->AddChild<TagPicker>();
    picker->SetOptions(L"All", {L"Alpha", L"Beta"});
    host.SetRoot(std::move(root));

    auto callbackText = std::make_shared<std::wstring>(L"selection callback survives replacement");
    std::wstring captureAfterReplacement;
    size_t originalCount    = 0u;
    size_t replacementCount = 0u;
    picker->SetOnSelectionChanged([&, callbackText = std::move(callbackText)](std::span<const std::wstring>)
    {
        ++originalCount;
        picker->SetOnSelectionChanged([&](std::span<const std::wstring>) { ++replacementCount; });
        captureAfterReplacement = *callbackText;
    });

    Require(picker->SelectOption(L"Alpha"), "TagPicker selection invokes the original callback");
    Require(originalCount == 1u, "the original TagPicker callback runs once before replacing itself");
    Require(captureAfterReplacement == L"selection callback survives replacement", "the callback capture remains readable after self-replacement");
    Require(picker->SelectOption(L"Beta"), "TagPicker selection invokes the replacement callback");
    Require(replacementCount == 1u, "the replacement TagPicker callback remains installed");
}

// ---------------------------------------------------------------------------
// Smoke overlay
// ---------------------------------------------------------------------------

void TestSmokeOverlayDefaultIsFalse()
{
    using namespace DxUi;

    WindowHost host;
    Require(! host.IsSmokeOverlayVisible(), "smoke overlay defaults to not visible");
}

void TestSmokeOverlayRoundtrips()
{
    using namespace DxUi;

    WindowHost host;
    host.SetSmokeOverlayVisible(true);
    Require(host.IsSmokeOverlayVisible(), "smoke overlay roundtrips to visible");

    host.SetSmokeOverlayVisible(false);
    Require(! host.IsSmokeOverlayVisible(), "smoke overlay roundtrips back to not visible");
}

// ---------------------------------------------------------------------------
// SetSystemBackdrop
// ---------------------------------------------------------------------------

void TestSetSystemBackdropReturnsFalseWithoutHwnd()
{
    using namespace DxUi;

    WindowHost host;
    const bool result = host.SetSystemBackdrop(WindowHost::BackdropType::Mica);
    Require(! result, "set-system-backdrop returns false when no HWND is attached");
}

void TestTabControlCloseCallbacksCanReplaceRootSafely()
{
    using namespace DxUi;

    {
        WindowHost host;
        auto root        = std::make_unique<Panel>();
        auto* tabControl = root->AddChild<TabControl>();
        tabControl->SetBounds(D2D1::RectF(0.0f, 0.0f, 360.0f, 200.0f));
        tabControl->AddTab<Label>(L"Home", L"Page 0");
        tabControl->AddTab<Label>(L"View", L"Page 1");
        tabControl->SetTabClosable(1u, true);
        tabControl->SetSelectedIndex(1u);

        size_t closeRequestCount = 0u;
        tabControl->SetOnTabCloseRequested([&](size_t index)
        {
            Require(index == 1u, "tab close request callback receives the requested tab index");
            ++closeRequestCount;
            host.SetRoot(std::make_unique<Panel>());
            return true;
        });

        host.SetRoot(std::move(root));
        const D2D1_POINT_2F closePoint = RectCenter(tabControl->DebugGetCloseButtonRect(1u));
        Require(tabControl->OnMouseDown(host, closePoint, false, 0), "tab control handles close-request replacement press");
        Require(tabControl->OnMouseUp(host, closePoint, false, 0), "tab control handles close-request replacement release");
        Require(closeRequestCount == 1u, "tab close request callback runs once before replacing the root");
    }

    {
        WindowHost host;
        auto root        = std::make_unique<Panel>();
        auto* tabControl = root->AddChild<TabControl>();
        tabControl->SetBounds(D2D1::RectF(0.0f, 0.0f, 360.0f, 200.0f));
        tabControl->AddTab<Label>(L"Home", L"Page 0");
        tabControl->AddTab<Label>(L"View", L"Page 1");
        tabControl->SetTabClosable(1u, true);
        tabControl->SetSelectedIndex(1u);

        size_t closeCount = 0u;
        tabControl->SetOnTabClosed([&](size_t index)
        {
            Require(index == 1u, "tab closed callback receives the closed tab index");
            ++closeCount;
            host.SetRoot(std::make_unique<Panel>());
        });

        host.SetRoot(std::move(root));
        const D2D1_POINT_2F closePoint = RectCenter(tabControl->DebugGetCloseButtonRect(1u));
        Require(tabControl->OnMouseDown(host, closePoint, false, 0), "tab control handles close replacement press");
        Require(tabControl->OnMouseUp(host, closePoint, false, 0), "tab control handles close replacement release");
        Require(closeCount == 1u, "tab closed callback runs once before replacing the root");
    }
}

void TestMutableCallbackCaptureStatePersistsForComboBoxPopupRequest()
{
    using namespace DxUi;

    WindowHost host;
    ComboBox combo;
    combo.SetItems({ComboBox::Item{L"one", L"One"}});
    std::vector<size_t> callbackCounts;
    combo.SetOnPopupRequested([count = size_t{0u}, &callbackCounts]() mutable
    {
        callbackCounts.push_back(++count);
        return true;
    });
    Require(combo.OnKeyDown(host, VK_RETURN, 0u) && combo.OnKeyDown(host, VK_RETURN, 0u), "ComboBox handles repeated claimed popup requests");
    Require(callbackCounts == std::vector<size_t>{1u, 2u}, "ComboBox retains mutable popup-request callback state between requests");
    Require(! combo.IsPopupOpen(), "a claimed popup request keeps the ComboBox popup closed");
}

void TestMutableCallbackCaptureStatePersistsForRadioControls()
{
    using namespace DxUi;

    WindowHost host;
    RadioButtons group;
    RadioButton* first  = group.AddItem(L"First");
    RadioButton* second = group.AddItem(L"Second");
    std::vector<size_t> groupCounts;
    group.SetOnSelectionChanged([count = size_t{0u}, &groupCounts](int) mutable { groupCounts.push_back(++count); });
    std::vector<size_t> itemCounts;
    first->SetOnSelected([count = size_t{0u}, &itemCounts]() mutable { itemCounts.push_back(++count); });

    Require(first->OnKeyDown(host, VK_SPACE, 0u), "first RadioButton handles selection");
    Require(second->OnKeyDown(host, VK_SPACE, 0u), "second RadioButton handles selection");
    Require(first->OnKeyDown(host, VK_SPACE, 0u), "first RadioButton handles reselection");
    Require(groupCounts == std::vector<size_t>{1u, 2u, 3u}, "RadioButtons retains mutable selection callback state across items");
    Require(itemCounts == std::vector<size_t>{1u, 2u}, "RadioButton retains mutable selected callback state across reselection");
}

void TestMutableCallbackCaptureStatePersistsForPageIndicator()
{
    using namespace DxUi;
    WindowHost host;
    PageIndicator indicator;
    indicator.SetPageCount(4u);
    std::vector<size_t> callbackCounts;
    indicator.SetOnSelected([count = size_t{0u}, &callbackCounts](uint32_t) mutable { callbackCounts.push_back(++count); });
    Require(indicator.OnKeyDown(host, VK_RIGHT, 0u) && indicator.OnKeyDown(host, VK_RIGHT, 0u), "PageIndicator handles repeated keyboard selection");
    Require(callbackCounts == std::vector<size_t>{1u, 2u}, "PageIndicator retains mutable selection callback state between changes");
}

void TestMutableCallbackCaptureStatePersistsForSliderCallbacks()
{
    using namespace DxUi;
    WindowHost host;
    Slider slider;
    slider.SetMinimum(0.0);
    slider.SetMaximum(100.0);
    std::vector<size_t> legacyCounts;
    std::vector<size_t> changeCounts;
    slider.SetOnValueChanged([count = size_t{0u}, &legacyCounts](double) mutable { legacyCounts.push_back(++count); });
    slider.SetOnChange([count = size_t{0u}, &changeCounts](SliderChange) mutable { changeCounts.push_back(++count); });
    Require(slider.RequestValue(host, 20.0) && slider.RequestValue(host, 40.0), "Slider accepts two distinct public value requests");
    Require(legacyCounts == std::vector<size_t>{1u, 2u}, "Slider retains mutable legacy callback state across value changes");
    Require(changeCounts == std::vector<size_t>{1u, 2u}, "Slider retains mutable phase callback state across value changes");
}

void TestMutableCallbackCaptureStatePersistsForMenuBarCallbacks()
{
    using namespace DxUi;
    WindowHost host;
    MenuBar menuBar;
    menuBar.SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 32.0f));
    menuBar.SetItems({MenuBarItem{.text = L"File", .mnemonic = L'F', .enabled = true}});
    std::vector<size_t> hoverCounts;
    menuBar.SetOnHoverChanged([count = size_t{0u}, &hoverCounts](std::optional<size_t>) mutable { hoverCounts.push_back(++count); });
    Require(menuBar.OnMouseMove(host, D2D1::Point2F(12.0f, 12.0f), 0u), "MenuBar handles a logical hover move");
    Require(menuBar.OnMouseLeave(host), "MenuBar handles a logical hover leave");
    Require(hoverCounts == std::vector<size_t>{1u, 2u}, "MenuBar retains mutable hover callback state between notifications");
    std::vector<size_t> openCounts;
    menuBar.SetOnOpenItem([count = size_t{0u}, &openCounts](size_t, POINT, bool) mutable { openCounts.push_back(++count); });
    Require(menuBar.ActivateItem(host, 0u, true) && menuBar.ActivateItem(host, 0u, true), "MenuBar handles repeated public item activation");
    Require(openCounts == std::vector<size_t>{1u, 2u}, "MenuBar retains mutable open callback state between activations");
}

void TestMutableCallbackCaptureStatePersistsForTabControlSelectionAndCloseEvents()
{
    using namespace DxUi;
    WindowHost host;
    auto root        = std::make_unique<Panel>();
    auto* tabControl = root->AddChild<TabControl>();
    tabControl->SetBounds(D2D1::RectF(0.0f, 0.0f, 440.0f, 180.0f));
    tabControl->AddTab<Panel>(L"First");
    tabControl->AddTab<Panel>(L"Second");
    tabControl->AddTab<Panel>(L"Third");
    for (size_t index = 0u; index < tabControl->GetTabCount(); ++index)
    {
        tabControl->SetTabClosable(index, true);
    }
    host.SetRoot(std::move(root));
    std::vector<size_t> selectionCounts;
    tabControl->SetOnSelectionChanged([count = size_t{0u}, &selectionCounts](size_t) mutable { selectionCounts.push_back(++count); });
    Require(tabControl->OnKeyDown(host, VK_RIGHT, 0u) && tabControl->OnKeyDown(host, VK_RIGHT, 0u), "TabControl handles two keyboard selection changes");
    Require(selectionCounts == std::vector<size_t>{1u, 2u}, "TabControl retains mutable selection callback state between changes");

    std::vector<size_t> requestCounts;
    std::vector<size_t> closedCounts;
    tabControl->SetOnTabCloseRequested([count = size_t{0u}, &requestCounts](size_t) mutable
    {
        requestCounts.push_back(++count);
        return false;
    });
    tabControl->SetOnTabClosed([count = size_t{0u}, &closedCounts](size_t) mutable { closedCounts.push_back(++count); });
    for (size_t closeAttempt = 0u; closeAttempt < 2u; ++closeAttempt)
    {
        const D2D1_RECT_F closeRect = tabControl->DebugGetCloseButtonRect(tabControl->GetSelectedIndex().value());
        Require(closeRect.right > closeRect.left && closeRect.bottom > closeRect.top, "the selected tab has a visible close button");
        const D2D1_POINT_2F closePoint = RectCenter(closeRect);
        Require(tabControl->OnMouseDown(host, closePoint, false, 0u), "TabControl handles a close-button press");
        Require(tabControl->OnMouseUp(host, closePoint, false, 0u), "TabControl handles a close-button release");
    }
    Require(requestCounts == std::vector<size_t>{1u, 2u}, "TabControl retains mutable close-request callback state across closes");
    Require(closedCounts == std::vector<size_t>{1u, 2u}, "TabControl retains mutable closed callback state across closes");
}

void TestMutableCallbackCaptureStatePersistsForTabControlReorder()
{
    using namespace DxUi;
    WindowHost host;
    auto root        = std::make_unique<Panel>();
    auto* tabControl = root->AddChild<TabControl>();
    tabControl->SetBounds(D2D1::RectF(0.0f, 0.0f, 640.0f, 180.0f));
    tabControl->AddTab<Panel>(L"Alpha");
    tabControl->AddTab<Panel>(L"Bravo");
    tabControl->AddTab<Panel>(L"Charlie");
    host.SetRoot(std::move(root));
    std::vector<size_t> callbackCounts;
    tabControl->SetOnTabReordered([count = size_t{0u}, &callbackCounts](size_t, size_t) mutable { callbackCounts.push_back(++count); });
    for (size_t move = 0u; move < 2u; ++move)
    {
        const D2D1_RECT_F firstRect  = tabControl->DebugGetTabRect(0u);
        const D2D1_RECT_F secondRect = tabControl->DebugGetTabRect(1u);
        const D2D1_POINT_2F from     = D2D1::Point2F((firstRect.left + firstRect.right) * 0.5f, (firstRect.top + firstRect.bottom) * 0.5f);
        const D2D1_POINT_2F to       = D2D1::Point2F(secondRect.left + 2.0f, (secondRect.top + secondRect.bottom) * 0.5f);
        Require(tabControl->OnMouseDown(host, from, false, 0u), "TabControl accepts the reorder drag start");
        Require(tabControl->OnMouseMove(host, to, 0u), "TabControl processes the reorder drag move");
        static_cast<void>(tabControl->OnMouseUp(host, to, false, 0u));
    }
    Require(callbackCounts == std::vector<size_t>{1u, 2u}, "TabControl retains mutable reorder callback state across moves");
}

void TestMutableCallbackCaptureStatePersistsForTagPicker()
{
    using namespace DxUi;
    TagPicker picker;
    picker.SetOptions(L"All", {L"Alpha", L"Beta"});
    std::vector<size_t> callbackCounts;
    picker.SetOnSelectionChanged([count = size_t{0u}, &callbackCounts](std::span<const std::wstring>) mutable { callbackCounts.push_back(++count); });
    Require(picker.SelectOption(L"Alpha") && picker.SelectOption(L"Beta"), "TagPicker accepts two distinct selections");
    Require(callbackCounts == std::vector<size_t>{1u, 2u}, "TagPicker retains mutable callback state across selection changes");
}

void TestTabControlSelectionSnapshotCleanupCanRetireRootBeforeMouseDownTail()
{
    using namespace DxUi;

    WindowHost host;
    auto root        = std::make_unique<Panel>();
    auto* tabControl = root->AddChild<TabControl>();
    tabControl->SetBounds(D2D1::RectF(0.0f, 0.0f, 440.0f, 180.0f));
    tabControl->AddTab<Panel>(L"First");
    tabControl->AddTab<Panel>(L"Second");
    host.SetRoot(std::move(root));

    size_t callbackCount          = 0u;
    bool retiredBySnapshotCleanup = false;
    tabControl->SetOnSelectionChanged([tabControl,
                                       &host,
                                       &callbackCount,
                                       &retiredBySnapshotCleanup,
                                       payload = std::shared_ptr<int>(new int(1),
                                                                      [&host, &retiredBySnapshotCleanup](int* value) noexcept
    {
        delete value;
        retiredBySnapshotCleanup = true;
        host.SetRoot({});
    })](size_t)
    {
        ++callbackCount;
        static_cast<void>(*payload);
        tabControl->SetOnSelectionChanged({});
    });

    const D2D1_POINT_2F secondTabCenter = RectCenter(tabControl->DebugGetTabRect(1u));
    const bool handled                  = tabControl->OnMouseDown(host, secondTabCenter, false, 0u);
    Require(handled, "TabControl consumes the click that selects the second tab");
    Require(callbackCount == 1u, "TabControl invokes its selection callback once");
    Require(retiredBySnapshotCleanup && ! host.GetRoot(), "releasing the callback snapshot can retire the root before the mouse-down tail");
    Require(host.GetCapturedControl() == nullptr, "TabControl does not capture the retired control after selection callback cleanup");
}

void TestMenuBarHoverMoveSnapshotCleanupCanRetireRootSafely()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<Panel>();
    auto* menuBar = root->AddChild<MenuBar>();
    menuBar->SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 32.0f));
    menuBar->SetItems({MenuBarItem{.text = L"File", .mnemonic = L'F', .enabled = true}});
    host.SetRoot(std::move(root));

    size_t callbackCount          = 0u;
    bool retiredBySnapshotCleanup = false;
    menuBar->SetOnHoverChanged([menuBar,
                                &host,
                                &callbackCount,
                                &retiredBySnapshotCleanup,
                                payload = std::shared_ptr<int>(new int(1),
                                                               [&host, &retiredBySnapshotCleanup](int* value) noexcept
    {
        delete value;
        retiredBySnapshotCleanup = true;
        host.SetRoot({});
    })](std::optional<size_t>)
    {
        ++callbackCount;
        static_cast<void>(*payload);
        menuBar->SetOnHoverChanged({});
    });

    const bool handled = menuBar->OnMouseMove(host, D2D1::Point2F(12.0f, 12.0f), 0u);
    Require(handled, "MenuBar reports the logical hover move handled");
    Require(callbackCount == 1u, "MenuBar runs the hover callback once before releasing its active snapshot");
    Require(retiredBySnapshotCleanup && ! host.GetRoot(), "the callback snapshot's final captured owner can retire the root");
}

void TestMenuBarHoverLeaveSnapshotCleanupCanRetireRootSafely()
{
    using namespace DxUi;

    WindowHost host;
    auto root     = std::make_unique<Panel>();
    auto* menuBar = root->AddChild<MenuBar>();
    menuBar->SetBounds(D2D1::RectF(0.0f, 0.0f, 240.0f, 32.0f));
    menuBar->SetItems({MenuBarItem{.text = L"File", .mnemonic = L'F', .enabled = true}});
    host.SetRoot(std::move(root));
    Require(menuBar->OnMouseMove(host, D2D1::Point2F(12.0f, 12.0f), 0u), "MenuBar starts hovered before leave callback setup");

    size_t callbackCount          = 0u;
    bool retiredBySnapshotCleanup = false;
    menuBar->SetOnHoverChanged([menuBar,
                                &host,
                                &callbackCount,
                                &retiredBySnapshotCleanup,
                                payload = std::shared_ptr<int>(new int(1),
                                                               [&host, &retiredBySnapshotCleanup](int* value) noexcept
    {
        delete value;
        retiredBySnapshotCleanup = true;
        host.SetRoot({});
    })](std::optional<size_t>)
    {
        ++callbackCount;
        static_cast<void>(*payload);
        menuBar->SetOnHoverChanged({});
    });

    const bool handled = menuBar->OnMouseLeave(host);
    Require(handled, "MenuBar reports the logical hover leave handled");
    Require(callbackCount == 1u, "MenuBar runs the leave callback once before releasing its active snapshot");
    Require(retiredBySnapshotCleanup && ! host.GetRoot(), "the leave callback snapshot's final captured owner can retire the root");
}

} // namespace

void RunNewControlTests()
{
    DXUI_RUN_TEST(TestMutableCallbackCaptureStatePersistsForComboBoxPopupRequest);
    DXUI_RUN_TEST(TestMutableCallbackCaptureStatePersistsForRadioControls);
    DXUI_RUN_TEST(TestMutableCallbackCaptureStatePersistsForPageIndicator);
    DXUI_RUN_TEST(TestMutableCallbackCaptureStatePersistsForSliderCallbacks);
    DXUI_RUN_TEST(TestMutableCallbackCaptureStatePersistsForMenuBarCallbacks);
    DXUI_RUN_TEST(TestMutableCallbackCaptureStatePersistsForTabControlSelectionAndCloseEvents);
    DXUI_RUN_TEST(TestMutableCallbackCaptureStatePersistsForTabControlReorder);
    DXUI_RUN_TEST(TestMutableCallbackCaptureStatePersistsForTagPicker);
    DXUI_RUN_TEST(TestTabControlSelectionSnapshotCleanupCanRetireRootBeforeMouseDownTail);
    DXUI_RUN_TEST(TestMenuBarHoverMoveSnapshotCleanupCanRetireRootSafely);
    DXUI_RUN_TEST(TestMenuBarHoverLeaveSnapshotCleanupCanRetireRootSafely);
    DXUI_RUN_TEST(TestTabControlCloseCallbacksCanReplaceRootSafely);
    // Button variant
    DXUI_RUN_TEST(TestButtonVariantDefaultIsStandard);
    DXUI_RUN_TEST(TestButtonVariantRoundtripsAllValues);
    DXUI_RUN_TEST(TestButtonVariantPaintPathsHandleMissingDeviceContext);
    DXUI_RUN_TEST(TestButtonDisclosureChevronAnimatesAndHonorsReducedMotion);
    DXUI_RUN_TEST(TestButtonDisclosureChevronAnimatesAfterAHiddenChange);
    DXUI_RUN_TEST(TestButtonDisclosureChevronPausesAcrossATickGap);
    DXUI_RUN_TEST(TestButtonChromeLayoutDifferentiatesSelectorDropDownAndSplit);
    DXUI_RUN_TEST(TestSelectorButtonChromeUsesStableCurrentValueTreatment);
    DXUI_RUN_TEST(TestButtonChromeCustomStylePreservesOverlayMetrics);
    DXUI_RUN_TEST(TestHyperlinkButtonClickInvokesCallback);
    DXUI_RUN_TEST(TestDropDownButtonKeyboardActivationInvokesDropDownCallback);
    DXUI_RUN_TEST(TestSelectorButtonUsesOneWholeSurfaceFlyoutAction);
    DXUI_RUN_TEST(TestButtonSuppressesTooltipThatRepeatsVisibleLabel);
    DXUI_RUN_TEST(TestNonInteractiveControlCanHostSupplementalTooltip);
    DXUI_RUN_TEST(TestDropDownButtonMnemonicInvokesDropDownCallback);
    DXUI_RUN_TEST(TestDropDownButtonCallbackCanReplaceRootSafely);
    DXUI_RUN_TEST(TestButtonMouseClickReleasesHostCaptureBeforeCallback);
    DXUI_RUN_TEST(TestSplitButtonDropDownMouseClickReleasesHostCaptureBeforeCallback);
    DXUI_RUN_TEST(TestButtonMouseLeaveClearsPressedState);

    // Checkbox indeterminate
    DXUI_RUN_TEST(TestCheckboxIndeterminateDefaultIsFalse);
    DXUI_RUN_TEST(TestCheckboxIndeterminateRoundtrips);
    DXUI_RUN_TEST(TestCheckboxIndeterminatePaintHandlesMissingDeviceContext);

    // RadioButton + RadioButtons
    DXUI_RUN_TEST(TestRadioButtonsAddItemCreatesChildren);
    DXUI_RUN_TEST(TestRadioButtonsSetSelectedIndexUpdatesState);
    DXUI_RUN_TEST(TestRadioButtonClickSelectsAndDeselectsOthers);
    DXUI_RUN_TEST(TestRadioButtonSelectionChangedCanReplaceRootSafely);
    DXUI_RUN_TEST(TestRadioButtonPaintHandlesMissingDeviceContext);

    // ProgressBar
    DXUI_RUN_TEST(TestProgressBarDefaultState);
    DXUI_RUN_TEST(TestProgressBarValueRoundtrips);
    DXUI_RUN_TEST(TestProgressBarRangeRoundtrips);
    DXUI_RUN_TEST(TestProgressBarIndeterminateRoundtrips);
    DXUI_RUN_TEST(TestProgressBarExplicitTrackHeightRoundtrips);
    DXUI_RUN_TEST(TestProgressBarIndeterminateRequestsAnimationWhenAttached);
    DXUI_RUN_TEST(TestProgressBarPaintHandlesMissingDeviceContext);
    DXUI_RUN_TEST(TestProgressBarDisabledIndeterminateStateDoesNotAnimateUntilReenabled);
    DXUI_RUN_TEST(TestProgressBarReducedMotionRestsIndeterminateSegment);
    DXUI_RUN_TEST(TestProgressBarIndeterminateTickSurvivesClockReset);
    DXUI_RUN_TEST(TestSliderSmallestStepStillMoves);

    // PageIndicator
    DXUI_RUN_TEST(TestPageIndicatorDefaultState);
    DXUI_RUN_TEST(TestPageIndicatorPageCountAndSelectionRoundtrip);
    DXUI_RUN_TEST(TestPageIndicatorClickSelectsPage);
    DXUI_RUN_TEST(TestPageIndicatorKeyboardNavigatesAndStopsAtEnds);
    DXUI_RUN_TEST(TestPageIndicatorSetSelectedIndexDoesNotFireCallback);
    DXUI_RUN_TEST(TestPageIndicatorSinglePageIsNotHittable);
    DXUI_RUN_TEST(TestPageIndicatorPaintHandlesMissingDeviceContext);
    DXUI_RUN_TEST(TestPageIndicatorSelectionCallbackCanReplaceRootSafely);

    // Slider
    DXUI_RUN_TEST(TestSliderDefaultState);
    DXUI_RUN_TEST(TestSliderTouchFriendlyGeometry);
    DXUI_RUN_TEST(TestSliderTallControlDoesNotHitFarFromTrack);
    DXUI_RUN_TEST(TestSliderThumbGrabDoesNotSeekWhenContactHitsTouchHalo);
    DXUI_RUN_TEST(TestSliderKeyboardAndPointerInputUpdatesValue);
    DXUI_RUN_TEST(TestSliderVerticalAndRightToLeftGeometryMirrors);
    DXUI_RUN_TEST(TestSliderPaintHandlesMissingDeviceContext);
    DXUI_RUN_TEST(TestSliderSetValueSnapsDisplayedPosition);
    DXUI_RUN_TEST(TestSliderAcknowledgementStopsPendingAnimation);
    DXUI_RUN_TEST(TestSliderRejectsNonFiniteRangeAndSteps);
    DXUI_RUN_TEST(TestSliderRangeAndStepSettersKeepDependentValuesValid);
    DXUI_RUN_TEST(TestSliderOffCenterGrabAndCancel);

    // Toolbar
    DXUI_RUN_TEST(TestToolbarAddButtonCreatesChildren);
    DXUI_RUN_TEST(TestToolbarButtonHoverShowsTooltip);
    DXUI_RUN_TEST(TestToolbarButtonClickFiresCallback);
    DXUI_RUN_TEST(TestToolbarPaintHandlesMissingDeviceContext);

    // MenuBar
    DXUI_RUN_TEST(TestMenuBarSetItemsRoundtrips);
    DXUI_RUN_TEST(TestMenuBarClickInvokesOpenCallback);
    DXUI_RUN_TEST(TestMenuBarHoverMoveCallbackCanRetireRoot);
    DXUI_RUN_TEST(TestMenuBarHoverLeaveCallbackCanRetireRoot);
    DXUI_RUN_TEST(TestMenuBarHoverCallbackCanReplaceItself);
    DXUI_RUN_TEST(TestMenuBarMouseOpenReleasesHostCaptureBeforeCallback);
    DXUI_RUN_TEST(TestMenuBarKeyboardNavigationOpensSelectedItem);
    DXUI_RUN_TEST(TestMenuBarMnemonicOpensMatchingItem);
    DXUI_RUN_TEST(TestFlowDirectionInheritanceRoundtrips);
    DXUI_RUN_TEST(TestHorizontalStackPanelRelayoutsWhenFlowDirectionChanges);
    DXUI_RUN_TEST(TestMenuBarRightToLeftMirrorsItemOrderAndArrowKeys);
    DXUI_RUN_TEST(TestMenuBarCompactDensityKeepsUsableItemHeight);

    // TabControl
    DXUI_RUN_TEST(TestTabControlSelectionShowsOnlyTheActivePage);
    DXUI_RUN_TEST(TestTabControlHiddenTabsKeepStableIndicesAndLeaveTheHeader);
    DXUI_RUN_TEST(TestTabControlCloseButtonRemovesTabsAndInvokesCallback);
    DXUI_RUN_TEST(TestTabControlRemoveResolvesRequestedPageAfterFocusCallbackReordersSiblings);
    DXUI_RUN_TEST(TestTabControlSelectionReportsResolvedIndexAfterFocusCallbackRemovesSibling);
    DXUI_RUN_TEST(TestTabControlCloseReportsResolvedIndexAfterCloseCallbackRemovesSibling);
    DXUI_RUN_TEST(TestTabControlOverflowButtonsAndWheelScroll);
    DXUI_RUN_TEST(TestTabControlHeaderDividerExposesPaintableGeometry);
    DXUI_RUN_TEST(TestTabControlKeyboardNavigationHonorsRightToLeft);

    // Oversized context menus
    DXUI_RUN_TEST(TestContextMenuPopupScrollsOversizedContent);
    DXUI_RUN_TEST(TestContextMenuPopupHonorsSessionMaxRootHeight);
    RunMenuDescriptionTests();

    // StatusStrip
    DXUI_RUN_TEST(TestStatusStripTextRoundtrips);
    DXUI_RUN_TEST(TestStatusStripMultiSectionSetup);
    DXUI_RUN_TEST(TestStatusStripRightAlignedLeadingEllipsisSections);
    DXUI_RUN_TEST(TestStatusStripBlendWithWindowBackgroundRoundtrips);
    DXUI_RUN_TEST(TestStatusStripPaintHandlesMissingDeviceContext);
    DXUI_RUN_TEST(TestTagPickerAddsRemovesAndDedupesOptions);
    DXUI_RUN_TEST(TestTagPickerSelectCallbackCanRetireRootAndReadSelectionAndCapture);
    DXUI_RUN_TEST(TestTagPickerRemoveCallbackCanRetireRootAndReadSelectionAndCapture);
    DXUI_RUN_TEST(TestTagPickerSelectionCallbackCanReplaceItself);

    // Smoke overlay
    DXUI_RUN_TEST(TestSmokeOverlayDefaultIsFalse);
    DXUI_RUN_TEST(TestSmokeOverlayRoundtrips);

    // SetSystemBackdrop
    DXUI_RUN_TEST(TestSetSystemBackdropReturnsFalseWithoutHwnd);
}
