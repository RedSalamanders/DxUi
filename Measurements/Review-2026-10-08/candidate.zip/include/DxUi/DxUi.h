#pragma once
#include "Configuration.h"

#include <array>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <functional>
#include <limits>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <vector>

#pragma warning(push)
#pragma warning(disable : 4625 4626 5026 5027 4820 28182)
#include <wil/com.h>
#include <wil/resource.h>
#pragma warning(pop)

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <d2d1_1.h>
#include <d3d11.h>
#include <dcomp.h>
#include <dwrite.h>
#include <dxgi1_2.h>
#include <windows.h>

#include "ThemeColors.h"
#include <unordered_map>

struct IRawElementProviderFragmentRoot;
struct ITextStoreACP;

namespace DxUi
{
inline constexpr UINT kModifierAlt = 0x0100u;

[[nodiscard]] inline bool ModifiersContainCtrl(UINT modifiers) noexcept
{
    return (modifiers & MK_CONTROL) != 0u;
}

[[nodiscard]] inline bool ModifiersContainShift(UINT modifiers) noexcept
{
    return (modifiers & MK_SHIFT) != 0u;
}

[[nodiscard]] inline bool ModifiersContainAlt(UINT modifiers) noexcept
{
    return (modifiers & kModifierAlt) != 0u;
}

[[nodiscard]] inline UINT ComposeModifierMask(bool shift,
                                              bool control,
                                              bool alt,
                                              bool leftButton   = false,
                                              bool rightButton  = false,
                                              bool middleButton = false,
                                              bool xButton1     = false,
                                              bool xButton2     = false) noexcept
{
    UINT modifiers = 0u;
    modifiers |= shift ? MK_SHIFT : 0u;
    modifiers |= control ? MK_CONTROL : 0u;
    modifiers |= alt ? kModifierAlt : 0u;
    modifiers |= leftButton ? MK_LBUTTON : 0u;
    modifiers |= rightButton ? MK_RBUTTON : 0u;
    modifiers |= middleButton ? MK_MBUTTON : 0u;
    modifiers |= xButton1 ? MK_XBUTTON1 : 0u;
    modifiers |= xButton2 ? MK_XBUTTON2 : 0u;
    return modifiers;
}

[[nodiscard]] bool IsDeviceLossHResult(HRESULT hr) noexcept;
[[nodiscard]] D2D1::ColorF ColorFromArgb(uint32_t argb) noexcept;
[[nodiscard]] D2D1_COLOR_F BlendColor(const D2D1_COLOR_F& from, const D2D1_COLOR_F& to, float amount) noexcept;
[[nodiscard]] HRESULT CreateD3D11DeviceWithWarpFallback(UINT creationFlags,
                                                        std::span<const D3D_FEATURE_LEVEL> featureLevels,
                                                        bool forceWarp,
                                                        ID3D11Device** device,
                                                        D3D_FEATURE_LEVEL* featureLevel,
                                                        ID3D11DeviceContext** context,
                                                        D3D_DRIVER_TYPE* driverType = nullptr) noexcept;

enum class ModalLoopResult : uint8_t
{
    Completed,
    Quit,
    GetMessageFailed,
};

using ModalLoopContinueCallback = bool (*)(void* context) noexcept;
using ModalLoopQuitCallback     = void (*)(WPARAM quitCode, void* context) noexcept;

struct ModalLoopOptions final
{
    std::wstring_view diagnosticName;
    ModalLoopContinueCallback shouldContinue = nullptr;
    void* context                            = nullptr;
    ModalLoopQuitCallback onQuit             = nullptr;
};

[[nodiscard]] ModalLoopResult RunModalLoop(HWND hwnd, const ModalLoopOptions& options) noexcept;

enum class SortDirection : uint8_t
{
    None,
    Ascending,
    Descending,
};

enum class GridSelectionMode : uint8_t
{
    Single,
    Extended,
};

enum class GridVisualMode : uint8_t
{
    Standard,
    FolderView,
};

enum class ComboBoxVariant : uint8_t
{
    Window,
    Modern,
    Edit,
};

enum class GridRowTone : uint8_t
{
    None,
    Info,
    Warning,
    Error,
};

enum class GridCellKind : uint8_t
{
    Text,
    Checkbox,
    IconText,
    ColorSwatch,
    Spinner,
    Marquee,
};

enum class GridColumnKind : uint8_t
{
    Text,
    Checkbox,
    StateImage,
};

enum class AdornmentTone : uint8_t
{
    Accent,
    Info,
    Warning,
    Error,
};

enum class OverlayMaterial : uint8_t
{
    Solid,
    Mica,
    MicaAlt,
    Acrylic,
};

enum class FontRole : uint8_t
{
    Body,
    BodyStrong, // 14/20 Semibold
    BodyLarge,  // 18/24 Regular
    ListItem,   // 12 Regular, dense file/list rows
    Title,
    Subtitle,   // 20/28 Semibold
    TitleLarge, // 40/52 Semibold
    Display,    // 68/92 Semibold
    Header,     // DEPRECATED — use Subtitle for new code; kept for backward compat
    Small,      // maps to Caption in WinUI
    Icon,       // 12 DIP Fluent/MDL2
    HeroIcon,   // 64 DIP Fluent/MDL2
    Monospace,
    IconLarge, // 32 DIP Fluent/MDL2; between Icon and HeroIcon
};

// ---------------------------------------------------------------------------
// Button variant types
// ---------------------------------------------------------------------------

enum class ButtonVariant : uint8_t
{
    Standard,   // Default button
    DropDown,   // Button with chevron, opens flyout
    Selector,   // Current-value selector; whole surface opens flyout, no split action
    Split,      // Left action + right dropdown divider
    Hyperlink,  // Text-only, accent color, underline on hover
    IconOnly,   // Square aspect, icon-only (no text label)
    Disclosure, // Card/group-integrated expand/collapse chevron without button chrome
    Repeat,     // Fires continuously while held
};

enum class EasingCurve : uint8_t
{
    Linear,
    FastDecelerate,
    PointToPoint,
};

// ---------------------------------------------------------------------------
// Menu system types
// ---------------------------------------------------------------------------

enum class MenuItemKind : uint8_t
{
    Standard,  // Normal action item
    Toggle,    // Checkable on/off item
    Radio,     // Radio-exclusive item (within a group)
    Separator, // Visual divider
    Header,    // Non-interactive group label
    Info,      // Non-interactive body row with optional right-aligned detail text
    Slider,    // Discrete slider row with command-backed stops
};

struct MenuFlyoutItem
{
    MenuItemKind kind = MenuItemKind::Standard;
    std::wstring text;
    std::wstring acceleratorText;
    std::wstring iconGlyph;
    struct BitmapIcon final
    {
        BitmapIcon() = default;
        BitmapIcon(wil::unique_hbitmap sourceBitmapValue, UINT widthPxValue, UINT heightPxValue) noexcept
            : sourceBitmap(std::move(sourceBitmapValue)),
              widthPx(widthPxValue),
              heightPx(heightPxValue)
        {
        }

        BitmapIcon(const BitmapIcon&)            = delete;
        BitmapIcon& operator=(const BitmapIcon&) = delete;
        BitmapIcon(BitmapIcon&&)                 = default;
        BitmapIcon& operator=(BitmapIcon&&)      = default;

        wil::unique_hbitmap sourceBitmap;
        UINT widthPx  = 0u;
        UINT heightPx = 0u;
        mutable wil::com_ptr<ID2D1Bitmap1> cachedBitmap;
        mutable wil::com_ptr<ID2D1Device> cachedDevice;
    };
    std::shared_ptr<BitmapIcon> iconBitmap;
    struct SliderStop final
    {
        std::wstring text;
        int commandId = 0;
    };
    std::vector<SliderStop> sliderStops;
    uint32_t sliderValue = 0u;
    bool enabled         = true;
    bool checked         = false;
    int commandId        = 0;
    std::vector<MenuFlyoutItem> children; // Non-empty → has submenu
    // Optional literal description below the primary label. Standard/Toggle/Radio/Info
    // rows wrap both fields at the available menu width and grow to fit their text.
    std::wstring secondaryText;
    // Complete spoken identity of the entry's UIA element; empty uses the decoded label, followed by
    // the secondary text when there is one.
    std::wstring accessibleName;
};

struct MenuBarItem
{
    std::wstring text;
    wchar_t mnemonic    = L'\0';
    bool enabled        = true;
    bool rightJustified = false;
    size_t sourceIndex  = static_cast<size_t>(-1);
};

struct PointDip final
{
    float x = 0.0f;
    float y = 0.0f;

    [[nodiscard]] D2D1_POINT_2F AsD2D() const noexcept
    {
        return D2D1_POINT_2F{x, y};
    }
};

[[nodiscard]] inline PointDip MakePointDip(float x, float y) noexcept
{
    return PointDip{.x = x, .y = y};
}

[[nodiscard]] inline PointDip MakePointDip(D2D1_POINT_2F point) noexcept
{
    return MakePointDip(point.x, point.y);
}

struct SingleLineSelectionClickSequence final
{
    D2D1_POINT_2F pointDip           = D2D1::Point2F();
    uint64_t tickMs                  = 0u;
    bool promoteNextClickToSelectAll = false;
};

struct ContextMenuRootSwitchRequest
{
    POINT screenPoint{};
    std::vector<MenuFlyoutItem> items;
};

enum class ContextMenuRootHorizontalAlignment
{
    Start,
    End,
};

enum class ContextMenuRootVerticalPlacement
{
    Below,
    Above,
};

struct ContextMenuSessionCallbacks
{
    std::function<std::optional<ContextMenuRootSwitchRequest>(POINT screenPoint)> switchRootFromPointer;
    std::function<std::optional<ContextMenuRootSwitchRequest>(bool forward)> switchRootFromDirection;
    // Called by a running Show for each ContextMenu::PostMenuBarHover, with the values it posted.
    std::function<std::optional<ContextMenuRootSwitchRequest>(size_t hoverIndex, std::uintptr_t sequence)> switchRootFromMenuBarHover;
    ContextMenuRootHorizontalAlignment rootHorizontalAlignment = ContextMenuRootHorizontalAlignment::Start;
    ContextMenuRootVerticalPlacement rootVerticalPlacement     = ContextMenuRootVerticalPlacement::Below;
    float minRootWidthDip                                      = 0.0f;
    float maxRootHeightDip                                     = 0.0f;
    bool focusFirstNavigableItem                               = false;
    bool ignoreInitialLeftButtonUp                             = false;
    bool ignoreInitialRightButtonUp                            = false;
};

// Shows a context menu at the given screen coordinates.
// Blocking: runs a nested message loop (like TrackPopupMenu).
// Returns the commandId of the invoked item, or nullopt if dismissed.
// (ThemePalette is defined later in this header; forward declaration suffices for reference parameter.)
struct ThemePalette;

using ContextMenuClosedCallback = std::function<void(std::optional<int> commandId)>;

class ContextMenu final
{
public:
    [[nodiscard]] static std::optional<int> Show(HWND ownerHwnd,
                                                 POINT screenPoint,
                                                 std::span<const MenuFlyoutItem> items,
                                                 const ThemePalette& theme,
                                                 const ContextMenuSessionCallbacks& sessionCallbacks = {});
    // Shows a context menu without a nested message loop. The callback runs on
    // the owning UI thread when an item is invoked or the menu is dismissed.
    [[nodiscard]] static bool ShowAsync(HWND ownerHwnd,
                                        POINT screenPoint,
                                        std::span<const MenuFlyoutItem> items,
                                        const ThemePalette& theme,
                                        ContextMenuClosedCallback onClosed,
                                        const ContextMenuSessionCallbacks& sessionCallbacks = {});
    // Tells a running Show (not ShowAsync) that the pointer now hovers item `hoverIndex` of the application's menu bar.
    // Post it to a window of the menu's thread, such as the popup holding capture or the owner: Show calls the session's
    // switchRootFromMenuBarHover(hoverIndex, sequence) and opens the root it returns. Outside a Show the window's procedure
    // receives it like any other message, and HandleMessage ignores it. The message is registered by name, so no
    // application message shares its value. Returns false when it could not be posted.
    [[nodiscard]] static bool PostMenuBarHover(HWND target, size_t hoverIndex, std::uintptr_t sequence) noexcept;
};

// Native menu diagnostics share the optional borrowed Diagnostics::sink. No trace file is opened by DxUi.
[[nodiscard]] bool IsContextMenuDiagnosticsEnabled() noexcept;
void TraceContextMenuDiagnostics(std::wstring_view eventName, std::wstring_view details = {}) noexcept;

#if DXUI_ENABLE_DIAGNOSTICS
struct ContextMenuPopupDebugState
{
    bool hasScrollbar                 = false;
    bool usesSystemBackdrop           = false;
    bool usesAppBackdropBlur          = false;
    UINT dpi                          = USER_DEFAULT_SCREEN_DPI;
    float visibleWidthDip             = 0.0f;
    float visibleHeightDip            = 0.0f;
    float contentHeightDip            = 0.0f;
    float scrollOffsetDip             = 0.0f;
    D2D1_RECT_F viewportRectDip       = D2D1::RectF();
    D2D1_RECT_F scrollbarTrackRectDip = D2D1::RectF();
    D2D1_RECT_F scrollbarThumbRectDip = D2D1::RectF();
    RECT surfaceRectPx{};
    RECT windowRectPx{};
    std::optional<size_t> hoveredIndex;
    std::optional<size_t> keyboardIndex;
    bool hoverTimerActive       = false;
    bool hoverTimerPendingOpen  = false;
    bool hoverTimerPendingClose = false;
    std::optional<size_t> hoverTimerItemIndex;
    std::vector<std::wstring> itemTexts;
    std::vector<std::wstring> itemAcceleratorTexts;
    std::vector<std::wstring> itemSecondaryTexts;
    std::vector<MenuItemKind> itemKinds;
    std::vector<bool> itemEnabled;
    std::vector<uint32_t> sliderValues;
    std::vector<uint32_t> sliderStopCounts;
    std::vector<float> sliderAnimatedPositions;
    std::vector<float> sliderTargetPositions;
    std::vector<bool> sliderDragging;
    std::vector<std::vector<float>> sliderStopVisualExtentsDip;
    uint64_t rootPointerSwitchCount         = 0;
    uint64_t rootSwitchImmediateRenderCount = 0;
    uint64_t renderCount                    = 0;
    size_t lastPaintedItemCount             = 0;
    uint64_t descriptionPreparationCount    = 0;
};

struct ContextMenuPopupItemLayoutDebugState
{
    D2D1_RECT_F itemRectDip          = D2D1::RectF();
    D2D1_RECT_F iconRectDip          = D2D1::RectF();
    D2D1_RECT_F textRectDip          = D2D1::RectF();
    D2D1_RECT_F acceleratorRectDip   = D2D1::RectF();
    D2D1_RECT_F chevronRectDip       = D2D1::RectF();
    D2D1_RECT_F secondaryTextRectDip = D2D1::RectF();
    UINT32 primaryLineCount          = 0;
    UINT32 secondaryLineCount        = 0;
    float primaryLayoutWidthDip      = 0.0f;
    float secondaryLayoutWidthDip    = 0.0f;
    // A described row's two fields are one layout: where its description starts below the top of that layout, which is the
    // row's text origin. The description is laid out a fixed gap below the label's height rounded up to whole DIPs.
    float descriptionOffsetDip = 0.0f;
    bool hasBitmapIcon         = false;
};

struct ContextMenuPopupItemPaintDebugState
{
    bool hovered                    = false;
    bool disabled                   = false;
    bool usesHighlightFill          = false;
    bool usesRainbowHighlight       = false;
    D2D1_COLOR_F fillColor          = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F compositeFillColor = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F textColor          = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F acceleratorColor   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F iconColor          = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F checkColor         = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F chevronColor       = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

// What the process's context menus hold alive, counted exactly whatever the renderer and the allocator keep, so a test can
// assert that a closed menu returned everything it held, even while a UI Automation client still holds one of its rows.
struct ContextMenuResourceDebugState
{
    size_t popups               = 0; // Menu popups alive: the root of each open menu and every open submenu.
    size_t rowLayouts           = 0; // Text layouts the rows of those popups hold (a described row holds one, for its label and its description).
    size_t accessibilityRecords = 0; // Control records of the UI Automation snapshots published for menu popups that are still alive, wherever held.

    [[nodiscard]] bool operator==(const ContextMenuResourceDebugState&) const noexcept = default;
};

struct WindowHostBitmapCapture;

[[nodiscard]] bool DebugGetContextMenuPopupState(HWND hwnd, ContextMenuPopupDebugState& outState) noexcept;
[[nodiscard]] ContextMenuResourceDebugState DebugGetContextMenuResources() noexcept;
void DebugSetContextMenuStateProbeStallForTest(HANDLE enteredEvent, HANDLE releaseEvent) noexcept;
// Called on the menu's thread just before its modal loop peeks a popup's own messages (`message`: WM_PAINT, or the state
// probes' message), with that popup's window. PeekMessageW runs the handlers of messages other threads sent, which can open
// or close a submenu while the loop walks the popup chain; a test does the same from the hook. Null clears it.
using ContextMenuModalLoopPeekHook = void (*)(void* context, HWND popupHwnd, UINT message) noexcept;
void DebugSetContextMenuModalLoopPeekHookForTest(ContextMenuModalLoopPeekHook hook, void* context) noexcept;
[[nodiscard]] bool DebugGetContextMenuPopupItemRect(HWND hwnd, size_t itemIndex, D2D1_RECT_F& outRectDip) noexcept;
[[nodiscard]] bool DebugGetContextMenuItemDisplayText(const MenuFlyoutItem& item, std::wstring& outText);
[[nodiscard]] bool DebugGetContextMenuPopupItemText(HWND hwnd, size_t itemIndex, std::wstring& outText) noexcept;
[[nodiscard]] bool DebugGetContextMenuPopupItemLayout(HWND hwnd, size_t itemIndex, ContextMenuPopupItemLayoutDebugState& outState) noexcept;
[[nodiscard]] bool DebugGetContextMenuPopupItemPaint(HWND hwnd, size_t itemIndex, ContextMenuPopupItemPaintDebugState& outState) noexcept;
[[nodiscard]] bool DebugSetContextMenuPopupBackdropCapture(HWND hwnd, const WindowHostBitmapCapture& capture) noexcept;
[[nodiscard]] bool DebugCaptureContextMenuPopupBitmap(HWND hwnd, WindowHostBitmapCapture& outCapture) noexcept;
// Discards the popup host's graphics device as a lost device would, so its next paint recreates the device resources. The
// popup must belong to the calling thread.
[[nodiscard]] bool DebugSimulateContextMenuPopupDeviceLoss(HWND hwnd) noexcept;
[[nodiscard]] bool DebugFireContextMenuPopupHoverTimer(HWND hwnd) noexcept;
[[nodiscard]] bool DebugComputeContextMenuPopupPosition(POINT screenPoint,
                                                        float widthDip,
                                                        float heightDip,
                                                        UINT dpi,
                                                        bool isSubmenu,
                                                        const RECT* parentRect,
                                                        const RECT* parentItemRect,
                                                        ContextMenuRootHorizontalAlignment rootHorizontalAlignment,
                                                        RECT& outRect) noexcept;
[[nodiscard]] bool DebugComputeContextMenuPopupPosition(POINT screenPoint,
                                                        float widthDip,
                                                        float heightDip,
                                                        UINT dpi,
                                                        bool isSubmenu,
                                                        const RECT* parentRect,
                                                        const RECT* parentItemRect,
                                                        ContextMenuRootHorizontalAlignment rootHorizontalAlignment,
                                                        ContextMenuRootVerticalPlacement rootVerticalPlacement,
                                                        RECT& outRect) noexcept;
#endif

enum class InputModality : uint8_t
{
    Pointer,
    Keyboard,
};

// The device behind a pointer event: the mouse, or a touch or pen contact that Windows promotes to mouse messages. A
// control reads it from ControlHost::GetPointerDevice while it handles the event, to give a finger the feedback it needs.
enum class PointerDevice : uint8_t
{
    Mouse,
    Touch,
    Pen,
};

// The device of a mouse message, from GetMessageExtraInfo() read while that message is handled. Windows marks a message
// it generated for a touch or pen contact with 0xFF515700 in the upper 24 bits of the low 32, and sets 0x80 for touch;
// anything else is the mouse. An application that forwards its own window's mouse messages to an EmbeddedHost fills
// PointerEvent::device with it.
[[nodiscard]] PointerDevice PointerDeviceFromMessageExtraInfo(LPARAM extraInfo) noexcept;

enum class FlowDirection : uint8_t
{
    LeftToRight,
    RightToLeft,
};

enum class Density : uint8_t
{
    Standard,
    Compact,
};

enum class TextInputBackend : uint8_t
{
    Native,
};

enum class PasswordRevealMode : uint8_t
{
    Peek,
    Visible,
    Hidden,
};

enum class PasswordRevealState : uint8_t
{
    Hidden,
    Peek,
    Visible,
};

enum class PasswordMaskLengthPolicy : uint8_t
{
    Exact,
    Concealed,
};

struct TextInputState
{
    std::wstring text;
    std::optional<size_t> selectionAnchorIndex;
    size_t caretIndex       = 0u;
    size_t firstVisibleLine = 0u;
    bool readOnly           = false;
    bool masked             = false;
    bool multiline          = false;
};

struct NativeTextInputState
{
    std::wstring text;
    std::optional<size_t> selectionAnchorIndex;
    size_t caretIndex       = 0u;
    size_t firstVisibleLine = 0u;
    bool readOnly           = false;
    bool masked             = false;
    bool multiline          = false;
    std::optional<size_t> compositionStartIndex;
    std::optional<size_t> compositionEndIndex;
    std::optional<size_t> conversionTargetStartIndex;
    std::optional<size_t> conversionTargetEndIndex;
    std::optional<size_t> compositionCursorIndex;
    std::vector<size_t> compositionClauseBoundaries;
    FlowDirection flowDirection               = FlowDirection::LeftToRight;
    DWRITE_READING_DIRECTION readingDirection = DWRITE_READING_DIRECTION_LEFT_TO_RIGHT;
    PasswordRevealMode passwordRevealMode     = PasswordRevealMode::Peek;
    PasswordRevealState passwordRevealState   = PasswordRevealState::Hidden;
    PasswordMaskLengthPolicy maskLengthPolicy = PasswordMaskLengthPolicy::Exact;
    size_t secretVisibleDotCount              = 0u;
};

enum class TextInputAutomationEventKind : uint8_t
{
    TextChanged,
    TextSelectionChanged,
    ActiveTextPositionChanged,
    TextEditCompositionChanged,
    TextEditConversionTargetChanged,
};

struct NativeTextInputEventCounters
{
    uint64_t activationCount                         = 0u;
    uint64_t synchronizationCount                    = 0u;
    uint64_t deactivationCount                       = 0u;
    uint64_t tsfActivationAttemptCount               = 0u;
    uint64_t tsfActivationSuccessCount               = 0u;
    uint64_t tsfActivationFailureCount               = 0u;
    uint64_t tsfDeactivationCount                    = 0u;
    uint64_t caretUpdateCount                        = 0u;
    uint64_t uiaTextChangedCount                     = 0u;
    uint64_t uiaTextSelectionChangedCount            = 0u;
    uint64_t uiaActiveTextPositionChangedCount       = 0u;
    uint64_t uiaTextEditTextChangedCount             = 0u;
    uint64_t uiaTextEditConversionTargetChangedCount = 0u;
};

struct NativeTextInputImePayload
{
    bool hasCompositionString = false;
    std::wstring compositionString;
    bool hasResultString = false;
    std::wstring resultString;
    bool hasCursorPosition = false;
    size_t cursorPosition  = 0u;
    std::vector<uint8_t> compositionAttributes;
    std::vector<uint32_t> compositionClauses;
};

struct TextFieldDebugMultilineState
{
    size_t firstVisibleLine     = 0u;
    size_t visibleLineCount     = 0u;
    size_t totalLineCount       = 0u;
    bool canScrollVertically    = false;
    bool cachedLayoutPresent    = false;
    bool layoutDirty            = true;
    float cachedLayoutWidthDip  = 0.0f;
    float cachedLayoutHeightDip = 0.0f;
};

struct TextFieldDebugSingleLinePaintState
{
    D2D1_RECT_F textRect{};
    D2D1_RECT_F selectionPaintRect{};
    D2D1_RECT_F trailingButtonRect{};
    std::vector<D2D1_RECT_F> compositionUnderlineRects;
    std::vector<D2D1_RECT_F> conversionTargetUnderlineRects;
    float horizontalScrollDip  = 0.0f;
    bool hasSelectionPaintRect = false;
    bool hasTrailingButtonRect = false;
};

struct SingleLineTextLayoutCache
{
    wil::com_ptr<IDWriteTextLayout> layout;
    std::wstring text;
    IDWriteTextFormat* textFormat             = nullptr;
    FontRole role                             = FontRole::Body;
    DWRITE_READING_DIRECTION readingDirection = DWRITE_READING_DIRECTION_LEFT_TO_RIGHT;
    float measuredTextWidthDip                = 0.0f;
    float layoutWidthDip                      = 0.0f;
    float layoutHeightDip                     = 0.0f;
};

struct ComboBoxDebugEditablePaintState
{
    D2D1_RECT_F textRect{};
    std::vector<D2D1_RECT_F> compositionUnderlineRects;
    std::vector<D2D1_RECT_F> conversionTargetUnderlineRects;
    float horizontalScrollDip = 0.0f;
};

struct VisibleSpan
{
    uint64_t beginIndex = 0;
    uint64_t endIndex   = 0;
    float offsetDip     = 0.0f;
};

struct GridVisibleWorkMetrics
{
    uint64_t visibleRowCount            = 0;
    uint64_t visibleGroupHeaderCount    = 0;
    size_t visibleColumnCount           = 0;
    uint64_t visibleCellCount           = 0;
    uint64_t visibleCellDataReadCount   = 0;
    uint64_t visibleIconCellCount       = 0;
    uint64_t visibleBitmapIconCellCount = 0;
    uint64_t visibleBadgeCellCount      = 0;
    float verticalScrollDip             = 0.0f;
    float horizontalScrollDip           = 0.0f;
    bool hasVerticalScrollbar           = false;
    bool hasHorizontalScrollbar         = false;
};

struct GridDebugRowVisualState
{
    uint32_t fillArgb          = 0u;
    uint32_t textArgb          = 0u;
    uint32_t iconArgb          = 0u;
    uint32_t busyArgb          = 0u;
    uint32_t progressTrackArgb = 0u;
    uint32_t progressFillArgb  = 0u;
    bool usesRainbow           = false;
    bool selected              = false;
};

struct GridDebugCellVisualState
{
    uint32_t checkboxIndicatorFillArgb   = 0u;
    uint32_t checkboxIndicatorBorderArgb = 0u;
    uint32_t checkboxCheckArgb           = 0u;
    uint32_t swatchFillArgb              = 0u;
    uint32_t swatchBorderArgb            = 0u;
    uint32_t badgeFillArgb               = 0u;
    uint32_t badgeTextArgb               = 0u;
    bool hasCheckbox                     = false;
    bool hasIcon                         = false;
    bool iconUsesIconFont                = false;
    bool hasSwatch                       = false;
    bool hasBadge                        = false;
    bool selected                        = false;
};

struct TreeDebugRowVisualState
{
    uint32_t fillArgb      = 0u;
    uint32_t textArgb      = 0u;
    uint32_t iconArgb      = 0u;
    uint32_t expanderArgb  = 0u;
    uint32_t badgeFillArgb = 0u;
    uint32_t badgeTextArgb = 0u;
    uint32_t focusArgb     = 0u;
    bool showFocus         = false;
    bool usesRainbow       = false;
    bool selected          = false;
    bool iconUsesIconFont  = false;
    // The focused (current) item, which owns the focus ring. It is the selected item unless multi-select is on.
    bool current = false;
};

struct GridSortGlyphVisualState
{
    SortDirection currentDirection  = SortDirection::None;
    float currentAlpha              = 0.0f;
    SortDirection previousDirection = SortDirection::None;
    float previousAlpha             = 0.0f;
    bool animating                  = false;
    bool reservesSpace              = false;
};

struct ScrollbarAnimationState
{
    float trackProgress = 0.0f;
    float thumbProgress = 0.0f;
    float targetTrack   = 0.0f;
    float targetThumb   = 0.0f;
    uint64_t lastTickMs = 0u;
    bool anchored       = false;
    bool active         = false;
};

struct GridScrollbarVisualState
{
    D2D1_RECT_F verticalTrackRect    = D2D1::RectF();
    D2D1_RECT_F verticalThumbRect    = D2D1::RectF();
    D2D1_RECT_F horizontalTrackRect  = D2D1::RectF();
    D2D1_RECT_F horizontalThumbRect  = D2D1::RectF();
    uint32_t verticalTrackArgb       = 0u;
    uint32_t verticalThumbArgb       = 0u;
    uint32_t horizontalTrackArgb     = 0u;
    uint32_t horizontalThumbArgb     = 0u;
    float verticalTrackHotProgress   = 0.0f;
    float verticalThumbHotProgress   = 0.0f;
    float horizontalTrackHotProgress = 0.0f;
    float horizontalThumbHotProgress = 0.0f;
    bool hasVerticalScrollbar        = false;
    bool hasHorizontalScrollbar      = false;
    bool verticalTrackHovered        = false;
    bool verticalThumbHovered        = false;
    bool horizontalTrackHovered      = false;
    bool horizontalThumbHovered      = false;
    bool verticalThumbDragging       = false;
    bool horizontalThumbDragging     = false;
};

struct TreeScrollbarVisualState
{
    D2D1_RECT_F verticalTrackRect  = D2D1::RectF();
    D2D1_RECT_F verticalThumbRect  = D2D1::RectF();
    uint32_t verticalTrackArgb     = 0u;
    uint32_t verticalThumbArgb     = 0u;
    float verticalTrackHotProgress = 0.0f;
    float verticalThumbHotProgress = 0.0f;
    bool hasVerticalScrollbar      = false;
    bool verticalTrackHovered      = false;
    bool verticalThumbHovered      = false;
    bool verticalThumbDragging     = false;
};

struct TreeItemData
{
    uint64_t id = 0u;
    std::optional<uint64_t> parentId;
    std::wstring text;
    std::wstring iconText;
    std::wstring badgeText;
    std::wstring tooltipText;
    uint32_t depth          = 0u;
    bool hasChildren        = false;
    bool expanded           = false;
    AdornmentTone badgeTone = AdornmentTone::Accent;
};

struct TreeItemLayoutMetrics
{
    bool hasExpander         = false;
    bool hasIcon             = false;
    bool hasBadge            = false;
    D2D1_RECT_F rowRect      = D2D1::RectF();
    D2D1_RECT_F expanderRect = D2D1::RectF();
    D2D1_RECT_F iconRect     = D2D1::RectF();
    D2D1_RECT_F textRect     = D2D1::RectF();
    D2D1_RECT_F badgeRect    = D2D1::RectF();
};

struct ThemePalette
{
    // ── Environment ──────────────────────────────────────────────────
    bool dark           = false;
    bool highContrast   = false;
    bool reducedMotion  = false;
    bool rainbowMode    = false;
    Density density     = Density::Standard;
    D2D1_COLOR_F accent = D2D1::ColorF(0.0f, 0.47f, 0.84f, 1.0f);

    // ── Surfaces ─────────────────────────────────────────────────────
    D2D1_COLOR_F windowBackground   = D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f);
    D2D1_COLOR_F surfaceBackground  = D2D1::ColorF(0.98f, 0.98f, 0.98f, 1.0f);
    D2D1_COLOR_F cardBackground     = D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f);
    D2D1_COLOR_F overlayBackground  = D2D1::ColorF(0.98f, 0.98f, 0.98f, 1.0f);
    D2D1_COLOR_F overlayBorder      = D2D1::ColorF(0.804f, 0.804f, 0.804f, 1.0f);
    OverlayMaterial overlayMaterial = OverlayMaterial::Solid;
    D2D1_COLOR_F smokeOverlay       = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.30f);

    // ── Header ───────────────────────────────────────────────────────
    D2D1_COLOR_F headerBackground = D2D1::ColorF(0.95f, 0.95f, 0.95f, 1.0f);
    D2D1_COLOR_F headerHovered    = D2D1::ColorF(0.92f, 0.95f, 1.0f, 1.0f);
    D2D1_COLOR_F headerPressed    = D2D1::ColorF(0.86f, 0.91f, 0.98f, 1.0f);

    // ── Chrome ───────────────────────────────────────────────────────
    D2D1_COLOR_F border        = D2D1::ColorF(0.74f, 0.74f, 0.74f, 1.0f);
    D2D1_COLOR_F gridLine      = D2D1::ColorF(0.88f, 0.88f, 0.88f, 1.0f);
    D2D1_COLOR_F borderDefault = D2D1::ColorF(0.804f, 0.804f, 0.804f, 1.0f);
    D2D1_COLOR_F borderStrong  = D2D1::ColorF(0.678f, 0.678f, 0.678f, 1.0f);

    // ── Typography ───────────────────────────────────────────────────
    D2D1_COLOR_F text         = D2D1::ColorF(0.08f, 0.08f, 0.08f, 1.0f);
    D2D1_COLOR_F subduedText  = D2D1::ColorF(0.40f, 0.40f, 0.40f, 1.0f);
    D2D1_COLOR_F disabledText = D2D1::ColorF(0.58f, 0.58f, 0.58f, 1.0f);

    // ── Selection ────────────────────────────────────────────────────
    D2D1_COLOR_F selectionFill         = D2D1::ColorF(0.0f, 0.47f, 0.84f, 1.0f);
    D2D1_COLOR_F selectionText         = D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f);
    D2D1_COLOR_F selectionInactiveFill = D2D1::ColorF(0.0f, 0.47f, 0.84f, 0.45f);
    D2D1_COLOR_F toggleKnobFill        = D2D1::ColorF(0.98f, 0.98f, 0.98f, 1.0f);
    D2D1_COLOR_F toggleKnobCheckedFill = D2D1::ColorF(0.06f, 0.06f, 0.06f, 1.0f);

    // ── Interaction states ───────────────────────────────────────────
    D2D1_COLOR_F focusStroke   = D2D1::ColorF(0.0f, 0.47f, 0.84f, 1.0f);
    D2D1_COLOR_F hoverFill     = D2D1::ColorF(0.0f, 0.47f, 0.84f, 0.10f);
    D2D1_COLOR_F pressedFill   = D2D1::ColorF(0.0f, 0.47f, 0.84f, 0.16f);
    D2D1_COLOR_F accentHover   = D2D1::ColorF(0.0f, 0.42f, 0.74f, 1.0f);
    D2D1_COLOR_F accentPressed = D2D1::ColorF(0.0f, 0.35f, 0.62f, 1.0f);

    // ── Focus ────────────────────────────────────────────────────────
    D2D1_COLOR_F focusStrokeOuter = D2D1::ColorF(0.0f, 0.0f, 0.0f, 1.0f);
    D2D1_COLOR_F focusStrokeInner = D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f);

    // ── Button ───────────────────────────────────────────────────────
    D2D1_COLOR_F buttonFill        = D2D1::ColorF(0.98f, 0.98f, 0.98f, 1.0f);
    D2D1_COLOR_F buttonBorder      = D2D1::ColorF(0.74f, 0.74f, 0.74f, 1.0f);
    D2D1_COLOR_F buttonHotFill     = D2D1::ColorF(0.96f, 0.97f, 1.0f, 1.0f);
    D2D1_COLOR_F buttonPressedFill = D2D1::ColorF(0.92f, 0.95f, 1.0f, 1.0f);

    // ── Input ────────────────────────────────────────────────────────
    D2D1_COLOR_F inputFill   = D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f);
    D2D1_COLOR_F inputBorder = D2D1::ColorF(0.72f, 0.72f, 0.72f, 1.0f);

    // ── Scrollbar ────────────────────────────────────────────────────
    D2D1_COLOR_F scrollbarTrack    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.06f);
    D2D1_COLOR_F scrollbarThumb    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.22f);
    D2D1_COLOR_F scrollbarThumbHot = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.32f);

    // ── Tooltip ──────────────────────────────────────────────────────
    D2D1_COLOR_F tooltipBackground = D2D1::ColorF(0.10f, 0.10f, 0.10f, 0.96f);
    D2D1_COLOR_F tooltipText       = D2D1::ColorF(0.98f, 0.98f, 0.98f, 1.0f);

    // ── Status indicators ────────────────────────────────────────────
    D2D1_COLOR_F infoFill    = D2D1::ColorF(0.90f, 0.95f, 1.0f, 1.0f);
    D2D1_COLOR_F infoText    = D2D1::ColorF(0.0f, 0.39f, 0.71f, 1.0f);
    D2D1_COLOR_F warningFill = D2D1::ColorF(1.0f, 0.98f, 0.90f, 1.0f);
    D2D1_COLOR_F warningText = D2D1::ColorF(0.65f, 0.38f, 0.0f, 1.0f);
    D2D1_COLOR_F errorFill   = D2D1::ColorF(1.0f, 0.95f, 0.95f, 1.0f);
    D2D1_COLOR_F errorText   = D2D1::ColorF(0.75f, 0.0f, 0.0f, 1.0f);
};

struct ButtonVisualStyle
{
    D2D1_COLOR_F fill    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F border  = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F focus   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F text    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    bool showBorder      = false;
    bool showFocus       = false;
    float textOffsetXDip = 0.0f;
    float textOffsetYDip = 0.0f;
};

inline constexpr float kButtonCornerRadiusDip         = 4.0f;
inline constexpr float kButtonDropDownChevronWidthDip = 20.0f;
inline constexpr float kButtonSelectorChevronWidthDip = 24.0f;
inline constexpr float kButtonSplitDropDownSegmentDip = 32.0f;
inline constexpr wchar_t kButtonDropDownChevronGlyph  = L'\xE70D';
inline constexpr wchar_t kButtonFallbackChevronGlyph  = L'\x25BE';

enum class ButtonChromeFocusRing : uint8_t
{
    Standard,
    Single,
};

struct ButtonChromeLayout
{
    D2D1_RECT_F textRect{};
    D2D1_RECT_F chevronRect{};
    float dividerX  = 0.0f;
    bool hasChevron = false;
    bool hasDivider = false;
};

struct ButtonChromeCustomStyle
{
    D2D1_COLOR_F fill               = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F border             = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F focus              = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F text               = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    bool showFill                   = true;
    bool showBorder                 = false;
    bool showFocus                  = false;
    float cornerRadiusDip           = kButtonCornerRadiusDip;
    float borderStrokeDip           = 1.0f;
    float focusOutsetDip            = 2.0f;
    float focusStrokeDip            = 2.0f;
    float textOffsetXDip            = 0.0f;
    float textOffsetYDip            = 0.0f;
    ButtonChromeFocusRing focusRing = ButtonChromeFocusRing::Single;
};

struct ButtonChromeResolvedStyle
{
    D2D1_COLOR_F fill     = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F border   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F focus    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F text     = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F chevron  = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    bool showFill         = true;
    bool showBorder       = false;
    bool showFocus        = false;
    float cornerRadiusDip = kButtonCornerRadiusDip;
    float borderStrokeDip = 1.0f;
    float focusOutsetDip  = 2.0f;
    float focusStrokeDip  = 2.0f;
    float textOffsetXDip  = 0.0f;
    float textOffsetYDip  = 0.0f;
    // Default aligned with ButtonChromeCustomStyle; ResolveButtonChromeResolvedStyle
    // always assigns this explicitly (Standard for the theme-resolved path).
    ButtonChromeFocusRing focusRing = ButtonChromeFocusRing::Single;
};

struct ButtonChromeDrawSpec
{
    D2D1_RECT_F bounds{};
    std::wstring_view text;
    ButtonVariant variant = ButtonVariant::Standard;
    bool primary          = false;
    bool enabled          = true;
    bool hovered          = false;
    bool pressed          = false;
    bool focused          = false;
    bool keyboardFocused  = false;
    float hoverStrength   = -1.0f;
    float focusStrength   = -1.0f;
    float scale           = 1.0f;
    wchar_t chevronGlyph  = kButtonDropDownChevronGlyph;
    std::optional<ButtonChromeCustomStyle> customStyle;
};

class ControlHost;
using WindowHost = ControlHost;

enum class ChevronDirection : uint8_t
{
    Left,
    Up,
    Right,
    Down,
};

struct DisclosureChevronVisualState final
{
    ChevronDirection direction = ChevronDirection::Right;
    float rotationDegrees      = 0.0f;
};

[[nodiscard]] float GetButtonChromeDropDownSegmentWidthDip(ButtonVariant variant) noexcept;
[[nodiscard]] ButtonChromeLayout ComputeButtonChromeLayout(const D2D1_RECT_F& bounds, ButtonVariant variant, float scale = 1.0f) noexcept;
[[nodiscard]] ButtonChromeResolvedStyle ResolveButtonChromeResolvedStyle(const ThemePalette& theme, const ButtonChromeDrawSpec& spec) noexcept;
void DrawButtonChrome(ID2D1RenderTarget* target,
                      ID2D1SolidColorBrush* brush,
                      IDWriteTextFormat* textFormat,
                      IDWriteTextFormat* iconFormat,
                      const ThemePalette& theme,
                      const ButtonChromeDrawSpec& spec) noexcept;
void DrawChevronGlyph(ControlHost& host, const D2D1_RECT_F& rect, ChevronDirection direction, const D2D1_COLOR_F& color) noexcept;
[[nodiscard]] DisclosureChevronVisualState ResolveDisclosureChevronVisualState(float expandedProgress,
                                                                               ChevronDirection collapsedDirection = ChevronDirection::Right) noexcept;
void DrawDisclosureChevron(ControlHost& host,
                           const D2D1_RECT_F& rect,
                           float expandedProgress,
                           const D2D1_COLOR_F& color,
                           ChevronDirection collapsedDirection = ChevronDirection::Right) noexcept;

struct LabelVisualStyle
{
    D2D1_COLOR_F text = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct CheckboxVisualStyle
{
    D2D1_COLOR_F indicatorFill   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F indicatorBorder = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F text            = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F check           = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F focus           = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F hoverFill       = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    bool showHoverFill           = false;
    bool showFocus               = false;
};

struct RadioButtonVisualStyle
{
    D2D1_COLOR_F circleBorder = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F circleFill   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F dotFill      = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F text         = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F hoverFill    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    float dotDiameterDip      = 8.0f;
    bool showHoverFill        = false;
    bool showFocus            = false;
};

struct ProgressBarVisualStyle
{
    D2D1_COLOR_F trackFill    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F progressFill = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct ToolbarVisualStyle
{
    D2D1_COLOR_F background    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F bottomBorder  = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F separatorLine = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct ColorSwatchVisualStyle
{
    D2D1_COLOR_F fill         = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F border       = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F swatchFill   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F swatchBorder = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F focus        = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    bool showFocus            = false;
};

struct CardPanelVisualStyle
{
    D2D1_COLOR_F fill   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F border = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct TooltipVisualStyle
{
    D2D1_COLOR_F fill   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F border = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F text   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct ToggleVisualStyle
{
    D2D1_COLOR_F rowFill     = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F text        = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F trackFill   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F trackBorder = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F knobFill    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F knobBorder  = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F focus       = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    float knobDiameter       = 12.0f;
    bool showRowFill         = false;
    bool showFocus           = false;
};

struct ToggleLayoutMetrics
{
    bool compactSwitchOnly     = false;
    D2D1_RECT_F backgroundRect = D2D1::RectF();
    D2D1_RECT_F focusRect      = D2D1::RectF();
    D2D1_RECT_F textRect       = D2D1::RectF();
    D2D1_RECT_F trackRect      = D2D1::RectF();
    D2D1_RECT_F knobRect       = D2D1::RectF();
};

struct ComboBoxVisualStyle
{
    D2D1_COLOR_F fieldFill              = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F fieldBorder            = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F buttonFill             = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F buttonBorder           = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F splitStroke            = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F focusAccent            = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F caret                  = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F glyph                  = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F text                   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F placeholderText        = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F selectionFill          = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F selectionText          = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F popupFill              = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F popupBorder            = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F popupSelectedFill      = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F popupActiveFill        = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F popupText              = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F popupSelectedText      = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F popupActiveText        = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F popupEmptyText         = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F popupScrollbarTrack    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F popupScrollbarThumb    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F popupScrollbarThumbHot = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    bool showOuterBorder                = true;
    bool showButtonBackground           = true;
    bool showButtonSplit                = false;
    bool showLeftFocusAccent            = false;
    float cornerRadiusDip               = 5.0f;
};

struct TextFieldVisualStyle
{
    D2D1_COLOR_F fill            = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F border          = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F focus           = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F text            = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F placeholderText = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F selectionFill   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F selectionText   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F caret           = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    bool showFocus               = false;
};

struct GridSurfaceVisualStyle
{
    D2D1_COLOR_F fill            = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F border          = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F headerFill      = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F headerBorder    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F rowSeparator    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F columnSeparator = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F emptyText       = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct TreeSurfaceVisualStyle
{
    D2D1_COLOR_F fill      = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F border    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F emptyText = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct GridHeaderVisualStyle
{
    D2D1_COLOR_F fill           = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F hoveredFill    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F pressedFill    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F separator      = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F titleText      = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F busyGlyph      = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F sortGlyph      = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F groupFill      = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F groupSeparator = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F groupText      = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F groupGlyph     = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct GridSwatchVisualStyle
{
    D2D1_COLOR_F fill   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F border = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct GridCheckboxVisualStyle
{
    D2D1_COLOR_F indicatorFill   = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F indicatorBorder = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F check           = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct GridBadgeVisualStyle
{
    D2D1_COLOR_F fill = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F text = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct TreeBadgeVisualStyle
{
    D2D1_COLOR_F fill = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F text = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

struct GridProgressVisualStyle
{
    D2D1_COLOR_F track = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    D2D1_COLOR_F fill  = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
};

[[nodiscard]] D2D1_COLOR_F ResolveListIconColor(const ThemePalette& theme, const D2D1_COLOR_F& textColor, bool selected) noexcept;
[[nodiscard]] D2D1_COLOR_F ResolveGridBusyColor(const ThemePalette& theme, const D2D1_COLOR_F& textColor, bool selected) noexcept;
[[nodiscard]] GridProgressVisualStyle ResolveGridProgressVisualStyle(const ThemePalette& theme,
                                                                     const D2D1_COLOR_F& rowFill,
                                                                     const D2D1_COLOR_F& rowText,
                                                                     bool selected) noexcept;

struct GridSortSpec
{
    size_t columnIndex      = 0;
    SortDirection direction = SortDirection::None;
};

struct GridColumnLayoutEntry
{
    std::wstring columnId;
    size_t displayIndex = 0u;
    float widthDip      = 0.0f;
};

struct GridGroupLayoutEntry
{
    uint64_t groupStableId = 0u;
    bool collapsed         = false;
};

struct GridColumnDesc
{
    std::wstring id;
    std::wstring title;
    float widthDip                      = 120.0f;
    float minWidthDip                   = 64.0f;
    GridColumnKind kind                 = GridColumnKind::Text;
    bool sortable                       = true;
    bool multiline                      = true;
    DWRITE_TEXT_ALIGNMENT textAlignment = DWRITE_TEXT_ALIGNMENT_LEADING;
};

struct GridCellData
{
    std::wstring text;
    std::wstring iconText;
    wil::com_ptr<ID2D1Bitmap1> iconBitmap;
    std::wstring badgeText;
    std::wstring tooltipText;
    int iconIndex                       = -1;
    GridCellKind kind                   = GridCellKind::Text;
    FontRole iconFontRole               = FontRole::Small;
    DWRITE_TEXT_ALIGNMENT textAlignment = DWRITE_TEXT_ALIGNMENT_LEADING;
    bool multiline                      = false;
    bool checked                        = false;
    bool enabled                        = true;
    bool hasSwatchValue                 = false;
    uint32_t swatchArgb                 = 0u;
    float progress                      = 0.0f;
    AdornmentTone badgeTone             = AdornmentTone::Accent;
};

struct GridCellLayoutMetrics
{
    bool hasCheckbox         = false;
    bool hasIcon             = false;
    bool hasSwatch           = false;
    bool hasBadge            = false;
    D2D1_RECT_F cellRect     = D2D1::RectF();
    D2D1_RECT_F checkboxRect = D2D1::RectF();
    D2D1_RECT_F iconRect     = D2D1::RectF();
    D2D1_RECT_F swatchRect   = D2D1::RectF();
    D2D1_RECT_F textRect     = D2D1::RectF();
    D2D1_RECT_F badgeRect    = D2D1::RectF();
};

struct GridRowStyle
{
    GridRowTone tone = GridRowTone::None;
    std::wstring rainbowSeed;
    std::optional<uint32_t> folderViewRainbowHash32;
};

struct GridGroupDesc
{
    uint64_t stableId = 0u;
    std::wstring title;
    size_t startRowIndex = 0u;
    size_t rowCount      = 0u;
    bool collapsed       = false;
};

class IGridModel
{
public:
    virtual ~IGridModel() = default;

    [[nodiscard]] virtual size_t GetRowCount() const noexcept                                  = 0;
    [[nodiscard]] virtual size_t GetColumnCount() const noexcept                               = 0;
    [[nodiscard]] virtual GridColumnDesc GetColumn(size_t columnIndex) const                   = 0;
    virtual void GetCellData(size_t rowIndex, size_t columnIndex, GridCellData& outCell) const = 0;

    [[nodiscard]] virtual GridRowStyle GetRowStyle(size_t rowIndex) const;
    [[nodiscard]] virtual size_t GetGroupCount() const noexcept;
    [[nodiscard]] virtual GridGroupDesc GetGroup(size_t groupIndex) const;
    [[nodiscard]] virtual uint64_t GetStableRowId(size_t rowIndex) const noexcept;
    [[nodiscard]] virtual std::optional<size_t> FindRowByStableId(uint64_t rowId) const noexcept = 0;
};

class Grid;

class IGridDelegate
{
public:
    virtual ~IGridDelegate() = default;

    virtual void OnGridSortRequested(const GridSortSpec& sortSpec);
    virtual void OnGridSelectionChanged(Grid& sender);
    virtual void OnGridSelectionChanged();
    virtual void OnGridCheckboxToggled(Grid& sender, size_t rowIndex, size_t columnIndex, bool checked);
    virtual void OnGridCheckboxToggled(size_t rowIndex, size_t columnIndex, bool checked);
    virtual void OnGridRowActivated(Grid& sender, size_t rowIndex);
    virtual void OnGridRowActivated(size_t rowIndex);
    virtual void OnGridContextMenu(Grid& sender, size_t rowIndex, POINT screenPoint);
    virtual void OnGridContextMenu(size_t rowIndex, POINT screenPoint);
    virtual void OnGridGroupToggled(Grid& sender, uint64_t groupStableId, bool collapsed);
    virtual void OnGridGroupToggled(uint64_t groupStableId, bool collapsed);
    [[nodiscard]] virtual wil::com_ptr<ID2D1Bitmap1> GetGridIconBitmap(const Grid& sender, int iconIndex, float targetDipSize, ID2D1DeviceContext* d2dContext);
};

class ITreeModel
{
public:
    virtual ~ITreeModel() = default;

    [[nodiscard]] virtual size_t GetVisibleItemCount() const noexcept             = 0;
    virtual void GetVisibleItem(size_t visibleIndex, TreeItemData& outItem) const = 0;
    [[nodiscard]] virtual std::optional<size_t> FindVisibleItemById(uint64_t itemId) const noexcept;
};

enum class TreeDropPlace : uint8_t
{
    Before = 0,
    After,
    Inside,
};

// A committed row drag. `sourceId` and `targetId` are model ids. Before/After are siblings of the target;
// Inside appends into a target that has children. The library does not move the model.
struct TreeDrop
{
    uint64_t sourceId   = 0u;
    uint64_t targetId   = 0u;
    TreeDropPlace place = TreeDropPlace::Before;
};

class ITreeDelegate
{
public:
    virtual ~ITreeDelegate() = default;

    // A user gesture (pointer, keyboard, typeahead or UI Automation) made `itemId` the selected item. With
    // Tree::SetMultiSelectEnabled(true) it is the focused (current) item, which Ctrl+click or Ctrl+Space may have just
    // deselected: read the selection from OnTreeSelectionSetChanged.
    virtual void OnTreeSelectionChanged(uint64_t itemId);
    virtual void OnTreeItemInvoked(uint64_t itemId);
    virtual void OnTreeToggleExpanded(uint64_t itemId, bool expanded);
    virtual void OnTreeContextMenu(uint64_t itemId, POINT screenPoint);
    virtual void OnTreeReorder(const TreeDrop& drop);
    // Only with Tree::SetMultiSelectEnabled(true): the set of selected items changed, once per change, after
    // OnTreeSelectionChanged for the same gesture and after a model change (`NotifyDataChanged`, `SetModel`) dropped
    // selected items. `selectedItemIds` lists the selection in visible order and is valid during the call only.
    virtual void OnTreeSelectionSetChanged(std::span<const uint64_t> selectedItemIds);
};

#if DXUI_ENABLE_DIAGNOSTICS
// How many ids each buffer of a GridSelectionModel has room for, counted exactly whatever the allocator keeps, so a test can assert
// that the buffers of a large selection were given back (Specs/Core/Core_PerformanceAndResources.md).
struct GridSelectionBufferDebugState
{
    size_t orderedIds = 0; // The ids in selection order.
    size_t sortedIds  = 0; // The ascending copy.

    [[nodiscard]] bool operator==(const GridSelectionBufferDebugState&) const noexcept = default;
};
#endif

// The stable ids of the selected rows, held twice: in selection order, which GetOrderedSelection returns (the primary row is
// last), and ascending. A Grid asks IsSelected once per visible row on every paint, so what that costs must not grow with the
// selection: a selection of up to 1,024 ids is scanned, as it always was, and a larger one is binary searched, in O(log n). The
// ascending copy costs 8 bytes per selected row. The mutators, which run on user gestures and data changes, keep both copies
// equal at O(n log n) at most. An id the model is given twice is held twice. The room of a copy that exceeds 4,096 ids is given
// back, not kept, when Clear, SetSingle, SetRange or a PreserveOrdered that drops ids leaves the selection at most half as large,
// so a model does not hold on to the Ctrl+A that is behind it.
class GridSelectionModel final
{
public:
    void Clear() noexcept;
    void SetSingle(uint64_t rowId) noexcept;
    void Toggle(uint64_t rowId) noexcept;
    void SetRange(const std::vector<uint64_t>& orderedRowIds, uint64_t anchorRowId, uint64_t currentRowId);
    void PreserveOrdered(const std::vector<uint64_t>& orderedRowIds);

    // No allocation. Up to 1,024 selected ids it scans them, as it always did; above that it binary searches the ascending copy,
    // which does not grow with the selection and, whatever order the ids asked about come in, is never slower than the scan.
    [[nodiscard]] bool IsSelected(uint64_t rowId) const noexcept;
    [[nodiscard]] std::optional<uint64_t> GetAnchor() const noexcept;
    [[nodiscard]] size_t GetCount() const noexcept;
    [[nodiscard]] std::span<const uint64_t> GetOrderedSelection() const noexcept;

#if DXUI_ENABLE_DIAGNOSTICS
    [[nodiscard]] GridSelectionBufferDebugState DebugGetBuffers() const noexcept;
#endif

private:
    std::vector<uint64_t> _selectedRowIds;
    std::vector<uint64_t> _sortedRowIds;
    std::optional<uint64_t> _anchorRowId;
};

class ControlHost;
class Panel;

struct PageHostDebugState
{
    bool active                         = false;
    bool hasConnectedAnimation          = false;
    uint64_t startTickMs                = 0u;
    float linearProgress                = 1.0f;
    float easedPageProgress             = 1.0f;
    float easedConnectedProgress        = 1.0f;
    float incomingOpacity               = 1.0f;
    float outgoingOpacity               = 0.0f;
    float incomingOffsetXDip            = 0.0f;
    float outgoingOffsetXDip            = 0.0f;
    D2D1_RECT_F currentConnectedRectDip = D2D1::RectF();
};

struct WindowHostBitmapCapture
{
    UINT widthPx  = 0u;
    UINT heightPx = 0u;
    std::vector<uint8_t> bgraPixels;
};

enum class WindowHostCursorKind : uint8_t
{
    Default,
    HorizontalResize,
    Hand,
    VerticalResize,
};

enum class AccessibilityRole : uint8_t
{
    Default,
    Status,
    MenuItem,
};

class Control
{
public:
    virtual ~Control() = default;

    void SetBounds(const D2D1_RECT_F& bounds) noexcept;
    [[nodiscard]] D2D1_RECT_F GetBounds() const noexcept;
    [[nodiscard]] virtual D2D1_RECT_F GetHitBounds() const noexcept;
    [[nodiscard]] std::optional<D2D1_RECT_F> TryGetTextInputViewportRect() const noexcept;
    [[nodiscard]] std::optional<D2D1_RECT_F> TryGetTextInputCaretRect(const ControlHost& host, size_t controlTextIndex) const noexcept;
    [[nodiscard]] std::optional<std::vector<D2D1_RECT_F>> TryGetTextInputRangeRects(const ControlHost& host,
                                                                                    size_t controlTextStartIndex,
                                                                                    size_t controlTextEndIndex) const;
    [[nodiscard]] std::optional<size_t> TryHitTestTextInputPoint(const ControlHost& host, D2D1_POINT_2F point) const noexcept;

    void SetVisible(bool visible) noexcept;
    [[nodiscard]] bool IsVisible() const noexcept;
    void SetEnabled(bool enabled) noexcept;
    [[nodiscard]] bool IsEnabled() const noexcept;
    void SetFocusable(bool focusable) noexcept;
    [[nodiscard]] bool IsFocusable() const noexcept;
    [[nodiscard]] bool HasFocus() const noexcept;
    [[nodiscard]] bool IsHovered() const noexcept;

    virtual void Paint(ControlHost& host) const = 0;
    virtual void PaintOverlay(ControlHost& host) const;
    virtual bool Tick(ControlHost& host, uint64_t nowTickMs);

    virtual bool OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers);
    virtual bool OnMouseLeave(ControlHost& host);
    virtual bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers);
    virtual bool OnMouseDoubleClick(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers);
    virtual bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers);
    virtual bool OnMouseWheel(ControlHost& host, D2D1_POINT_2F point, float wheelDelta, UINT modifiers);
    virtual bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers);
    virtual bool OnKeyUp(ControlHost& host, UINT virtualKey, UINT modifiers);
    virtual bool OnChar(ControlHost& host, wchar_t ch, UINT modifiers);
    virtual bool OnContextMenu(ControlHost& host, bool keyboardInvocation, D2D1_POINT_2F pointDip);
    virtual bool OnCopy(ControlHost& host);
    virtual bool OnSelectAll(ControlHost& host);
    virtual bool OnMnemonic(ControlHost& host);
    [[nodiscard]] virtual size_t GetLogicalChildCount() const noexcept;
    [[nodiscard]] virtual Control* GetLogicalChild(size_t index) noexcept;
    [[nodiscard]] virtual const Control* GetLogicalChild(size_t index) const noexcept;

    void SetMnemonic(wchar_t mnemonic) noexcept;
    [[nodiscard]] wchar_t GetMnemonic() const noexcept;
    void SetFlowDirection(FlowDirection direction) noexcept;
    void ClearFlowDirection() noexcept;
    [[nodiscard]] bool HasExplicitFlowDirection() const noexcept;
    [[nodiscard]] FlowDirection GetFlowDirection() const noexcept;
    [[nodiscard]] bool IsRightToLeft() const noexcept;
    void SetDensity(Density density) noexcept;
    void ClearDensity() noexcept;
    [[nodiscard]] bool HasExplicitDensity() const noexcept;
    [[nodiscard]] Density GetDensity() const noexcept;
    [[nodiscard]] bool IsCompactDensity() const noexcept;
    void SetConnectedAnimationKey(std::wstring key);
    [[nodiscard]] std::wstring_view GetConnectedAnimationKey() const noexcept;
    void SetTooltipText(std::wstring tooltipText);
    [[nodiscard]] std::wstring_view GetTooltipText() const noexcept;
    void SetAccessibleName(std::wstring name);
    [[nodiscard]] std::wstring_view GetAccessibleName() const noexcept;
    void SetAccessibleHelpText(std::wstring helpText);
    [[nodiscard]] std::wstring_view GetAccessibleHelpText() const noexcept;
    void SetAccessibleAutomationId(std::wstring automationId);
    [[nodiscard]] std::wstring_view GetAccessibleAutomationId() const noexcept;
    void SetAccessibilityRole(AccessibilityRole role) noexcept;
    [[nodiscard]] AccessibilityRole GetAccessibilityRole() const noexcept;
    void SetAccessibleInvoke(std::function<void(ControlHost&)> onInvoke);
    [[nodiscard]] bool SupportsAccessibleInvoke() const noexcept;
    bool InvokeAccessible(ControlHost& host);
    void SetOnContextMenu(std::function<void(POINT screenPoint, bool keyboardInvocation)> onContextMenu);

protected:
    friend class Panel;
    friend class PageHost;
    friend class ScrollPanel;
    friend class ControlHost;
    friend class EmbeddedHost;
    friend std::weak_ptr<int> GetControlLifetimeToken(const Control& control) noexcept;

    [[nodiscard]] virtual Control* HitTest(D2D1_POINT_2F point);
    [[nodiscard]] virtual const Control* HitTest(D2D1_POINT_2F point) const;
    [[nodiscard]] virtual Control* HitTestOverlay(D2D1_POINT_2F point);
    [[nodiscard]] virtual const Control* HitTestOverlay(D2D1_POINT_2F point) const;
    virtual bool DismissOverlayOnPointerDown(ControlHost& host, D2D1_POINT_2F point);
    [[nodiscard]] virtual POINT ResolveContextMenuAnchor(ControlHost& host, bool keyboardInvocation, D2D1_POINT_2F pointDip) const noexcept;
    [[nodiscard]] virtual WindowHostCursorKind ResolveCursorKind(ControlHost& host, D2D1_POINT_2F pointDip) const noexcept;

    [[nodiscard]] ControlHost* GetHost() const noexcept;
    void Invalidate(ControlHost& host) const;
    void RequestInvalidate() const noexcept;
    [[nodiscard]] std::weak_ptr<int> GetLifetimeToken() const noexcept
    {
        return _lifetimeToken;
    }
    virtual void PropagateHost(ControlHost* host) noexcept;
    void SetParent(Panel* parent) noexcept;
    // Puts the control under `parent` (none for a host root) in `host`, then announces the flow direction
    // and density it now inherits (OnFlowDirectionChanged, OnDensityChanged) if they differ from before, as a parent's
    // own change is announced to its children. Nothing is announced when they do not differ.
    void Reparent(Panel* parent, ControlHost* host) noexcept;
    [[nodiscard]] Panel* GetParent() const noexcept;
    virtual void OnBoundsChanged() noexcept;
    virtual void OnFlowDirectionChanged() noexcept;
    virtual void OnDensityChanged() noexcept;
    virtual void OnEnabledChanged(bool enabled) noexcept;
    // Called when this control, or an ancestor, is hidden: it is not painted until shown again. A control releases what
    // its next paint rebuilds on demand (the Grid's retained text layouts); showing needs no call. Containers forward it.
    virtual void OnHidden() noexcept;
    virtual void OnHostDpiChanged(ControlHost& host) noexcept;
    virtual void OnFocusChanged(ControlHost& host, bool focused);
    virtual void OnHoverChanged(ControlHost& host, bool hovered);
    virtual void OnCaptureLost(ControlHost& host);
    [[nodiscard]] virtual bool SupportsTextInput() const noexcept;
    [[nodiscard]] virtual std::optional<D2D1_RECT_F> GetTextInputViewportRect() const noexcept;
    [[nodiscard]] virtual std::optional<D2D1_RECT_F> GetTextInputCaretRect(const ControlHost& host, size_t controlTextIndex) const noexcept;
    [[nodiscard]] virtual std::optional<std::vector<D2D1_RECT_F>> GetTextInputRangeRects(const ControlHost& host,
                                                                                         size_t controlTextStartIndex,
                                                                                         size_t controlTextEndIndex) const;
    [[nodiscard]] virtual std::optional<size_t> HitTestTextInputPoint(const ControlHost& host, D2D1_POINT_2F point) const noexcept;
    virtual bool ExportTextInputState(TextInputState& outState) const;
    virtual bool ImportTextInputState(ControlHost& host, const TextInputState& state, bool notifyChange);

private:
    // A host snapshots these before reset callbacks can retire the old parent chain.
    void ReparentWithPreviousInheritance(Control* parent, ControlHost* host, FlowDirection previousFlowDirection, Density previousDensity) noexcept;
    Control* _parent    = nullptr;
    ControlHost* _host  = nullptr;
    D2D1_RECT_F _bounds = D2D1::RectF();
    bool _visible       = true;
    bool _enabled       = true;
    bool _focusable     = false;
    bool _hasFocus      = false;
    bool _hovered       = false;
    wchar_t _mnemonic   = L'\0';
    std::optional<FlowDirection> _explicitFlowDirection;
    std::optional<Density> _explicitDensity;
    std::wstring _connectedAnimationKey;
    std::wstring _tooltipText;
    std::wstring _accessibleName;
    std::wstring _accessibleHelpText;
    std::wstring _accessibleAutomationId;
    AccessibilityRole _accessibilityRole = AccessibilityRole::Default;
    std::shared_ptr<const std::function<void(ControlHost&)>> _onAccessibleInvoke;
    std::shared_ptr<const std::function<void(POINT screenPoint, bool keyboardInvocation)>> _onContextMenu;
    std::shared_ptr<int> _lifetimeToken = std::make_shared<int>(0);
};

class Panel : public Control
{
public:
    Panel() = default;

    template <typename TControl, typename... TArgs> TControl* AddChild(TArgs&&... args)
    {
        const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
        auto child                             = std::make_unique<TControl>(std::forward<TArgs>(args)...);
        auto* raw                              = child.get();
        if (ownerLifetime.expired())
        {
            return nullptr;
        }
        const std::weak_ptr<int> childLifetime = GetControlLifetimeToken(*raw);
        raw->SetParent(this);
        if (ownerLifetime.expired())
        {
            if (childLifetime.expired())
            {
                static_cast<void>(child.release());
                return nullptr;
            }

            static_cast<Control*>(raw)->_parent = nullptr;
            static_cast<Control*>(raw)->PropagateHost(nullptr);
            if (childLifetime.expired())
            {
                static_cast<void>(child.release());
            }
            return nullptr;
        }
        if (childLifetime.expired())
        {
            static_cast<void>(child.release());
            return nullptr;
        }
        _children.push_back(std::move(child));
        return raw;
    }

    virtual void ClearChildren() noexcept;
    [[nodiscard]] size_t DebugChildCount() const noexcept
    {
        return _children.size();
    }
    // The owning pointers. A child moved out of the span (to give it to ControlHost::SetRoot or PageHost::SetPage) leaves
    // a null slot that every panel operation skips; do it while the panel and the child's host still exist.
    [[nodiscard]] std::span<std::unique_ptr<Control>> GetChildren() noexcept;
    [[nodiscard]] std::span<const std::unique_ptr<Control>> GetChildren() const noexcept;
    [[nodiscard]] size_t GetLogicalChildCount() const noexcept override;
    [[nodiscard]] Control* GetLogicalChild(size_t index) noexcept override;
    [[nodiscard]] const Control* GetLogicalChild(size_t index) const noexcept override;

    void Paint(ControlHost& host) const override;
    void PaintOverlay(ControlHost& host) const override;
    bool Tick(ControlHost& host, uint64_t nowTickMs) override;

protected:
    [[nodiscard]] Control* HitTest(D2D1_POINT_2F point) override;
    [[nodiscard]] const Control* HitTest(D2D1_POINT_2F point) const override;
    [[nodiscard]] Control* HitTestOverlay(D2D1_POINT_2F point) override;
    [[nodiscard]] const Control* HitTestOverlay(D2D1_POINT_2F point) const override;
    void PropagateHost(ControlHost* host) noexcept override;
    void OnFlowDirectionChanged() noexcept override;
    void OnDensityChanged() noexcept override;
    void OnHidden() noexcept override;
    void OnHostDpiChanged(ControlHost& host) noexcept override;
    [[nodiscard]] std::vector<std::unique_ptr<Control>>& AccessChildren() noexcept;
    [[nodiscard]] const std::vector<std::unique_ptr<Control>>& AccessChildren() const noexcept;

private:
    std::vector<std::unique_ptr<Control>> _children;
};

class PageHost final : public Control
{
public:
    PageHost()                           = default;
    PageHost(const PageHost&)            = delete;
    PageHost(PageHost&&)                 = delete;
    PageHost& operator=(const PageHost&) = delete;
    PageHost& operator=(PageHost&&)      = delete;

    void SetPage(std::unique_ptr<Control> page, std::wstring connectedAnimationKey = {});
    [[nodiscard]] Control* GetPage() noexcept;
    [[nodiscard]] const Control* GetPage() const noexcept;
    [[nodiscard]] bool HasActiveTransition() const noexcept;

    void Paint(ControlHost& host) const override;
    void PaintOverlay(ControlHost& host) const override;
    bool Tick(ControlHost& host, uint64_t nowTickMs) override;
    [[nodiscard]] size_t GetLogicalChildCount() const noexcept override;
    [[nodiscard]] Control* GetLogicalChild(size_t index) noexcept override;
    [[nodiscard]] const Control* GetLogicalChild(size_t index) const noexcept override;
#if DXUI_ENABLE_DIAGNOSTICS
    [[nodiscard]] PageHostDebugState DebugGetTransitionState(uint64_t nowTickMs) const noexcept;
    void DebugFreezeTransitionProgress(float linearProgress) noexcept;
    void DebugUnfreezeTransitionProgress() noexcept;
#endif

protected:
    [[nodiscard]] Control* HitTest(D2D1_POINT_2F point) override;
    [[nodiscard]] const Control* HitTest(D2D1_POINT_2F point) const override;
    [[nodiscard]] Control* HitTestOverlay(D2D1_POINT_2F point) override;
    [[nodiscard]] const Control* HitTestOverlay(D2D1_POINT_2F point) const override;
    void PropagateHost(ControlHost* host) noexcept override;
    void OnBoundsChanged() noexcept override;
    void OnFlowDirectionChanged() noexcept override;
    void OnDensityChanged() noexcept override;
    void OnHidden() noexcept override;
    void OnHostDpiChanged(ControlHost& host) noexcept override;

private:
    struct TransitionState final
    {
        bool active                = false;
        bool hasConnectedAnimation = false;
        uint64_t startTickMs       = 0u;
        uint64_t lastTickMs        = 0u;
        float linearProgress       = 1.0f;
        D2D1_RECT_F sourceRectDip  = D2D1::RectF();
        D2D1_RECT_F targetRectDip  = D2D1::RectF();
        // Keep test-only transition state in the layout for all builds so
        // DxUi static-library consumers cannot diverge on PageHost storage.
        bool debugFrozen          = false;
        float debugFrozenProgress = 1.0f;
    };

    void SyncChildBounds() noexcept;
    [[nodiscard]] bool FinishTransition() noexcept;
    [[nodiscard]] PageHostDebugState ResolveDebugState(const ThemePalette& theme, uint64_t nowTickMs) const noexcept;
    void PaintPage(ControlHost& host, const Control* page, float opacity, float offsetXDip) const;

    static constexpr uint64_t kPageTransitionDurationMs = 250u;
    static constexpr float kIncomingOffsetXDip          = 24.0f;
    static constexpr float kOutgoingOffsetXDip          = -12.0f;

    std::unique_ptr<Control> _currentPage;
    std::unique_ptr<Control> _outgoingPage;
    TransitionState _transition;
};

class CardPanel : public Panel
{
public:
    CardPanel() = default;

    void SetCornerRadius(float cornerRadiusDip) noexcept;
    [[nodiscard]] float GetCornerRadius() const noexcept;

    void Paint(ControlHost& host) const override;

private:
    float _cornerRadiusDip = 4.0f; // 4 DIP inline card, 8 DIP overlay card
};

class Label : public Control
{
public:
    explicit Label(std::wstring text = {});

    void SetText(std::wstring text);
    [[nodiscard]] std::wstring_view GetText() const noexcept;
    [[nodiscard]] Control* GetMnemonicTarget() const noexcept;
    void SetFontRole(FontRole fontRole) noexcept;
    void SetAlignment(DWRITE_TEXT_ALIGNMENT alignment) noexcept;
    void SetMultiline(bool multiline) noexcept;
    void SetTextColor(std::optional<D2D1_COLOR_F> color) noexcept;
    void SetMnemonicTarget(Control* target) noexcept;

    void Paint(ControlHost& host) const override;
    Control* HitTest(D2D1_POINT_2F point) override;
    const Control* HitTest(D2D1_POINT_2F point) const override;
    bool OnMnemonic(ControlHost& host) override;

private:
    std::wstring _text;
    FontRole _fontRole               = FontRole::Body;
    DWRITE_TEXT_ALIGNMENT _alignment = DWRITE_TEXT_ALIGNMENT_LEADING;
    bool _multiline                  = false;
    std::optional<D2D1_COLOR_F> _textColor;
    Control* _mnemonicTarget = nullptr;
};

class Button : public Control
{
public:
    explicit Button(std::wstring text = {});

    void SetText(std::wstring text);
    [[nodiscard]] std::wstring_view GetText() const noexcept;
    // Opt-in wrapping for Standard button text. The caller measures and supplies sufficient bounds.
    void SetMultiline(bool multiline) noexcept;
    [[nodiscard]] bool IsMultiline() const noexcept;
    void SetPrimary(bool primary) noexcept;
    [[nodiscard]] bool IsPrimary() const noexcept;
    void SetVariant(ButtonVariant variant) noexcept;
    [[nodiscard]] ButtonVariant GetVariant() const noexcept;
    void SetDisclosureCollapsedDirection(ChevronDirection direction) noexcept;
    void SetDisclosureExpanded(bool expanded) noexcept;
    [[nodiscard]] std::optional<bool> GetDisclosureExpanded() const noexcept;
    void ClearDisclosureState() noexcept;
    void SetOnClick(std::function<void()> onClick);
    void SetOnDropDownClick(std::function<void()> onDropDownClick);
    bool Invoke(ControlHost& host, bool focusSelf);
    void SetPressedVisual(bool pressed) noexcept;
    [[nodiscard]] float DebugGetHoverAnimationProgress() const noexcept;
    [[nodiscard]] float DebugGetFocusAnimationProgress() const noexcept;
    [[nodiscard]] float DebugGetDisclosureAnimationProgress() const noexcept;
    [[nodiscard]] bool DebugIsDisclosureAnimationActive() const noexcept;
#if DXUI_ENABLE_DIAGNOSTICS
    [[nodiscard]] bool DebugIsPressed() const noexcept;
#endif

    void Paint(ControlHost& host) const override;
    bool Tick(ControlHost& host, uint64_t nowTickMs) override;
    bool OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers) override;
    bool OnMouseLeave(ControlHost& host) override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    bool OnMnemonic(ControlHost& host) override;

protected:
    [[nodiscard]] bool IsPressed() const noexcept;
    void SetPressed(bool pressed) noexcept;
    void OnFocusChanged(ControlHost& host, bool focused) override;
    void OnHoverChanged(ControlHost& host, bool hovered) override;
    void OnCaptureLost(ControlHost& host) override;
    [[nodiscard]] float ResolveHoverAnimationProgress(const ControlHost& host) const noexcept;
    [[nodiscard]] float ResolveFocusAnimationProgress(const ControlHost& host) const noexcept;

private:
    struct InteractionTransitionState final
    {
        float progress      = 0.0f;
        float target        = 0.0f;
        uint64_t lastTickMs = 0u;
        bool anchored       = false;
        bool active         = false;
    };

    struct DisclosureTransitionState final
    {
        float progress      = 0.0f;
        float startProgress = 0.0f;
        float target        = 0.0f;
        uint64_t elapsedMs  = 0u; // Animated time: a gap between ticks counts for one bounded step (see the tick).
        uint64_t lastTickMs = 0u;
        bool anchored       = false; // The first tick anchors the clock, so the rotation starts when it can show.
        bool initialized    = false;
        bool active         = false;
    };

    void UpdateInteractionTransition(ControlHost& host, InteractionTransitionState& transition, float target) noexcept;
    [[nodiscard]] bool AdvanceInteractionTransition(const ControlHost& host, InteractionTransitionState& transition, uint64_t nowTickMs) noexcept;
    [[nodiscard]] bool AdvanceDisclosureTransition(ControlHost& host, uint64_t nowTickMs) noexcept;
    [[nodiscard]] bool IsDropDownInvocationPoint(D2D1_POINT_2F point) const noexcept;
    [[nodiscard]] bool InvokeDropDown(ControlHost& host);

    static constexpr uint64_t _interactionAnimationDurationMs = 140u;
    static constexpr uint64_t _disclosureAnimationDurationMs  = 240u;
    static constexpr float _dropDownChevronWidthDip           = kButtonDropDownChevronWidthDip;
    static constexpr float _splitDropDownWidthDip             = kButtonSplitDropDownSegmentDip;
    std::wstring _text;
    std::shared_ptr<const std::function<void()>> _onClick;
    std::shared_ptr<const std::function<void()>> _onDropDownClick;
    InteractionTransitionState _hoverTransition{};
    InteractionTransitionState _focusTransition{};
    DisclosureTransitionState _disclosureTransition{};
    std::optional<bool> _disclosureExpanded;
    ChevronDirection _disclosureCollapsedDirection = ChevronDirection::Right;
    bool _pressed                                  = false;
    bool _pressedDropDown                          = false;
    bool _dropDownOpen                             = false;
    bool _primary                                  = false;
    bool _multiline                                = false;
    ButtonVariant _variant                         = ButtonVariant::Standard;
};

class Toggle : public Button
{
public:
    explicit Toggle(std::wstring text = {});

    void SetChecked(bool checked) noexcept;
    [[nodiscard]] bool IsChecked() const noexcept;
    void SetStateLabels(std::wstring uncheckedText, std::wstring checkedText);
    [[nodiscard]] std::wstring_view GetActiveStateLabel() const noexcept;
    [[nodiscard]] std::wstring_view GetDisplayedText() const noexcept;
    void SetOnToggled(std::function<void(bool)> onToggled);
    [[nodiscard]] ToggleLayoutMetrics GetLayoutMetrics() const noexcept;

    void Paint(ControlHost& host) const override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    bool OnMnemonic(ControlHost& host) override;

private:
    void ApplyCheckedState(ControlHost& host, bool checked, bool notify);

    std::wstring _uncheckedText;
    std::wstring _checkedText;
    std::shared_ptr<const std::function<void(bool)>> _onToggled;
    bool _checked = false;
};

class Checkbox final : public Toggle
{
public:
    explicit Checkbox(std::wstring text = {});

    void SetIndeterminate(bool indeterminate) noexcept;
    [[nodiscard]] bool IsIndeterminate() const noexcept;

    void Paint(ControlHost& host) const override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    bool OnMnemonic(ControlHost& host) override;

private:
    bool _indeterminate = false;
};

class RadioButtons;

class RadioButton final : public Button
{
public:
    explicit RadioButton(std::wstring text = {});

    void SetChecked(bool checked) noexcept;
    [[nodiscard]] bool IsChecked() const noexcept;
    void SetOnSelected(std::function<void()> onSelected);
    void SetGroup(RadioButtons* group) noexcept;

    void Paint(ControlHost& host) const override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    bool OnMnemonic(ControlHost& host) override;

private:
    void SelectSelf(ControlHost& host);

    std::shared_ptr<const std::function<void()>> _onSelected;
    RadioButtons* _group = nullptr;
    bool _checked        = false;
};

class RadioButtons final : public Panel
{
public:
    RadioButtons() = default;

    RadioButton* AddItem(std::wstring text);
    void SetSelectedIndex(int index) noexcept;
    [[nodiscard]] int GetSelectedIndex() const noexcept;
    void SetOnSelectionChanged(std::function<void(int)> onSelectionChanged);
    void SetHeader(std::wstring text);

    void Paint(ControlHost& host) const override;

private:
    friend class RadioButton;
    void SelectItem(RadioButton* item);

    std::shared_ptr<const std::function<void(int)>> _onSelectionChanged;
    std::wstring _header;
    int _selectedIndex = -1;
};

class ProgressBar final : public Control
{
public:
    ProgressBar() = default;

    void SetValue(double value) noexcept;
    [[nodiscard]] double GetValue() const noexcept;
    void SetMinimum(double minimum) noexcept;
    [[nodiscard]] double GetMinimum() const noexcept;
    void SetMaximum(double maximum) noexcept;
    [[nodiscard]] double GetMaximum() const noexcept;
    void SetIndeterminate(bool indeterminate) noexcept;
    [[nodiscard]] bool IsIndeterminate() const noexcept;
    void SetTrackHeightDip(float heightDip) noexcept;
    [[nodiscard]] float GetTrackHeightDip() const noexcept;
    void SetSegmentedValues(double primaryValue, double secondaryValue, D2D1_COLOR_F secondaryColor) noexcept;
    void ClearSegmentedValues() noexcept;
    [[nodiscard]] bool HasSegmentedValues() const noexcept;

    void Paint(ControlHost& host) const override;
    bool Tick(ControlHost& host, uint64_t nowTickMs) override;

#if DXUI_ENABLE_DIAGNOSTICS
    // The segment the indeterminate state paints under this theme, in DIPs. Empty (left == right) while off the track.
    [[nodiscard]] D2D1_RECT_F DebugGetIndeterminateSegmentRect(const ThemePalette& theme) const noexcept;
#endif

private:
    double _value                       = 0.0;
    double _minimum                     = 0.0;
    double _maximum                     = 100.0;
    double _primarySegmentValue         = 0.0;
    double _secondarySegmentValue       = 0.0;
    D2D1_COLOR_F _secondarySegmentColor = D2D1::ColorF(D2D1::ColorF::Orange);
    bool _segmented                     = false;
    bool _indeterminate                 = false;
    float _trackHeightDip               = 0.0f;
    mutable float _animationPhase       = 0.0f;
    uint64_t _lastTickMs                = 0;
};

class PageIndicator final : public Control
{
public:
    static constexpr uint32_t kMaximumPages      = 16;
    static constexpr float kStripHeightDip       = 20.0f;
    static constexpr float kDotRadiusDip         = 3.0f;
    static constexpr float kSelectedDotRadiusDip = 4.0f;
    static constexpr float kDotGapDip            = 14.0f;

    PageIndicator();

    void SetPageCount(uint32_t count) noexcept;
    [[nodiscard]] uint32_t GetPageCount() const noexcept;
    void SetSelectedIndex(uint32_t index) noexcept;
    [[nodiscard]] uint32_t GetSelectedIndex() const noexcept;
    void SetOnSelected(std::function<void(uint32_t)> onSelected);
    [[nodiscard]] uint32_t HitPageIndex(D2D1_POINT_2F point) const noexcept;
    [[nodiscard]] D2D1_POINT_2F DotCenter(uint32_t index) const noexcept;

    [[nodiscard]] D2D1_RECT_F GetHitBounds() const noexcept override;
    void Paint(ControlHost& host) const override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    void OnCaptureLost(ControlHost& host) override;

private:
    void SelectIndex(ControlHost& host, uint32_t index);
    void RefreshAccessibleName() noexcept;

    std::shared_ptr<const std::function<void(uint32_t)>> _onSelected;
    uint32_t _pageCount     = 0;
    uint32_t _selectedIndex = 0;
    uint32_t _pressedIndex  = UINT32_MAX;
    bool _pressed           = false;
};

struct ThroughputGraphHueWeight final
{
    float hueDegrees  = -1.0f;
    double weight     = 0.0;
    uint8_t colorSlot = (std::numeric_limits<uint8_t>::max)();
};

struct ThroughputGraphSample final
{
    static constexpr size_t kMaxSamples        = 180u;
    static constexpr size_t kMaxHueWeights     = 16u;
    static constexpr uint8_t kInvalidColorSlot = (std::numeric_limits<uint8_t>::max)();

    double value      = 0.0;
    float hueDegrees  = -1.0f;
    uint8_t colorSlot = kInvalidColorSlot;
    std::array<ThroughputGraphHueWeight, kMaxHueWeights> hueWeights{};
    size_t hueWeightCount = 0u;
};

struct ThroughputGraphBandPaintOptions final
{
    D2D1_COLOR_F baseFillColor{};
    bool rainbowMode    = false;
    bool perStreamBands = false;
    bool highContrast   = false;
    bool dark           = false;
};

struct ThroughputGraphBandPaintMetrics final
{
    size_t sampleCount          = 0u;
    size_t quadCount            = 0u;
    size_t geometryCount        = 0u;
    size_t activeColorSlotCount = 0u;
    uint64_t renderDurationUs   = 0u;
    float fillAlpha             = 0.0f;
    bool bandsActive            = false;
};

// One semantic gate is shared by the retained control and legacy/fallback host:
// Rainbow may color one admitted stream, while ordinary themes require history
// that proves at least two concurrent stream slots. High Contrast always wins.
[[nodiscard]] bool ShouldRenderThroughputGraphBands(bool rainbowMode, bool perStreamBands, bool highContrast, size_t maximumConcurrentColorSlots) noexcept;

// Canonical fixed-slot band painter used by all throughput graph hosts. Stream
// colorSlot values are bounded by ThroughputGraphSample::kMaxHueWeights; one
// internal fallback batch covers samples without stream attribution.
[[nodiscard]] ThroughputGraphBandPaintMetrics PaintThroughputGraphBands(ID2D1RenderTarget* target,
                                                                        const D2D1_RECT_F& bounds,
                                                                        std::span<const ThroughputGraphSample> samples,
                                                                        double displayedLatestValue,
                                                                        double maximum,
                                                                        const ThroughputGraphBandPaintOptions& options) noexcept;

struct ThroughputGraphDebugState final
{
    size_t sampleCount                    = 0u;
    size_t hueBandCount                   = 0u;
    size_t renderedQuadCount              = 0u;
    size_t renderedGeometryCount          = 0u;
    size_t activeColorSlotCount           = 0u;
    bool usesRainbowStroke                = false;
    bool bandsActive                      = false;
    bool transitionActive                 = false;
    bool reducedMotion                    = false;
    bool highContrast                     = false;
    uint64_t bandRenderDurationUs         = 0u;
    float bandFillAlpha                   = 0.0f;
    double displayedLatestValue           = 0.0;
    double targetLatestValue              = 0.0;
    bool currentValueMarkerVisible        = false;
    bool secondarySeriesVisible           = false;
    bool secondarySeriesColorCustomized   = false;
    bool currentValueTrailingLabelVisible = false;
    double displayedCurrentValue          = 0.0;
    double targetCurrentValue             = 0.0;
};

// Canonical rainbow color for throughput samples and any UI that identifies the
// same transfer stream outside the graph.
[[nodiscard]] D2D1_COLOR_F ThroughputGraphColorFromHue(float hueDegrees, bool dark) noexcept;

// Reusable throughput history control. It renders an optional limit marker,
// rainbow sample strokes, and per-stream hue-weight bands while honoring the
// host's reduced-motion and high-contrast palette contracts.
class ThroughputGraph final : public Control
{
public:
    ThroughputGraph() = default;

    void SetSamples(std::span<const ThroughputGraphSample> samples);
    void SetSecondarySamples(std::span<const double> samples);
    void SetSecondarySeriesColor(D2D1_COLOR_F color) noexcept;
    void SetLimit(double value) noexcept;
    void SetCurrentValueMarker(double value, std::wstring label, std::wstring trailingLabel = {});
    void SetOverlayText(std::wstring text);
    void SetRainbowMode(bool enabled) noexcept;
    void SetPerStreamBands(bool enabled) noexcept;
    void SetTransitionDuration(uint64_t durationMs) noexcept;
    [[nodiscard]] ThroughputGraphDebugState GetDebugState() const noexcept;

    void Paint(ControlHost& host) const override;
    bool Tick(ControlHost& host, uint64_t nowTickMs) override;

private:
    std::vector<ThroughputGraphSample> _samples;
    std::vector<double> _secondarySamples;
    std::optional<D2D1_COLOR_F> _secondarySeriesColor;
    std::wstring _overlayText;
    std::wstring _currentValueLabel;
    std::wstring _currentValueTrailingLabel;
    double _limit                               = 0.0;
    double _displayedLatestValue                = 0.0;
    double _transitionStartValue                = 0.0;
    double _targetLatestValue                   = 0.0;
    double _displayedCurrentValue               = 0.0;
    double _currentValueTransitionStart         = 0.0;
    double _targetCurrentValue                  = 0.0;
    uint64_t _transitionStartTickMs             = 0u;
    uint64_t _currentValueTransitionStartTickMs = 0u;
    uint64_t _transitionDurationMs              = 160u;
    bool _rainbowMode                           = false;
    bool _perStreamBands                        = false;
    bool _transitionActive                      = false;
    bool _currentValueTransitionActive          = false;
    mutable bool _lastReducedMotion             = false;
    mutable bool _lastHighContrast              = false;
    mutable ThroughputGraphBandPaintMetrics _lastBandPaintMetrics{};
};

enum class SliderOrientation : uint8_t
{
    Horizontal,
    Vertical,
};

enum class SliderChangePhase : uint8_t
{
    Preview,
    Commit,
    Cancel
};
struct SliderChange
{
    SliderChangePhase phase;
    double value;
};

class Slider final : public Control
{
public:
    Slider();

    void SetOrientation(SliderOrientation orientation) noexcept;
    [[nodiscard]] SliderOrientation GetOrientation() const noexcept;
    void SetMinimum(double minimum) noexcept;
    [[nodiscard]] double GetMinimum() const noexcept;
    void SetMaximum(double maximum) noexcept;
    [[nodiscard]] double GetMaximum() const noexcept;
    void SetValue(double value) noexcept;
    // One committed user edit; rejects disabled controls, active pointer gestures and non-finite/out-of-range values.
    bool RequestValue(ControlHost& host, double value) noexcept;
    [[nodiscard]] double GetValue() const noexcept;
    void SetStep(double step) noexcept;
    [[nodiscard]] double GetStep() const noexcept;
    void SetLargeStep(double step) noexcept;
    [[nodiscard]] double GetLargeStep() const noexcept;
    void SetTickMarks(std::vector<double> tickMarks);
    [[nodiscard]] std::span<const double> GetTickMarks() const noexcept;
    void SetOnValueChanged(std::function<void(double)> onValueChanged);
    // Preview during drag; exactly one Commit on release, or Cancel restoring the starting value. Keyboard changes commit.
    void SetOnChange(std::function<void(SliderChange)> onChange);

    void Paint(ControlHost& host) const override;
    bool Tick(ControlHost& host, uint64_t nowTickMs) override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    void OnHoverChanged(ControlHost& host, bool hovered) override;
    void OnEnabledChanged(bool enabled) noexcept override;
    void OnCaptureLost(ControlHost& host) override;
    [[nodiscard]] D2D1_RECT_F GetHitBounds() const noexcept override;

#if DXUI_ENABLE_DIAGNOSTICS
    [[nodiscard]] D2D1_RECT_F DebugGetTrackRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetThumbRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetInnerThumbRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetHaloRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetFillRect() const noexcept;
    [[nodiscard]] float DebugGetHoverAnimationProgress() const noexcept;
    [[nodiscard]] float DebugGetPressAnimationProgress() const noexcept;
    // The touch halo, shown while a touch contact drags the slider: its painted rectangle and transition progress.
    [[nodiscard]] D2D1_RECT_F DebugGetTouchHaloRect() const noexcept;
    [[nodiscard]] float DebugGetTouchHaloProgress() const noexcept;
    [[nodiscard]] double DebugGetDisplayedValue() const noexcept;
#endif

private:
    struct VisualTransitionState final
    {
        float progress       = 0.0f;
        float startProgress  = 0.0f;
        float target         = 0.0f;
        uint64_t startTickMs = 0u;
        bool active          = false;
    };

    [[nodiscard]] double ClampValue(double value) const noexcept;
    [[nodiscard]] double GetDisplayedNormalizedValue() const noexcept;
    void SetValueInternal(ControlHost* host, double value, bool notifyChanged, bool animatePosition) noexcept;
    void SnapDisplayedValue() noexcept;
    void PublishRangeState() noexcept;
    void BeginValueAnimation(ControlHost& host, double fromValue, double toValue) noexcept;
    [[nodiscard]] bool AdvanceValueAnimation(ControlHost& host, uint64_t nowTickMs) noexcept;
    void BeginVisualTransition(ControlHost& host, VisualTransitionState& transition, float target) noexcept;
    [[nodiscard]] bool AdvanceVisualTransition(VisualTransitionState& transition, uint64_t nowTickMs, EasingCurve curve) noexcept;
    void SnapVisualTransitions() noexcept;
    void SyncInteractionVisuals(ControlHost& host) noexcept;
    [[nodiscard]] D2D1_POINT_2F GetThumbCenter() const noexcept;
    [[nodiscard]] float ResolveInnerThumbDiameter() const noexcept;
    [[nodiscard]] float ResolveHaloDiameter(const D2D1_RECT_F& bounds) const noexcept;
    [[nodiscard]] D2D1_COLOR_F ResolveChromeColor(const ThemePalette& theme) const noexcept;
    [[nodiscard]] D2D1_RECT_F GetTrackRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetThumbRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetInnerThumbRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetHaloRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetTouchHaloRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetFillRect() const noexcept;
    void UpdateValueFromPoint(ControlHost& host, D2D1_POINT_2F point) noexcept;

    void NotifyChange(SliderChangePhase phase, bool notifyLegacy) noexcept;
    std::shared_ptr<const std::function<void(SliderChange)>> _onChange;
    double _dragInitialValue = 0.0;
    std::shared_ptr<const std::function<void(double)>> _onValueChanged;
    std::vector<double> _tickMarks;
    double _minimum                     = 0.0;
    double _maximum                     = 100.0;
    double _value                       = 0.0;
    double _displayedValue              = 0.0;
    double _valueAnimationStart         = 0.0;
    double _valueAnimationTarget        = 0.0;
    uint64_t _valueAnimationStartTickMs = 0u;
    double _step                        = 1.0;
    double _largeStep                   = 10.0;
    SliderOrientation _orientation      = SliderOrientation::Horizontal;
    VisualTransitionState _hoverTransition{};
    VisualTransitionState _pressTransition{};
    VisualTransitionState _touchTransition{};
    bool _dragging = false;
    // The drag began with a touch contact, so the touch halo shows until it ends.
    bool _touchDragging                                       = false;
    bool _valueAnimationActive                                = false;
    float _dragThumbPointerOffsetDip                          = 0.0f;
    static constexpr uint64_t _interactionAnimationDurationMs = 100u;
    static constexpr uint64_t _valueAnimationDurationMs       = 167u;
};

class Toolbar final : public Panel
{
public:
    Toolbar() = default;

    Button* AddButton(std::wstring tooltip, std::wstring iconGlyph);
    Toggle* AddToggleButton(std::wstring tooltip, std::wstring iconGlyph);
    void AddSeparator();

    void Paint(ControlHost& host) const override;
};

class MenuBar final : public Control
{
public:
    static constexpr float kDefaultHeightDip = 30.0f;

    using OpenItemCallback     = std::function<void(size_t index, POINT screenPoint, bool keyboardInvocation)>;
    using HoverChangedCallback = std::function<void(std::optional<size_t> hoveredIndex)>;

    MenuBar();

    void SetItems(std::vector<MenuBarItem> items);
    [[nodiscard]] std::span<const MenuBarItem> GetItems() const noexcept;
    void SetOnOpenItem(OpenItemCallback onOpenItem);
    void SetOnHoverChanged(HoverChangedCallback onHoverChanged);
    void SetSelectedIndex(std::optional<size_t> index) noexcept;
    void ClearInteractionState() noexcept;
    void SetRetainSelectedIndexOnFocusLost(bool retain) noexcept;
    [[nodiscard]] std::optional<size_t> GetSelectedIndex() const noexcept;
    [[nodiscard]] std::optional<size_t> GetHoveredIndex() const noexcept;
    [[nodiscard]] std::optional<size_t> GetVisualHighlightIndex() const noexcept;
    [[nodiscard]] size_t GetVisualHighlightCount() const noexcept;
    [[nodiscard]] bool ActivateMnemonic(ControlHost& host, wchar_t mnemonic);
    [[nodiscard]] bool ActivateItem(ControlHost& host, size_t index, bool keyboardInvocation);
    [[nodiscard]] bool ActivateSelected(ControlHost& host, bool keyboardInvocation);
    [[nodiscard]] std::optional<size_t> HitTestPoint(const ControlHost& host, PointDip pointDip) const noexcept;
    [[nodiscard]] bool TryGetItemScreenRect(const ControlHost& host, size_t index, RECT& rectPx) const noexcept;

    void Paint(ControlHost& host) const override;
    bool OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers) override;
    bool OnMouseLeave(ControlHost& host) override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    bool OnMnemonic(ControlHost& host) override;

protected:
    void PropagateHost(ControlHost* host) noexcept override;
    void OnBoundsChanged() noexcept override;
    void OnFlowDirectionChanged() noexcept override;
    void OnDensityChanged() noexcept override;
    void OnHostDpiChanged(ControlHost& host) noexcept override;
    void OnFocusChanged(ControlHost& host, bool focused) override;
    void OnCaptureLost(ControlHost& host) override;

private:
    struct MenuBarLayoutCache
    {
        bool valid              = false;
        const ControlHost* host = nullptr;
        D2D1_RECT_F bounds{};
        DWRITE_READING_DIRECTION readingDirection = DWRITE_READING_DIRECTION_LEFT_TO_RIGHT;
        IDWriteTextFormat* textFormat             = nullptr;
        FontRole fontRole                         = FontRole::Body;
        float menuBarHeightDip                    = 0.0f;
        float insetDip                            = 0.0f;
        float itemGapDip                          = 0.0f;
        float itemPaddingXDip                     = 0.0f;
        float measureHeightDip                    = 0.0f;
        std::vector<float> itemWidthsDip;
        std::vector<D2D1_RECT_F> itemRects;
    };

    void InvalidateMenuBarLayoutCache() const noexcept;
    [[nodiscard]] const MenuBarLayoutCache& EnsureMenuBarLayoutCache(const ControlHost& host) const noexcept;
    [[nodiscard]] std::optional<size_t> HitTestItem(const ControlHost& host, PointDip pointDip) const noexcept;
    [[nodiscard]] D2D1_RECT_F GetItemRect(const ControlHost& host, size_t index) const noexcept;
    [[nodiscard]] float MeasureItemWidth(const ControlHost& host, const MenuBarItem& item) const noexcept;
    [[nodiscard]] std::optional<size_t> FindMnemonicItem(wchar_t mnemonic) const noexcept;
    void InvalidateIfInteractive(ControlHost& host) noexcept;

    std::vector<MenuBarItem> _items;
    std::shared_ptr<const OpenItemCallback> _onOpenItem;
    std::shared_ptr<const HoverChangedCallback> _onHoverChanged;
    std::optional<size_t> _hoveredIndex;
    std::optional<size_t> _selectedIndex;
    std::optional<size_t> _pressedIndex;
    bool _retainSelectedIndexOnFocusLost = false;
    mutable MenuBarLayoutCache _menuBarLayoutCache;
};

class TabControl final : public Panel
{
public:
    struct TabItem
    {
        std::wstring title;
        std::wstring tooltipText;
        mutable std::optional<float> measuredTitleWidthDip;
        mutable wil::com_ptr<IDWriteTextFormat> measuredTitleTextFormat;
        mutable DWRITE_READING_DIRECTION measuredTitleReadingDirection = DWRITE_READING_DIRECTION_LEFT_TO_RIGHT;
        bool closable                                                  = false;
        bool visible                                                   = true;
    };

    TabControl();

    template <typename TControl, typename... TArgs> TControl* AddTab(std::wstring title, TArgs&&... args)
    {
        const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
        auto* child                            = AddChild<TControl>(std::forward<TArgs>(args)...);
        if (ownerLifetime.expired() || ! child)
        {
            return nullptr;
        }
        const std::weak_ptr<int> pageLifetime = GetControlLifetimeToken(*child);
        _tabs.push_back(TabItem{.title = std::move(title)});
        InvalidateTabHeaderLayoutCache();
        if (! _selectedIndex.has_value())
        {
            _selectedIndex = _tabs.size() - 1u;
        }
        if (! SyncLayout() || ownerLifetime.expired() || pageLifetime.expired() || ! FindTabIndex(child, pageLifetime))
        {
            return nullptr;
        }
        return child;
    }

    void RemoveTab(size_t index) noexcept;
    void SetTabTitle(size_t index, std::wstring title);
    [[nodiscard]] std::wstring_view GetTabTitle(size_t index) const noexcept;
    void SetTabTooltip(size_t index, std::wstring tooltipText);
    [[nodiscard]] std::wstring_view GetTabTooltip(size_t index) const noexcept;
    void SetTabClosable(size_t index, bool closable) noexcept;
    [[nodiscard]] bool IsTabClosable(size_t index) const noexcept;
    void SetTabVisible(size_t index, bool visible) noexcept;
    [[nodiscard]] bool IsTabVisible(size_t index) const noexcept;
    void SetTabReorderingEnabled(bool enabled) noexcept;
    [[nodiscard]] bool IsTabReorderingEnabled() const noexcept;
    [[nodiscard]] size_t GetTabCount() const noexcept;
    [[nodiscard]] size_t GetVisibleTabCount() const noexcept;
    void SetSelectedIndex(std::optional<size_t> index) noexcept;
    [[nodiscard]] std::optional<size_t> GetSelectedIndex() const noexcept;
    [[nodiscard]] Control* GetSelectedPage() noexcept;
    [[nodiscard]] const Control* GetSelectedPage() const noexcept;
    void SetOnSelectionChanged(std::function<void(size_t)> onSelectionChanged);
    void SetOnTabCloseRequested(std::function<bool(size_t)> onTabCloseRequested);
    void SetOnTabClosed(std::function<void(size_t)> onTabClosed);
    void SetOnTabReordered(std::function<void(size_t, size_t)> onTabReordered);

    void Paint(ControlHost& host) const override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers) override;
    bool OnMouseLeave(ControlHost& host) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseWheel(ControlHost& host, D2D1_POINT_2F point, float wheelDelta, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    void OnCaptureLost(ControlHost& host) override;

#if DXUI_ENABLE_DIAGNOSTICS
    [[nodiscard]] D2D1_RECT_F DebugGetTabRect(size_t index) const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetCloseButtonRect(size_t index) const noexcept;
    [[nodiscard]] bool DebugIsCloseButtonVisible(size_t index) const noexcept;
    [[nodiscard]] float DebugGetHeaderScrollOffsetDip() const noexcept;
    [[nodiscard]] bool DebugHasOverflowButtons() const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetHeaderDividerRect() const noexcept;
    [[nodiscard]] bool DebugHasHeaderDivider() const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetBackButtonRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetForwardButtonRect() const noexcept;
#endif

protected:
    [[nodiscard]] Control* HitTest(D2D1_POINT_2F point) override;
    [[nodiscard]] const Control* HitTest(D2D1_POINT_2F point) const override;
    void PropagateHost(ControlHost* host) noexcept override;
    void OnBoundsChanged() noexcept override;
    void OnFlowDirectionChanged() noexcept override;
    void OnDensityChanged() noexcept override;
    void OnHostDpiChanged(ControlHost& host) noexcept override;

private:
    enum class HeaderPart : uint8_t
    {
        None,
        BackButton,
        ForwardButton,
        Tab,
        CloseButton,
    };

    struct HeaderHitInfo
    {
        HeaderPart part = HeaderPart::None;
        size_t index    = 0u;
    };

    struct TabHeaderLayoutCache
    {
        bool valid                = false;
        bool needsOverflowButtons = false;
        float viewportLeftDip     = 0.0f;
        float viewportRightDip    = 0.0f;
        float totalTabWidthDip    = 0.0f;
        D2D1_RECT_F backButtonRect{};
        D2D1_RECT_F forwardButtonRect{};
        std::vector<float> tabWidthsDip;
        std::vector<D2D1_RECT_F> tabRects;
    };

    [[nodiscard]] bool SyncLayout() noexcept;
    [[nodiscard]] bool UpdateVisiblePageBounds() noexcept;
    [[nodiscard]] std::optional<size_t> FindTabIndex(const Control* page, const std::weak_ptr<int>& pageLifetime) const noexcept;
    [[nodiscard]] bool RemoveTabByIdentity(Control* page, const std::weak_ptr<int>& pageLifetime, size_t& removedIndex) noexcept;
    void EnsureSelectedTabVisible() noexcept;
    void InvalidateTabHeaderLayoutCache() const noexcept;
    void InvalidateTabTitleMeasurements() const noexcept;
    [[nodiscard]] const TabHeaderLayoutCache& EnsureTabHeaderLayoutCache() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetHeaderRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetContentRect() const noexcept;
    [[nodiscard]] bool NeedsOverflowButtons() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetHeaderDividerRect() const noexcept;
    [[nodiscard]] bool HasHeaderDividerPaintSegment() const noexcept;
    [[nodiscard]] float GetHeaderViewportLeft() const noexcept;
    [[nodiscard]] float GetHeaderViewportRight() const noexcept;
    [[nodiscard]] float MeasureTabTitleWidthDip(size_t index, const ControlHost& host) const noexcept;
    [[nodiscard]] float MeasureTabWidthDip(size_t index) const noexcept;
    [[nodiscard]] float GetTotalTabWidthDip() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetBackButtonRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetForwardButtonRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetTabRect(size_t index) const noexcept;
    [[nodiscard]] D2D1_RECT_F GetCloseButtonRect(size_t index) const noexcept;
    [[nodiscard]] bool IsCloseButtonVisible(size_t index) const noexcept;
    [[nodiscard]] HeaderHitInfo HitTestHeader(D2D1_POINT_2F point) const noexcept;
    void ScrollHeaderBy(float deltaDip) noexcept;
    // False when the focus or selection callbacks destroyed this control, which its caller then leaves alone.
    [[nodiscard]] bool SelectTab(ControlHost& host, size_t index, bool focusSelf) noexcept;
    void CloseTab(ControlHost& host, size_t index) noexcept;
    void ReorderTab(size_t fromIndex, size_t toIndex) noexcept;
    void UpdateDragReorder(ControlHost& host, D2D1_POINT_2F point) noexcept;
    void PaintHeaderDivider(ControlHost& host) const noexcept;

    std::vector<TabItem> _tabs;
    std::shared_ptr<const std::function<void(size_t)>> _onSelectionChanged;
    std::shared_ptr<const std::function<bool(size_t)>> _onTabCloseRequested;
    std::shared_ptr<const std::function<void(size_t)>> _onTabClosed;
    std::shared_ptr<const std::function<void(size_t, size_t)>> _onTabReordered;
    std::optional<size_t> _selectedIndex;
    std::optional<size_t> _hoveredTabIndex;
    std::optional<size_t> _pressedTabIndex;
    std::optional<size_t> _closePressedIndex;
    std::optional<size_t> _draggingTabIndex;
    D2D1_POINT_2F _dragStartPoint = D2D1::Point2F();
    float _headerScrollOffsetDip  = 0.0f;
    bool _tabReorderingEnabled    = true;
    bool _dragReordering          = false;
    mutable TabHeaderLayoutCache _tabHeaderLayoutCache;
};

class ColorSwatch final : public Control
{
public:
    explicit ColorSwatch(std::optional<uint32_t> swatchArgb = std::nullopt);

    void SetSwatchValue(std::optional<uint32_t> swatchArgb) noexcept;
    [[nodiscard]] std::optional<uint32_t> GetSwatchValue() const noexcept;
    void SetOnClick(std::function<void()> onClick);

    void Paint(ControlHost& host) const override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    void OnCaptureLost(ControlHost& host) override;

private:
    std::optional<uint32_t> _swatchArgb;
    std::shared_ptr<const std::function<void()>> _onClick;
    bool _pressed = false;
};

class TextField : public Control
{
public:
    explicit TextField(std::wstring text = {});
    ~TextField() noexcept override;

    void SetText(std::wstring text);
    void SetTextAndNotify(std::wstring text);
    [[nodiscard]] std::wstring_view GetText() const noexcept;
    [[nodiscard]] size_t GetCaretIndex() const noexcept;
    void SetSelectionRange(size_t selectionStart, size_t selectionEnd) noexcept;
    [[nodiscard]] std::optional<std::pair<size_t, size_t>> GetSelectionRange() const noexcept;
    void ReplaceSelectionAndNotify(std::wstring_view replacement);
    void SetMasked(bool masked) noexcept;
    [[nodiscard]] bool IsMasked() const noexcept;
    void SetPasswordRevealMode(PasswordRevealMode mode) noexcept;
    [[nodiscard]] PasswordRevealMode GetPasswordRevealMode() const noexcept;
    void SetPasswordRevealState(PasswordRevealState state) noexcept;
    [[nodiscard]] PasswordRevealState GetPasswordRevealState() const noexcept;
    void SetPasswordMaskLengthPolicy(PasswordMaskLengthPolicy policy) noexcept;
    [[nodiscard]] PasswordMaskLengthPolicy GetPasswordMaskLengthPolicy() const noexcept;
    [[nodiscard]] size_t GetSecretVisibleDotCount() const noexcept;
    void SetPasswordRevealAccessibleName(std::wstring name);
    [[nodiscard]] std::wstring_view GetPasswordRevealAccessibleName() const noexcept;
    [[nodiscard]] bool IsPasswordRevealButtonVisibleForAccessibility() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetPasswordRevealButtonAccessibilityRect() const noexcept;
    [[nodiscard]] bool InvokePasswordRevealButton(ControlHost& host);
    void SetPlaceholder(std::wstring text);
    void SetMultiline(bool multiline) noexcept;
    [[nodiscard]] bool IsMultiline() const noexcept;
    void SetClearButtonEnabled(bool enabled) noexcept;
    [[nodiscard]] bool IsClearButtonEnabled() const noexcept;
    void SetCaretColor(std::optional<D2D1_COLOR_F> caretColor) noexcept;
    void SetHorizontalTextPadding(float leftDip, float rightDip) noexcept;
    void SetVerticalTextPadding(float topDip, float bottomDip) noexcept;
    void SetReadOnly(bool readOnly) noexcept;
    [[nodiscard]] bool IsReadOnly() const noexcept;
    void SetOnTextChanged(std::function<void(std::wstring_view)> onTextChanged);
    void SetOnSubmitted(std::function<void()> onSubmitted);
    void SetOnPreviewKeyDown(std::function<bool(ControlHost& host, UINT virtualKey, UINT modifiers)> onPreviewKeyDown);
    void SetOnBlur(std::function<void()> onBlur);
    [[nodiscard]] bool DebugGetMultilineState(const ControlHost& host, TextFieldDebugMultilineState& out) const noexcept;
    [[nodiscard]] bool DebugGetSingleLinePaintState(const ControlHost& host, TextFieldDebugSingleLinePaintState& out) const noexcept;
    [[nodiscard]] bool DebugGetCaretRect(const ControlHost& host, size_t controlTextIndex, D2D1_RECT_F& outRect) const noexcept;

    void Paint(ControlHost& host) const override;
    bool Tick(ControlHost& host, uint64_t nowTickMs) override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseDoubleClick(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    void OnCaptureLost(ControlHost& host) override;
    bool OnMouseWheel(ControlHost& host, D2D1_POINT_2F point, float wheelDelta, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    bool OnKeyUp(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    bool OnChar(ControlHost& host, wchar_t ch, UINT modifiers) override;
    bool OnContextMenu(ControlHost& host, bool keyboardInvocation, D2D1_POINT_2F pointDip) override;
    bool OnCopy(ControlHost& host) override;
    bool OnSelectAll(ControlHost& host) override;

protected:
    void OnBoundsChanged() noexcept override;
    void OnFocusChanged(ControlHost& host, bool focused) override;
    void OnEnabledChanged(bool enabled) noexcept override;
    void OnFlowDirectionChanged() noexcept override;
    void OnDensityChanged() noexcept override;
    void OnHostDpiChanged(ControlHost& host) noexcept override;
    [[nodiscard]] bool SupportsTextInput() const noexcept override;
    [[nodiscard]] std::optional<D2D1_RECT_F> GetTextInputViewportRect() const noexcept override;
    [[nodiscard]] std::optional<D2D1_RECT_F> GetTextInputCaretRect(const ControlHost& host, size_t controlTextIndex) const noexcept override;
    [[nodiscard]] std::optional<std::vector<D2D1_RECT_F>> GetTextInputRangeRects(const ControlHost& host,
                                                                                 size_t controlTextStartIndex,
                                                                                 size_t controlTextEndIndex) const override;
    [[nodiscard]] std::optional<size_t> HitTestTextInputPoint(const ControlHost& host, D2D1_POINT_2F point) const noexcept override;
    bool ExportTextInputState(TextInputState& outState) const override;
    bool ImportTextInputState(ControlHost& host, const TextInputState& state, bool notifyChange) override;

private:
    struct EditHistoryState
    {
        std::wstring text;
        size_t caretIndex = 0u;
        std::optional<size_t> selectionAnchorIndex;
        size_t firstVisibleLine = 0u;
    };

    enum class DirectEditMergeKind : uint8_t
    {
        None,
        InsertRun,
        BackspaceRun,
        DeleteRun,
    };

    [[nodiscard]] std::wstring GetDisplayText() const;
    [[nodiscard]] bool UsesMaskedDisplayText() const noexcept;
    [[nodiscard]] const std::vector<size_t>& GetMaskedSourceTextElementBoundaries() const noexcept;
    [[nodiscard]] size_t ControlTextIndexToDisplayTextIndex(size_t controlTextIndex) const noexcept;
    [[nodiscard]] size_t DisplayTextIndexToControlTextIndex(size_t displayTextIndex) const noexcept;
    [[nodiscard]] std::optional<std::pair<size_t, size_t>> ControlTextRangeToDisplayTextRange(size_t controlTextStartIndex,
                                                                                              size_t controlTextEndIndex) const noexcept;
    [[nodiscard]] D2D1_RECT_F GetTextRect() const noexcept;
    [[nodiscard]] bool IsClearButtonVisible() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetClearButtonRect() const noexcept;
    [[nodiscard]] bool IsPasswordRevealButtonVisible() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetPasswordRevealButtonRect() const noexcept;
    [[nodiscard]] wil::com_ptr<IDWriteTextLayout> GetOrCreateMultilineLayout(const ControlHost* host,
                                                                             std::wstring_view text,
                                                                             float widthDip,
                                                                             float heightDip) const noexcept;
    [[nodiscard]] wil::com_ptr<IDWriteTextLayout> GetOrCreateSingleLineLayout(
        const ControlHost* host, std::wstring_view text, float minimumWidthDip, float heightDip, DWRITE_READING_DIRECTION readingDirection) const noexcept;
    void InvalidateSingleLineLayoutCache() const noexcept;
    void InvalidateMultilineLayoutCache() const noexcept;
    void EnsureCaretVisible(const ControlHost* host, float availableWidthDip) const noexcept;
    void EnsureMultilineCaretVisible(const ControlHost* host) noexcept;
    void ResetCaretBlink(ControlHost& host) noexcept;
    void SetCaretIndex(size_t caretIndex, bool extendSelection) noexcept;
    [[nodiscard]] bool HasSelection() const noexcept;
    [[nodiscard]] bool DeleteSelection() noexcept;
    [[nodiscard]] EditHistoryState CaptureEditHistoryState() const;
    void RestoreEditHistoryState(const EditHistoryState& state) noexcept;
    void SecureClearStorage() noexcept;
    void RefreshAccessibilitySnapshot() const noexcept;
    void BeginEditTransactionMetric(const wchar_t* detail) noexcept;
    void FinishEditTransactionMetric() noexcept;
    void RegenerateConcealedMaskEpoch() const noexcept;
    [[nodiscard]] size_t GetConcealedMaskVisibleDotCount(size_t exactCount) const noexcept;
    void BreakDirectEditMerge() noexcept;
    void RecordUndoStateForDirectEdit(DirectEditMergeKind mergeKind = DirectEditMergeKind::None);
    [[nodiscard]] bool TryUndoDirectEdit() noexcept;
    [[nodiscard]] bool TryRedoDirectEdit() noexcept;
    void RemaskPasswordReveal() noexcept;
    void SelectAllText() noexcept;
    void SelectWordAt(size_t hitIndex) noexcept;
    [[nodiscard]] bool NotifyChanged();

    std::wstring _text;
    std::wstring _placeholder;
    std::shared_ptr<const std::function<void(std::wstring_view)>> _onTextChanged;
    std::shared_ptr<const std::function<void()>> _onSubmitted;
    std::shared_ptr<const std::function<bool(ControlHost& host, UINT virtualKey, UINT modifiers)>> _onPreviewKeyDown;
    std::shared_ptr<const std::function<void()>> _onBlur;
    size_t _caretIndex = 0;
    std::optional<size_t> _selectionAnchorIndex;
    std::optional<float> _preferredMultilineXOffsetDip;
    uint64_t _caretBlinkAnchorTickMs   = 0u;
    bool _caretVisible                 = true;
    mutable float _horizontalScrollDip = 0.0f;
    mutable SingleLineTextLayoutCache _singleLineLayoutCache;
    mutable std::vector<size_t> _maskedSourceTextElementBoundaries;
    mutable wil::com_ptr<IDWriteTextLayout> _cachedMultilineLayout;
    mutable std::wstring _cachedLayoutText;
    mutable D2D1_SIZE_F _cachedLayoutSize           = D2D1::SizeF(0.0f, 0.0f);
    mutable bool _multilineLayoutDirty              = true;
    size_t _multilineFirstVisibleLine               = 0u;
    float _multilineWheelDeltaRemainder             = 0.0f;
    bool _multiline                                 = false;
    bool _readOnly                                  = false;
    bool _masked                                    = false;
    PasswordRevealMode _passwordRevealMode          = PasswordRevealMode::Peek;
    PasswordRevealState _passwordRevealState        = PasswordRevealState::Hidden;
    PasswordMaskLengthPolicy _maskLengthPolicy      = PasswordMaskLengthPolicy::Exact;
    std::wstring _passwordRevealAccessibleName      = L"Show password";
    mutable uint64_t _concealedMaskEpoch            = 0u;
    mutable size_t _concealedMaskBucketStart        = 0u;
    mutable size_t _concealedMaskBucketEnd          = 0u;
    mutable size_t _concealedMaskVisibleDotCount    = 0u;
    mutable bool _concealedMaskVisibleDotCountValid = false;
    bool _dragSelecting                             = false;
    bool _clearButtonHovered                        = false;
    bool _clearButtonEnabled                        = true;
    bool _passwordRevealButtonHovered               = false;
    bool _passwordRevealButtonPressed               = false;
    bool _passwordRevealKeyboardFocused             = false;
    std::optional<D2D1_COLOR_F> _caretColorOverride;
    float _textPaddingLeftDip              = 8.0f;
    float _textPaddingRightDip             = 8.0f;
    float _textPaddingTopDip               = 4.0f;
    float _textPaddingBottomDip            = 4.0f;
    bool _hasExplicitHorizontalTextPadding = false;
    bool _hasExplicitVerticalTextPadding   = false;
    SingleLineSelectionClickSequence _selectionClickSequence;
    std::vector<EditHistoryState> _undoHistory;
    std::vector<EditHistoryState> _redoHistory;
    DirectEditMergeKind _directEditMergeKind = DirectEditMergeKind::None;
    std::optional<std::chrono::steady_clock::time_point> _pendingEditTransactionStartedAt;
    const wchar_t* _pendingEditTransactionDetail = L"";

    static constexpr size_t kMaxEditHistoryEntries = 64u;
};

class ComboBox : public Control
{
public:
    struct Item
    {
        std::wstring value;
        std::wstring display;
    };

    ComboBox();

    void SetVariant(ComboBoxVariant variant) noexcept;
    [[nodiscard]] ComboBoxVariant GetVariant() const noexcept;
    void SetChromeVisible(bool visible) noexcept;
    [[nodiscard]] bool IsChromeVisible() const noexcept;
    // Override the default kComboBoxMaxVisibleItems cap for this instance.
    // Pass 0 to restore the default.
    void SetMaxVisibleItems(size_t maxItems) noexcept;
    // Owned per-instance translation; empty restores the English default. Open popup layout is refreshed.
    void SetNoMatchesText(std::wstring text);
    [[nodiscard]] std::wstring_view GetNoMatchesText() const noexcept;
    // Per-instance row minimum in DIPs, including paint, hit testing and scrolling. Zero restores the theme default.
    // Finite values in [0, 4096] are accepted; invalid values leave the current setting unchanged.
    void SetMinimumPopupItemHeight(float heightDip) noexcept;
    [[nodiscard]] float GetMinimumPopupItemHeight() const noexcept;
    void SetEditable(bool editable) noexcept;
    [[nodiscard]] bool IsEditable() const noexcept;
    void SetAutoOpenOnTextInput(bool autoOpen) noexcept;
    [[nodiscard]] bool GetAutoOpenOnTextInput() const noexcept;
    void SetItems(std::vector<Item> items);
    [[nodiscard]] std::span<const Item> GetItems() const noexcept;
    void SetSelectedIndex(std::optional<size_t> selectedIndex) noexcept;
    [[nodiscard]] std::optional<size_t> GetSelectedIndex() const noexcept;
    [[nodiscard]] std::wstring_view GetSelectedValue() const noexcept;
    [[nodiscard]] std::wstring_view GetDisplayedText() const noexcept;
    void SetText(std::wstring text);
    void SetTextAndNotify(std::wstring text);
    [[nodiscard]] std::wstring_view GetText() const noexcept;
    void SetEditableSelectionRange(size_t selectionStart, size_t selectionEnd) noexcept;
    [[nodiscard]] std::optional<std::pair<size_t, size_t>> GetEditableSelectionRange() const noexcept;
    void SetPlaceholder(std::wstring text);
    void SetOnTextChanged(std::function<void(std::wstring_view)> onTextChanged);
    void SetOnSelectionChanged(std::function<void(size_t)> onSelectionChanged);
    void SetOnSubmitted(std::function<void()> onSubmitted);
    void SetOnPopupRequested(std::function<bool()> onPopupRequested);
    [[nodiscard]] bool IsPopupOpen() const noexcept;
    [[nodiscard]] bool DebugIsPopupOpen() const noexcept;
    [[nodiscard]] std::optional<size_t> DebugGetHoveredPopupIndex() const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetPopupBounds() const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetPopupItemRect(size_t popupListIndex, const ControlHost* host = nullptr) const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetPopupItemTextRect(size_t popupListIndex, const ControlHost* host = nullptr) const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetEditableTextRect() const noexcept;
    [[nodiscard]] bool DebugGetEditablePaintState(const ControlHost& host, ComboBoxDebugEditablePaintState& out) const noexcept;
    [[nodiscard]] size_t HitTestEditableCaretIndex(const ControlHost& host, D2D1_POINT_2F point) const noexcept;

    void Paint(ControlHost& host) const override;
    void PaintOverlay(ControlHost& host) const override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseDoubleClick(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers) override;
    bool OnMouseLeave(ControlHost& host) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    void OnCaptureLost(ControlHost& host) override;
    bool OnMouseWheel(ControlHost& host, D2D1_POINT_2F point, float wheelDelta, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    bool OnChar(ControlHost& host, wchar_t ch, UINT modifiers) override;
    bool OnContextMenu(ControlHost& host, bool keyboardInvocation, D2D1_POINT_2F pointDip) override;
    bool Tick(ControlHost& host, uint64_t nowTickMs) override;
    bool OnCopy(ControlHost& host) override;
    bool OnSelectAll(ControlHost& host) override;

    [[nodiscard]] D2D1_RECT_F GetHitBounds() const noexcept override;

protected:
    void OnFocusChanged(ControlHost& host, bool focused) override;
    void OnBoundsChanged() noexcept override;
    [[nodiscard]] Control* HitTestOverlay(D2D1_POINT_2F point) override;
    [[nodiscard]] const Control* HitTestOverlay(D2D1_POINT_2F point) const override;
    bool DismissOverlayOnPointerDown(ControlHost& host, D2D1_POINT_2F point) override;
    [[nodiscard]] bool SupportsTextInput() const noexcept override;
    [[nodiscard]] std::optional<D2D1_RECT_F> GetTextInputViewportRect() const noexcept override;
    [[nodiscard]] std::optional<D2D1_RECT_F> GetTextInputCaretRect(const ControlHost& host, size_t controlTextIndex) const noexcept override;
    [[nodiscard]] std::optional<std::vector<D2D1_RECT_F>> GetTextInputRangeRects(const ControlHost& host,
                                                                                 size_t controlTextStartIndex,
                                                                                 size_t controlTextEndIndex) const override;
    [[nodiscard]] std::optional<size_t> HitTestTextInputPoint(const ControlHost& host, D2D1_POINT_2F point) const noexcept override;
    bool ExportTextInputState(TextInputState& outState) const override;
    bool ImportTextInputState(ControlHost& host, const TextInputState& state, bool notifyChange) override;

private:
    struct EditHistoryState
    {
        std::wstring text;
        size_t caretIndex = 0u;
        std::optional<size_t> selectionAnchorIndex;
        float horizontalScrollDip = 0.0f;
    };

    [[nodiscard]] std::optional<size_t> GetHighlightedPopupIndex() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetEditableTextRect() const noexcept;
    [[nodiscard]] wil::com_ptr<IDWriteTextLayout> GetOrCreateSingleLineLayout(
        const ControlHost* host, std::wstring_view text, float minimumWidthDip, float heightDip, DWRITE_READING_DIRECTION readingDirection) const noexcept;
    void InvalidateSingleLineLayoutCache() const noexcept;
    float EnsureEditableCaretVisible(const ControlHost* host, float availableWidthDip) const noexcept;
    void ResetEditableCaretBlink(ControlHost& host) noexcept;
    void SetEditableCaretIndex(size_t caretIndex, bool extendSelection) noexcept;
    [[nodiscard]] bool HasEditableSelection() const noexcept;
    [[nodiscard]] bool DeleteEditableSelection() noexcept;
    void SelectAllEditableText() noexcept;
    void SelectEditableWordAt(size_t hitIndex) noexcept;
    [[nodiscard]] bool NotifyTextChanged() const;
    void RefreshAccessibilitySnapshot() const noexcept;
    [[nodiscard]] EditHistoryState CaptureEditHistoryState() const;
    void RestoreEditHistoryState(const EditHistoryState& state) noexcept;
    void RecordUndoStateForEditableEdit();
    [[nodiscard]] bool TryUndoEditableEdit() noexcept;
    [[nodiscard]] bool TryRedoEditableEdit() noexcept;
    void RefreshEditableTextAfterMutation(ControlHost& host);
    void OpenPopup(ControlHost& host) noexcept;
    void ClosePopup() noexcept;
    bool RequestPopup(ControlHost& host);
    void MaybeAutoOpenPopup(ControlHost& host) noexcept;
    void CapturePopupBackdrop(ControlHost& host) noexcept;
    void RebuildPopupItems(const ControlHost* host = nullptr) noexcept;
    void CommitSelection(ControlHost& host, size_t itemIndex, bool closePopup);
    void SyncEditableSelectionFromText() noexcept;
    void EnsurePopupSelectionVisible(const ControlHost* host = nullptr) noexcept;
    void ScrollPopupBy(int deltaItems, const ControlHost* host = nullptr) noexcept;
    void ResetPopupLayout() noexcept;
    void UpdatePopupLayout(const ControlHost* host = nullptr) const noexcept;
    [[nodiscard]] float ComputePopupWidthDip(const ControlHost* host = nullptr) const noexcept;
    [[nodiscard]] bool HasPopupScrollbar() const noexcept;
    [[nodiscard]] size_t GetPopupItemCount() const noexcept;
    [[nodiscard]] size_t GetPopupVisibleItemCount() const noexcept;
    [[nodiscard]] size_t GetPopupRenderRowCount() const noexcept;
    [[nodiscard]] std::optional<size_t> GetPopupItemIndexAt(size_t popupListIndex) const noexcept;
    [[nodiscard]] std::optional<size_t> FindPopupListIndexForItem(size_t itemIndex) const noexcept;
    [[nodiscard]] std::optional<size_t> FindTypeaheadMatch(std::wstring_view prefix) const noexcept;
    [[nodiscard]] std::optional<size_t> HitTestPopupItem(D2D1_POINT_2F point) const noexcept;
    [[nodiscard]] D2D1_RECT_F GetPopupBounds() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetPopupItemRect(size_t popupListIndex, const ControlHost* host = nullptr) const noexcept;
    [[nodiscard]] D2D1_RECT_F GetPopupItemTextRect(size_t popupListIndex, const ControlHost* host = nullptr) const noexcept;
    [[nodiscard]] D2D1_RECT_F GetPopupScrollbarRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetPopupScrollbarThumbRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetPopupScrollbarThumbHitRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetDropButtonRect() const noexcept;
    void DragPopupScrollbarThumb(D2D1_POINT_2F point) noexcept;

    std::vector<Item> _items;
    std::vector<size_t> _popupItemIndices;
    std::wstring _text;
    std::wstring _placeholder;
    std::wstring _noMatchesText;
    std::shared_ptr<const std::function<void(std::wstring_view)>> _onTextChanged;
    std::shared_ptr<const std::function<void(size_t)>> _onSelectionChanged;
    std::shared_ptr<const std::function<void()>> _onSubmitted;
    std::shared_ptr<const std::function<bool()>> _onPopupRequested;
    std::wstring _typeaheadBuffer;
    std::vector<EditHistoryState> _undoHistory;
    std::vector<EditHistoryState> _redoHistory;
    std::optional<size_t> _selectedIndex;
    std::optional<size_t> _activePopupIndex;
    std::optional<size_t> _hoveredPopupIndex;
    size_t _caretIndex = 0u;
    std::optional<size_t> _selectionAnchorIndex;
    size_t _popupScrollIndex                   = 0u;
    uint64_t _caretBlinkAnchorTickMs           = 0u;
    uint64_t _lastTypeaheadTickMs              = 0u;
    bool _caretVisible                         = true;
    mutable float _editableHorizontalScrollDip = 0.0f;
    mutable SingleLineTextLayoutCache _singleLineLayoutCache;
    mutable D2D1_RECT_F _popupBounds      = D2D1::RectF();
    mutable size_t _popupVisibleItemCount = 0u;
    mutable WindowHostBitmapCapture _popupBackdropCapture{};
    mutable wil::com_ptr<ID2D1Bitmap1> _popupBackdropBitmap;
    mutable wil::com_ptr<ID2D1Device> _popupBackdropDevice;
    bool _dragPopupScrollbar    = false;
    bool _dragSelecting         = false;
    bool _popupUsesBackdropBlur = false;
    bool _chromeVisible         = true;
    SingleLineSelectionClickSequence _selectionClickSequence;
    float _popupScrollbarDragOffsetDip             = 0.0f;
    ComboBoxVariant _variant                       = ComboBoxVariant::Modern;
    bool _editable                                 = false;
    bool _autoOpenOnTextInput                      = false;
    bool _open                                     = false;
    size_t _maxVisibleItemsOverride                = 0u;
    float _minimumPopupItemHeightDip               = 0.0f;
    static constexpr size_t kMaxEditHistoryEntries = 64u;
};

class TagPicker : public Panel
{
public:
    TagPicker();

    void SetOptions(std::wstring allLabel, std::vector<std::wstring> options);
    [[nodiscard]] std::span<const std::wstring> GetOptions() const noexcept;
    void SetSelectedValues(std::vector<std::wstring> values);
    [[nodiscard]] std::span<const std::wstring> GetSelectedValues() const noexcept;
    void SetInputText(std::wstring text);
    [[nodiscard]] std::wstring_view GetInputText() const noexcept;
    [[nodiscard]] bool SelectOption(std::wstring_view value);
    [[nodiscard]] bool CommitInput();
    [[nodiscard]] bool RemoveDisplayTag(size_t displayTagIndex);
    [[nodiscard]] size_t GetDisplayTagCount() const noexcept;
    [[nodiscard]] std::wstring_view GetDisplayTagText(size_t displayTagIndex) const noexcept;
    [[nodiscard]] float GetPreferredHeightDip(float widthDip) const noexcept;
    void SetOnSelectionChanged(std::function<void(std::span<const std::wstring>)> onSelectionChanged);

    void Paint(ControlHost& host) const override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;

#if DXUI_ENABLE_DIAGNOSTICS
    [[nodiscard]] size_t DebugGetLaidOutDisplayTagCount() const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetDisplayTagRect(size_t displayTagIndex) const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetInputRect() const noexcept;
    [[nodiscard]] ComboBox* DebugGetEmbeddedCombo() noexcept;
    [[nodiscard]] const ComboBox* DebugGetEmbeddedCombo() const noexcept;
#endif

protected:
    void OnBoundsChanged() noexcept override;
    [[nodiscard]] Control* HitTest(D2D1_POINT_2F point) override;
    [[nodiscard]] const Control* HitTest(D2D1_POINT_2F point) const override;

private:
    struct DisplayTag
    {
        std::wstring text;
        std::wstring value;
        bool all = false;
    };

    void RefreshComboItems();
    void RebuildDisplayTags();
    void LayoutParts() noexcept;
    [[nodiscard]] float ComputePreferredHeightDip(float widthDip, const ControlHost* host) const noexcept;
    [[nodiscard]] float MeasureDisplayTagWidthDip(const DisplayTag& tag, float rowHeightDip, const ControlHost* host) const noexcept;
    [[nodiscard]] bool NotifySelectionChanged();
    [[nodiscard]] bool ContainsOption(std::wstring_view value) const noexcept;
    [[nodiscard]] bool ContainsSelectedValue(std::wstring_view value) const noexcept;
    [[nodiscard]] bool IsAllSelectionActive() const noexcept;
    [[nodiscard]] std::optional<size_t> FindOptionIndex(std::wstring_view value) const noexcept;
    [[nodiscard]] std::optional<size_t> FindBestInputMatch(std::wstring_view input) const noexcept;
    void PruneSelectedValues();

    ComboBox* _combo = nullptr;
    std::wstring _allLabel;
    std::vector<std::wstring> _options;
    std::vector<std::wstring> _selectedValues;
    std::vector<DisplayTag> _displayTags;
    std::vector<D2D1_RECT_F> _tagRects;
    std::vector<D2D1_RECT_F> _tagRemoveRects;
    std::shared_ptr<const std::function<void(std::span<const std::wstring>)>> _onSelectionChanged;
    bool _syncingCombo = false;
};

class StatusStrip final : public Control
{
public:
    explicit StatusStrip(std::wstring text = {});

    struct Section
    {
        std::wstring text;
        float widthDip                  = 0.0f; // 0 = stretch to fill remaining space
        DWRITE_TEXT_ALIGNMENT alignment = DWRITE_TEXT_ALIGNMENT_LEADING;
        bool leadingEllipsis            = false;
    };

    void SetText(std::wstring text);
    [[nodiscard]] std::wstring_view GetText() const noexcept;
    void SetFontRole(FontRole fontRole) noexcept;
    void SetBlendWithWindowBackground(bool blend) noexcept;
    [[nodiscard]] bool GetBlendWithWindowBackground() const noexcept;
    void SetSections(std::vector<Section> sections);
    void SetSectionText(size_t index, std::wstring text);
    [[nodiscard]] size_t GetSectionCount() const noexcept;
    [[nodiscard]] std::wstring_view GetSectionText(size_t index) const noexcept;
    [[nodiscard]] DWRITE_TEXT_ALIGNMENT GetSectionAlignment(size_t index) const noexcept;
    [[nodiscard]] bool GetSectionLeadingEllipsis(size_t index) const noexcept;
    [[nodiscard]] static std::wstring DebugElideLeadingForWidth(
        const ControlHost* host, std::wstring_view text, FontRole fontRole, float widthDip, float heightDip) noexcept;

    void Paint(ControlHost& host) const override;

private:
    [[nodiscard]] static std::wstring ElideLeadingForWidth(
        const ControlHost* host, std::wstring_view text, FontRole fontRole, float widthDip, float heightDip) noexcept;

    std::wstring _text;
    std::vector<Section> _sections;
    FontRole _fontRole              = FontRole::Small;
    bool _blendWithWindowBackground = false;
};

class PopupLayer final : public Panel
{
public:
    void Paint(ControlHost& host) const override;
    void PaintOverlay(ControlHost& host) const override;

protected:
    [[nodiscard]] Control* HitTestOverlay(D2D1_POINT_2F point) override;
    [[nodiscard]] const Control* HitTestOverlay(D2D1_POINT_2F point) const override;
};

enum class StackOrientation : uint8_t
{
    Vertical,
    Horizontal,
};

struct LayoutConstraint
{
    float minExtent       = 0.0f;
    float preferredExtent = 0.0f;
    float maxExtent       = (std::numeric_limits<float>::max)();
};

[[nodiscard]] float ResolveConstrainedExtent(const LayoutConstraint& constraint, float availableExtent) noexcept;

// Layout helper that computes and applies SetBounds for children automatically.
// Children are arranged sequentially in the specified orientation. Each child gets
// the full cross-axis extent and a configurable main-axis extent (fixed height or
// auto-measured). Call ApplyLayout() after adding/removing children or when bounds change.
//
// Usage:
//   auto* stack = root->AddChild<StackPanel>();
//   stack->SetOrientation(StackOrientation::Vertical);
//   stack->SetGap(8.0f);
//   stack->SetPadding(12.0f, 12.0f, 12.0f, 12.0f);
//   auto* label = stack->AddChild<Label>(L"Title");
//   stack->SetChildExtent(label, 24.0f);  // 24 DIP tall
//   auto* edit = stack->AddChild<TextField>();
//   stack->SetChildExtent(edit, 32.0f);
//   stack->ApplyLayout();
//
class StackPanel : public Panel
{
public:
    StackPanel() = default;

    void SetOrientation(StackOrientation orientation) noexcept;
    [[nodiscard]] StackOrientation GetOrientation() const noexcept;
    void SetGap(float gapDip) noexcept;
    [[nodiscard]] float GetGap() const noexcept;
    void SetPadding(float left, float top, float right, float bottom) noexcept;

    // Set the main-axis extent for a child (height for Vertical, width for Horizontal).
    // Must be called for each child before ApplyLayout().
    void SetChildExtent(const Control* child, float extentDip);

    // Compute and apply SetBounds on all children based on current bounds, orientation,
    // gap, padding, and child extents. Call after modifying children or this panel's bounds.
    void ApplyLayout();

    // Returns the total content extent (main axis) needed to fit all children + gaps + padding.
    [[nodiscard]] float GetContentExtent() const noexcept;

private:
    void OnFlowDirectionChanged() noexcept override;
    void OnDensityChanged() noexcept override;

    StackOrientation _orientation = StackOrientation::Vertical;
    float _gapDip                 = 0.0f;
    float _padLeft                = 0.0f;
    float _padTop                 = 0.0f;
    float _padRight               = 0.0f;
    float _padBottom              = 0.0f;
    std::vector<std::pair<const Control*, float>> _childExtents;
};

struct MeasuredActionLayout
{
    float heightDip = 0.0f;
    size_t rowCount = 0;
};

// Allocation-free ordered flow, in local DIPs. Call on layout invalidation, then apply the same
// rectangles to the controls. Text measurement and minimum target sizes belong to the caller.
// Sizes must fit availableWidthDip; measure an overlong label wrapped before arranging it.
// {0,0} omits a hidden action without changing its array index. Rows are top-aligned.
// Invalid/nonfinite sizes, overflow or insufficient output capacity leave ALL outputs unchanged.
[[nodiscard]] HRESULT ArrangeMeasuredActions(std::span<const D2D1_SIZE_F> sizes,
                                             float availableWidthDip,
                                             D2D1_SIZE_F gapsDip,
                                             std::span<D2D1_RECT_F> bounds,
                                             MeasuredActionLayout& result,
                                             FlowDirection direction = FlowDirection::LeftToRight) noexcept;

// Scrollable container with a vertical scrollbar. Children are positioned in "content space"
// starting at the panel's top. When content exceeds the viewport, a scrollbar appears and the
// visible portion is clipped. ScrollPanel intercepts all mouse events and translates coordinates
// to content space before dispatching to children.
//
// Usage:
//   auto* scroll = root->AddChild<ScrollPanel>();
//   auto* stack = scroll->AddChild<StackPanel>();
//   stack->SetOrientation(StackOrientation::Vertical);
//   stack->SetGap(8.0f);
//   auto* label = stack->AddChild<Label>(L"Title");
//   stack->SetChildExtent(label, 24.0f);
//   // After layout:
//   scroll->SetBounds(viewportRect);
//   D2D1_RECT_F contentRect = { viewportRect.left, viewportRect.top,
//       viewportRect.right - scroll->GetScrollbarThickness(), viewportRect.top + 99999.0f };
//   stack->SetBounds(contentRect);
//   stack->ApplyLayout();
//   scroll->SetContentHeight(stack->GetContentExtent());
//
class ScrollPanel : public Panel
{
public:
    ScrollPanel() = default;

    void ClearChildren() noexcept override;

    void SetContentHeight(float heightDip) noexcept;
    [[nodiscard]] float GetContentHeight() const noexcept;

    [[nodiscard]] float GetScrollOffset() const noexcept;
    void SetScrollOffset(float offsetDip) noexcept;
    void ScrollToTop() noexcept;

    void SetScrollStepDip(float stepDip) noexcept;
    void SetInternalScrollbarEnabled(bool enabled) noexcept;
    void SetOnScrollChanged(std::function<void(float)> callback) noexcept;

    [[nodiscard]] bool NeedsScrollbar() const noexcept;
    [[nodiscard]] float GetScrollbarThickness() const noexcept;
    [[nodiscard]] bool IsInternalScrollbarEnabled() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetViewportRect() const noexcept;
    [[nodiscard]] bool DebugGetScrollbarThumbHitRect(D2D1_RECT_F& out) const noexcept;

    // Control overrides
    void Paint(ControlHost& host) const override;
    void PaintOverlay(ControlHost& host) const override;
    Control* HitTest(D2D1_POINT_2F point) override;
    const Control* HitTest(D2D1_POINT_2F point) const override;
    Control* HitTestOverlay(D2D1_POINT_2F point) override;
    const Control* HitTestOverlay(D2D1_POINT_2F point) const override;
    bool DismissOverlayOnPointerDown(ControlHost& host, D2D1_POINT_2F point) override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseDoubleClick(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseWheel(ControlHost& host, D2D1_POINT_2F point, float wheelDelta, UINT modifiers) override;
    bool OnMouseLeave(ControlHost& host) override;
    void OnCaptureLost(ControlHost& host) override;

private:
    float _contentHeightDip        = 0.0f;
    float _scrollOffsetDip         = 0.0f;
    float _scrollStepDip           = 40.0f;
    bool _internalScrollbarEnabled = true;

    bool _dragThumb           = false;
    float _dragThumbOffsetDip = 0.0f;

    enum class HotPart : uint8_t
    {
        None,
        Track,
        Thumb
    };
    HotPart _scrollbarHotPart = HotPart::None;

    Control* _innerHoveredChild  = nullptr;
    Control* _innerCapturedChild = nullptr;

    [[nodiscard]] float GetScrollableExtent() const noexcept;
    [[nodiscard]] bool UsesInternalScrollbar() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetScrollbarTrackRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetScrollbarThumbRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetScrollbarThumbHitRect() const noexcept;
    void ClampScrollOffset() noexcept;
    [[nodiscard]] bool NotifyScrollChanged(float previousOffsetDip) noexcept;
    [[nodiscard]] D2D1_POINT_2F ToContentSpace(D2D1_POINT_2F viewportPoint) const noexcept;
    Control* FindChildAtContent(D2D1_POINT_2F contentPoint);
    Control* FindOverlayChildAtContent(D2D1_POINT_2F contentPoint);
    [[nodiscard]] const Control* FindOverlayChildAtContent(D2D1_POINT_2F contentPoint) const;
    void UpdateInnerHover(ControlHost& host, D2D1_POINT_2F viewportPoint);

    std::shared_ptr<const std::function<void(float)>> _onScrollChanged;
};

class TooltipLayer final : public Control
{
public:
    bool SetTooltip(std::wstring text, const D2D1_POINT_2F& originDip);
    bool SetTooltipDelayed(std::wstring text, const D2D1_POINT_2F& originDip, uint64_t nowTickMs, uint64_t delayMs);
    bool BeginHideDelay(uint64_t nowTickMs, uint64_t delayMs = 100u) noexcept;
    bool CancelHideDelay() noexcept;
    bool Clear() noexcept;
    [[nodiscard]] bool HasTooltip() const noexcept;
    [[nodiscard]] std::wstring_view GetTooltipText() const noexcept;
#if DXUI_ENABLE_DIAGNOSTICS
    [[nodiscard]] std::wstring_view DebugGetPendingTooltipText() const noexcept;
    [[nodiscard]] D2D1_RECT_F DebugGetBoundsDip(const ControlHost& host) const noexcept;
#endif

    void Paint(ControlHost& host) const override;
    bool Tick(ControlHost& host, uint64_t nowTickMs) override;
    void OnHostDpiChanged(ControlHost& host) noexcept override;

private:
    struct LayoutCache final
    {
        wil::com_ptr<IDWriteTextLayout> layout;
        D2D1_RECT_F bounds       = D2D1::RectF(0.0f, 0.0f, 0.0f, 0.0f);
        D2D1_RECT_F clientBounds = D2D1::RectF(0.0f, 0.0f, 0.0f, 0.0f);
        bool valid               = false;
    };

    void InvalidateLayoutCache() noexcept;
    [[nodiscard]] bool EnsureLayoutCache(const ControlHost& host) const noexcept;
    [[nodiscard]] D2D1_RECT_F ComputeBoundsDip(const ControlHost& host) const noexcept;
    std::wstring _text;
    std::wstring _pendingText;
    D2D1_POINT_2F _originDip        = D2D1::Point2F();
    D2D1_POINT_2F _pendingOriginDip = D2D1::Point2F();
    mutable LayoutCache _layoutCache{};
    bool _showScheduled  = false;
    uint64_t _showTickMs = 0u;
    bool _hideScheduled  = false;
    uint64_t _hideTickMs = 0u;
};

class Tree final : public Control
{
public:
    Tree();

    // Non-owning model pointer. Caller manages model lifetime from SetModel() until Tree destruction.
    // Model state accessed only on UI thread — no synchronization needed.
    void SetModel(ITreeModel* model) noexcept;
    // Owned per-instance translation; empty restores the English default.
    void SetEmptyStateText(std::wstring text);
    [[nodiscard]] std::wstring_view GetEmptyStateText() const noexcept;
    void SetDelegate(ITreeDelegate* delegate) noexcept;
    // Pointer drag of a row. Release reports one `OnTreeReorder`; Escape and capture loss cancel.
    void SetReorderEnabled(bool enabled) noexcept;
    [[nodiscard]] bool ReorderEnabled() const noexcept
    {
        return _reorderEnabled;
    }
    void SetRowHeightDip(float rowHeightDip) noexcept;
    void SetIndentDip(float indentDip) noexcept;
    void NotifyDataChanged();
    [[nodiscard]] ITreeModel* GetModel() const noexcept
    {
        return _model;
    }
    // Opt-in multiple selection, off by default: the tree then keeps exactly one selected item, as before. On, it keeps a
    // set of selected items and, separately, the focused (current) item that GetSelectedItemId reports. Plain click or
    // key selects one item and is the anchor; Ctrl+click toggles one; Shift+click (or Shift with Up, Down, Home, End,
    // Page Up, Page Down) selects the visible range from the anchor; Ctrl with those keys moves the focus alone,
    // Ctrl+Space toggles the focused item and Ctrl+A selects every visible item. The call is silent: enabling starts with
    // the selected item alone, disabling keeps the focused item if it is selected, else the last selected one.
    void SetMultiSelectEnabled(bool enabled) noexcept;
    [[nodiscard]] bool MultiSelectEnabled() const noexcept
    {
        return _multiSelect;
    }
    // Single selection: the selected item. Multi-select: the focused (current) item, which need not be selected.
    // `SetSelectedItemId` is silent and selects that item alone (none clears the selection).
    void SetSelectedItemId(std::optional<uint64_t> itemId) noexcept;
    [[nodiscard]] std::optional<uint64_t> GetSelectedItemId() const noexcept;
    // The focused (current) item owns the focus ring and is where the keys start. It is the selected item, except with
    // multi-select, where it may be outside the selection. `SetFocusedItemId` is silent and, with multi-select, moves the
    // focus alone (UI Automation's SetFocus does); without multi-select it is SetSelectedItemId.
    void SetFocusedItemId(std::optional<uint64_t> itemId) noexcept;
    [[nodiscard]] std::optional<uint64_t> GetFocusedItemId() const noexcept;
    // The selected items in visible order: the set with multi-select, else the selected item alone or nothing.
    [[nodiscard]] std::vector<uint64_t> GetSelectedItemIds() const;
    [[nodiscard]] bool IsItemSelected(uint64_t itemId) const noexcept;
    // Silent. Selects the listed items that are visible rows, keeps the last of them as the focused item and the anchor.
    // Without multi-select only that last visible item is selected.
    void SetSelectedItemIds(std::span<const uint64_t> itemIds) noexcept;
    // Selection by the user's action, as UI Automation does: Select replaces the selection with the item; with
    // multi-select Add and Remove change only that item's membership (Add also makes it the focused item). Each notifies
    // the delegate. False for an index that is not a visible row, and for Remove without multi-select; Add without it
    // selects the item like Select. Each is also false when the tree did not survive the request: its delegate, or a
    // message dispatched while the tree published the new selection to UI Automation, destroyed it.
    bool RequestSelectVisibleItem(size_t visibleIndex) noexcept;
    bool RequestAddVisibleItemToSelection(size_t visibleIndex) noexcept;
    bool RequestRemoveVisibleItemFromSelection(size_t visibleIndex) noexcept;
    bool RequestExpandedState(size_t visibleIndex, bool expanded) noexcept;
    [[nodiscard]] size_t GetFirstVisibleItemIndex() const noexcept;
    [[nodiscard]] std::optional<D2D1_RECT_F> GetVisibleItemHitRect(size_t visibleIndex) const noexcept;
    [[nodiscard]] std::optional<size_t> FindVisibleItemAtPoint(D2D1_POINT_2F pointDip) const noexcept;
    [[nodiscard]] TreeItemLayoutMetrics GetItemLayoutMetrics(const ControlHost& host, size_t visibleIndex) const;
#if DXUI_ENABLE_DIAGNOSTICS
    [[nodiscard]] bool DebugGetRowVisualState(const ThemePalette& theme,
                                              size_t visibleIndex,
                                              bool keyboardFocusVisible,
                                              TreeDebugRowVisualState& out) const noexcept;
    [[nodiscard]] TreeScrollbarVisualState DebugGetScrollbarVisualState(const ThemePalette& theme) const noexcept;
    [[nodiscard]] float DebugGetVerticalScrollDip() const noexcept;
    [[nodiscard]] size_t DebugGetFirstVisibleIndex() const noexcept;
    [[nodiscard]] std::optional<size_t> DebugGetSelectedVisibleIndex() const noexcept;
#endif

    void Paint(ControlHost& host) const override;
    bool Tick(ControlHost& host, uint64_t nowTickMs) override;
    bool OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers) override;
    bool OnMouseLeave(ControlHost& host) override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseDoubleClick(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    void OnCaptureLost(ControlHost& host) override;
    bool OnMouseWheel(ControlHost& host, D2D1_POINT_2F point, float wheelDelta, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    bool OnChar(ControlHost& host, wchar_t ch, UINT modifiers) override;
    bool OnContextMenu(ControlHost& host, bool keyboardInvocation, D2D1_POINT_2F pointDip) override;
    // Multi-select only: selects every visible item (Ctrl+A); the focused item stays, or is the first item.
    bool OnSelectAll(ControlHost& host) override;
    void OnDensityChanged() noexcept override;

private:
    enum class HitZone : uint8_t
    {
        None,
        Item,
        Expander,
        VerticalScrollbar,
    };

    // How a selection gesture lands on an item. Without multi-select every gesture replaces the selection.
    enum class SelectMode : uint8_t
    {
        Replace,   // The item alone is selected and becomes the anchor.
        Toggle,    // The item's membership flips; the anchor stays unless the selection was empty.
        Range,     // The visible range from the anchor (or the focused item) to the item replaces the selection.
        FocusOnly, // The item becomes the focused item and the selection stays as it is.
    };

    struct HitInfo
    {
        HitZone zone          = HitZone::None;
        size_t visibleIndex   = 0u;
        D2D1_RECT_F rectDip   = D2D1::RectF();
        bool onScrollbarThumb = false;
    };

    struct TreeBadgeWidthCacheEntry
    {
        std::wstring text;
        IDWriteTextFormat* textFormat = nullptr;
        float widthDip                = 0.0f;
    };

    struct TreeTooltipOverflowCache
    {
        bool valid          = false;
        size_t visibleIndex = 0u;
        uint64_t itemId     = 0u;
        std::wstring text;
        std::wstring tooltipText;
        IDWriteTextFormat* textFormat = nullptr;
        float availableWidthDip       = 0.0f;
        std::wstring resolvedTooltipText;
    };

    enum class ScrollbarHotPart : uint8_t
    {
        None,
        Track,
        Thumb,
    };

    [[nodiscard]] HitInfo HitTestPoint(PointDip pointDip) const noexcept;
    [[nodiscard]] float GetVerticalScrollableExtent() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetContentRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetVerticalScrollbarRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetVerticalThumbRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetVerticalThumbHitRect() const noexcept;
    void InvalidateTreeTextMeasurementCaches() const noexcept;
    [[nodiscard]] float MeasureCachedBadgeTextWidthDip(const ControlHost& host, std::wstring_view badgeText) const noexcept;
    [[nodiscard]] std::wstring ResolveCachedTreeTooltipText(const ControlHost& host,
                                                            size_t visibleIndex,
                                                            const TreeItemData& item,
                                                            const TreeItemLayoutMetrics& layout) const;
    [[nodiscard]] TreeItemLayoutMetrics ComputeItemLayoutMetrics(const ControlHost& host, size_t visibleIndex, const TreeItemData& item) const noexcept;
    [[nodiscard]] TreeItemLayoutMetrics ComputeItemLayoutMetrics(const ControlHost& host, float rowTopDip, const TreeItemData& item) const noexcept;
    void ClampScrollOffset() noexcept;
    void UpdateScrollbarHotState(const HitInfo& hit) noexcept;
    void SyncScrollbarAnimation(ControlHost& host) noexcept;
    [[nodiscard]] std::optional<size_t> FindSelectedVisibleIndex() const noexcept;
    void EnsureVisibleIndex(size_t visibleIndex) noexcept;
    [[nodiscard]] bool SelectVisibleIndex(size_t visibleIndex, bool notifyDelegate);
    // Lands a selection gesture on a visible row: updates the focused item and, with multi-select, the selection set by
    // `mode`, then notifies the delegate (OnTreeSelectionChanged for the focused item, then OnTreeSelectionSetChanged once
    // if the set changed). False when the index is not a row, or when the delegate or the accessibility publish that
    // follows it (UI Automation event delivery dispatches messages) destroyed the tree.
    [[nodiscard]] bool SelectVisibleIndex(size_t visibleIndex, SelectMode mode, bool notifyDelegate);
    [[nodiscard]] std::vector<uint64_t> CollectVisibleItemIds() const;
    // Drops selected items that are no longer visible rows and puts the rest in visible order (multi-select only).
    void ReconcileSelectionWithModel();
    // The delegate's OnTreeSelectionSetChanged, for a change from `previous`; false when the tree is gone after it.
    [[nodiscard]] bool NotifySelectionSetChanged(const std::vector<uint64_t>& previous);
    // The release of a click on a row of a multi-selection: the row becomes the whole selection (set callback only).
    [[nodiscard]] bool CollapseSelectionToItem(uint64_t itemId);
    [[nodiscard]] bool ToggleExpanded(size_t visibleIndex);
    void RefreshAccessibilitySnapshot() const noexcept;
    [[nodiscard]] float ComputeExpanderProgress(uint64_t itemId, bool expanded, uint64_t nowTickMs) const noexcept;
    void StartExpanderAnimation(uint64_t itemId, bool fromExpanded, bool toExpanded) noexcept;
    [[nodiscard]] std::optional<size_t> FindNextTypeaheadMatch(std::wstring_view prefix) const noexcept;
    [[nodiscard]] float GetExpanderProgress(uint64_t itemId, bool expanded, uint64_t nowTickMs) const noexcept;
    [[nodiscard]] std::vector<TreeItemData> CaptureVisibleItems() const;
    void BeginTreeExpansionAnimation(
        uint64_t itemId, bool toExpanded, std::vector<TreeItemData>&& beforeItems, std::vector<TreeItemData>&& afterItems, uint64_t nowTickMs) noexcept;
    void ClearTreeExpansionAnimation() noexcept;
    [[nodiscard]] bool HasActiveTreeExpansionAnimation(uint64_t nowTickMs) const noexcept;
    [[nodiscard]] float GetTreeExpansionProgress(uint64_t nowTickMs) const noexcept;
    void ClearReorderDrag() noexcept;
    // Re-resolves the dragged row and its visible subtree by id; false once the row is gone.
    [[nodiscard]] bool ResolveReorderSource() noexcept;
    [[nodiscard]] std::optional<TreeDrop> ResolveReorderDrop(D2D1_POINT_2F point, size_t& targetIndex) const noexcept;
    void UpdateReorderDrop(ControlHost& host, D2D1_POINT_2F point) noexcept;

    std::wstring _emptyStateText;
    // Non-owning. Caller manages model lifetime. Valid from SetModel() until Tree destruction.
    // Invalidation validated at message entry by PruneStaleInteractionState().
    ITreeModel* _model       = nullptr;
    ITreeDelegate* _delegate = nullptr;
    // The selected item, or with multi-select the focused (current) item.
    std::optional<uint64_t> _selectedItemId;
    // Multi-select only: the selected items and their anchor. Unused (empty) while `_multiSelect` is off.
    GridSelectionModel _selection;
    bool _multiSelect = false;
    std::optional<size_t> _hoveredVisibleIndex;
    float _rowHeightBaseDip    = 28.0f;
    float _rowHeightDip        = 28.0f;
    float _indentDip           = 16.0f;
    float _verticalScrollDip   = 0.0f;
    float _wheelDeltaRemainder = 0.0f;
    float _dragThumbOffsetDip  = 0.0f;
    std::wstring _typeaheadBuffer;
    uint64_t _lastTypeaheadTickMs                               = 0u;
    static constexpr uint64_t _treeExpanderAnimationDurationMs  = 240u;
    static constexpr uint64_t _treeExpansionAnimationDurationMs = 320u;
    struct ExpanderAnimationState final
    {
        uint64_t itemId      = 0u;
        bool fromExpanded    = false;
        bool toExpanded      = false;
        float fromProgress   = 0.0f;
        float toProgress     = 1.0f;
        uint64_t startTickMs = 0u;
        bool active          = false;
    };
    struct TreeExpansionAnimationState final
    {
        uint64_t itemId      = 0u;
        bool toExpanded      = false;
        bool active          = false;
        uint64_t startTickMs = 0u;
        std::vector<TreeItemData> beforeItems;
        std::vector<TreeItemData> afterItems;
    };
    std::vector<ExpanderAnimationState> _expanderAnimations{};
    std::optional<TreeExpansionAnimationState> _treeExpansionAnimation;
    mutable std::vector<TreeBadgeWidthCacheEntry> _badgeWidthCache;
    mutable TreeTooltipOverflowCache _tooltipOverflowCache;
    ScrollbarHotPart _verticalScrollbarHotPart = ScrollbarHotPart::None;
    ScrollbarAnimationState _verticalScrollbarAnimation{};
    bool _dragVerticalThumb = false;
    bool _reorderEnabled    = false;
    bool _reorderArmed      = false;
    bool _reorderDragging   = false;
    // The press landed on a row of a multi-selection: it keeps the selection while pointer is down, and a release that
    // never became a drag collapses the selection to that row (`_reorderSourceId`).
    bool _reorderCollapsesSelection = false;
    uint64_t _reorderSourceId       = 0u;
    // Visible rows (source, subtreeEnd) are the dragged row's own descendants: a drop there would make the row
    // its own ancestor. The drop index names the target row for painting while the model is unchanged.
    size_t _reorderSourceIndex = 0u;
    size_t _reorderSubtreeEnd  = 0u;
    size_t _reorderDropIndex   = 0u;
    D2D1_POINT_2F _reorderPress{};
    std::optional<TreeDrop> _reorderDrop;
};

class Grid final : public Control
{
public:
    Grid();

    // Non-owning model pointer. Caller manages model lifetime from SetModel() until Grid destruction.
    // Model state accessed only on UI thread — no synchronization needed.
    void SetModel(IGridModel* model) noexcept;
    void SetDelegate(IGridDelegate* delegate) noexcept;
    void SetSelectionMode(GridSelectionMode mode) noexcept;
    [[nodiscard]] GridSelectionMode GetSelectionMode() const noexcept
    {
        return _selectionMode;
    }
    void SetVisualMode(GridVisualMode mode) noexcept;
    [[nodiscard]] GridVisualMode GetVisualMode() const noexcept
    {
        return _visualMode;
    }
    void SetRowHeightDip(float rowHeightDip) noexcept;
    void SetEffectiveRowHeightDip(float rowHeightDip) noexcept;
    void SetHeaderHeightDip(float headerHeightDip) noexcept;
    void SetCellTextFontRole(FontRole fontRole) noexcept;
    [[nodiscard]] FontRole GetCellTextFontRole() const noexcept
    {
        return _cellTextFontRole;
    }
    void SetIconSizeDip(float iconSizeDip) noexcept;
    [[nodiscard]] float GetIconSizeDip() const noexcept
    {
        return _iconSizeDip;
    }
    void SetLineClamp(uint32_t lineClamp) noexcept;
    void SetEmptyStateText(std::wstring text);
    [[nodiscard]] std::wstring_view GetEmptyStateText() const noexcept;
    void SetHeaderBusy(bool busy) noexcept;
    void SetHeaderBusyColumn(std::optional<size_t> columnIndex) noexcept;
    void SetSortSpec(const GridSortSpec& sortSpec) noexcept;
    [[nodiscard]] GridSortSpec GetSortSpec() const noexcept;
    void ApplyColumnLayout(std::span<const GridColumnLayoutEntry> layout) noexcept;
    [[nodiscard]] std::vector<GridColumnLayoutEntry> CaptureColumnLayout() const;
    void ApplyGroupLayout(std::span<const GridGroupLayoutEntry> layout) noexcept;
    [[nodiscard]] std::vector<GridGroupLayoutEntry> CaptureGroupLayout() const;
    void NotifyDataChanged();
    [[nodiscard]] IGridModel* GetModel() const noexcept
    {
        return _model;
    }

    [[nodiscard]] GridSelectionModel& GetSelectionModel() noexcept;
    [[nodiscard]] const GridSelectionModel& GetSelectionModel() const noexcept;
    void RefreshAccessibilitySnapshot() const noexcept;
    [[nodiscard]] GridVisibleWorkMetrics GetVisibleWorkMetrics() const;
    [[nodiscard]] GridCellLayoutMetrics GetCellLayoutMetrics(const ControlHost& host, size_t rowIndex, size_t columnIndex) const;
    [[nodiscard]] size_t GetVisibleRowCount() const;
    [[nodiscard]] std::optional<size_t> GetVisibleRowAt(size_t visibleRowIndex) const;
    [[nodiscard]] std::optional<size_t> FindVisibleRowOrdinal(size_t rowIndex) const;
    void EnsureRowVisible(size_t rowIndex) noexcept;
    [[nodiscard]] size_t GetVisibleColumnCount() const;
    [[nodiscard]] std::optional<size_t> GetVisibleColumnAt(size_t visibleColumnIndex) const;
    [[nodiscard]] std::optional<size_t> FindVisibleColumnOrdinal(size_t columnIndex) const;
    [[nodiscard]] std::optional<size_t> FindHeaderColumnAtPoint(PointDip pointDip) const noexcept;
    [[nodiscard]] std::optional<size_t> FindRowAtPoint(PointDip pointDip) const noexcept;
    [[nodiscard]] std::optional<std::pair<size_t, size_t>> FindCellAtPoint(PointDip pointDip) const noexcept;
    [[nodiscard]] std::optional<D2D1_RECT_F> GetVisibleColumnHeaderRect(size_t columnIndex) const;
    [[nodiscard]] std::optional<D2D1_RECT_F> GetVisibleDisplayColumnHeaderRect(size_t displayIndex) const;
    [[nodiscard]] std::optional<D2D1_RECT_F> GetVisibleRowRect(size_t rowIndex) const;
    [[nodiscard]] std::optional<D2D1_RECT_F> GetVisibleCellRect(size_t rowIndex, size_t columnIndex) const;
    [[nodiscard]] bool IsRowSelected(size_t rowIndex) const noexcept;
    [[nodiscard]] std::optional<size_t> GetPrimarySelectedRow() const noexcept;
    [[nodiscard]] std::wstring BuildSelectionTsv() const;
#if DXUI_ENABLE_DIAGNOSTICS
    struct GridDebugHitInfo
    {
        uint32_t zone         = 0u;
        size_t rowIndex       = 0u;
        size_t groupIndex     = 0u;
        size_t columnIndex    = 0u;
        D2D1_RECT_F rectDip   = D2D1::RectF();
        bool onScrollbarThumb = false;
        bool isHeaderResize   = false;
    };
    struct GridDebugPointerState
    {
        uint64_t headerResizeDownCount                       = 0u;
        uint64_t resizeMoveCount                             = 0u;
        bool resizeActive                                    = false;
        float lastResizeDeltaDip                             = 0.0f;
        float lastResizeWidthDip                             = 0.0f;
        bool pressedHeaderActive                             = false;
        size_t pressedHeaderColumn                           = 0u;
        bool reorderActive                                   = false;
        size_t reorderColumn                                 = 0u;
        size_t reorderTargetDisplayIndex                     = 0u;
        uint64_t headerReorderStartCount                     = 0u;
        uint64_t headerReorderCommitCount                    = 0u;
        uint64_t headerReorderNoOpCount                      = 0u;
        size_t lastHeaderReorderColumn                       = 0u;
        size_t lastHeaderReorderFromDisplayIndex             = 0u;
        size_t lastHeaderReorderRawTargetDisplayIndex        = 0u;
        size_t lastHeaderReorderNormalizedTargetDisplayIndex = 0u;
    };

    [[nodiscard]] bool DebugGetRowVisualState(const ThemePalette& theme, size_t rowIndex, GridDebugRowVisualState& out) const noexcept;
    [[nodiscard]] bool DebugGetCellVisualState(const ThemePalette& theme, size_t rowIndex, size_t columnIndex, GridDebugCellVisualState& out) const noexcept;
    [[nodiscard]] GridSortGlyphVisualState DebugGetSortGlyphVisualState(const ThemePalette& theme, size_t columnIndex, uint64_t nowTickMs) const noexcept;
    [[nodiscard]] GridScrollbarVisualState DebugGetScrollbarVisualState(const ThemePalette& theme) const noexcept;
    [[nodiscard]] uint64_t DebugGetPaintCount() const noexcept;
    [[nodiscard]] bool DebugHitTestPoint(PointDip pointDip, GridDebugHitInfo& out) const noexcept;
    [[nodiscard]] GridDebugPointerState DebugGetPointerState() const noexcept;
    void DebugSetScrollOffsets(float verticalScrollDip, float horizontalScrollDip) noexcept;
    struct GridDebugTextLayoutStatistics
    {
        uint64_t lookups         = 0u; // Retained multiline layout requests from paint and hover.
        uint64_t hits            = 0u;
        uint64_t layoutCreations = 0u; // DirectWrite layouts created for multiline cells, temporary ones included.
        uint64_t shapedUnits     = 0u; // UTF-16 units handed to those layouts.
        size_t retainedLayouts   = 0u; // Live layouts in the value table, and its entries.
        size_t capacity          = 0u;
        size_t displayLayouts    = 0u; // The same for the omitted-tail table: the value entries share its layouts and it lets go at the next paint that hits.
        size_t displayCapacity   = 0u;
        size_t textUnits         = 0u;    // UTF-16 units of heap storage the two tables' key strings and the scratch string hold.
        size_t tableBytes        = 0u;    // Bytes of the two tables' entries.
        bool ellipsis            = false; // The ellipsis trimming sign of the omitted tails, or its text format, is held.
    };
    [[nodiscard]] GridDebugTextLayoutStatistics DebugGetTextLayoutStatistics() const noexcept;
    // The entry ceiling of the layout tables: 16,384 by default, which no test window holds enough distinct cells to
    // reach. A smaller one (rounded down to a power of two of at least 32, the sizes the tables take) lets a few hundred
    // cells reach it; 0 restores the default. Tables already larger than the new ceiling keep their size until they halve.
    void DebugSetTextLayoutEntryLimit(size_t maxEntries) noexcept;
    [[nodiscard]] size_t DebugGetTextLayoutEntryLimit() const noexcept;
#endif
    bool RequestSelectRow(size_t rowIndex, UINT modifiers);
    bool RequestRemoveRowSelection(size_t rowIndex);
    bool RequestToggleCheckboxCell(ControlHost& host, size_t rowIndex, size_t columnIndex);

    void Paint(ControlHost& host) const override;
    bool Tick(ControlHost& host, uint64_t nowTickMs) override;
    bool OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers) override;
    bool OnMouseLeave(ControlHost& host) override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseDoubleClick(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    void OnCaptureLost(ControlHost& host) override;
    bool OnMouseWheel(ControlHost& host, D2D1_POINT_2F point, float wheelDelta, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    bool OnContextMenu(ControlHost& host, bool keyboardInvocation, D2D1_POINT_2F pointDip) override;
    bool OnCopy(ControlHost& host) override;
    bool OnSelectAll(ControlHost& host) override;
    [[nodiscard]] WindowHostCursorKind ResolveCursorKind(ControlHost& host, D2D1_POINT_2F pointDip) const noexcept override;
    void OnDensityChanged() noexcept override;

protected:
    void PropagateHost(ControlHost* host) noexcept override;
    void OnHidden() noexcept override;

private:
    enum class HitZone : uint8_t
    {
        None,
        Header,
        HeaderResize,
        GroupHeader,
        Cell,
        VerticalScrollbar,
        HorizontalScrollbar,
    };

    struct HitInfo
    {
        HitZone zone          = HitZone::None;
        size_t rowIndex       = 0;
        size_t groupIndex     = 0;
        size_t columnIndex    = 0;
        D2D1_RECT_F rectDip   = D2D1::RectF();
        bool onScrollbarThumb = false;
    };

    enum class ScrollbarHotPart : uint8_t
    {
        None,
        Track,
        Thumb,
    };

    struct VisibleBodyItem
    {
        enum class Kind : uint8_t
        {
            GroupHeader,
            Row,
        };

        Kind kind           = Kind::Row;
        size_t rowIndex     = 0u;
        size_t groupIndex   = 0u;
        D2D1_RECT_F rectDip = D2D1::RectF();
    };

    struct VisibleColumnSpan
    {
        size_t beginIndex = 0;
        size_t endIndex   = 0;
        float beginXDip   = 0.0f;
    };

    [[nodiscard]] HitInfo HitTestPoint(PointDip pointDip) const noexcept;
    void ClampScrollOffsets(bool normalizeVertical = true) noexcept;
    void EnsureColumnWidths() const;
    // False when the selection's delegate, or the accessibility publish that follows it, destroyed this grid, which its
    // caller then leaves alone.
    [[nodiscard]] bool SelectRow(size_t rowIndex, UINT modifiers);
    [[nodiscard]] std::optional<size_t> ResolveCheckboxToggleColumn(size_t rowIndex) const;
    [[nodiscard]] bool ToggleCheckboxCell(ControlHost& host, size_t rowIndex, size_t columnIndex);
    [[nodiscard]] std::optional<size_t> FindNearestVisibleRow(std::span<const GridGroupDesc> groups, size_t preferredRowIndex) const noexcept;
    void ReconcileSelectionForVisibleRows(std::span<const GridGroupDesc> groups);
    [[nodiscard]] size_t CountGroupHeadersBeforeRow(std::span<const GridGroupDesc> groups, size_t rowIndex) const noexcept;
    [[nodiscard]] size_t CountCollapsedRowsBeforeRow(std::span<const GridGroupDesc> groups, size_t rowIndex) const noexcept;
    [[nodiscard]] float GetRowTopDip(std::span<const GridGroupDesc> groups, size_t rowIndex) const noexcept;
    [[nodiscard]] float GetBodyContentHeight(std::span<const GridGroupDesc> groups) const noexcept;
    [[nodiscard]] float GetRawVerticalScrollableExtent(std::span<const GridGroupDesc> groups) const noexcept;
    [[nodiscard]] float AlignVerticalScrollExtentToVisibleItemBoundary(float rawExtentDip, std::span<const GridGroupDesc> groups) const noexcept;
    [[nodiscard]] float NormalizeVerticalScrollOffset(float offsetDip) const noexcept;
    [[nodiscard]] float NormalizeVerticalScrollOffset(float offsetDip, std::span<const GridGroupDesc> groups) const noexcept;
    [[nodiscard]] std::vector<VisibleBodyItem> BuildVisibleBodyItems(std::span<const GridGroupDesc> groups) const;
    [[nodiscard]] std::vector<VisibleBodyItem> BuildVisibleBodyItems(std::span<const GridGroupDesc> groups, const D2D1_RECT_F& bodyRect) const;
    [[nodiscard]] float GetVerticalScrollableExtent() const;
    [[nodiscard]] float GetVerticalScrollableExtent(std::span<const GridGroupDesc> groups) const;
    [[nodiscard]] float GetHorizontalScrollableExtent() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetContentRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetContentRect(std::span<const GridGroupDesc> groups) const noexcept;
    [[nodiscard]] D2D1_RECT_F GetVerticalScrollbarRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetHorizontalScrollbarRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetVerticalThumbRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetHorizontalThumbRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetVerticalThumbHitRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetHorizontalThumbHitRect() const noexcept;
    [[nodiscard]] float GetColumnLeftDip(size_t columnIndex) const noexcept;
    [[nodiscard]] GridCellLayoutMetrics ComputeCellLayoutMetrics(const ControlHost& host,
                                                                 const D2D1_RECT_F& cellRect,
                                                                 const GridColumnDesc& columnDesc,
                                                                 const GridCellData& cellData) const noexcept;
    // Visible multiline cells keep their layouts in a set-associative table keyed by value (see
    // PrepareCellTextLayout). An entry holds the text its layout was built from: the value's content, or the prefix
    // shaped for a value longer than the cell can show, which any value starting with it shares. A layout needing more
    // than a bounded key (a whole long right-to-left line) is temporary, so a scrolling grid cannot retain unbounded
    // text.
    struct CellTextLayoutCache
    {
        std::wstring text;
        wil::com_ptr<IDWriteTextFormat> format;
        wil::com_ptr<IDWriteTextLayout> layout;
        uint64_t keyHash   = 0u;
        uint64_t lastUse   = 0u; // Paint generation of the latest paint or hover that used the entry.
        float width        = 0.0f;
        float height       = 0.0f;
        float paintHeight  = 0.0f;
        uint32_t lineClamp = 0u;
        bool truncated     = false; // Paint cannot show the whole value; hover offers it in full.
        bool prefixOnly    = false; // text is the shaped prefix of a longer value.
        uint8_t breakShape = 0u;    // With prefixOnly: how that value continues (none, a line break, a CR LF pair).
    };
    // The layout of an omitted tail (the visible lines and the omission marker), shared by the values whose visible
    // text is the same.
    struct CellDisplayLayoutCache
    {
        std::wstring text;
        wil::com_ptr<IDWriteTextFormat> format;
        wil::com_ptr<IDWriteTextLayout> layout;
        uint64_t keyHash  = 0u;
        uint64_t lastUse  = 0u;
        float width       = 0.0f;
        float paintHeight = 0.0f;
    };
    // Paint and the hover tooltip share one prepared multiline layout, so the
    // omission marker and the full-value tooltip cannot disagree. Returns the
    // retained or temporary entry, or nullptr when no text can be painted.
    [[nodiscard]] const CellTextLayoutCache* PrepareCellTextLayout(
        const ControlHost& host, const GridCellData& cellData, float width, float height, std::optional<CellTextLayoutCache>& temporary) const;
    [[nodiscard]] bool IsMultilineCellTextClipped(const ControlHost& host,
                                                  const GridCellData& cellData,
                                                  const D2D1_RECT_F& textRect,
                                                  const D2D1_RECT_F& viewportRect) const;
    // A single-line cell's caption layout, as DrawCenteredText lays it out, kept between paints in the same table as
    // multiline layouts; paint and the hover check share it. Returns the retained or temporary entry, or nullptr.
    [[nodiscard]] const CellTextLayoutCache* PrepareSingleLineCellLayout(const ControlHost& host,
                                                                         const GridCellData& cellData,
                                                                         const D2D1_RECT_F& textRect,
                                                                         std::optional<CellTextLayoutCache>& temporary) const;
    [[nodiscard]] bool IsSingleLineCellTextClipped(const ControlHost& host,
                                                   const GridCellData& cellData,
                                                   const D2D1_RECT_F& textRect,
                                                   const D2D1_RECT_F& viewportRect) const;
    void DrawCellText(ControlHost& host, const GridCellData& cellData, const D2D1_RECT_F& bounds, const D2D1_COLOR_F& color) const;
    // Returns every retained layout, its string storage and the tables themselves, for a grid that stops painting (hidden,
    // detached from its host or given another model): the next paint, if any, rebuilds what it shows.
    void ReleaseCellTextResources() noexcept;
    mutable std::vector<CellTextLayoutCache> _cellTextLayouts;
    mutable std::vector<CellDisplayLayoutCache> _cellDisplayLayouts;
    mutable std::wstring _cellVisibleText; // Scratch for an omitted tail's visible text.
    mutable uint64_t _cellTextPaintGeneration = 1u;
    mutable wil::com_ptr<IDWriteTextFormat> _cellEllipsisFormat;
    mutable wil::com_ptr<IDWriteInlineObject> _cellEllipsis;
    [[nodiscard]] VisibleColumnSpan ComputeVisibleColumnSpan(float clipRightDip) const noexcept;
    [[nodiscard]] bool HasAnimatedVisibleCells() const;
    [[nodiscard]] GridSortGlyphVisualState ResolveSortGlyphVisualState(const ThemePalette& theme, size_t columnIndex, uint64_t nowTickMs) const noexcept;
    [[nodiscard]] float ComputeSortGlyphTransitionProgress(uint64_t nowTickMs) const noexcept;
    [[nodiscard]] std::optional<size_t> ResolveHeaderBusyColumn() const noexcept;
    bool UpdateScrollbarHotState(const HitInfo& hit) noexcept;
    void SyncScrollbarAnimation(ControlHost& host) noexcept;
    [[nodiscard]] size_t GetModelColumnIndexForDisplayIndex(size_t displayIndex) const noexcept;
    [[nodiscard]] size_t ResolveHeaderReorderTargetDisplayIndex(float xDip) const noexcept;
    void MoveColumnToDisplayIndex(size_t columnIndex, size_t targetDisplayIndex) noexcept;
    void RebuildColumnDisplayIndexLookup() const noexcept;

    // Non-owning. Caller manages model lifetime. Valid from SetModel() until Grid destruction.
    // Invalidation validated at message entry by PruneStaleInteractionState().
    IGridModel* _model       = nullptr;
    IGridDelegate* _delegate = nullptr;
    mutable std::vector<float> _columnWidths;
    mutable std::vector<size_t> _columnDisplayOrder;
    mutable std::vector<size_t> _columnDisplayIndexByModel;
    mutable std::vector<GridGroupDesc> _cachedGroups;
    GridSelectionModel _selectionModel;
    // The last selected row in visible/model order is not necessarily the row a Shift range reached.
    std::optional<uint64_t> _currentRowId;
    GridSelectionMode _selectionMode = GridSelectionMode::Extended;
    GridVisualMode _visualMode       = GridVisualMode::Standard;
    GridSortSpec _sortSpec{};
    std::optional<size_t> _headerBusyColumn;
    float _rowHeightBaseDip         = 28.0f;
    float _groupHeaderHeightBaseDip = 28.0f;
    float _headerHeightBaseDip      = 32.0f;
    float _rowHeightDip             = 28.0f;
    float _groupHeaderHeightDip     = 28.0f;
    float _headerHeightDip          = 32.0f;
    float _verticalScrollDip        = 0.0f;
    float _horizontalScrollDip      = 0.0f;
    std::optional<float> _effectiveRowHeightDip;
    FontRole _cellTextFontRole = FontRole::Body;
    float _iconSizeDip         = 18.0f;
    uint32_t _lineClamp        = 2;
    std::optional<size_t> _hoveredRow;
    std::optional<size_t> _hoveredColumn;
    std::optional<size_t> _activeColumn;
    std::optional<size_t> _pressedHeaderColumn;
    std::optional<size_t> _dragReorderColumn;
    size_t _dragReorderTargetDisplayIndex = 0u;
    std::optional<size_t> _resizeColumn;
    float _pressedHeaderOriginXDip               = 0.0f;
    float _resizeOriginXDip                      = 0.0f;
    float _resizeInitialWidthDip                 = 0.0f;
    bool _dragVerticalThumb                      = false;
    bool _dragHorizontalThumb                    = false;
    ScrollbarHotPart _verticalScrollbarHotPart   = ScrollbarHotPart::None;
    ScrollbarHotPart _horizontalScrollbarHotPart = ScrollbarHotPart::None;
    ScrollbarAnimationState _verticalScrollbarAnimation{};
    ScrollbarAnimationState _horizontalScrollbarAnimation{};
    float _dragThumbOffsetDip                      = 0.0f;
    bool _headerBusy                               = false;
    mutable bool _lastPaintHadAnimatedVisibleCells = false;
    mutable bool _animatedVisibleCellStateValid    = false;
    std::wstring _emptyStateText;
    // Keep test counters in the layout for all builds so ENABLE_TESTS only
    // affects helper APIs, not the object ABI across project boundaries.
    mutable uint64_t _debugPaintCount                          = 0u;
    mutable uint64_t _debugTextLayoutLookups                   = 0u;
    mutable uint64_t _debugTextLayoutHits                      = 0u;
    mutable uint64_t _debugTextLayoutCreations                 = 0u;
    mutable uint64_t _debugTextLayoutShapedUnits               = 0u;
    size_t _debugTextLayoutEntryLimit                          = 0u; // 0: the default ceiling.
    uint64_t _debugHeaderResizeDownCount                       = 0u;
    uint64_t _debugResizeMoveCount                             = 0u;
    float _debugLastResizeDeltaDip                             = 0.0f;
    float _debugLastResizeWidthDip                             = 0.0f;
    uint64_t _debugHeaderReorderStartCount                     = 0u;
    uint64_t _debugHeaderReorderCommitCount                    = 0u;
    uint64_t _debugHeaderReorderNoOpCount                      = 0u;
    size_t _debugLastHeaderReorderColumn                       = 0u;
    size_t _debugLastHeaderReorderFromDisplayIndex             = 0u;
    size_t _debugLastHeaderReorderRawTargetDisplayIndex        = 0u;
    size_t _debugLastHeaderReorderNormalizedTargetDisplayIndex = 0u;
    struct SortGlyphTransitionState final
    {
        GridSortSpec from{};
        GridSortSpec to{};
        uint64_t startTickMs = 0u;
        bool active          = false;
    } _sortGlyphTransition{};
};

ThemePalette MakeDefaultThemePalette(bool dark) noexcept;
ThemePalette MakeThemePalette(const ThemeColors& viewerTheme) noexcept;
void RefreshAccentVariants(ThemePalette& palette, bool darkBase) noexcept;

[[nodiscard]] ButtonVisualStyle ResolveButtonVisualStyle(
    const ThemePalette& theme, bool enabled, bool hovered, bool pressed, bool focused, bool keyboardFocused, bool primary) noexcept;
[[nodiscard]] ButtonVisualStyle ResolveButtonVisualStyle(const ThemePalette& theme,
                                                         bool enabled,
                                                         bool hovered,
                                                         bool pressed,
                                                         bool focused,
                                                         bool keyboardFocused,
                                                         bool primary,
                                                         float hoverStrength,
                                                         float focusStrength) noexcept;
[[nodiscard]] LabelVisualStyle ResolveLabelVisualStyle(const ThemePalette& theme, const std::optional<D2D1_COLOR_F>& textColorOverride) noexcept;
[[nodiscard]] ToggleVisualStyle ResolveToggleVisualStyle(
    const ThemePalette& theme, bool enabled, bool hovered, bool pressed, bool focused, bool keyboardFocused, bool checked) noexcept;
[[nodiscard]] ToggleVisualStyle ResolveToggleVisualStyle(const ThemePalette& theme,
                                                         bool enabled,
                                                         bool hovered,
                                                         bool pressed,
                                                         bool focused,
                                                         bool keyboardFocused,
                                                         bool checked,
                                                         float hoverStrength,
                                                         float focusStrength) noexcept;
[[nodiscard]] CheckboxVisualStyle ResolveCheckboxVisualStyle(
    const ThemePalette& theme, bool enabled, bool hovered, bool pressed, bool focused, bool keyboardFocused, bool checked) noexcept;
[[nodiscard]] CheckboxVisualStyle ResolveCheckboxVisualStyle(const ThemePalette& theme,
                                                             bool enabled,
                                                             bool hovered,
                                                             bool pressed,
                                                             bool focused,
                                                             bool keyboardFocused,
                                                             bool checked,
                                                             float hoverStrength,
                                                             float focusStrength) noexcept;
[[nodiscard]] RadioButtonVisualStyle ResolveRadioButtonVisualStyle(
    const ThemePalette& theme, bool enabled, bool hovered, bool pressed, bool focused, bool keyboardFocused, bool checked) noexcept;
[[nodiscard]] RadioButtonVisualStyle ResolveRadioButtonVisualStyle(const ThemePalette& theme,
                                                                   bool enabled,
                                                                   bool hovered,
                                                                   bool pressed,
                                                                   bool focused,
                                                                   bool keyboardFocused,
                                                                   bool checked,
                                                                   float hoverStrength,
                                                                   float focusStrength) noexcept;
[[nodiscard]] ProgressBarVisualStyle ResolveProgressBarVisualStyle(const ThemePalette& theme) noexcept;
[[nodiscard]] ToolbarVisualStyle ResolveToolbarVisualStyle(const ThemePalette& theme) noexcept;
[[nodiscard]] ColorSwatchVisualStyle ResolveColorSwatchVisualStyle(const ThemePalette& theme,
                                                                   bool enabled,
                                                                   bool hovered,
                                                                   bool pressed,
                                                                   bool focused,
                                                                   bool keyboardFocused                      = false,
                                                                   const std::optional<uint32_t>& swatchArgb = std::nullopt) noexcept;
[[nodiscard]] CardPanelVisualStyle ResolveCardPanelVisualStyle(const ThemePalette& theme) noexcept;
[[nodiscard]] TooltipVisualStyle ResolveTooltipVisualStyle(const ThemePalette& theme) noexcept;
[[nodiscard]] TextFieldVisualStyle ResolveTextFieldVisualStyle(const ThemePalette& theme,
                                                               bool enabled,
                                                               bool hovered,
                                                               bool focused,
                                                               bool keyboardFocused,
                                                               std::optional<D2D1_COLOR_F> caretColorOverride = std::nullopt) noexcept;
[[nodiscard]] GridSurfaceVisualStyle ResolveGridSurfaceVisualStyle(const ThemePalette& theme) noexcept;
[[nodiscard]] TreeSurfaceVisualStyle ResolveTreeSurfaceVisualStyle(const ThemePalette& theme) noexcept;
[[nodiscard]] GridHeaderVisualStyle ResolveGridHeaderVisualStyle(const ThemePalette& theme) noexcept;
[[nodiscard]] GridCheckboxVisualStyle ResolveGridCheckboxVisualStyle(
    const ThemePalette& theme, const D2D1_COLOR_F& rowFill, const D2D1_COLOR_F& rowText, bool enabled, bool hovered, bool selected, bool checked) noexcept;
[[nodiscard]] GridSwatchVisualStyle ResolveGridSwatchVisualStyle(
    const ThemePalette& theme, const D2D1_COLOR_F& rowFill, const D2D1_COLOR_F& rowText, bool selected, const GridCellData& cellData) noexcept;
[[nodiscard]] GridBadgeVisualStyle ResolveGridBadgeVisualStyle(
    const ThemePalette& theme, const D2D1_COLOR_F& rowFill, const D2D1_COLOR_F& rowText, bool selected, AdornmentTone tone) noexcept;
[[nodiscard]] TreeBadgeVisualStyle ResolveTreeBadgeVisualStyle(const ThemePalette& theme, AdornmentTone tone) noexcept;
[[nodiscard]] ComboBoxVisualStyle ResolveComboBoxVisualStyle(
    const ThemePalette& theme, ComboBoxVariant variant, bool enabled, bool hovered, bool popupOpen, bool focused, bool keyboardFocused) noexcept;
[[nodiscard]] float EvaluateEasing(EasingCurve curve, float t) noexcept;
[[nodiscard]] SortDirection NextSortDirection(SortDirection current) noexcept;
[[nodiscard]] VisibleSpan ComputeVisibleSpan(uint64_t totalItems, float itemExtentDip, float scrollOffsetDip, float viewportExtentDip) noexcept;
[[nodiscard]] std::optional<size_t> FindMnemonicTextIndex(std::wstring_view text, wchar_t mnemonic) noexcept;
void ShutdownAllWindowHostsForProcessExit() noexcept;
void ShutdownNativeTextInputForCurrentThread() noexcept;
#if DXUI_ENABLE_DIAGNOSTICS
[[nodiscard]] size_t DebugGetAttachedWindowHostCount() noexcept;
[[nodiscard]] uint32_t DebugGetSharedWindowHostAttachmentCountForThread(DWORD threadId) noexcept;
void DebugClearClipboardFallbackText() noexcept;
[[nodiscard]] bool DebugSetClipboardFallbackText(std::wstring_view text) noexcept;
[[nodiscard]] std::optional<std::wstring> DebugReadClipboardFallbackText() noexcept;
[[nodiscard]] bool DebugWriteClipboardUnicodeText(HWND ownerWindow, std::wstring_view text) noexcept;
#endif

// ── Editor consumer controls ─────────────────────────────────────────────
// Generic controls an editor-class consumer composes into its own chrome (split panes, numeric inspectors, a
// color picker). None of them knows about documents, layers, brushes or application settings.

enum class SplitterOrientation : uint8_t
{
    Vertical,   // The separator is a vertical bar: first pane left, second pane right (mirrored in RTL).
    Horizontal, // The separator is a horizontal bar: first pane above, second pane below.
};

enum class SplitterChangePhase : uint8_t
{
    Preview,
    Commit,
    Cancel,
};

struct SplitterChange
{
    SplitterChangePhase phase;
    float position;
};

// A draggable separator between two panes whose bounds the consumer applies. Position is the DIP offset of the
// separator's leading edge from the control's leading edge, clamped by the pane minimums. Dragging previews,
// releasing commits, Escape or capture loss restores the drag start. Left/Right (Up/Down) step, Shift steps
// further, Home/End go to the limits; keyboard changes commit. The persistable position is consumer state.
class Splitter final : public Control
{
public:
    static constexpr float kDefaultThicknessDip   = 6.0f;
    static constexpr float kDefaultMinimumPaneDip = 48.0f;
    static constexpr float kKeyboardStepDip       = 8.0f;
    static constexpr float kKeyboardLargeStepDip  = 32.0f;
    static constexpr float kHitSlopDip            = 2.0f;

    Splitter();

    void SetOrientation(SplitterOrientation orientation) noexcept;
    [[nodiscard]] SplitterOrientation GetOrientation() const noexcept;
    void SetThickness(float thicknessDip) noexcept;
    [[nodiscard]] float GetThickness() const noexcept;
    void SetMinimumFirstPane(float minimumDip) noexcept;
    [[nodiscard]] float GetMinimumFirstPane() const noexcept;
    void SetMinimumSecondPane(float minimumDip) noexcept;
    [[nodiscard]] float GetMinimumSecondPane() const noexcept;
    // Clamps and repaints without notifying; use it to apply persisted or resize-derived positions.
    void SetPosition(float positionDip) noexcept;
    [[nodiscard]] float GetPosition() const noexcept;
    // One committed programmatic change; false while dragging, when disabled, or for a non-finite value.
    bool RequestPosition(ControlHost& host, float positionDip) noexcept;
    void SetOnChange(std::function<void(SplitterChange)> onChange);
    [[nodiscard]] bool IsDragging() const noexcept;
    [[nodiscard]] float ClampPosition(float positionDip) const noexcept;
    [[nodiscard]] D2D1_RECT_F GetFirstPaneBounds() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetSecondPaneBounds() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetSeparatorBounds() const noexcept;

    [[nodiscard]] D2D1_RECT_F GetHitBounds() const noexcept override;
    void Paint(ControlHost& host) const override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    void OnCaptureLost(ControlHost& host) override;

protected:
    void OnBoundsChanged() noexcept override;
    [[nodiscard]] WindowHostCursorKind ResolveCursorKind(ControlHost& host, D2D1_POINT_2F pointDip) const noexcept override;

private:
    void NotifyChange(SplitterChangePhase phase) noexcept;
    [[nodiscard]] float Extent() const noexcept;
    [[nodiscard]] float PointerAxis(D2D1_POINT_2F point) const noexcept;

    std::shared_ptr<const std::function<void(SplitterChange)>> _onChange;
    SplitterOrientation _orientation = SplitterOrientation::Vertical;
    float _thicknessDip              = kDefaultThicknessDip;
    float _minimumFirstDip           = kDefaultMinimumPaneDip;
    float _minimumSecondDip          = kDefaultMinimumPaneDip;
    float _positionDip               = kDefaultMinimumPaneDip;
    float _dragStartPositionDip      = 0.0f;
    float _dragPointerOffsetDip      = 0.0f;
    bool _dragging                   = false;
};

enum class NumericStepperChangePhase : uint8_t
{
    Preview,
    Commit,
    Cancel,
};

struct NumericStepperChange
{
    NumericStepperChangePhase phase;
    double value;
};

// A labeled numeric field with step buttons and keyboard nudge for inspectors and dialogs. Typing previews as soon
// as the text parses; Enter, focus loss, the buttons, Up/Down (Shift: large step) commit; Escape cancels the edit
// and restores the committed value. Values clamp to [minimum, maximum] and format with a fixed number of decimals.
class NumericStepper final : public Panel
{
public:
    static constexpr float kDefaultHeightDip = 32.0f;
    static constexpr float kButtonWidthDip   = 22.0f;
    static constexpr float kGapDip           = 4.0f;

    NumericStepper();

    void SetLabel(std::wstring label, float widthDip);
    [[nodiscard]] std::wstring_view GetLabel() const noexcept;
    void SetUnit(std::wstring unit, float widthDip);
    [[nodiscard]] std::wstring_view GetUnit() const noexcept;
    // Names the step buttons for UI Automation (their glyphs say nothing to a screen reader). The defaults are the
    // English "Increase" and "Decrease"; a consumer supplies complete localized names ("Augmenter la largeur").
    void SetStepButtonNames(std::wstring increaseName, std::wstring decreaseName);
    void SetMinimum(double minimum) noexcept;
    [[nodiscard]] double GetMinimum() const noexcept;
    void SetMaximum(double maximum) noexcept;
    [[nodiscard]] double GetMaximum() const noexcept;
    void SetStep(double step) noexcept;
    [[nodiscard]] double GetStep() const noexcept;
    void SetLargeStep(double step) noexcept;
    [[nodiscard]] double GetLargeStep() const noexcept;
    void SetDecimals(uint8_t decimals) noexcept;
    [[nodiscard]] uint8_t GetDecimals() const noexcept;
    // Clamps, updates the text and repaints without notifying.
    void SetValue(double value) noexcept;
    [[nodiscard]] double GetValue() const noexcept;
    // One committed change; false when disabled or for a non-finite value.
    bool RequestValue(ControlHost& host, double value) noexcept;
    // One step (large: the large step) in `direction` (+1 / -1), committed; false when disabled or at the limit.
    bool Nudge(ControlHost& host, int direction, bool large) noexcept;
    void SetOnChange(std::function<void(NumericStepperChange)> onChange);
    [[nodiscard]] bool IsEditing() const noexcept;
    [[nodiscard]] TextField& Field() noexcept;
    [[nodiscard]] const TextField& Field() const noexcept;
    [[nodiscard]] Button& IncrementButton() noexcept;
    [[nodiscard]] Button& DecrementButton() noexcept;
    [[nodiscard]] std::wstring FormatValue(double value) const;
    // Accepts an optional sign, digits, and one '.' or ',' fraction; surrounding whitespace is ignored. Full-width and
    // Arabic-Indic digits, signs and separators read as their ASCII equivalents.
    [[nodiscard]] static std::optional<double> ParseValue(std::wstring_view text) noexcept;

    void Paint(ControlHost& host) const override;

protected:
    void OnBoundsChanged() noexcept override;
    void OnEnabledChanged(bool enabled) noexcept override;
    void OnFlowDirectionChanged() noexcept override;

private:
    void Arrange() noexcept;
    void SyncText();
    [[nodiscard]] double ClampValue(double value) const noexcept;
    bool CommitEdit(ControlHost* host) noexcept;
    void CancelEdit(ControlHost* host) noexcept;
    void ApplyValue(ControlHost* host, double value, NumericStepperChangePhase phase) noexcept;
    void NotifyChange(NumericStepperChangePhase phase) noexcept;

    std::shared_ptr<const std::function<void(NumericStepperChange)>> _onChange;
    TextField* _field  = nullptr;
    Button* _increment = nullptr;
    Button* _decrement = nullptr;
    std::wstring _label;
    std::wstring _unit;
    float _labelWidthDip = 0.0f;
    float _unitWidthDip  = 0.0f;
    double _minimum      = -1.0e9;
    double _maximum      = 1.0e9;
    double _step         = 1.0;
    double _largeStep    = 10.0;
    double _value        = 0.0;
    double _editStart    = 0.0;
    uint8_t _decimals    = 0;
    bool _editing        = false;
    bool _editPreviewed  = false; // The open edit sent a preview, so it must end with Commit or Cancel.
    bool _syncing        = false;
};

struct HsvColor
{
    float hue        = 0.0f; // degrees, 0 ≤ hue < 360
    float saturation = 0.0f; // 0…1
    float value      = 0.0f; // 0…1
};

// Grays and black have no hue of their own; `previous` keeps the last hue (and saturation for black) so a picker
// field does not jump while the user drags through the gray axis.
[[nodiscard]] HsvColor HsvFromArgb(uint32_t argb, const HsvColor* previous = nullptr) noexcept;
[[nodiscard]] uint32_t ArgbFromHsv(const HsvColor& hsv, uint8_t alpha = 255u) noexcept;
// "#RRGGBB", "RRGGBB", "#RGB" or "RGB" (case-insensitive, surrounding whitespace ignored); alpha is opaque.
[[nodiscard]] std::optional<uint32_t> ParseHexColor(std::wstring_view text) noexcept;
[[nodiscard]] std::wstring FormatHexColor(uint32_t argb);

enum class ColorPickerChangePhase : uint8_t
{
    Preview,
    Commit,
    Cancel,
};

struct ColorPickerChange
{
    ColorPickerChangePhase phase;
    uint32_t argb;
};

// HSV field, hue strip, R/G/B steppers, hex field, new/current swatches, OK and Cancel. Pointer drags and typed
// values preview; OK or Enter commit; Escape, Cancel, or capture loss during a drag cancel and restore the current
// color. Eyedropping outside the picker is the host's job: it feeds `SampleColor`. Strings are consumer-supplied.
class ColorPicker final : public Panel
{
public:
    static constexpr float kDefaultWidthDip  = 316.0f;
    static constexpr float kDefaultHeightDip = 236.0f;
    static constexpr float kFieldDip         = 160.0f;
    static constexpr float kHueStripWidthDip = 20.0f;
    static constexpr float kGapDip           = 8.0f;
    static constexpr float kSwatchDip        = 28.0f; // swatch height
    static constexpr float kSwatchWidthDip   = 44.0f; // wide enough for a short caption beneath
    static constexpr float kRowDip           = 28.0f;
    static constexpr float kButtonWidthDip   = 72.0f;

    struct Labels
    {
        std::wstring newColor     = L"New";
        std::wstring currentColor = L"Current";
        std::wstring hex          = L"Hex";
        std::wstring red          = L"R";
        std::wstring green        = L"G";
        std::wstring blue         = L"B";
        std::wstring ok           = L"OK";
        std::wstring cancel       = L"Cancel";
        // The names assistive technologies read for the R/G/B fields' step buttons (whole phrases, as word order
        // varies between languages).
        std::wstring increaseRed   = L"Increase red";
        std::wstring decreaseRed   = L"Decrease red";
        std::wstring increaseGreen = L"Increase green";
        std::wstring decreaseGreen = L"Decrease green";
        std::wstring increaseBlue  = L"Increase blue";
        std::wstring decreaseBlue  = L"Decrease blue";
        // Room for translated captions: the R/G/B caption slot, the hex caption slot and each swatch (which its
        // caption fits beneath), each at most kMaxLabelWidthDip. A picker wider than kDefaultWidthDip leaves room for
        // wider swatches.
        float channelLabelWidthDip = 14.0f;
        float hexLabelWidthDip     = 26.0f;
        float swatchWidthDip       = kSwatchWidthDip;
    };
    static constexpr float kMaxLabelWidthDip = 4096.0f;

    ColorPicker();

    void SetLabels(Labels labels);
    [[nodiscard]] const Labels& GetLabels() const noexcept;
    // The editing color and the current (reference) swatch, without notifying.
    void SetColor(uint32_t argb) noexcept;
    [[nodiscard]] uint32_t GetColor() const noexcept;
    void SetCurrentColor(uint32_t argb) noexcept;
    [[nodiscard]] uint32_t GetCurrentColor() const noexcept;
    [[nodiscard]] HsvColor GetHsv() const noexcept;
    // A host-sampled color (eyedropper) becomes the editing color and previews.
    void SampleColor(ControlHost& host, uint32_t argb) noexcept;
    void Commit(ControlHost& host) noexcept;
    void Cancel(ControlHost& host) noexcept;
    void SetOnChange(std::function<void(ColorPickerChange)> onChange);
    [[nodiscard]] bool IsDragging() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetFieldRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetHueStripRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetNewSwatchRect() const noexcept;
    [[nodiscard]] D2D1_RECT_F GetCurrentSwatchRect() const noexcept;
    [[nodiscard]] NumericStepper& RedField() noexcept;
    [[nodiscard]] NumericStepper& GreenField() noexcept;
    [[nodiscard]] NumericStepper& BlueField() noexcept;
    [[nodiscard]] TextField& HexField() noexcept;
    [[nodiscard]] Button& OkButton() noexcept;
    [[nodiscard]] Button& CancelButton() noexcept;
#if DXUI_ENABLE_DIAGNOSTICS
    [[nodiscard]] bool DebugHasCachedBrushes() const noexcept;
#endif

    void Paint(ControlHost& host) const override;
    bool OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers) override;
    bool OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers) override;
    bool OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers) override;
    void OnCaptureLost(ControlHost& host) override;

protected:
    void PropagateHost(ControlHost* host) noexcept override;
    void OnBoundsChanged() noexcept override;
    void OnEnabledChanged(bool enabled) noexcept override;
    void OnFlowDirectionChanged() noexcept override;

private:
    enum class Drag : uint8_t
    {
        None,
        Field,
        Hue,
    };

    void Arrange() noexcept;
    void ApplyHsv(ControlHost* host, HsvColor hsv, bool notify) noexcept;
    // `source` is the child whose edit produced the color; it keeps its text, caret and undo history.
    void ApplyArgb(ControlHost* host, uint32_t argb, bool notify, const Control* source = nullptr) noexcept;
    void SyncChildren(const Control* source = nullptr) noexcept;
    void NotifyChange(ColorPickerChangePhase phase) noexcept;
    void UpdateFromPoint(ControlHost& host, D2D1_POINT_2F point) noexcept;
    void EnsureBrushes(ControlHost& host) const noexcept;

    std::shared_ptr<const std::function<void(ColorPickerChange)>> _onChange;
    Labels _labels;
    D2D1_RECT_F _hexCaptionRect = D2D1::RectF(); // Arranged beside the hex field; Paint draws the caption there.
    NumericStepper* _red        = nullptr;
    NumericStepper* _green      = nullptr;
    NumericStepper* _blue       = nullptr;
    TextField* _hex             = nullptr;
    Button* _ok                 = nullptr;
    Button* _cancel             = nullptr;
    HsvColor _hsv;
    uint32_t _argb    = 0xFF000000u;
    uint32_t _current = 0xFF000000u;
    Drag _drag        = Drag::None;
    bool _syncing     = false;
    // Hue-independent unit-space gradients, placed by a brush transform: neither a hue change nor a layout move
    // recreates them. The retained device reference keeps a recreated device from aliasing the cached one. They
    // belong to the host being painted for, so a host change releases them (PropagateHost). The arrangement follows
    // the flow direction through OnFlowDirectionChanged, which a move announces (Control::Reparent).
    mutable wil::com_ptr<ID2D1Device> _brushDevice;
    mutable wil::com_ptr<ID2D1LinearGradientBrush> _saturationBrush;
    mutable wil::com_ptr<ID2D1LinearGradientBrush> _valueBrush;
    mutable wil::com_ptr<ID2D1LinearGradientBrush> _hueBrush;
};

class ControlHost final
{
public:
    enum class PresentationMode : uint8_t
    {
        HwndSwapChain,
        CompositionSwapChain,
    };

    struct AttachOptions final
    {
        PresentationMode presentationMode = PresentationMode::HwndSwapChain;
    };

    ControlHost() = default;
    ~ControlHost();

    ControlHost(const ControlHost&)            = delete;
    ControlHost(ControlHost&&)                 = delete;
    ControlHost& operator=(const ControlHost&) = delete;
    ControlHost& operator=(ControlHost&&)      = delete;

    [[nodiscard]] bool Attach(HWND hwnd) noexcept;
    [[nodiscard]] bool Attach(HWND hwnd, const AttachOptions& options) noexcept;
    void Detach() noexcept;

    void SetTheme(const ThemePalette& palette) noexcept;
    [[nodiscard]] const ThemePalette& GetTheme() const noexcept;

    void SetRoot(std::unique_ptr<Control> root);
    [[nodiscard]] Control* GetRoot() noexcept;
    [[nodiscard]] const Control* GetRoot() const noexcept;

    bool SetTooltip(std::wstring text, const D2D1_POINT_2F& originDip);
    bool SetTooltipDelayed(std::wstring text, const D2D1_POINT_2F& originDip);
    bool BeginTooltipHideDelay(uint64_t delayMs = 100u) noexcept;
    bool ClearTooltip() noexcept;
    [[nodiscard]] bool HasTooltip() const noexcept;
    [[nodiscard]] std::wstring_view GetTooltipText() const noexcept;
#if DXUI_ENABLE_DIAGNOSTICS
    [[nodiscard]] std::wstring_view DebugGetPendingTooltipText() const noexcept;
    [[nodiscard]] bool DebugAdvanceTooltipDelayForTest() noexcept;
#endif

    void SetSmokeOverlayVisible(bool visible) noexcept;
    [[nodiscard]] bool IsSmokeOverlayVisible() const noexcept;

    // Mica/Acrylic backdrop hint — sets DWM system backdrop type on the supported Windows 11 baseline.
    // Returns true if the backdrop was applied (host HWND exists and API succeeds).
    enum class BackdropType : int
    {
        None    = 1, // DWMSBT_NONE
        Mica    = 2, // DWMSBT_MAINWINDOW
        Acrylic = 3, // DWMSBT_TRANSIENTWINDOW
        MicaAlt = 4  // DWMSBT_TABBEDWINDOW
    };
    bool SetSystemBackdrop(BackdropType type) noexcept;

    void Invalidate() const noexcept;
    void RefreshAccessibilitySnapshot() noexcept;
    [[nodiscard]] bool PrimeForShow() noexcept;
    [[nodiscard]] bool RenderInitialFrameForShow() noexcept;
    void RequestAnimation() noexcept;
    void SetDefaultButton(Button* button) noexcept;
    [[nodiscard]] Button* GetDefaultButton() const noexcept;
    void SetCancelButton(Button* button) noexcept;
    [[nodiscard]] Button* GetCancelButton() const noexcept;
    void SetOnTabBoundary(std::function<bool(bool reverse)> onTabBoundary);
    void SetOnEscape(std::function<bool()> onEscape);
    void SetOnFocusChanged(std::function<void(Control* control)> onFocusChanged);
    void ResetInteractionState() noexcept;
    // Native command menus may track a non-text logical focus while their owner
    // retains Win32 focus. Ordinary controls keep the default native transfer.
    void SetFocusControl(Control* control, bool transferNativeFocus = true) noexcept;
    [[nodiscard]] Control* GetFocusControl() const noexcept;
    [[nodiscard]] bool HandleMnemonic(wchar_t mnemonic) noexcept;
    void SetTextInputBackend(TextInputBackend backend) noexcept;
    [[nodiscard]] TextInputBackend GetTextInputBackend() const noexcept;
    [[nodiscard]] bool HasActiveNativeTextInputSession() const noexcept;
    [[nodiscard]] bool TryReadNativeTextInputState(const Control* control, NativeTextInputState& outState) const noexcept;
    void CommitFocusedTextInput() noexcept;
    [[nodiscard]] bool TryReadTextInputState(const Control* control, TextInputState& outState) const noexcept;
    void SyncTextInput(Control* control) noexcept;
    [[nodiscard]] bool HasActiveTextInput() const noexcept;
    [[nodiscard]] HWND GetTextInputHwnd() const noexcept;
    void CaptureMouse(Control* control) noexcept;
    [[nodiscard]] Control* GetCapturedControl() const noexcept;
    void ReleaseMouseCapture() noexcept;
    [[nodiscard]] HWND GetHwnd() const noexcept;
    [[nodiscard]] bool IsEmbedded() const noexcept
    {
        return _embedded;
    }
    [[nodiscard]] D2D1_RECT_F GetClientBoundsDip() const noexcept;
    [[nodiscard]] float GetDpi() const noexcept;
    [[nodiscard]] float PixelsToDip(float pixels) const noexcept;
    [[nodiscard]] float DipsToPixels(float dips) const noexcept;
    [[nodiscard]] PointDip PixelsToDipPoint(POINT pointPx) const noexcept;
    [[nodiscard]] std::optional<PointDip> ScreenPointToDipPoint(POINT screenPointPx) const noexcept;
    [[nodiscard]] POINT DipPointToScreenPoint(D2D1_POINT_2F pointDip) const noexcept;
    [[nodiscard]] InputModality GetInputModality() const noexcept;
    // The device of the pointer event being handled, kept until the next one: the window host reads it from each mouse
    // message, an embedded host from PointerEvent::device.
    [[nodiscard]] PointerDevice GetPointerDevice() const noexcept;
    [[nodiscard]] bool IsKeyboardFocusVisible() const noexcept;
    [[nodiscard]] PresentationMode GetPresentationMode() const noexcept
    {
        return _presentationMode;
    }
    [[nodiscard]] ID2D1DeviceContext* GetDeviceContext() const noexcept;
    [[nodiscard]] IDWriteFactory* GetWriteFactory() const noexcept;
    [[nodiscard]] IDWriteTextFormat* GetTextFormat(FontRole role) const noexcept;
    [[nodiscard]] IDWriteTextFormat* GetTextFormat(FontRole role,
                                                   DWRITE_TEXT_ALIGNMENT alignment,
                                                   DWRITE_PARAGRAPH_ALIGNMENT paragraphAlignment,
                                                   bool wrap,
                                                   DWRITE_READING_DIRECTION readingDirection = DWRITE_READING_DIRECTION_LEFT_TO_RIGHT) const noexcept;
    [[nodiscard]] bool HasFluentIconFont() const noexcept;
    [[nodiscard]] ID2D1SolidColorBrush* GetSolidBrush(const D2D1_COLOR_F& color) const;
    // Bounds of the per-host solid-brush and configured-text-format caches. A cache beyond its bound is
    // cleared at the start of the next paint/preparation, never while a borrowed pointer is in use.
    static constexpr size_t kSolidBrushCacheLimit           = 256;
    static constexpr size_t kConfiguredTextFormatCacheLimit = 96;

    [[nodiscard]] bool CopyTextToClipboard(std::wstring_view text) const noexcept;
    [[nodiscard]] std::optional<std::wstring> ReadTextFromClipboard() const noexcept;

    LRESULT HandleMessage(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp, bool& handled) noexcept;
#if DXUI_ENABLE_DIAGNOSTICS
    // The device of the pointer events a test dispatches straight to a control, which no message or PointerEvent carries.
    void DebugSetPointerDevice(PointerDevice device) noexcept;
    [[nodiscard]] uint64_t DebugGetInvalidateCount() const noexcept;
    // UI Automation focus-changed events this host raised itself (the window's own focus event is the system's).
    [[nodiscard]] uint64_t DebugGetFocusAnnouncementCount() const noexcept;
    // Focus moves the host left to the system's focus event rather than announce: moves made in the message-loop turn in
    // which the window gained focus while no call of the fragment root's GetFocus had ever begun (see OnSetFocus).
    [[nodiscard]] uint64_t DebugGetFocusMovesLeftToSystemCount() const noexcept;
    // Whether the window gained focus in the message-loop turn still running (see OnSetFocus).
    [[nodiscard]] bool DebugIsInFocusGainTurn() const noexcept;
    // Gains of a window whose fragment root had been asked for its focus before, whose focused element the host announced
    // when the gain's turn ended because UI Automation reports nothing for them (see BeginFocusGainTurn). Counted when the
    // host decides, whether or not the window holds the foreground for the announcement to reach a client.
    [[nodiscard]] uint64_t DebugGetReactivationAnnouncementCount() const noexcept;
    [[nodiscard]] uint64_t DebugGetRenderCount() const noexcept;
    [[nodiscard]] uint64_t DebugGetResizeCount() const noexcept;
    [[nodiscard]] uint64_t DebugGetResizeFailureCount() const noexcept;
    [[nodiscard]] uint64_t DebugGetSwapChainPrepareD2DFlushFailureCount() const noexcept;
    [[nodiscard]] uint64_t DebugGetPresentFailureCount() const noexcept;
    [[nodiscard]] bool DebugHasActiveAnimationSubscription() const noexcept;
    [[nodiscard]] bool DebugAnimationTickForTest(uint64_t nowTickMs) noexcept;
    [[nodiscard]] IRawElementProviderFragmentRoot* DebugCreateAccessibilityProvider() const noexcept;
    void DebugSimulateDeviceLoss() noexcept;
    [[nodiscard]] size_t DebugGetBrushCacheSize() const noexcept;
    [[nodiscard]] bool DebugHasFallbackBrush() const noexcept;
    [[nodiscard]] bool DebugHasD2DContext() const noexcept;
    [[nodiscard]] size_t DebugGetConfiguredTextFormatCount() const noexcept;
    [[nodiscard]] UINT DebugGetModifierState() const noexcept;
    [[nodiscard]] bool DebugHasActiveNativeTextInputSession() const noexcept;
    [[nodiscard]] bool DebugHasActiveNativeTextInputTsfDocument() const noexcept;
    [[nodiscard]] bool DebugGetNativeTextInputState(NativeTextInputState& outState) const noexcept;
    [[nodiscard]] bool DebugGetNativeTextInputCaretRect(D2D1_RECT_F& outRectDip, RECT& outScreenRectPx) const noexcept;
    [[nodiscard]] NativeTextInputEventCounters DebugGetNativeTextInputEventCounters() const noexcept;
    void DebugSetNativeTextInputImePayloadForTest(NativeTextInputImePayload payload);
    void DebugDetachForProcessExit() noexcept;
    void DebugSetForceNullSolidBrushes(bool force) noexcept;
    [[nodiscard]] const Control* DebugHitTestControl(D2D1_POINT_2F pointDip) noexcept;
    [[nodiscard]] WindowHostCursorKind DebugResolveCursorKindForPoint(D2D1_POINT_2F pointDip) noexcept;
    [[nodiscard]] UINT DebugGetWidthPx() const noexcept
    {
        return _widthPx;
    }
    [[nodiscard]] UINT DebugGetHeightPx() const noexcept
    {
        return _heightPx;
    }
    [[nodiscard]] D2D1_RECT_F DebugGetTooltipBoundsDip() const noexcept;
    [[nodiscard]] bool DebugCaptureBitmap(WindowHostBitmapCapture& out) noexcept;
    [[nodiscard]] ITextStoreACP* DebugCreateNativeTextInputTextStoreForTest() noexcept;
#endif

private:
    friend class EmbeddedHost;
    friend class Control;
    friend struct EmbeddedAccessibilityAccess;
    void* _embeddedAccessibilityTarget          = nullptr;
    bool _gainingWindowFocus                    = false; // In OnSetFocus: the system's focus event reports the element.
    ULONGLONG _focusGainTurnStartedMs           = 0u;    // From OnSetFocus until the message loop turns: the event may still report.
    WPARAM _focusGainTurnId                     = 0u;    // The turn the posted end message names; an earlier turn's message ends nothing.
    uint64_t _focusGainResolutions              = 0u;    // Fragment-root GetFocus calls begun when the latest gain began.
    bool _focusGainTurnAnnounced                = false; // The host announced a focus move of the gain's turn itself.
    uint64_t _interactionRevision               = 0;
    bool _embedded                              = false;
    bool _embeddedAnimationRequested            = false;
    void* _embeddedContext                      = nullptr;
    void (*_embeddedInvalidate)(void*) noexcept = nullptr;
    friend void ShutdownAllWindowHostsForProcessExit() noexcept;

    void Detach(bool processExit) noexcept;
    void DetachForProcessExit() noexcept;
    void AbandonRetainedControlObserversForProcessExit() noexcept;
    [[nodiscard]] bool EnsureDeviceIndependentResources() const noexcept;
    [[nodiscard]] bool EnsureDeviceResources() noexcept;
    [[nodiscard]] bool EnsureSizeDependentResources(bool allowHidden = false) noexcept;
    void PrepareForSwapChainResize() noexcept;
    void DiscardSizeDependentResources(std::wstring_view reason = {}) noexcept;
    void DiscardDeviceResources() noexcept;
    void RecreateBrushCache() const;
    void TrimCaches() const noexcept;
    void Render(const RECT* dirtyRectPx = nullptr, bool allowHidden = false) noexcept;
#if DXUI_ENABLE_DIAGNOSTICS
    void Render(const RECT* dirtyRectPx, WindowHostBitmapCapture* capture, bool allowHidden = false) noexcept;
    [[nodiscard]] bool CaptureCurrentBackBuffer(WindowHostBitmapCapture& out) noexcept;
#endif
    void OnDpiChanged(HWND hwnd, UINT newDpi, const RECT* suggestedRect) noexcept;
    void OnSize(UINT widthPx, UINT heightPx) noexcept;
    void OnSetFocus() noexcept;
    void BeginFocusGainTurn() noexcept;
    [[nodiscard]] bool IsInFocusGainTurn() const noexcept;
    void OnKillFocus(bool clearRetainedFocus) noexcept;
    void ActivateTextInput(Control* control) noexcept;
    void DeactivateTextInput(bool restoreHostFocus) noexcept;
    void ActivateNativeTextInputSession(Control* control) noexcept;
    void DeactivateNativeTextInputSession(bool restoreHostFocus) noexcept;
    void SyncNativeTextInputSession(Control* control) noexcept;
    void SecureClearNativeTextInputStateCache() noexcept;
    [[nodiscard]] bool ActivateNativeTextInputTsf(Control* control) noexcept;
    void DeactivateNativeTextInputTsf() noexcept;
    void ApplyNativeTextInputCompositionStateToCache() noexcept;
    void ClearNativeTextInputCompositionState() noexcept;
    [[nodiscard]] NativeTextInputImePayload ReadNativeTextInputImePayload(LPARAM compositionFlags) noexcept;
    void UpdateNativeTextInputImeWindows() noexcept;
    void UpdateNativeTextInputCaret() noexcept;
    void DestroyNativeTextInputCaret() noexcept;
    void RaiseNativeTextInputAccessibilityEvent(TextInputAutomationEventKind kind) noexcept;
    void RaiseNativeTextInputAccessibilityEvents(const NativeTextInputState& previousState) noexcept;
    [[nodiscard]] bool TryGetNativeTextInputCaretRects(D2D1_RECT_F& outRectDip, RECT& outClientRectPx, RECT& outScreenRectPx) const noexcept;
    // Drops interaction state on controls that left the tree or became inert; a dropped focus is published.
    void PruneStaleInteractionState() noexcept;
    // Message entry only, where no dispatched control is borrowed: a captured control that is still in the tree but
    // no longer interactive (it or an ancestor was hidden or disabled) cancels its drag, as EmbeddedHost does.
    void CancelStaleCapture() noexcept;
    void ResetRootInteractionState() noexcept;
    void UpdateSupplementalTooltipTarget(D2D1_POINT_2F pointDip) noexcept;
    void ValidateSupplementalTooltipTarget() noexcept;
    [[nodiscard]] bool HandleTabNavigation(bool reverse) noexcept;
    [[nodiscard]] bool RouteFocusedCharInput(wchar_t ch, UINT modifiers, const wchar_t* perfDetail) noexcept;
    void RecordNativeTextInputKeyToStateMetric(
        std::chrono::steady_clock::time_point inputStartedAt, const wchar_t* detail, uint64_t value0, uint64_t value1, bool armPaintMetric = true) noexcept;
    void EmitPendingNativeTextInputPaintMetric(HRESULT hr) noexcept;
    [[nodiscard]] bool HandleNativeTextInputEditMessage(UINT msg, WPARAM wp, LPARAM lp, LRESULT& outResult) noexcept;
    [[nodiscard]] bool HandleNativeTextInputImeMessage(UINT msg, WPARAM wp, LPARAM lp) noexcept;
    [[nodiscard]] Control* HitTestControl(D2D1_POINT_2F pointDip) noexcept;
    [[nodiscard]] WindowHostCursorKind ResolveCursorKindForPoint(D2D1_POINT_2F pointDip) noexcept;
    [[nodiscard]] HCURSOR ResolveCursorHandle(WindowHostCursorKind cursorKind) const noexcept;
    void UpdateHover(D2D1_POINT_2F pointDip, UINT modifiers) noexcept;
    void ClearPendingPointerDoubleClick() noexcept;
    [[nodiscard]] bool ShouldTreatButtonDownAsDoubleClick(Control* target, UINT buttonDownMessage, LPARAM lp) const noexcept;
    [[nodiscard]] bool ShouldTreatPointerDownAsDoubleClick(Control* target, D2D1_POINT_2F pointDip) const noexcept;
    void RememberPointerButtonDown(Control* target, UINT buttonDownMessage, LPARAM lp) noexcept;
    void RememberPointerDownDip(Control* target, D2D1_POINT_2F pointDip) noexcept;
    void UpdateModifierStateForKey(UINT virtualKey, bool keyDown, bool systemKey) noexcept;
    void SetInputModality(InputModality modality) noexcept;
    void SetPointerDevice(PointerDevice device) noexcept;
    [[nodiscard]] D2D1_POINT_2F PointFromLParam(LPARAM lp) const noexcept;
    [[nodiscard]] UINT GetModifierState() const noexcept;
    static bool AnimationTickThunk(void* context, uint64_t nowTickMs) noexcept;
    bool OnAnimationTick(uint64_t nowTickMs) noexcept;

    struct NativeSystemCaret final
    {
        NativeSystemCaret() noexcept = default;
        ~NativeSystemCaret() noexcept;
        NativeSystemCaret(const NativeSystemCaret&)            = delete;
        NativeSystemCaret& operator=(const NativeSystemCaret&) = delete;
        NativeSystemCaret(NativeSystemCaret&&)                 = delete;
        NativeSystemCaret& operator=(NativeSystemCaret&&)      = delete;

        [[nodiscard]] bool Create(HWND ownerHwnd, int widthPx, int heightPx) noexcept;
        [[nodiscard]] bool Show() noexcept;
        void Hide() noexcept;
        void Reset() noexcept;
        [[nodiscard]] bool IsCreated() const noexcept
        {
            return _created;
        }
        [[nodiscard]] int WidthPx() const noexcept
        {
            return _widthPx;
        }
        [[nodiscard]] int HeightPx() const noexcept
        {
            return _heightPx;
        }

    private:
        HWND _ownerHwnd = nullptr;
        bool _created   = false;
        bool _visible   = false;
        int _widthPx    = 0;
        int _heightPx   = 0;
    };

    HWND _hwnd            = nullptr;
    UINT _dpi             = USER_DEFAULT_SCREEN_DPI;
    ThemePalette _palette = MakeDefaultThemePalette(false);

    mutable wil::com_ptr<IDWriteFactory> _dwriteFactory;
    mutable wil::com_ptr<IDWriteTextFormat> _bodyTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _bodyStrongTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _bodyLargeTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _listItemTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _titleTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _subtitleTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _titleLargeTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _displayTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _headerTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _smallTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _iconTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _heroIconTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _iconLargeTextFormat;
    mutable wil::com_ptr<IDWriteTextFormat> _monoTextFormat;
    mutable std::unordered_map<uint64_t, wil::com_ptr<IDWriteTextFormat>> _configuredTextFormats;
    mutable bool _fluentIconFontAvailabilityChecked = false;
    mutable bool _fluentIconFontAvailable           = false;

    wil::com_ptr<ID3D11Device> _d3dDevice;
    wil::com_ptr<ID3D11DeviceContext> _d3dContext;
    wil::com_ptr<ID2D1Factory1> _d2dFactory;
    wil::com_ptr<ID2D1Device> _d2dDevice;
    wil::com_ptr<ID2D1DeviceContext> _d2dContext;
    wil::com_ptr<IDXGISwapChain1> _swapChain;
    wil::com_ptr<IDCompositionDesktopDevice> _dcompDevice;
    wil::com_ptr<IDCompositionTarget> _dcompTarget;
    wil::com_ptr<IDCompositionVisual2> _dcompVisual;
    wil::com_ptr<ID2D1Bitmap1> _targetBitmap;
    D3D_FEATURE_LEVEL _featureLevel           = D3D_FEATURE_LEVEL_11_0;
    UINT _widthPx                             = 0;
    UINT _heightPx                            = 0;
    UINT _swapChainWidthPx                    = 0;
    UINT _swapChainHeightPx                   = 0;
    uint64_t _sharedGraphicsGeneration        = 0u;
    bool _forceFullPresentAfterDeviceRecreate = false;

    mutable std::unordered_map<uint32_t, wil::com_ptr<ID2D1SolidColorBrush>> _brushCache;
    mutable wil::com_ptr<ID2D1SolidColorBrush> _fallbackBrush;
    mutable std::vector<uint32_t> _brushFailureLogKeys;
    // Keep test-only storage unconditional so ControlHost layout stays stable
    // even when ENABLE_TESTS differs between a DxUi producer and consumer.
    bool _debugForceNullSolidBrushes   = false;
    TextInputBackend _textInputBackend = TextInputBackend::Native;
    Control* _nativeTextInputControl   = nullptr;
    uint64_t _nativeTextInputFocusId   = 0;
    std::weak_ptr<int> _nativeTextInputControlLifetime;
    NativeTextInputState _nativeTextInputStateCache;
    bool _nativeTextInputStateCacheValid = false;
    NativeTextInputEventCounters _nativeTextInputEventCounters;
    wil::com_ptr_nothrow<IUnknown> _nativeTextInputTsfThreadMgr;
    wil::com_ptr_nothrow<IUnknown> _nativeTextInputTsfDocumentMgr;
    wil::com_ptr_nothrow<IUnknown> _nativeTextInputTsfPreviousFocusDocumentMgr;
    wil::com_ptr_nothrow<IUnknown> _nativeTextInputTsfContext;
    wil::com_ptr_nothrow<IUnknown> _nativeTextInputTsfTextStore;
    DWORD _nativeTextInputTsfClientId = 0u;
    bool _nativeTextInputTsfActive    = false;
    bool _nativeTextInputImeComposing = false;
    std::optional<size_t> _nativeTextInputCompositionStartIndex;
    std::optional<size_t> _nativeTextInputCompositionEndIndex;
    std::optional<size_t> _nativeTextInputConversionTargetStartIndex;
    std::optional<size_t> _nativeTextInputConversionTargetEndIndex;
    std::optional<size_t> _nativeTextInputCompositionCursorIndex;
    std::vector<size_t> _nativeTextInputCompositionClauseBoundaries;
    std::optional<TextInputState> _nativeTextInputImeBaseState;
    std::optional<NativeTextInputImePayload> _debugNativeTextInputImePayload;
    NativeSystemCaret _nativeTextInputCaret;
    bool _nativeTextInputCaretRectValid      = false;
    D2D1_RECT_F _nativeTextInputCaretRectDip = D2D1::RectF();
    RECT _nativeTextInputCaretClientRectPx{};
    RECT _nativeTextInputCaretScreenRectPx{};
    struct PendingNativeTextInputPaintMetric final
    {
        std::chrono::steady_clock::time_point inputStartedAt{};
        const wchar_t* detail = L"";
        uint64_t value0       = 0u;
        uint64_t value1       = 0u;
    };
    std::optional<PendingNativeTextInputPaintMetric> _pendingNativeTextInputPaintMetric;

    std::unique_ptr<Control> _root;
    TooltipLayer _tooltipLayer;
    mutable uint64_t _debugInvalidateCount                      = 0u;
    uint64_t _debugFocusAnnouncementCount                       = 0u;
    uint64_t _debugFocusMovesLeftToSystemCount                  = 0u;
    uint64_t _debugReactivationAnnouncementCount                = 0u;
    mutable uint64_t _debugRenderCount                          = 0u;
    mutable uint64_t _debugResizeCount                          = 0u;
    mutable uint64_t _debugResizeFailureCount                   = 0u;
    mutable uint64_t _debugSwapChainPrepareD2DFlushFailureCount = 0u;
    mutable uint64_t _debugPresentFailureCount                  = 0u;
    // Non-owning observers into the current retained control tree. Ownership stays with
    // `_root` / `Panel::_children`, so these pointers must be cleared or ignored before
    // the observed tree is replaced or destroyed.
    struct PointerDoubleClickCandidate
    {
        Control* target  = nullptr;
        UINT downMessage = 0u;
        POINT pointPx{};
        uint64_t tickMs = 0u;
    };

    Control* _hoveredControl             = nullptr;
    Control* _capturedControl            = nullptr;
    D2D1_RECT_F _capturedBounds          = {};
    Control* _focusedControl             = nullptr;
    Control* _supplementalTooltipControl = nullptr;
    std::weak_ptr<int> _supplementalTooltipLifetime;
    std::wstring _supplementalTooltipText;
    D2D1_POINT_2F _supplementalTooltipPointDip = D2D1::Point2F();
    Button* _defaultButton                     = nullptr;
    Button* _cancelButton                      = nullptr;
    PointerDoubleClickCandidate _pendingPointerDoubleClick;
    std::shared_ptr<const std::function<bool(bool reverse)>> _onTabBoundary;
    std::shared_ptr<const std::function<bool()>> _onEscape;
    std::shared_ptr<const std::function<void(Control* control)>> _onFocusChanged;
    UINT _modifierState                = 0u;
    InputModality _inputModality       = InputModality::Pointer;
    PointerDevice _pointerDevice       = PointerDevice::Mouse;
    PresentationMode _presentationMode = PresentationMode::HwndSwapChain;
    bool _smokeOverlayVisible          = false;
    std::atomic_bool _detachInProgress{false};
    DWORD _attachmentOwnerThreadId      = 0u;
    uint64_t _animationSubscriptionId   = 0;
    uint64_t _lastAnimationTickMs       = 0;
    bool _animationSuspendedWhileHidden = false;
};

struct TransientSurfaceBackdrop final
{
    void SetCapture(WindowHostBitmapCapture capture) noexcept;
    void Reset() noexcept;
    [[nodiscard]] bool HasCapture() const noexcept;

    WindowHostBitmapCapture capture;
    mutable wil::com_ptr<ID2D1Bitmap1> cachedBitmap;
    mutable wil::com_ptr<ID2D1Device> cachedDevice;
};

struct TransientSurfaceOptions final
{
    float cornerRadiusDip              = 18.0f;
    bool drawShadow                    = true;
    bool pressed                       = false;
    TransientSurfaceBackdrop* backdrop = nullptr;
};

// Canonical material for small owned transient surfaces such as passive status
// popups. The caller owns placement, transforms, opacity, and content; this
// helper owns the shared app-rendered backdrop, fill, border, and shadow policy.
// The popup HWND must keep its DWM system backdrop disabled.
[[nodiscard]] bool CaptureTransientSurfaceBackdrop(const RECT& surfaceScreenRect,
                                                   TransientSurfaceBackdrop& outBackdrop,
                                                   std::wstring_view componentName) noexcept;
void PaintTransientSurface(ControlHost& host, const D2D1_RECT_F& surfaceRect, const TransientSurfaceOptions& options = {}) noexcept;

// Acquires the canonical native root for an attached HWND in this process. The returned COM reference
// belongs to the caller (adopt with wil::com_ptr::attach). Returns null for an invalid/unattached HWND.
// Foreign-thread calls synchronously marshal to the window owner, which must be pumping messages.
// Surviving references remain callable after detach without accessing the retired control tree; keep
// the module containing DxUi mapped for their lifetime. No DxUi C++ object crosses a plugin ABI.
[[nodiscard]] IRawElementProviderFragmentRoot* CreateWindowHostAccessibilityProvider(HWND hwnd) noexcept;

[[nodiscard]] bool RaiseWindowHostAccessibilityNotification(HWND hwnd, std::wstring_view notification, std::wstring_view activityId) noexcept;
} // namespace DxUi
