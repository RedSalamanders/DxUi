# Control guide

All controls below are declared in [DxUi.h](../include/DxUi/DxUi.h), available through
[ControlCatalog.h](../include/DxUi/ControlCatalog.h), and shown in the [gallery](gallery/README.md).
Use `Panel::AddChild<T>(...)` for typed construction or `CreateControl` for catalog-driven construction.
Set bounds, visibility, enabled state and content before preparation. Mutate controls/models on the UI thread.

| Control | Configure and use |
| --- | --- |
| Panel | Own children with `AddChild<T>`; set explicit child bounds. Use as the root for fixed layouts. `GetChildren()` exposes the owning pointers: move a child out to give it to `SetRoot` or `PageHost::SetPage` (its slot stays empty and is skipped) and it is told the flow direction and density its new place gives it. |
| PageHost | Transfer a root with `SetPage(unique_ptr<Control>, connectedAnimationKey)`; the host retains transition state. Advance animation through the containing host. |
| CardPanel | A Panel with themed card chrome; position child bounds in host DIPs, including the card's origin. |
| Label | Construct with text or call `SetText`; choose a font role for headings/body text. |
| Button | Construct with its caption; `SetOnClick` handles activation and `SetOnDropDownClick` handles split-button actions. |
| Toggle | Set initial state with `SetChecked`; handle user intent with `SetOnToggled(bool)`. |
| Checkbox | Uses toggle checked-state/event semantics with checkbox visuals. `SetMultiline(true)` wraps long captions; reserve 36 DIP horizontally for indicator/gaps and 6 DIP vertically around measured Body text. |
| RadioButton | Configure selection state and `SetOnSelected`; use RadioButtons when selection is mutually exclusive. |
| RadioButtons | Own a group of choices and handle `SetOnSelectionChanged(int)`. |
| ProgressBar | Set minimum, maximum and value. `SetIndeterminate(true)` sweeps a segment on host animation ticks; under reduced motion it rests centered and needs no ticks. |
| PageIndicator | Set `SetPageCount` / `SetSelectedIndex` for a bottom strip of dots. `SetOnSelected` reports user clicks and Left/Right/Home/End. Hidden and not hittable when there are fewer than two pages. Strip height is `kStripHeightDip` (20). |
| ThroughputGraph | Feed timestamped samples through its public sample API; keep history within its configured limits. Use the rendering tests for populated series and bands. |
| Slider | Set range/value and handle `SetOnChange(SliderChange)` for preview, commit and cancel. Painted chrome is a 6 DIP track, a 24 DIP gray disc, and an accent inner thumb (14 DIP rest, 20 hover, 16 pressed); while a touch contact drags it, a 48 DIP translucent accent halo shows around the finger (an opaque ring in high contrast). Embedded hosts pass the contact's `PointerEvent::device` for it. Pointer hit testing is an unpainted 48 DIP band; a press within 24 DIP of the thumb center drags, otherwise the track seeks. Capture keeps dragging outside the bounds; cancellation restores the starting value. Hover, press and keyboard steps animate; `SetValue` snaps even when acknowledging the same target. Non-finite ranges, values and steps are ignored. |
| Toolbar | Panel for command controls; populate buttons with labels, bounds and actions. |
| MenuBar | Supply `MenuBarItem` records through `SetItems`; handle `SetOnOpenItem` and hover changes. Native menu operations require the HWND integration. While a bar item's menu runs in a modal `ContextMenu::Show`, a hover change calls `ContextMenu::PostMenuBarHover`, and the session's `switchRootFromMenuBarHover` returns the hovered item's menu. |
| TabControl | Add populated tab pages with `AddTab`; handle selection, close-request, closed and reorder callbacks as needed. |
| ColorSwatch | Configure the displayed color and handle `SetOnClick` to launch your color selection flow. |
| TextField | Set text/editing options; handle `SetOnTextChanged`, `SetOnSubmitted` and `SetOnBlur`. Full IME/native text behavior needs the appropriate host bridge. A multiline field draws its caret only inside its text viewport: on a partly visible line it is cut at the viewport's edge, and scrolled out of view it is not drawn. |
| ComboBox | Supply `Item` records with `SetItems`; use `SetOnSelectionChanged`, text/submission callbacks and popup requests for editable selection. For touch, call `SetMinimumPopupItemHeight(48.0f)`; the gallery Modern open variant uses it. |
| TagPicker | Call `SetOptions(allLabel, values)`, `SetSelectedValues` and `SetOnSelectionChanged` for multiple named choices. |
| StatusStrip | Use `SetText` for one value or `SetSections` and `SetSectionText` for multiple aligned status values. |
| PopupLayer | A Panel for overlay content; populate real children and control its visibility/lifetime with the owning host. |
| StackPanel | Set orientation, gap and padding; call `SetChildExtent` for every child and `ApplyLayout` after content or bounds changes. |
| ScrollPanel | Own a content tree, set the content extent, and handle `SetOnScrollChanged` if needed. It clips and translates pointer coordinates into content space. |
| TooltipLayer | Usually managed through `ControlHost::SetTooltip`, `SetTooltipDelayed`, hide-delay and `ClearTooltip`; delayed behavior needs host ticks. |
| Tree | Supply a borrowed `ITreeModel`, optional `ITreeDelegate`, then `NotifyDataChanged` when data changes. Use stable IDs for selection/expansion. `iconText` in the private-use range uses the icon font; letters and symbols keep the UI font. `SetReorderEnabled` reports one `OnTreeReorder` per row drag (never into the row's own subtree); the tree does not move your model, and a keyboard reorder command is yours to provide. `SetMultiSelectEnabled(true)` (off by default, which keeps the single selection exactly as it was) selects several items: click selects one and sets the anchor, Ctrl+click toggles, Shift+click (or Shift with a movement key) selects the visible range from the anchor, Ctrl with a movement key moves the focus alone, Ctrl+Space toggles the focused item and Ctrl+A selects every visible row. `GetSelectedItemIds` lists the selection in visible order (`GetSelectedItemId` stays the focused item, which need not be selected), `OnTreeSelectionSetChanged` reports each change of the set once, and the selection survives `NotifyDataChanged` except for rows that are no longer visible (removed, or hidden by a collapse). A drag of a selected row reports that row alone and leaves the selection intact, so your `OnTreeReorder` may move every id in `GetSelectedItemIds` when the source is one of them. UI Automation reports `CanSelectMultiple`, and every change of the selection, single or multiple and from a gesture or your silent setters, raises its [selection events](../Specs/UI/UI_InputAndAccessibility.md#selection-events) to screen readers: `ElementSelected` for an item that became the selection, `ElementAddedToSelection`/`ElementRemovedFromSelection` otherwise, with each item's `IsSelected` change, and one `Selection_Invalidated` past 20 items or for an item that left the tree, unless one item became the whole selection, whose `ElementSelected` says the others left. |
| Grid | Supply a borrowed `IGridModel` and optional `IGridDelegate`; configure columns, row height and selection. Call `NotifyDataChanged` after model changes. A change of the selected rows (a click, the keys, Ctrl+A, UI Automation, or `GetSelectionModel()` changes you publish with `NotifyDataChanged` or `RefreshAccessibilitySnapshot`) raises the [selection events](../Specs/UI/UI_InputAndAccessibility.md#selection-events) from the rows, as a tree's items do. Rows out of view have no element: a change that would name one that left the selection is one `Selection_Invalidated` of the grid, unless one row became the whole selection, whose `ElementSelected` says the others left. |
| Splitter | Size it over both panes, choose `SetOrientation`, set the pane minimums and `SetPosition`, then place your pane controls from `GetFirstPaneBounds` / `GetSecondPaneBounds` inside `SetOnChange(SplitterChange)` (preview while dragging, commit on release or keyboard, cancel on Escape or capture loss). Only the separator plus 2 DIP is hittable; the position you persist is your state. In an EmbeddedHost apply the pane bounds on your next Prepare rather than inside the callback, or the bounds change cancels the drag on the next pointer event. |
| NumericStepper | Set range, `SetStep` / `SetLargeStep`, `SetDecimals`, an optional `SetLabel` / `SetUnit` with widths, and handle `SetOnChange(NumericStepperChange)`: typing previews, Enter, focus loss, the buttons and Up/Down (Shift: large step) commit, Escape cancels, and an edit whose text no longer parses reverts with a cancel. `SetValue` is silent. The step buttons are named "Increase" / "Decrease" for UI Automation; supply localized names with `SetStepButtonNames`. Preferred height is `kDefaultHeightDip` (32). |
| ColorPicker | Size it to `kDefaultWidthDip` x `kDefaultHeightDip` (316 x 236), supply captions through `SetLabels`, open it with `SetColor` and handle `SetOnChange(ColorPickerChange)`. Feed eyedropper results through `SampleColor`; OK or Enter commit, Cancel or Escape restore the current color. For translated captions set `Labels::channelLabelWidthDip`, `hexLabelWidthDip` and `swatchWidthDip` (up to 4,096 DIPs; widen the picker for wider swatches), and name the channel step buttons with `Labels::increaseRed` … `decreaseBlue` (whole phrases). |

The selection-event exception described above has one current limitation: replacing a large selection with
one new item still emits `Selection_Invalidated` when more than 20 items change. The implementation applies
that bound before the exactly-one replacement rule. Its priority remains an open decision in
[Q14 of the review plan](../Specs/Plans/WIP/ProductionReview_2026-10-05.md#questions-for-the-developer).

## Described native menu entries

Described menus support `MenuFlyoutItem::secondaryText` for Standard, Toggle, Radio and Info entries.
The [menu description plan](../Specs/Plans/WIP/MenuDescriptions_2026-09-21.md) keeps consumer qualification open.
The primary label and secondary field wrap independently at the available width; the row grows,
and a constrained menu scrolls. Secondary text is literal Unicode. Primary text keeps existing
mnemonic rules: double an ampersand to display it literally. Do not use the shortcut column for
parent locations or other descriptive text.

Supply `accessibleName` when the complete spoken identity differs from the displayed fields.
Otherwise UIA exposes the decoded primary label, followed by its secondary text when there is one. Every entry
of every menu popup (root or submenu, described or not) is a UIA element: MenuItem/Invoke for commands and the
acknowledged checked state, and a row scrolled out of view reports `IsOffscreen` until UIA focus scrolls it in.
A menu opened by the pointer starts without a keyboard selection. Command IDs remain
the selection authority; repeated primary labels are supported. Description layout is prepared on
open/DPI reflow and reused during paint. Queued invocations expire with that popup instance. The elements cost
memory and time in every menu, screen reader or not, and more in a long menu: see the
[measurement](../Measurements/PlainMenuUia/2026-10-02/README.md).
A described row holds one native text layout for both fields (the label, a spacer paragraph and the
description), which costs one layout's shaping storage where two layouts cost two; the description starts a fixed
gap below the label as before. Commands and accessible names stay independent of it, and scrollbar/DPI reflow
preserves each row's final available width.

Normal dismissal delivers the completion callback and restores the prior owner control as applicable.
If the process/thread exits with an asynchronous menu still open, controller teardown releases its
capture and windows without invoking application completion callbacks or re-entering finalization.
A described menu's layouts and accessibility proxies exist only while it is open; closing returns them.

While any menu is open the arrow cursor shows over its popups, whatever cursor the window had set. Outside them a
window of the menu's thread chooses its own cursor through its usual `WM_SETCURSOR` handling, and chooses again as
soon as the menu closes; other threads' windows show the arrow.

```cpp
DxUi::MenuFlyoutItem item;
item.kind = DxUi::MenuItemKind::Radio;
item.text = L"Archives familiales";
item.secondaryText = L"D:\\Photographies\\Exposition annuelle";
item.accessibleName = L"D:\\Photographies\\Exposition annuelle\\Archives familiales";
item.commandId = 42;
```

Existing one-line entries keep their layout. Header, Separator and Slider descriptions are not
supported. This native popup capability adds no new catalog control or embedded popup window.
Application destination eligibility, path formatting and final platform/AT adoption remain consumer work.
The [original menu measurements](../Measurements/MenuDescriptions/2026-09-21/README.md)
separate open-menu layout/accessibility cost and screenshot buffers. The
[30 September paired follow-up](../Measurements/MenuDescriptions/2026-09-30/paired-local/README.md)
resolved the repeated common-scene memory flag and removed its waiver. The
[performance contract](../Specs/Core/Core_PerformanceAndResources.md#described-menu-clean-private-memory)
records that evidence and the separately accepted cost of plain-menu accessibility. Consumer platform/input/AT
qualification remains open in the menu description plan.

## Editable values

```cpp
auto* slider = root->AddChild<DxUi::Slider>();
slider->SetMinimum(0);
slider->SetMaximum(100);
slider->SetValue(65);
slider->SetOnChange([&model](DxUi::SliderChange change) {
    model.preview = change.value;
    if (change.phase == DxUi::SliderChangePhase::Commit) {
        model.Commit(change.value);
    }
    // Cancel carries the restored value; update the displayed draft without committing it.
});
```

Keep preview separate from durable application commands. An asynchronous backend acknowledgement is separate from
local intent. Keep model/callback captures alive, and do not reuse borrowed control pointers after root replacement.
The [embedded scene](../Samples/EmbeddedControls/EmbeddedScene.h) is a complete typed event example;
[embedded tests](../Tests/Embedded/Embedded.Tests.Embedded.cpp) cover drag cancellation and root changes during callbacks.

## Layout and data-backed controls

For a localized action group, measure each label with the current host font, add the desired padding
and minimum target size, then call `ArrangeMeasuredActions` with those sizes, available DIP width,
horizontal/vertical gaps and caller-owned output rectangles. The helper allocates nothing, preserves
input order, wraps whole actions and returns total height/row count. It supports right-to-left flow.
An omitted `{0,0}` size produces an empty rectangle without changing indices. Invalid inputs,
insufficient output space and arithmetic overflow leave all outputs unchanged.

An individual size must fit the available width. Measure overlong text wrapped first; standard
`Button::SetMultiline(true)` enables matching wrapped paint with 12 DIP horizontal and 8 DIP vertical
padding on each side. Checkbox also honors this inherited option, using its own indicator/text geometry described above. The default is false, preserving existing single-line behavior. Other button
variants retain their existing text/chrome policy. The helper does not choose actions, mutate focus,
activate a host or cache application state. Cache measurements in your layout owner and recompute on
text/font/DPI/width/visibility changes; apply the returned rectangles consistently to paint/input/UIA.
At short height, reserve the action group's measured height and scroll the remaining body separately.

A Button with `SetDisclosureExpanded(bool)` exposes UIA ExpandCollapse as well as Invoke. Repeated
requests for the already acknowledged state do nothing. A changed request invokes the normal click
callback; the application updates the state, content visibility and focus. `GetDisclosureExpanded()`
returns that acknowledged optional state; `ClearDisclosureState()` removes the pattern. Disabled
buttons reject UIA state changes. The chevron's rotation starts at its first animation tick, so a state changed while
the button (or its panel) is hidden rotates when it is shown again, and a pause in the ticks pauses the rotation.
Embedded hosts publish the new snapshot after preparation, using
their existing accessibility update path. Retained providers disconnect when their control is removed.

```cpp
auto* stack = root->AddChild<DxUi::StackPanel>();
stack->SetBounds(D2D1::RectF(16, 16, 320, 160));
stack->SetOrientation(DxUi::StackOrientation::Vertical);
stack->SetGap(8);
auto* caption = stack->AddChild<DxUi::Label>(L"Name");
auto* field = stack->AddChild<DxUi::TextField>();
stack->SetChildExtent(caption, 24);
stack->SetChildExtent(field, 36);
stack->ApplyLayout();
```

Grid and Tree borrow model/delegate pointers; retain these until the controls are destroyed or pointers are cleared.
Native accessibility publishing can dispatch messages during UI Automation event delivery and replace the controls.
Tree and Grid stop their selection handlers when that destroys them; Tree also skips the pending selection-set
delegate after a model-change publish destroys it. Tree's `RequestSelectVisibleItem`, `RequestAddVisibleItemToSelection`
and `RequestRemoveVisibleItemFromSelection` return false when the tree did not survive them. Do not reuse a borrowed
control pointer after such a publish.
You may rebuild or replace the controls from the host's focus-changed callback, or from a grid's or a tree's selection
delegate: a control that focused itself, and a selection made by a click, a key (collapsing the group of a selected
grid row included), UI Automation or a model change (`NotifyDataChanged`, `SetModel`, a grid's `SetSelectionMode`, or a
checkbox toggle whose model change moves the selection), touches nothing of a control the callback destroyed.
Grid also stops after checkbox, group and sort delegates replace its model or destroy it. Group-layout requests resolve
each remaining group by stable ID after callbacks. Never reuse the old sender pointer after replacing its tree.
Grid keyboard ranges remember their moving endpoint independently of the ordered selection, so repeated Shift+Up
shrinks or extends the range correctly. Switching to single selection keeps that endpoint when it is selected.
Grid models provide row/column counts, column descriptors, cell data and stable-row lookup. Tree models provide
the visible item sequence with IDs, depth and expansion state. Supply actual populated data, stable identity and
notifications; a factory-created empty control does not demonstrate interaction.
For multiline grid summaries, set `GridCellData::multiline`, a suitable row height, and
`Grid::SetLineClamp`. The grid displays complete measured lines and marks omitted content with
an ellipsis, including explicit paragraphs; trailing line breaks are not content. A row too short
for one line still shows its first line, clipped like a single-line cell. Viewport clipping keeps
text placement stable. Copy and accessibility still expose the full model value, and hovering
shows it as a tooltip whenever lines are omitted or clipped; provide a complete detail view when
the summary alone is insufficient. The gallery includes a long French summary. Each visible value keeps its shaped
layout between paints (a repaint of unchanged cells shapes nothing, scrolling either way shapes only the rows that
enter), a very long value shapes only what it can show, wrapped or on one line (a whole right-to-left line is the
exception: its order depends on all of it), and is retained by that part, so repainting or hovering it shapes nothing.
The omission marker ends right-to-left text at its left end, an emoji at the end included, and trailing lines of other
spaces or invisible characters add nothing. Single-line cells keep their layouts the same way (a repaint shapes
nothing, a scroll shapes the entering row), and a long leading-aligned caption shapes only what its cell can show.
A grid keeps its layouts only while it paints: hidden (itself, under a hidden panel or tab page, or in a hidden
embedded view), removed from its host or given another model, it returns them all, and showing it shapes only the cells
it then shows.
See [the benchmark model](../Samples/ComplexUi/ComplexUiScene.h),
[grid tests](../Tests/Controls/DxUi.Tests.Grid.cpp), [tree tests](../Tests/Controls/DxUi.Tests.Tree.cpp), and
[gallery construction](../Tests/Controls/DxUi.Tests.Gallery.cpp) for concrete configurations and variants.

When overriding `OnFocusChanged` in a derived control, call the base implementation before
handling application-specific detail. It acknowledges `HasFocus`, which drives visible focus and
UIA keyboard-focus properties. Test both the provider state and the painted focus outline.

Use keyboard/focus, cancellation, disabled and hidden states alongside pointer input. Verify high contrast,
Unicode, DPI and minimum layout bounds. Consult [hosting](hosting.md) for the embedded text/UIA limitations.

`ComboBox::SetMinimumPopupItemHeight` takes a per-instance DIP minimum for popup row painting, hit testing,
scrolling and keyboard visibility. Zero restores the theme default. Finite values from 0 through 4096 are accepted;
invalid values leave the setting unchanged. `GetMinimumPopupItemHeight` returns the configured minimum, not the
effective theme height. The field bounds are independent and should also meet the consumer's touch minimum.
The popup shows fewer complete rows when space is limited and can open above the field; it does not shrink rows.
Hosts must provide space on at least one side for a full row and the popup padding, or open the selector in a larger view.

In high contrast, primary Buttons use the exact opaque selection color pair for idle, hover, pressed and focused
states. Disabled Buttons retain a border with the disabled text color; focus is visible for pointer and keyboard.
Embedded surfaces are transparent by default: consumers needing an opaque application background must paint it
from their theme in their root panel before painting the child controls.

[Primary-button contrast validation](https://github.com/RedSalamanders/DxUi/blob/1947a5b91beb029e9b99d71e0893c6075bbb29ca/docs/measurements/primary-high-contrast-2026-09-05/README.md) records the native suites, gallery and matched performance evidence.

For localized empty states, call `combo.SetNoMatchesText(L"Aucun résultat")`,
`tree.SetEmptyStateText(L"Aucune donnée")`, or `grid.SetEmptyStateText(...)` with your product's
resource strings. The controls own the supplied text. Reapply it when the language changes;
an empty string restores the English default. An open ComboBox popup updates its width.

## Tree multi-select

```cpp
class LayersPanel final : public DxUi::ITreeDelegate
{
public:
    // The focused row moved (a click, a key, typeahead or UI Automation). With multi-select it may be outside the selection.
    void OnTreeSelectionChanged(uint64_t itemId) override { _activeLayer = itemId; }
    // The selection changed, once per change: `ids` are the selected rows in visible order, valid during the call.
    void OnTreeSelectionSetChanged(std::span<const uint64_t> ids) override { _selected.assign(ids.begin(), ids.end()); }
    // One row was dragged; the tree moves nothing. When it belongs to the selection the drop may move them all.
    void OnTreeReorder(const DxUi::TreeDrop& drop) override
    {
        const std::vector<uint64_t> selection = _tree->GetSelectedItemIds();
        const bool wholeSelection             = std::ranges::contains(selection, drop.sourceId);
        MoveLayers(wholeSelection ? selection : std::vector<uint64_t>{drop.sourceId}, drop.targetId, drop.place);
        _tree->NotifyDataChanged(); // The selection follows the ids, in their new order.
    }
    // ...
};

tree->SetModel(&layers);
tree->SetDelegate(&panel);
tree->SetReorderEnabled(true);
tree->SetMultiSelectEnabled(true);
```

Enabling multi-select changes nothing else about a tree: until then every modifier is ignored and no set callback is made.
The focused row and the selection are separate, so a command reads `GetSelectedItemIds`, not `GetSelectedItemId`. A press
with Ctrl or Shift never starts a drag; a press on a row of a multi-selection keeps the selection until the release, so the
drag can carry it. After a model change call `NotifyDataChanged`: selected rows that are no longer visible leave the
selection (a collapsed group deselects the rows it hides, and expanding it does not reselect them). `SetSelectedItemIds`
restores a selection without a callback. The selection is a `GridSelectionModel`, so Ctrl+click, Shift+click and Ctrl+A
follow Grid; Ctrl with a movement key moves the focus and Ctrl+Space toggles it, as in a list view. The
[gallery](gallery/README.md) shows a tree with several rows selected, and the [tree tests](../Tests/Controls/DxUi.Tests.Tree.cpp)
cover each gesture.
Host navigation keys leave an empty tree selection alone. A multi-row drag rejects selected targets and descendants
of every selected row. Public Tree/Grid selection and expansion/toggle requests reject disabled controls.

PageHost pages inherit density and flow direction through their PageHost, including later changes to its ancestors.
Panel, PageHost and tab layout revalidate children after mutation callbacks. `AddChild`/`AddTab` return null if a
callback retires their owner or the new child. `ClearChildren` clears the children owned at entry; reentrant additions
remain in the live panel.
Explicit page overrides still take precedence. A child promoted to the host root snapshots its previous inherited
values before reset callbacks can retire its old parent. Overlay dismissal stops traversing a retired container.

Callbacks may replace their own registration or rebuild the controls. DxUi retains the registered callable without
copying its mutable state. It releases the dispatch snapshot before checking whether an input continuation can
proceed: final captured-resource cleanup may also retire the sender. Failed allocation of replacement callback storage
keeps the prior registration installed. Rebuild consumers with matching headers and DxUi.lib. TagPicker selection callbacks receive a
snapshot valid throughout that call, including after replacement of the picker. Copy values you need afterward;
the notification does not extend the sender's lifetime.
If solid-brush creation and its fallback fail, painting omits the affected primitive and can recover on a later frame.
