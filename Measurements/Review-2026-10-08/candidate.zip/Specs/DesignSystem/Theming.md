# Feeding the palette from an application theme

Inactive Tree/Grid selections check their text contrast against the alpha-composited fill, retaining a configured
ink when it reaches 4.5:1 and falling back to measured black/white otherwise. High contrast keeps HighlightText.
The focused selected Tree row uses a ring contrasting with its resolved fill, including rainbow tints.

DxUi owns no theme files, theme keys or settings. An application resolves its own theme and hands DxUi colors through one of two adapters. Everything in this system is expressed in `ThemePalette` roles so that either path can be checked against it.

## Path A: `ThemeColors` → `MakeThemePalette`

Supply 11 colors and 4 flags; DxUi derives every other role.

| `ThemeColors` field | Becomes |
| --- | --- |
| `backgroundArgb` | `windowBackground`; the source of `surfaceBackground`, `headerBackground`, `border`, `gridLine`, `inputFill`, `buttonFill` blends |
| `textArgb` | `text`; the source of `subduedText`, `disabledText`, scrollbar and border blends |
| `selectionBackgroundArgb` / `selectionTextArgb` | `selectionFill` / `selectionText`; the source of `focusStroke`, `hoverFill`, `pressedFill`, header and button state blends |
| `accentArgb` | `accent`, then `accentHover` / `accentPressed` by Oklab lightness |
| `alertInfo*`, `alertWarning*`, `alertError*` | `infoFill`/`infoText`, `warningFill`/`warningText`, `errorFill`/`errorText`; a supplied pair is used as given. A zero-alpha value, including the zero default, means none was supplied: that color takes the tone's Light or Dark default (distinct, readable tones), or `text` on `windowBackground` with `highContrast`; half a pair gets a partner that keeps 4.5:1 as painted (the tone's or theme's color when it does, else black or white by measured contrast; a translucent supplied fill is measured over `windowBackground`) |
| `darkMode` | selects the Light or Dark defaults for roles the derivation does not touch |
| `darkBase` | chooses every light-versus-dark blend weight in the derivation |
| `highContrast` | stronger hover/press washes, opaque inactive selection, focus strokes from `text` / `windowBackground` |
| `rainbowMode` | per-item hue tints in lists and menus |

The seven `diff*Argb` fields are accepted but **not read** by `MakeThemePalette`; no DxUi control paints a diff color. Diff views stay application-owned.

## Path B: start from `MakeDefaultThemePalette(dark)` and override roles

An application may write roles directly, as RedSalamander's main window does. Then the roles it does not write keep the library defaults of this system, whatever the application's colors are:

- `cardBackground`, `smokeOverlay`, `borderDefault`, `borderStrong`, `overlayBorder` (unless written)
- `toggleKnobFill`, `toggleKnobCheckedFill`, `pressedFill`
- `focusStrokeOuter`, `focusStrokeInner`
- `tooltipBackground`, `tooltipText`

When overriding, write every role in the same family (all grounds, all borders, all text) or derive the missing ones with the same blends as Path A. Call `RefreshAccentVariants` after changing `accent`.

## Rules for either path

- **Set `dark` and `darkBase` from the resolved colors, not from the theme's name or base.** A custom theme with dark grounds built on a light base otherwise gets light-theme knobs, tooltips, borders and blend weights. Decide by the luminance of the resolved `windowBackground`.
- **Accent**: applications normally pass the Windows accent (`DwmGetColorizationColor`). `#0078d6` is only the library default.
- **Windows high contrast**: take grounds, text and selection from `GetSysColor` (`COLOR_WINDOW`, `COLOR_WINDOWTEXT`, `COLOR_HIGHLIGHT`, `COLOR_HIGHLIGHTTEXT`, `COLOR_GRAYTEXT`) and set `highContrast`. System palettes have no alert colors, so applications commonly map all three severities to the highlight pair — which makes them identical — or supply none and get `text` on `windowBackground`. Status in DxUi therefore MUST always carry a word or glyph. Outside high contrast, supplying none keeps the default tones.
- **App high contrast** is a normal theme with `highContrast` set, for example the gallery's black / white / `#003b80` / yellow input used for this system's High contrast values. Its alert pairs are whatever the application supplies. The gallery supplies none, so its high-contrast sheet shows the `text` on `windowBackground` fallback.
- **Rainbow** is a flag, never a palette. Keep a fixed per-application seed so hues are stable across sessions.
- **Derived contrast** uses measured linear WCAG luminance: `ChooseContrastingTextColor` returns pure black or white,
  whichever contrasts more with the painted fill. Composite translucent fills over their actual ground first. This
  governs derived tooltip text, toggle knobs, rainbow popup text and tag text; it does not override supplied text colors.
- **Fonts** are not theme data. Themes change colors only; type roles and the Segoe UI Variable / Fluent Icons / Consolas families stay fixed.
