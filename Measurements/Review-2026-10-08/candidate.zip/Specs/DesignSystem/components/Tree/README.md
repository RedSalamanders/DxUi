# Tree

Hierarchical list over a borrowed model with expand/collapse, badges and optional multi-select.

- **Consumer supplies**: a borrowed `ITreeModel`, optional `ITreeDelegate`, stable IDs for selection/expansion; `NotifyDataChanged` when data changes. For several selected rows, `SetMultiSelectEnabled(true)`, then read `GetSelectedItemIds` (visible order) and handle `OnTreeSelectionSetChanged`.
- **Metrics**: row 28, indent 16; badges min 28×16, max height 18, padding 16. Expander 240 ms, expansion 320 ms.
- **Colors**: selected rows `selectionFill`/`selectionText`, unfocused `selectionInactiveFill`, hover `hoverFill`; rainbow mode tints rows by a stable hash. Inactive text keeps `text` when it reaches 4.5:1 against the composited row fill, otherwise uses the more contrasting pure black or white. High contrast keeps the supplied `selectionText` exactly.
- **Multi-select** (off by default; a tree that never enables it is unchanged): every selected row takes the selection colors, and only the focused row draws a 1 DIP ring inset 1.5 DIP, even when it is not selected. The ring keeps `focusStroke` when it contrasts with the resolved painted fill, falling back to the more contrasting pure black or white; high contrast uses `selectionText` on selected rows. Click selects one row and sets the anchor, Ctrl+click toggles, Shift+click (or Shift with a movement key) selects the visible range from the anchor, Ctrl with a movement key moves the focus alone, Ctrl+Space toggles the focused row and Ctrl+A selects every row. A right-click on a selected row keeps the selection. A reorder drag still names one row, and a press with Ctrl or Shift never starts it.

The preview shows the default palette's resolved contrast colors. Custom fills, alpha and rainbow tints are resolved by the native control. This is a static HTML rendition styled by `bundle.css`; the gallery captures under Assets › Gallery are the authoritative rendering.
