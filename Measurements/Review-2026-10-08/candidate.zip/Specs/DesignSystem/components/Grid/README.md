# Grid

Virtualized multi-column data grid over a borrowed model.

- **Consumer supplies**: a borrowed `IGridModel`, optional `IGridDelegate`, columns, row height, selection; call `NotifyDataChanged` after model changes.
- **Metrics**: row 28, group header 28, header 32, icon 18; Compact density scales by 0.82. Sort glyph animates 140 ms.
- **Colors**: header `headerBackground`; lines `gridLine`; selected `selectionFill`/`selectionText`, unfocused `selectionInactiveFill`, hover `hoverFill`. Inactive text keeps `selectionText` when it reaches 4.5:1 against the composited row fill, otherwise uses the more contrasting pure black or white. High contrast keeps the supplied `selectionText` exactly. Status badges and toned rows pair `infoFill`/`infoText`, `warningFill`/`warningText`, `errorFill`/`errorText` — always with a word, never color alone. Without supplied alert colors they keep the default tones, or read as `text` on `windowBackground` in high contrast.
- **Multiline text**: set `GridCellData::multiline`, a row height and `SetLineClamp`. Only complete measured lines paint and omitted content ends with an ellipsis right after the last visible character; trailing line breaks are not content. A row too short for one line shows its first line clipped to the text area. A partly scrolled row clips without reflow. Copy and UIA always carry the full value; hovering shows it as a tooltip whenever lines are omitted or clipped.

The preview shows the default palette's resolved contrast colors. Custom fills, alpha and rainbow tints are resolved by the native control. This is a static HTML rendition styled by `bundle.css`; the gallery captures under Assets › Gallery are the authoritative rendering.
