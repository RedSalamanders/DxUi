[CmdletBinding()]param([Parameter(Mandatory)][string]$StepsFile)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
function Get-Middle([double[]]$Numbers){[Array]::Sort($Numbers);$n=$Numbers.Length;return ($Numbers[[int]($n/2-1)]+$Numbers[[int]($n/2)])/2}
function Assert-Near([double]$Actual,[double]$Expected,[string]$Context){if([math]::Abs($Actual-$Expected)-gt 1e-8*[math]::Max(1,[math]::Abs($Expected))){throw "Independent numeric mismatch: $Context ($Actual vs $Expected)"}}
$steps=@(Get-Content -LiteralPath $StepsFile -Raw|ConvertFrom-Json)
if($steps.Count-ne 5-or @($steps.repository|Sort-Object -Unique).Count-ne 5){throw 'Expected five distinct completed owners'}
$verified=foreach($step in $steps){
 if($step.exitCode-ne 0-or $step.analysisExitCode-ne 0){throw "Pipeline failed: $($step.repository)"}
 $study=$step.study
 $plan=Get-Content -LiteralPath (Join-Path $study 'plan.json') -Raw|ConvertFrom-Json
 $complete=Get-Content -LiteralPath (Join-Path $study 'complete.json') -Raw|ConvertFrom-Json
 $comparison=Get-Content -LiteralPath (Join-Path $study 'comparison-reviewed.json') -Raw|ConvertFrom-Json
 if($comparison.analysisRevision-cne 'double-holm-v2'){throw 'Reviewed statistics revision required'}
 $samples=@(Get-Content -LiteralPath (Join-Path $study 'samples.json') -Raw|ConvertFrom-Json)
 $expected=if($step.repository-eq 'RedTilde'){100}else{50}
 if(-not $complete.passed-or -not $complete.harnessVerified-or -not $complete.closureVerified-or $plan.blocks-ne 12-or $comparison.blocks-ne 12-or $samples.Count-ne $expected-or $complete.sampleCount-ne $expected){throw 'Invalid completed native inventory'}
 $scenarios=@($samples.scenario|Sort-Object -Unique)
 foreach($scenario in $scenarios){
  $members=@($samples|Where-Object scenario -ceq $scenario)
  $warm=@($members|Where-Object block -eq -1)
  if($warm.Count-ne 2-or @($warm.side|Sort-Object -Unique).Count-ne 2){throw 'Warmup inventory mismatch'}
  for($block=0;$block-lt 12;++$block){
   $actual=@($members|Where-Object block -eq $block)
   $sequence=if($block%2){'B1,A1,A2,B2'}else{'A1,B1,B2,A2'}
   if(($actual.position-join ',')-cne $sequence){throw 'ABBA/BAAB schedule mismatch'}
  }
 }
 foreach($sample in $samples){
  if($sample.exitCode-ne 0){throw 'Failed native process in completed study'}
  $receipt=Get-Content -LiteralPath (Join-Path $sample.path 'receipt.json') -Raw|ConvertFrom-Json
  if(($sample.metrics|ConvertTo-Json -Compress)-cne ($receipt.metrics|ConvertTo-Json -Compress)){throw 'Sample disagrees with native process receipt'}
  $raw=@{}
  switch($step.repository){
   DxUi{$native=Get-Content -LiteralPath (Join-Path $sample.path 'native.json') -Raw|ConvertFrom-Json;foreach($phase in $native.scenarios){foreach($pair in @(@('FrameP50Ms','frameP50Ms'),@('PrivateBytes','privateBytes'))){$values=[double[]]@($phase.rounds.($pair[1]));[Array]::Sort($values);$raw[$phase.name+$pair[0]]=$values[[int][math]::Floor($values.Length/2)]}}}
   RedTilde{$native=Get-Content -LiteralPath (Join-Path $sample.path 'native.json') -Raw|ConvertFrom-Json;foreach($key in 'commandUs','ownerCpuCycles','completedEditUs','cleanCompletedUs'){$raw[$key]=Get-Middle ([double[]]$native.samples.$key)};foreach($key in 'privateBytes','workingSetBytes'){$raw[$key]=[double]$native.final.$key}}
   RedPrism{$out=Get-Content -LiteralPath (Join-Path $sample.path 'stdout.log') -Raw;$line=@($out-split "`n"|Where-Object {$_-like 'UI BENCH name=sampler-accepted-prefix *'})[0];$raw.elapsedMedianUs=[double]::Parse([regex]::Match($line,'elapsedMedianUs=([0-9.]+)').Groups[1].Value,[cultureinfo]::InvariantCulture)}
   RedXe{$out=Get-Content -LiteralPath (Join-Path $sample.path 'stdout.log') -Raw;$line=@($out-split "`n"|Where-Object {$_-like 'SystemData Release row-cap measurement:*'})[0];foreach($key in @(@('wallUsPerCollection','wall_us_per_collection'),@('cpuUsPerCollection','process_cpu_us_per_collection'))){$raw[$key[0]]=[double]::Parse([regex]::Match($line,('\b'+$key[1]+'=([0-9.eE+-]+)')).Groups[1].Value,[cultureinfo]::InvariantCulture)}}
   RedSalamander{[xml]$trx=Get-Content -LiteralPath (Join-Path $sample.path 'native.trx') -Raw;foreach($test in $trx.SelectNodes('//*[local-name()="UnitTestResult"]')){if($test.outcome-cne 'Passed'){throw 'Native TRX failed'};$raw[$test.testName+'Ms']=[TimeSpan]::Parse($test.duration,[cultureinfo]::InvariantCulture).TotalMilliseconds}}
  }
  foreach($key in $raw.Keys){Assert-Near $sample.metrics.$key $raw[$key] "raw/$($step.repository)/$key"}
 }
 $recomputed=foreach($row in $comparison.rows){
  $selected=@($samples|Where-Object {$_.scenario-ceq $row.scenario-and $_.block-ge 0})
  $before=[double[]]@($selected|Where-Object side -ceq 'baseline'|ForEach-Object {$_.metrics.($row.metric)})
  $after=[double[]]@($selected|Where-Object side -ceq 'candidate'|ForEach-Object {$_.metrics.($row.metric)})
  Assert-Near $row.baselineMedian (Get-Middle $before) 'before median'
  Assert-Near $row.candidateMedian (Get-Middle $after) 'after median'
  $deltas=foreach($block in 0..11){$members=@($selected|Where-Object block -eq $block);$a=@($members|Where-Object side -ceq 'baseline');$b=@($members|Where-Object side -ceq 'candidate');[math]::Log(([double]$b[0].metrics.($row.metric)*[double]$b[1].metrics.($row.metric))/([double]$a[0].metrics.($row.metric)*[double]$a[1].metrics.($row.metric)))/2}
  Assert-Near $row.pairedChangePercent (100*([math]::Exp(($deltas|Measure-Object -Average).Average)-1)) 'paired block ratio'
  $assignments=@(0.0)
  foreach($delta in $deltas){$assignments=@(foreach($value in $assignments){$value+$delta;$value-$delta})}
  $threshold=[math]::Abs(($deltas|Measure-Object -Sum).Sum)-1e-12
  $p=@($assignments|Where-Object {[math]::Abs($_)-ge $threshold}).Count/[double]$assignments.Count
  Assert-Near $row.p $p 'exact sign flip'
  [pscustomobject]@{row=$row;p=$p}
 }
 $ranked=@($recomputed|Sort-Object p);$last=0.0
 for($i=0;$i-lt $ranked.Count;++$i){$last=[math]::Min(1.0,[math]::Max($last,$ranked[$i].p*($ranked.Count-$i)));Assert-Near $ranked[$i].row.adjustedP $last 'Holm adjustment'}
 [ordered]@{repository=$step.repository;study=$study;nativeProcesses=$samples.Count;metrics=$comparison.rows.Count;passed=$true;checked='All native raw metrics, receipts, schedule, medians, paired ratios, exact p and Holm correction'}
}
$result=[ordered]@{completedUtc=[DateTime]::UtcNow.ToString('o');passed=$true;studies=@($verified)}
$result|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path (Split-Path $StepsFile) 'independent-verification.json')
$verified|ForEach-Object {[pscustomobject]$_}|Format-Table repository,nativeProcesses,metrics,passed
