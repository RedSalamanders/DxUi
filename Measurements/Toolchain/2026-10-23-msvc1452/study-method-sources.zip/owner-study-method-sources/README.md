# DxUi compiler-policy experiment methods

The four original collection/analysis sources and their frozen SHA256 manifest are retained unchanged for provenance. The original Holm adjustment in Summarize-CompilerPolicy.ps1 selects an integer Math.Min overload and is superseded by Summarize-CompilerPolicy-Reviewed.ps1 (double-holm-v2). Use only runtime-*-reviewed.json/md for interpretation. Native sampling remains the original frozen collector; corrected analysis does not recollect or alter raw samples.

Test-CompilerPolicyReviewedStatistics.ps1 asserts exact nonzero Holm probabilities and reproduces the old zero-rounding defect. Verify-FinalCompilerStudies.ps1 independently checks raw native values, process receipts, ABBA/BAAB schedules, medians, paired ratios and exact probabilities. This owner package contains only this repository's native branch verification. The generic method source supports the five selected owners; their application results remain in their own evidence folders.
