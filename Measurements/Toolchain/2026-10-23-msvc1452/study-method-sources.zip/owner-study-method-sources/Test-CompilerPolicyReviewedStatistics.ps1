[CmdletBinding()]param()
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$base='E:\DxUi.Perf\compiler-policy\reviewed-summary-controls'
if(Test-Path -LiteralPath $base){throw 'Refusing numerical control evidence overwrite'}
[void][IO.Directory]::CreateDirectory($base)
$samples=@(foreach($block in 0..11){foreach($position in 'A1','A2','B1','B2'){
 $candidate=$position.StartsWith('B')
 [ordered]@{scenario='Synthetic';block=$block;position=$position;exitCode=0;preBuildActivity=@();duringBuildActivity=@();postBuildActivity=@();metrics=[ordered]@{allTwelve=$(if($candidate){50.0}else{100.0});fourNonzero=$(if($candidate-and $block-lt 4){50.0}else{100.0})}}
}})
foreach($case in 'known-probabilities','original-negative-control'){
 $dir=Join-Path $base $case;[void][IO.Directory]::CreateDirectory($dir)
 @{repository='SyntheticSummaryControl';blocks=12;diagnosticSharedHost=$false}|ConvertTo-Json|Set-Content (Join-Path $dir 'plan.json')
 @{passed=$true;sampleCount=48}|ConvertTo-Json|Set-Content (Join-Path $dir 'complete.json')
 $samples|ConvertTo-Json -Depth 6|Set-Content (Join-Path $dir 'samples.json')
 $script=if($case-eq 'known-probabilities'){'E:\DxUi.Perf\Summarize-CompilerPolicy-Reviewed.ps1'}else{'E:\DxUi.Perf\Summarize-CompilerPolicy.ps1'}
 & pwsh -NoProfile -File $script -Study $dir *> (Join-Path $dir 'output.log')
 if($LASTEXITCODE-ne 0){throw 'Numerical control process failed'}
 $file=if($case-eq 'known-probabilities'){'comparison-reviewed.json'}else{'comparison.json'}
 $result=Get-Content -LiteralPath (Join-Path $dir $file) -Raw|ConvertFrom-Json
 foreach($row in $result.rows){
  $expected=if($row.metric-ceq 'allTwelve'){0.0009765625}else{0.125}
  if($case-eq 'known-probabilities'){
   if([math]::Abs($row.adjustedP-$expected)-gt 1e-12){throw "Incorrect exact Holm probability: $($row.metric)"}
   if($row.metric-ceq 'fourNonzero'-and $row.finding-cne 'no significant fixture change detected; not non-regression proof'){throw 'Nonsignificant numerical control incorrectly promoted'}
  }elseif($row.adjustedP-ne 0){throw 'Original integer-overload defect no longer reproduced; investigate provenance'}
 }
}
[ordered]@{passed=$true;completedUtc=[DateTime]::UtcNow.ToString('o');exactHolmProbabilities=@(0.0009765625,0.125);negativeControl='Original frozen analyzer reproduces zero rounding';reviewedAnalyzerSha256=(Get-FileHash -LiteralPath 'E:\DxUi.Perf\Summarize-CompilerPolicy-Reviewed.ps1').Hash}|ConvertTo-Json|Tee-Object -FilePath (Join-Path $base 'complete.json')
