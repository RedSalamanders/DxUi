[CmdletBinding()] param([Parameter(Mandatory)][string] $SummaryPath,[Parameter(Mandatory)][string] $OutputPath)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$s=Get-Content -LiteralPath $SummaryPath -Raw|ConvertFrom-Json -AsHashtable
$folder=Split-Path -Parent $SummaryPath
function Median([double[]] $Values) {
    $copy=[double[]]$Values.Clone(); [Array]::Sort($copy); $mid=[int][Math]::Floor($copy.Length/2.0)
    if ($copy.Length%2) {return $copy[$mid]}; return ($copy[$mid-1]+$copy[$mid])/2.0
}
$results=[Collections.Generic.List[object]]::new(); $upward=@{baseline=0;candidate=0}
foreach ($scenario in $s.scenarios) {
    $reports=@{}; $samples=@{baseline=[Collections.Generic.List[double]]::new();candidate=[Collections.Generic.List[double]]::new()}
    foreach ($step in $s.steps) {
        $raw=Get-Content -LiteralPath (Join-Path $folder "$($scenario.scenario)-$($step.Name).json") -Raw|ConvertFrom-Json -AsHashtable
        $phase=@($raw.scenarios|Where-Object name -CEQ clean)[0]
        $reports[$step.Name]=Median ([double[]]$phase.rounds.prepareP95Ms)
        foreach ($round in $phase.rounds) {foreach ($value in $round.timingSamplesMs.prepare) {$samples[$step.Side].Add([double]$value)}}
    }
    foreach ($block in $s.blockSchedule) {
        foreach ($side in @('baseline','candidate')) {
            $runs=if ($side -ceq 'baseline') {$block.BaselineRuns} else {$block.CandidateRuns}
            if ($reports[$runs[1]]/$reports[$runs[0]] -gt 1.05) {$upward[$side]++}
        }
    }
    $pairs=@{}
    foreach ($side in @('baseline','candidate')) {
        $values=$samples[$side].ToArray(); if ($values.Count -ne 4800) {throw 'Incomplete preparation distribution'}
        [Array]::Sort($values)
        $pairs[$side]=[ordered]@{samples=$values.Length;pooledMedianNs=1e6*(Median $values);pooledP95Ns=1e6*$values[4559]}
    }
    $metric=@($scenario.set.metrics|Where-Object {$_.phase -ceq 'clean' -and $_.metric -ceq 'prepareP95Ms'})[0]
    $results.Add([ordered]@{scenario=$scenario.scenario;distributions=$pairs;positiveBlocks=@($metric.blockEffects|Where-Object {$_ -gt 0}).Count;negativeBlocks=@($metric.blockEffects|Where-Object {$_ -lt 0}).Count;zeroBlocks=@($metric.blockEffects|Where-Object {$_ -eq 0}).Count})
}
[ordered]@{summarySha256=(Get-FileHash -LiteralPath $SummaryPath).Hash;results=$results.ToArray();sameSideControlsUpwardBeyondFivePercent=$upward;controlsPerSide=36;interpretation='Pooled distributions are additional diagnostics, not a replacement metric or a verdict. Preserve unresolved legacy flags and the prescribed unchanged bands.'} | ConvertTo-Json -Depth 6|Set-Content -LiteralPath $OutputPath -Encoding utf8
Write-Host "PREPARE_DISTRIBUTIONS_VERIFIED upwardControls=$($upward.baseline+$upward.candidate)/72 baseline=$($upward.baseline) candidate=$($upward.candidate)"
