[CmdletBinding()] param([Parameter(Mandatory)][string] $SummaryPath,[Parameter(Mandatory)][string] $OutputPath)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$s=Get-Content -LiteralPath $SummaryPath -Raw | ConvertFrom-Json -AsHashtable
$root=Split-Path -Parent $SummaryPath
function Median([double[]] $Values) {
    $v=@($Values|Sort-Object); $i=[int][Math]::Floor($v.Count/2.0)
    if ($v.Count%2) {return $v[$i]}; return ($v[$i-1]+$v[$i])/2.0
}
$results=@(foreach ($scenarioName in @('MultilineGrid','MultilineGridDistinct')) {
    $scenario=@($s.scenarios|Where-Object scenario -CEQ $scenarioName)[0]
    $runs=@(foreach ($step in $s.steps) {
        $r=Get-Content -LiteralPath (Join-Path $root "$scenarioName-$($step.Name).json") -Raw | ConvertFrom-Json -AsHashtable
        $phase=@($r.scenarios|Where-Object name -CEQ clean)[0]
        [pscustomobject]@{name=$step.Name;side=$step.Side;value=(Median @($phase.rounds.prepareP95Ms));tickNanoseconds=$r.clock.tickNanoseconds}
    })
    if ($runs.Count -ne 48 -or @($runs|Where-Object side -CEQ candidate).Count -ne 24 -or @($runs.tickNanoseconds|Sort-Object -Unique).Count -ne 1) {throw 'Incomplete raw run/clock set'}
    # Weighted selection over complete tie groups. Doubled ranks keep tied average ranks integral.
    # Group names are localized display text (for example 0,001); order the numeric values themselves.
    $groups=@($runs|Group-Object value|Sort-Object {[double]$_.Group[0].value})
    $states=@{'0,0'=[decimal]1}; $first=1; $candidateRankSum=0
    foreach ($group in $groups) {
        $m=$group.Count; $rank2=2*$first+$m-1; $first+=$m
        $candidateRankSum+=@($group.Group|Where-Object side -CEQ candidate).Count*$rank2
        $next=@{}
        foreach ($key in $states.Keys) {
            $parts=$key.Split(','); $count=[int]$parts[0]; $sum=[int]$parts[1]; $choose=[decimal]1
            for ($k=0; $k -le [Math]::Min($m,24-$count); $k++) {
                if ($k) {$choose=$choose*($m-$k+1)/$k}
                $newKey="$($count+$k),$($sum+$k*$rank2)"
                if (-not $next.ContainsKey($newKey)) {$next[$newKey]=[decimal]0}
                $next[$newKey]+=$states[$key]*$choose
            }
        }
        $states=$next
    }
    $total=[decimal]0; $extreme=[decimal]0; $distance=[Math]::Abs($candidateRankSum-1176)
    foreach ($key in $states.Keys) {
        $parts=$key.Split(','); if ([int]$parts[0] -ne 24) {continue}
        $total+=$states[$key]
        if ([Math]::Abs([int]$parts[1]-1176) -ge $distance) {$extreme+=$states[$key]}
    }
    $p=[double]($extreme/$total)
    $metric=@($scenario.judgeComparison.legacyJudge.metrics|Where-Object {$_.phase -ceq 'clean' -and $_.metric -ceq 'prepareP95Ms'})[0]
    $migrated=@($scenario.set.metrics|Where-Object {$_.phase -ceq 'clean' -and $_.metric -ceq 'prepareP95Ms'})[0]
    $baseline=Median @($runs|Where-Object side -CEQ baseline|Select-Object -ExpandProperty value)
    $candidate=Median @($runs|Where-Object side -CEQ candidate|Select-Object -ExpandProperty value)
    if ([Math]::Abs($p-$metric.pValue) -gt 1e-12 -or $total -ne 32247603683100 -or $candidateRankSum/2.0-300 -ne $metric.u -or $baseline -ne $metric.baselineMedian -or $candidate -ne $metric.candidateMedian) {throw "Legacy inference differs: scenario=$scenarioName p=$p expected=$($metric.pValue) total=$total U=$($candidateRankSum/2.0-300) expectedU=$($metric.u) baseline=$baseline expected=$($metric.baselineMedian) candidate=$candidate expected=$($metric.candidateMedian)"}
    [ordered]@{scenario=$scenarioName;phase='clean';metric='prepareP95Ms';legacyExactU=$metric.u;legacyAssignments=$total;legacyExtreme=$extreme;legacyP=$p;baselineMedianNs=1e6*$baseline;candidateMedianNs=1e6*$candidate;counterTickNs=$runs[0].tickNanoseconds;legacyChangePercent=$metric.changePercent;migratedRawP=$migrated.pValue;migratedAdjustedP=$migrated.adjustedPValue;migratedChangePercent=$migrated.changePercent;legacyVerdict=$metric.verdict;migratedVerdict=$migrated.verdict}
})
[ordered]@{summarySha256=(Get-FileHash -LiteralPath $SummaryPath).Hash;results=$results;interpretation='Preserve both legacy regression flags. Paired family-corrected inference has no flagged outcome, but unstable controls and an unqualified policy leave non-regression inconclusive. One-counter-tick median increases do not prove quantization is the only cause.'} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $OutputPath -Encoding utf8
Write-Host 'LEGACY_TIE_GROUP_AUDIT_PASS two raw regression flags independently reproduced'
