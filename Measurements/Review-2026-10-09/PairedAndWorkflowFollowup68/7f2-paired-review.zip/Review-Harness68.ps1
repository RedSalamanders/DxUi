[CmdletBinding()] param([Parameter(Mandatory)][string] $SummaryPath,[Parameter(Mandatory)][string] $OutputPath)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$s=Get-Content -LiteralPath $SummaryPath -Raw|ConvertFrom-Json -AsHashtable
$head='7f2e9595a26f8a84cd11f9b769abb16e70d9716f'
$merge=Get-Content .build/7f2-merge-provenance66.json -Raw|ConvertFrom-Json -AsHashtable
$headProof=Get-Content .build/7f2-head-provenance66.json -Raw|ConvertFrom-Json -AsHashtable
if ($s.candidateCommit -cne $merge.sha -or $merge.tree -cne $headProof.tree -or ($merge.parents -join ',') -cne ($s.baselineCommit+','+$head)) {throw 'Frozen study does not bind expected merge/head tree and parents'}
$hashes=@(foreach ($path in $s.harness.Keys) {
    $start=[Diagnostics.ProcessStartInfo]::new('git');$start.UseShellExecute=$false;$start.RedirectStandardOutput=$true;$start.RedirectStandardError=$true;$start.StandardOutputEncoding=[Text.UTF8Encoding]::new($false)
    $start.ArgumentList.Add('show');$start.ArgumentList.Add($head+':'+$path)
    $process=[Diagnostics.Process]::Start($start)
    try {$source=$process.StandardOutput.ReadToEnd();$errorText=$process.StandardError.ReadToEnd();$process.WaitForExit();if ($process.ExitCode) {throw "Immutable source read failed: $path $errorText"}} finally {$process.Dispose()}
    $lf=$source.Replace("`r`n","`n"); $windows=$lf.Replace("`n","`r`n")
    $lfHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($lf)))
    $windowsHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($windows)))
    if ($s.harness[$path] -cne $lfHash -and $s.harness[$path] -cne $windowsHash) {throw "Harness bytes do not match immutable head: $path"}
    [ordered]@{path=$path;recordedSha256=$s.harness[$path];lfSha256=$lfHash;windowsSha256=$windowsHash;matched=$true}
})
if ($hashes.Count -ne 13) {throw 'Incomplete harness inventory'}
[ordered]@{head=$head;actualMerge=$merge.sha;tree=$merge.tree;hashes=$hashes;limitation='LF and Windows CRLF forms are derived from immutable Git source; no CI executable bytes are available to rehash.'}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $OutputPath -Encoding utf8
Write-Host 'IMMUTABLE_HARNESS_VERIFIED 13 hashes and actual merge/head tree'
