## Paired benchmark: Inconclusive

The study cannot qualify a pass: policy review, missing identity, drifting controls or insufficient evidence leaves the result unresolved. Re-run or complete independent policy review; do not dismiss flagged metrics as noise.

Policy review required: The measured base does not contain the versioned acceptance policy; the candidate cannot introduce its own trust anchor.

| | |
|---|---|
| Baseline | `bea676a1f841` first parent of the merge commit (the base as the merge ref was made) |
| Candidate | `0ebf4820dce2` (this checkout) |
| Library inputs | changed, fingerprint `41423433DDF4` to `CF33A85A9BE4` |
| Method | 12 independent paired blocks; seed 38264413; independently drawn ABBA/BAAB; exact sign-flip with Holm correction; x64 Release; 5% timing and 2% memory bands, exact budgets stay exact |
| Runner | runnervmfi6oq; a shared hosted VM, not a controlled quiet desktop |
| Event | pull request merge ref (refs/pull/70/merge) |

### Scenarios

| Scenario | Check | Set verdict | Regressed | Improved | Metrics held by controls | Controls stable |
|---|---|---|---:|---:|---:|---:|

### Flagged metrics

None: no metric regressed or improved.

The retained receipts, comparisons and `summary.json` are in the `paired-benchmark-x64-Release` artifact. Migrated timing and memory metrics use the Holm-adjusted p-value and declared band; legacy rows retain their original raw p-value and show no adjusted p-value. Exact-budget rows report median and raw-peak findings separately. `Specs/Core/Core_PerformanceAndResources.md` says what a verdict establishes and what a finding requires.
