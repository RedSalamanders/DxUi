[CmdletBinding()] param([Parameter(Mandatory)][string] $SummaryPath,[Parameter(Mandatory)][string] $OutputPath)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$s=Get-Content -LiteralPath $SummaryPath -Raw|ConvertFrom-Json -AsHashtable
$root=Split-Path -Parent $SummaryPath
function Median([double[]] $Values){$v=@($Values|Sort-Object);$i=[int][Math]::Floor($v.Count/2.0);if($v.Count%2){return $v[$i]};return ($v[$i-1]+$v[$i])/2.0}
$scenario=@($s.scenarios|Where-Object scenario -CEQ Default)[0]
$results=@(foreach($metricName in @('workingSetBytes','workingSetPeakBytes')){
    $runs=@(foreach($step in $s.steps){
        $r=Get-Content -LiteralPath (Join-Path $root "Default-$($step.Name).json") -Raw|ConvertFrom-Json -AsHashtable
        $phase=@($r.scenarios|Where-Object name -CEQ dirty)[0]
        [pscustomobject]@{name=$step.Name;side=$step.Side;value=(Median @($phase.rounds|ForEach-Object {$_[$metricName]}))}
    })
    if($runs.Count -ne 48 -or @($runs|Where-Object side -CEQ candidate).Count -ne 24){throw 'Incomplete paired memory samples'}
    $groups=@($runs|Group-Object value|Sort-Object {[double]$_.Group[0].value})
    $states=@{'0,0'=[decimal]1};$first=1;$candidateRankSum=0
    foreach($group in $groups){
        $m=$group.Count;$rank2=2*$first+$m-1;$first+=$m
        $candidateRankSum+=@($group.Group|Where-Object side -CEQ candidate).Count*$rank2
        $next=@{}
        foreach($key in $states.Keys){
            $parts=$key.Split(',');$count=[int]$parts[0];$sum=[int]$parts[1];$choose=[decimal]1
            for($k=0;$k -le [Math]::Min($m,24-$count);$k++){
                if($k){$choose=$choose*($m-$k+1)/$k}
                $newKey="$($count+$k),$($sum+$k*$rank2)"
                if(-not $next.ContainsKey($newKey)){$next[$newKey]=[decimal]0}
                $next[$newKey]+=$states[$key]*$choose
            }
        }
        $states=$next
    }
    $total=[decimal]0;$extreme=[decimal]0;$distance=[Math]::Abs($candidateRankSum-1176)
    foreach($key in $states.Keys){$parts=$key.Split(',');if([int]$parts[0] -ne 24){continue};$total+=$states[$key];if([Math]::Abs([int]$parts[1]-1176) -ge $distance){$extreme+=$states[$key]}}
    $p=[double]($extreme/$total)
    $metric=@($scenario.judgeComparison.legacyJudge.metrics|Where-Object {$_.phase -ceq 'dirty' -and $_.metric -ceq $metricName})[0]
    $paired=@($scenario.set.metrics|Where-Object {$_.phase -ceq 'dirty' -and $_.metric -ceq $metricName})[0]
    $a=Median @($runs|Where-Object side -CEQ baseline|Select-Object -ExpandProperty value)
    $b=Median @($runs|Where-Object side -CEQ candidate|Select-Object -ExpandProperty value)
    if([Math]::Abs($p-$metric.pValue) -gt 1e-12 -or $total -ne 32247603683100 -or $candidateRankSum/2.0-300 -ne $metric.u -or $a -ne $metric.baselineMedian -or $b -ne $metric.candidateMedian -or $metric.verdict -cne 'regressed'){throw "Raw legacy memory inference differs: $metricName"}
    [ordered]@{phase='dirty';metric=$metricName;legacyAssignments=$total;legacyExtreme=$extreme;legacyU=$metric.u;legacyP=$p;baselineMedianBytes=$a;candidateMedianBytes=$b;differenceBytes=$b-$a;legacyChangePercent=$metric.changePercent;pairedChangePercent=$paired.changePercent;pairedP=$paired.pValue;pairedAdjustedP=$paired.adjustedPValue;legacyVerdict=$metric.verdict;pairedVerdict=$paired.verdict}
})
[ordered]@{summarySha256=(Get-FileHash -LiteralPath $SummaryPath).Hash;results=$results;qualification='Raw tied-rank dynamic programming independently reproduces both legacy flags; no production comparator imported. Unstable same-binary controls, judge disagreement and unqualified policy retain inconclusive nonregression.'}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $OutputPath
Write-Host 'EXTRACTION_LEGACY_AUDIT_PASS two memory flags independently reproduced'
