Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$destination=[IO.Path]::GetFullPath('Measurements/Review-2026-10-09/ExtractionFollowup70')
New-Item -ItemType Directory -Path $destination -Force | Out-Null
$manifest=[Collections.Generic.List[string]]::new()
$manifest.Add('Before library source 65476a8a457b10d1e8b7fd6520a7453d1d4d83a3; exact dirty candidate source/artifact identities retained independently. Focused x64 tests and unqualified Debug paired diagnostic; no six-profile or production acceptance inferred.')
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile([IO.Path]::GetFullPath('.build/Seal-ReviewFollowup61.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Archive helper parse failure'}
$functions=@($ast.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -in @('Seal-Packet','Get-PacketFiles')},$false))
if($functions.Count -ne 2){throw 'Missing reviewed archive helpers'}
foreach($function in $functions){Invoke-Expression $function.Extent.Text}
$files=[ordered]@{}
foreach($folder in @('extraction70-baseline','extraction70-red','extraction70-candidate','extraction70-current-Debug','extraction70-current-Release','extraction70-current-ASan Debug')){
    $packet=Get-PacketFiles ".build/$folder"
    foreach($entry in $packet.Keys){$files["$folder/$entry"]=$packet[$entry]}
}
foreach($name in @('extraction70-performance-comparison.json','extraction70-repeat-1.json','extraction70-repeat-2.json','extraction70-repeat-1-baseline-comparison.json','extraction70-repeat-2-baseline-comparison.json','extraction70-repeat-process-observation.json','extraction70-local-independent-audit.json','extraction70-timing-independent-audit.json','extraction70-paired-independent-audit.json','extraction70-paired-independent-controls.json','extraction70-paired-timing-independent-audit.json','extraction70-paired-source-and-artifact-audit.json','extraction70-legacy-independent-audit.json','Review-ExtractionLocal70.ps1','Review-ExtractionTiming70.ps1','Review-ExtractionPaired70.ps1','Review-AAControls55.ps1','Review-ExtractionPairedTiming70.ps1','Review-ExtractionLegacy70.ps1','Seal-Extraction70.ps1')){$files[$name]=".build/$name"}
foreach($file in Get-ChildItem .build/logs -File -Filter 'production-review-2026-10-10-extraction70-*.log'){$files["logs/$($file.Name)"]=$file.FullName}
foreach($name in @('build-x64-Debug-37faaec88a8c4ed0afec01c426d65eae.log','build-x64-Debug-5cf7b66e38314166a274b9602053a357.log','build-x64-Debug-912a605fbe4743808637f7778dc3f19a.log')){$files["logs/$name"]=".build/logs/$name"}
foreach($source in @('src/Controls/DxUi.Controls.cpp','Tests/Controls/DxUi.Tests.Controls.cpp','include/DxUi/DxUi.h')){$files["candidate-source/$source"]=$source}
Seal-Packet 'extraction-local-proof.zip' $files
Seal-Packet 'extraction-paired-raw.zip' (Get-PacketFiles '.build/extraction70-paired/20261010T021804Z-65476a8a457b/reports')
$manifest|Set-Content (Join-Path $destination 'archive-manifest.txt')
