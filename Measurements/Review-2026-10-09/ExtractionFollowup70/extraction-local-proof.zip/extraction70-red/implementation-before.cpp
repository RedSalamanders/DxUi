#include "DxUi.Internal.h"

#include <algorithm>
#include <cmath>
#include <cwctype>
#include <format>
#include <limits>
#include <memory>
#include <new>
#include <string>
#include <utility>

#include "../Support/Diagnostics.h"

namespace DxUi
{
std::weak_ptr<int> GetControlLifetimeToken(const Control& control) noexcept
{
    return control.GetLifetimeToken();
}

namespace
{
template <typename TCallback> [[nodiscard]] Control* FindPanelChildHit(Panel& panel, const std::weak_ptr<int>& ownerLifetime, TCallback&& callback)
{
    size_t index             = panel.GetLogicalChildCount();
    const size_t visitBudget = index;
    for (size_t visits = 0u; visits < visitBudget && index > 0u; ++visits)
    {
        if (ownerLifetime.expired())
            return nullptr;
        auto children = panel.GetChildren();
        index         = (std::min)(index, children.size());
        if (index == 0u)
            return nullptr;
        Control* const child = children[--index].get();
        if (! child)
            continue;
        const auto childLifetime = GetControlLifetimeToken(*child);
        Control* const hit       = callback(*child);
        if (ownerLifetime.expired())
            return nullptr;
        children = panel.GetChildren();
        if (! childLifetime.expired() && index < children.size() && children[index].get() == child && hit && IsControlEffectivelyInteractive(child, hit))
            return hit;
    }
    return nullptr;
}

template <typename TPanel, typename TCallback>
void ForEachPanelChildCallback(TPanel& panel,
                               const std::weak_ptr<int>& ownerLifetime,
                               TCallback&& callback) noexcept(noexcept(std::declval<TCallback&>()(std::declval<Control&>())))
{
    const size_t visitBudget = panel.GetLogicalChildCount();
    size_t index             = 0u;
    size_t visits            = 0u;
    while (visits < visitBudget)
    {
        if (ownerLifetime.expired())
        {
            return;
        }

        auto children = panel.GetChildren();
        if (index >= children.size())
        {
            return;
        }

        Control* child = children[index].get();
        if (! child)
        {
            ++index;
            ++visits;
            continue;
        }

        const std::weak_ptr<int> childLifetime = GetControlLifetimeToken(*child);
        callback(*child);
        if (ownerLifetime.expired())
        {
            return;
        }

        ++visits;
        children = panel.GetChildren();
        if (! childLifetime.expired() && index < children.size() && children[index].get() == child)
        {
            ++index;
        }
        else if (! childLifetime.expired())
        {
            const auto moved = std::find_if(children.begin(), children.end(), [child](const auto& candidate) { return candidate.get() == child; });
            if (moved != children.end())
            {
                index = static_cast<size_t>(moved - children.begin()) + 1u;
            }
        }
    }
}
} // namespace

namespace
{
constexpr GUID kD2DShadowEffectId = {0xC67EA361, 0x1863, 0x4e69, {0x89, 0xDB, 0x69, 0x5D, 0x3E, 0x9A, 0x5B, 0x6B}};

[[nodiscard]] std::wstring TraceLimitedText(std::wstring_view value)
{
    constexpr size_t kMaxTraceTextChars = 80u;
    std::wstring text;
    text.reserve((std::min)(value.size(), kMaxTraceTextChars + 3u));
    for (const wchar_t ch : value)
    {
        if (text.size() >= kMaxTraceTextChars)
        {
            text.append(L"...");
            break;
        }
        text.push_back((ch == L'\r' || ch == L'\n' || ch == L'\t') ? L' ' : ch);
    }
    return text;
}

[[nodiscard]] std::wstring TraceRect(const D2D1_RECT_F& rect)
{
    return std::format(L"({:.1f},{:.1f},{:.1f},{:.1f})", rect.left, rect.top, rect.right, rect.bottom);
}

[[nodiscard]] const wchar_t* TraceButtonVariantName(ButtonVariant variant) noexcept
{
    switch (variant)
    {
        case ButtonVariant::Standard: return L"Standard";
        case ButtonVariant::DropDown: return L"DropDown";
        case ButtonVariant::Selector: return L"Selector";
        case ButtonVariant::Split: return L"Split";
        case ButtonVariant::Hyperlink: return L"Hyperlink";
        case ButtonVariant::IconOnly: return L"IconOnly";
        case ButtonVariant::Disclosure: return L"Disclosure";
        case ButtonVariant::Repeat: return L"Repeat";
        default: return L"Unknown";
    }
}

template <typename... Args> void TraceButtonDiagnostics(std::wstring_view eventName, std::wformat_string<Args...> format, Args&&... args) noexcept
{
    if (! IsContextMenuDiagnosticsEnabled())
    {
        return;
    }

    try
    {
        TraceContextMenuDiagnostics(eventName, std::format(format, std::forward<Args>(args)...));
    }
    catch (const std::bad_alloc&)
    {
        std::terminate();
    }
    catch (const std::format_error&)
    {
        // Button tracing is diagnostic only; formatting failure must not disturb input dispatch.
        TraceContextMenuDiagnostics(eventName, L"formatting failed");
    }
}

[[nodiscard]] int TraceOptionalIndex(std::optional<size_t> value) noexcept
{
    return value.has_value() && value.value() <= static_cast<size_t>(std::numeric_limits<int>::max()) ? static_cast<int>(value.value()) : -1;
}

void TraceMenuBarPointerEvent(std::wstring_view eventName,
                              const ControlHost& host,
                              D2D1_POINT_2F point,
                              std::optional<size_t> hit,
                              std::optional<size_t> pressed,
                              std::optional<size_t> selected,
                              size_t itemCount) noexcept
{
    Debug::Info(L"DxUi::MenuTrace MenuBar {} hwnd={:#x} capture={:#x} pointDip=({:.1f},{:.1f}) hit={} pressed={} selected={} itemCount={}",
                eventName,
                reinterpret_cast<uintptr_t>(host.GetHwnd()),
                reinterpret_cast<uintptr_t>(GetCapture()),
                point.x,
                point.y,
                TraceOptionalIndex(hit),
                TraceOptionalIndex(pressed),
                TraceOptionalIndex(selected),
                itemCount);
}

void DrawFallbackShadowRoundedRects(
    ControlHost& host, const D2D1_RECT_F& targetRect, float cornerRadiusDip, float yOffsetDip, float spreadDip, float outerOpacity, float innerOpacity) noexcept
{
    const float outerRadius     = cornerRadiusDip + spreadDip;
    const float innerRadius     = cornerRadiusDip + 1.0f;
    const D2D1_RECT_F outerRect = D2D1::RectF(
        targetRect.left - spreadDip, targetRect.top - spreadDip + yOffsetDip, targetRect.right + spreadDip, targetRect.bottom + spreadDip + yOffsetDip);
    const D2D1_RECT_F innerRect =
        D2D1::RectF(targetRect.left - 1.0f, targetRect.top - 1.0f + yOffsetDip, targetRect.right + 1.0f, targetRect.bottom + 1.0f + yOffsetDip);
    const D2D1_ROUNDED_RECT outerRr = D2D1::RoundedRect(outerRect, outerRadius, outerRadius);
    const D2D1_ROUNDED_RECT innerRr = D2D1::RoundedRect(innerRect, innerRadius, innerRadius);
    auto* const dc                  = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    if (auto* const outerBrush = host.GetSolidBrush(D2D1::ColorF(0.0f, 0.0f, 0.0f, outerOpacity)))
    {
        dc->FillRoundedRectangle(outerRr, outerBrush);
    }
    if (auto* const innerBrush = host.GetSolidBrush(D2D1::ColorF(0.0f, 0.0f, 0.0f, innerOpacity)))
    {
        dc->FillRoundedRectangle(innerRr, innerBrush);
    }
}

bool DrawShadowEffectPass(ControlHost& host, const D2D1_RECT_F& targetRect, float cornerRadiusDip, float yOffsetDip, float blurDip, float opacity) noexcept
{
    auto* const dc = host.GetDeviceContext();
    if (! dc || blurDip <= 0.0f || opacity <= 0.0f)
    {
        return false;
    }

    wil::com_ptr<ID2D1Image> previousTarget;
    dc->GetTarget(previousTarget.put());

    wil::com_ptr<ID2D1CommandList> mask;
    if (FAILED(dc->CreateCommandList(mask.put())) || ! mask)
    {
        return false;
    }

    dc->SetTarget(mask.get());
    const auto restoreTarget = wil::scope_exit([&]() noexcept { dc->SetTarget(previousTarget.get()); });

    dc->Clear(D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f));
    if (auto* const maskBrush = host.GetSolidBrush(D2D1::ColorF(1.0f, 1.0f, 1.0f, 1.0f)))
    {
        dc->FillRoundedRectangle(D2D1::RoundedRect(targetRect, cornerRadiusDip, cornerRadiusDip), maskBrush);
    }
    else
    {
        return false;
    }

    dc->SetTarget(previousTarget.get());
    if (FAILED(mask->Close()))
    {
        return false;
    }

    wil::com_ptr<ID2D1Effect> shadowEffect;
    if (FAILED(dc->CreateEffect(kD2DShadowEffectId, shadowEffect.put())) || ! shadowEffect)
    {
        return false;
    }

    shadowEffect->SetInput(0u, mask.get());
    shadowEffect->SetValue(D2D1_SHADOW_PROP_BLUR_STANDARD_DEVIATION, blurDip);
    shadowEffect->SetValue(D2D1_SHADOW_PROP_COLOR, D2D1::Vector4F(0.0f, 0.0f, 0.0f, opacity));
    shadowEffect->SetValue(D2D1_SHADOW_PROP_OPTIMIZATION, D2D1_SHADOW_OPTIMIZATION_QUALITY);

    const D2D1_POINT_2F shadowOffset = D2D1::Point2F(0.0f, yOffsetDip);
    dc->DrawImage(shadowEffect.get(), &shadowOffset, nullptr, D2D1_INTERPOLATION_MODE_LINEAR, D2D1_COMPOSITE_MODE_SOURCE_OVER);
    return true;
}

constexpr std::wstring_view kFluentCheckGlyph   = L"\uE73E";
constexpr std::wstring_view kFallbackCheckGlyph = L"\u2713";
// The most one tick advances a disclosure rotation: a longer gap means the ticks stopped, and pauses it.
constexpr uint64_t kDisclosureMaxTickStepMs      = 100u;
constexpr float kTooltipOffsetXDip               = 14.0f;
constexpr float kTooltipOffsetYDip               = 18.0f;
constexpr float kTooltipViewportMarginDip        = 8.0f;
constexpr float kTooltipPaddingXDip              = 10.0f;
constexpr float kTooltipPaddingYDip              = 6.0f;
constexpr float kTooltipMinWidthDip              = 96.0f;
constexpr float kTooltipMaxWidthDip              = 280.0f;
constexpr float kTooltipMinHeightDip             = 28.0f;
constexpr float kTooltipCornerRadiusDip          = 4.0f;
constexpr float kTooltipFallbackLineHeightDip    = 18.0f;
constexpr float kTooltipPreferredTextHeightDip   = 256.0f;
constexpr float kMenuBarItemCornerRadiusDip      = 4.0f;
constexpr float kSliderTrackThicknessDip         = 6.0f;
constexpr float kSliderThumbDiameterDip          = 14.0f;
constexpr float kSliderThumbHoverDiameterDip     = 20.0f;
constexpr float kSliderThumbPressedDiameterDip   = 16.0f;
constexpr float kSliderChromeDiameterDip         = 24.0f;
constexpr float kSliderTrackInsetDip             = 12.0f;
constexpr float kSliderHitExtentDip              = 48.0f;
constexpr float kSliderTickLengthDip             = 6.0f;
constexpr float kTabStripHeightDip               = 32.0f;
constexpr float kTabCornerRadiusDip              = 5.0f;
constexpr float kTabAttachFillExtensionDip       = 1.0f;
constexpr float kTabAttachStrokeInsetDip         = 1.0f;
constexpr float kTabHeaderPaddingXDip            = 12.0f;
constexpr float kTabHeaderGapDip                 = 4.0f;
constexpr float kTabHeaderMinWidthDip            = 72.0f;
constexpr float kTabHeaderCloseButtonSizeDip     = 16.0f;
constexpr float kTabHeaderOverflowButtonWidthDip = 24.0f;

// A touch drag shows the 48 DIP grab area as a translucent accent halo, so feedback shows around the finger that covers
// the thumb. High contrast keeps system colors opaque and draws it as a ring.
constexpr float kSliderTouchHaloDiameterDip  = kSliderHitExtentDip;
constexpr float kSliderTouchHaloOpacity      = 0.24f;
constexpr float kSliderTouchHaloRingWidthDip = 2.0f;

[[nodiscard]] wchar_t NormalizeMnemonicChar(wchar_t ch) noexcept
{
    return static_cast<wchar_t>(std::towupper(static_cast<wint_t>(ch)));
}

[[nodiscard]] bool ControlBelongsToBranch(const Control* root, const Control* target) noexcept
{
    if (! root || ! target)
    {
        return false;
    }

    if (root == target)
    {
        return true;
    }

    for (size_t childIndex = 0u; childIndex < root->GetLogicalChildCount(); ++childIndex)
    {
        if (const Control* const child = root->GetLogicalChild(childIndex))
        {
            if (ControlBelongsToBranch(child, target))
            {
                return true;
            }
        }
    }

    return false;
}

[[nodiscard]] Control* RevalidateScrollPanelChild(const std::weak_ptr<int>& lifetime, const Control* root, Control* child) noexcept
{
    if (! child || lifetime.expired() || ! ControlBelongsToBranch(root, child))
    {
        return nullptr;
    }

    return child;
}

[[nodiscard]] float ClampUnit(float value) noexcept
{
    return (std::clamp)(value, 0.0f, 1.0f);
}

[[nodiscard]] float Lerp(float from, float to, float t) noexcept
{
    return from + ((to - from) * ClampUnit(t));
}

[[nodiscard]] D2D1_RECT_F LerpRect(const D2D1_RECT_F& from, const D2D1_RECT_F& to, float t) noexcept
{
    const float clamped = ClampUnit(t);
    return D2D1::RectF(
        Lerp(from.left, to.left, clamped), Lerp(from.top, to.top, clamped), Lerp(from.right, to.right, clamped), Lerp(from.bottom, to.bottom, clamped));
}

[[nodiscard]] float EvaluateCubicBezier1D(float p1, float p2, float t) noexcept
{
    const float invT = 1.0f - t;
    return (3.0f * invT * invT * t * p1) + (3.0f * invT * t * t * p2) + (t * t * t);
}

[[nodiscard]] float EvaluateCubicBezier(float x1, float y1, float x2, float y2, float t) noexcept
{
    const float clamped = ClampUnit(t);
    if (clamped <= 0.0f || clamped >= 1.0f)
    {
        return clamped;
    }

    float low  = 0.0f;
    float high = 1.0f;
    float u    = clamped;
    for (int iteration = 0; iteration < 14; ++iteration)
    {
        u = (low + high) * 0.5f;
        if (EvaluateCubicBezier1D(x1, x2, u) < clamped)
        {
            low = u;
        }
        else
        {
            high = u;
        }
    }

    return EvaluateCubicBezier1D(y1, y2, u);
}

[[nodiscard]] const Control* FindConnectedAnimationControl(const Control* root, std::wstring_view key) noexcept
{
    if (! root || key.empty())
    {
        return nullptr;
    }

    if (root->GetConnectedAnimationKey() == key)
    {
        return root;
    }

    for (size_t childIndex = 0u; childIndex < root->GetLogicalChildCount(); ++childIndex)
    {
        if (const Control* const child = root->GetLogicalChild(childIndex))
        {
            if (const Control* const match = FindConnectedAnimationControl(child, key))
            {
                return match;
            }
        }
    }

    return nullptr;
}

[[nodiscard]] float ResolveConnectedOverlayCornerRadius(const D2D1_RECT_F& rect) noexcept
{
    const float widthDip  = (std::max)(0.0f, rect.right - rect.left);
    const float heightDip = (std::max)(0.0f, rect.bottom - rect.top);
    return (std::clamp)((std::min)(widthDip, heightDip) * 0.18f, 4.0f, 10.0f);
}

[[nodiscard]] wil::com_ptr<IDWriteTextLayout> CreateTooltipTextLayout(
    const ControlHost& host, std::wstring_view text, float widthDip, float heightDip, DWRITE_READING_DIRECTION readingDirection) noexcept
{
    auto* factory = host.GetWriteFactory();
    auto* format  = host.GetTextFormat(FontRole::Small, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_NEAR, true, readingDirection);
    if (! factory || ! format)
    {
        return {};
    }

    wil::com_ptr<IDWriteTextLayout> layout;
    if (FAILED(factory->CreateTextLayout(
            text.data(), static_cast<UINT32>(text.size()), format, (std::max)(1.0f, widthDip), (std::max)(1.0f, heightDip), layout.addressof())) ||
        ! layout)
    {
        return {};
    }

    return layout;
}

[[nodiscard]] bool TooltipPointsMatch(const D2D1_POINT_2F& lhs, const D2D1_POINT_2F& rhs) noexcept
{
    return std::fabs(lhs.x - rhs.x) <= 0.0001f && std::fabs(lhs.y - rhs.y) <= 0.0001f;
}

[[nodiscard]] bool TooltipRectsMatch(const D2D1_RECT_F& lhs, const D2D1_RECT_F& rhs) noexcept
{
    return std::fabs(lhs.left - rhs.left) <= 0.0001f && std::fabs(lhs.top - rhs.top) <= 0.0001f && std::fabs(lhs.right - rhs.right) <= 0.0001f &&
           std::fabs(lhs.bottom - rhs.bottom) <= 0.0001f;
}
} // namespace

float EvaluateEasing(EasingCurve curve, float t) noexcept
{
    switch (curve)
    {
        case EasingCurve::Linear: return ClampUnit(t);
        case EasingCurve::FastDecelerate: return EvaluateCubicBezier(0.0f, 0.0f, 0.0f, 1.0f, t);
        case EasingCurve::PointToPoint: return EvaluateCubicBezier(0.55f, 0.55f, 0.0f, 1.0f, t);
    }

    return ClampUnit(t);
}

std::optional<size_t> FindMnemonicTextIndex(std::wstring_view text, wchar_t mnemonic) noexcept
{
    const wchar_t normalizedMnemonic = NormalizeMnemonicChar(mnemonic);
    if (normalizedMnemonic == L'\0')
    {
        return std::nullopt;
    }

    std::optional<size_t> fallbackIndex;
    size_t displayIndex      = 0u;
    bool hasExplicitMnemonic = false;

    for (size_t index = 0u; index < text.size(); ++index)
    {
        const wchar_t ch = text[index];
        if (ch == L'&')
        {
            if ((index + 1u) < text.size())
            {
                const wchar_t escaped = text[index + 1u];
                if (escaped == L'&')
                {
                    if (! hasExplicitMnemonic && ! fallbackIndex && NormalizeMnemonicChar(escaped) == normalizedMnemonic)
                    {
                        fallbackIndex = displayIndex;
                    }

                    ++displayIndex;
                    ++index;
                    continue;
                }

                hasExplicitMnemonic = true;
                if (NormalizeMnemonicChar(escaped) == normalizedMnemonic)
                {
                    return displayIndex;
                }

                ++displayIndex;
                ++index;
                continue;
            }

            if (! hasExplicitMnemonic && ! fallbackIndex && NormalizeMnemonicChar(ch) == normalizedMnemonic)
            {
                fallbackIndex = displayIndex;
            }

            ++displayIndex;
            continue;
        }

        if (! hasExplicitMnemonic && ! fallbackIndex && NormalizeMnemonicChar(ch) == normalizedMnemonic)
        {
            fallbackIndex = displayIndex;
        }

        ++displayIndex;
    }

    return hasExplicitMnemonic ? std::nullopt : fallbackIndex;
}

bool PointInRect(const D2D1_RECT_F& rect, const D2D1_POINT_2F& point) noexcept
{
    return point.x >= rect.left && point.x < rect.right && point.y >= rect.top && point.y < rect.bottom;
}

D2D1_RECT_F InflateRect(const D2D1_RECT_F& rect, float amountX, float amountY) noexcept
{
    return D2D1::RectF(rect.left - amountX, rect.top - amountY, rect.right + amountX, rect.bottom + amountY);
}

float SnapDipToPixel(const ControlHost& host, float dip) noexcept
{
    return host.PixelsToDip(std::round(host.DipsToPixels(dip)));
}

D2D1_RECT_F SnapRectToPixel(const ControlHost& host, const D2D1_RECT_F& rect) noexcept
{
    return D2D1::RectF(SnapDipToPixel(host, rect.left), SnapDipToPixel(host, rect.top), SnapDipToPixel(host, rect.right), SnapDipToPixel(host, rect.bottom));
}

void FillRoundedRectWithColor(ControlHost& host, const D2D1_ROUNDED_RECT& rounded, const D2D1_COLOR_F& color) noexcept
{
    auto* dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    if (auto* brush = host.GetSolidBrush(color))
    {
        dc->FillRoundedRectangle(&rounded, brush);
    }
}

void DrawRoundedRectWithColor(ControlHost& host, const D2D1_ROUNDED_RECT& rounded, const D2D1_COLOR_F& color, float strokeWidth) noexcept
{
    auto* dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    if (auto* brush = host.GetSolidBrush(color))
    {
        dc->DrawRoundedRectangle(&rounded, brush, strokeWidth);
    }
}

void FillRectangleWithColor(ControlHost& host, const D2D1_RECT_F& rect, const D2D1_COLOR_F& color) noexcept
{
    auto* dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    if (auto* brush = host.GetSolidBrush(color))
    {
        dc->FillRectangle(rect, brush);
    }
}

void DrawLineWithColor(ControlHost& host, D2D1_POINT_2F from, D2D1_POINT_2F to, const D2D1_COLOR_F& color, float strokeWidth) noexcept
{
    auto* dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    if (auto* brush = host.GetSolidBrush(color))
    {
        dc->DrawLine(from, to, brush, strokeWidth);
    }
}

void FillEllipseWithColor(ControlHost& host, const D2D1_ELLIPSE& ellipse, const D2D1_COLOR_F& color) noexcept
{
    auto* dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    if (auto* brush = host.GetSolidBrush(color))
    {
        dc->FillEllipse(&ellipse, brush);
    }
}

void DrawEllipseWithColor(ControlHost& host, const D2D1_ELLIPSE& ellipse, const D2D1_COLOR_F& color, float strokeWidth) noexcept
{
    auto* dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    if (auto* brush = host.GetSolidBrush(color))
    {
        dc->DrawEllipse(&ellipse, brush, strokeWidth);
    }
}

void DrawRoundedRect(ControlHost& host, const D2D1_RECT_F& rect, const D2D1_COLOR_F& fill, const D2D1_COLOR_F& stroke, float radiusDip)
{
    const D2D1_RECT_F snappedRect = SnapRectToPixel(host, rect);
    const D2D1_ROUNDED_RECT rounded{snappedRect, radiusDip, radiusDip};
    FillRoundedRectWithColor(host, rounded, fill);
    if (stroke.a > 0.0f)
    {
        DrawRoundedRectWithColor(host, rounded, stroke, 1.0f);
    }
}

void DrawTopRoundedAttachedRect(ControlHost& host,
                                const D2D1_RECT_F& rect,
                                const D2D1_COLOR_F& fill,
                                const D2D1_COLOR_F& stroke,
                                float radiusDip,
                                float fillBottomExtensionDip,
                                float strokeBottomInsetDip)
{
    auto* dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    const D2D1_RECT_F fillRect   = SnapRectToPixel(host, D2D1::RectF(rect.left, rect.top, rect.right, rect.bottom + (std::max)(0.0f, fillBottomExtensionDip)));
    const D2D1_RECT_F strokeRect = SnapRectToPixel(host, rect);
    const float width            = (std::max)(0.0f, fillRect.right - fillRect.left);
    const float height           = (std::max)(0.0f, fillRect.bottom - fillRect.top);
    const float radius           = std::clamp(radiusDip, 0.0f, (std::min)(width * 0.5f, height));
    if (width <= 0.0f || height <= 0.0f)
    {
        return;
    }

    wil::com_ptr<ID2D1Factory> factory;
    dc->GetFactory(factory.addressof());
    if (! factory)
    {
        FillRectangleWithColor(host, fillRect, fill);
        return;
    }

    wil::com_ptr<ID2D1PathGeometry> fillGeometry;
    if (FAILED(factory->CreatePathGeometry(fillGeometry.addressof())) || ! fillGeometry)
    {
        FillRectangleWithColor(host, fillRect, fill);
        return;
    }

    wil::com_ptr<ID2D1GeometrySink> sink;
    if (FAILED(fillGeometry->Open(sink.addressof())) || ! sink)
    {
        FillRectangleWithColor(host, fillRect, fill);
        return;
    }

    sink->BeginFigure(D2D1::Point2F(fillRect.left, fillRect.bottom), D2D1_FIGURE_BEGIN_FILLED);
    sink->AddLine(D2D1::Point2F(fillRect.left, fillRect.top + radius));
    sink->AddArc(D2D1::ArcSegment(
        D2D1::Point2F(fillRect.left + radius, fillRect.top), D2D1::SizeF(radius, radius), 0.0f, D2D1_SWEEP_DIRECTION_CLOCKWISE, D2D1_ARC_SIZE_SMALL));
    sink->AddLine(D2D1::Point2F(fillRect.right - radius, fillRect.top));
    sink->AddArc(D2D1::ArcSegment(
        D2D1::Point2F(fillRect.right, fillRect.top + radius), D2D1::SizeF(radius, radius), 0.0f, D2D1_SWEEP_DIRECTION_CLOCKWISE, D2D1_ARC_SIZE_SMALL));
    sink->AddLine(D2D1::Point2F(fillRect.right, fillRect.bottom));
    sink->AddLine(D2D1::Point2F(fillRect.left, fillRect.bottom));
    sink->EndFigure(D2D1_FIGURE_END_CLOSED);
    if (FAILED(sink->Close()))
    {
        FillRectangleWithColor(host, fillRect, fill);
        return;
    }

    if (auto* fillBrush = host.GetSolidBrush(fill))
    {
        dc->FillGeometry(fillGeometry.get(), fillBrush);
    }

    if (stroke.a <= 0.0f)
    {
        return;
    }

    wil::com_ptr<ID2D1PathGeometry> strokeGeometry;
    if (FAILED(factory->CreatePathGeometry(strokeGeometry.addressof())) || ! strokeGeometry)
    {
        return;
    }

    wil::com_ptr<ID2D1GeometrySink> strokeSink;
    if (FAILED(strokeGeometry->Open(strokeSink.addressof())) || ! strokeSink)
    {
        return;
    }

    const float strokeBottom = std::clamp(SnapDipToPixel(host, rect.bottom - (std::max)(0.0f, strokeBottomInsetDip)), strokeRect.top + radius, fillRect.bottom);
    strokeSink->BeginFigure(D2D1::Point2F(strokeRect.left, strokeBottom), D2D1_FIGURE_BEGIN_HOLLOW);
    strokeSink->AddLine(D2D1::Point2F(strokeRect.left, strokeRect.top + radius));
    strokeSink->AddArc(D2D1::ArcSegment(
        D2D1::Point2F(strokeRect.left + radius, strokeRect.top), D2D1::SizeF(radius, radius), 0.0f, D2D1_SWEEP_DIRECTION_CLOCKWISE, D2D1_ARC_SIZE_SMALL));
    strokeSink->AddLine(D2D1::Point2F(strokeRect.right - radius, strokeRect.top));
    strokeSink->AddArc(D2D1::ArcSegment(
        D2D1::Point2F(strokeRect.right, strokeRect.top + radius), D2D1::SizeF(radius, radius), 0.0f, D2D1_SWEEP_DIRECTION_CLOCKWISE, D2D1_ARC_SIZE_SMALL));
    strokeSink->AddLine(D2D1::Point2F(strokeRect.right, strokeBottom));
    strokeSink->EndFigure(D2D1_FIGURE_END_OPEN);
    if (FAILED(strokeSink->Close()))
    {
        return;
    }

    if (auto* strokeBrush = host.GetSolidBrush(stroke))
    {
        dc->DrawGeometry(strokeGeometry.get(), strokeBrush, 1.0f);
    }
}

void PaintFocusRing(ControlHost& host, const D2D1_RECT_F& controlBounds, float controlCornerRadiusDip) noexcept
{
    const auto& palette = host.GetTheme();

    // Outer ring: 2 DIP outside control bounds, 2 DIP stroke width
    constexpr float outerOffset   = 2.0f;
    constexpr float outerStroke   = 2.0f;
    const float outerRadius       = controlCornerRadiusDip + outerOffset;
    const D2D1_RECT_F outerRect   = InflateRect(controlBounds, outerOffset, outerOffset);
    const D2D1_ROUNDED_RECT outer = D2D1::RoundedRect(outerRect, outerRadius, outerRadius);
    DrawRoundedRectWithColor(host, outer, palette.focusStrokeOuter, outerStroke);

    // Inner ring: 1 DIP outside control bounds, 1 DIP stroke width
    constexpr float innerOffset   = 1.0f;
    constexpr float innerStroke   = 1.0f;
    const float innerRadius       = controlCornerRadiusDip + innerOffset;
    const D2D1_RECT_F innerRect   = InflateRect(controlBounds, innerOffset, innerOffset);
    const D2D1_ROUNDED_RECT inner = D2D1::RoundedRect(innerRect, innerRadius, innerRadius);
    DrawRoundedRectWithColor(host, inner, palette.focusStrokeInner, innerStroke);
}

void DrawDropShadow(
    ControlHost& host, const D2D1_RECT_F& targetRect, float cornerRadiusDip, float yOffsetDip, float spreadDip, float outerOpacity, float innerOpacity) noexcept
{
    const D2D1_RECT_F innerTargetRect = D2D1::RectF(targetRect.left - 0.5f, targetRect.top - 0.5f, targetRect.right + 0.5f, targetRect.bottom + 0.5f);
    const float innerBlurDip          = (std::max)(1.0f, spreadDip * 0.4f);
    const float innerCornerRadiusDip  = cornerRadiusDip + 0.5f;

    const bool drewOuter = DrawShadowEffectPass(host, targetRect, cornerRadiusDip, yOffsetDip, spreadDip, outerOpacity);
    const bool drewInner = DrawShadowEffectPass(host, innerTargetRect, innerCornerRadiusDip, yOffsetDip, innerBlurDip, innerOpacity);
    if (! drewOuter || ! drewInner)
    {
        DrawFallbackShadowRoundedRects(host, targetRect, cornerRadiusDip, yOffsetDip, spreadDip, outerOpacity, innerOpacity);
    }
}

namespace
{
[[nodiscard]] float ResolveButtonChromeScale(float scale) noexcept
{
    return std::isfinite(scale) && scale > 0.0f ? scale : 1.0f;
}

[[nodiscard]] D2D1_RECT_F OffsetButtonChromeRect(const D2D1_RECT_F& rect, float dx, float dy) noexcept
{
    return D2D1::RectF(rect.left + dx, rect.top + dy, rect.right + dx, rect.bottom + dy);
}

[[nodiscard]] bool HasPaintableArea(const D2D1_RECT_F& rect) noexcept
{
    return rect.right > rect.left && rect.bottom > rect.top;
}

void DrawRawFocusRing(ID2D1RenderTarget* target, ID2D1SolidColorBrush* brush, const ThemePalette& theme, const D2D1_RECT_F& bounds, float cornerRadius) noexcept
{
    if (! target || ! brush || ! HasPaintableArea(bounds))
    {
        return;
    }

    const float scale = (std::max)(0.01f, cornerRadius / kButtonCornerRadiusDip);

    const float outerOffset     = 2.0f * scale;
    const float outerStroke     = 2.0f * scale;
    const D2D1_RECT_F outerRect = D2D1::RectF(bounds.left - outerOffset, bounds.top - outerOffset, bounds.right + outerOffset, bounds.bottom + outerOffset);
    const float outerRadius     = cornerRadius + outerOffset;
    brush->SetColor(theme.focusStrokeOuter);
    target->DrawRoundedRectangle(D2D1::RoundedRect(outerRect, outerRadius, outerRadius), brush, outerStroke);

    const float innerOffset     = 1.0f * scale;
    const float innerStroke     = 1.0f * scale;
    const D2D1_RECT_F innerRect = D2D1::RectF(bounds.left - innerOffset, bounds.top - innerOffset, bounds.right + innerOffset, bounds.bottom + innerOffset);
    const float innerRadius     = cornerRadius + innerOffset;
    brush->SetColor(theme.focusStrokeInner);
    target->DrawRoundedRectangle(D2D1::RoundedRect(innerRect, innerRadius, innerRadius), brush, innerStroke);
}

void DrawSingleFocusRing(ID2D1RenderTarget* target,
                         ID2D1SolidColorBrush* brush,
                         const D2D1_RECT_F& bounds,
                         const D2D1_COLOR_F& color,
                         float cornerRadius,
                         float focusOutset,
                         float focusStroke) noexcept
{
    if (! target || ! brush || ! HasPaintableArea(bounds) || focusStroke <= 0.0f)
    {
        return;
    }

    const D2D1_RECT_F focusRect = D2D1::RectF(bounds.left - focusOutset, bounds.top - focusOutset, bounds.right + focusOutset, bounds.bottom + focusOutset);
    brush->SetColor(color);
    target->DrawRoundedRectangle(D2D1::RoundedRect(focusRect, cornerRadius + focusOutset, cornerRadius + focusOutset), brush, focusStroke);
}

void DrawRawCenteredText(ID2D1RenderTarget* target,
                         ID2D1SolidColorBrush* brush,
                         IDWriteTextFormat* format,
                         std::wstring_view text,
                         const D2D1_RECT_F& rect,
                         const D2D1_COLOR_F& color) noexcept
{
    if (! target || ! brush || ! format || text.empty() || ! HasPaintableArea(rect))
    {
        return;
    }

    brush->SetColor(color);
    target->DrawTextW(text.data(), static_cast<UINT32>(text.size()), format, rect, brush, kTextDrawOptions, DWRITE_MEASURING_MODE_NATURAL);
}

} // namespace

float GetButtonChromeDropDownSegmentWidthDip(ButtonVariant variant) noexcept
{
    switch (variant)
    {
        case ButtonVariant::DropDown: return kButtonDropDownChevronWidthDip;
        case ButtonVariant::Selector: return kButtonSelectorChevronWidthDip;
        case ButtonVariant::Split: return kButtonSplitDropDownSegmentDip;
        case ButtonVariant::Standard:
        case ButtonVariant::Hyperlink:
        case ButtonVariant::IconOnly:
        case ButtonVariant::Disclosure:
        case ButtonVariant::Repeat: return 0.0f;
    }

    return 0.0f;
}

ButtonChromeLayout ComputeButtonChromeLayout(const D2D1_RECT_F& bounds, ButtonVariant variant, float scale) noexcept
{
    ButtonChromeLayout layout{};
    layout.textRect = bounds;

    const float segmentWidth = GetButtonChromeDropDownSegmentWidthDip(variant) * ResolveButtonChromeScale(scale);
    if (segmentWidth <= 0.0f)
    {
        return layout;
    }

    const float segmentLeft = (std::max)(bounds.left, bounds.right - segmentWidth);
    layout.hasChevron       = true;
    layout.chevronRect      = D2D1::RectF(segmentLeft, bounds.top, bounds.right, bounds.bottom);
    layout.textRect.right   = segmentLeft;

    if (variant == ButtonVariant::Selector)
    {
        // Balance the trailing chevron with an empty leading lane so the current
        // value remains optically centered across the complete selector.
        layout.textRect.left = (std::min)(segmentLeft, bounds.left + segmentWidth);
    }

    if (variant == ButtonVariant::Split)
    {
        layout.hasDivider = true;
        layout.dividerX   = segmentLeft;
    }

    return layout;
}

ButtonChromeResolvedStyle ResolveButtonChromeResolvedStyle(const ThemePalette& theme, const ButtonChromeDrawSpec& spec) noexcept
{
    const float hoverStrength = spec.hoverStrength >= 0.0f ? spec.hoverStrength : (spec.hovered ? 1.0f : 0.0f);
    const float focusStrength = spec.focusStrength >= 0.0f ? spec.focusStrength : (spec.focused ? 1.0f : 0.0f);

    if (spec.customStyle.has_value())
    {
        const ButtonChromeCustomStyle& custom = spec.customStyle.value();
        ButtonChromeResolvedStyle resolved{};
        resolved.fill            = custom.fill;
        resolved.border          = custom.border;
        resolved.focus           = custom.focus;
        resolved.text            = custom.text;
        resolved.chevron         = custom.text;
        resolved.showFill        = custom.showFill && custom.fill.a > 0.0f;
        resolved.showBorder      = custom.showBorder && custom.border.a > 0.0f;
        resolved.showFocus       = custom.showFocus && custom.focus.a > 0.0f;
        resolved.cornerRadiusDip = (std::max)(0.0f, custom.cornerRadiusDip);
        resolved.borderStrokeDip = (std::max)(0.0f, custom.borderStrokeDip);
        resolved.focusOutsetDip  = (std::max)(0.0f, custom.focusOutsetDip);
        resolved.focusStrokeDip  = (std::max)(0.0f, custom.focusStrokeDip);
        resolved.textOffsetXDip  = custom.textOffsetXDip;
        resolved.textOffsetYDip  = custom.textOffsetYDip;
        resolved.focusRing       = custom.focusRing;
        return resolved;
    }

    const ButtonVisualStyle style = ResolveButtonVisualStyle(
        theme, spec.enabled, spec.hovered, spec.pressed, spec.focused, spec.keyboardFocused, spec.primary, hoverStrength, focusStrength);
    ButtonChromeResolvedStyle resolved{};
    resolved.fill            = style.fill;
    resolved.border          = style.border;
    resolved.focus           = style.focus;
    resolved.text            = style.text;
    resolved.chevron         = style.text;
    resolved.showFill        = true;
    resolved.showBorder      = style.showBorder && style.border.a > 0.0f;
    resolved.showFocus       = style.showFocus;
    resolved.cornerRadiusDip = kButtonCornerRadiusDip;
    resolved.borderStrokeDip = 1.0f;
    resolved.focusOutsetDip  = 2.0f;
    resolved.focusStrokeDip  = 2.0f;
    resolved.textOffsetXDip  = style.textOffsetXDip;
    resolved.textOffsetYDip  = style.textOffsetYDip;
    resolved.focusRing       = ButtonChromeFocusRing::Standard;

    if (spec.variant == ButtonVariant::Selector)
    {
        const float chevronEmphasis = spec.pressed ? 1.0f : (std::clamp)(hoverStrength, 0.0f, 1.0f);
        resolved.chevron            = BlendColor(spec.enabled ? theme.subduedText : theme.disabledText, resolved.text, chevronEmphasis);
        resolved.cornerRadiusDip    = 6.0f;
        resolved.textOffsetXDip     = 0.0f;
        resolved.textOffsetYDip     = 0.0f;
    }
    return resolved;
}

void DrawButtonChrome(ID2D1RenderTarget* target,
                      ID2D1SolidColorBrush* brush,
                      IDWriteTextFormat* textFormat,
                      IDWriteTextFormat* iconFormat,
                      const ThemePalette& theme,
                      const ButtonChromeDrawSpec& spec) noexcept
{
    if (! target || ! brush || ! HasPaintableArea(spec.bounds))
    {
        return;
    }

    const float scale                     = ResolveButtonChromeScale(spec.scale);
    const ButtonChromeResolvedStyle style = ResolveButtonChromeResolvedStyle(theme, spec);
    const float cornerRadius              = style.cornerRadiusDip * scale;
    const D2D1_ROUNDED_RECT roundedButton = D2D1::RoundedRect(spec.bounds, cornerRadius, cornerRadius);
    const ButtonChromeLayout layout       = ComputeButtonChromeLayout(spec.bounds, spec.variant, scale);
    const float offsetX                   = style.textOffsetXDip * scale;
    const float offsetY                   = style.textOffsetYDip * scale;
    const float borderStroke              = style.borderStrokeDip * scale;
    const bool drawBorder                 = style.showBorder && borderStroke > 0.0f && style.border.a > 0.0f;

    if (style.showFill && style.fill.a > 0.0f)
    {
        brush->SetColor(style.fill);
        target->FillRoundedRectangle(roundedButton, brush);
    }

    if (drawBorder)
    {
        brush->SetColor(style.border);
        target->DrawRoundedRectangle(roundedButton, brush, borderStroke);
    }

    if (style.showFocus)
    {
        if (style.focusRing == ButtonChromeFocusRing::Standard)
        {
            // The Standard two-stroke ring is painted from the palette's focus
            // strokes; callers passing a transparent/default-constructed palette
            // would get an invisible or wrong-theme ring.
            if (theme.focusStrokeOuter.a <= 0.0f && theme.focusStrokeInner.a <= 0.0f)
            {
                Debug::Error(L"DrawButtonChrome: a Standard focus ring requires a palette with visible focus strokes.");
            }
            DrawRawFocusRing(target, brush, theme, spec.bounds, cornerRadius);
        }
        else
        {
            DrawSingleFocusRing(target, brush, spec.bounds, style.focus, cornerRadius, style.focusOutsetDip * scale, style.focusStrokeDip * scale);
        }
    }

    if (spec.variant == ButtonVariant::IconOnly)
    {
        DrawRawCenteredText(target, brush, iconFormat ? iconFormat : textFormat, spec.text, OffsetButtonChromeRect(spec.bounds, offsetX, offsetY), style.text);
        return;
    }

    if (layout.hasDivider)
    {
        brush->SetColor(style.border);
        const float lineInset = 6.0f * scale;
        target->DrawLine(
            D2D1::Point2F(layout.dividerX, spec.bounds.top + lineInset), D2D1::Point2F(layout.dividerX, spec.bounds.bottom - lineInset), brush, 1.0f * scale);
    }

    const D2D1_RECT_F textRect = OffsetButtonChromeRect(layout.textRect, offsetX, offsetY);
    DrawRawCenteredText(target, brush, textFormat, spec.text, textRect, style.text);

    if (layout.hasChevron)
    {
        const wchar_t chevronText[2]{spec.chevronGlyph != L'\0' ? spec.chevronGlyph : kButtonDropDownChevronGlyph, L'\0'};
        DrawRawCenteredText(target, brush, iconFormat ? iconFormat : textFormat, std::wstring_view(chevronText, 1u), layout.chevronRect, style.chevron);
    }
}

void DrawCenteredText(ControlHost& host,
                      std::wstring_view text,
                      const D2D1_RECT_F& rect,
                      FontRole fontRole,
                      const D2D1_COLOR_F& color,
                      DWRITE_TEXT_ALIGNMENT alignment,
                      DWRITE_PARAGRAPH_ALIGNMENT paragraphAlignment,
                      bool wrap,
                      FlowDirection flowDirection)
{
    auto* dc     = host.GetDeviceContext();
    auto* format = host.GetTextFormat(fontRole, alignment, paragraphAlignment, wrap, ResolveReadingDirection(flowDirection));
    if (! dc || ! format)
    {
        return;
    }

    if (auto* brush = host.GetSolidBrush(color))
    {
        dc->DrawTextW(text.data(), static_cast<UINT32>(text.size()), format, rect, brush, kTextDrawOptions, DWRITE_MEASURING_MODE_NATURAL);
    }
}

void DrawChevronGlyph(ControlHost& host, const D2D1_RECT_F& rect, ChevronDirection direction, const D2D1_COLOR_F& color) noexcept
{
    if (! host.GetDeviceContext() || rect.right <= rect.left || rect.bottom <= rect.top)
    {
        return;
    }

    constexpr wchar_t kFluentChevronLeft    = L'\uE76B';
    constexpr wchar_t kFluentChevronUp      = L'\uE70E';
    constexpr wchar_t kFluentChevronRight   = L'\uE76C';
    constexpr wchar_t kFluentChevronDown    = L'\uE70D';
    constexpr wchar_t kFallbackChevronLeft  = L'\u2039';
    constexpr wchar_t kFallbackChevronUp    = L'\u25B4';
    constexpr wchar_t kFallbackChevronRight = L'\u203A';
    constexpr wchar_t kFallbackChevronDown  = L'\u25BE';

    const bool useFluent = host.HasFluentIconFont();
    wchar_t glyph        = useFluent ? kFluentChevronDown : kFallbackChevronDown;
    switch (direction)
    {
        case ChevronDirection::Left: glyph = useFluent ? kFluentChevronLeft : kFallbackChevronLeft; break;
        case ChevronDirection::Up: glyph = useFluent ? kFluentChevronUp : kFallbackChevronUp; break;
        case ChevronDirection::Right: glyph = useFluent ? kFluentChevronRight : kFallbackChevronRight; break;
        case ChevronDirection::Down: break;
        default: break;
    }

    DrawCenteredText(host, std::wstring_view(&glyph, 1u), rect, useFluent ? FontRole::Icon : FontRole::Small, color);
}

void DrawDisclosureChevron(
    ControlHost& host, const D2D1_RECT_F& rect, float expandedProgress, const D2D1_COLOR_F& color, ChevronDirection collapsedDirection) noexcept
{
    auto* context = host.GetDeviceContext();
    if (! context || rect.right <= rect.left || rect.bottom <= rect.top)
    {
        return;
    }

    const DisclosureChevronVisualState visual = ResolveDisclosureChevronVisualState(expandedProgress, collapsedDirection);
    if (visual.rotationDegrees == 0.0f)
    {
        DrawChevronGlyph(host, rect, visual.direction, color);
        return;
    }

    D2D1_MATRIX_3X2_F previousTransform{};
    context->GetTransform(&previousTransform);
    const D2D1_POINT_2F center = D2D1::Point2F((rect.left + rect.right) * 0.5f, (rect.top + rect.bottom) * 0.5f);
    context->SetTransform(D2D1::Matrix3x2F::Rotation(visual.rotationDegrees, center) * previousTransform);
    auto restoreTransform = wil::scope_exit([&] { context->SetTransform(previousTransform); });

    DrawChevronGlyph(host, rect, visual.direction, color);
}

DisclosureChevronVisualState ResolveDisclosureChevronVisualState(float expandedProgress, ChevronDirection collapsedDirection) noexcept
{
    collapsedDirection   = collapsedDirection == ChevronDirection::Left ? ChevronDirection::Left : ChevronDirection::Right;
    const float progress = std::clamp(expandedProgress, 0.0f, 1.0f);
    if (progress <= 0.0f)
    {
        return {.direction = collapsedDirection};
    }
    if (progress >= 1.0f)
    {
        return {.direction = ChevronDirection::Down};
    }

    const float rotationDegrees = collapsedDirection == ChevronDirection::Left ? -90.0f * progress : 90.0f * progress;
    return {.direction = collapsedDirection, .rotationDegrees = rotationDegrees};
}

void DrawTextWithMnemonic(ControlHost& host,
                          std::wstring_view text,
                          const D2D1_RECT_F& rect,
                          FontRole fontRole,
                          const D2D1_COLOR_F& color,
                          wchar_t mnemonic,
                          DWRITE_TEXT_ALIGNMENT alignment,
                          DWRITE_PARAGRAPH_ALIGNMENT paragraphAlignment,
                          bool wrap,
                          FlowDirection flowDirection)
{
    const std::optional<size_t> mnemonicIndex = FindMnemonicTextIndex(text, mnemonic);
    if (! mnemonicIndex)
    {
        DrawCenteredText(host, text, rect, fontRole, color, alignment, paragraphAlignment, wrap, flowDirection);
        return;
    }

    auto* dc      = host.GetDeviceContext();
    auto* format  = host.GetTextFormat(fontRole, alignment, paragraphAlignment, wrap, ResolveReadingDirection(flowDirection));
    auto* factory = host.GetWriteFactory();
    auto* brush   = host.GetSolidBrush(color);
    if (! dc || ! format || ! factory || ! brush)
    {
        DrawCenteredText(host, text, rect, fontRole, color, alignment, paragraphAlignment, wrap, flowDirection);
        return;
    }

    const float width  = (std::max)(1.0f, rect.right - rect.left);
    const float height = (std::max)(1.0f, rect.bottom - rect.top);
    wil::com_ptr<IDWriteTextLayout> layout;
    if (FAILED(factory->CreateTextLayout(text.data(), static_cast<UINT32>(text.size()), format, width, height, layout.addressof())) || ! layout)
    {
        DrawCenteredText(host, text, rect, fontRole, color, alignment, paragraphAlignment, wrap, flowDirection);
        return;
    }

    const DWRITE_TEXT_RANGE range{static_cast<UINT32>(*mnemonicIndex), 1u};
    static_cast<void>(layout->SetUnderline(TRUE, range));
    dc->DrawTextLayout(D2D1::Point2F(rect.left, rect.top), layout.get(), brush, kTextDrawOptions);
}

std::wstring_view GetCheckboxCheckGlyph(const ControlHost& host) noexcept
{
    return host.HasFluentIconFont() ? kFluentCheckGlyph : kFallbackCheckGlyph;
}

FontRole GetCheckboxCheckFontRole(const ControlHost& host) noexcept
{
    return host.HasFluentIconFont() ? FontRole::Icon : FontRole::Small;
}

DWRITE_READING_DIRECTION ResolveReadingDirection(FlowDirection flowDirection) noexcept
{
    return flowDirection == FlowDirection::RightToLeft ? DWRITE_READING_DIRECTION_RIGHT_TO_LEFT : DWRITE_READING_DIRECTION_LEFT_TO_RIGHT;
}

float ResolveConstrainedExtent(const LayoutConstraint& constraint, float availableExtent) noexcept
{
    const float available = (std::max)(0.0f, availableExtent);
    const float minExtent = (std::max)(0.0f, constraint.minExtent);
    const float maxExtent = (std::max)(minExtent, constraint.maxExtent);
    if (available <= minExtent)
    {
        return available;
    }

    const float preferredExtent = (std::clamp)(constraint.preferredExtent, minExtent, maxExtent);
    return (std::clamp)(preferredExtent, minExtent, (std::min)(available, maxExtent));
}

constexpr float kToggleTrackWidthDip           = 34.0f;
constexpr float kToggleTrackHeightDip          = 20.0f;
constexpr float kToggleKnobDiameterDip         = 16.0f;
constexpr float kToggleKnobInsetDip            = 2.0f;
constexpr float kToggleRowPaddingXDip          = 6.0f;
constexpr float kToggleTextTrackGapDip         = 8.0f;
constexpr float kToggleTrackTrailingPaddingDip = 4.0f;

[[nodiscard]] ToggleLayoutMetrics BuildToggleLayoutMetrics(const D2D1_RECT_F& bounds, bool checked, bool compactSwitchOnly) noexcept
{
    ToggleLayoutMetrics metrics{};
    metrics.compactSwitchOnly = compactSwitchOnly;

    const D2D1_RECT_F rowRect = D2D1::RectF(bounds.left + 1.0f, bounds.top + 1.0f, bounds.right - 1.0f, bounds.bottom - 1.0f);
    metrics.backgroundRect    = rowRect;

    const float trackTop  = rowRect.top + ((rowRect.bottom - rowRect.top - kToggleTrackHeightDip) * 0.5f);
    const float trackLeft = compactSwitchOnly ? (rowRect.left + ((rowRect.right - rowRect.left - kToggleTrackWidthDip) * 0.5f))
                                              : (rowRect.right - kToggleTrackWidthDip - kToggleTrackTrailingPaddingDip);
    metrics.trackRect     = D2D1::RectF(trackLeft, trackTop, trackLeft + kToggleTrackWidthDip, trackTop + kToggleTrackHeightDip);

    if (compactSwitchOnly)
    {
        const D2D1_RECT_F compactBackground =
            D2D1::RectF(metrics.trackRect.left - 8.0f, metrics.trackRect.top - 6.0f, metrics.trackRect.right + 8.0f, metrics.trackRect.bottom + 6.0f);
        metrics.backgroundRect = D2D1::RectF((std::max)(rowRect.left, compactBackground.left),
                                             (std::max)(rowRect.top, compactBackground.top),
                                             (std::min)(rowRect.right, compactBackground.right),
                                             (std::min)(rowRect.bottom, compactBackground.bottom));
        metrics.textRect       = D2D1::RectF(metrics.backgroundRect.left, metrics.backgroundRect.top, metrics.backgroundRect.left, metrics.backgroundRect.top);
    }
    else
    {
        const float textLeft  = rowRect.left + kToggleRowPaddingXDip;
        const float textRight = (std::max)(textLeft, metrics.trackRect.left - kToggleTextTrackGapDip);
        metrics.textRect      = D2D1::RectF(textLeft, rowRect.top + 2.0f, textRight, rowRect.bottom - 2.0f);
    }

    metrics.focusRect    = InflateRect(metrics.backgroundRect, -1.5f, -1.5f);
    const float knobLeft = checked ? (metrics.trackRect.right - kToggleKnobInsetDip - kToggleKnobDiameterDip) : (metrics.trackRect.left + kToggleKnobInsetDip);
    metrics.knobRect     = D2D1::RectF(knobLeft,
                                       metrics.trackRect.top + kToggleKnobInsetDip,
                                       knobLeft + kToggleKnobDiameterDip,
                                       metrics.trackRect.top + kToggleKnobInsetDip + kToggleKnobDiameterDip);
    return metrics;
}

void Panel::DetachChildPreservingInheritance(Control& child) noexcept
{
    child._detachedFlowDirection = child.GetFlowDirection();
    child._detachedDensity       = child.GetDensity();
    child._parent                = nullptr;
    child.PropagateHost(nullptr);
}

std::unique_ptr<Control> Panel::TakeChild(size_t index) noexcept
{
    if (index >= _children.size() || ! _children[index])
        return {};

    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    Control* const requested               = _children[index].get();
    const std::weak_ptr<int> childLifetime = requested->GetLifetimeToken();
    ControlHost* const host                = GetHost();
    if (host)
    {
        if (Control* captured = host->GetCapturedControl(); captured && IsControlInTree(requested, captured))
            host->CancelCapturedControlInteraction();
        if (ownerLifetime.expired() || childLifetime.expired())
            return {};
        if (Control* focused = host->GetFocusControl(); focused && IsControlInTree(requested, focused))
            host->SetFocusControl(nullptr);
        if (ownerLifetime.expired() || childLifetime.expired())
            return {};
    }

    // Focus/capture callbacks can shift or remove the requested slot. Resolve its identity after those callbacks.
    for (auto& slot : _children)
    {
        if (slot.get() != requested)
            continue;
        auto child = std::move(slot);
        DetachChildPreservingInheritance(*child);
        if (childLifetime.expired())
        {
            static_cast<void>(child.release());
            return {};
        }
        if (! ownerLifetime.expired())
        {
            if (host)
                host->RefreshAccessibilitySnapshot();
            if (! ownerLifetime.expired())
                RequestInvalidate();
        }
        return child;
    }
    return {};
}

void Panel::ClearChildren() noexcept
{
    // Dispatch against the entry snapshot. Reentrant additions stay in the live panel while the original owners are
    // detached from it, so recursive ClearChildren calls cannot invalidate this pass.
    auto children = std::exchange(_children, std::vector<std::unique_ptr<Control>>{});
    for (auto& child : children)
    {
        if (child)
        {
            child->_parent                         = nullptr;
            const std::weak_ptr<int> childLifetime = GetControlLifetimeToken(*child);
            child->PropagateHost(nullptr);
            if (childLifetime.expired())
            {
                static_cast<void>(child.release());
            }
        }
    }
}

std::span<std::unique_ptr<Control>> Panel::GetChildren() noexcept
{
    return _children;
}

std::span<const std::unique_ptr<Control>> Panel::GetChildren() const noexcept
{
    return _children;
}

size_t Panel::GetLogicalChildCount() const noexcept
{
    return _children.size();
}

Control* Panel::GetLogicalChild(size_t index) noexcept
{
    return index < _children.size() ? _children[index].get() : nullptr;
}

const Control* Panel::GetLogicalChild(size_t index) const noexcept
{
    return index < _children.size() ? _children[index].get() : nullptr;
}

void Panel::PropagateHost(ControlHost* host) noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    Control::PropagateHost(host);
    if (ownerLifetime.expired())
    {
        return;
    }
    ForEachPanelChildCallback(*this, ownerLifetime, [host](Control& child) { child.PropagateHost(host); });
}

void Panel::OnFlowDirectionChanged() noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    Control::OnFlowDirectionChanged();
    if (ownerLifetime.expired())
    {
        return;
    }
    ForEachPanelChildCallback(*this, ownerLifetime, [](Control& child) { child.OnFlowDirectionChanged(); });
}

void Panel::OnDensityChanged() noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    Control::OnDensityChanged();
    if (ownerLifetime.expired())
    {
        return;
    }
    ForEachPanelChildCallback(*this,
                              ownerLifetime,
                              [](Control& child)
    {
        if (! child.HasExplicitDensity())
        {
            child.OnDensityChanged();
        }
    });
}

void Panel::OnHidden() noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    Control::OnHidden();
    if (ownerLifetime.expired())
    {
        return;
    }
    ForEachPanelChildCallback(*this, ownerLifetime, [](Control& child) { child.OnHidden(); });
}

void Panel::OnHostDpiChanged(ControlHost& host) noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    Control::OnHostDpiChanged(host);
    if (ownerLifetime.expired())
    {
        return;
    }
    ForEachPanelChildCallback(*this, ownerLifetime, [&host](Control& child) { child.OnHostDpiChanged(host); });
}

void Panel::Paint(ControlHost& host) const
{
    ForEachPanelChildCallback(*this,
                              GetLifetimeToken(),
                              [&host](const Control& child)
    {
        if (child.IsVisible())
        {
            child.Paint(host);
        }
    });
}

void Panel::PaintOverlay(ControlHost& host) const
{
    ForEachPanelChildCallback(*this,
                              GetLifetimeToken(),
                              [&host](const Control& child)
    {
        if (child.IsVisible())
        {
            child.PaintOverlay(host);
        }
    });
}

bool Panel::Tick(ControlHost& host, uint64_t nowTickMs)
{
    bool keepTicking         = false;
    const auto ownerLifetime = GetLifetimeToken();
    ForEachPanelChildCallback(*this,
                              ownerLifetime,
                              [&host, nowTickMs, &keepTicking](Control& child)
    {
        if (child.IsVisible())
        {
            keepTicking = child.Tick(host, nowTickMs) || keepTicking;
        }
    });
    return ! ownerLifetime.expired() && keepTicking;
}

Control* Panel::HitTest(D2D1_POINT_2F point)
{
    if (! Control::HitTest(point))
    {
        return nullptr;
    }

    const auto ownerLifetime = GetLifetimeToken();
    if (Control* const hit = FindPanelChildHit(*this, ownerLifetime, [point](Control& child) { return child.HitTest(point); }))
        return hit;
    return ownerLifetime.expired() ? nullptr : this;
}

const Control* Panel::HitTest(D2D1_POINT_2F point) const
{
    return const_cast<Panel*>(this)->HitTest(point);
}

Control* Panel::HitTestOverlay(D2D1_POINT_2F point)
{
    if (! IsVisible() || ! IsEnabled())
    {
        return nullptr;
    }

    return FindPanelChildHit(*this, GetLifetimeToken(), [point](Control& child) { return child.HitTestOverlay(point); });
}

const Control* Panel::HitTestOverlay(D2D1_POINT_2F point) const
{
    return const_cast<Panel*>(this)->HitTestOverlay(point);
}

void PageHost::SetPage(std::unique_ptr<Control> page, std::wstring connectedAnimationKey)
{
    const auto invalidateGeometry                    = ControlModelQueryAccess::InvalidateGeometry(*this);
    const std::weak_ptr<int> ownerLifetime           = GetLifetimeToken();
    Control* const expectedCurrent                   = _currentPage.get();
    Control* expectedOutgoing                        = _outgoingPage.get();
    const std::weak_ptr<int> expectedCurrentLifetime = expectedCurrent ? GetControlLifetimeToken(*expectedCurrent) : std::weak_ptr<int>{};
    std::weak_ptr<int> expectedOutgoingLifetime      = expectedOutgoing ? GetControlLifetimeToken(*expectedOutgoing) : std::weak_ptr<int>{};
    const auto rolesUnchanged = [this, expectedCurrent, &expectedOutgoing, &expectedCurrentLifetime, &expectedOutgoingLifetime]() noexcept
    {
        return _currentPage.get() == expectedCurrent && _outgoingPage.get() == expectedOutgoing &&
               (expectedCurrent == nullptr || ! expectedCurrentLifetime.expired()) && (expectedOutgoing == nullptr || ! expectedOutgoingLifetime.expired());
    };

    const std::weak_ptr<int> incomingLifetime = page ? GetControlLifetimeToken(*page) : std::weak_ptr<int>{};
    if (page)
    {
        if (IsRenderStageActive())
        {
            // The next explicit preparation applies the new page bounds; paint never performs layout.
            _childBoundsPending = true;
            if (auto* const host = GetHost())
                host->_pendingPageLayout = true;
        }
        else
        {
            page->SetBounds(GetBounds());
        }
        if (incomingLifetime.expired())
        {
            static_cast<void>(page.release());
            return;
        }
        if (ownerLifetime.expired())
        {
            return;
        }
        if (! rolesUnchanged())
        {
            return;
        }
        page->ReparentWithPreviousInheritance(this, GetHost(), page->GetFlowDirection(), page->GetDensity());
        if (incomingLifetime.expired())
        {
            static_cast<void>(page.release());
            return;
        }
        if (ownerLifetime.expired())
        {
            return;
        }
        if (! rolesUnchanged())
        {
            return;
        }
    }

    ControlHost* const host = GetHost();
    const bool animate      = host && _currentPage && page && ! host->GetTheme().reducedMotion;
    if (! animate)
    {
        if (_outgoingPage)
        {
            Control* const outgoing = _outgoingPage.get();
            outgoing->PropagateHost(nullptr);
            if (ownerLifetime.expired())
            {
                return;
            }
            if (_outgoingPage.get() != outgoing || ! rolesUnchanged())
            {
                return;
            }
            _outgoingPage.reset();
            expectedOutgoing = nullptr;
            expectedOutgoingLifetime.reset();
        }
        if (_currentPage)
        {
            Control* const current = _currentPage.get();
            current->PropagateHost(nullptr);
            if (ownerLifetime.expired())
            {
                return;
            }
            if (_currentPage.get() != current || ! rolesUnchanged())
            {
                return;
            }
        }
        if (ownerLifetime.expired() || ! rolesUnchanged())
        {
            return;
        }
        _currentPage = std::move(page);
        if (! FinishTransition())
        {
            return;
        }
        RequestInvalidate();
        return;
    }

    if (_outgoingPage)
    {
        Control* const outgoing = _outgoingPage.get();
        outgoing->PropagateHost(nullptr);
        if (ownerLifetime.expired())
        {
            return;
        }
        if (_outgoingPage.get() != outgoing || ! rolesUnchanged())
        {
            return;
        }
        _outgoingPage.reset();
        expectedOutgoing = nullptr;
        expectedOutgoingLifetime.reset();
    }

    if (ownerLifetime.expired() || ! rolesUnchanged())
    {
        return;
    }

    _outgoingPage                     = std::move(_currentPage);
    _currentPage                      = std::move(page);
    _transition.active                = true;
    _transition.startTickMs           = GetTickCount64();
    _transition.lastTickMs            = _transition.startTickMs;
    _transition.linearProgress        = 0.0f;
    _transition.hasConnectedAnimation = false;
    _transition.sourceRectDip         = D2D1::RectF();
    _transition.targetRectDip         = D2D1::RectF();
#if DXUI_ENABLE_DIAGNOSTICS
    _transition.debugFrozen         = false;
    _transition.debugFrozenProgress = 1.0f;
#endif

    if (! connectedAnimationKey.empty() && _outgoingPage && _currentPage)
    {
        if (const Control* const source = FindConnectedAnimationControl(_outgoingPage.get(), connectedAnimationKey))
        {
            if (const Control* const target = FindConnectedAnimationControl(_currentPage.get(), connectedAnimationKey))
            {
                _transition.sourceRectDip         = source->GetBounds();
                _transition.targetRectDip         = target->GetBounds();
                _transition.hasConnectedAnimation = true;
            }
        }
    }

    host->RequestAnimation();
    RequestInvalidate();
}

Control* PageHost::GetPage() noexcept
{
    return _currentPage.get();
}

const Control* PageHost::GetPage() const noexcept
{
    return _currentPage.get();
}

bool PageHost::HasActiveTransition() const noexcept
{
    return _transition.active;
}

void PageHost::PaintPage(ControlHost& host, const Control* page, float opacity, float offsetXDip) const
{
    auto* dc = host.GetDeviceContext();
    if (! dc || ! page || ! page->IsVisible())
    {
        return;
    }

    D2D1_MATRIX_3X2_F previousTransform{};
    dc->GetTransform(&previousTransform);
    auto restoreTransform = wil::scope_exit([dc, previousTransform] { dc->SetTransform(previousTransform); });
    wil::com_ptr<ID2D1Layer> layer;
    if (FAILED(dc->CreateLayer(layer.addressof())) || ! layer)
    {
        dc->SetTransform(D2D1::Matrix3x2F::Translation(offsetXDip, 0.0f) * previousTransform);
        page->Paint(host);
        return;
    }

    const D2D1_RECT_F clipRect                   = GetBounds();
    const D2D1_LAYER_PARAMETERS1 layerParameters = D2D1::LayerParameters1(
        clipRect, nullptr, D2D1_ANTIALIAS_MODE_PER_PRIMITIVE, D2D1::Matrix3x2F::Identity(), ClampUnit(opacity), nullptr, D2D1_LAYER_OPTIONS1_NONE);
    dc->SetTransform(D2D1::Matrix3x2F::Translation(offsetXDip, 0.0f) * previousTransform);
    dc->PushLayer(layerParameters, layer.get());
    auto restoreLayer = wil::scope_exit([dc] { dc->PopLayer(); });
    page->Paint(host);
}

PageHostDebugState PageHost::ResolveDebugState(const ThemePalette& theme, uint64_t nowTickMs) const noexcept
{
    PageHostDebugState state{};
    state.active                 = _transition.active;
    state.hasConnectedAnimation  = _transition.hasConnectedAnimation;
    state.startTickMs            = _transition.startTickMs;
    float resolvedLinearProgress = _transition.active && ! theme.reducedMotion ? ClampUnit(_transition.linearProgress) : 1.0f;
#if DXUI_ENABLE_DIAGNOSTICS
    if (_transition.active && _transition.debugFrozen)
    {
        resolvedLinearProgress = ClampUnit(_transition.debugFrozenProgress);
    }
#endif
    state.linearProgress         = resolvedLinearProgress;
    state.easedPageProgress      = theme.reducedMotion ? 1.0f : EvaluateEasing(EasingCurve::FastDecelerate, state.linearProgress);
    state.easedConnectedProgress = theme.reducedMotion ? 1.0f : EvaluateEasing(EasingCurve::PointToPoint, state.linearProgress);
    state.incomingOpacity        = _transition.active ? state.easedPageProgress : 1.0f;
    state.outgoingOpacity        = _transition.active ? (1.0f - state.easedPageProgress) : 0.0f;
    state.incomingOffsetXDip     = _transition.active ? Lerp(kIncomingOffsetXDip, 0.0f, state.easedPageProgress) : 0.0f;
    state.outgoingOffsetXDip     = _transition.active ? Lerp(0.0f, kOutgoingOffsetXDip, state.easedPageProgress) : 0.0f;
    state.currentConnectedRectDip =
        _transition.hasConnectedAnimation ? LerpRect(_transition.sourceRectDip, _transition.targetRectDip, state.easedConnectedProgress) : D2D1::RectF();

    if (_transition.active && _transition.lastTickMs == 0u && nowTickMs != 0u)
    {
        state.linearProgress         = ClampUnit(static_cast<float>(nowTickMs - _transition.startTickMs) / static_cast<float>(kPageTransitionDurationMs));
        state.easedPageProgress      = theme.reducedMotion ? 1.0f : EvaluateEasing(EasingCurve::FastDecelerate, state.linearProgress);
        state.easedConnectedProgress = theme.reducedMotion ? 1.0f : EvaluateEasing(EasingCurve::PointToPoint, state.linearProgress);
        state.incomingOpacity        = state.easedPageProgress;
        state.outgoingOpacity        = 1.0f - state.easedPageProgress;
        state.incomingOffsetXDip     = Lerp(kIncomingOffsetXDip, 0.0f, state.easedPageProgress);
        state.outgoingOffsetXDip     = Lerp(0.0f, kOutgoingOffsetXDip, state.easedPageProgress);
        state.currentConnectedRectDip =
            _transition.hasConnectedAnimation ? LerpRect(_transition.sourceRectDip, _transition.targetRectDip, state.easedConnectedProgress) : D2D1::RectF();
    }

    return state;
}

void PageHost::Paint(ControlHost& host) const
{
    const std::weak_ptr<int> ownerLifetime    = GetLifetimeToken();
    Control* const current                    = _currentPage.get();
    Control* const outgoing                   = _outgoingPage.get();
    const std::weak_ptr<int> currentLifetime  = current ? GetControlLifetimeToken(*current) : std::weak_ptr<int>{};
    const std::weak_ptr<int> outgoingLifetime = outgoing ? GetControlLifetimeToken(*outgoing) : std::weak_ptr<int>{};
    if (! current)
    {
        return;
    }

    const auto state = ResolveDebugState(host.GetTheme(), 0u);
    if (! state.active)
    {
        current->Paint(host);
        return;
    }

    Debug::Perf::Scope transitionPaintPerf(L"dxui.animation.page_transition.paint");
    transitionPaintPerf.SetValue0(static_cast<uint64_t>(state.linearProgress * 1000.0f));
    transitionPaintPerf.SetValue1(_transition.hasConnectedAnimation ? 1u : 0u);

    if (outgoing)
    {
        PaintPage(host, outgoing, state.outgoingOpacity, state.outgoingOffsetXDip);
        if (ownerLifetime.expired() || currentLifetime.expired() || _currentPage.get() != current || outgoingLifetime.expired() ||
            _outgoingPage.get() != outgoing || ! _transition.active)
        {
            return;
        }
    }
    if (! ownerLifetime.expired() && ! currentLifetime.expired() && _currentPage.get() == current)
    {
        PaintPage(host, current, state.incomingOpacity, state.incomingOffsetXDip);
    }
}

void PageHost::PaintOverlay(ControlHost& host) const
{
    const std::weak_ptr<int> ownerLifetime    = GetLifetimeToken();
    Control* const current                    = _currentPage.get();
    Control* const outgoing                   = _outgoingPage.get();
    const std::weak_ptr<int> currentLifetime  = current ? GetControlLifetimeToken(*current) : std::weak_ptr<int>{};
    const std::weak_ptr<int> outgoingLifetime = outgoing ? GetControlLifetimeToken(*outgoing) : std::weak_ptr<int>{};
    if (! current)
    {
        return;
    }

    const auto state = ResolveDebugState(host.GetTheme(), 0u);
    auto* dc         = host.GetDeviceContext();
    if (! state.active)
    {
        current->PaintOverlay(host);
        return;
    }

    bool pagesStillCurrent   = true;
    const auto validatePages = [&]() noexcept
    {
        pagesStillCurrent = ! ownerLifetime.expired() && ! currentLifetime.expired() && _currentPage.get() == current;
        if (outgoing)
        {
            pagesStillCurrent = pagesStillCurrent && ! outgoingLifetime.expired() && _outgoingPage.get() == outgoing && _transition.active;
        }
        return pagesStillCurrent;
    };

    const auto paintOverlayLayer = [&](const Control* page, float opacity, float offsetXDip)
    {
        if (! dc || ! page || ! page->IsVisible())
        {
            return;
        }

        if (! validatePages())
            return;
        D2D1_MATRIX_3X2_F previousTransform{};
        dc->GetTransform(&previousTransform);
        auto restoreTransform = wil::scope_exit([dc, previousTransform] { dc->SetTransform(previousTransform); });
        wil::com_ptr<ID2D1Layer> layer;
        if (FAILED(dc->CreateLayer(layer.addressof())) || ! layer)
        {
            dc->SetTransform(D2D1::Matrix3x2F::Translation(offsetXDip, 0.0f) * previousTransform);
            page->PaintOverlay(host);
            static_cast<void>(validatePages());
            return;
        }

        const D2D1_LAYER_PARAMETERS1 layerParameters =
            D2D1::LayerParameters1(GetBounds(), nullptr, D2D1_ANTIALIAS_MODE_PER_PRIMITIVE, D2D1::Matrix3x2F::Identity(), ClampUnit(opacity));
        dc->SetTransform(D2D1::Matrix3x2F::Translation(offsetXDip, 0.0f) * previousTransform);
        dc->PushLayer(layerParameters, layer.get());
        auto restoreLayer = wil::scope_exit([dc] { dc->PopLayer(); });
        page->PaintOverlay(host);
        static_cast<void>(validatePages());
    };

    if (outgoing)
    {
        paintOverlayLayer(outgoing, state.outgoingOpacity, state.outgoingOffsetXDip);
        if (! validatePages())
            return;
    }
    paintOverlayLayer(current, state.incomingOpacity, state.incomingOffsetXDip);
    if (! validatePages())
        return;

    if (! dc || ! _transition.hasConnectedAnimation)
    {
        return;
    }

    const D2D1_RECT_F animatedRect = state.currentConnectedRectDip;
    if (animatedRect.right <= animatedRect.left || animatedRect.bottom <= animatedRect.top)
    {
        return;
    }

    Debug::Perf::Scope connectedPaintPerf(L"dxui.animation.connected_overlay.paint");
    connectedPaintPerf.SetValue0(static_cast<uint64_t>(state.easedConnectedProgress * 1000.0f));

    const ThemePalette& theme = host.GetTheme();
    const D2D1_COLOR_F fill   = D2D1::ColorF(theme.accent.r, theme.accent.g, theme.accent.b, theme.highContrast ? 0.20f : 0.12f);
    const D2D1_COLOR_F stroke = D2D1::ColorF(theme.accent.r, theme.accent.g, theme.accent.b, theme.highContrast ? 0.90f : 0.65f);
    DrawRoundedRect(host, animatedRect, fill, stroke, ResolveConnectedOverlayCornerRadius(animatedRect));
}

bool PageHost::Tick(ControlHost& host, uint64_t nowTickMs)
{
    const std::weak_ptr<int> ownerLifetime    = GetLifetimeToken();
    Control* const current                    = _currentPage.get();
    Control* const outgoing                   = _outgoingPage.get();
    const std::weak_ptr<int> currentLifetime  = current ? GetControlLifetimeToken(*current) : std::weak_ptr<int>{};
    const std::weak_ptr<int> outgoingLifetime = outgoing ? GetControlLifetimeToken(*outgoing) : std::weak_ptr<int>{};
    bool keepTicking                          = false;
    if (current && ! currentLifetime.expired() && current->IsVisible())
    {
        keepTicking = current->Tick(host, nowTickMs) || keepTicking;
        if (ownerLifetime.expired())
        {
            return false;
        }
    }
    if (outgoing && outgoing != current && ! outgoingLifetime.expired() && (_currentPage.get() == outgoing || _outgoingPage.get() == outgoing) &&
        outgoing->IsVisible())
    {
        keepTicking = outgoing->Tick(host, nowTickMs) || keepTicking;
        if (ownerLifetime.expired())
        {
            return false;
        }
    }

    if (ownerLifetime.expired())
    {
        return false;
    }
    if (host.GetTheme().reducedMotion)
    {
        if (_transition.active)
        {
            if (! FinishTransition())
            {
                return false;
            }
            Invalidate(host);
            return true;
        }
        return keepTicking;
    }

    if (! _transition.active)
    {
        return keepTicking;
    }

#if DXUI_ENABLE_DIAGNOSTICS
    if (_transition.debugFrozen)
    {
        const float frozenProgress = ClampUnit(_transition.debugFrozenProgress);
        if (_transition.linearProgress != frozenProgress)
        {
            _transition.linearProgress = frozenProgress;
            Invalidate(host);
        }
        return keepTicking;
    }
#endif

    _transition.lastTickMs     = nowTickMs;
    _transition.linearProgress = ClampUnit(static_cast<float>(nowTickMs - _transition.startTickMs) / static_cast<float>(kPageTransitionDurationMs));
    if (_transition.linearProgress >= 1.0f)
    {
        if (! FinishTransition())
        {
            return false;
        }
    }
    // Every transition tick moves the pages, including the tick that settles them into their final state.
    Invalidate(host);
    return true;
}

size_t PageHost::GetLogicalChildCount() const noexcept
{
    return _currentPage ? 1u : 0u;
}

Control* PageHost::GetLogicalChild(size_t index) noexcept
{
    return index == 0u ? _currentPage.get() : nullptr;
}

const Control* PageHost::GetLogicalChild(size_t index) const noexcept
{
    return index == 0u ? _currentPage.get() : nullptr;
}

#if DXUI_ENABLE_DIAGNOSTICS
PageHostDebugState PageHost::DebugGetTransitionState(uint64_t nowTickMs) const noexcept
{
    const ThemePalette theme = GetHost() ? GetHost()->GetTheme() : MakeDefaultThemePalette(false);
    return ResolveDebugState(theme, nowTickMs);
}

void PageHost::DebugFreezeTransitionProgress(float linearProgress) noexcept
{
    if (! _transition.active)
    {
        return;
    }

    _transition.debugFrozen         = true;
    _transition.debugFrozenProgress = ClampUnit(linearProgress);
    _transition.linearProgress      = _transition.debugFrozenProgress;
}

void PageHost::DebugUnfreezeTransitionProgress() noexcept
{
    _transition.debugFrozen = false;
}
#endif

Control* PageHost::HitTest(D2D1_POINT_2F point)
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    if (! Control::HitTest(point))
    {
        return nullptr;
    }

    if (_transition.active)
    {
        return nullptr;
    }

    Control* const page = _currentPage.get();
    if (page)
    {
        const std::weak_ptr<int> pageLifetime = GetControlLifetimeToken(*page);
        Control* const hit                    = page->HitTest(point);
        if (ownerLifetime.expired())
            return nullptr;
        if (pageLifetime.expired() || _currentPage.get() != page || _transition.active)
        {
            return _transition.active ? nullptr : this;
        }
        if (hit && ControlBelongsToBranch(page, hit) && IsControlEffectivelyInteractive(page, hit))
        {
            return hit;
        }
    }

    return this;
}

const Control* PageHost::HitTest(D2D1_POINT_2F point) const
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    if (! Control::HitTest(point))
    {
        return nullptr;
    }

    if (_transition.active)
    {
        return nullptr;
    }

    const Control* const page = _currentPage.get();
    if (page)
    {
        const std::weak_ptr<int> pageLifetime = GetControlLifetimeToken(*page);
        const Control* const hit              = page->HitTest(point);
        if (ownerLifetime.expired())
            return nullptr;
        if (pageLifetime.expired() || _currentPage.get() != page || _transition.active)
        {
            return _transition.active ? nullptr : this;
        }
        if (hit && ControlBelongsToBranch(page, hit) && IsControlEffectivelyInteractive(page, hit))
        {
            return hit;
        }
    }

    return this;
}

Control* PageHost::HitTestOverlay(D2D1_POINT_2F point)
{
    if (_transition.active || ! IsVisible() || ! IsEnabled() || ! _currentPage)
    {
        return nullptr;
    }

    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    Control* const page                    = _currentPage.get();
    const std::weak_ptr<int> pageLifetime  = GetControlLifetimeToken(*page);
    Control* const hit                     = page->HitTestOverlay(point);
    if (ownerLifetime.expired() || pageLifetime.expired() || _currentPage.get() != page || ! hit || ! ControlBelongsToBranch(page, hit) ||
        ! IsControlEffectivelyInteractive(page, hit))
    {
        return nullptr;
    }
    return hit;
}

const Control* PageHost::HitTestOverlay(D2D1_POINT_2F point) const
{
    if (_transition.active || ! IsVisible() || ! IsEnabled() || ! _currentPage)
    {
        return nullptr;
    }

    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    const Control* const page              = _currentPage.get();
    const std::weak_ptr<int> pageLifetime  = GetControlLifetimeToken(*page);
    const Control* const hit               = page->HitTestOverlay(point);
    if (ownerLifetime.expired() || pageLifetime.expired() || _currentPage.get() != page || ! hit || ! ControlBelongsToBranch(page, hit) ||
        ! IsControlEffectivelyInteractive(page, hit))
    {
        return nullptr;
    }
    return hit;
}

void PageHost::PropagateHost(ControlHost* host) noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    Control::PropagateHost(host);
    if (ownerLifetime.expired())
    {
        return;
    }

    if (host && _childBoundsPending)
        host->_pendingPageLayout = true;

    Control* const current                    = _currentPage.get();
    Control* const outgoing                   = _outgoingPage.get();
    const std::weak_ptr<int> currentLifetime  = current ? GetControlLifetimeToken(*current) : std::weak_ptr<int>{};
    const std::weak_ptr<int> outgoingLifetime = outgoing ? GetControlLifetimeToken(*outgoing) : std::weak_ptr<int>{};
    if (current && ! currentLifetime.expired())
    {
        current->PropagateHost(host);
        if (ownerLifetime.expired())
        {
            return;
        }
    }
    if (outgoing && outgoing != current && ! outgoingLifetime.expired() && (_currentPage.get() == outgoing || _outgoingPage.get() == outgoing))
    {
        outgoing->PropagateHost(host);
    }
}

void PageHost::OnBoundsChanged() noexcept
{
    SyncChildBounds();
}

void PageHost::OnFlowDirectionChanged() noexcept
{
    const std::weak_ptr<int> ownerLifetime    = GetLifetimeToken();
    Control* const current                    = _currentPage.get();
    Control* const outgoing                   = _outgoingPage.get();
    const std::weak_ptr<int> currentLifetime  = current ? GetControlLifetimeToken(*current) : std::weak_ptr<int>{};
    const std::weak_ptr<int> outgoingLifetime = outgoing ? GetControlLifetimeToken(*outgoing) : std::weak_ptr<int>{};
    Control::OnFlowDirectionChanged();
    if (ownerLifetime.expired())
    {
        return;
    }
    if (current && ! currentLifetime.expired() && (_currentPage.get() == current || _outgoingPage.get() == current))
    {
        current->OnFlowDirectionChanged();
        if (ownerLifetime.expired())
        {
            return;
        }
    }
    if (outgoing && outgoing != current && ! outgoingLifetime.expired() && (_currentPage.get() == outgoing || _outgoingPage.get() == outgoing))
    {
        outgoing->OnFlowDirectionChanged();
    }
}

void PageHost::OnDensityChanged() noexcept
{
    const std::weak_ptr<int> ownerLifetime    = GetLifetimeToken();
    Control* const current                    = _currentPage.get();
    Control* const outgoing                   = _outgoingPage.get();
    const std::weak_ptr<int> currentLifetime  = current ? GetControlLifetimeToken(*current) : std::weak_ptr<int>{};
    const std::weak_ptr<int> outgoingLifetime = outgoing ? GetControlLifetimeToken(*outgoing) : std::weak_ptr<int>{};
    Control::OnDensityChanged();
    if (ownerLifetime.expired())
    {
        return;
    }
    if (current && ! currentLifetime.expired() && (_currentPage.get() == current || _outgoingPage.get() == current) && ! current->HasExplicitDensity())
    {
        current->OnDensityChanged();
        if (ownerLifetime.expired())
        {
            return;
        }
    }
    if (outgoing && outgoing != current && ! outgoingLifetime.expired() && (_currentPage.get() == outgoing || _outgoingPage.get() == outgoing) &&
        ! outgoing->HasExplicitDensity())
    {
        outgoing->OnDensityChanged();
    }
}

void PageHost::OnHidden() noexcept
{
    const std::weak_ptr<int> ownerLifetime    = GetLifetimeToken();
    Control* const current                    = _currentPage.get();
    Control* const outgoing                   = _outgoingPage.get();
    const std::weak_ptr<int> currentLifetime  = current ? GetControlLifetimeToken(*current) : std::weak_ptr<int>{};
    const std::weak_ptr<int> outgoingLifetime = outgoing ? GetControlLifetimeToken(*outgoing) : std::weak_ptr<int>{};
    Control::OnHidden();
    if (ownerLifetime.expired())
    {
        return;
    }
    if (current && ! currentLifetime.expired() && (_currentPage.get() == current || _outgoingPage.get() == current))
    {
        current->OnHidden();
        if (ownerLifetime.expired())
        {
            return;
        }
    }
    if (outgoing && outgoing != current && ! outgoingLifetime.expired() && (_currentPage.get() == outgoing || _outgoingPage.get() == outgoing))
    {
        outgoing->OnHidden();
    }
}

void PageHost::OnHostDpiChanged(ControlHost& host) noexcept
{
    const std::weak_ptr<int> ownerLifetime    = GetLifetimeToken();
    Control* const current                    = _currentPage.get();
    Control* const outgoing                   = _outgoingPage.get();
    const std::weak_ptr<int> currentLifetime  = current ? GetControlLifetimeToken(*current) : std::weak_ptr<int>{};
    const std::weak_ptr<int> outgoingLifetime = outgoing ? GetControlLifetimeToken(*outgoing) : std::weak_ptr<int>{};
    Control::OnHostDpiChanged(host);
    if (ownerLifetime.expired())
    {
        return;
    }
    if (current && ! currentLifetime.expired() && (_currentPage.get() == current || _outgoingPage.get() == current))
    {
        current->OnHostDpiChanged(host);
        if (ownerLifetime.expired())
        {
            return;
        }
    }
    if (outgoing && outgoing != current && ! outgoingLifetime.expired() && (_currentPage.get() == outgoing || _outgoingPage.get() == outgoing))
    {
        outgoing->OnHostDpiChanged(host);
    }
}

void PageHost::SyncChildBounds() noexcept
{
    const std::weak_ptr<int> ownerLifetime    = GetLifetimeToken();
    const D2D1_RECT_F bounds                  = GetBounds();
    Control* const current                    = _currentPage.get();
    Control* const outgoing                   = _outgoingPage.get();
    const std::weak_ptr<int> currentLifetime  = current ? GetControlLifetimeToken(*current) : std::weak_ptr<int>{};
    const std::weak_ptr<int> outgoingLifetime = outgoing ? GetControlLifetimeToken(*outgoing) : std::weak_ptr<int>{};
    if (current && ! currentLifetime.expired())
    {
        current->SetBounds(bounds);
        if (ownerLifetime.expired())
        {
            return;
        }
    }
    if (outgoing && outgoing != current && ! outgoingLifetime.expired() && (_currentPage.get() == outgoing || _outgoingPage.get() == outgoing))
    {
        outgoing->SetBounds(bounds);
    }
}

bool ControlHost::PreparePendingPageLayout() noexcept
{
    if (! _pendingPageLayout)
        return true;
    _pendingPageLayout      = false;
    Control* const root     = _root.get();
    const auto rootLifetime = root ? GetControlLifetimeToken(*root) : std::weak_ptr<int>{};
    const auto rootCurrent  = [&]() noexcept { return root && ! rootLifetime.expired() && _root.get() == root; };
    const auto prepare      = [&](auto&& self, Control& control) noexcept -> void
    {
        const auto lifetime = GetControlLifetimeToken(control);
        if (auto* const page = dynamic_cast<PageHost*>(&control); page && page->_childBoundsPending)
        {
            page->_childBoundsPending = false;
            page->SyncChildBounds();
            if (lifetime.expired() || ! rootCurrent())
                return;
        }
        const size_t visitBudget = control.GetLogicalChildCount();
        if (lifetime.expired() || ! rootCurrent())
            return;
        // Reacquire each child after virtual callbacks. New additions wait for the next real preparation.
        size_t index = 0u;
        for (size_t visits = 0u; visits < visitBudget; ++visits)
        {
            const size_t count = control.GetLogicalChildCount();
            if (lifetime.expired() || ! rootCurrent() || index >= count)
                return;
            Control* const child = control.GetLogicalChild(index);
            if (lifetime.expired() || ! rootCurrent())
                return;
            const auto childLifetime = child ? GetControlLifetimeToken(*child) : std::weak_ptr<int>{};
            if (child)
                self(self, *child);
            if (lifetime.expired() || ! rootCurrent())
                return;
            Control* const current = control.GetLogicalChild(index);
            if (lifetime.expired() || ! rootCurrent())
                return;
            if (! child || (! childLifetime.expired() && current == child))
                ++index;
        }
        const size_t remaining = control.GetLogicalChildCount();
        if (lifetime.expired() || ! rootCurrent())
            return;
        if (index < remaining)
            _pendingPageLayout = true;
        // Transition pages still paint even though only the current page belongs to logical navigation.
        if (auto* const page = dynamic_cast<PageHost*>(&control); page && page->_outgoingPage && page->_outgoingPage != page->_currentPage)
        {
            self(self, *page->_outgoingPage);
        }
    };
    if (root)
        prepare(prepare, *root);
    // Reentrant replacement requests another preparation; never publish its deferred geometry as complete.
    return (! root || rootCurrent()) && ! _pendingPageLayout;
}

bool PageHost::FinishTransition() noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    _transition.active                     = false;
    _transition.hasConnectedAnimation      = false;
    _transition.linearProgress             = 1.0f;
    _transition.startTickMs                = 0u;
    _transition.lastTickMs                 = 0u;
    _transition.sourceRectDip              = D2D1::RectF();
    _transition.targetRectDip              = D2D1::RectF();
#if DXUI_ENABLE_DIAGNOSTICS
    _transition.debugFrozen         = false;
    _transition.debugFrozenProgress = 1.0f;
#endif
    auto outgoing = std::move(_outgoingPage);
    if (outgoing)
    {
        outgoing->PropagateHost(nullptr);
    }
    return ! ownerLifetime.expired();
}

void CardPanel::SetCornerRadius(float cornerRadiusDip) noexcept
{
    _cornerRadiusDip = (std::max)(0.0f, cornerRadiusDip);
}

float CardPanel::GetCornerRadius() const noexcept
{
    return _cornerRadiusDip;
}

void CardPanel::Paint(ControlHost& host) const
{
    const CardPanelVisualStyle style = ResolveCardPanelVisualStyle(host.GetTheme());
    DrawRoundedRect(host, GetBounds(), style.fill, style.border, _cornerRadiusDip);
    Panel::Paint(host);
}

Label::Label(std::wstring text) : _text(std::move(text))
{
}

void Label::SetText(std::wstring text)
{
    if (_text != text)
    {
        _text = std::move(text);
        if (ControlHost* const host = GetHost())
        {
            RefreshWindowHostAccessibilitySnapshot(host->GetHwnd(), host);
        }
        RequestInvalidate();
    }
}

std::wstring_view Label::GetText() const noexcept
{
    return _text;
}

Control* Label::GetMnemonicTarget() const noexcept
{
    return _mnemonicTarget;
}

void Label::SetFontRole(FontRole fontRole) noexcept
{
    _fontRole = fontRole;
    RequestInvalidate();
}

void Label::SetAlignment(DWRITE_TEXT_ALIGNMENT alignment) noexcept
{
    _alignment = alignment;
    RequestInvalidate();
}

void Label::SetMultiline(bool multiline) noexcept
{
    _multiline = multiline;
    RequestInvalidate();
}

void Label::SetTextColor(std::optional<D2D1_COLOR_F> color) noexcept
{
    _textColor = color;
    RequestInvalidate();
}

void Label::SetMnemonicTarget(Control* target) noexcept
{
    if (_mnemonicTarget != target)
    {
        _mnemonicTarget = target;
        if (ControlHost* const host = GetHost())
        {
            RefreshWindowHostAccessibilitySnapshot(host->GetHwnd(), host);
        }
    }
}

void Label::Paint(ControlHost& host) const
{
    const LabelVisualStyle style = ResolveLabelVisualStyle(host.GetTheme(), _textColor);
    DrawTextWithMnemonic(
        host, _text, GetBounds(), _fontRole, style.text, GetMnemonic(), _alignment, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, _multiline, GetFlowDirection());
}

Control* Label::HitTest(D2D1_POINT_2F /*point*/)
{
    // Labels are text/mnemonic surfaces; pointer-interactive label-like UI should use a button/link control.
    return nullptr;
}

const Control* Label::HitTest(D2D1_POINT_2F /*point*/) const
{
    return nullptr;
}

bool Label::OnMnemonic(ControlHost& host)
{
    if (_mnemonicTarget && ControlBelongsToBranch(host.GetRoot(), _mnemonicTarget))
    {
        return _mnemonicTarget->OnMnemonic(host);
    }

    return Control::OnMnemonic(host);
}

Button::Button(std::wstring text) : _text(std::move(text))
{
    SetFocusable(true);
}

void Button::SetMultiline(bool multiline) noexcept
{
    if (_multiline != multiline)
    {
        _multiline = multiline;
        RequestInvalidate();
    }
}

bool Button::IsMultiline() const noexcept
{
    return _multiline;
}

void Button::SetText(std::wstring text)
{
    if (_text != text)
    {
        _text = std::move(text);
        if (ControlHost* const host = GetHost())
        {
            RefreshWindowHostAccessibilitySnapshot(host->GetHwnd(), host);
        }
        RequestInvalidate();
    }
}

void Button::SetPrimary(bool primary) noexcept
{
    _primary = primary;
    RequestInvalidate();
}

bool Button::IsPrimary() const noexcept
{
    return _primary;
}

void Button::SetVariant(ButtonVariant variant) noexcept
{
    _variant = variant;
    RequestInvalidate();
}

ButtonVariant Button::GetVariant() const noexcept
{
    return _variant;
}

void Button::SetDisclosureCollapsedDirection(ChevronDirection direction) noexcept
{
    const ChevronDirection collapsedDirection = direction == ChevronDirection::Left ? ChevronDirection::Left : ChevronDirection::Right;
    if (_disclosureCollapsedDirection != collapsedDirection)
    {
        _disclosureCollapsedDirection = collapsedDirection;
        RequestInvalidate();
    }
}

void Button::SetDisclosureExpanded(bool expanded) noexcept
{
    const float target = expanded ? 1.0f : 0.0f;
    if (! _disclosureExpanded.has_value())
    {
        _disclosureExpanded                 = expanded;
        _disclosureTransition.progress      = target;
        _disclosureTransition.startProgress = target;
        _disclosureTransition.target        = target;
        _disclosureTransition.elapsedMs     = 0u;
        _disclosureTransition.anchored      = false;
        _disclosureTransition.initialized   = true;
        _disclosureTransition.active        = false;
        RequestInvalidate();
        if (ControlHost* const host = GetHost())
        {
            host->RefreshAccessibilitySnapshot();
        }
        return;
    }

    if (_disclosureExpanded.value() == expanded)
    {
        return;
    }

    ControlHost* const host = GetHost();
    // The rotation runs on its own ticks: it starts at the first one, so a button hidden now (it gets none until it
    // paints again) rotates when it shows, and a pause in them pauses it instead of skipping to the end.
    _disclosureExpanded                 = expanded;
    _disclosureTransition.startProgress = _disclosureTransition.progress;
    _disclosureTransition.target        = target;
    _disclosureTransition.elapsedMs     = 0u;
    _disclosureTransition.anchored      = false;
    _disclosureTransition.initialized   = true;
    _disclosureTransition.active        = host && ! host->GetTheme().reducedMotion;
    if (_disclosureTransition.active)
    {
        host->RequestAnimation();
    }
    else
    {
        _disclosureTransition.progress = target;
    }
    RequestInvalidate();
    if (host)
    {
        host->RefreshAccessibilitySnapshot();
        RaiseWindowHostDisclosureChanged(host->GetHwnd(), this, expanded);
    }
}

std::optional<bool> Button::GetDisclosureExpanded() const noexcept
{
    return _disclosureExpanded;
}

void Button::ClearDisclosureState() noexcept
{
    if (_disclosureExpanded.has_value())
    {
        _disclosureExpanded.reset();
        _disclosureTransition = {};
        RequestInvalidate();
        if (ControlHost* const host = GetHost())
        {
            host->RefreshAccessibilitySnapshot();
        }
    }
}

void Button::SetOnClick(std::function<void()> onClick)
{
    ReplaceControlCallback(_onClick, std::move(onClick));
}

void Button::SetOnDropDownClick(std::function<void()> onDropDownClick)
{
    ReplaceControlCallback(_onDropDownClick, std::move(onDropDownClick));
}

bool Button::Invoke(ControlHost& host, bool focusSelf)
{
    TraceButtonDiagnostics(L"dxui.button.invoke",
                           L"hwnd={:#x} text=\"{}\" variant={} focusSelf={} enabled={} visible={} hasClick={} hasDropDown={}",
                           reinterpret_cast<uintptr_t>(host.GetHwnd()),
                           TraceLimitedText(_text),
                           TraceButtonVariantName(_variant),
                           focusSelf ? 1 : 0,
                           IsEnabled() ? 1 : 0,
                           IsVisible() ? 1 : 0,
                           _onClick ? 1 : 0,
                           _onDropDownClick ? 1 : 0);
    if (! IsEnabled() || ! IsVisible())
    {
        return false;
    }

    // A button a focus callback destroyed does not run the invocation it was asked for.
    if (focusSelf && ! FocusControlAndSurvive(host, *this, true))
    {
        return false;
    }

    if ((_variant == ButtonVariant::DropDown || _variant == ButtonVariant::Selector) && _onDropDownClick)
    {
        return InvokeDropDown(host);
    }

    Invalidate(host);
    const auto onClick = _onClick;
    if (onClick)
    {
        (*onClick)();
    }
    return true;
}

void Button::Paint(ControlHost& host) const
{
    // A disclosure rotation left pending while the button was hidden resumes ticking when it paints again.
    if (_disclosureTransition.active)
    {
        host.RequestAnimation();
    }
    const FlowDirection flowDirection = GetFlowDirection();
    const ButtonVisualStyle style     = ResolveButtonVisualStyle(host.GetTheme(),
                                                                 IsEnabled(),
                                                                 IsHovered(),
                                                                 IsPressed(),
                                                                 HasFocus(),
                                                                 HasFocus() && host.IsKeyboardFocusVisible(),
                                                                 _primary || host.GetDefaultButton() == this,
                                                                 ResolveHoverAnimationProgress(host),
                                                                 ResolveFocusAnimationProgress(host));
    const D2D1_COLOR_F transparent    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);

    if (_variant == ButtonVariant::Hyperlink)
    {
        const auto& theme     = host.GetTheme();
        const D2D1_COLOR_F fg = IsEnabled() ? theme.selectionFill : theme.disabledText;
        if (style.showFocus)
        {
            PaintFocusRing(host, GetBounds(), kButtonCornerRadiusDip);
        }
        DrawCenteredText(host, _text, GetBounds(), FontRole::Body, fg, DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false, flowDirection);
        if (IsHovered() && IsEnabled())
        {
            const D2D1_RECT_F b           = GetBounds();
            const float widthDip          = (std::max)(0.0f, b.right - b.left);
            const float heightDip         = (std::max)(1.0f, b.bottom - b.top);
            const float availableDip      = (std::max)(0.0f, widthDip - 8.0f);
            const float textWidthDip      = MeasureSingleLineTextWidthDip(&host, _text, FontRole::Body, heightDip, ResolveReadingDirection(flowDirection));
            const float underlineWidthDip = (std::clamp)(textWidthDip, 0.0f, availableDip);
            const float underlineLeftDip  = b.left + ((widthDip - underlineWidthDip) * 0.5f);
            const float underlineRightDip = underlineLeftDip + underlineWidthDip;
            const float underlineYDip     = SnapDipToPixel(host, b.bottom - 3.0f);
            DrawLineWithColor(host, D2D1::Point2F(underlineLeftDip, underlineYDip), D2D1::Point2F(underlineRightDip, underlineYDip), fg, 1.0f);
        }
        return;
    }

    if (_variant == ButtonVariant::Selector)
    {
        ButtonChromeDrawSpec spec{};
        spec.bounds          = GetBounds();
        spec.text            = _text;
        spec.variant         = _variant;
        spec.enabled         = IsEnabled();
        spec.hovered         = IsHovered();
        spec.pressed         = IsPressed();
        spec.focused         = HasFocus();
        spec.keyboardFocused = HasFocus() && host.IsKeyboardFocusVisible();
        spec.hoverStrength   = ResolveHoverAnimationProgress(host);
        spec.focusStrength   = ResolveFocusAnimationProgress(host);

        IDWriteTextFormat* const textFormat =
            host.GetTextFormat(FontRole::Body, DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false, ResolveReadingDirection(flowDirection));
        IDWriteTextFormat* const iconFormat =
            host.GetTextFormat(FontRole::Icon, DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false, ResolveReadingDirection(flowDirection));
        DrawButtonChrome(host.GetDeviceContext(), host.GetSolidBrush(style.text), textFormat, iconFormat, host.GetTheme(), spec);
        return;
    }

    if (_variant == ButtonVariant::Disclosure)
    {
        if (style.showFocus)
        {
            PaintFocusRing(host, GetBounds(), kButtonCornerRadiusDip);
        }
        if (_disclosureExpanded.has_value())
        {
            const float progress = host.GetTheme().reducedMotion ? (_disclosureExpanded.value() ? 1.0f : 0.0f) : _disclosureTransition.progress;
            DrawDisclosureChevron(host, GetBounds(), progress, style.text, _disclosureCollapsedDirection);
        }
        else
        {
            DrawCenteredText(host, _text, GetBounds(), FontRole::Icon, style.text);
        }
        return;
    }

    DrawRoundedRect(host, GetBounds(), style.fill, style.showBorder ? style.border : transparent, kButtonCornerRadiusDip);
    if (style.showFocus)
    {
        PaintFocusRing(host, GetBounds(), kButtonCornerRadiusDip);
    }

    if (_disclosureExpanded.has_value())
    {
        const float progress = host.GetTheme().reducedMotion ? (_disclosureExpanded.value() ? 1.0f : 0.0f) : _disclosureTransition.progress;
        DrawDisclosureChevron(host, GetBounds(), progress, style.text, _disclosureCollapsedDirection);
    }
    else if (_variant == ButtonVariant::DropDown)
    {
        const ButtonChromeLayout layout = ComputeButtonChromeLayout(GetBounds(), _variant);
        const D2D1_RECT_F textRect      = D2D1::RectF(layout.textRect.left + style.textOffsetXDip,
                                                      layout.textRect.top + style.textOffsetYDip,
                                                      layout.textRect.right + style.textOffsetXDip,
                                                      layout.textRect.bottom + style.textOffsetYDip);
        DrawCenteredText(
            host, _text, textRect, FontRole::Body, style.text, DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false, flowDirection);
        DrawCenteredText(host, std::wstring_view(&kButtonDropDownChevronGlyph, 1u), layout.chevronRect, FontRole::Icon, style.text);
    }
    else if (_variant == ButtonVariant::Split)
    {
        const ButtonChromeLayout layout = ComputeButtonChromeLayout(GetBounds(), _variant);
        const D2D1_RECT_F textRect      = D2D1::RectF(layout.textRect.left + style.textOffsetXDip,
                                                      layout.textRect.top + style.textOffsetYDip,
                                                      layout.textRect.right + style.textOffsetXDip,
                                                      layout.textRect.bottom + style.textOffsetYDip);
        DrawCenteredText(
            host, _text, textRect, FontRole::Body, style.text, DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false, flowDirection);
        DrawLineWithColor(
            host, D2D1::Point2F(layout.dividerX, GetBounds().top + 6.0f), D2D1::Point2F(layout.dividerX, GetBounds().bottom - 6.0f), style.border, 1.0f);
        DrawCenteredText(host, std::wstring_view(&kButtonDropDownChevronGlyph, 1u), layout.chevronRect, FontRole::Icon, style.text);
    }
    else if (_variant == ButtonVariant::IconOnly)
    {
        // Segoe Fluent Icons when that family is installed (the same choice as RedSalamander chrome). A missing
        // family draws the caller's Unicode stand-in in the UI font instead of a private-use box.
        DrawCenteredText(host, _text, GetBounds(), host.HasFluentIconFont() ? FontRole::Icon : FontRole::Body, style.text);
    }
    else
    {
        const float padX           = _multiline ? 12.0f : 0.0f;
        const float padY           = _multiline ? 8.0f : 0.0f;
        const D2D1_RECT_F textRect = D2D1::RectF(GetBounds().left + style.textOffsetXDip + padX,
                                                 GetBounds().top + style.textOffsetYDip + padY,
                                                 (std::max)(GetBounds().left + padX, GetBounds().right + style.textOffsetXDip - padX),
                                                 (std::max)(GetBounds().top + padY, GetBounds().bottom + style.textOffsetYDip - padY));
        DrawCenteredText(
            host, _text, textRect, FontRole::Body, style.text, DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, _multiline, flowDirection);
    }
}

bool Button::OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    const bool dropDownPoint = IsDropDownInvocationPoint(point);
    TraceButtonDiagnostics(L"dxui.button.mouse-down",
                           L"hwnd={:#x} text=\"{}\" variant={} point=({:.1f},{:.1f}) bounds={} hit={} rightButton={} enabled={} visible={} "
                           L"pressedBefore={} pressedDropDownBefore={} dropDownPoint={} hasClick={} hasDropDown={}",
                           reinterpret_cast<uintptr_t>(host.GetHwnd()),
                           TraceLimitedText(_text),
                           TraceButtonVariantName(_variant),
                           point.x,
                           point.y,
                           TraceRect(GetBounds()),
                           TraceRect(GetHitBounds()),
                           rightButton ? 1 : 0,
                           IsEnabled() ? 1 : 0,
                           IsVisible() ? 1 : 0,
                           _pressed ? 1 : 0,
                           _pressedDropDown ? 1 : 0,
                           dropDownPoint ? 1 : 0,
                           _onClick ? 1 : 0,
                           _onDropDownClick ? 1 : 0);
    if (! IsEnabled())
    {
        return false;
    }

    if (rightButton)
    {
        if (! FocusControlAndSurvive(host, *this, true))
        {
            return true;
        }
        return Control::OnContextMenu(host, false, point);
    }

    if (! FocusControlAndSurvive(host, *this))
    {
        return true;
    }
    _pressed         = true;
    _pressedDropDown = dropDownPoint;
    Invalidate(host);
    return true;
}

bool Button::OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    const bool wasPressedBeforeReturn = _pressed;
    const bool hitBeforeReturn        = PointInRect(GetHitBounds(), point);
    TraceButtonDiagnostics(L"dxui.button.mouse-up-enter",
                           L"hwnd={:#x} text=\"{}\" variant={} point=({:.1f},{:.1f}) bounds={} hit={} rightButton={} enabled={} visible={} "
                           L"pressedBefore={} pressedDropDownBefore={} hasClick={} hasDropDown={}",
                           reinterpret_cast<uintptr_t>(host.GetHwnd()),
                           TraceLimitedText(_text),
                           TraceButtonVariantName(_variant),
                           point.x,
                           point.y,
                           TraceRect(GetBounds()),
                           hitBeforeReturn ? 1 : 0,
                           rightButton ? 1 : 0,
                           IsEnabled() ? 1 : 0,
                           IsVisible() ? 1 : 0,
                           wasPressedBeforeReturn ? 1 : 0,
                           _pressedDropDown ? 1 : 0,
                           _onClick ? 1 : 0,
                           _onDropDownClick ? 1 : 0);
    if (rightButton || ! IsEnabled())
    {
        return false;
    }

    const bool wasPressed     = _pressed;
    const bool hitButton      = PointInRect(GetHitBounds(), point);
    const bool invokeDropDown = _pressedDropDown && hitButton;
    const auto onClick        = _onClick;
    _pressed                  = false;
    _pressedDropDown          = false;
    TraceButtonDiagnostics(L"dxui.button.mouse-up-dispatch",
                           L"hwnd={:#x} text=\"{}\" variant={} wasPressed={} hitButton={} invokeDropDown={} hasClick={} hasDropDown={}",
                           reinterpret_cast<uintptr_t>(host.GetHwnd()),
                           TraceLimitedText(_text),
                           TraceButtonVariantName(_variant),
                           wasPressed ? 1 : 0,
                           hitButton ? 1 : 0,
                           invokeDropDown ? 1 : 0,
                           onClick ? 1 : 0,
                           _onDropDownClick ? 1 : 0);
    if (wasPressed)
    {
        Invalidate(host);
        host.ReleaseMouseCapture();
    }
    if (wasPressed && invokeDropDown && InvokeDropDown(host))
    {
        return true;
    }
    if (wasPressed && hitButton && onClick)
    {
        (*onClick)();
    }
    return wasPressed;
}

bool Button::OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers)
{
    if (! IsEnabled())
    {
        return false;
    }

    if (virtualKey == VK_SPACE || virtualKey == VK_RETURN)
    {
        return Invoke(host, false);
    }
    if ((virtualKey == VK_F4 || (virtualKey == VK_DOWN && ModifiersContainAlt(modifiers))) && InvokeDropDown(host))
    {
        return true;
    }
    return false;
}

bool Button::OnMnemonic(ControlHost& host)
{
    return Invoke(host, true);
}

float Button::DebugGetHoverAnimationProgress() const noexcept
{
    return _hoverTransition.progress;
}

float Button::DebugGetFocusAnimationProgress() const noexcept
{
    return _focusTransition.progress;
}

float Button::DebugGetDisclosureAnimationProgress() const noexcept
{
    return _disclosureTransition.progress;
}

bool Button::DebugIsDisclosureAnimationActive() const noexcept
{
    return _disclosureTransition.active;
}

bool Button::Tick(ControlHost& host, uint64_t nowTickMs)
{
    const float hoverProgressBefore = _hoverTransition.progress;
    const float focusProgressBefore = _focusTransition.progress;
    const bool hoverAnimating       = AdvanceInteractionTransition(host, _hoverTransition, nowTickMs);
    const bool focusAnimating       = AdvanceInteractionTransition(host, _focusTransition, nowTickMs);
    const bool disclosureAnimating  = AdvanceDisclosureTransition(host, nowTickMs);
    // The disclosure transition invalidates itself; interaction transitions invalidate only when their progress moved.
    if (_hoverTransition.progress != hoverProgressBefore || _focusTransition.progress != focusProgressBefore)
    {
        Invalidate(host);
    }
    return hoverAnimating || focusAnimating || disclosureAnimating;
}

bool Button::OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers)
{
    const std::wstring_view tooltipText = GetTooltipText();
    if (! tooltipText.empty() && tooltipText == _text)
    {
        static_cast<void>(host.ClearTooltip());
        return false;
    }
    return Control::OnMouseMove(host, point, modifiers);
}

bool Button::OnMouseLeave(ControlHost& host)
{
    const bool handled = Control::OnMouseLeave(host);
    TraceButtonDiagnostics(L"dxui.button.mouse-leave",
                           L"hwnd={:#x} text=\"{}\" variant={} pressedBefore={} pressedDropDownBefore={} enabled={} visible={}",
                           reinterpret_cast<uintptr_t>(host.GetHwnd()),
                           TraceLimitedText(_text),
                           TraceButtonVariantName(_variant),
                           _pressed ? 1 : 0,
                           _pressedDropDown ? 1 : 0,
                           IsEnabled() ? 1 : 0,
                           IsVisible() ? 1 : 0);
    if (_pressed && host.GetCapturedControl() != this)
    {
        _pressed         = false;
        _pressedDropDown = false;
        Invalidate(host);
    }
    static_cast<void>(host.ClearTooltip());
    return handled;
}

bool Button::IsPressed() const noexcept
{
    return _pressed || _dropDownOpen;
}

std::wstring_view Button::GetText() const noexcept
{
    return _text;
}

#if DXUI_ENABLE_DIAGNOSTICS
bool Button::DebugIsPressed() const noexcept
{
    return IsPressed();
}
#endif

void Button::SetPressed(bool pressed) noexcept
{
    _pressed = pressed;
}

void Button::SetPressedVisual(bool pressed) noexcept
{
    SetPressed(pressed);
}

void Button::OnCaptureLost(ControlHost& host)
{
    TraceButtonDiagnostics(L"dxui.button.capture-lost",
                           L"hwnd={:#x} text=\"{}\" variant={} pressedBefore={} pressedDropDownBefore={} enabled={} visible={}",
                           reinterpret_cast<uintptr_t>(host.GetHwnd()),
                           TraceLimitedText(_text),
                           TraceButtonVariantName(_variant),
                           _pressed ? 1 : 0,
                           _pressedDropDown ? 1 : 0,
                           IsEnabled() ? 1 : 0,
                           IsVisible() ? 1 : 0);
    if (_pressed)
    {
        _pressed         = false;
        _pressedDropDown = false;
        Invalidate(host);
    }
    static_cast<void>(host.ClearTooltip());
}

bool Button::IsDropDownInvocationPoint(D2D1_POINT_2F point) const noexcept
{
    if (! _onDropDownClick)
    {
        return false;
    }

    const D2D1_RECT_F bounds = GetBounds();
    if (_variant == ButtonVariant::DropDown || _variant == ButtonVariant::Selector)
    {
        return PointInRect(bounds, point);
    }
    if (_variant != ButtonVariant::Split)
    {
        return false;
    }

    const float dividerX = bounds.right - _splitDropDownWidthDip;
    return point.x >= dividerX && PointInRect(bounds, point);
}

bool Button::InvokeDropDown(ControlHost& host)
{
    TraceButtonDiagnostics(L"dxui.button.dropdown-invoke",
                           L"hwnd={:#x} text=\"{}\" variant={} enabled={} visible={} hasDropDown={} pressedBefore={} pressedDropDownBefore={} openBefore={}",
                           reinterpret_cast<uintptr_t>(host.GetHwnd()),
                           TraceLimitedText(_text),
                           TraceButtonVariantName(_variant),
                           IsEnabled() ? 1 : 0,
                           IsVisible() ? 1 : 0,
                           _onDropDownClick ? 1 : 0,
                           _pressed ? 1 : 0,
                           _pressedDropDown ? 1 : 0,
                           _dropDownOpen ? 1 : 0);
    if (! IsEnabled() || ! IsVisible() || ! _onDropDownClick)
    {
        return false;
    }

    _pressed      = true;
    _dropDownOpen = true;
    Invalidate(host);
    const auto onDropDownClick        = _onDropDownClick;
    const std::weak_ptr<int> lifetime = GetLifetimeToken();
    (*onDropDownClick)();
    if (lifetime.expired())
    {
        return true;
    }
    TraceButtonDiagnostics(L"dxui.button.dropdown-return",
                           L"hwnd={:#x} text=\"{}\" variant={} pressed={} pressedDropDown={} open={}",
                           reinterpret_cast<uintptr_t>(host.GetHwnd()),
                           TraceLimitedText(_text),
                           TraceButtonVariantName(_variant),
                           _pressed ? 1 : 0,
                           _pressedDropDown ? 1 : 0,
                           _dropDownOpen ? 1 : 0);
    _dropDownOpen    = false;
    _pressed         = false;
    _pressedDropDown = false;
    Invalidate(host);
    return true;
}

void Button::OnFocusChanged(ControlHost& host, bool focused)
{
    Control::OnFocusChanged(host, focused);
    UpdateInteractionTransition(host, _focusTransition, focused ? 1.0f : 0.0f);
}

void Button::OnHoverChanged(ControlHost& host, bool hovered)
{
    Control::OnHoverChanged(host, hovered);
    UpdateInteractionTransition(host, _hoverTransition, hovered ? 1.0f : 0.0f);
}

void Button::UpdateInteractionTransition(ControlHost& host, InteractionTransitionState& transition, float target) noexcept
{
    const float clampedTarget = std::clamp(target, 0.0f, 1.0f);
    transition.target         = clampedTarget;

    if (host.GetTheme().reducedMotion || ! IsEnabled() || ! IsVisible() || std::fabs(transition.progress - clampedTarget) <= 0.0001f)
    {
        transition.progress   = clampedTarget;
        transition.lastTickMs = 0u;
        transition.anchored   = false;
        transition.active     = false;
        Invalidate(host);
        return;
    }

    // Seed from "now" so a previously idle host does not fast-forward a fresh transition on its first dispatcher tick.
    transition.lastTickMs = ::GetTickCount64();
    transition.anchored   = true;
    transition.active     = true;
    host.RequestAnimation();
    Invalidate(host);
}

bool Button::AdvanceInteractionTransition(const ControlHost& host, InteractionTransitionState& transition, uint64_t nowTickMs) noexcept
{
    if (host.GetTheme().reducedMotion || ! transition.active)
    {
        return false;
    }

    if (! transition.anchored)
    {
        transition.lastTickMs = nowTickMs;
        transition.anchored   = true;
        return true;
    }

    const uint64_t elapsedMs = nowTickMs > transition.lastTickMs ? (nowTickMs - transition.lastTickMs) : 0u;
    transition.lastTickMs    = nowTickMs;
    if (elapsedMs == 0u)
    {
        return transition.active;
    }

    const float step             = static_cast<float>(elapsedMs) / static_cast<float>(_interactionAnimationDurationMs);
    const float previousProgress = transition.progress;
    if (transition.progress < transition.target)
    {
        transition.progress = (std::min)(transition.progress + step, transition.target);
    }
    else
    {
        transition.progress = (std::max)(transition.progress - step, transition.target);
    }

    const bool changedThisTick = std::fabs(transition.progress - previousProgress) > 0.0001f;
    if (std::fabs(transition.progress - transition.target) <= 0.0001f)
    {
        transition.progress   = transition.target;
        transition.active     = false;
        transition.anchored   = false;
        transition.lastTickMs = 0u;
    }

    return transition.active || changedThisTick;
}

bool Button::AdvanceDisclosureTransition(ControlHost& host, uint64_t nowTickMs) noexcept
{
    if (! _disclosureExpanded.has_value() || ! _disclosureTransition.initialized)
    {
        return false;
    }
    if (host.GetTheme().reducedMotion)
    {
        _disclosureTransition.progress = _disclosureTransition.target;
        _disclosureTransition.active   = false;
        return false;
    }
    if (! _disclosureTransition.active)
    {
        return false;
    }
    if (! _disclosureTransition.anchored)
    {
        // The first frame shows where the rotation starts; time runs from here.
        _disclosureTransition.anchored   = true;
        _disclosureTransition.lastTickMs = nowTickMs;
        Invalidate(host);
        return true;
    }
    // A longer gap than kDisclosureMaxTickStepMs means the ticks stopped (the button was hidden, or the thread
    // stalled): it advances the rotation by one such step, so the chevron resumes where it was.
    const uint64_t stepMs            = nowTickMs > _disclosureTransition.lastTickMs ? nowTickMs - _disclosureTransition.lastTickMs : 0u;
    _disclosureTransition.lastTickMs = nowTickMs;
    _disclosureTransition.elapsedMs += (std::min)(stepMs, kDisclosureMaxTickStepMs);
    const float linearProgress =
        std::clamp(static_cast<float>(_disclosureTransition.elapsedMs) / static_cast<float>(_disclosureAnimationDurationMs), 0.0f, 1.0f);
    const float easedProgress      = EvaluateEasing(EasingCurve::PointToPoint, linearProgress);
    _disclosureTransition.progress = std::lerp(_disclosureTransition.startProgress, _disclosureTransition.target, easedProgress);
    if (linearProgress >= 1.0f)
    {
        _disclosureTransition.progress = _disclosureTransition.target;
        _disclosureTransition.active   = false;
    }
    Invalidate(host);
    return _disclosureTransition.active;
}

float Button::ResolveHoverAnimationProgress(const ControlHost& host) const noexcept
{
    return host.GetTheme().reducedMotion ? (IsHovered() ? 1.0f : 0.0f) : _hoverTransition.progress;
}

float Button::ResolveFocusAnimationProgress(const ControlHost& host) const noexcept
{
    return host.GetTheme().reducedMotion ? (HasFocus() ? 1.0f : 0.0f) : _focusTransition.progress;
}

Toggle::Toggle(std::wstring text) : Button(std::move(text))
{
}

void Toggle::SetChecked(bool checked) noexcept
{
    if (_checked != checked)
    {
        _checked = checked;
        if (ControlHost* const host = GetHost())
        {
            RefreshWindowHostAccessibilitySnapshot(host->GetHwnd(), host);
        }
        RequestInvalidate();
    }
}

bool Toggle::IsChecked() const noexcept
{
    return _checked;
}

void Toggle::SetStateLabels(std::wstring uncheckedText, std::wstring checkedText)
{
    _uncheckedText = std::move(uncheckedText);
    _checkedText   = std::move(checkedText);
    RequestInvalidate();
}

std::wstring_view Toggle::GetActiveStateLabel() const noexcept
{
    return _checked ? std::wstring_view(_checkedText) : std::wstring_view(_uncheckedText);
}

std::wstring_view Toggle::GetDisplayedText() const noexcept
{
    const std::wstring_view text = GetText();
    if (! text.empty())
    {
        return text;
    }

    return GetActiveStateLabel();
}

void Toggle::SetOnToggled(std::function<void(bool)> onToggled)
{
    ReplaceControlCallback(_onToggled, std::move(onToggled));
}

ToggleLayoutMetrics Toggle::GetLayoutMetrics() const noexcept
{
    return BuildToggleLayoutMetrics(GetBounds(), IsChecked(), GetDisplayedText().empty());
}

void Toggle::Paint(ControlHost& host) const
{
    const FlowDirection flowDirection = GetFlowDirection();
    const ToggleVisualStyle style     = ResolveToggleVisualStyle(host.GetTheme(),
                                                                 IsEnabled(),
                                                                 IsHovered(),
                                                                 IsPressed(),
                                                                 HasFocus(),
                                                                 host.IsKeyboardFocusVisible(),
                                                                 IsChecked(),
                                                                 ResolveHoverAnimationProgress(host),
                                                                 ResolveFocusAnimationProgress(host));
    const ToggleLayoutMetrics metrics = GetLayoutMetrics();
    if (style.showRowFill)
    {
        DrawRoundedRect(host, metrics.backgroundRect, style.rowFill, style.rowFill, metrics.compactSwitchOnly ? 7.0f : 8.0f);
    }
    if (style.showFocus && metrics.focusRect.right > metrics.focusRect.left && metrics.focusRect.bottom > metrics.focusRect.top)
    {
        PaintFocusRing(host, metrics.backgroundRect, metrics.compactSwitchOnly ? 7.0f : 8.0f);
    }

    DrawRoundedRect(host, metrics.trackRect, style.trackFill, style.trackBorder, kToggleTrackHeightDip * 0.5f);
    // Knob diameter varies by state: 12 rest, 14 hover, 10 pressed (spec §3.5)
    const float knobRadius = style.knobDiameter * 0.5f;
    const D2D1_ELLIPSE ellipse =
        D2D1::Ellipse(D2D1::Point2F((metrics.knobRect.left + metrics.knobRect.right) * 0.5f, (metrics.knobRect.top + metrics.knobRect.bottom) * 0.5f),
                      knobRadius,
                      knobRadius);
    FillEllipseWithColor(host, ellipse, style.knobFill);
    DrawEllipseWithColor(host, ellipse, style.knobBorder, 1.0f);

    if (! metrics.compactSwitchOnly)
    {
        const bool stateOnlyLabel = GetText().empty() && ! GetActiveStateLabel().empty();
        DrawTextWithMnemonic(host,
                             GetDisplayedText(),
                             metrics.textRect,
                             FontRole::Body,
                             style.text,
                             GetMnemonic(),
                             stateOnlyLabel ? DWRITE_TEXT_ALIGNMENT_TRAILING : DWRITE_TEXT_ALIGNMENT_LEADING,
                             DWRITE_PARAGRAPH_ALIGNMENT_CENTER,
                             false,
                             flowDirection);
    }
}

bool Toggle::OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    if (rightButton || ! IsEnabled())
    {
        return false;
    }

    const bool wasPressed = IsPressed();
    SetPressed(false);
    const bool activate = wasPressed && PointInRect(GetHitBounds(), point);
    if (! activate)
    {
        Invalidate(host);
        return wasPressed;
    }

    ApplyCheckedState(host, ! _checked, true);
    return true;
}

bool Toggle::OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers)
{
    if (virtualKey == VK_LEFT)
    {
        ApplyCheckedState(host, false, true);
        return true;
    }
    if (virtualKey == VK_RIGHT)
    {
        ApplyCheckedState(host, true, true);
        return true;
    }
    if (virtualKey == VK_SPACE || virtualKey == VK_RETURN)
    {
        ApplyCheckedState(host, ! _checked, true);
        return true;
    }
    return Button::OnKeyDown(host, virtualKey, modifiers);
}

bool Toggle::OnMnemonic(ControlHost& host)
{
    if (! IsEnabled() || ! IsVisible())
    {
        return false;
    }

    if (FocusControlAndSurvive(host, *this, true))
    {
        ApplyCheckedState(host, ! _checked, true);
    }
    return true;
}

void Toggle::ApplyCheckedState(ControlHost& host, bool checked, bool notify)
{
    if (_checked == checked)
    {
        return;
    }

    _checked = checked;
    Invalidate(host);
    if (notify)
    {
        const auto onToggled = _onToggled;
        if (onToggled)
        {
            (*onToggled)(_checked);
        }
    }
}

Checkbox::Checkbox(std::wstring text) : Toggle(std::move(text))
{
}

bool Checkbox::OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers)
{
    const bool willToggle = ! rightButton && IsEnabled() && IsPressed() && PointInRect(GetHitBounds(), point);
    if (willToggle)
    {
        _indeterminate = false;
    }

    return Toggle::OnMouseUp(host, point, rightButton, modifiers);
}

bool Checkbox::OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers)
{
    if (virtualKey == VK_RETURN)
    {
        return false;
    }

    if (virtualKey == VK_SPACE || virtualKey == VK_LEFT || virtualKey == VK_RIGHT)
    {
        const bool wasIndeterminate = _indeterminate;
        _indeterminate              = false;
        if (wasIndeterminate)
        {
            Invalidate(host);
        }
    }

    return Toggle::OnKeyDown(host, virtualKey, modifiers);
}

bool Checkbox::OnMnemonic(ControlHost& host)
{
    if (! IsEnabled() || ! IsVisible())
    {
        return false;
    }

    _indeterminate = false;
    return Toggle::OnMnemonic(host);
}

void Checkbox::SetIndeterminate(bool indeterminate) noexcept
{
    _indeterminate = indeterminate;
    RequestInvalidate();
}

bool Checkbox::IsIndeterminate() const noexcept
{
    return _indeterminate;
}

void Checkbox::Paint(ControlHost& host) const
{
    const bool rightToLeft          = IsRightToLeft();
    const bool effectiveChecked     = IsChecked() || _indeterminate;
    const CheckboxVisualStyle style = ResolveCheckboxVisualStyle(host.GetTheme(),
                                                                 IsEnabled(),
                                                                 IsHovered(),
                                                                 IsPressed(),
                                                                 HasFocus(),
                                                                 host.IsKeyboardFocusVisible(),
                                                                 effectiveChecked,
                                                                 ResolveHoverAnimationProgress(host),
                                                                 ResolveFocusAnimationProgress(host));

    const D2D1_RECT_F bounds      = GetBounds();
    const D2D1_RECT_F contentRect = D2D1::RectF(bounds.left + 1.0f, bounds.top + 1.0f, bounds.right - 1.0f, bounds.bottom - 1.0f);
    if (style.showHoverFill)
    {
        DrawRoundedRect(host, contentRect, style.hoverFill, style.hoverFill, 4.0f);
    }
    if (style.showFocus)
    {
        PaintFocusRing(host, contentRect, 4.0f);
    }

    const float indicatorSize   = 16.0f;
    const float indicatorTop    = contentRect.top + ((contentRect.bottom - contentRect.top - indicatorSize) * 0.5f);
    const float indicatorLeft   = rightToLeft ? (contentRect.right - 6.0f - indicatorSize) : (contentRect.left + 6.0f);
    const D2D1_RECT_F indicator = D2D1::RectF(indicatorLeft, indicatorTop, indicatorLeft + indicatorSize, indicatorTop + indicatorSize);
    DrawRoundedRect(host, indicator, style.indicatorFill, style.indicatorBorder, 4.0f);

    if (_indeterminate)
    {
        // Horizontal dash (spec §3.6) — 1.5 DIP stroke, centered in indicator
        const float centerY    = (indicator.top + indicator.bottom) * 0.5f;
        const float dashInset  = 4.0f;
        const D2D1_POINT_2F p0 = D2D1::Point2F(indicator.left + dashInset, centerY);
        const D2D1_POINT_2F p1 = D2D1::Point2F(indicator.right - dashInset, centerY);
        DrawLineWithColor(host, p0, p1, style.check, 1.5f);
    }
    else if (IsChecked())
    {
        const D2D1_RECT_F checkRect = InflateRect(indicator, -1.0f, -1.0f);
        DrawCenteredText(host, GetCheckboxCheckGlyph(host), checkRect, GetCheckboxCheckFontRole(host), style.check);
    }

    DrawTextWithMnemonic(host,
                         GetText(),
                         rightToLeft ? D2D1::RectF(contentRect.left + 4.0f, contentRect.top + 2.0f, indicator.left - 8.0f, contentRect.bottom - 2.0f)
                                     : D2D1::RectF(indicator.right + 8.0f, contentRect.top + 2.0f, contentRect.right - 4.0f, contentRect.bottom - 2.0f),
                         FontRole::Body,
                         style.text,
                         GetMnemonic(),
                         // The text format reads in the flow's direction, so leading hugs the indicator on either side.
                         DWRITE_TEXT_ALIGNMENT_LEADING,
                         DWRITE_PARAGRAPH_ALIGNMENT_CENTER,
                         IsMultiline(),
                         GetFlowDirection());
}

// --- RadioButton ---

RadioButton::RadioButton(std::wstring text) : Button(std::move(text))
{
}

void RadioButton::SetChecked(bool checked) noexcept
{
    _checked = checked;
    RequestInvalidate();
}

bool RadioButton::IsChecked() const noexcept
{
    return _checked;
}

void RadioButton::SetOnSelected(std::function<void()> onSelected)
{
    ReplaceControlCallback(_onSelected, std::move(onSelected));
}

void RadioButton::SetGroup(RadioButtons* group) noexcept
{
    _group = group;
}

void RadioButton::Paint(ControlHost& host) const
{
    const bool rightToLeft             = IsRightToLeft();
    const RadioButtonVisualStyle style = ResolveRadioButtonVisualStyle(host.GetTheme(),
                                                                       IsEnabled(),
                                                                       IsHovered(),
                                                                       IsPressed(),
                                                                       HasFocus(),
                                                                       host.IsKeyboardFocusVisible(),
                                                                       _checked,
                                                                       ResolveHoverAnimationProgress(host),
                                                                       ResolveFocusAnimationProgress(host));

    const D2D1_RECT_F bounds      = GetBounds();
    const D2D1_RECT_F contentRect = D2D1::RectF(bounds.left + 1.0f, bounds.top + 1.0f, bounds.right - 1.0f, bounds.bottom - 1.0f);
    if (style.showHoverFill)
    {
        DrawRoundedRect(host, contentRect, style.hoverFill, style.hoverFill, 4.0f);
    }
    if (style.showFocus)
    {
        PaintFocusRing(host, contentRect, 4.0f);
    }

    // 20 DIP outer circle (spec §3.3)
    constexpr float circleSize   = 20.0f;
    const float circleTop        = contentRect.top + ((contentRect.bottom - contentRect.top - circleSize) * 0.5f);
    const float circleCenterX    = rightToLeft ? (contentRect.right - 6.0f - (circleSize * 0.5f)) : (contentRect.left + 6.0f + circleSize * 0.5f);
    const float circleCenterY    = circleTop + circleSize * 0.5f;
    const D2D1_ELLIPSE outerRing = D2D1::Ellipse(D2D1::Point2F(circleCenterX, circleCenterY), circleSize * 0.5f, circleSize * 0.5f);

    FillEllipseWithColor(host, outerRing, style.circleFill);
    DrawEllipseWithColor(host, outerRing, style.circleBorder, 1.0f);

    if (_checked)
    {
        const float dotRadius       = style.dotDiameterDip * 0.5f;
        const D2D1_ELLIPSE innerDot = D2D1::Ellipse(D2D1::Point2F(circleCenterX, circleCenterY), dotRadius, dotRadius);
        FillEllipseWithColor(host, innerDot, style.dotFill);
    }

    DrawTextWithMnemonic(
        host,
        GetText(),
        rightToLeft ? D2D1::RectF(contentRect.left + 4.0f, contentRect.top + 2.0f, circleCenterX - (circleSize * 0.5f) - 8.0f, contentRect.bottom - 2.0f)
                    : D2D1::RectF(contentRect.left + 6.0f + circleSize + 8.0f, contentRect.top + 2.0f, contentRect.right - 4.0f, contentRect.bottom - 2.0f),
        FontRole::Body,
        style.text,
        GetMnemonic(),
        // The text format reads in the flow's direction, so leading hugs the circle on either side.
        DWRITE_TEXT_ALIGNMENT_LEADING,
        DWRITE_PARAGRAPH_ALIGNMENT_CENTER,
        false,
        GetFlowDirection());
}

bool RadioButton::OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    if (rightButton || ! IsEnabled())
    {
        return false;
    }

    const bool wasPressed = IsPressed();
    SetPressed(false);
    const bool activate = wasPressed && PointInRect(GetHitBounds(), point);
    if (! activate)
    {
        Invalidate(host);
        return wasPressed;
    }

    SelectSelf(host);
    return true;
}

bool RadioButton::OnKeyDown(ControlHost& host, UINT virtualKey, UINT modifiers)
{
    if (virtualKey == VK_SPACE || virtualKey == VK_RETURN)
    {
        SelectSelf(host);
        return true;
    }
    return Button::OnKeyDown(host, virtualKey, modifiers);
}

bool RadioButton::OnMnemonic(ControlHost& host)
{
    if (! IsEnabled() || ! IsVisible())
    {
        return false;
    }

    if (FocusControlAndSurvive(host, *this, true))
    {
        SelectSelf(host);
    }
    return true;
}

void RadioButton::SelectSelf(ControlHost& host)
{
    if (! _checked)
    {
        const std::weak_ptr<int> selfLifetime = GetLifetimeToken();
        const auto onSelected                 = _onSelected;
        if (_group)
        {
            _group->SelectItem(this);
        }
        else
        {
            _checked = true;
            Invalidate(host);
        }
        if (selfLifetime.expired())
        {
            return;
        }
        if (onSelected)
        {
            (*onSelected)();
        }
    }
}

// --- RadioButtons group ---

RadioButton* RadioButtons::AddItem(std::wstring text)
{
    auto* item = AddChild<RadioButton>(std::move(text));
    item->SetGroup(this);
    return item;
}

void RadioButtons::SetSelectedIndex(int index) noexcept
{
    const auto children = GetChildren();
    const int count     = static_cast<int>(children.size());
    if (index < 0 || index >= count)
    {
        _selectedIndex = -1;
        for (auto& child : children)
        {
            if (auto* rb = dynamic_cast<RadioButton*>(child.get()))
            {
                rb->SetChecked(false);
            }
        }
        return;
    }

    _selectedIndex = index;
    for (int i = 0; i < count; ++i)
    {
        if (auto* rb = dynamic_cast<RadioButton*>(children[static_cast<size_t>(i)].get()))
        {
            rb->SetChecked(i == index);
        }
    }
}

int RadioButtons::GetSelectedIndex() const noexcept
{
    return _selectedIndex;
}

void RadioButtons::SetOnSelectionChanged(std::function<void(int)> onSelectionChanged)
{
    ReplaceControlCallback(_onSelectionChanged, std::move(onSelectionChanged));
}

void RadioButtons::SetHeader(std::wstring text)
{
    _header = std::move(text);
    RequestInvalidate();
}

void RadioButtons::SelectItem(RadioButton* item)
{
    const auto children = GetChildren();
    const int count     = static_cast<int>(children.size());
    for (int i = 0; i < count; ++i)
    {
        auto* rb = dynamic_cast<RadioButton*>(children[static_cast<size_t>(i)].get());
        if (rb)
        {
            rb->SetChecked(rb == item);
        }
    }
    for (int i = 0; i < count; ++i)
    {
        if (children[static_cast<size_t>(i)].get() == item)
        {
            _selectedIndex = i;
            break;
        }
    }
    const auto onSelectionChanged = _onSelectionChanged;
    if (onSelectionChanged)
    {
        (*onSelectionChanged)(_selectedIndex);
    }
}

void RadioButtons::Paint(ControlHost& host) const
{
    if (! _header.empty())
    {
        const D2D1_RECT_F bounds = GetBounds();
        DrawCenteredText(
            host, _header, D2D1::RectF(bounds.left + 4.0f, bounds.top, bounds.right - 4.0f, bounds.top + 20.0f), FontRole::BodyStrong, host.GetTheme().text);
    }
    Panel::Paint(host);
}

// --- ProgressBar ---

namespace
{
// One indeterminate sweep (spec §3.8). Reduced motion rests the segment at the phase that centers it.
constexpr uint64_t kIndeterminateLoopMs          = 2000u;
constexpr float kReducedMotionIndeterminatePhase = 0.5f;

struct ProgressTrack
{
    D2D1_RECT_F rect{};
    float height = 0.0f;
};

[[nodiscard]] ProgressTrack ComputeProgressTrack(const D2D1_RECT_F& bounds, bool indeterminate, float trackHeightDip) noexcept
{
    // Track: 2 DIP rest, 4 DIP indeterminate (spec §3.8)
    const float availableHeight    = std::max(0.0f, bounds.bottom - bounds.top);
    const float defaultTrackHeight = indeterminate ? 4.0f : 2.0f;
    const float trackHeight        = std::min(availableHeight, trackHeightDip > 0.0f ? trackHeightDip : defaultTrackHeight);
    const float trackTop           = bounds.top + ((bounds.bottom - bounds.top - trackHeight) * 0.5f);
    return ProgressTrack{D2D1::RectF(bounds.left, trackTop, bounds.right, trackTop + trackHeight), trackHeight};
}

[[nodiscard]] float ResolveIndeterminatePhase(const ThemePalette& theme, float animationPhase) noexcept
{
    return theme.reducedMotion ? kReducedMotionIndeterminatePhase : animationPhase;
}

[[nodiscard]] D2D1_RECT_F ComputeIndeterminateSegmentRect(const D2D1_RECT_F& track, float phase) noexcept
{
    // 40% segment across the track (spec §3.8). Phase 0..1 moves it from off-screen left to off-screen right.
    const float trackWidth   = track.right - track.left;
    const float segmentWidth = trackWidth * 0.4f;
    const float leading      = track.left + (trackWidth + segmentWidth) * phase - segmentWidth;
    const float segLeft      = (std::max)(leading, track.left);
    const float segRight     = (std::min)(leading + segmentWidth, track.right);
    return D2D1::RectF(segLeft, track.top, (std::max)(segLeft, segRight), track.bottom);
}
} // namespace

void ProgressBar::SetValue(double value) noexcept
{
    // Like Slider, a non-finite value is rejected: NaN would reach UI Automation and never compare equal.
    if (! std::isfinite(value))
        return;
    _value = value;
    RequestInvalidate();
    if (ControlHost* const host = GetHost())
        RefreshWindowHostAccessibilitySnapshot(host->GetHwnd(), host);
}

double ProgressBar::GetValue() const noexcept
{
    return _value;
}

void ProgressBar::SetMinimum(double minimum) noexcept
{
    if (! std::isfinite(minimum))
        return;
    _minimum = minimum;
    RequestInvalidate();
}

double ProgressBar::GetMinimum() const noexcept
{
    return _minimum;
}

void ProgressBar::SetMaximum(double maximum) noexcept
{
    if (! std::isfinite(maximum))
        return;
    _maximum = maximum;
    RequestInvalidate();
}

double ProgressBar::GetMaximum() const noexcept
{
    return _maximum;
}

void ProgressBar::SetIndeterminate(bool indeterminate) noexcept
{
    if (_indeterminate == indeterminate)
    {
        return;
    }

    _indeterminate  = indeterminate;
    _animationPhase = 0.0f;
    _lastTickMs     = 0u;
    if (indeterminate && IsEnabled() && IsVisible())
    {
        if (ControlHost* host = GetHost(); host && ! host->GetTheme().reducedMotion)
        {
            host->RequestAnimation();
        }
    }
    RequestInvalidate();
}

bool ProgressBar::IsIndeterminate() const noexcept
{
    return _indeterminate;
}

void ProgressBar::SetTrackHeightDip(float heightDip) noexcept
{
    const float next = std::max(0.0f, heightDip);
    if (_trackHeightDip != next)
    {
        _trackHeightDip = next;
        RequestInvalidate();
    }
}

float ProgressBar::GetTrackHeightDip() const noexcept
{
    return _trackHeightDip;
}

void ProgressBar::SetSegmentedValues(double primaryValue, double secondaryValue, D2D1_COLOR_F secondaryColor) noexcept
{
    _primarySegmentValue   = primaryValue;
    _secondarySegmentValue = secondaryValue;
    _secondarySegmentColor = secondaryColor;
    _segmented             = true;
    RequestInvalidate();
}

void ProgressBar::ClearSegmentedValues() noexcept
{
    if (! _segmented)
    {
        return;
    }
    _segmented = false;
    RequestInvalidate();
}

bool ProgressBar::HasSegmentedValues() const noexcept
{
    return _segmented;
}

void ProgressBar::Paint(ControlHost& host) const
{
    const ThemePalette& theme          = host.GetTheme();
    const ProgressBarVisualStyle style = ResolveProgressBarVisualStyle(theme);
    const D2D1_RECT_F bounds           = GetBounds();
    const auto oriented                = [&](D2D1_RECT_F rect) noexcept
    {
        if (IsRightToLeft())
        {
            const float left = bounds.left + bounds.right - rect.right;
            rect.right       = bounds.left + bounds.right - rect.left;
            rect.left        = left;
        }
        return rect;
    };

    // Reduced motion paints a resting segment and requests no ticks.
    if (_indeterminate && IsEnabled() && IsVisible() && ! theme.reducedMotion && bounds.right > bounds.left && bounds.bottom > bounds.top)
    {
        host.RequestAnimation();
    }

    const ProgressTrack progressTrack = ComputeProgressTrack(bounds, _indeterminate, _trackHeightDip);
    const D2D1_RECT_F track           = progressTrack.rect;
    const float trackTop              = track.top;
    const float trackHeight           = progressTrack.height;
    const float radius                = trackHeight * 0.5f;

    DrawRoundedRect(host, track, style.trackFill, style.trackFill, radius);

    if (_indeterminate)
    {
        const D2D1_RECT_F seg = oriented(ComputeIndeterminateSegmentRect(track, ResolveIndeterminatePhase(theme, _animationPhase)));
        if (seg.right > seg.left)
        {
            DrawRoundedRect(host, seg, style.progressFill, style.progressFill, radius);
        }
    }
    else if (_segmented)
    {
        const double range             = (_maximum > _minimum) ? (_maximum - _minimum) : 1.0;
        const double primaryFraction   = std::clamp((_primarySegmentValue - _minimum) / range, 0.0, 1.0);
        const double secondaryFraction = std::clamp((_secondarySegmentValue - _minimum) / range, 0.0, 1.0);
        const float midpoint           = bounds.left + (bounds.right - bounds.left) * 0.5f;
        const float primaryWidth       = static_cast<float>(primaryFraction) * (midpoint - bounds.left);
        if (primaryWidth > 0.5f)
        {
            const D2D1_RECT_F primaryFill = oriented(D2D1::RectF(bounds.left, trackTop, bounds.left + primaryWidth, trackTop + trackHeight));
            DrawRoundedRect(host, primaryFill, style.progressFill, style.progressFill, radius);
        }

        const float secondaryWidth = static_cast<float>(secondaryFraction) * (bounds.right - midpoint);
        if (secondaryWidth > 0.5f)
        {
            const D2D1_RECT_F secondaryFill = oriented(D2D1::RectF(midpoint, trackTop, midpoint + secondaryWidth, trackTop + trackHeight));
            const auto secondaryColor       = theme.highContrast ? style.trackFill : _secondarySegmentColor;
            DrawRoundedRect(host, secondaryFill, secondaryColor, secondaryColor, radius);

            auto* const context    = host.GetDeviceContext();
            auto* const hatchBrush = host.GetSolidBrush(style.progressFill);
            if (context && hatchBrush)
            {
                context->PushAxisAlignedClip(secondaryFill, D2D1_ANTIALIAS_MODE_ALIASED);
                constexpr float hatchStep = 5.0f;
                for (float x = secondaryFill.left - trackHeight; x < secondaryFill.right; x += hatchStep)
                {
                    context->DrawLine(D2D1::Point2F(x, secondaryFill.bottom), D2D1::Point2F(x + trackHeight, secondaryFill.top), hatchBrush, 1.0f);
                }
                context->PopAxisAlignedClip();
            }
        }

        if (auto* dividerBrush = host.GetSolidBrush(style.trackFill); dividerBrush && host.GetDeviceContext())
        {
            host.GetDeviceContext()->DrawLine(D2D1::Point2F(midpoint, trackTop), D2D1::Point2F(midpoint, trackTop + trackHeight), dividerBrush, 1.0f);
        }
    }
    else
    {
        const double range    = (_maximum > _minimum) ? (_maximum - _minimum) : 1.0;
        const double fraction = std::clamp((_value - _minimum) / range, 0.0, 1.0);
        const float fillWidth = static_cast<float>(fraction) * (bounds.right - bounds.left);
        if (fillWidth > 0.5f)
        {
            const D2D1_RECT_F fill = oriented(D2D1::RectF(bounds.left, trackTop, bounds.left + fillWidth, trackTop + trackHeight));
            DrawRoundedRect(host, fill, style.progressFill, style.progressFill, radius);
        }
    }
}

bool ProgressBar::Tick(ControlHost& host, uint64_t nowTickMs)
{
    // An empty bar has nothing to sweep: it requests no frames until it has bounds again.
    const D2D1_RECT_F bounds = GetBounds();
    if (! _indeterminate || ! IsEnabled() || ! IsVisible() || host.GetTheme().reducedMotion || ! (bounds.right > bounds.left) || ! (bounds.bottom > bounds.top))
    {
        _lastTickMs = 0u;
        return false;
    }

    // The first tick seeds the loop. A clock that moves backwards re-seeds it instead of wrapping the elapsed time.
    if (_lastTickMs == 0 || nowTickMs < _lastTickMs)
    {
        _lastTickMs = nowTickMs;
    }
    const uint64_t elapsed = nowTickMs - _lastTickMs;
    _lastTickMs            = nowTickMs;

    // Whole loops are dropped before converting, so any elapsed time advances the phase by less than one loop.
    _animationPhase += static_cast<float>(elapsed % kIndeterminateLoopMs) / static_cast<float>(kIndeterminateLoopMs);
    if (_animationPhase >= 1.0f)
    {
        _animationPhase -= 1.0f;
    }
    Invalidate(host);
    return true;
}

#if DXUI_ENABLE_DIAGNOSTICS
D2D1_RECT_F ProgressBar::DebugGetIndeterminateSegmentRect(const ThemePalette& theme) const noexcept
{
    const ProgressTrack progressTrack = ComputeProgressTrack(GetBounds(), true, _trackHeightDip);
    auto rect                         = ComputeIndeterminateSegmentRect(progressTrack.rect, ResolveIndeterminatePhase(theme, _animationPhase));
    if (IsRightToLeft())
    {
        const auto bounds = GetBounds();
        const float left  = bounds.left + bounds.right - rect.right;
        rect.right        = bounds.left + bounds.right - rect.left;
        rect.left         = left;
    }
    return rect;
}
#endif

PageIndicator::PageIndicator()
{
    SetFocusable(true);
}

void PageIndicator::SetPageCount(uint32_t count) noexcept
{
    const uint32_t next = (std::min)(count, kMaximumPages);
    if (_pageCount == next)
    {
        return;
    }
    _pageCount = next;
    if (_pageCount == 0)
    {
        _selectedIndex = 0;
    }
    else if (_selectedIndex >= _pageCount)
    {
        _selectedIndex = _pageCount - 1;
    }
    SetFocusable(_pageCount >= 2);
    RefreshAccessibleName();
    RequestInvalidate();
}

uint32_t PageIndicator::GetPageCount() const noexcept
{
    return _pageCount;
}

void PageIndicator::SetSelectedIndex(uint32_t index) noexcept
{
    if (_pageCount == 0)
    {
        return;
    }
    const uint32_t next = (std::min)(index, _pageCount - 1);
    if (_selectedIndex == next)
    {
        return;
    }
    _selectedIndex = next;
    RefreshAccessibleName();
    RequestInvalidate();
}

uint32_t PageIndicator::GetSelectedIndex() const noexcept
{
    return _selectedIndex;
}

void PageIndicator::SetOnSelected(std::function<void(uint32_t)> onSelected)
{
    ReplaceControlCallback(_onSelected, std::move(onSelected));
}

uint32_t PageIndicator::HitPageIndex(D2D1_POINT_2F point) const noexcept
{
    if (_pageCount < 2 || ! PointInRect(GetBounds(), point))
    {
        return UINT32_MAX;
    }

    float best        = (std::numeric_limits<float>::max)();
    uint32_t hit      = UINT32_MAX;
    const float limit = kDotGapDip * 0.5f;
    for (uint32_t index = 0; index < _pageCount; ++index)
    {
        const D2D1_POINT_2F center = DotCenter(index);
        const float dx             = point.x - center.x;
        const float dy             = point.y - center.y;
        const float distance       = std::sqrt(dx * dx + dy * dy);
        if (distance <= limit && distance < best)
        {
            best = distance;
            hit  = index;
        }
    }
    return hit;
}

D2D1_POINT_2F PageIndicator::DotCenter(uint32_t index) const noexcept
{
    const D2D1_RECT_F bounds = GetBounds();
    const float width        = std::max(0.0f, bounds.right - bounds.left);
    const float total        = _pageCount > 1 ? kDotGapDip * static_cast<float>(_pageCount - 1) : 0.0f;
    const float originX      = bounds.left + (width - total) * 0.5f;
    const float originY      = (bounds.top + bounds.bottom) * 0.5f;
    return D2D1::Point2F(originX + kDotGapDip * static_cast<float>(index), originY);
}

D2D1_RECT_F PageIndicator::GetHitBounds() const noexcept
{
    if (_pageCount < 2)
    {
        return D2D1::RectF();
    }
    return Control::GetHitBounds();
}

void PageIndicator::Paint(ControlHost& host) const
{
    if (_pageCount < 2)
    {
        return;
    }

    const ThemePalette& theme = host.GetTheme();
    for (uint32_t index = 0; index < _pageCount; ++index)
    {
        const bool selected        = index == _selectedIndex;
        const float radius         = selected ? kSelectedDotRadiusDip : kDotRadiusDip;
        const D2D1_POINT_2F center = DotCenter(index);
        const D2D1_ELLIPSE ellipse = D2D1::Ellipse(center, radius, radius);
        const D2D1_COLOR_F fill    = selected ? theme.accent : theme.subduedText;
        FillEllipseWithColor(host, ellipse, fill);
    }

    if (HasFocus() && host.IsKeyboardFocusVisible())
    {
        const D2D1_POINT_2F center = DotCenter(_selectedIndex);
        const float pad            = kSelectedDotRadiusDip + 3.0f;
        PaintFocusRing(host, D2D1::RectF(center.x - pad, center.y - pad, center.x + pad, center.y + pad), pad);
    }
}

bool PageIndicator::OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    if (rightButton || ! IsEnabled() || _pageCount < 2)
    {
        return false;
    }
    const uint32_t hit = HitPageIndex(point);
    if (hit == UINT32_MAX)
    {
        return false;
    }
    if (! FocusControlAndSurvive(host, *this))
    {
        return true;
    }
    _pressed      = true;
    _pressedIndex = hit;
    Invalidate(host);
    return true;
}

bool PageIndicator::OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    if (rightButton || ! _pressed)
    {
        return false;
    }
    const uint32_t pressed = _pressedIndex;
    _pressed               = false;
    _pressedIndex          = UINT32_MAX;
    Invalidate(host);
    if (HitPageIndex(point) == pressed)
    {
        SelectIndex(host, pressed);
    }
    return true;
}

bool PageIndicator::OnKeyDown(ControlHost& host, UINT virtualKey, UINT /*modifiers*/)
{
    if (! IsEnabled() || _pageCount < 2)
    {
        return false;
    }
    switch (virtualKey)
    {
        case VK_LEFT: SelectIndex(host, IsRightToLeft() ? _selectedIndex + 1 : (_selectedIndex == 0 ? 0 : _selectedIndex - 1)); return true;
        case VK_RIGHT: SelectIndex(host, IsRightToLeft() ? (_selectedIndex == 0 ? 0 : _selectedIndex - 1) : _selectedIndex + 1); return true;
        case VK_HOME: SelectIndex(host, IsRightToLeft() ? _pageCount - 1 : 0); return true;
        case VK_END: SelectIndex(host, IsRightToLeft() ? 0 : _pageCount - 1); return true;
        default: return false;
    }
}

void PageIndicator::OnCaptureLost(ControlHost& host)
{
    if (! _pressed)
    {
        return;
    }
    _pressed      = false;
    _pressedIndex = UINT32_MAX;
    Invalidate(host);
}

void PageIndicator::SelectIndex(ControlHost& host, uint32_t index)
{
    if (_pageCount < 2 || index >= _pageCount || index == _selectedIndex)
    {
        return;
    }
    _selectedIndex                    = index;
    const std::weak_ptr<int> lifetime = GetLifetimeToken();
    RefreshAccessibleName();
    if (lifetime.expired())
    {
        return;
    }
    Invalidate(host);
    if (_onSelected)
    {
        const auto onSelected = _onSelected;
        (*onSelected)(index);
    }
}

void PageIndicator::RefreshAccessibleName() noexcept
{
    if (_pageCount < 2)
    {
        SetAccessibleName({});
        return;
    }
    try
    {
        SetAccessibleName(L"Page " + std::to_wstring(_selectedIndex + 1) + L" of " + std::to_wstring(_pageCount));
    }
    catch (...)
    {
    }
}

// --- Slider ---

Slider::Slider()
{
    SetFocusable(true);
}

D2D1_COLOR_F ThroughputGraphColorFromHue(float hueDegrees, bool dark) noexcept
{
    float hue = std::fmod(hueDegrees, 360.0f);
    if (hue < 0.0f)
    {
        hue += 360.0f;
    }
    const float saturation = dark ? 0.78f : 0.86f;
    const float value      = dark ? 0.92f : 0.76f;
    const float chroma     = value * saturation;
    const float section    = hue / 60.0f;
    const float x          = chroma * (1.0f - std::abs(std::fmod(section, 2.0f) - 1.0f));
    float red              = 0.0f;
    float green            = 0.0f;
    float blue             = 0.0f;
    if (section < 1.0f)
    {
        red   = chroma;
        green = x;
    }
    else if (section < 2.0f)
    {
        red   = x;
        green = chroma;
    }
    else if (section < 3.0f)
    {
        green = chroma;
        blue  = x;
    }
    else if (section < 4.0f)
    {
        green = x;
        blue  = chroma;
    }
    else if (section < 5.0f)
    {
        red  = x;
        blue = chroma;
    }
    else
    {
        red  = chroma;
        blue = x;
    }
    const float match = value - chroma;
    return D2D1::ColorF(red + match, green + match, blue + match, 1.0f);
}

namespace
{
[[nodiscard]] wil::com_ptr<ID2D1PathGeometry> CreateThroughputGraphAreaGeometry(
    ID2D1RenderTarget* context, const D2D1_RECT_F& bounds, std::span<const ThroughputGraphSample> samples, double displayedLatestValue, double maximum) noexcept
{
    wil::com_ptr<ID2D1PathGeometry> geometry;
    if (! context || samples.size() < 2u || maximum <= 0.0)
    {
        return geometry;
    }

    wil::com_ptr<ID2D1Factory> factory;
    context->GetFactory(factory.addressof());
    if (! factory || FAILED(factory->CreatePathGeometry(geometry.addressof())) || ! geometry)
    {
        geometry.reset();
        return geometry;
    }

    wil::com_ptr<ID2D1GeometrySink> sink;
    if (FAILED(geometry->Open(sink.addressof())) || ! sink)
    {
        geometry.reset();
        return geometry;
    }

    const float width  = bounds.right - bounds.left;
    const float height = bounds.bottom - bounds.top;
    const float step   = width / static_cast<float>(samples.size() - 1u);

    sink->BeginFigure(D2D1::Point2F(bounds.left, bounds.bottom), D2D1_FIGURE_BEGIN_FILLED);
    for (size_t index = 0u; index < samples.size(); ++index)
    {
        const double value       = index + 1u == samples.size() ? displayedLatestValue : samples[index].value;
        const double finiteValue = std::isfinite(value) ? std::max(0.0, value) : 0.0;
        const float x            = bounds.left + step * static_cast<float>(index);
        const float y            = bounds.bottom - static_cast<float>(finiteValue / maximum) * height;
        sink->AddLine(D2D1::Point2F(x, std::clamp(y, bounds.top, bounds.bottom)));
    }
    sink->AddLine(D2D1::Point2F(bounds.right, bounds.bottom));
    sink->EndFigure(D2D1_FIGURE_END_CLOSED);
    if (FAILED(sink->Close()))
    {
        geometry.reset();
    }
    return geometry;
}

[[nodiscard]] size_t MaximumConcurrentThroughputGraphColorSlots(std::span<const ThroughputGraphSample> samples) noexcept
{
    size_t maximum = 0u;
    for (const auto& sample : samples)
    {
        std::array<bool, ThroughputGraphSample::kMaxHueWeights> present{};
        size_t count             = 0u;
        const size_t weightCount = std::min(sample.hueWeightCount, sample.hueWeights.size());
        for (size_t weightIndex = 0u; weightIndex < weightCount; ++weightIndex)
        {
            const auto& weight = sample.hueWeights[weightIndex];
            if (weight.weight <= 0.0 || weight.colorSlot >= present.size() || present[weight.colorSlot])
            {
                continue;
            }
            present[weight.colorSlot] = true;
            ++count;
        }
        maximum = std::max(maximum, count);
    }
    return maximum;
}
} // namespace

bool ShouldRenderThroughputGraphBands(bool rainbowMode, bool perStreamBands, bool highContrast, size_t maximumConcurrentColorSlots) noexcept
{
    if (highContrast || maximumConcurrentColorSlots == 0u)
    {
        return false;
    }
    return rainbowMode || (perStreamBands && maximumConcurrentColorSlots >= 2u);
}

ThroughputGraphBandPaintMetrics PaintThroughputGraphBands(ID2D1RenderTarget* target,
                                                          const D2D1_RECT_F& bounds,
                                                          std::span<const ThroughputGraphSample> samples,
                                                          double displayedLatestValue,
                                                          double maximum,
                                                          const ThroughputGraphBandPaintOptions& options) noexcept
{
    ThroughputGraphBandPaintMetrics metrics{};
    metrics.sampleCount  = samples.size();
    metrics.fillAlpha    = std::clamp(options.baseFillColor.a, 0.0f, 1.0f);
    const auto startedAt = std::chrono::steady_clock::now();
    const auto finish    = [&]() noexcept
    {
        metrics.renderDurationUs = Debug::Perf::ElapsedUs(startedAt);
        return metrics;
    };

    if (! target || samples.size() < 2u || bounds.right <= bounds.left || bounds.bottom <= bounds.top || ! std::isfinite(maximum) || maximum <= 0.0)
    {
        return finish();
    }

    const size_t maximumConcurrentColorSlots = MaximumConcurrentThroughputGraphColorSlots(samples);
    metrics.bandsActive = ShouldRenderThroughputGraphBands(options.rainbowMode, options.perStreamBands, options.highContrast, maximumConcurrentColorSlots);

    wil::com_ptr<ID2D1SolidColorBrush> brush;
    if (FAILED(target->CreateSolidColorBrush(options.baseFillColor, brush.addressof())) || ! brush)
    {
        return finish();
    }

    if (! metrics.bandsActive)
    {
        const wil::com_ptr<ID2D1PathGeometry> areaGeometry = CreateThroughputGraphAreaGeometry(target, bounds, samples, displayedLatestValue, maximum);
        if (areaGeometry)
        {
            target->FillGeometry(areaGeometry.get(), brush.get());
            metrics.geometryCount = 1u;
        }
        return finish();
    }

    constexpr size_t kFallbackBatch = ThroughputGraphSample::kMaxHueWeights;
    constexpr size_t kBatchCount    = kFallbackBatch + 1u;
    struct BandBatch final
    {
        std::array<float, ThroughputGraphSample::kMaxSamples> lowerShares{};
        std::array<float, ThroughputGraphSample::kMaxSamples> upperShares{};
        float hueDegrees = -1.0f;
        bool active      = false;
    };
    std::array<BandBatch, kBatchCount> batches{};
    std::array<bool, ThroughputGraphSample::kMaxHueWeights> activeSlots{};

    const size_t sampleCount = std::min(samples.size(), ThroughputGraphSample::kMaxSamples);
    for (size_t index = 0u; index < sampleCount; ++index)
    {
        const auto& sample = samples[index];
        std::array<double, ThroughputGraphSample::kMaxHueWeights> weightsBySlot{};
        std::array<float, ThroughputGraphSample::kMaxHueWeights> huesBySlot{};
        huesBySlot.fill(-1.0f);
        double totalWeight       = 0.0;
        const size_t weightCount = std::min(sample.hueWeightCount, sample.hueWeights.size());
        for (size_t weightIndex = 0u; weightIndex < weightCount; ++weightIndex)
        {
            const auto& weight = sample.hueWeights[weightIndex];
            if (weight.weight <= 0.0 || weight.colorSlot >= weightsBySlot.size())
            {
                continue;
            }
            weightsBySlot[weight.colorSlot] += weight.weight;
            totalWeight += weight.weight;
            if (huesBySlot[weight.colorSlot] < 0.0f && weight.hueDegrees >= 0.0f)
            {
                huesBySlot[weight.colorSlot] = weight.hueDegrees;
            }
        }

        double lowerShare = 0.0;

        const auto setBandColumn = [&](size_t batchIndex, float hueDegrees, double requestedUpperShare, bool active) noexcept
        {
            const float lower = std::clamp(static_cast<float>(lowerShare), 0.0f, 1.0f);
            const float upper = std::clamp(static_cast<float>(requestedUpperShare), 0.0f, 1.0f);
            lowerShare        = requestedUpperShare;
            BandBatch& batch  = batches[batchIndex];
            if (batch.hueDegrees < 0.0f && hueDegrees >= 0.0f)
            {
                batch.hueDegrees = hueDegrees;
            }
            batch.lowerShares[index] = lower;
            batch.upperShares[index] = upper;
            batch.active             = batch.active || active;
        };

        if (totalWeight <= 0.0)
        {
            for (size_t colorSlot = 0u; colorSlot < weightsBySlot.size(); ++colorSlot)
            {
                setBandColumn(colorSlot, -1.0f, 0.0, false);
            }
            setBandColumn(kFallbackBatch, -1.0f, 1.0, true);
            continue;
        }

        for (size_t colorSlot = 0u; colorSlot < weightsBySlot.size(); ++colorSlot)
        {
            const bool active       = weightsBySlot[colorSlot] > 0.0;
            activeSlots[colorSlot]  = activeSlots[colorSlot] || active;
            const double upperShare = lowerShare + weightsBySlot[colorSlot] / totalWeight;
            setBandColumn(colorSlot, huesBySlot[colorSlot], upperShare, active);
        }
        setBandColumn(kFallbackBatch, -1.0f, lowerShare, false);
    }

    metrics.activeColorSlotCount = static_cast<size_t>(std::ranges::count(activeSlots, true));
    constexpr size_t kRasterRows = ThroughputGraphSample::kMaxHueWeights * 4u;
    std::array<uint32_t, ThroughputGraphSample::kMaxSamples * kRasterRows> pixels{};
    const auto packPremultipliedBgra = [](D2D1_COLOR_F color) noexcept
    {
        const float alpha  = std::clamp(color.a, 0.0f, 1.0f);
        const auto channel = [alpha](float value) noexcept { return static_cast<uint32_t>(std::lround(std::clamp(value, 0.0f, 1.0f) * alpha * 255.0f)); };
        const uint32_t a   = static_cast<uint32_t>(std::lround(alpha * 255.0f));
        return channel(color.b) | (channel(color.g) << 8u) | (channel(color.r) << 16u) | (a << 24u);
    };
    const uint32_t basePixel = packPremultipliedBgra(options.baseFillColor);
    std::fill_n(pixels.begin(), sampleCount * kRasterRows, basePixel);
    for (size_t batchIndex = 0u; batchIndex < batches.size(); ++batchIndex)
    {
        const BandBatch& batch = batches[batchIndex];
        if (! batch.active)
        {
            continue;
        }
        D2D1_COLOR_F color = options.baseFillColor;
        if (batchIndex < ThroughputGraphSample::kMaxHueWeights && batch.hueDegrees >= 0.0f)
        {
            color   = ThroughputGraphColorFromHue(batch.hueDegrees, options.dark);
            color.a = metrics.fillAlpha;
        }
        const uint32_t colorPixel = packPremultipliedBgra(color);
        for (size_t sampleIndex = 0u; sampleIndex < sampleCount; ++sampleIndex)
        {
            const float lower = batch.lowerShares[sampleIndex];
            const float upper = batch.upperShares[sampleIndex];
            if (upper <= lower)
            {
                continue;
            }
            const size_t topRow    = std::min(kRasterRows, static_cast<size_t>(std::floor((1.0f - std::clamp(upper, 0.0f, 1.0f)) * kRasterRows)));
            const size_t bottomRow = std::min(kRasterRows, static_cast<size_t>(std::ceil((1.0f - std::clamp(lower, 0.0f, 1.0f)) * kRasterRows)));
            for (size_t row = topRow; row < bottomRow; ++row)
            {
                pixels[row * sampleCount + sampleIndex] = colorPixel;
            }
        }
        metrics.quadCount += sampleCount - 1u;
    }

    const D2D1_BITMAP_PROPERTIES bitmapProperties =
        D2D1::BitmapProperties(D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED), 96.0f, 96.0f);
    wil::com_ptr<ID2D1Bitmap> bandBitmap;
    if (FAILED(target->CreateBitmap(D2D1::SizeU(static_cast<UINT32>(sampleCount), static_cast<UINT32>(kRasterRows)),
                                    pixels.data(),
                                    static_cast<UINT32>(sampleCount * sizeof(uint32_t)),
                                    &bitmapProperties,
                                    bandBitmap.addressof())) ||
        ! bandBitmap)
    {
        return finish();
    }
    const wil::com_ptr<ID2D1PathGeometry> areaGeometry =
        CreateThroughputGraphAreaGeometry(target, bounds, samples.first(sampleCount), displayedLatestValue, maximum);
    if (! areaGeometry)
    {
        return finish();
    }
    wil::com_ptr<ID2D1Layer> layer;
    if (FAILED(target->CreateLayer(layer.addressof())) || ! layer)
    {
        return finish();
    }
    const D2D1_LAYER_PARAMETERS layerParameters = D2D1::LayerParameters(bounds, areaGeometry.get());
    target->PushLayer(layerParameters, layer.get());
    target->DrawBitmap(bandBitmap.get(), bounds, 1.0f, D2D1_BITMAP_INTERPOLATION_MODE_NEAREST_NEIGHBOR);
    target->PopLayer();
    metrics.geometryCount = 1u;
    return finish();
}

void ThroughputGraph::SetSamples(std::span<const ThroughputGraphSample> samples)
{
    const double previousTarget = _targetLatestValue;
    const size_t retainedCount  = std::min(samples.size(), ThroughputGraphSample::kMaxSamples);
    _samples.assign(samples.end() - static_cast<std::ptrdiff_t>(retainedCount), samples.end());
    _targetLatestValue = _samples.empty() ? 0.0 : std::max(0.0, _samples.back().value);

    ControlHost* const host  = GetHost();
    const bool targetChanged = previousTarget != _targetLatestValue;
    if (host && ! host->GetTheme().reducedMotion && ! _samples.empty() && targetChanged)
    {
        _transitionStartValue  = _displayedLatestValue;
        _transitionStartTickMs = 0u;
        _transitionActive      = true;
        host->RequestAnimation();
    }
    else if (! _transitionActive || ! host || host->GetTheme().reducedMotion || _samples.empty())
    {
        _displayedLatestValue = _targetLatestValue;
        _transitionActive     = false;
    }
    RequestInvalidate();
}

void ThroughputGraph::SetSecondarySamples(std::span<const double> samples)
{
    const size_t retainedCount = std::min(samples.size(), ThroughputGraphSample::kMaxSamples);
    _secondarySamples.assign(samples.end() - static_cast<std::ptrdiff_t>(retainedCount), samples.end());
    for (double& sample : _secondarySamples)
    {
        sample = std::max(0.0, sample);
    }
    RequestInvalidate();
}

void ThroughputGraph::SetSecondarySeriesColor(D2D1_COLOR_F color) noexcept
{
    _secondarySeriesColor = color;
    RequestInvalidate();
}

void ThroughputGraph::SetLimit(double value) noexcept
{
    _limit = std::max(0.0, value);
    RequestInvalidate();
}

void ThroughputGraph::SetCurrentValueMarker(double value, std::wstring label, std::wstring trailingLabel)
{
    const double nextTarget    = std::max(0.0, value);
    _currentValueLabel         = std::move(label);
    _currentValueTrailingLabel = std::move(trailingLabel);

    ControlHost* const host  = GetHost();
    const bool targetChanged = _targetCurrentValue != nextTarget;
    _targetCurrentValue      = nextTarget;
    if (host && ! host->GetTheme().reducedMotion && targetChanged)
    {
        _currentValueTransitionStart       = _displayedCurrentValue;
        _currentValueTransitionStartTickMs = 0u;
        _currentValueTransitionActive      = true;
        host->RequestAnimation();
    }
    else if (! _currentValueTransitionActive || ! host || host->GetTheme().reducedMotion)
    {
        _displayedCurrentValue        = _targetCurrentValue;
        _currentValueTransitionActive = false;
    }
    RequestInvalidate();
}

void ThroughputGraph::SetOverlayText(std::wstring text)
{
    _overlayText = std::move(text);
    RequestInvalidate();
}

void ThroughputGraph::SetRainbowMode(bool enabled) noexcept
{
    _rainbowMode = enabled;
    RequestInvalidate();
}

void ThroughputGraph::SetPerStreamBands(bool enabled) noexcept
{
    _perStreamBands = enabled;
    RequestInvalidate();
}

void ThroughputGraph::SetTransitionDuration(uint64_t durationMs) noexcept
{
    _transitionDurationMs = std::max<uint64_t>(1u, durationMs);
}

ThroughputGraphDebugState ThroughputGraph::GetDebugState() const noexcept
{
    ThroughputGraphDebugState state{};
    state.sampleCount                      = _samples.size();
    state.usesRainbowStroke                = _rainbowMode && ! _lastHighContrast;
    state.renderedQuadCount                = _lastBandPaintMetrics.quadCount;
    state.renderedGeometryCount            = _lastBandPaintMetrics.geometryCount;
    state.activeColorSlotCount             = _lastBandPaintMetrics.activeColorSlotCount;
    state.bandsActive                      = _lastBandPaintMetrics.bandsActive;
    state.transitionActive                 = _transitionActive;
    state.reducedMotion                    = _lastReducedMotion;
    state.highContrast                     = _lastHighContrast;
    state.bandRenderDurationUs             = _lastBandPaintMetrics.renderDurationUs;
    state.bandFillAlpha                    = _lastBandPaintMetrics.fillAlpha;
    state.displayedLatestValue             = _displayedLatestValue;
    state.targetLatestValue                = _targetLatestValue;
    state.currentValueMarkerVisible        = _displayedCurrentValue > 0.0 || _targetCurrentValue > 0.0;
    state.secondarySeriesVisible           = std::ranges::any_of(_secondarySamples, [](double value) noexcept { return value > 0.0; });
    state.secondarySeriesColorCustomized   = _secondarySeriesColor.has_value();
    state.currentValueTrailingLabelVisible = ! _currentValueTrailingLabel.empty();
    state.displayedCurrentValue            = _displayedCurrentValue;
    state.targetCurrentValue               = _targetCurrentValue;
    for (const auto& sample : _samples)
    {
        state.hueBandCount += std::min(sample.hueWeightCount, sample.hueWeights.size());
    }
    return state;
}

void ThroughputGraph::Paint(ControlHost& host) const
{
    const ThemePalette& palette = host.GetTheme();
    _lastReducedMotion          = palette.reducedMotion;
    _lastHighContrast           = palette.highContrast;
    _lastBandPaintMetrics       = {};

    auto* context = host.GetDeviceContext();
    if (! context)
    {
        return;
    }

    const D2D1_RECT_F bounds = GetBounds();
    if (bounds.right <= bounds.left || bounds.bottom <= bounds.top)
    {
        return;
    }

    if (auto* background = host.GetSolidBrush(palette.surfaceBackground))
    {
        context->FillRectangle(bounds, background);
    }
    if (auto* grid = host.GetSolidBrush(palette.gridLine))
    {
        for (int line = 1; line < 4; ++line)
        {
            const float y = bounds.top + (bounds.bottom - bounds.top) * static_cast<float>(line) / 4.0f;
            context->DrawLine(D2D1::Point2F(bounds.left, y), D2D1::Point2F(bounds.right, y), grid, 0.75f);
        }
    }

    double observedMaximum = 0.0;
    for (const auto& sample : _samples)
    {
        observedMaximum = std::max(observedMaximum, std::max(0.0, sample.value));
    }
    for (const double sample : _secondarySamples)
    {
        observedMaximum = std::max(observedMaximum, sample);
    }
    observedMaximum                      = std::max(observedMaximum, _displayedLatestValue);
    observedMaximum                      = std::max(observedMaximum, _displayedCurrentValue);
    observedMaximum                      = std::max(observedMaximum, _targetCurrentValue);
    const bool currentValueMarkerVisible = _displayedCurrentValue > 0.0 || _targetCurrentValue > 0.0;
    const double graphMaximum            = currentValueMarkerVisible ? observedMaximum * 1.10 : observedMaximum;
    const double maximum                 = std::max({1.0, _limit, graphMaximum});

    if (_limit > 0.0 && _limit <= maximum)
    {
        const float y = bounds.bottom - static_cast<float>(_limit / maximum) * (bounds.bottom - bounds.top);
        if (auto* limitBrush = host.GetSolidBrush(palette.warningText))
        {
            context->DrawLine(D2D1::Point2F(bounds.left, y), D2D1::Point2F(bounds.right, y), limitBrush, 1.0f);
        }
    }

    if (! _samples.empty())
    {
        const float step = _samples.size() > 1u ? (bounds.right - bounds.left) / static_cast<float>(_samples.size() - 1u) : 0.0f;
        if (_perStreamBands || _rainbowMode)
        {
            D2D1_COLOR_F bandFillColor = palette.accent;
            bandFillColor.a            = palette.highContrast ? 0.32f : (palette.dark ? 0.22f : 0.18f);
            _lastBandPaintMetrics      = PaintThroughputGraphBands(context,
                                                                   bounds,
                                                                   _samples,
                                                                   _displayedLatestValue,
                                                                   maximum,
                                                                   ThroughputGraphBandPaintOptions{
                                                                       .baseFillColor  = bandFillColor,
                                                                       .rainbowMode    = _rainbowMode,
                                                                       .perStreamBands = _perStreamBands,
                                                                       .highContrast   = palette.highContrast,
                                                                       .dark           = palette.dark,
                                                                   });
        }

        if (_samples.size() > 1u)
        {
            for (size_t index = 1u; index < _samples.size(); ++index)
            {
                const auto& previous       = _samples[index - 1u];
                const auto& current        = _samples[index];
                const double previousValue = std::max(0.0, previous.value);
                const double currentValue  = index + 1u == _samples.size() ? _displayedLatestValue : std::max(0.0, current.value);
                const D2D1_POINT_2F from   = D2D1::Point2F(bounds.left + step * static_cast<float>(index - 1u),
                                                           bounds.bottom - static_cast<float>(previousValue / maximum) * (bounds.bottom - bounds.top));
                const D2D1_POINT_2F to     = D2D1::Point2F(bounds.left + step * static_cast<float>(index),
                                                           bounds.bottom - static_cast<float>(currentValue / maximum) * (bounds.bottom - bounds.top));
                const bool useRainbow      = _rainbowMode && ! palette.highContrast && current.hueDegrees >= 0.0f;
                const D2D1_COLOR_F color   = useRainbow ? ThroughputGraphColorFromHue(current.hueDegrees, palette.dark) : palette.accent;
                if (auto* brush = host.GetSolidBrush(color))
                {
                    context->DrawLine(from, to, brush, 2.0f);
                }
            }
        }
    }

    if (_secondarySamples.size() > 1u)
    {
        const float secondaryStep         = (bounds.right - bounds.left) / static_cast<float>(_secondarySamples.size() - 1u);
        const D2D1_COLOR_F secondaryColor = _secondarySeriesColor.value_or(palette.warningText);
        if (auto* secondaryBrush = host.GetSolidBrush(secondaryColor))
        {
            for (size_t index = 1u; index < _secondarySamples.size(); ++index)
            {
                const double previousValue = _secondarySamples[index - 1u];
                const double currentValue  = _secondarySamples[index];
                const D2D1_POINT_2F from   = D2D1::Point2F(bounds.left + secondaryStep * static_cast<float>(index - 1u),
                                                           bounds.bottom - static_cast<float>(previousValue / maximum) * (bounds.bottom - bounds.top));
                const D2D1_POINT_2F to     = D2D1::Point2F(bounds.left + secondaryStep * static_cast<float>(index),
                                                           bounds.bottom - static_cast<float>(currentValue / maximum) * (bounds.bottom - bounds.top));
                context->DrawLine(from, to, secondaryBrush, 1.5f);
            }
        }
    }

    if (currentValueMarkerVisible && maximum > 0.0)
    {
        const float y = bounds.bottom - static_cast<float>(_displayedCurrentValue / maximum) * (bounds.bottom - bounds.top);
        if (auto* markerBrush = host.GetSolidBrush(palette.disabledText))
        {
            context->DrawLine(D2D1::Point2F(bounds.left, y), D2D1::Point2F(bounds.right, y), markerBrush, 1.0f);
        }

        if (! _currentValueLabel.empty())
        {
            constexpr float kLabelInsetDip  = 6.0f;
            constexpr float kLabelGapDip    = 8.0f;
            const float labelCenter         = (bounds.left + bounds.right) * 0.5f;
            const bool hasTrailingLabel     = ! _currentValueTrailingLabel.empty();
            const D2D1_RECT_F leadingBounds = D2D1::RectF(bounds.left + kLabelInsetDip,
                                                          bounds.top + 3.0f,
                                                          hasTrailingLabel ? labelCenter - kLabelGapDip * 0.5f : bounds.right - kLabelInsetDip,
                                                          bounds.bottom);
            if (auto* format = host.GetTextFormat(FontRole::Small, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_NEAR, false))
            {
                if (auto* textBrush = host.GetSolidBrush(palette.text))
                {
                    context->DrawTextW(_currentValueLabel.data(),
                                       static_cast<UINT32>(_currentValueLabel.size()),
                                       format,
                                       leadingBounds,
                                       textBrush,
                                       D2D1_DRAW_TEXT_OPTIONS_CLIP);
                }
            }

            if (hasTrailingLabel)
            {
                if (auto* format = host.GetTextFormat(FontRole::Small, DWRITE_TEXT_ALIGNMENT_TRAILING, DWRITE_PARAGRAPH_ALIGNMENT_NEAR, false))
                {
                    if (auto* textBrush = host.GetSolidBrush(palette.text))
                    {
                        const D2D1_RECT_F trailingBounds =
                            D2D1::RectF(labelCenter + kLabelGapDip * 0.5f, bounds.top + 3.0f, bounds.right - kLabelInsetDip, bounds.bottom);
                        context->DrawTextW(_currentValueTrailingLabel.data(),
                                           static_cast<UINT32>(_currentValueTrailingLabel.size()),
                                           format,
                                           trailingBounds,
                                           textBrush,
                                           D2D1_DRAW_TEXT_OPTIONS_CLIP);
                    }
                }
            }
        }
    }

    if (! _overlayText.empty())
    {
        if (auto* format = host.GetTextFormat(FontRole::Small, DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false))
        {
            if (auto* textBrush = host.GetSolidBrush(palette.text))
            {
                context->DrawTextW(_overlayText.data(), static_cast<UINT32>(_overlayText.size()), format, bounds, textBrush, D2D1_DRAW_TEXT_OPTIONS_CLIP);
            }
        }
    }
}

bool ThroughputGraph::Tick(ControlHost& host, uint64_t nowTickMs)
{
    if (! _transitionActive && ! _currentValueTransitionActive)
    {
        return false;
    }
    if (host.GetTheme().reducedMotion)
    {
        _displayedLatestValue         = _targetLatestValue;
        _displayedCurrentValue        = _targetCurrentValue;
        _transitionActive             = false;
        _currentValueTransitionActive = false;
        Invalidate(host);
        return false;
    }

    const auto advanceTransition =
        [nowTickMs, this](double startValue, double targetValue, uint64_t& startTickMs, double& displayedValue, bool& active) noexcept
    {
        if (! active)
        {
            return;
        }
        if (startTickMs == 0u)
        {
            startTickMs = nowTickMs;
        }
        const uint64_t elapsed = nowTickMs >= startTickMs ? nowTickMs - startTickMs : 0u;
        const double linear    = std::clamp(static_cast<double>(elapsed) / static_cast<double>(_transitionDurationMs), 0.0, 1.0);
        const double eased     = 1.0 - std::pow(1.0 - linear, 3.0);
        displayedValue         = startValue + (targetValue - startValue) * eased;
        active                 = linear < 1.0;
    };

    advanceTransition(_transitionStartValue, _targetLatestValue, _transitionStartTickMs, _displayedLatestValue, _transitionActive);
    advanceTransition(
        _currentValueTransitionStart, _targetCurrentValue, _currentValueTransitionStartTickMs, _displayedCurrentValue, _currentValueTransitionActive);
    Invalidate(host);
    return _transitionActive || _currentValueTransitionActive;
}

void Slider::SetOrientation(SliderOrientation orientation) noexcept
{
    if (_orientation == orientation)
    {
        return;
    }

    _orientation = orientation;
    RequestInvalidate();
}

SliderOrientation Slider::GetOrientation() const noexcept
{
    return _orientation;
}

void Slider::SetMinimum(double minimum) noexcept
{
    if (! std::isfinite(minimum) || ! std::isfinite((std::max)(_maximum, minimum) - minimum))
        return;
    _minimum = minimum;
    if (_maximum < _minimum)
    {
        _maximum = _minimum;
    }
    for (double& tick : _tickMarks)
    {
        tick = ClampValue(tick);
    }
    std::ranges::sort(_tickMarks);
    _value = ClampValue(_value);
    SnapDisplayedValue();
    PublishRangeState();
}

double Slider::GetMinimum() const noexcept
{
    return _minimum;
}

void Slider::SetMaximum(double maximum) noexcept
{
    if (! std::isfinite(maximum) || ! std::isfinite((std::max)(maximum, _minimum) - _minimum))
        return;
    _maximum = (std::max)(maximum, _minimum);
    for (double& tick : _tickMarks)
    {
        tick = ClampValue(tick);
    }
    std::ranges::sort(_tickMarks);
    _value = ClampValue(_value);
    SnapDisplayedValue();
    PublishRangeState();
}

double Slider::GetMaximum() const noexcept
{
    return _maximum;
}

void Slider::SetValue(double value) noexcept
{
    SetValueInternal(nullptr, value, false, false);
}

bool Slider::RequestValue(ControlHost& host, double value) noexcept
{
    if (! IsEnabled() || _dragging || ! std::isfinite(value) || value < _minimum || value > _maximum)
        return false;
    SetValueInternal(&host, value, true, true);
    return true;
}

double Slider::GetValue() const noexcept
{
    return _value;
}

void Slider::SetStep(double step) noexcept
{
    if (! std::isfinite(step))
        return;
    _step      = (std::max)(step, 0.0001);
    _largeStep = (std::max)(_largeStep, _step);
    PublishRangeState();
}

double Slider::GetStep() const noexcept
{
    return _step;
}

void Slider::SetLargeStep(double step) noexcept
{
    if (! std::isfinite(step))
        return;
    _largeStep = (std::max)(step, _step);
    PublishRangeState();
}

double Slider::GetLargeStep() const noexcept
{
    return _largeStep;
}

void Slider::PublishRangeState() noexcept
{
    const std::weak_ptr<int> lifetime = GetLifetimeToken();
    RequestInvalidate();
    if (! lifetime.expired())
        if (ControlHost* const host = GetHost())
            RefreshWindowHostAccessibilitySnapshot(host->GetHwnd(), host);
}

void Slider::SetTickMarks(std::vector<double> tickMarks)
{
    _tickMarks = std::move(tickMarks);
    for (double& tick : _tickMarks)
    {
        tick = ClampValue(tick);
    }
    std::ranges::sort(_tickMarks);
    RequestInvalidate();
}

std::span<const double> Slider::GetTickMarks() const noexcept
{
    return _tickMarks;
}

void Slider::SetOnChange(std::function<void(SliderChange)> onChange)
{
    ReplaceControlCallback(_onChange, std::move(onChange));
}
void Slider::NotifyChange(SliderChangePhase phase, bool notifyLegacy) noexcept
{
    const std::weak_ptr<int> lifetime = GetLifetimeToken();
    try
    {
        const auto life    = GetLifetimeToken();
        const auto legacy  = _onValueChanged;
        const auto changed = _onChange;
        const double value = _value;
        if (notifyLegacy && legacy)
            (*legacy)(value);
        if (! life.expired() && changed)
            (*changed)({phase, value});
    }
    catch (const std::exception&)
    {
        Debug::Warning(L"Slider change callback failed");
    }
    if (! lifetime.expired())
        if (ControlHost* const host = GetHost())
            RefreshWindowHostAccessibilitySnapshot(host->GetHwnd(), host);
}

void Slider::SetOnValueChanged(std::function<void(double)> onValueChanged)
{
    ReplaceControlCallback(_onValueChanged, std::move(onValueChanged));
}

double Slider::ClampValue(double value) const noexcept
{
    if (_maximum <= _minimum)
    {
        return _minimum;
    }
    if (! std::isfinite(value))
        return _value;
    return (std::clamp)(value, _minimum, _maximum);
}

double Slider::GetDisplayedNormalizedValue() const noexcept
{
    if (_maximum <= _minimum)
    {
        return 0.0;
    }
    return (std::clamp)((_displayedValue - _minimum) / (_maximum - _minimum), 0.0, 1.0);
}

void Slider::SnapDisplayedValue() noexcept
{
    _displayedValue            = _value;
    _valueAnimationStart       = _value;
    _valueAnimationTarget      = _value;
    _valueAnimationStartTickMs = 0u;
    _valueAnimationActive      = false;
}

void Slider::BeginValueAnimation(ControlHost& host, double fromValue, double toValue) noexcept
{
    if (host.GetTheme().reducedMotion || std::fabs(fromValue - toValue) <= 0.0001)
    {
        SnapDisplayedValue();
        Invalidate(host);
        return;
    }

    _displayedValue            = fromValue;
    _valueAnimationStart       = fromValue;
    _valueAnimationTarget      = toValue;
    _valueAnimationStartTickMs = ::GetTickCount64();
    _valueAnimationActive      = true;
    host.RequestAnimation();
    Invalidate(host);
}

bool Slider::AdvanceValueAnimation(ControlHost& host, uint64_t nowTickMs) noexcept
{
    if (! _valueAnimationActive)
    {
        return false;
    }
    if (host.GetTheme().reducedMotion)
    {
        SnapDisplayedValue();
        Invalidate(host);
        return false;
    }

    const uint64_t elapsedMs   = nowTickMs > _valueAnimationStartTickMs ? nowTickMs - _valueAnimationStartTickMs : 0u;
    const float linearProgress = std::clamp(static_cast<float>(elapsedMs) / static_cast<float>(_valueAnimationDurationMs), 0.0f, 1.0f);
    const float easedProgress  = EvaluateEasing(EasingCurve::PointToPoint, linearProgress);
    const double previous      = _displayedValue;
    _displayedValue            = std::lerp(_valueAnimationStart, _valueAnimationTarget, static_cast<double>(easedProgress));
    const bool changed         = std::fabs(_displayedValue - previous) > 0.0001;
    if (linearProgress >= 1.0f)
    {
        SnapDisplayedValue();
    }
    if (changed)
    {
        Invalidate(host);
    }
    return _valueAnimationActive || changed;
}

void Slider::BeginVisualTransition(ControlHost& host, VisualTransitionState& transition, float target) noexcept
{
    const float clampedTarget = std::clamp(target, 0.0f, 1.0f);
    if (host.GetTheme().reducedMotion || ! IsEnabled() || ! IsVisible() || std::fabs(transition.progress - clampedTarget) <= 0.0001f)
    {
        transition.progress      = clampedTarget;
        transition.startProgress = clampedTarget;
        transition.target        = clampedTarget;
        transition.startTickMs   = 0u;
        transition.active        = false;
        Invalidate(host);
        return;
    }

    transition.startProgress = transition.progress;
    transition.target        = clampedTarget;
    transition.startTickMs   = ::GetTickCount64();
    transition.active        = true;
    host.RequestAnimation();
    Invalidate(host);
}

bool Slider::AdvanceVisualTransition(VisualTransitionState& transition, uint64_t nowTickMs, EasingCurve curve) noexcept
{
    if (! transition.active)
    {
        return false;
    }

    const uint64_t elapsedMs   = nowTickMs > transition.startTickMs ? nowTickMs - transition.startTickMs : 0u;
    const float linearProgress = std::clamp(static_cast<float>(elapsedMs) / static_cast<float>(_interactionAnimationDurationMs), 0.0f, 1.0f);
    const float easedProgress  = EvaluateEasing(curve, linearProgress);
    const float previous       = transition.progress;
    transition.progress        = std::lerp(transition.startProgress, transition.target, easedProgress);
    const bool changed         = std::fabs(transition.progress - previous) > 0.0001f;
    if (linearProgress >= 1.0f)
    {
        transition.progress      = transition.target;
        transition.startProgress = transition.target;
        transition.startTickMs   = 0u;
        transition.active        = false;
    }
    return transition.active || changed;
}

void Slider::SnapVisualTransitions() noexcept
{
    const float hoverTarget        = (IsHovered() || _dragging) ? 1.0f : 0.0f;
    const float pressTarget        = _dragging ? 1.0f : 0.0f;
    _hoverTransition.progress      = hoverTarget;
    _hoverTransition.startProgress = hoverTarget;
    _hoverTransition.target        = hoverTarget;
    _hoverTransition.startTickMs   = 0u;
    _hoverTransition.active        = false;
    _pressTransition.progress      = pressTarget;
    _pressTransition.startProgress = pressTarget;
    _pressTransition.target        = pressTarget;
    _pressTransition.startTickMs   = 0u;
    _pressTransition.active        = false;
    const float touchTarget        = (_dragging && _touchDragging) ? 1.0f : 0.0f;
    _touchTransition.progress      = touchTarget;
    _touchTransition.startProgress = touchTarget;
    _touchTransition.target        = touchTarget;
    _touchTransition.startTickMs   = 0u;
    _touchTransition.active        = false;
}

void Slider::SyncInteractionVisuals(ControlHost& host) noexcept
{
    BeginVisualTransition(host, _hoverTransition, (IsHovered() || _dragging) ? 1.0f : 0.0f);
    BeginVisualTransition(host, _pressTransition, _dragging ? 1.0f : 0.0f);
    BeginVisualTransition(host, _touchTransition, (_dragging && _touchDragging) ? 1.0f : 0.0f);
}

void Slider::SetValueInternal(ControlHost* host, double value, bool notifyChanged, bool animatePosition) noexcept
{
    if (! std::isfinite(value))
        return;
    const double clamped = ClampValue(value);
    // "Same target" absorbs floating noise, well below the smallest step (0.0001), so a minimum step still moves.
    if (std::fabs(clamped - _value) <= (std::min)(0.0001, _step * 1.0e-3))
    {
        // A model acknowledgement can match the accepted target while the painted thumb is still easing.
        // SetValue is silent and immediate even for that same target; it must also retire animation work.
        if (! animatePosition && _valueAnimationActive)
        {
            SnapDisplayedValue();
            RequestInvalidate();
        }
        return;
    }

    const double previousDisplayed = _displayedValue;
    _value                         = clamped;
    if (_dragging || ! animatePosition || ! host || host->GetTheme().reducedMotion)
    {
        SnapDisplayedValue();
        if (host)
        {
            Invalidate(*host);
        }
        else
        {
            RequestInvalidate();
        }
    }
    else
    {
        BeginValueAnimation(*host, previousDisplayed, _value);
    }

    const std::weak_ptr<int> lifetime = GetLifetimeToken();
    if (notifyChanged)
        NotifyChange(_dragging ? SliderChangePhase::Preview : SliderChangePhase::Commit, true);
    if (! notifyChanged && ! lifetime.expired())
        if (ControlHost* const currentHost = GetHost())
            RefreshWindowHostAccessibilitySnapshot(currentHost->GetHwnd(), currentHost);
}

D2D1_POINT_2F Slider::GetThumbCenter() const noexcept
{
    const D2D1_RECT_F track = GetTrackRect();
    const double normalized = GetDisplayedNormalizedValue();
    if (_orientation == SliderOrientation::Vertical)
    {
        const float available = (std::max)(0.0f, track.bottom - track.top);
        return D2D1::Point2F((track.left + track.right) * 0.5f, track.bottom - static_cast<float>(normalized) * available);
    }

    const float available = (std::max)(0.0f, track.right - track.left);
    const float progress  = IsRightToLeft() ? static_cast<float>(1.0 - normalized) : static_cast<float>(normalized);
    return D2D1::Point2F(track.left + (available * progress), (track.top + track.bottom) * 0.5f);
}

float Slider::ResolveInnerThumbDiameter() const noexcept
{
    const float hovered = std::lerp(kSliderThumbDiameterDip, kSliderThumbHoverDiameterDip, _hoverTransition.progress);
    return std::lerp(hovered, kSliderThumbPressedDiameterDip, _pressTransition.progress);
}

float Slider::ResolveHaloDiameter(const D2D1_RECT_F& bounds) const noexcept
{
    const float maxDiameter = (std::max)(0.0f, (std::min)(bounds.right - bounds.left, bounds.bottom - bounds.top) - 2.0f);
    return (std::min)(kSliderChromeDiameterDip, maxDiameter);
}

D2D1_COLOR_F Slider::ResolveChromeColor(const ThemePalette& theme) const noexcept
{
    if (theme.highContrast)
    {
        return IsEnabled() ? theme.borderStrong : theme.disabledText;
    }

    const float mix        = std::lerp(theme.dark ? 0.32f : 0.10f, theme.dark ? 0.44f : 0.16f, _hoverTransition.progress);
    const float pressedMix = std::lerp(mix, theme.dark ? 0.52f : 0.22f, _pressTransition.progress);
    D2D1_COLOR_F chrome    = BlendColor(theme.surfaceBackground, theme.text, pressedMix);
    if (! IsEnabled())
    {
        chrome = BlendColor(chrome, theme.windowBackground, 0.45f);
    }
    chrome.a = 1.0f;
    return chrome;
}

D2D1_RECT_F Slider::GetTrackRect() const noexcept
{
    const D2D1_RECT_F bounds = GetBounds();
    if (_orientation == SliderOrientation::Vertical)
    {
        const float centerX = (bounds.left + bounds.right) * 0.5f;
        return D2D1::RectF(centerX - (kSliderTrackThicknessDip * 0.5f),
                           bounds.top + kSliderTrackInsetDip,
                           centerX + (kSliderTrackThicknessDip * 0.5f),
                           bounds.bottom - kSliderTrackInsetDip);
    }

    const float centerY = (bounds.top + bounds.bottom) * 0.5f;
    return D2D1::RectF(bounds.left + kSliderTrackInsetDip,
                       centerY - (kSliderTrackThicknessDip * 0.5f),
                       bounds.right - kSliderTrackInsetDip,
                       centerY + (kSliderTrackThicknessDip * 0.5f));
}

D2D1_RECT_F Slider::GetThumbRect() const noexcept
{
    const D2D1_POINT_2F center = GetThumbCenter();
    const float radius         = ResolveInnerThumbDiameter() * 0.5f;
    return D2D1::RectF(center.x - radius, center.y - radius, center.x + radius, center.y + radius);
}

D2D1_RECT_F Slider::GetInnerThumbRect() const noexcept
{
    return GetThumbRect();
}

D2D1_RECT_F Slider::GetHaloRect() const noexcept
{
    const D2D1_POINT_2F center = GetThumbCenter();
    const float radius         = ResolveHaloDiameter(GetBounds()) * 0.5f;
    return D2D1::RectF(center.x - radius, center.y - radius, center.x + radius, center.y + radius);
}

D2D1_RECT_F Slider::GetTouchHaloRect() const noexcept
{
    // Grows from the chrome disc to the grab area as the touch transition runs, and shrinks back after the drag.
    const D2D1_POINT_2F center = GetThumbCenter();
    const float diameter       = std::lerp(ResolveHaloDiameter(GetBounds()), kSliderTouchHaloDiameterDip, _touchTransition.progress);
    const float radius         = diameter * 0.5f;
    return D2D1::RectF(center.x - radius, center.y - radius, center.x + radius, center.y + radius);
}

D2D1_RECT_F Slider::GetHitBounds() const noexcept
{
    const D2D1_RECT_F bounds = Control::GetHitBounds();
    const float half         = kSliderHitExtentDip * 0.5f;
    if (_orientation == SliderOrientation::Vertical)
    {
        const float centerX = (bounds.left + bounds.right) * 0.5f;
        return D2D1::RectF((std::max)(bounds.left, centerX - half), bounds.top, (std::min)(bounds.right, centerX + half), bounds.bottom);
    }

    const float centerY = (bounds.top + bounds.bottom) * 0.5f;
    return D2D1::RectF(bounds.left, (std::max)(bounds.top, centerY - half), bounds.right, (std::min)(bounds.bottom, centerY + half));
}

D2D1_RECT_F Slider::GetFillRect() const noexcept
{
    const D2D1_RECT_F track    = GetTrackRect();
    const D2D1_POINT_2F center = GetThumbCenter();
    if (_orientation == SliderOrientation::Vertical)
    {
        return D2D1::RectF(track.left, center.y, track.right, track.bottom);
    }

    return IsRightToLeft() ? D2D1::RectF(center.x, track.top, track.right, track.bottom) : D2D1::RectF(track.left, track.top, center.x, track.bottom);
}

void Slider::UpdateValueFromPoint(ControlHost& host, D2D1_POINT_2F point) noexcept
{
    D2D1_POINT_2F mapped = point;
    if (_orientation == SliderOrientation::Vertical)
    {
        mapped.y -= _dragThumbPointerOffsetDip;
    }
    else
    {
        mapped.x -= _dragThumbPointerOffsetDip;
    }

    const D2D1_RECT_F track = GetTrackRect();
    double normalized       = 0.0;
    if (_orientation == SliderOrientation::Vertical)
    {
        const float extent = (std::max)(1.0f, track.bottom - track.top);
        normalized         = (track.bottom - mapped.y) / extent;
    }
    else
    {
        const float extent = (std::max)(1.0f, track.right - track.left);
        const double raw   = (mapped.x - track.left) / extent;
        normalized         = IsRightToLeft() ? (1.0 - raw) : raw;
    }

    const double nextValue = _minimum + ((std::clamp)(normalized, 0.0, 1.0) * (_maximum - _minimum));
    SetValueInternal(&host, nextValue, true, false);
}

void Slider::Paint(ControlHost& host) const
{
    Debug::Perf::Scope sliderPaintPerf(L"dxui.slider.paint");

    auto* dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    const auto& theme          = host.GetTheme();
    const bool enabled         = IsEnabled();
    const D2D1_RECT_F track    = GetTrackRect();
    const D2D1_RECT_F fill     = GetFillRect();
    const D2D1_RECT_F thumb    = GetThumbRect();
    const D2D1_POINT_2F center = GetThumbCenter();
    const D2D1_COLOR_F trackColor =
        theme.highContrast ? theme.borderDefault : D2D1::ColorF(theme.text.r, theme.text.g, theme.text.b, theme.dark ? 0.36f : 0.26f);
    const D2D1_COLOR_F fillColor = enabled ? theme.accent : BlendColor(theme.disabledText, theme.windowBackground, theme.dark ? 0.45f : 0.35f);
    D2D1_COLOR_F thumbFill       = fillColor;
    if (enabled && ! theme.highContrast)
    {
        thumbFill = BlendColor(theme.accent, theme.accentHover, _hoverTransition.progress);
        thumbFill = BlendColor(thumbFill, theme.accentPressed, _pressTransition.progress);
    }
    const float trackRadius     = kSliderTrackThicknessDip * 0.5f;
    const D2D1_COLOR_F noStroke = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
    DrawRoundedRect(host, track, trackColor, noStroke, trackRadius);
    if (fill.right > fill.left && fill.bottom > fill.top)
    {
        DrawRoundedRect(host, fill, fillColor, noStroke, trackRadius);
    }

    if (! _tickMarks.empty())
    {
        for (double tick : _tickMarks)
        {
            if (_maximum <= _minimum)
            {
                break;
            }

            const float normalized = static_cast<float>((tick - _minimum) / (_maximum - _minimum));
            if (_orientation == SliderOrientation::Vertical)
            {
                const float y = track.bottom - (normalized * (track.bottom - track.top));
                DrawLineWithColor(host, D2D1::Point2F(track.left - kSliderTickLengthDip, y), D2D1::Point2F(track.left - 1.0f, y), theme.borderDefault, 1.0f);
            }
            else
            {
                const float progress = IsRightToLeft() ? (1.0f - normalized) : normalized;
                const float x        = track.left + (progress * (track.right - track.left));
                DrawLineWithColor(
                    host, D2D1::Point2F(x, track.bottom + 1.0f), D2D1::Point2F(x, track.bottom + kSliderTickLengthDip), theme.borderDefault, 1.0f);
            }
        }
    }

    if (_touchTransition.progress > 0.0f)
    {
        // Constrain only the extra touch feedback; ordinary thumb, tick and focus-ring painting retains its contract.
        // Ancestor viewport and host clips stay stacked, including ScrollPanel's content-space transform.
        dc->PushAxisAlignedClip(GetBounds(), D2D1_ANTIALIAS_MODE_PER_PRIMITIVE);
        auto restoreClip            = wil::scope_exit([dc] { dc->PopAxisAlignedClip(); });
        const D2D1_RECT_F touchHalo = GetTouchHaloRect();
        const float touchRadius     = (touchHalo.right - touchHalo.left) * 0.5f;
        if (theme.highContrast)
        {
            const float ringRadius = touchRadius - (kSliderTouchHaloRingWidthDip * 0.5f);
            DrawEllipseWithColor(host, D2D1::Ellipse(center, ringRadius, ringRadius), theme.selectionFill, kSliderTouchHaloRingWidthDip);
        }
        else
        {
            D2D1_COLOR_F haloColor = theme.accent;
            haloColor.a            = kSliderTouchHaloOpacity * _touchTransition.progress;
            FillEllipseWithColor(host, D2D1::Ellipse(center, touchRadius, touchRadius), haloColor);
        }
    }

    const D2D1_RECT_F chrome         = GetHaloRect();
    const float chromeRadius         = (chrome.right - chrome.left) * 0.5f;
    const D2D1_ELLIPSE chromeEllipse = D2D1::Ellipse(center, chromeRadius, chromeRadius);
    FillEllipseWithColor(host, chromeEllipse, ResolveChromeColor(theme));

    const float thumbRadius         = (thumb.right - thumb.left) * 0.5f;
    const D2D1_ELLIPSE thumbEllipse = D2D1::Ellipse(center, thumbRadius, thumbRadius);
    FillEllipseWithColor(host, thumbEllipse, thumbFill);
    if (HasFocus() && host.IsKeyboardFocusVisible())
    {
        PaintFocusRing(host, chrome, chromeRadius);
    }
}

bool Slider::Tick(ControlHost& host, uint64_t nowTickMs)
{
    if (! IsEnabled() || ! IsVisible())
    {
        SnapVisualTransitions();
        SnapDisplayedValue();
        return false;
    }
    if (host.GetTheme().reducedMotion)
    {
        const bool hoverWasActive = _hoverTransition.active;
        const bool pressWasActive = _pressTransition.active;
        const bool touchWasActive = _touchTransition.active;
        const bool valueWasActive = _valueAnimationActive;
        SnapVisualTransitions();
        SnapDisplayedValue();
        if (hoverWasActive || pressWasActive || touchWasActive || valueWasActive)
        {
            Invalidate(host);
        }
        return false;
    }

    const float hoverBefore   = _hoverTransition.progress;
    const float pressBefore   = _pressTransition.progress;
    const float touchBefore   = _touchTransition.progress;
    const bool hoverAnimating = AdvanceVisualTransition(_hoverTransition, nowTickMs, EasingCurve::FastDecelerate);
    const bool pressAnimating = AdvanceVisualTransition(_pressTransition, nowTickMs, EasingCurve::FastDecelerate);
    const bool touchAnimating = AdvanceVisualTransition(_touchTransition, nowTickMs, EasingCurve::FastDecelerate);
    const bool valueAnimating = AdvanceValueAnimation(host, nowTickMs);
    if (_hoverTransition.progress != hoverBefore || _pressTransition.progress != pressBefore || _touchTransition.progress != touchBefore)
    {
        Invalidate(host);
    }
    return hoverAnimating || pressAnimating || touchAnimating || valueAnimating;
}

bool Slider::OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    if (! IsEnabled() || rightButton || ! PointInRect(GetHitBounds(), point))
    {
        return false;
    }

    if (! FocusControlAndSurvive(host, *this))
    {
        return true;
    }
    _dragInitialValue          = _value;
    _dragging                  = true;
    _touchDragging             = host.GetPointerDevice() == PointerDevice::Touch;
    const D2D1_POINT_2F center = GetThumbCenter();
    // Grab uses the unpainted 48 DIP hit band, not the painted halo or inner thumb.
    const float grabRadius = kSliderHitExtentDip * 0.5f;
    const float deltaX     = point.x - center.x;
    const float deltaY     = point.y - center.y;
    if ((deltaX * deltaX) + (deltaY * deltaY) <= (grabRadius * grabRadius))
    {
        _dragThumbPointerOffsetDip = _orientation == SliderOrientation::Vertical ? deltaY : deltaX;
    }
    else
    {
        _dragThumbPointerOffsetDip = 0.0f;
    }
    host.CaptureMouse(this);
    SyncInteractionVisuals(host);
    UpdateValueFromPoint(host, point);
    return true;
}

bool Slider::OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT /*modifiers*/)
{
    if (! _dragging)
    {
        return false;
    }

    UpdateValueFromPoint(host, point);
    return true;
}

bool Slider::OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    if (rightButton || ! _dragging)
    {
        return false;
    }

    const auto life = GetLifetimeToken();
    UpdateValueFromPoint(host, point);
    if (life.expired())
        return true;
    _dragging                  = false;
    _touchDragging             = false;
    _dragThumbPointerOffsetDip = 0.0f;
    host.ReleaseMouseCapture();
    SyncInteractionVisuals(host);
    Invalidate(host);
    NotifyChange(SliderChangePhase::Commit, false);
    return true;
}

bool Slider::OnKeyDown(ControlHost& host, UINT virtualKey, UINT /*modifiers*/)
{
    if (! IsEnabled())
    {
        return false;
    }

    if (virtualKey == VK_ESCAPE && _dragging)
    {
        OnCaptureLost(host);
        host.ReleaseMouseCapture();
        return true;
    }

    switch (virtualKey)
    {
        case VK_HOME: SetValueInternal(&host, _minimum, true, true); return true;
        case VK_END: SetValueInternal(&host, _maximum, true, true); return true;
        case VK_PRIOR: SetValueInternal(&host, _value + _largeStep, true, true); return true;
        case VK_NEXT: SetValueInternal(&host, _value - _largeStep, true, true); return true;
        case VK_UP:
            if (_orientation == SliderOrientation::Vertical)
            {
                SetValueInternal(&host, _value + _step, true, true);
                return true;
            }
            break;
        case VK_DOWN:
            if (_orientation == SliderOrientation::Vertical)
            {
                SetValueInternal(&host, _value - _step, true, true);
                return true;
            }
            break;
        case VK_LEFT:
            if (_orientation == SliderOrientation::Horizontal)
            {
                SetValueInternal(&host, _value + (IsRightToLeft() ? _step : -_step), true, true);
                return true;
            }
            break;
        case VK_RIGHT:
            if (_orientation == SliderOrientation::Horizontal)
            {
                SetValueInternal(&host, _value + (IsRightToLeft() ? -_step : _step), true, true);
                return true;
            }
            break;
        default: break;
    }

    return false;
}

void Slider::OnHoverChanged(ControlHost& host, bool hovered)
{
    Control::OnHoverChanged(host, hovered);
    SyncInteractionVisuals(host);
}

void Slider::OnEnabledChanged(bool enabled) noexcept
{
    Control::OnEnabledChanged(enabled);
    SnapVisualTransitions();
    SnapDisplayedValue();
}

void Slider::OnCaptureLost(ControlHost& host)
{
    if (_dragging)
    {
        _dragging                  = false;
        _touchDragging             = false;
        _dragThumbPointerOffsetDip = 0.0f;
        _value                     = ClampValue(_dragInitialValue);
        SnapDisplayedValue();
        SnapVisualTransitions();
        Invalidate(host);
        NotifyChange(SliderChangePhase::Cancel, true);
    }
}

#if DXUI_ENABLE_DIAGNOSTICS
D2D1_RECT_F Slider::DebugGetTrackRect() const noexcept
{
    return GetTrackRect();
}

D2D1_RECT_F Slider::DebugGetThumbRect() const noexcept
{
    return GetThumbRect();
}

D2D1_RECT_F Slider::DebugGetInnerThumbRect() const noexcept
{
    return GetInnerThumbRect();
}

D2D1_RECT_F Slider::DebugGetHaloRect() const noexcept
{
    return GetHaloRect();
}

D2D1_RECT_F Slider::DebugGetFillRect() const noexcept
{
    return GetFillRect();
}

float Slider::DebugGetHoverAnimationProgress() const noexcept
{
    return _hoverTransition.progress;
}

float Slider::DebugGetPressAnimationProgress() const noexcept
{
    return _pressTransition.progress;
}

D2D1_RECT_F Slider::DebugGetTouchHaloRect() const noexcept
{
    return GetTouchHaloRect();
}

float Slider::DebugGetTouchHaloProgress() const noexcept
{
    return _touchTransition.progress;
}

double Slider::DebugGetDisplayedValue() const noexcept
{
    return _displayedValue;
}
#endif

// --- TagPicker ---

namespace
{
[[nodiscard]] wchar_t ToLowerTagPickerChar(wchar_t ch) noexcept
{
    return static_cast<wchar_t>(std::towlower(static_cast<wint_t>(ch)));
}

[[nodiscard]] bool TagPickerEqualsIgnoreCase(std::wstring_view lhs, std::wstring_view rhs) noexcept
{
    if (lhs.size() != rhs.size())
    {
        return false;
    }

    for (size_t index = 0u; index < lhs.size(); ++index)
    {
        if (ToLowerTagPickerChar(lhs[index]) != ToLowerTagPickerChar(rhs[index]))
        {
            return false;
        }
    }
    return true;
}

[[nodiscard]] bool TagPickerStartsWithIgnoreCase(std::wstring_view text, std::wstring_view prefix) noexcept
{
    if (prefix.size() > text.size())
    {
        return false;
    }

    for (size_t index = 0u; index < prefix.size(); ++index)
    {
        if (ToLowerTagPickerChar(text[index]) != ToLowerTagPickerChar(prefix[index]))
        {
            return false;
        }
    }
    return true;
}

[[nodiscard]] bool TagPickerContainsIgnoreCase(std::wstring_view text, std::wstring_view needle) noexcept
{
    if (needle.empty())
    {
        return true;
    }
    if (needle.size() > text.size())
    {
        return false;
    }

    for (size_t index = 0u; index + needle.size() <= text.size(); ++index)
    {
        if (TagPickerStartsWithIgnoreCase(text.substr(index), needle))
        {
            return true;
        }
    }
    return false;
}

constexpr float kTagPickerMinHeightDip     = 32.0f;
constexpr float kTagPickerFramePaddingDip  = 4.0f;
constexpr float kTagPickerGapDip           = 6.0f;
constexpr float kTagPickerRowGapDip        = 4.0f;
constexpr float kTagPickerRowHeightDip     = 24.0f;
constexpr float kTagPickerRemoveWidthDip   = 18.0f;
constexpr float kTagPickerMinComboWidthDip = 96.0f;
constexpr float kTagPickerMinTagWidthDip   = 48.0f;
constexpr float kTagPickerMaxTagWidthDip   = 172.0f;
} // namespace

TagPicker::TagPicker()
{
    _combo = AddChild<ComboBox>();
    _combo->SetEditable(true);
    _combo->SetChromeVisible(false);
    _combo->SetAutoOpenOnTextInput(true);
    _combo->SetMaxVisibleItems(8u);
    _combo->SetOnSelectionChanged([this](size_t)
    {
        if (_syncingCombo || ! _combo)
        {
            return;
        }
        if (_combo->IsPopupOpen())
        {
            return;
        }

        static_cast<void>(SelectOption(_combo->GetSelectedValue()));
    });
    _combo->SetOnSubmitted([this] { static_cast<void>(CommitInput()); });
}

void TagPicker::SetOptions(std::wstring allLabel, std::vector<std::wstring> options)
{
    _allLabel = std::move(allLabel);
    _options.clear();
    _options.reserve(options.size());
    for (std::wstring& option : options)
    {
        if (option.empty() || ContainsOption(option))
        {
            continue;
        }
        _options.push_back(std::move(option));
    }

    PruneSelectedValues();
    RefreshComboItems();
    RebuildDisplayTags();
    LayoutParts();
    RequestInvalidate();
}

std::span<const std::wstring> TagPicker::GetOptions() const noexcept
{
    return _options;
}

void TagPicker::SetSelectedValues(std::vector<std::wstring> values)
{
    _selectedValues.clear();
    _selectedValues.reserve(values.size());
    for (std::wstring& value : values)
    {
        const std::optional<size_t> optionIndex = FindOptionIndex(value);
        if (! optionIndex || ContainsSelectedValue(_options[optionIndex.value()]))
        {
            continue;
        }
        _selectedValues.push_back(_options[optionIndex.value()]);
    }

    RebuildDisplayTags();
    RefreshComboItems();
    LayoutParts();
    RequestInvalidate();
}

std::span<const std::wstring> TagPicker::GetSelectedValues() const noexcept
{
    return _selectedValues;
}

void TagPicker::SetInputText(std::wstring text)
{
    if (! _combo)
    {
        return;
    }

    _syncingCombo = true;
    _combo->SetText(std::move(text));
    _syncingCombo = false;
}

std::wstring_view TagPicker::GetInputText() const noexcept
{
    return _combo ? _combo->GetText() : std::wstring_view{};
}

bool TagPicker::SelectOption(std::wstring_view value)
{
    if (value.empty())
    {
        return false;
    }

    bool changed = false;
    if (! _allLabel.empty() && TagPickerEqualsIgnoreCase(value, _allLabel))
    {
        changed         = _selectedValues.size() != _options.size();
        _selectedValues = _options;
    }
    else if (const std::optional<size_t> optionIndex = FindOptionIndex(value))
    {
        const std::wstring& option = _options[optionIndex.value()];
        if (IsAllSelectionActive())
        {
            _selectedValues.clear();
        }
        if (! ContainsSelectedValue(option))
        {
            _selectedValues.push_back(option);
            changed = true;
        }
    }
    else
    {
        return false;
    }

    if (_combo)
    {
        _syncingCombo = true;
        _combo->SetText({});
        _combo->SetSelectedIndex(std::nullopt);
        _syncingCombo = false;
    }

    if (changed)
    {
        RebuildDisplayTags();
        RefreshComboItems();
        LayoutParts();
        if (! NotifySelectionChanged())
        {
            return true;
        }
        RequestInvalidate();
    }
    return true;
}

bool TagPicker::CommitInput()
{
    if (! _combo)
    {
        return false;
    }

    const std::wstring input(_combo->GetText());
    if (input.empty())
    {
        return false;
    }

    if (! _allLabel.empty() && TagPickerEqualsIgnoreCase(input, _allLabel))
    {
        return SelectOption(_allLabel);
    }

    if (const std::optional<size_t> optionIndex = FindBestInputMatch(input))
    {
        return SelectOption(_options[optionIndex.value()]);
    }
    return false;
}

bool TagPicker::RemoveDisplayTag(size_t displayTagIndex)
{
    if (displayTagIndex >= _displayTags.size())
    {
        return false;
    }

    if (_displayTags[displayTagIndex].all)
    {
        if (_selectedValues.empty())
        {
            return true;
        }
        _selectedValues.clear();
    }
    else
    {
        const std::wstring value = _displayTags[displayTagIndex].value;
        const auto it            = std::find_if(_selectedValues.begin(), _selectedValues.end(), [&value](const std::wstring& candidate) noexcept {
            return TagPickerEqualsIgnoreCase(candidate, value);
        });
        if (it == _selectedValues.end())
        {
            return false;
        }
        _selectedValues.erase(it);
    }

    RebuildDisplayTags();
    RefreshComboItems();
    LayoutParts();
    if (! NotifySelectionChanged())
    {
        return true;
    }
    RequestInvalidate();
    return true;
}

size_t TagPicker::GetDisplayTagCount() const noexcept
{
    return _displayTags.size();
}

std::wstring_view TagPicker::GetDisplayTagText(size_t displayTagIndex) const noexcept
{
    return displayTagIndex < _displayTags.size() ? std::wstring_view(_displayTags[displayTagIndex].text) : std::wstring_view{};
}

float TagPicker::GetPreferredHeightDip(float widthDip) const noexcept
{
    return ComputePreferredHeightDip(widthDip, GetHost());
}

void TagPicker::SetOnSelectionChanged(std::function<void(std::span<const std::wstring>)> onSelectionChanged)
{
    ReplaceControlCallback(_onSelectionChanged, std::move(onSelectionChanged));
}

void TagPicker::Paint(ControlHost& host) const
{
    const ThemePalette& theme            = host.GetTheme();
    const bool comboFocused              = _combo && _combo->HasFocus();
    const bool comboHovered              = _combo && _combo->IsHovered();
    const bool comboOpen                 = _combo && _combo->IsPopupOpen();
    const ComboBoxVisualStyle fieldStyle = ResolveComboBoxVisualStyle(
        theme, ComboBoxVariant::Edit, IsEnabled(), IsHovered() || comboHovered, comboOpen, comboFocused, host.IsKeyboardFocusVisible());
    const D2D1_RECT_F frameBounds = SnapRectToPixel(host, GetBounds());
    DrawRoundedRect(host, frameBounds, fieldStyle.fieldFill, fieldStyle.fieldBorder, fieldStyle.cornerRadiusDip);

    const D2D1_COLOR_F tagFill     = theme.highContrast ? theme.headerBackground : BlendColor(theme.accent, theme.cardBackground, theme.dark ? 0.78f : 0.86f);
    const D2D1_COLOR_F tagBorder   = theme.highContrast ? theme.borderStrong : BlendColor(theme.accent, theme.borderDefault, theme.dark ? 0.44f : 0.30f);
    const D2D1_COLOR_F textColor   = theme.highContrast ? theme.text : ChooseContrastingTextColor(tagFill);
    const D2D1_COLOR_F removeColor = BlendColor(textColor, tagFill, 0.18f);

    for (size_t index = 0u; index < _tagRects.size() && index < _displayTags.size(); ++index)
    {
        const D2D1_RECT_F tagRect = _tagRects[index];
        if (tagRect.right <= tagRect.left || tagRect.bottom <= tagRect.top)
        {
            continue;
        }

        DrawRoundedRect(host, tagRect, tagFill, tagBorder, 5.0f);
        const D2D1_RECT_F removeRect = index < _tagRemoveRects.size()
                                           ? _tagRemoveRects[index]
                                           : D2D1::RectF(tagRect.right - kTagPickerRemoveWidthDip, tagRect.top, tagRect.right, tagRect.bottom);
        const D2D1_RECT_F textRect   = D2D1::RectF(tagRect.left + 8.0f, tagRect.top, std::max(tagRect.left + 8.0f, removeRect.left - 2.0f), tagRect.bottom);
        DrawSingleLineTextClipped(host, _displayTags[index].text, textRect, FontRole::Small, textColor, 0.0f, ResolveReadingDirection(GetFlowDirection()));
        DrawCenteredText(host, L"×", removeRect, FontRole::Small, removeColor, DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
    }

    Panel::Paint(host);
}

bool TagPicker::OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers)
{
    if (rightButton)
    {
        return Panel::OnMouseDown(host, point, rightButton, modifiers);
    }

    for (size_t index = 0u; index < _tagRemoveRects.size(); ++index)
    {
        if (PointInRect(_tagRemoveRects[index], point))
        {
            const std::weak_ptr<int> lifetime = GetLifetimeToken();
            static_cast<void>(RemoveDisplayTag(index));
            if (! lifetime.expired())
            {
                Invalidate(host);
            }
            return true;
        }
    }

    if (_combo && PointInRect(GetBounds(), point) && ! PointInRect(_combo->GetBounds(), point))
    {
        const std::weak_ptr<int> lifetime = GetLifetimeToken();
        host.SetFocusControl(_combo);
        if (! lifetime.expired())
        {
            Invalidate(host);
        }
        return true;
    }

    return Panel::OnMouseDown(host, point, rightButton, modifiers);
}

#if DXUI_ENABLE_DIAGNOSTICS
size_t TagPicker::DebugGetLaidOutDisplayTagCount() const noexcept
{
    return _tagRects.size();
}

D2D1_RECT_F TagPicker::DebugGetDisplayTagRect(size_t displayTagIndex) const noexcept
{
    return displayTagIndex < _tagRects.size() ? _tagRects[displayTagIndex] : D2D1::RectF();
}

D2D1_RECT_F TagPicker::DebugGetInputRect() const noexcept
{
    return _combo ? _combo->GetBounds() : D2D1::RectF();
}

ComboBox* TagPicker::DebugGetEmbeddedCombo() noexcept
{
    return _combo;
}

const ComboBox* TagPicker::DebugGetEmbeddedCombo() const noexcept
{
    return _combo;
}
#endif

void TagPicker::OnBoundsChanged() noexcept
{
    LayoutParts();
}

Control* TagPicker::HitTest(D2D1_POINT_2F point)
{
    return Panel::HitTest(point);
}

const Control* TagPicker::HitTest(D2D1_POINT_2F point) const
{
    return Panel::HitTest(point);
}

void TagPicker::RefreshComboItems()
{
    if (! _combo)
    {
        return;
    }

    std::vector<ComboBox::Item> items;
    items.reserve(_options.size() + (! _allLabel.empty() ? 1u : 0u));
    const bool allSelectionActive = IsAllSelectionActive();
    if (! _allLabel.empty() && _selectedValues.empty())
    {
        items.push_back(ComboBox::Item{.value = _allLabel, .display = _allLabel});
    }
    for (const std::wstring& option : _options)
    {
        if (! allSelectionActive && ContainsSelectedValue(option))
        {
            continue;
        }
        items.push_back(ComboBox::Item{.value = option, .display = option});
    }

    _syncingCombo = true;
    _combo->SetItems(std::move(items));
    _combo->SetSelectedIndex(std::nullopt);
    _syncingCombo = false;
}

void TagPicker::RebuildDisplayTags()
{
    _displayTags.clear();
    if (! _options.empty() && _selectedValues.size() == _options.size() && ! _allLabel.empty())
    {
        _displayTags.push_back(DisplayTag{.text = _allLabel, .value = _allLabel, .all = true});
        return;
    }

    _displayTags.reserve(_selectedValues.size());
    for (const std::wstring& value : _selectedValues)
    {
        _displayTags.push_back(DisplayTag{.text = value, .value = value});
    }
}

void TagPicker::LayoutParts() noexcept
{
    _tagRects.clear();
    _tagRemoveRects.clear();

    if (! _combo)
    {
        return;
    }

    const D2D1_RECT_F bounds = GetBounds();
    const float width        = std::max(0.0f, bounds.right - bounds.left);
    const float height       = std::max(0.0f, bounds.bottom - bounds.top);
    if (width <= 0.0f || height <= 0.0f)
    {
        _combo->SetBounds(D2D1::RectF(bounds.left, bounds.top, bounds.left, bounds.top));
        return;
    }

    const ControlHost* host       = GetHost();
    const float preferredHeight   = ComputePreferredHeightDip(width, host);
    const float preferredContentH = std::max(kTagPickerRowHeightDip, preferredHeight - (kTagPickerFramePaddingDip * 2.0f));
    const float rowTopInset       = std::max(kTagPickerFramePaddingDip, (height - preferredContentH) * 0.5f);
    const float rowLeft           = bounds.left + kTagPickerFramePaddingDip;
    const float rowRight          = std::max(rowLeft, bounds.right - kTagPickerFramePaddingDip);
    float rowTop                  = bounds.top + rowTopInset;
    float x                       = rowLeft;
    const auto moveToNextRow      = [&]() noexcept
    {
        rowTop += kTagPickerRowHeightDip + kTagPickerRowGapDip;
        x = rowLeft;
    };

    for (const DisplayTag& tag : _displayTags)
    {
        const float tagW = MeasureDisplayTagWidthDip(tag, kTagPickerRowHeightDip, host);
        if (x > rowLeft && x + tagW > rowRight)
        {
            moveToNextRow();
        }

        const float tagRight      = std::min(rowRight, x + tagW);
        const D2D1_RECT_F tagRect = D2D1::RectF(x, rowTop, std::max(x + 24.0f, tagRight), rowTop + kTagPickerRowHeightDip);
        _tagRects.push_back(tagRect);
        _tagRemoveRects.push_back(D2D1::RectF(std::max(tagRect.left, tagRect.right - kTagPickerRemoveWidthDip), tagRect.top, tagRect.right, tagRect.bottom));
        x = tagRect.right + kTagPickerGapDip;
    }

    if (x > rowLeft && x + kTagPickerMinComboWidthDip > rowRight)
    {
        moveToNextRow();
    }

    const float comboLeft = std::clamp(x, rowLeft, std::max(rowLeft, rowRight - kTagPickerMinComboWidthDip));
    _combo->SetBounds(D2D1::RectF(comboLeft, rowTop, rowRight, rowTop + kTagPickerRowHeightDip));
}

float TagPicker::ComputePreferredHeightDip(float widthDip, const ControlHost* host) const noexcept
{
    const float availableWidth = std::max(0.0f, widthDip - (kTagPickerFramePaddingDip * 2.0f));
    if (availableWidth <= 0.0f)
    {
        return kTagPickerMinHeightDip;
    }

    size_t rowCount = 1u;
    float x         = 0.0f;
    for (const DisplayTag& tag : _displayTags)
    {
        const float tagW = MeasureDisplayTagWidthDip(tag, kTagPickerRowHeightDip, host);
        if (x > 0.0f && x + tagW > availableWidth)
        {
            ++rowCount;
            x = 0.0f;
        }

        x = std::min(availableWidth, x + tagW) + kTagPickerGapDip;
    }

    if (x > 0.0f && x + kTagPickerMinComboWidthDip > availableWidth)
    {
        ++rowCount;
    }

    const float rowsH = (static_cast<float>(rowCount) * kTagPickerRowHeightDip) + (static_cast<float>(rowCount - 1u) * kTagPickerRowGapDip);
    return std::max(kTagPickerMinHeightDip, rowsH + (kTagPickerFramePaddingDip * 2.0f));
}

float TagPicker::MeasureDisplayTagWidthDip(const DisplayTag& tag, float rowHeightDip, const ControlHost* host) const noexcept
{
    const DWRITE_READING_DIRECTION readingDirection = ResolveReadingDirection(GetFlowDirection());
    const float measuredTextW                       = MeasureSingleLineTextWidthDip(host, tag.text, FontRole::Small, rowHeightDip, readingDirection);
    const float maxTagWidth                         = std::max(kTagPickerMinTagWidthDip, kTagPickerMaxTagWidthDip);
    return std::clamp(measuredTextW + kTagPickerRemoveWidthDip + 18.0f, kTagPickerMinTagWidthDip, maxTagWidth);
}

bool TagPicker::NotifySelectionChanged()
{
    const std::weak_ptr<int> lifetime = GetLifetimeToken();
    if (_onSelectionChanged)
    {
        const auto onSelectionChanged = _onSelectionChanged;
        const auto selectedValues     = _selectedValues;
        (*onSelectionChanged)(selectedValues);
    }
    return ! lifetime.expired();
}

bool TagPicker::ContainsOption(std::wstring_view value) const noexcept
{
    return FindOptionIndex(value).has_value();
}

bool TagPicker::ContainsSelectedValue(std::wstring_view value) const noexcept
{
    return std::any_of(
        _selectedValues.begin(), _selectedValues.end(), [value](const std::wstring& selected) noexcept { return TagPickerEqualsIgnoreCase(selected, value); });
}

bool TagPicker::IsAllSelectionActive() const noexcept
{
    return ! _allLabel.empty() && ! _options.empty() && _selectedValues.size() == _options.size();
}

std::optional<size_t> TagPicker::FindOptionIndex(std::wstring_view value) const noexcept
{
    for (size_t index = 0u; index < _options.size(); ++index)
    {
        if (TagPickerEqualsIgnoreCase(_options[index], value))
        {
            return index;
        }
    }
    return std::nullopt;
}

std::optional<size_t> TagPicker::FindBestInputMatch(std::wstring_view input) const noexcept
{
    for (size_t index = 0u; index < _options.size(); ++index)
    {
        if (TagPickerEqualsIgnoreCase(_options[index], input))
        {
            return index;
        }
    }

    for (size_t index = 0u; index < _options.size(); ++index)
    {
        if (TagPickerStartsWithIgnoreCase(_options[index], input))
        {
            return index;
        }
    }

    for (size_t index = 0u; index < _options.size(); ++index)
    {
        if (TagPickerContainsIgnoreCase(_options[index], input))
        {
            return index;
        }
    }
    return std::nullopt;
}

void TagPicker::PruneSelectedValues()
{
    std::vector<std::wstring> pruned;
    pruned.reserve(_selectedValues.size());
    for (const std::wstring& selected : _selectedValues)
    {
        const std::optional<size_t> optionIndex = FindOptionIndex(selected);
        if (! optionIndex)
        {
            continue;
        }

        const std::wstring& option = _options[optionIndex.value()];
        const bool alreadyAdded    = std::any_of(
            pruned.begin(), pruned.end(), [&option](const std::wstring& candidate) noexcept { return TagPickerEqualsIgnoreCase(candidate, option); });
        if (! alreadyAdded)
        {
            pruned.push_back(option);
        }
    }
    _selectedValues = std::move(pruned);
}

// --- Toolbar ---

Button* Toolbar::AddButton(std::wstring tooltip, std::wstring iconGlyph)
{
    auto* btn = AddChild<Button>(std::move(iconGlyph));
    btn->SetVariant(ButtonVariant::IconOnly);
    btn->SetTooltipText(std::move(tooltip));
    return btn;
}

Toggle* Toolbar::AddToggleButton(std::wstring tooltip, std::wstring iconGlyph)
{
    auto* toggle = AddChild<Toggle>(std::move(iconGlyph));
    toggle->SetVariant(ButtonVariant::IconOnly);
    toggle->SetTooltipText(std::move(tooltip));
    return toggle;
}

void Toolbar::AddSeparator()
{
    auto* separator = AddChild<Label>();
    separator->SetEnabled(false);
}

void Toolbar::Paint(ControlHost& host) const
{
    const ToolbarVisualStyle style = ResolveToolbarVisualStyle(host.GetTheme());
    const ThemePalette& theme      = host.GetTheme();
    const D2D1_RECT_F bounds       = GetBounds();
    const float separatorInsetDip  = theme.density == Density::Compact ? 4.0f : 6.0f;

    // Background
    if (host.GetDeviceContext())
    {
        FillRectangleWithColor(host, bounds, style.background);
        // Bottom border (1 DIP)
        const D2D1_RECT_F borderLine = D2D1::RectF(bounds.left, bounds.bottom - 1.0f, bounds.right, bounds.bottom);
        FillRectangleWithColor(host, borderLine, style.bottomBorder);

        for (const auto& child : GetChildren())
        {
            const auto* label = dynamic_cast<const Label*>(child.get());
            if (! label || ! label->GetText().empty())
            {
                continue;
            }

            const D2D1_RECT_F childBounds = child->GetBounds();
            if (childBounds.right <= childBounds.left || childBounds.bottom <= childBounds.top)
            {
                continue;
            }

            const float centerX = std::floor((childBounds.left + childBounds.right) * 0.5f) + 0.5f;
            DrawLineWithColor(host,
                              D2D1::Point2F(centerX, childBounds.top + separatorInsetDip),
                              D2D1::Point2F(centerX, childBounds.bottom - separatorInsetDip),
                              style.separatorLine,
                              1.0f);
        }
    }

    // Paint children (buttons)
    Panel::Paint(host);
}

// --- MenuBar ---

MenuBar::MenuBar()
{
    SetFocusable(true);
}

void MenuBar::SetItems(std::vector<MenuBarItem> items)
{
    _items = std::move(items);
    InvalidateMenuBarLayoutCache();
    if (_selectedIndex.has_value() && _selectedIndex.value() >= _items.size())
    {
        _selectedIndex.reset();
    }
    if (_hoveredIndex.has_value() && _hoveredIndex.value() >= _items.size())
    {
        _hoveredIndex.reset();
    }
    if (_pressedIndex.has_value() && _pressedIndex.value() >= _items.size())
    {
        _pressedIndex.reset();
    }
    RequestInvalidate();
}

std::span<const MenuBarItem> MenuBar::GetItems() const noexcept
{
    return _items;
}

void MenuBar::SetOnOpenItem(OpenItemCallback onOpenItem)
{
    ReplaceControlCallback(_onOpenItem, std::move(onOpenItem));
}

void MenuBar::SetOnHoverChanged(HoverChangedCallback onHoverChanged)
{
    ReplaceControlCallback(_onHoverChanged, std::move(onHoverChanged));
}

void MenuBar::SetSelectedIndex(std::optional<size_t> index) noexcept
{
    if (index.has_value() && index.value() >= _items.size())
    {
        index.reset();
    }
    if (_selectedIndex != index)
    {
        _selectedIndex = index;
        RequestInvalidate();
    }
}

void MenuBar::ClearInteractionState() noexcept
{
    const bool changed = _selectedIndex.has_value() || _hoveredIndex.has_value() || _pressedIndex.has_value();
    _selectedIndex.reset();
    _hoveredIndex.reset();
    _pressedIndex.reset();
    if (changed)
    {
        RequestInvalidate();
    }
}

void MenuBar::SetRetainSelectedIndexOnFocusLost(bool retain) noexcept
{
    _retainSelectedIndexOnFocusLost = retain;
}

std::optional<size_t> MenuBar::GetSelectedIndex() const noexcept
{
    return _selectedIndex;
}

std::optional<size_t> MenuBar::GetHoveredIndex() const noexcept
{
    return (_hoveredIndex.has_value() && _hoveredIndex.value() < _items.size() && _items[_hoveredIndex.value()].enabled) ? _hoveredIndex : std::nullopt;
}

size_t MenuBar::GetVisualHighlightCount() const noexcept
{
    return GetVisualHighlightIndex().has_value() ? 1u : 0u;
}

bool MenuBar::ActivateMnemonic(ControlHost& host, wchar_t mnemonic)
{
    if (const std::optional<size_t> match = FindMnemonicItem(mnemonic); match.has_value())
    {
        return ! FocusControlAndSurvive(host, *this) || ActivateItem(host, match.value(), true);
    }
    return false;
}

bool MenuBar::ActivateItem(ControlHost& host, size_t index, bool keyboardInvocation)
{
    if (index >= _items.size() || ! _items[index].enabled || ! _onOpenItem)
    {
        Debug::Info(L"DxUi::MenuTrace MenuBar activate-rejected hwnd={:#x} capture={:#x} index={} itemCount={} enabled={} hasCallback={} keyboard={}",
                    reinterpret_cast<uintptr_t>(host.GetHwnd()),
                    reinterpret_cast<uintptr_t>(GetCapture()),
                    index,
                    _items.size(),
                    index < _items.size() && _items[index].enabled ? L"true" : L"false",
                    _onOpenItem ? L"true" : L"false",
                    keyboardInvocation ? L"true" : L"false");
        return false;
    }

    _selectedIndex             = index;
    _hoveredIndex              = index;
    const D2D1_RECT_F itemRect = GetItemRect(host, index);
    const POINT screenPoint    = host.DipPointToScreenPoint(D2D1::Point2F(itemRect.left, itemRect.bottom));
    Debug::Info(
        L"DxUi::MenuTrace MenuBar activate hwnd={:#x} capture={:#x} index={} keyboard={} anchor=({}, {}) itemRectDip=({:.1f},{:.1f},{:.1f},{:.1f}) label='{}'",
        reinterpret_cast<uintptr_t>(host.GetHwnd()),
        reinterpret_cast<uintptr_t>(GetCapture()),
        index,
        keyboardInvocation ? L"true" : L"false",
        screenPoint.x,
        screenPoint.y,
        itemRect.left,
        itemRect.top,
        itemRect.right,
        itemRect.bottom,
        std::wstring_view{_items[index].text});
    const auto openItem = _onOpenItem;
    RequestInvalidate();
    (*openItem)(index, screenPoint, keyboardInvocation);
    return true;
}

bool MenuBar::ActivateSelected(ControlHost& host, bool keyboardInvocation)
{
    if (! _selectedIndex.has_value())
    {
        return false;
    }
    return ActivateItem(host, _selectedIndex.value(), keyboardInvocation);
}

std::optional<size_t> MenuBar::HitTestPoint(const ControlHost& host, PointDip pointDip) const noexcept
{
    return HitTestItem(host, pointDip);
}

bool MenuBar::TryGetItemScreenRect(const ControlHost& host, size_t index, RECT& rectPx) const noexcept
{
    if (index >= _items.size())
    {
        return false;
    }

    const D2D1_RECT_F itemRect = GetItemRect(host, index);
    if (itemRect.right <= itemRect.left || itemRect.bottom <= itemRect.top)
    {
        return false;
    }

    const POINT topLeft     = host.DipPointToScreenPoint(D2D1::Point2F(itemRect.left, itemRect.top));
    const POINT bottomRight = host.DipPointToScreenPoint(D2D1::Point2F(itemRect.right, itemRect.bottom));
    rectPx                  = RECT{topLeft.x, topLeft.y, bottomRight.x, bottomRight.y};
    return true;
}

void MenuBar::Paint(ControlHost& host) const
{
    auto* dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    const auto& theme                            = host.GetTheme();
    const D2D1_RECT_F bounds                     = GetBounds();
    const D2D1_RECT_F bgRect                     = D2D1::RectF(bounds.left, bounds.top, bounds.right, bounds.bottom);
    const D2D1_RECT_F border                     = D2D1::RectF(bounds.left, bounds.bottom - 1.0f, bounds.right, bounds.bottom);
    const MenuBarLayoutCache& layout             = EnsureMenuBarLayoutCache(host);
    const FontRole fontRole                      = layout.fontRole;
    const std::optional<size_t> highlightedIndex = GetVisualHighlightIndex();
    FillRectangleWithColor(host, bgRect, theme.windowBackground);
    FillRectangleWithColor(host, border, theme.borderDefault);

    for (size_t index = 0; index < _items.size() && index < layout.itemRects.size(); ++index)
    {
        const MenuBarItem& item    = _items[index];
        const D2D1_RECT_F itemRect = layout.itemRects[index];
        if (itemRect.right <= itemRect.left)
        {
            continue;
        }

        const bool highlighted = highlightedIndex == std::optional<size_t>{index};
        const bool pressed     = _pressedIndex.has_value() && _pressedIndex.value() == index;
        if (highlighted && item.enabled)
        {
            const D2D1_COLOR_F fill = pressed ? theme.headerPressed : theme.headerHovered;
            DrawRoundedRect(host, itemRect, fill, D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f), kMenuBarItemCornerRadiusDip);
        }

        const D2D1_COLOR_F textColor = item.enabled ? theme.text : theme.disabledText;
        DrawCenteredText(
            host, item.text, itemRect, fontRole, textColor, DWRITE_TEXT_ALIGNMENT_CENTER, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false, GetFlowDirection());
    }
}

bool MenuBar::OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT /*modifiers*/)
{
    const std::optional<size_t> hit = HitTestItem(host, MakePointDip(point));
    if (_hoveredIndex != hit)
    {
        TraceMenuBarPointerEvent(L"mouse-move-hover-change", host, point, hit, _pressedIndex, _selectedIndex, _items.size());
        _hoveredIndex = hit;
        if (_onHoverChanged)
        {
            const std::weak_ptr<int> lifetime = GetLifetimeToken();
            auto onHoverChanged               = _onHoverChanged;
            (*onHoverChanged)(GetHoveredIndex());
            onHoverChanged.reset();
            if (lifetime.expired())
            {
                return true;
            }
        }
        InvalidateIfInteractive(host);
    }
    return true;
}

bool MenuBar::OnMouseLeave(ControlHost& host)
{
    if (_hoveredIndex.has_value())
    {
        _hoveredIndex.reset();
        if (_onHoverChanged)
        {
            const std::weak_ptr<int> lifetime = GetLifetimeToken();
            auto onHoverChanged               = _onHoverChanged;
            (*onHoverChanged)(std::nullopt);
            onHoverChanged.reset();
            if (lifetime.expired())
            {
                return true;
            }
        }
        InvalidateIfInteractive(host);
    }
    return true;
}

void MenuBar::OnCaptureLost(ControlHost& host)
{
    if (_pressedIndex.has_value())
    {
        _pressedIndex.reset();
        InvalidateIfInteractive(host);
    }
}

bool MenuBar::OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    if (rightButton)
    {
        return false;
    }

    const std::optional<size_t> hit = HitTestItem(host, MakePointDip(point));
    TraceMenuBarPointerEvent(L"mouse-down", host, point, hit, _pressedIndex, _selectedIndex, _items.size());
    if (! hit.has_value() || ! _items[hit.value()].enabled)
    {
        return false;
    }

    if (! FocusControlAndSurvive(host, *this))
    {
        return true;
    }
    _selectedIndex = hit;
    _pressedIndex  = hit;
    InvalidateIfInteractive(host);
    return true;
}

bool MenuBar::OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    if (rightButton)
    {
        return false;
    }

    const std::optional<size_t> hit     = HitTestItem(host, MakePointDip(point));
    const std::optional<size_t> pressed = _pressedIndex;
    TraceMenuBarPointerEvent(L"mouse-up", host, point, hit, pressed, _selectedIndex, _items.size());
    _pressedIndex = std::nullopt;
    InvalidateIfInteractive(host);

    if (! pressed.has_value() || hit != pressed)
    {
        Debug::Info(L"DxUi::MenuTrace MenuBar mouse-up-rejected hwnd={:#x} capture={:#x} hit={} pressed={} selected={}",
                    reinterpret_cast<uintptr_t>(host.GetHwnd()),
                    reinterpret_cast<uintptr_t>(GetCapture()),
                    TraceOptionalIndex(hit),
                    TraceOptionalIndex(pressed),
                    TraceOptionalIndex(_selectedIndex));
        return false;
    }

    const size_t openIndex = pressed.value();
    Debug::Info(L"DxUi::MenuTrace MenuBar mouse-up-open hwnd={:#x} captureBeforeRelease={:#x} index={}",
                reinterpret_cast<uintptr_t>(host.GetHwnd()),
                reinterpret_cast<uintptr_t>(GetCapture()),
                openIndex);
    host.ReleaseMouseCapture();
    Debug::Info(L"DxUi::MenuTrace MenuBar mouse-up-after-release hwnd={:#x} capture={:#x} index={}",
                reinterpret_cast<uintptr_t>(host.GetHwnd()),
                reinterpret_cast<uintptr_t>(GetCapture()),
                openIndex);
    return ActivateItem(host, openIndex, false);
}

void MenuBar::PropagateHost(ControlHost* host) noexcept
{
    const bool hostChanged = GetHost() != host;
    Control::PropagateHost(host);
    if (hostChanged)
    {
        InvalidateMenuBarLayoutCache();
    }
}

void MenuBar::OnBoundsChanged() noexcept
{
    InvalidateMenuBarLayoutCache();
}

void MenuBar::OnFlowDirectionChanged() noexcept
{
    Control::OnFlowDirectionChanged();
    InvalidateMenuBarLayoutCache();
}

void MenuBar::OnDensityChanged() noexcept
{
    Control::OnDensityChanged();
    InvalidateMenuBarLayoutCache();
}

void MenuBar::OnHostDpiChanged(ControlHost& host) noexcept
{
    Control::OnHostDpiChanged(host);
    InvalidateMenuBarLayoutCache();
}

bool MenuBar::OnKeyDown(ControlHost& host, UINT virtualKey, UINT /*modifiers*/)
{
    if (_items.empty())
    {
        return false;
    }
    const bool rightToLeft = IsRightToLeft();

    const auto findDirectionalItem = [this](std::optional<size_t> current, bool forward) -> std::optional<size_t>
    {
        if (_items.empty())
        {
            return std::nullopt;
        }

        if (! current.has_value())
        {
            const auto begin = forward ? size_t{0u} : (_items.size() - 1u);
            const auto end   = forward ? _items.size() : static_cast<size_t>(-1);
            if (forward)
            {
                for (size_t index = begin; index < end; ++index)
                {
                    if (_items[index].enabled)
                    {
                        return index;
                    }
                }
            }
            else
            {
                for (size_t index = begin + 1u; index > 0u; --index)
                {
                    if (_items[index - 1u].enabled)
                    {
                        return index - 1u;
                    }
                }
            }
            return std::nullopt;
        }

        for (size_t step = 1u; step <= _items.size(); ++step)
        {
            const size_t next =
                forward ? ((current.value() + step) % _items.size()) : ((current.value() + _items.size() - (step % _items.size())) % _items.size());
            if (_items[next].enabled)
            {
                return next;
            }
        }
        return std::nullopt;
    };

    switch (virtualKey)
    {
        case VK_LEFT:
            if (const std::optional<size_t> next = findDirectionalItem(_selectedIndex, rightToLeft); next.has_value())
            {
                _selectedIndex = next;
                InvalidateIfInteractive(host);
                return true;
            }
            return false;
        case VK_RIGHT:
            if (const std::optional<size_t> next = findDirectionalItem(_selectedIndex, ! rightToLeft); next.has_value())
            {
                _selectedIndex = next;
                InvalidateIfInteractive(host);
                return true;
            }
            return false;
        case VK_HOME:
            if (const std::optional<size_t> next = findDirectionalItem(std::nullopt, true); next.has_value())
            {
                _selectedIndex = next;
                InvalidateIfInteractive(host);
                return true;
            }
            return false;
        case VK_END:
            if (const std::optional<size_t> next = findDirectionalItem(std::nullopt, false); next.has_value())
            {
                _selectedIndex = next;
                InvalidateIfInteractive(host);
                return true;
            }
            return false;
        case VK_DOWN:
        case VK_RETURN:
        case VK_SPACE: return ActivateSelected(host, true);
        default: return false;
    }
}

bool MenuBar::OnMnemonic(ControlHost& host)
{
    return ActivateSelected(host, true);
}

void MenuBar::OnFocusChanged(ControlHost& host, bool focused)
{
    Control::OnFocusChanged(host, focused);
    if (! focused)
    {
        _pressedIndex.reset();
        _hoveredIndex.reset();
        if (! _retainSelectedIndexOnFocusLost)
        {
            _selectedIndex.reset();
        }
    }
    else if (! _selectedIndex.has_value())
    {
        for (size_t index = 0; index < _items.size(); ++index)
        {
            if (_items[index].enabled)
            {
                _selectedIndex = index;
                break;
            }
        }
    }
    InvalidateIfInteractive(host);
}

std::optional<size_t> MenuBar::GetVisualHighlightIndex() const noexcept
{
    const auto sanitize = [this](std::optional<size_t> index) noexcept -> std::optional<size_t>
    { return (index.has_value() && index.value() < _items.size() && _items[index.value()].enabled) ? index : std::nullopt; };

    if (const std::optional<size_t> pressed = sanitize(_pressedIndex); pressed.has_value())
    {
        return pressed;
    }
    if (const std::optional<size_t> selected = sanitize(_selectedIndex); selected.has_value())
    {
        return selected;
    }
    return sanitize(_hoveredIndex);
}

std::optional<size_t> MenuBar::HitTestItem(const ControlHost& host, PointDip pointDip) const noexcept
{
    const D2D1_POINT_2F point        = pointDip.AsD2D();
    const D2D1_RECT_F bounds         = GetBounds();
    const MenuBarLayoutCache& layout = EnsureMenuBarLayoutCache(host);
    for (size_t index = 0; index < layout.itemRects.size(); ++index)
    {
        D2D1_RECT_F hitRect = layout.itemRects[index];
        hitRect.top         = bounds.top;
        hitRect.bottom      = bounds.bottom;
        if (PointInRect(hitRect, point))
        {
            return index;
        }
    }
    return std::nullopt;
}

void MenuBar::InvalidateMenuBarLayoutCache() const noexcept
{
    _menuBarLayoutCache.valid = false;
}

const MenuBar::MenuBarLayoutCache& MenuBar::EnsureMenuBarLayoutCache(const ControlHost& host) const noexcept
{
    // Layout-cache allocation failure remains fatal by repository policy; noexcept is intentional at this UI boundary.
    const D2D1_RECT_F bounds                        = GetBounds();
    const ThemePalette& theme                       = host.GetTheme();
    const DWRITE_READING_DIRECTION readingDirection = ResolveReadingDirection(GetFlowDirection());
    const FontRole fontRole                         = ResolveMenuBarFontRole(theme);
    const float menuBarHeightDip                    = ResolveMenuBarHeightDip(theme);
    const float insetDip                            = ResolveMenuBarInsetDip(theme);
    const float itemGapDip                          = ResolveMenuBarItemGapDip(theme);
    const float itemPaddingXDip                     = ResolveMenuBarItemPaddingXDip(theme);
    const float measureHeightDip                    = ResolveMenuBarItemMeasureHeightDip(theme);
    auto* format = host.GetTextFormat(fontRole, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false, readingDirection);

    const MenuBarLayoutCache& cached = _menuBarLayoutCache;
    if (cached.valid && cached.host == &host && cached.bounds.left == bounds.left && cached.bounds.top == bounds.top && cached.bounds.right == bounds.right &&
        cached.bounds.bottom == bounds.bottom && cached.readingDirection == readingDirection && cached.textFormat == format && cached.fontRole == fontRole &&
        cached.menuBarHeightDip == menuBarHeightDip && cached.insetDip == insetDip && cached.itemGapDip == itemGapDip &&
        cached.itemPaddingXDip == itemPaddingXDip && cached.measureHeightDip == measureHeightDip && cached.itemRects.size() == _items.size())
    {
        return _menuBarLayoutCache;
    }

    MenuBarLayoutCache& layout = _menuBarLayoutCache;
    layout.valid               = true;
    layout.host                = &host;
    layout.bounds              = bounds;
    layout.readingDirection    = readingDirection;
    layout.textFormat          = format;
    layout.fontRole            = fontRole;
    layout.menuBarHeightDip    = menuBarHeightDip;
    layout.insetDip            = insetDip;
    layout.itemGapDip          = itemGapDip;
    layout.itemPaddingXDip     = itemPaddingXDip;
    layout.measureHeightDip    = measureHeightDip;
    layout.itemWidthsDip.clear();
    layout.itemRects.clear();
    layout.itemWidthsDip.reserve(_items.size());
    layout.itemRects.reserve(_items.size());

    const float top        = bounds.top + insetDip;
    const float bottom     = (std::min)(bounds.bottom, bounds.top + menuBarHeightDip - insetDip);
    const bool rightToLeft = IsRightToLeft();
    float leadingCursor    = rightToLeft ? (bounds.right - insetDip) : (bounds.left + insetDip);
    float trailingCursor   = rightToLeft ? (bounds.left + insetDip) : (bounds.right - insetDip);

    for (size_t itemIndex = 0; itemIndex < _items.size(); ++itemIndex)
    {
        const MenuBarItem& item = _items[itemIndex];
        const float width       = MeasureItemWidth(host, item);
        layout.itemWidthsDip.push_back(width);
        D2D1_RECT_F itemRect{};
        if (item.rightJustified)
        {
            itemRect       = rightToLeft ? D2D1::RectF(trailingCursor, top, trailingCursor + width, bottom)
                                         : D2D1::RectF(trailingCursor - width, top, trailingCursor, bottom);
            trailingCursor = rightToLeft ? (itemRect.right + itemGapDip) : (itemRect.left - itemGapDip);
        }
        else
        {
            itemRect =
                rightToLeft ? D2D1::RectF(leadingCursor - width, top, leadingCursor, bottom) : D2D1::RectF(leadingCursor, top, leadingCursor + width, bottom);
            leadingCursor = rightToLeft ? (itemRect.left - itemGapDip) : (itemRect.right + itemGapDip);
        }

        layout.itemRects.push_back(itemRect);
    }

    if (Debug::Perf::IsCaptureEnabled())
    {
        Debug::Perf::Emit(
            L"dxui.menubar.layout_rebuild_count", L"", 0u, static_cast<uint64_t>(layout.itemRects.size()), static_cast<uint64_t>(_items.size()), S_OK);
    }

    return layout;
}

D2D1_RECT_F MenuBar::GetItemRect(const ControlHost& host, size_t index) const noexcept
{
    const MenuBarLayoutCache& layout = EnsureMenuBarLayoutCache(host);
    if (index >= layout.itemRects.size())
    {
        return D2D1::RectF();
    }

    return layout.itemRects[index];
}

float MenuBar::MeasureItemWidth(const ControlHost& host, const MenuBarItem& item) const noexcept
{
    auto* factory                = host.GetWriteFactory();
    const ThemePalette& theme    = host.GetTheme();
    const float itemPaddingXDip  = ResolveMenuBarItemPaddingXDip(theme);
    const float measureHeightDip = ResolveMenuBarItemMeasureHeightDip(theme);
    const FontRole fontRole      = ResolveMenuBarFontRole(theme);
    auto* format =
        host.GetTextFormat(fontRole, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false, ResolveReadingDirection(GetFlowDirection()));
    if (! factory || ! format || item.text.empty())
    {
        return (itemPaddingXDip * 2.0f) + 24.0f;
    }

    wil::com_ptr<IDWriteTextLayout> layout;
    if (FAILED(factory->CreateTextLayout(item.text.data(), static_cast<UINT32>(item.text.size()), format, 512.0f, measureHeightDip, layout.addressof())) ||
        ! layout)
    {
        return (itemPaddingXDip * 2.0f) + 24.0f;
    }

    DWRITE_TEXT_METRICS metrics{};
    if (FAILED(layout->GetMetrics(&metrics)))
    {
        return (itemPaddingXDip * 2.0f) + 24.0f;
    }

    return (itemPaddingXDip * 2.0f) + metrics.widthIncludingTrailingWhitespace;
}

std::optional<size_t> MenuBar::FindMnemonicItem(wchar_t mnemonic) const noexcept
{
    const wchar_t normalizedMnemonic = NormalizeMnemonicChar(mnemonic);
    if (normalizedMnemonic == L'\0')
    {
        return std::nullopt;
    }

    for (size_t index = 0; index < _items.size(); ++index)
    {
        if (! _items[index].enabled)
        {
            continue;
        }

        if (NormalizeMnemonicChar(_items[index].mnemonic) == normalizedMnemonic)
        {
            return index;
        }
    }

    return std::nullopt;
}

void MenuBar::InvalidateIfInteractive(ControlHost& host) noexcept
{
    if (IsVisible())
    {
        Invalidate(host);
    }
}

// --- TabControl ---

TabControl::TabControl()
{
    SetFocusable(true);
}

void TabControl::RemoveTab(size_t index) noexcept
{
    const auto& children = AccessChildren();
    if (index >= _tabs.size() || index >= children.size())
    {
        return;
    }

    Control* const page = children[index].get();
    if (! page)
    {
        return;
    }
    const std::weak_ptr<int> pageLifetime = GetControlLifetimeToken(*page);
    size_t removedIndex                   = 0u;
    static_cast<void>(RemoveTabByIdentity(page, pageLifetime, removedIndex));
}

std::optional<size_t> TabControl::FindTabIndex(const Control* page, const std::weak_ptr<int>& pageLifetime) const noexcept
{
    if (! page || pageLifetime.expired())
    {
        return std::nullopt;
    }

    const auto& children = AccessChildren();
    for (size_t index = 0u; index < children.size() && index < _tabs.size(); ++index)
    {
        if (children[index].get() == page && ! pageLifetime.expired())
        {
            return index;
        }
    }
    return std::nullopt;
}

std::unique_ptr<Control> TabControl::TakeTab(size_t index) noexcept
{
    auto& children = AccessChildren();
    if (index >= _tabs.size() || index >= children.size() || ! children[index])
        return {};
    Control* const page               = children[index].get();
    const std::weak_ptr<int> lifetime = GetControlLifetimeToken(*page);
    std::unique_ptr<Control> taken;
    size_t removedIndex = 0u;
    static_cast<void>(RemoveTabByIdentity(page, lifetime, removedIndex, &taken));
    return taken;
}

std::unique_ptr<Control> TabControl::TakeChild(size_t index) noexcept
{
    return TakeTab(index);
}

void TabControl::ClearChildren() noexcept
{
    const std::weak_ptr<int> lifetime = GetLifetimeToken();
    _tabs.clear();
    _selectedIndex.reset();
    InvalidateTabHeaderLayoutCache();
    Panel::ClearChildren();
    if (! lifetime.expired())
        static_cast<void>(SyncLayout());
}

bool TabControl::RemoveTabByIdentity(Control* page, const std::weak_ptr<int>& pageLifetime, size_t& removedIndex, std::unique_ptr<Control>* takenPage) noexcept
{
    const std::weak_ptr<int> controlLifetime = GetLifetimeToken();
    std::optional<size_t> currentIndex       = FindTabIndex(page, pageLifetime);
    if (! currentIndex)
    {
        return false;
    }

    if (ControlHost* host = GetHost())
    {
        if (Control* captured = host->GetCapturedControl(); captured && ControlBelongsToBranch(page, captured))
        {
            host->CancelCapturedControlInteraction();
            if (controlLifetime.expired() || pageLifetime.expired())
                return false;
            currentIndex = FindTabIndex(page, pageLifetime);
            if (! currentIndex)
                return false;
        }
        if (Control* focused = host->GetFocusControl(); focused && ControlBelongsToBranch(page, focused))
        {
            // A focus callback may destroy the TabControl, remove the requested page, or shift it among its siblings.
            if (! FocusControlAndSurvive(*host, *this) || controlLifetime.expired() || pageLifetime.expired())
            {
                return false;
            }
            currentIndex = FindTabIndex(page, pageLifetime);
            if (! currentIndex)
            {
                return false;
            }
        }
    }

    auto& children                       = AccessChildren();
    const size_t index                   = currentIndex.value();
    std::unique_ptr<Control> removedPage = std::move(children[index]);
    children.erase(children.begin() + static_cast<ptrdiff_t>(index));
    _tabs.erase(_tabs.begin() + static_cast<ptrdiff_t>(index));
    removedIndex = index;
    InvalidateTabHeaderLayoutCache();

    if (_tabs.empty())
    {
        _selectedIndex.reset();
    }
    else if (_selectedIndex.has_value())
    {
        if (_selectedIndex.value() > index)
        {
            _selectedIndex = _selectedIndex.value() - 1u;
        }
        else if (_selectedIndex.value() >= _tabs.size())
        {
            _selectedIndex = _tabs.size() - 1u;
        }

        if (! _tabs[_selectedIndex.value()].visible)
        {
            _selectedIndex.reset();
            for (size_t candidate = 0u; candidate < _tabs.size(); ++candidate)
            {
                if (_tabs[candidate].visible)
                {
                    _selectedIndex = candidate;
                    break;
                }
            }
        }
    }

    if (takenPage)
    {
        DetachChildPreservingInheritance(*removedPage);
        if (pageLifetime.expired())
        {
            static_cast<void>(removedPage.release());
            return false;
        }
        *takenPage = std::move(removedPage);
    }
    return ! controlLifetime.expired() && SyncLayout();
}

void TabControl::SetTabTitle(size_t index, std::wstring title)
{
    if (index >= _tabs.size())
    {
        return;
    }

    _tabs[index].title = std::move(title);
    _tabs[index].measuredTitleWidthDip.reset();
    _tabs[index].measuredTitleTextFormat = nullptr;
    InvalidateTabHeaderLayoutCache();
    static_cast<void>(SyncLayout());
}

std::wstring_view TabControl::GetTabTitle(size_t index) const noexcept
{
    return index < _tabs.size() ? _tabs[index].title : std::wstring_view{};
}

void TabControl::SetTabTooltip(size_t index, std::wstring tooltipText)
{
    if (index >= _tabs.size())
    {
        return;
    }

    _tabs[index].tooltipText = std::move(tooltipText);
}

std::wstring_view TabControl::GetTabTooltip(size_t index) const noexcept
{
    return index < _tabs.size() ? _tabs[index].tooltipText : std::wstring_view{};
}

void TabControl::SetTabClosable(size_t index, bool closable) noexcept
{
    if (index >= _tabs.size())
    {
        return;
    }

    if (_tabs[index].closable == closable)
    {
        return;
    }

    _tabs[index].closable = closable;
    InvalidateTabHeaderLayoutCache();
    static_cast<void>(SyncLayout());
}

bool TabControl::IsTabClosable(size_t index) const noexcept
{
    return index < _tabs.size() && _tabs[index].closable;
}

void TabControl::SetTabVisible(size_t index, bool visible) noexcept
{
    if (index >= _tabs.size() || _tabs[index].visible == visible)
    {
        return;
    }

    _tabs[index].visible = visible;
    if (! visible)
    {
        if (_hoveredTabIndex == index)
        {
            _hoveredTabIndex.reset();
        }
        if (_pressedTabIndex == index)
        {
            _pressedTabIndex.reset();
        }
        if (_closePressedIndex == index)
        {
            _closePressedIndex.reset();
        }
        if (_draggingTabIndex == index)
        {
            _draggingTabIndex.reset();
            _dragReordering = false;
        }
    }

    if (_selectedIndex == index && ! visible)
    {
        _selectedIndex.reset();
        for (size_t candidate = 0u; candidate < _tabs.size(); ++candidate)
        {
            if (_tabs[candidate].visible)
            {
                _selectedIndex = candidate;
                break;
            }
        }
    }
    else if (! _selectedIndex.has_value() && visible)
    {
        _selectedIndex = index;
    }

    InvalidateTabHeaderLayoutCache();
    static_cast<void>(SyncLayout());
}

bool TabControl::IsTabVisible(size_t index) const noexcept
{
    return index < _tabs.size() && _tabs[index].visible;
}

void TabControl::SetTabReorderingEnabled(bool enabled) noexcept
{
    if (_tabReorderingEnabled == enabled)
    {
        return;
    }
    _tabReorderingEnabled = enabled;
    if (! enabled)
    {
        _draggingTabIndex.reset();
        _dragReordering = false;
    }
}

bool TabControl::IsTabReorderingEnabled() const noexcept
{
    return _tabReorderingEnabled;
}

size_t TabControl::GetTabCount() const noexcept
{
    return _tabs.size();
}

size_t TabControl::GetVisibleTabCount() const noexcept
{
    return static_cast<size_t>(std::count_if(_tabs.begin(), _tabs.end(), [](const TabItem& tab) noexcept { return tab.visible; }));
}

void TabControl::SetSelectedIndex(std::optional<size_t> index) noexcept
{
    if (index.has_value() && (index.value() >= _tabs.size() || ! _tabs[index.value()].visible))
    {
        index.reset();
        for (size_t candidate = _tabs.size(); candidate > 0u; --candidate)
        {
            if (_tabs[candidate - 1u].visible)
            {
                index = candidate - 1u;
                break;
            }
        }
    }

    if (_selectedIndex == index)
    {
        return;
    }

    _selectedIndex = index;
    static_cast<void>(SyncLayout());
}

std::optional<size_t> TabControl::GetSelectedIndex() const noexcept
{
    return _selectedIndex;
}

Control* TabControl::GetSelectedPage() noexcept
{
    auto& children = AccessChildren();
    return (_selectedIndex.has_value() && _selectedIndex.value() < children.size()) ? children[_selectedIndex.value()].get() : nullptr;
}

const Control* TabControl::GetSelectedPage() const noexcept
{
    const auto& children = AccessChildren();
    return (_selectedIndex.has_value() && _selectedIndex.value() < children.size()) ? children[_selectedIndex.value()].get() : nullptr;
}

void TabControl::SetOnSelectionChanged(std::function<void(size_t)> onSelectionChanged)
{
    ReplaceControlCallback(_onSelectionChanged, std::move(onSelectionChanged));
}

void TabControl::SetOnTabCloseRequested(std::function<bool(size_t)> onTabCloseRequested)
{
    ReplaceControlCallback(_onTabCloseRequested, std::move(onTabCloseRequested));
}

void TabControl::SetOnTabClosed(std::function<void(size_t)> onTabClosed)
{
    ReplaceControlCallback(_onTabClosed, std::move(onTabClosed));
}

void TabControl::SetOnTabReordered(std::function<void(size_t, size_t)> onTabReordered)
{
    ReplaceControlCallback(_onTabReordered, std::move(onTabReordered));
}

D2D1_RECT_F TabControl::GetHeaderRect() const noexcept
{
    const D2D1_RECT_F bounds = GetBounds();
    return D2D1::RectF(bounds.left, bounds.top, bounds.right, (std::min)(bounds.bottom, bounds.top + kTabStripHeightDip));
}

D2D1_RECT_F TabControl::GetContentRect() const noexcept
{
    const D2D1_RECT_F bounds = GetBounds();
    const D2D1_RECT_F header = GetHeaderRect();
    return D2D1::RectF(bounds.left, header.bottom, bounds.right, bounds.bottom);
}

void TabControl::InvalidateTabHeaderLayoutCache() const noexcept
{
    _tabHeaderLayoutCache.valid = false;
}

void TabControl::InvalidateTabTitleMeasurements() const noexcept
{
    for (const TabItem& tab : _tabs)
    {
        tab.measuredTitleWidthDip.reset();
        tab.measuredTitleTextFormat.reset();
        tab.measuredTitleReadingDirection = DWRITE_READING_DIRECTION_LEFT_TO_RIGHT;
    }
    InvalidateTabHeaderLayoutCache();
}

bool TabControl::NeedsOverflowButtons() const noexcept
{
    return EnsureTabHeaderLayoutCache().needsOverflowButtons;
}

D2D1_RECT_F TabControl::GetHeaderDividerRect() const noexcept
{
    const D2D1_RECT_F contentRect = GetContentRect();
    if (GetVisibleTabCount() == 0u || contentRect.right <= contentRect.left)
    {
        return D2D1::RectF();
    }

    return D2D1::RectF(contentRect.left, contentRect.top, contentRect.right, contentRect.top + 1.0f);
}

bool TabControl::HasHeaderDividerPaintSegment() const noexcept
{
    const D2D1_RECT_F dividerRect = GetHeaderDividerRect();
    if (dividerRect.right <= dividerRect.left || dividerRect.bottom <= dividerRect.top)
    {
        return false;
    }

    const auto hasVisibleSegment = [&](const float fromX, const float toX) noexcept
    {
        const float left  = std::clamp(fromX, dividerRect.left, dividerRect.right);
        const float right = std::clamp(toX, dividerRect.left, dividerRect.right);
        return right - left > 0.5f;
    };

    if (_selectedIndex.has_value() && _selectedIndex.value() < _tabs.size())
    {
        const D2D1_RECT_F selectedTabRect = GetTabRect(_selectedIndex.value());
        return hasVisibleSegment(dividerRect.left, selectedTabRect.left) || hasVisibleSegment(selectedTabRect.right, dividerRect.right);
    }

    return hasVisibleSegment(dividerRect.left, dividerRect.right);
}

float TabControl::GetHeaderViewportLeft() const noexcept
{
    return EnsureTabHeaderLayoutCache().viewportLeftDip;
}

float TabControl::GetHeaderViewportRight() const noexcept
{
    return EnsureTabHeaderLayoutCache().viewportRightDip;
}

float TabControl::MeasureTabTitleWidthDip(size_t index, const ControlHost& host) const noexcept
{
    if (index >= _tabs.size())
    {
        return 0.0f;
    }

    const DWRITE_READING_DIRECTION readingDirection = ResolveReadingDirection(GetFlowDirection());
    auto* format       = host.GetTextFormat(FontRole::Body, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false, readingDirection);
    const TabItem& tab = _tabs[index];
    if (tab.measuredTitleWidthDip.has_value() && tab.measuredTitleTextFormat.get() == format && tab.measuredTitleReadingDirection == readingDirection)
    {
        return tab.measuredTitleWidthDip.value();
    }

    const bool perfEnabled            = Debug::Perf::IsCaptureEnabled();
    const auto startedAt              = perfEnabled ? std::chrono::steady_clock::now() : std::chrono::steady_clock::time_point{};
    const float widthDip              = MeasureSingleLineTextWidthDip(&host, tab.title, FontRole::Body, kTabStripHeightDip, readingDirection);
    tab.measuredTitleWidthDip         = widthDip;
    tab.measuredTitleTextFormat       = format;
    tab.measuredTitleReadingDirection = readingDirection;

    if (perfEnabled)
    {
        const std::wstring_view detail = readingDirection == DWRITE_READING_DIRECTION_RIGHT_TO_LEFT ? L"rtl" : L"ltr";
        Debug::Perf::Emit(L"dxui.tabcontrol.title_measure_count", detail, Debug::Perf::ElapsedUs(startedAt), 1u, tab.title.size(), S_OK);
    }

    return widthDip;
}

const TabControl::TabHeaderLayoutCache& TabControl::EnsureTabHeaderLayoutCache() const noexcept
{
    // Layout-cache allocation failure remains fatal by repository policy; noexcept is intentional at this UI boundary.
    if (_tabHeaderLayoutCache.valid)
    {
        return _tabHeaderLayoutCache;
    }

    TabHeaderLayoutCache& layout = _tabHeaderLayoutCache;
    layout.valid                 = true;
    layout.needsOverflowButtons  = false;
    layout.viewportLeftDip       = 0.0f;
    layout.viewportRightDip      = 0.0f;
    layout.totalTabWidthDip      = 0.0f;
    layout.backButtonRect        = D2D1::RectF();
    layout.forwardButtonRect     = D2D1::RectF();
    layout.tabWidthsDip.clear();
    layout.tabRects.clear();
    layout.tabWidthsDip.reserve(_tabs.size());
    layout.tabRects.reserve(_tabs.size());

    size_t visibleTabCount = 0u;
    for (size_t index = 0u; index < _tabs.size(); ++index)
    {
        const float widthDip = _tabs[index].visible ? MeasureTabWidthDip(index) : 0.0f;
        layout.tabWidthsDip.push_back(widthDip);
        if (widthDip > 0.0f)
        {
            if (visibleTabCount != 0u)
            {
                layout.totalTabWidthDip += kTabHeaderGapDip;
            }
            layout.totalTabWidthDip += widthDip;
            ++visibleTabCount;
        }
    }

    const D2D1_RECT_F header        = GetHeaderRect();
    const float reserved            = kTabHeaderGapDip * 2.0f;
    layout.needsOverflowButtons     = layout.totalTabWidthDip > ((header.right - header.left) - reserved);
    const float overflowButtonWidth = layout.needsOverflowButtons ? kTabHeaderOverflowButtonWidthDip : 0.0f;
    layout.viewportLeftDip          = header.left + kTabHeaderGapDip + overflowButtonWidth;
    layout.viewportRightDip         = header.right - kTabHeaderGapDip - overflowButtonWidth;

    if (layout.needsOverflowButtons)
    {
        layout.backButtonRect    = IsRightToLeft()
                                       ? D2D1::RectF(header.right - kTabHeaderOverflowButtonWidthDip, header.top + 4.0f, header.right, header.bottom - 4.0f)
                                       : D2D1::RectF(header.left, header.top + 4.0f, header.left + kTabHeaderOverflowButtonWidthDip, header.bottom - 4.0f);
        layout.forwardButtonRect = IsRightToLeft()
                                       ? D2D1::RectF(header.left, header.top + 4.0f, header.left + kTabHeaderOverflowButtonWidthDip, header.bottom - 4.0f)
                                       : D2D1::RectF(header.right - kTabHeaderOverflowButtonWidthDip, header.top + 4.0f, header.right, header.bottom - 4.0f);
    }

    if (header.bottom > header.top)
    {
        const float top    = header.top + 4.0f;
        const float bottom = header.bottom;
        if (IsRightToLeft())
        {
            float cursor = layout.viewportRightDip + _headerScrollOffsetDip;
            for (float widthDip : layout.tabWidthsDip)
            {
                if (widthDip <= 0.0f)
                {
                    layout.tabRects.push_back(D2D1::RectF());
                    continue;
                }
                const D2D1_RECT_F rect = D2D1::RectF(cursor - widthDip, top, cursor, bottom);
                layout.tabRects.push_back(rect);
                cursor = rect.left - kTabHeaderGapDip;
            }
        }
        else
        {
            float cursor = layout.viewportLeftDip - _headerScrollOffsetDip;
            for (float widthDip : layout.tabWidthsDip)
            {
                if (widthDip <= 0.0f)
                {
                    layout.tabRects.push_back(D2D1::RectF());
                    continue;
                }
                const D2D1_RECT_F rect = D2D1::RectF(cursor, top, cursor + widthDip, bottom);
                layout.tabRects.push_back(rect);
                cursor = rect.right + kTabHeaderGapDip;
            }
        }
    }

    if (Debug::Perf::IsCaptureEnabled())
    {
        Debug::Perf::Emit(
            L"dxui.tabcontrol.header_layout_rebuild_count", L"", 0u, static_cast<uint64_t>(layout.tabRects.size()), static_cast<uint64_t>(_tabs.size()), S_OK);
    }

    return layout;
}

float TabControl::MeasureTabWidthDip(size_t index) const noexcept
{
    if (index >= _tabs.size() || ! _tabs[index].visible)
    {
        return 0.0f;
    }

    const ControlHost* host  = GetHost();
    const float textWidthDip = host ? MeasureTabTitleWidthDip(index, *host) : static_cast<float>(_tabs[index].title.size()) * 7.5f;
    return (std::max)(kTabHeaderMinWidthDip,
                      textWidthDip + (kTabHeaderPaddingXDip * 2.0f) + (_tabs[index].closable ? (kTabHeaderCloseButtonSizeDip + 6.0f) : 0.0f));
}

float TabControl::GetTotalTabWidthDip() const noexcept
{
    return EnsureTabHeaderLayoutCache().totalTabWidthDip;
}

D2D1_RECT_F TabControl::GetBackButtonRect() const noexcept
{
    return EnsureTabHeaderLayoutCache().backButtonRect;
}

D2D1_RECT_F TabControl::GetForwardButtonRect() const noexcept
{
    return EnsureTabHeaderLayoutCache().forwardButtonRect;
}

D2D1_RECT_F TabControl::GetTabRect(size_t index) const noexcept
{
    const TabHeaderLayoutCache& layout = EnsureTabHeaderLayoutCache();
    if (index >= layout.tabRects.size())
    {
        return D2D1::RectF();
    }

    return layout.tabRects[index];
}

D2D1_RECT_F TabControl::GetCloseButtonRect(size_t index) const noexcept
{
    if (index >= _tabs.size() || ! _tabs[index].visible || ! _tabs[index].closable)
    {
        return D2D1::RectF();
    }

    const D2D1_RECT_F tabRect = GetTabRect(index);
    const float top           = tabRect.top + ((tabRect.bottom - tabRect.top - kTabHeaderCloseButtonSizeDip) * 0.5f);
    return IsRightToLeft() ? D2D1::RectF(tabRect.left + 6.0f, top, tabRect.left + 6.0f + kTabHeaderCloseButtonSizeDip, top + kTabHeaderCloseButtonSizeDip)
                           : D2D1::RectF(tabRect.right - 6.0f - kTabHeaderCloseButtonSizeDip, top, tabRect.right - 6.0f, top + kTabHeaderCloseButtonSizeDip);
}

bool TabControl::IsCloseButtonVisible(size_t index) const noexcept
{
    if (index >= _tabs.size() || ! _tabs[index].visible || ! _tabs[index].closable)
    {
        return false;
    }

    const bool selected = _selectedIndex.has_value() && _selectedIndex.value() == index;
    const bool hovered  = _hoveredTabIndex.has_value() && _hoveredTabIndex.value() == index;
    return selected || hovered;
}

TabControl::HeaderHitInfo TabControl::HitTestHeader(D2D1_POINT_2F point) const noexcept
{
    if (! PointInRect(GetHeaderRect(), point))
    {
        return {};
    }

    if (NeedsOverflowButtons())
    {
        if (PointInRect(GetBackButtonRect(), point))
        {
            return HeaderHitInfo{.part = HeaderPart::BackButton};
        }
        if (PointInRect(GetForwardButtonRect(), point))
        {
            return HeaderHitInfo{.part = HeaderPart::ForwardButton};
        }
    }

    for (size_t index = 0u; index < _tabs.size(); ++index)
    {
        const D2D1_RECT_F tabRect = GetTabRect(index);
        if (! PointInRect(tabRect, point))
        {
            continue;
        }

        if (IsCloseButtonVisible(index) && PointInRect(GetCloseButtonRect(index), point))
        {
            return HeaderHitInfo{.part = HeaderPart::CloseButton, .index = index};
        }

        return HeaderHitInfo{.part = HeaderPart::Tab, .index = index};
    }

    return {};
}

void TabControl::ScrollHeaderBy(float deltaDip) noexcept
{
    const float viewportWidth = (std::max)(0.0f, GetHeaderViewportRight() - GetHeaderViewportLeft());
    const float maxOffset     = (std::max)(0.0f, GetTotalTabWidthDip() - viewportWidth);
    const float oldOffset     = _headerScrollOffsetDip;
    _headerScrollOffsetDip    = (std::clamp)(_headerScrollOffsetDip + deltaDip, 0.0f, maxOffset);
    if (_headerScrollOffsetDip != oldOffset)
    {
        InvalidateTabHeaderLayoutCache();
    }
    RequestInvalidate();
}

void TabControl::EnsureSelectedTabVisible() noexcept
{
    if (! _selectedIndex.has_value())
    {
        return;
    }

    const D2D1_RECT_F viewport = D2D1::RectF(GetHeaderViewportLeft(), GetHeaderRect().top, GetHeaderViewportRight(), GetHeaderRect().bottom);
    const D2D1_RECT_F tabRect  = GetTabRect(_selectedIndex.value());
    if (tabRect.right <= tabRect.left || viewport.right <= viewport.left)
    {
        return;
    }

    if (tabRect.left < viewport.left)
    {
        ScrollHeaderBy(IsRightToLeft() ? (viewport.left - tabRect.left) : (tabRect.left - viewport.left));
    }
    else if (tabRect.right > viewport.right)
    {
        ScrollHeaderBy(IsRightToLeft() ? (viewport.right - tabRect.right) : (tabRect.right - viewport.right));
    }
}

bool TabControl::UpdateVisiblePageBounds() noexcept
{
    Debug::Perf::Scope updatePerf(L"dxui.tabcontrol.update_visible_pages_us");
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    const size_t visitBudget               = (std::min)(AccessChildren().size(), _tabs.size());
    updatePerf.SetValue0(_selectedIndex.has_value() ? static_cast<uint64_t>(_selectedIndex.value()) : 0u);
    updatePerf.SetValue1(static_cast<uint64_t>(visitBudget));

    // Page callbacks may synchronously remove or reorder siblings, or destroy this TabControl. Re-fetch the
    // owning vector after each callback, resolve the page by identity, and cap visits to the initial page count;
    // a nested SyncLayout handles pages inserted by a callback.
    size_t index  = 0u;
    size_t visits = 0u;
    while (visits < visitBudget)
    {
        if (ownerLifetime.expired())
        {
            return false;
        }

        auto& children = AccessChildren();
        if (index >= children.size() || index >= _tabs.size())
        {
            break;
        }

        Control* const page = children[index].get();
        if (! page)
        {
            ++index;
            ++visits;
            continue;
        }
        const std::weak_ptr<int> pageLifetime = GetControlLifetimeToken(*page);
        bool visible                          = _tabs[index].visible && _selectedIndex.has_value() && _selectedIndex.value() == index;
        if (visible)
        {
            page->SetBounds(GetContentRect());
            if (ownerLifetime.expired())
            {
                return false;
            }

            const std::optional<size_t> currentIndex = FindTabIndex(page, pageLifetime);
            if (! currentIndex)
            {
                ++visits;
                continue;
            }
            index = currentIndex.value();
        }

        std::optional<size_t> currentIndex = FindTabIndex(page, pageLifetime);
        if (! currentIndex)
        {
            ++visits;
            continue;
        }
        index   = currentIndex.value();
        visible = _tabs[index].visible && _selectedIndex.has_value() && _selectedIndex.value() == index;
        page->SetVisible(visible);
        if (ownerLifetime.expired())
        {
            return false;
        }

        currentIndex = FindTabIndex(page, pageLifetime);
        ++visits;
        index = currentIndex ? currentIndex.value() + 1u : index;
    }
    return ! ownerLifetime.expired();
}

bool TabControl::SyncLayout() noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    Debug::Perf::Scope syncPerf(L"dxui.tabcontrol.sync_layout_us");
    const float viewportWidth = (std::max)(0.0f, GetHeaderViewportRight() - GetHeaderViewportLeft());
    const float maxOffset     = (std::max)(0.0f, GetTotalTabWidthDip() - viewportWidth);
    const float oldOffset     = _headerScrollOffsetDip;
    _headerScrollOffsetDip    = (std::clamp)(_headerScrollOffsetDip, 0.0f, maxOffset);
    if (_headerScrollOffsetDip != oldOffset)
    {
        InvalidateTabHeaderLayoutCache();
    }
    syncPerf.SetValue0(_selectedIndex.has_value() ? static_cast<uint64_t>(_selectedIndex.value()) : 0u);
    syncPerf.SetValue1(static_cast<uint64_t>(_tabs.size()));
    if (! UpdateVisiblePageBounds() || ownerLifetime.expired())
    {
        return false;
    }
    EnsureSelectedTabVisible();
    if (ownerLifetime.expired())
    {
        return false;
    }
    RequestInvalidate();
    return ! ownerLifetime.expired();
}

bool TabControl::SelectTab(ControlHost& host, size_t index, bool focusSelf) noexcept
{
    if (index >= _tabs.size() || ! _tabs[index].visible)
    {
        return true;
    }

    const bool changed = _selectedIndex != index;
    Debug::Perf::Scope selectPerf(L"dxui.tabcontrol.select_tab_us");
    selectPerf.SetValue0(static_cast<uint64_t>(index));
    selectPerf.SetValue1(changed ? 1u : 0u);
    if (! changed)
    {
        return ! focusSelf || FocusControlAndSurvive(host, *this);
    }

    const auto& initialChildren = AccessChildren();
    if (index >= initialChildren.size() || ! initialChildren[index])
    {
        return true;
    }
    Control* const requestedPage             = initialChildren[index].get();
    const std::weak_ptr<int> pageLifetime    = GetControlLifetimeToken(*requestedPage);
    const std::weak_ptr<int> controlLifetime = GetLifetimeToken();
    _selectedIndex                           = index;
    if (focusSelf && (! FocusControlAndSurvive(host, *this) || controlLifetime.expired()))
    {
        return false;
    }
    std::optional<size_t> currentIndex = FindTabIndex(requestedPage, pageLifetime);
    if (! currentIndex)
    {
        return true;
    }
    _selectedIndex = currentIndex;
    if (! SyncLayout() || controlLifetime.expired())
    {
        return false;
    }
    if (controlLifetime.expired())
    {
        return false;
    }
    currentIndex = FindTabIndex(requestedPage, pageLifetime);
    if (! currentIndex || _selectedIndex != currentIndex)
    {
        return true;
    }
    if (const auto onSelectionChanged = _onSelectionChanged; onSelectionChanged)
    {
        (*onSelectionChanged)(currentIndex.value());
    }
    return ! controlLifetime.expired();
}

void TabControl::CloseTab(ControlHost& host, size_t index) noexcept
{
    const auto& initialChildren = AccessChildren();
    if (index >= _tabs.size() || index >= initialChildren.size() || ! initialChildren[index])
    {
        return;
    }

    Control* const requestedPage           = initialChildren[index].get();
    const std::weak_ptr<int> pageLifetime  = GetControlLifetimeToken(*requestedPage);
    const std::weak_ptr<int> closeLifetime = GetLifetimeToken();
    const auto onTabCloseRequested         = _onTabCloseRequested;
    if (onTabCloseRequested)
    {
        const bool closeCanceled = (*onTabCloseRequested)(index);
        if (closeLifetime.expired())
        {
            return;
        }
        if (closeCanceled)
        {
            Invalidate(host);
            return;
        }
    }

    if (closeLifetime.expired())
    {
        return;
    }

    size_t closedIndex = 0u;
    if (! RemoveTabByIdentity(requestedPage, pageLifetime, closedIndex) || closeLifetime.expired())
    {
        return;
    }
    const auto onTabClosed = _onTabClosed;
    if (onTabClosed)
    {
        (*onTabClosed)(closedIndex);
        if (closeLifetime.expired())
        {
            return;
        }
    }
    Invalidate(host);
}

void TabControl::ReorderTab(size_t fromIndex, size_t toIndex) noexcept
{
    auto& children = AccessChildren();
    if (fromIndex >= _tabs.size() || toIndex >= _tabs.size() || fromIndex == toIndex || fromIndex >= children.size() || toIndex >= children.size())
    {
        return;
    }

    auto movedTab   = std::move(_tabs[fromIndex]);
    auto movedChild = std::move(children[fromIndex]);
    _tabs.erase(_tabs.begin() + static_cast<ptrdiff_t>(fromIndex));
    children.erase(children.begin() + static_cast<ptrdiff_t>(fromIndex));
    _tabs.insert(_tabs.begin() + static_cast<ptrdiff_t>(toIndex), std::move(movedTab));
    children.insert(children.begin() + static_cast<ptrdiff_t>(toIndex), std::move(movedChild));

    if (_selectedIndex.has_value())
    {
        if (_selectedIndex.value() == fromIndex)
        {
            _selectedIndex = toIndex;
        }
        else if (fromIndex < _selectedIndex.value() && toIndex >= _selectedIndex.value())
        {
            _selectedIndex = _selectedIndex.value() - 1u;
        }
        else if (fromIndex > _selectedIndex.value() && toIndex <= _selectedIndex.value())
        {
            _selectedIndex = _selectedIndex.value() + 1u;
        }
    }
    InvalidateTabHeaderLayoutCache();
}

void TabControl::UpdateDragReorder(ControlHost& host, D2D1_POINT_2F point) noexcept
{
    if (! _tabReorderingEnabled || ! _draggingTabIndex.has_value())
    {
        return;
    }

    const size_t dragIndex = _draggingTabIndex.value();
    for (size_t index = 0u; index < _tabs.size(); ++index)
    {
        if (index == dragIndex || ! _tabs[index].visible)
        {
            continue;
        }

        const D2D1_RECT_F tabRect = GetTabRect(index);
        const float midpoint      = (tabRect.left + tabRect.right) * 0.5f;
        if ((IsRightToLeft() && point.x > midpoint) || (! IsRightToLeft() && point.x < midpoint))
        {
            const auto& children = AccessChildren();
            if (dragIndex >= children.size() || ! children[dragIndex])
            {
                return;
            }
            Control* const movedPage                   = children[dragIndex].get();
            const std::weak_ptr<int> movedPageLifetime = GetControlLifetimeToken(*movedPage);
            const std::weak_ptr<int> ownerLifetime     = GetLifetimeToken();
            ReorderTab(dragIndex, index);
            _draggingTabIndex = index;
            if (! SyncLayout() || ownerLifetime.expired())
            {
                return;
            }
            const std::optional<size_t> currentIndex = FindTabIndex(movedPage, movedPageLifetime);
            if (! currentIndex)
            {
                _draggingTabIndex.reset();
                return;
            }
            _draggingTabIndex = currentIndex;
            Invalidate(host);
            if (ownerLifetime.expired())
            {
                return;
            }
            const auto onTabReordered = _onTabReordered;
            if (onTabReordered)
            {
                (*onTabReordered)(dragIndex, currentIndex.value());
            }
            return;
        }
    }
}

void TabControl::PaintHeaderDivider(ControlHost& host) const noexcept
{
    const D2D1_RECT_F dividerRect = GetHeaderDividerRect();
    if (! HasHeaderDividerPaintSegment())
    {
        return;
    }

    const auto& theme          = host.GetTheme();
    const D2D1_COLOR_F divider = theme.highContrast ? theme.border : theme.borderStrong;
    const float dividerY       = SnapDipToPixel(host, dividerRect.top);
    const auto drawSegment     = [&](const float fromX, const float toX) noexcept
    {
        const float left  = std::clamp(fromX, dividerRect.left, dividerRect.right);
        const float right = std::clamp(toX, dividerRect.left, dividerRect.right);
        if (right - left > 0.5f)
        {
            DrawLineWithColor(host, D2D1::Point2F(left, dividerY), D2D1::Point2F(right, dividerY), divider, 1.0f);
        }
    };

    if (_selectedIndex.has_value() && _selectedIndex.value() < _tabs.size())
    {
        const D2D1_RECT_F selectedTabRect = GetTabRect(_selectedIndex.value());
        drawSegment(dividerRect.left, selectedTabRect.left);
        drawSegment(selectedTabRect.right, dividerRect.right);
        return;
    }

    drawSegment(dividerRect.left, dividerRect.right);
}

void TabControl::Paint(ControlHost& host) const
{
    Debug::Perf::Scope tabPaintPerf(L"dxui.tabcontrol.paint");

    auto* dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    const auto& theme             = host.GetTheme();
    const D2D1_RECT_F bounds      = GetBounds();
    const D2D1_RECT_F headerRect  = GetHeaderRect();
    const D2D1_RECT_F contentRect = GetContentRect();

    FillRectangleWithColor(host, bounds, theme.windowBackground);
    FillRectangleWithColor(host, contentRect, theme.cardBackground);
    if (contentRect.right > contentRect.left && contentRect.bottom > contentRect.top)
    {
        const auto drawHeaderSeparatorSegment = [&](const float fromX, const float toX) noexcept
        {
            const float left  = std::clamp(fromX, contentRect.left, contentRect.right);
            const float right = std::clamp(toX, contentRect.left, contentRect.right);
            if (right - left > 0.5f)
            {
                DrawLineWithColor(host, D2D1::Point2F(left, contentRect.top), D2D1::Point2F(right, contentRect.top), theme.borderDefault, 1.0f);
            }
        };

        if (_selectedIndex.has_value() && _selectedIndex.value() < _tabs.size())
        {
            const D2D1_RECT_F selectedTabRect = GetTabRect(_selectedIndex.value());
            drawHeaderSeparatorSegment(contentRect.left, selectedTabRect.left);
            drawHeaderSeparatorSegment(selectedTabRect.right, contentRect.right);
        }
        else
        {
            drawHeaderSeparatorSegment(contentRect.left, contentRect.right);
        }

        DrawLineWithColor(
            host, D2D1::Point2F(contentRect.left, contentRect.top), D2D1::Point2F(contentRect.left, contentRect.bottom), theme.borderDefault, 1.0f);
        DrawLineWithColor(host,
                          D2D1::Point2F(contentRect.right - 1.0f, contentRect.top),
                          D2D1::Point2F(contentRect.right - 1.0f, contentRect.bottom),
                          theme.borderDefault,
                          1.0f);
        DrawLineWithColor(host,
                          D2D1::Point2F(contentRect.left, contentRect.bottom - 1.0f),
                          D2D1::Point2F(contentRect.right, contentRect.bottom - 1.0f),
                          theme.borderDefault,
                          1.0f);
    }

    if (NeedsOverflowButtons())
    {
        const D2D1_RECT_F backRect    = GetBackButtonRect();
        const D2D1_RECT_F forwardRect = GetForwardButtonRect();
        DrawRoundedRect(host, backRect, theme.headerBackground, theme.borderDefault, 4.0f);
        DrawRoundedRect(host, forwardRect, theme.headerBackground, theme.borderDefault, 4.0f);
        DrawCenteredText(host,
                         IsRightToLeft() ? L"\xE76C" : L"\xE76B",
                         backRect,
                         FontRole::Icon,
                         theme.text,
                         DWRITE_TEXT_ALIGNMENT_CENTER,
                         DWRITE_PARAGRAPH_ALIGNMENT_CENTER,
                         false,
                         FlowDirection::LeftToRight);
        DrawCenteredText(host,
                         IsRightToLeft() ? L"\xE76B" : L"\xE76C",
                         forwardRect,
                         FontRole::Icon,
                         theme.text,
                         DWRITE_TEXT_ALIGNMENT_CENTER,
                         DWRITE_PARAGRAPH_ALIGNMENT_CENTER,
                         false,
                         FlowDirection::LeftToRight);
    }

    const D2D1_RECT_F clipRect = D2D1::RectF(GetHeaderViewportLeft(), headerRect.top, GetHeaderViewportRight(), headerRect.bottom);
    dc->PushAxisAlignedClip(clipRect, D2D1_ANTIALIAS_MODE_PER_PRIMITIVE);
    for (size_t index = 0u; index < _tabs.size(); ++index)
    {
        if (! _tabs[index].visible)
        {
            continue;
        }
        const D2D1_RECT_F tabRect         = GetTabRect(index);
        const bool selected               = _selectedIndex.has_value() && _selectedIndex.value() == index;
        const bool hovered                = _hoveredTabIndex.has_value() && _hoveredTabIndex.value() == index;
        const bool closeVisible           = IsCloseButtonVisible(index);
        const D2D1_COLOR_F fill           = selected ? theme.cardBackground : (hovered ? theme.headerHovered : theme.windowBackground);
        const D2D1_COLOR_F transparent    = D2D1::ColorF(0.0f, 0.0f, 0.0f, 0.0f);
        const D2D1_RECT_F attachedTabRect = D2D1::RectF(tabRect.left, tabRect.top, tabRect.right, tabRect.bottom);
        if (selected)
        {
            DrawTopRoundedAttachedRect(
                host, attachedTabRect, fill, theme.borderDefault, kTabCornerRadiusDip, kTabAttachFillExtensionDip, kTabAttachStrokeInsetDip);
        }
        else if (hovered)
        {
            DrawTopRoundedAttachedRect(host, attachedTabRect, fill, transparent, kTabCornerRadiusDip, kTabAttachFillExtensionDip, 0.0f);
        }

        const D2D1_RECT_F closeRect = GetCloseButtonRect(index);
        const D2D1_RECT_F textRect = IsRightToLeft()
                                         ? D2D1::RectF(tabRect.left + (_tabs[index].closable ? (kTabHeaderCloseButtonSizeDip + 12.0f) : kTabHeaderPaddingXDip),
                                                       tabRect.top,
                                                       tabRect.right - kTabHeaderPaddingXDip,
                                                       tabRect.bottom)
                                         : D2D1::RectF(tabRect.left + kTabHeaderPaddingXDip,
                                                       tabRect.top,
                                                       tabRect.right - (_tabs[index].closable ? (kTabHeaderCloseButtonSizeDip + 12.0f) : kTabHeaderPaddingXDip),
                                                       tabRect.bottom);
        DrawCenteredText(host,
                         _tabs[index].title,
                         textRect,
                         FontRole::Body,
                         theme.text,
                         DWRITE_TEXT_ALIGNMENT_LEADING, // The format reads in the flow direction, so leading is the start side.
                         DWRITE_PARAGRAPH_ALIGNMENT_CENTER,
                         false,
                         GetFlowDirection());

        if (closeVisible)
        {
            DrawCenteredText(host,
                             L"\xE711",
                             closeRect,
                             FontRole::Icon,
                             theme.subduedText,
                             DWRITE_TEXT_ALIGNMENT_CENTER,
                             DWRITE_PARAGRAPH_ALIGNMENT_CENTER,
                             false,
                             FlowDirection::LeftToRight);
        }
    }
    dc->PopAxisAlignedClip();

    if (HasFocus() && host.IsKeyboardFocusVisible() && _selectedIndex.has_value())
    {
        PaintFocusRing(host, GetTabRect(_selectedIndex.value()), 6.0f);
    }

    Panel::Paint(host);
    PaintHeaderDivider(host);
}

bool TabControl::OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    if (rightButton || ! IsEnabled())
    {
        return false;
    }

    const HeaderHitInfo hit = HitTestHeader(point);
    switch (hit.part)
    {
        case HeaderPart::None: break;
        case HeaderPart::BackButton:
            ScrollHeaderBy(IsRightToLeft() ? 96.0f : -96.0f);
            Invalidate(host);
            return true;
        case HeaderPart::ForwardButton:
            ScrollHeaderBy(IsRightToLeft() ? -96.0f : 96.0f);
            Invalidate(host);
            return true;
        case HeaderPart::CloseButton:
            host.CaptureMouse(this);
            _closePressedIndex = hit.index;
            if (IsFocusable() && ! FocusControlAndSurvive(host, *this))
            {
                return true;
            }
            Invalidate(host);
            return true;
        case HeaderPart::Tab:
            if (! SelectTab(host, hit.index, IsFocusable()))
            {
                return true;
            }
            host.CaptureMouse(this);
            _pressedTabIndex = hit.index;
            if (_tabReorderingEnabled)
            {
                _draggingTabIndex = hit.index;
                _dragStartPoint   = point;
                _dragReordering   = false;
            }
            return true;
    }

    return false;
}

bool TabControl::OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT /*modifiers*/)
{
    const HeaderHitInfo hit = HitTestHeader(point);
    const std::optional<size_t> nextHover =
        (hit.part == HeaderPart::Tab || hit.part == HeaderPart::CloseButton) ? std::optional<size_t>{hit.index} : std::nullopt;
    bool tooltipChanged = false;
    if (nextHover.has_value() && nextHover.value() < _tabs.size() && ! _tabs[nextHover.value()].tooltipText.empty())
    {
        tooltipChanged = host.SetTooltipDelayed(std::wstring(_tabs[nextHover.value()].tooltipText), point);
    }
    else
    {
        tooltipChanged = host.BeginTooltipHideDelay();
    }
    if (_hoveredTabIndex != nextHover)
    {
        _hoveredTabIndex = nextHover;
        Invalidate(host);
    }
    else if (tooltipChanged)
    {
        Invalidate(host);
    }

    if (_tabReorderingEnabled && _draggingTabIndex.has_value())
    {
        if (! _dragReordering && std::fabs(point.x - _dragStartPoint.x) >= 6.0f)
        {
            _dragReordering = true;
        }
        if (_dragReordering)
        {
            UpdateDragReorder(host, point);
            return true;
        }
    }

    return hit.part != HeaderPart::None;
}

bool TabControl::OnMouseLeave(ControlHost& host)
{
    const bool tooltipChanged = host.BeginTooltipHideDelay();
    if (_hoveredTabIndex.has_value())
    {
        _hoveredTabIndex.reset();
        Invalidate(host);
    }
    else if (tooltipChanged)
    {
        Invalidate(host);
    }
    return true;
}

void TabControl::OnCaptureLost(ControlHost& host)
{
    const bool hadPressedState = _pressedTabIndex.has_value() || _closePressedIndex.has_value() || _draggingTabIndex.has_value() || _dragReordering;
    _pressedTabIndex.reset();
    _closePressedIndex.reset();
    _draggingTabIndex.reset();
    _dragReordering = false;
    if (hadPressedState)
    {
        Invalidate(host);
    }
}

bool TabControl::OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    host.ReleaseMouseCapture();

    if (rightButton)
    {
        return false;
    }

    const HeaderHitInfo hit                  = HitTestHeader(point);
    const std::optional<size_t> closePressed = _closePressedIndex;
    const std::optional<size_t> pressedTab   = _pressedTabIndex;
    _closePressedIndex.reset();
    _pressedTabIndex.reset();
    _draggingTabIndex.reset();
    _dragReordering = false;

    if (closePressed.has_value() && hit.part == HeaderPart::CloseButton && hit.index == closePressed.value())
    {
        CloseTab(host, hit.index);
        return true;
    }

    if (pressedTab.has_value() && hit.part == HeaderPart::Tab && hit.index == pressedTab.value())
    {
        static_cast<void>(SelectTab(host, hit.index, IsFocusable()));
        return true;
    }

    Invalidate(host);
    return false;
}

bool TabControl::OnMouseWheel(ControlHost& host, D2D1_POINT_2F point, float wheelDelta, UINT /*modifiers*/)
{
    if (! PointInRect(GetHeaderRect(), point) || ! NeedsOverflowButtons())
    {
        return false;
    }

    ScrollHeaderBy((wheelDelta > 0.0f ? -72.0f : 72.0f) * (IsRightToLeft() ? -1.0f : 1.0f));
    Invalidate(host);
    return true;
}

bool TabControl::OnKeyDown(ControlHost& host, UINT virtualKey, UINT /*modifiers*/)
{
    if (GetVisibleTabCount() == 0u)
    {
        return false;
    }

    const bool rightToLeft = IsRightToLeft();
    const size_t current   = _selectedIndex.value_or(0u);
    const auto findVisible = [this](size_t start, int direction) noexcept -> size_t
    {
        size_t candidate = start;
        do
        {
            candidate = direction > 0 ? ((candidate + 1u) % _tabs.size()) : ((candidate + _tabs.size() - 1u) % _tabs.size());
            if (_tabs[candidate].visible)
            {
                return candidate;
            }
        } while (candidate != start);
        return start;
    };
    const auto firstVisible = [this]() noexcept -> size_t
    {
        for (size_t index = 0u; index < _tabs.size(); ++index)
        {
            if (_tabs[index].visible)
            {
                return index;
            }
        }
        return 0u;
    };
    const auto lastVisible = [this]() noexcept -> size_t
    {
        for (size_t index = _tabs.size(); index > 0u; --index)
        {
            if (_tabs[index - 1u].visible)
            {
                return index - 1u;
            }
        }
        return 0u;
    };
    switch (virtualKey)
    {
        case VK_HOME: static_cast<void>(SelectTab(host, firstVisible(), true)); return true;
        case VK_END: static_cast<void>(SelectTab(host, lastVisible(), true)); return true;
        case VK_LEFT: static_cast<void>(SelectTab(host, findVisible(current, rightToLeft ? 1 : -1), true)); return true;
        case VK_RIGHT: static_cast<void>(SelectTab(host, findVisible(current, rightToLeft ? -1 : 1), true)); return true;
        default: return false;
    }
}

Control* TabControl::HitTest(D2D1_POINT_2F point)
{
    if (! Control::HitTest(point))
    {
        return nullptr;
    }

    if (PointInRect(GetHeaderRect(), point))
    {
        return this;
    }

    return Panel::HitTest(point);
}

const Control* TabControl::HitTest(D2D1_POINT_2F point) const
{
    if (! Control::HitTest(point))
    {
        return nullptr;
    }

    if (PointInRect(GetHeaderRect(), point))
    {
        return this;
    }

    return Panel::HitTest(point);
}

void TabControl::PropagateHost(ControlHost* host) noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    const bool hostChanged                 = GetHost() != host;
    Panel::PropagateHost(host);
    if (ownerLifetime.expired())
    {
        return;
    }
    if (hostChanged)
    {
        InvalidateTabTitleMeasurements();
    }
}

void TabControl::OnBoundsChanged() noexcept
{
    InvalidateTabHeaderLayoutCache();
    static_cast<void>(SyncLayout());
}

void TabControl::OnFlowDirectionChanged() noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    Panel::OnFlowDirectionChanged();
    if (ownerLifetime.expired())
    {
        return;
    }
    InvalidateTabHeaderLayoutCache();
    static_cast<void>(SyncLayout());
}

void TabControl::OnDensityChanged() noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    Panel::OnDensityChanged();
    if (ownerLifetime.expired())
    {
        return;
    }
    InvalidateTabTitleMeasurements();
    static_cast<void>(SyncLayout());
}

void TabControl::OnHostDpiChanged(ControlHost& host) noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    Panel::OnHostDpiChanged(host);
    if (ownerLifetime.expired())
    {
        return;
    }
    InvalidateTabTitleMeasurements();
    static_cast<void>(SyncLayout());
}

#if DXUI_ENABLE_DIAGNOSTICS
D2D1_RECT_F TabControl::DebugGetTabRect(size_t index) const noexcept
{
    return GetTabRect(index);
}

D2D1_RECT_F TabControl::DebugGetCloseButtonRect(size_t index) const noexcept
{
    return GetCloseButtonRect(index);
}

bool TabControl::DebugIsCloseButtonVisible(size_t index) const noexcept
{
    return IsCloseButtonVisible(index);
}

float TabControl::DebugGetHeaderScrollOffsetDip() const noexcept
{
    return _headerScrollOffsetDip;
}

bool TabControl::DebugHasOverflowButtons() const noexcept
{
    return NeedsOverflowButtons();
}

D2D1_RECT_F TabControl::DebugGetHeaderDividerRect() const noexcept
{
    return GetHeaderDividerRect();
}

bool TabControl::DebugHasHeaderDivider() const noexcept
{
    return HasHeaderDividerPaintSegment();
}

D2D1_RECT_F TabControl::DebugGetBackButtonRect() const noexcept
{
    return GetBackButtonRect();
}

D2D1_RECT_F TabControl::DebugGetForwardButtonRect() const noexcept
{
    return GetForwardButtonRect();
}
#endif

// --- StatusStrip (multi-section upgrade) ---

StatusStrip::StatusStrip(std::wstring text) : _text(std::move(text))
{
}

void StatusStrip::SetText(std::wstring text)
{
    _text = std::move(text);
    RequestInvalidate();
}

std::wstring_view StatusStrip::GetText() const noexcept
{
    return _text;
}

void StatusStrip::SetFontRole(FontRole fontRole) noexcept
{
    _fontRole = fontRole;
    RequestInvalidate();
}

void StatusStrip::SetBlendWithWindowBackground(bool blend) noexcept
{
    if (_blendWithWindowBackground == blend)
    {
        return;
    }

    _blendWithWindowBackground = blend;
    RequestInvalidate();
}

bool StatusStrip::GetBlendWithWindowBackground() const noexcept
{
    return _blendWithWindowBackground;
}

void StatusStrip::SetSections(std::vector<Section> sections)
{
    _sections = std::move(sections);
    RequestInvalidate();
}

void StatusStrip::SetSectionText(size_t index, std::wstring text)
{
    if (index < _sections.size())
    {
        _sections[index].text = std::move(text);
        RequestInvalidate();
    }
}

size_t StatusStrip::GetSectionCount() const noexcept
{
    return _sections.size();
}

std::wstring_view StatusStrip::GetSectionText(size_t index) const noexcept
{
    if (index >= _sections.size())
    {
        return {};
    }

    return _sections[index].text;
}

DWRITE_TEXT_ALIGNMENT StatusStrip::GetSectionAlignment(size_t index) const noexcept
{
    if (index >= _sections.size())
    {
        return DWRITE_TEXT_ALIGNMENT_LEADING;
    }

    return _sections[index].alignment;
}

bool StatusStrip::GetSectionLeadingEllipsis(size_t index) const noexcept
{
    return index < _sections.size() && _sections[index].leadingEllipsis;
}

std::wstring StatusStrip::ElideLeadingForWidth(const ControlHost* host, std::wstring_view text, FontRole fontRole, float widthDip, float heightDip) noexcept
{
    if (text.empty())
    {
        return {};
    }

    if (widthDip <= 0.5f)
    {
        return L"...";
    }

    if (MeasureSingleLineTextWidthDip(host, text, fontRole, heightDip) <= (widthDip + 0.5f))
    {
        return std::wstring(text);
    }

    constexpr std::wstring_view kEllipsis = L"...";
    if (MeasureSingleLineTextWidthDip(host, kEllipsis, fontRole, heightDip) > widthDip)
    {
        return std::wstring(kEllipsis);
    }

    size_t low  = 0u;
    size_t high = text.size();
    while (low < high)
    {
        const size_t candidateSuffixLength = low + ((high - low + 1u) / 2u);
        const size_t suffixStart           = text.size() - candidateSuffixLength;
        std::wstring candidate(kEllipsis);
        candidate.append(text.substr(suffixStart));

        if (MeasureSingleLineTextWidthDip(host, candidate, fontRole, heightDip) <= (widthDip + 0.5f))
        {
            low = candidateSuffixLength;
        }
        else
        {
            high = candidateSuffixLength - 1u;
        }
    }

    size_t suffixStart = text.size() - low;
    while (suffixStart < text.size() && IsUtf16TrailSurrogate(text[suffixStart]))
    {
        ++suffixStart;
    }

    std::wstring result(kEllipsis);
    result.append(text.substr(suffixStart));
    return result;
}

std::wstring StatusStrip::DebugElideLeadingForWidth(
    const ControlHost* host, std::wstring_view text, FontRole fontRole, float widthDip, float heightDip) noexcept
{
    return ElideLeadingForWidth(host, text, fontRole, widthDip, heightDip);
}

void StatusStrip::Paint(ControlHost& host) const
{
    const auto& theme             = host.GetTheme();
    const D2D1_RECT_F bounds      = GetBounds();
    const float textInsetLeftDip  = theme.density == Density::Compact ? 6.0f : 8.0f;
    const float textInsetRightDip = theme.density == Density::Compact ? 3.0f : 4.0f;
    const float separatorInset    = theme.density == Density::Compact ? 3.0f : 4.0f;

    // 22 DIP height (spec §3.10), subtle background unless embedded as inline status text.
    if (host.GetDeviceContext() && ! _blendWithWindowBackground)
    {
        FillRectangleWithColor(host, bounds, theme.cardBackground);
        // Top border
        const D2D1_RECT_F topBorder = D2D1::RectF(bounds.left, bounds.top, bounds.right, bounds.top + 1.0f);
        FillRectangleWithColor(host, topBorder, theme.borderDefault);
    }

    if (_sections.empty())
    {
        // Single-text mode (backward compatible)
        if (! _text.empty())
        {
            const D2D1_RECT_F textRect = D2D1::RectF(bounds.left + 8.0f, bounds.top + 1.0f, bounds.right - 8.0f, bounds.bottom);
            DrawCenteredText(
                host, _text, textRect, _fontRole, theme.text, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false, GetFlowDirection());
        }
        return;
    }

    // Multi-section layout
    const float totalWidth = bounds.right - bounds.left;
    float fixedWidth       = 0.0f;
    int stretchCount       = 0;
    for (const auto& section : _sections)
    {
        if (section.widthDip > 0.0f)
        {
            fixedWidth += section.widthDip;
        }
        else
        {
            ++stretchCount;
        }
    }
    const float remainingWidth  = (std::max)(0.0f, totalWidth - fixedWidth);
    const float stretchWidth    = stretchCount > 0 ? remainingWidth / static_cast<float>(stretchCount) : 0.0f;
    const D2D1_COLOR_F sepColor = BlendColor(theme.windowBackground, theme.borderDefault, theme.dark ? 0.50f : 0.36f);

    float xPos = bounds.left;
    for (size_t i = 0; i < _sections.size(); ++i)
    {
        const auto& section        = _sections[i];
        const float sectionWidth   = section.widthDip > 0.0f ? section.widthDip : stretchWidth;
        const D2D1_RECT_F textRect = D2D1::RectF(xPos + textInsetLeftDip, bounds.top + 1.0f, xPos + sectionWidth - textInsetRightDip, bounds.bottom);

        if (! section.text.empty())
        {
            std::wstring elidedText;
            std::wstring_view text = section.text;
            if (section.leadingEllipsis)
            {
                elidedText =
                    ElideLeadingForWidth(&host, section.text, _fontRole, std::max(0.0f, textRect.right - textRect.left), textRect.bottom - textRect.top);
                text = elidedText;
            }

            DrawCenteredText(host, text, textRect, _fontRole, theme.text, section.alignment, DWRITE_PARAGRAPH_ALIGNMENT_CENTER, false, GetFlowDirection());
        }

        xPos += sectionWidth;

        // Separator between sections
        if (i + 1 < _sections.size() && ! _blendWithWindowBackground)
        {
            if (host.GetDeviceContext())
            {
                const D2D1_RECT_F sep = D2D1::RectF(xPos - 0.5f, bounds.top + separatorInset, xPos + 0.5f, bounds.bottom - separatorInset);
                FillRectangleWithColor(host, sep, sepColor);
            }
        }
    }
}

ColorSwatch::ColorSwatch(std::optional<uint32_t> swatchArgb) : _swatchArgb(swatchArgb)
{
}

void ColorSwatch::SetOnClick(std::function<void()> onClick)
{
    ReplaceControlCallback(_onClick, std::move(onClick));
}

void ColorSwatch::SetSwatchValue(std::optional<uint32_t> swatchArgb) noexcept
{
    _swatchArgb = swatchArgb;
    RequestInvalidate();
}

std::optional<uint32_t> ColorSwatch::GetSwatchValue() const noexcept
{
    return _swatchArgb;
}

void ColorSwatch::Paint(ControlHost& host) const
{
    const D2D1_RECT_F bounds           = GetBounds();
    const ColorSwatchVisualStyle style = ResolveColorSwatchVisualStyle(
        host.GetTheme(), IsEnabled(), IsHovered(), _pressed, HasFocus(), HasFocus() && host.IsKeyboardFocusVisible(), _swatchArgb);
    DrawRoundedRect(host, bounds, style.fill, style.border, 4.0f);

    const D2D1_RECT_F innerRect = InflateRect(bounds, -4.0f, -4.0f);
    DrawRoundedRect(host, innerRect, style.swatchFill, style.swatchBorder, 2.5f);

    if (style.showFocus)
    {
        PaintFocusRing(host, bounds, 4.0f);
    }
}

bool ColorSwatch::OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    if (! IsEnabled() || rightButton)
    {
        return false;
    }

    if (! FocusControlAndSurvive(host, *this))
    {
        return true;
    }
    _pressed = PointInRect(GetHitBounds(), point);
    Invalidate(host);
    return _pressed;
}

bool ColorSwatch::OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT /*modifiers*/)
{
    if (! IsEnabled() || rightButton)
    {
        return false;
    }

    const bool wasPressed = _pressed;
    _pressed              = false;
    Invalidate(host);
    if (wasPressed && PointInRect(GetHitBounds(), point))
    {
        const auto onClick = _onClick;
        if (onClick)
        {
            (*onClick)();
        }
    }
    return wasPressed;
}

bool ColorSwatch::OnKeyDown(ControlHost& host, UINT virtualKey, UINT /*modifiers*/)
{
    if (! IsEnabled())
    {
        return false;
    }

    if (virtualKey == VK_SPACE || virtualKey == VK_RETURN)
    {
        const std::weak_ptr<int> lifetime = GetLifetimeToken();
        if (const auto onClick = _onClick; onClick)
        {
            (*onClick)();
        }
        if (lifetime.expired())
        {
            return true;
        }
        Invalidate(host);
        return true;
    }

    return false;
}

void ColorSwatch::OnCaptureLost(ControlHost& host)
{
    if (_pressed)
    {
        _pressed = false;
        Invalidate(host);
    }
}

void PopupLayer::Paint(ControlHost& host) const
{
    static_cast<void>(host);
}

void PopupLayer::PaintOverlay(ControlHost& host) const
{
    Panel::Paint(host);
    Panel::PaintOverlay(host);
}

Control* PopupLayer::HitTestOverlay(D2D1_POINT_2F point)
{
    return Panel::HitTest(point);
}

const Control* PopupLayer::HitTestOverlay(D2D1_POINT_2F point) const
{
    return Panel::HitTest(point);
}

// --- StackPanel ---

void StackPanel::SetOrientation(StackOrientation orientation) noexcept
{
    if (_orientation != orientation)
    {
        _orientation = orientation;
        ++_layoutRevision;
    }
    RequestInvalidate();
}

StackOrientation StackPanel::GetOrientation() const noexcept
{
    return _orientation;
}

void StackPanel::SetGap(float gapDip) noexcept
{
    if (_gapDip != gapDip)
    {
        _gapDip = gapDip;
        ++_layoutRevision;
    }
    RequestInvalidate();
}

float StackPanel::GetGap() const noexcept
{
    return _gapDip;
}

void StackPanel::SetPadding(float left, float top, float right, float bottom) noexcept
{
    if (_padLeft != left || _padTop != top || _padRight != right || _padBottom != bottom)
    {
        _padLeft   = left;
        _padTop    = top;
        _padRight  = right;
        _padBottom = bottom;
        ++_layoutRevision;
    }
    RequestInvalidate();
}

void StackPanel::SetChildExtent(const Control* child, float extentDip)
{
    for (auto& entry : _childExtents)
    {
        if (entry.first == child)
        {
            if (entry.second != extentDip)
            {
                entry.second = extentDip;
                ++_layoutRevision;
            }
            return;
        }
    }
    _childExtents.emplace_back(child, extentDip);
    ++_layoutRevision;
}

float StackPanel::GetContentExtent() const noexcept
{
    const auto children  = GetChildren();
    const bool vertical  = (_orientation == StackOrientation::Vertical);
    const float padStart = vertical ? _padTop : _padLeft;
    const float padEnd   = vertical ? _padBottom : _padRight;

    float extent = padStart;
    bool first   = true;
    for (const auto& child : children)
    {
        if (! child || ! child->IsVisible())
        {
            continue;
        }

        float childExtent = 0.0f;
        for (const auto& entry : _childExtents)
        {
            if (entry.first == child.get())
            {
                childExtent = entry.second;
                break;
            }
        }

        if (! first)
        {
            extent += _gapDip;
        }
        extent += childExtent;
        first = false;
    }

    extent += padEnd;
    return extent;
}

void StackPanel::ApplyLayout()
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    const uint64_t layoutRevision          = ++_layoutRevision;
    const D2D1_RECT_F bounds               = GetBounds();
    const bool vertical                    = _orientation == StackOrientation::Vertical;
    const bool rightToLeft                 = ! vertical && IsRightToLeft();
    const float gapDip                     = _gapDip;
    const float padLeft                    = _padLeft;
    const float padTop                     = _padTop;
    const float padRight                   = _padRight;
    const float padBottom                  = _padBottom;
    const size_t initialChildCount         = GetLogicalChildCount();

    const float crossStart = vertical ? bounds.left + padLeft : bounds.top + padTop;
    const float crossEnd   = vertical ? bounds.right - padRight : bounds.bottom - padBottom;
    float mainCursor       = vertical ? bounds.top + padTop : (rightToLeft ? bounds.right - padRight : bounds.left + padLeft);
    bool first             = true;
    size_t nextChildIndex  = 0u;
    bool staleLayout       = false;
    ForEachPanelChildCallback(*this,
                              ownerLifetime,
                              [&](Control& child) noexcept
    {
        if (staleLayout || ownerLifetime.expired())
        {
            return;
        }
        if (_layoutRevision != layoutRevision)
        {
            staleLayout = true;
            return;
        }
        const auto children = GetChildren();
        if (children.size() != initialChildCount)
        {
            staleLayout = true;
            return;
        }
        size_t childIndex = nextChildIndex;
        while (childIndex < children.size() && children[childIndex].get() != &child)
        {
            ++childIndex;
        }
        if (childIndex >= children.size())
        {
            staleLayout = true;
            return;
        }
        const bool visible = child.IsVisible();
        nextChildIndex     = childIndex + 1u;
        if (! visible)
        {
            return;
        }

        float childExtent = 0.0f;
        for (const auto& entry : _childExtents)
        {
            if (entry.first == &child)
            {
                childExtent = entry.second;
                break;
            }
        }

        if (! first)
        {
            mainCursor += rightToLeft ? -gapDip : gapDip;
        }

        const std::weak_ptr<int> childLifetime = GetControlLifetimeToken(child);
        D2D1_RECT_F childBounds{};
        if (vertical)
        {
            childBounds = D2D1::RectF(crossStart, mainCursor, crossEnd, mainCursor + childExtent);
        }
        else
        {
            childBounds = rightToLeft ? D2D1::RectF(mainCursor - childExtent, crossStart, mainCursor, crossEnd)
                                      : D2D1::RectF(mainCursor, crossStart, mainCursor + childExtent, crossEnd);
        }
        child.SetBounds(childBounds);
        if (ownerLifetime.expired() || childLifetime.expired() || _layoutRevision != layoutRevision)
        {
            staleLayout = true;
            return;
        }
        const auto currentChildren = GetChildren();
        if (currentChildren.size() != initialChildCount || childIndex >= currentChildren.size() || currentChildren[childIndex].get() != &child ||
            child.IsVisible() != visible)
        {
            staleLayout = true;
            return;
        }
        mainCursor += rightToLeft ? -childExtent : childExtent;
        first = false;
    });
}

HRESULT ArrangeMeasuredActions(std::span<const D2D1_SIZE_F> sizes,
                               float availableWidthDip,
                               D2D1_SIZE_F gapsDip,
                               std::span<D2D1_RECT_F> bounds,
                               MeasuredActionLayout& result,
                               FlowDirection direction) noexcept
{
    if (! std::isfinite(availableWidthDip) || availableWidthDip <= 0.0f || ! std::isfinite(gapsDip.width) || gapsDip.width < 0.0f ||
        ! std::isfinite(gapsDip.height) || gapsDip.height < 0.0f || bounds.size() < sizes.size() ||
        (direction != FlowDirection::LeftToRight && direction != FlowDirection::RightToLeft))
    {
        return E_INVALIDARG;
    }
    for (const auto size : sizes)
    {
        if (! std::isfinite(size.width) || ! std::isfinite(size.height) || size.width < 0.0f || size.height < 0.0f || size.width > availableWidthDip ||
            ((size.width == 0.0f) != (size.height == 0.0f)))
        {
            return E_INVALIDARG;
        }
    }
    // First pass validates the total height. No partial bounds can escape on overflow.
    const auto arrange = [&](bool publish, MeasuredActionLayout& measured) noexcept
    {
        double x         = 0.0;
        double y         = 0.0;
        double rowHeight = 0.0;
        size_t rows      = 0;
        for (size_t index = 0; index < sizes.size(); ++index)
        {
            const auto size = sizes[index];
            if (size.width == 0.0f)
            {
                if (publish)
                {
                    bounds[index] = {};
                }
                continue;
            }
            if (rows == 0)
            {
                rows = 1;
            }
            if (x > 0.0)
            {
                if (x + gapsDip.width + size.width > availableWidthDip)
                {
                    y += rowHeight + gapsDip.height;
                    x         = 0.0;
                    rowHeight = 0.0;
                    ++rows;
                }
                else
                {
                    x += gapsDip.width;
                }
            }
            rowHeight = (std::max)(rowHeight, static_cast<double>(size.height));
            if (y + rowHeight > (std::numeric_limits<float>::max)())
            {
                return HRESULT_FROM_WIN32(ERROR_ARITHMETIC_OVERFLOW);
            }
            if (publish)
            {
                const double left = direction == FlowDirection::RightToLeft ? availableWidthDip - x - size.width : x;
                bounds[index] =
                    D2D1::RectF(static_cast<float>(left), static_cast<float>(y), static_cast<float>(left + size.width), static_cast<float>(y + size.height));
            }
            x += size.width;
        }
        measured = {static_cast<float>(y + rowHeight), rows};
        return S_OK;
    };
    MeasuredActionLayout measured{};
    const HRESULT hr = arrange(false, measured);
    if (FAILED(hr))
    {
        return hr;
    }
    return arrange(true, result);
}

// --- ScrollPanel ---

void ScrollPanel::ClearChildren() noexcept
{
    _innerHoveredChild  = nullptr;
    _innerCapturedChild = nullptr;
    _scrollbarHotPart   = HotPart::None;
    _dragThumb          = false;
    _dragThumbOffsetDip = 0.0f;
    Panel::ClearChildren();
}

void ScrollPanel::SetContentHeight(float heightDip) noexcept
{
    const float previousOffset = _scrollOffsetDip;
    _contentHeightDip          = (std::max)(0.0f, heightDip);
    ClampScrollOffset();
    RequestInvalidate();
    static_cast<void>(NotifyScrollChanged(previousOffset));
}

void StackPanel::OnBoundsChanged() noexcept
{
    ++_layoutRevision;
}

void StackPanel::OnFlowDirectionChanged() noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    ++_layoutRevision;
    Panel::OnFlowDirectionChanged();
    if (ownerLifetime.expired())
    {
        return;
    }
    ApplyLayout();
}

void StackPanel::OnDensityChanged() noexcept
{
    const std::weak_ptr<int> ownerLifetime = GetLifetimeToken();
    ++_layoutRevision;
    Panel::OnDensityChanged();
    if (ownerLifetime.expired())
    {
        return;
    }
    ApplyLayout();
}

float ScrollPanel::GetContentHeight() const noexcept
{
    return _contentHeightDip;
}

float ScrollPanel::GetScrollOffset() const noexcept
{
    return _scrollOffsetDip;
}

void ScrollPanel::SetScrollOffset(float offsetDip) noexcept
{
    const float previousOffset = _scrollOffsetDip;
    _scrollOffsetDip           = offsetDip;
    ClampScrollOffset();
    if (_scrollOffsetDip != previousOffset)
    {
        RequestInvalidate();
        static_cast<void>(NotifyScrollChanged(previousOffset));
    }
}

void ScrollPanel::ScrollToTop() noexcept
{
    SetScrollOffset(0.0f);
}

void ScrollPanel::SetScrollStepDip(float stepDip) noexcept
{
    _scrollStepDip = (std::max)(1.0f, stepDip);
}

void ScrollPanel::SetInternalScrollbarEnabled(bool enabled) noexcept
{
    if (_internalScrollbarEnabled != enabled)
    {
        _internalScrollbarEnabled = enabled;
        _scrollbarHotPart         = HotPart::None;
        _dragThumb                = false;
        _dragThumbOffsetDip       = 0.0f;
        RequestInvalidate();
    }
}

void ScrollPanel::SetOnScrollChanged(std::function<void(float)> callback) noexcept
{
    ReplaceControlCallback(_onScrollChanged, std::move(callback));
}

bool ScrollPanel::NeedsScrollbar() const noexcept
{
    const D2D1_RECT_F bounds   = GetBounds();
    const float viewportHeight = bounds.bottom - bounds.top;
    return _contentHeightDip > viewportHeight && viewportHeight > 0.0f;
}

float ScrollPanel::GetScrollbarThickness() const noexcept
{
    return kScrollbarThicknessDip;
}

bool ScrollPanel::IsInternalScrollbarEnabled() const noexcept
{
    return _internalScrollbarEnabled;
}

bool ScrollPanel::DebugGetScrollbarThumbHitRect(D2D1_RECT_F& out) const noexcept
{
    if (! UsesInternalScrollbar())
    {
        out = D2D1::RectF();
        return false;
    }

    out = GetScrollbarThumbHitRect();
    return out.right > out.left && out.bottom > out.top;
}

float ScrollPanel::GetScrollableExtent() const noexcept
{
    const D2D1_RECT_F bounds   = GetBounds();
    const float viewportHeight = bounds.bottom - bounds.top;
    return (std::max)(0.0f, _contentHeightDip - viewportHeight);
}

bool ScrollPanel::UsesInternalScrollbar() const noexcept
{
    return _internalScrollbarEnabled && NeedsScrollbar();
}

D2D1_RECT_F ScrollPanel::GetViewportRect() const noexcept
{
    D2D1_RECT_F bounds = GetBounds();
    if (UsesInternalScrollbar())
    {
        if (IsRightToLeft())
        {
            bounds.left += kScrollbarThicknessDip;
        }
        else
        {
            bounds.right -= kScrollbarThicknessDip;
        }
    }
    return bounds;
}

D2D1_RECT_F ScrollPanel::GetScrollbarTrackRect() const noexcept
{
    const D2D1_RECT_F bounds = GetBounds();
    return IsRightToLeft() ? D2D1::RectF(bounds.left, bounds.top, bounds.left + kScrollbarThicknessDip, bounds.bottom)
                           : D2D1::RectF(bounds.right - kScrollbarThicknessDip, bounds.top, bounds.right, bounds.bottom);
}

D2D1_RECT_F ScrollPanel::GetScrollbarThumbRect() const noexcept
{
    const D2D1_RECT_F track    = GetScrollbarTrackRect();
    const D2D1_RECT_F bounds   = GetBounds();
    const float viewportHeight = bounds.bottom - bounds.top;
    const float extent         = GetScrollableExtent();
    return ComputeScrollbarThumbRect(track, ScrollbarOrientation::Vertical, viewportHeight, _contentHeightDip, _scrollOffsetDip, extent);
}

D2D1_RECT_F ScrollPanel::GetScrollbarThumbHitRect() const noexcept
{
    const D2D1_RECT_F track    = GetScrollbarTrackRect();
    const D2D1_RECT_F bounds   = GetBounds();
    const float viewportHeight = bounds.bottom - bounds.top;
    const float extent         = GetScrollableExtent();
    return ComputeScrollbarThumbHitRect(track, ScrollbarOrientation::Vertical, viewportHeight, _contentHeightDip, _scrollOffsetDip, extent);
}

void ScrollPanel::ClampScrollOffset() noexcept
{
    const float extent = GetScrollableExtent();
    _scrollOffsetDip   = (extent <= 0.0f) ? 0.0f : (std::clamp)(_scrollOffsetDip, 0.0f, extent);
}

bool ScrollPanel::NotifyScrollChanged(float previousOffsetDip) noexcept
{
    const std::weak_ptr<int> lifetime = GetLifetimeToken();
    if (_scrollOffsetDip != previousOffsetDip && _onScrollChanged)
    {
        const auto onScrollChanged = _onScrollChanged;
        (*onScrollChanged)(_scrollOffsetDip);
    }
    return ! lifetime.expired();
}

D2D1_POINT_2F ScrollPanel::ToContentSpace(D2D1_POINT_2F viewportPoint) const noexcept
{
    return D2D1::Point2F(viewportPoint.x, viewportPoint.y + _scrollOffsetDip);
}

Control* ScrollPanel::FindChildAtContent(D2D1_POINT_2F contentPoint)
{
    return FindPanelChildHit(*this, GetLifetimeToken(), [contentPoint](Control& child) { return child.IsVisible() ? child.HitTest(contentPoint) : nullptr; });
}

Control* ScrollPanel::FindOverlayChildAtContent(D2D1_POINT_2F contentPoint)
{
    return FindPanelChildHit(
        *this, GetLifetimeToken(), [contentPoint](Control& child) { return child.IsVisible() ? child.HitTestOverlay(contentPoint) : nullptr; });
}

const Control* ScrollPanel::FindOverlayChildAtContent(D2D1_POINT_2F contentPoint) const
{
    return const_cast<ScrollPanel*>(this)->FindOverlayChildAtContent(contentPoint);
}

void ScrollPanel::UpdateInnerHover(ControlHost& host, D2D1_POINT_2F viewportPoint)
{
    const std::weak_ptr<int> selfLifetime = GetLifetimeToken();
    const D2D1_RECT_F viewport            = GetViewportRect();
    Control* newHovered                   = nullptr;
    std::weak_ptr<int> newHoveredLifetime;
    if (PointInRect(viewport, viewportPoint))
    {
        const D2D1_POINT_2F contentPoint = ToContentSpace(viewportPoint);
        newHovered                       = FindChildAtContent(contentPoint);
        if (selfLifetime.expired())
        {
            return;
        }
        if (newHovered)
        {
            newHoveredLifetime = newHovered->GetLifetimeToken();
        }
    }

    if (_innerHoveredChild != newHovered)
    {
        if (_innerHoveredChild)
        {
            Control* const oldHovered                   = _innerHoveredChild;
            const std::weak_ptr<int> oldHoveredLifetime = oldHovered->GetLifetimeToken();
            oldHovered->OnHoverChanged(host, false);
            if (selfLifetime.expired())
            {
                return;
            }
            _innerHoveredChild = RevalidateScrollPanelChild(oldHoveredLifetime, this, oldHovered);
        }
        _innerHoveredChild = RevalidateScrollPanelChild(newHoveredLifetime, this, newHovered);
        if (_innerHoveredChild)
        {
            Control* const entered                   = _innerHoveredChild;
            const std::weak_ptr<int> enteredLifetime = entered->GetLifetimeToken();
            entered->OnHoverChanged(host, true);
            if (selfLifetime.expired())
            {
                return;
            }
            _innerHoveredChild = RevalidateScrollPanelChild(enteredLifetime, this, entered);
        }
    }
}

void ScrollPanel::Paint(ControlHost& host) const
{
    if (! IsVisible())
    {
        return;
    }

    auto* dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    const auto ownerLifetime   = GetLifetimeToken();
    const D2D1_RECT_F viewport = GetViewportRect();

    // Clip to viewport
    dc->PushAxisAlignedClip(viewport, D2D1_ANTIALIAS_MODE_PER_PRIMITIVE);

    // Apply scroll transform
    D2D1_MATRIX_3X2_F oldTransform;
    dc->GetTransform(&oldTransform);
    auto scrollTransform = oldTransform;
    scrollTransform._32 -= _scrollOffsetDip;
    dc->SetTransform(scrollTransform);
    auto restoreDrawingState = wil::scope_exit([dc, oldTransform]
    {
        dc->SetTransform(oldTransform);
        dc->PopAxisAlignedClip();
    });

    // Paint children in content space
    Panel::Paint(host);

    // Restore
    dc->SetTransform(oldTransform);
    dc->PopAxisAlignedClip();
    restoreDrawingState.release();
    if (ownerLifetime.expired())
        return;

    // Paint scrollbar
    if (UsesInternalScrollbar())
    {
        const D2D1_RECT_F track = GetScrollbarTrackRect();
        const D2D1_RECT_F thumb = GetScrollbarThumbRect();
        const auto visuals = ResolveScrollbarVisuals(host.GetTheme(), _scrollbarHotPart == HotPart::Track, _scrollbarHotPart == HotPart::Thumb, _dragThumb);
        PaintScrollbar(host, track, thumb, visuals);
    }
}

void ScrollPanel::PaintOverlay(ControlHost& host) const
{
    if (! IsVisible())
    {
        return;
    }

    auto* dc = host.GetDeviceContext();
    if (! dc)
    {
        return;
    }

    D2D1_MATRIX_3X2_F oldTransform;
    dc->GetTransform(&oldTransform);
    auto scrollTransform = oldTransform;
    scrollTransform._32 -= _scrollOffsetDip;
    dc->SetTransform(scrollTransform);
    const auto restoreDrawingState = wil::scope_exit([dc, oldTransform] { dc->SetTransform(oldTransform); });

    Panel::PaintOverlay(host);
}

Control* ScrollPanel::HitTest(D2D1_POINT_2F point)
{
    if (! IsVisible() || ! IsEnabled())
    {
        return nullptr;
    }
    const D2D1_RECT_F bounds = GetBounds();
    if (! PointInRect(bounds, point))
    {
        return nullptr;
    }
    // ScrollPanel intercepts all events (returns this, not children)
    // to manage coordinate translation between viewport and content space.
    return this;
}

const Control* ScrollPanel::HitTest(D2D1_POINT_2F point) const
{
    return const_cast<ScrollPanel*>(this)->HitTest(point);
}

Control* ScrollPanel::HitTestOverlay(D2D1_POINT_2F point)
{
    if (! IsVisible() || ! IsEnabled())
    {
        return nullptr;
    }

    const std::weak_ptr<int> selfLifetime = GetLifetimeToken();
    const Control* const hit              = FindOverlayChildAtContent(ToContentSpace(point));
    return ! selfLifetime.expired() && hit ? this : nullptr;
}

const Control* ScrollPanel::HitTestOverlay(D2D1_POINT_2F point) const
{
    return const_cast<ScrollPanel*>(this)->HitTestOverlay(point);
}

bool ScrollPanel::DismissOverlayOnPointerDown(ControlHost& host, D2D1_POINT_2F point)
{
    return Control::DismissOverlayOnPointerDown(host, ToContentSpace(point));
}

bool ScrollPanel::OnMouseDown(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers)
{
    if (rightButton)
    {
        return false;
    }

    const D2D1_POINT_2F contentPoint       = ToContentSpace(point);
    const std::weak_ptr<int> queryLifetime = GetLifetimeToken();
    Control* overlayChild                  = FindOverlayChildAtContent(contentPoint);
    if (queryLifetime.expired())
    {
        return false;
    }
    if (overlayChild)
    {
        const std::weak_ptr<int> selfLifetime  = GetLifetimeToken();
        const std::weak_ptr<int> childLifetime = overlayChild->GetLifetimeToken();
        const bool childHandled                = overlayChild->OnMouseDown(host, contentPoint, rightButton, modifiers);
        if (selfLifetime.expired())
        {
            return childHandled;
        }
        if (childHandled)
        {
            if (Control* const liveChild = RevalidateScrollPanelChild(childLifetime, this, overlayChild))
            {
                _innerCapturedChild = liveChild;
                host.CaptureMouse(this);
            }
            return true;
        }
        return false;
    }

    // Scrollbar interaction
    if (UsesInternalScrollbar())
    {
        const D2D1_RECT_F track = GetScrollbarTrackRect();
        if (PointInRect(track, point))
        {
            const D2D1_RECT_F thumb = GetScrollbarThumbHitRect();
            if (PointInRect(thumb, point))
            {
                _dragThumb          = true;
                _dragThumbOffsetDip = point.y - thumb.top;
                _scrollbarHotPart   = HotPart::Thumb;
                host.CaptureMouse(this);
            }
            else
            {
                const D2D1_RECT_F bounds   = GetBounds();
                const float viewportDip    = std::max(1.0f, bounds.bottom - bounds.top);
                const float pageStep       = ComputeScrollbarPageStepDip(track, ScrollbarOrientation::Vertical, viewportDip, _contentHeightDip);
                const float previousOffset = _scrollOffsetDip;
                _scrollOffsetDip += (point.y < thumb.top) ? -pageStep : pageStep;
                ClampScrollOffset();
                _scrollbarHotPart = HotPart::Track;
                if (! NotifyScrollChanged(previousOffset))
                {
                    return true;
                }
            }
            RequestInvalidate();
            return true;
        }
    }

    // Dispatch to child in content space
    const D2D1_RECT_F viewport = GetViewportRect();
    if (PointInRect(viewport, point))
    {
        Control* child = FindChildAtContent(contentPoint);
        if (queryLifetime.expired())
        {
            return false;
        }
        if (child)
        {
            const std::weak_ptr<int> selfLifetime  = GetLifetimeToken();
            const std::weak_ptr<int> childLifetime = child->GetLifetimeToken();
            const bool childHandled                = child->OnMouseDown(host, contentPoint, rightButton, modifiers);
            if (selfLifetime.expired())
            {
                return childHandled;
            }
            if (childHandled)
            {
                if (Control* const liveChild = RevalidateScrollPanelChild(childLifetime, this, child))
                {
                    _innerCapturedChild = liveChild;
                    host.CaptureMouse(this);
                }
                return true;
            }
        }
    }

    return false;
}

bool ScrollPanel::OnMouseDoubleClick(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers)
{
    if (rightButton)
    {
        return false;
    }

    const D2D1_RECT_F viewport = GetViewportRect();
    if (PointInRect(viewport, point))
    {
        const D2D1_POINT_2F contentPoint      = ToContentSpace(point);
        const std::weak_ptr<int> selfLifetime = GetLifetimeToken();
        Control* overlayChild                 = FindOverlayChildAtContent(contentPoint);
        if (selfLifetime.expired())
        {
            return false;
        }
        if (overlayChild)
        {
            return overlayChild->OnMouseDoubleClick(host, contentPoint, rightButton, modifiers);
        }
        Control* child = FindChildAtContent(contentPoint);
        if (selfLifetime.expired())
        {
            return false;
        }
        if (child)
        {
            return child->OnMouseDoubleClick(host, contentPoint, rightButton, modifiers);
        }
    }

    return false;
}

bool ScrollPanel::OnMouseMove(ControlHost& host, D2D1_POINT_2F point, UINT modifiers)
{
    if (_innerCapturedChild)
    {
        Control* const capturedChild           = _innerCapturedChild;
        const std::weak_ptr<int> selfLifetime  = GetLifetimeToken();
        const std::weak_ptr<int> childLifetime = capturedChild->GetLifetimeToken();
        capturedChild->OnMouseMove(host, ToContentSpace(point), modifiers);
        if (selfLifetime.expired())
        {
            return true;
        }
        _innerCapturedChild = RevalidateScrollPanelChild(childLifetime, this, capturedChild);
        return true;
    }

    if (_dragThumb)
    {
        const D2D1_RECT_F track = GetScrollbarTrackRect();
        const D2D1_RECT_F thumb = GetScrollbarThumbHitRect();
        const float thumbHeight = thumb.bottom - thumb.top;
        const float available   = (std::max)(0.0f, (track.bottom - track.top) - thumbHeight);
        if (available > 0.0f)
        {
            const float previousOffset = _scrollOffsetDip;
            const float thumbTop       = (std::clamp)(point.y - _dragThumbOffsetDip, track.top, track.bottom - thumbHeight);
            _scrollOffsetDip           = ((thumbTop - track.top) / available) * GetScrollableExtent();
            ClampScrollOffset();
            if (! NotifyScrollChanged(previousOffset))
            {
                return true;
            }
        }
        RequestInvalidate();
        return true;
    }

    const D2D1_POINT_2F contentPoint       = ToContentSpace(point);
    const std::weak_ptr<int> queryLifetime = GetLifetimeToken();
    Control* overlayChild                  = FindOverlayChildAtContent(contentPoint);
    if (queryLifetime.expired())
    {
        return true;
    }
    if (overlayChild)
    {
        const std::weak_ptr<int> selfLifetime = GetLifetimeToken();
        std::weak_ptr<int> overlayLifetime    = overlayChild->GetLifetimeToken();
        if (_innerHoveredChild != overlayChild)
        {
            if (_innerHoveredChild)
            {
                Control* const oldHovered                   = _innerHoveredChild;
                const std::weak_ptr<int> oldHoveredLifetime = oldHovered->GetLifetimeToken();
                oldHovered->OnHoverChanged(host, false);
                if (selfLifetime.expired())
                {
                    return true;
                }
                _innerHoveredChild = RevalidateScrollPanelChild(oldHoveredLifetime, this, oldHovered);
            }
            overlayChild       = RevalidateScrollPanelChild(overlayLifetime, this, overlayChild);
            _innerHoveredChild = overlayChild;
            if (_innerHoveredChild)
            {
                Control* const entered                   = _innerHoveredChild;
                const std::weak_ptr<int> enteredLifetime = entered->GetLifetimeToken();
                entered->OnHoverChanged(host, true);
                if (selfLifetime.expired())
                {
                    return true;
                }
                _innerHoveredChild = RevalidateScrollPanelChild(enteredLifetime, this, entered);
                overlayChild       = _innerHoveredChild;
            }
        }
        if (overlayChild)
        {
            overlayLifetime = overlayChild->GetLifetimeToken();
            overlayChild->OnMouseMove(host, contentPoint, modifiers);
            if (selfLifetime.expired())
            {
                return true;
            }
            _innerHoveredChild = RevalidateScrollPanelChild(overlayLifetime, this, overlayChild);
        }
        return true;
    }

    // Update scrollbar hover
    if (UsesInternalScrollbar())
    {
        const D2D1_RECT_F track = GetScrollbarTrackRect();
        HotPart newHot          = HotPart::None;
        if (PointInRect(track, point))
        {
            const D2D1_RECT_F thumb = GetScrollbarThumbHitRect();
            newHot                  = PointInRect(thumb, point) ? HotPart::Thumb : HotPart::Track;
        }
        if (_scrollbarHotPart != newHot)
        {
            _scrollbarHotPart = newHot;
            RequestInvalidate();
        }
    }

    // Inner child hover
    const std::weak_ptr<int> selfLifetime = GetLifetimeToken();
    UpdateInnerHover(host, point);
    if (selfLifetime.expired())
    {
        return true;
    }

    // Dispatch move to inner hovered child
    if (_innerHoveredChild)
    {
        Control* const hoveredChild            = _innerHoveredChild;
        const std::weak_ptr<int> childLifetime = hoveredChild->GetLifetimeToken();
        hoveredChild->OnMouseMove(host, contentPoint, modifiers);
        if (selfLifetime.expired())
        {
            return true;
        }
        _innerHoveredChild = RevalidateScrollPanelChild(childLifetime, this, hoveredChild);
    }

    return true;
}

bool ScrollPanel::OnMouseUp(ControlHost& host, D2D1_POINT_2F point, bool rightButton, UINT modifiers)
{
    if (_innerCapturedChild)
    {
        Control* const capturedChild          = _innerCapturedChild;
        const std::weak_ptr<int> selfLifetime = GetLifetimeToken();
        _innerCapturedChild                   = nullptr;
        const bool handled                    = capturedChild->OnMouseUp(host, ToContentSpace(point), rightButton, modifiers);
        if (selfLifetime.expired())
        {
            return handled;
        }
        UpdateInnerHover(host, point);
        return handled;
    }

    if (_dragThumb)
    {
        _dragThumb = false;
        host.ReleaseMouseCapture();

        // Update scrollbar hover after drag
        const D2D1_RECT_F track = GetScrollbarTrackRect();
        if (PointInRect(track, point))
        {
            const D2D1_RECT_F thumb = GetScrollbarThumbHitRect();
            _scrollbarHotPart       = PointInRect(thumb, point) ? HotPart::Thumb : HotPart::Track;
        }
        else
        {
            _scrollbarHotPart = HotPart::None;
        }
        RequestInvalidate();
        return true;
    }

    const D2D1_POINT_2F contentPoint       = ToContentSpace(point);
    const std::weak_ptr<int> queryLifetime = GetLifetimeToken();
    Control* overlayChild                  = FindOverlayChildAtContent(contentPoint);
    if (queryLifetime.expired())
    {
        return false;
    }
    if (overlayChild)
    {
        return overlayChild->OnMouseUp(host, contentPoint, rightButton, modifiers);
    }

    // Dispatch to child
    const D2D1_RECT_F viewport = GetViewportRect();
    if (PointInRect(viewport, point))
    {
        Control* child = FindChildAtContent(contentPoint);
        if (queryLifetime.expired())
        {
            return false;
        }
        if (child)
        {
            return child->OnMouseUp(host, contentPoint, rightButton, modifiers);
        }
    }

    return false;
}

bool ScrollPanel::OnMouseWheel(ControlHost& host, D2D1_POINT_2F point, float wheelDelta, UINT modifiers)
{
    const D2D1_POINT_2F contentPoint       = ToContentSpace(point);
    const std::weak_ptr<int> queryLifetime = GetLifetimeToken();
    Control* overlayChild                  = FindOverlayChildAtContent(contentPoint);
    if (queryLifetime.expired())
    {
        return false;
    }
    if (overlayChild)
    {
        const std::weak_ptr<int> selfLifetime = GetLifetimeToken();
        const bool childHandled               = overlayChild->OnMouseWheel(host, contentPoint, wheelDelta, modifiers);
        if (selfLifetime.expired())
        {
            return childHandled;
        }
        if (childHandled)
        {
            return true;
        }
    }

    const D2D1_RECT_F viewport = GetViewportRect();
    if (PointInRect(viewport, point))
    {
        Control* child = FindChildAtContent(contentPoint);
        if (queryLifetime.expired())
        {
            return false;
        }
        if (child)
        {
            const std::weak_ptr<int> selfLifetime = GetLifetimeToken();
            const bool childHandled               = child->OnMouseWheel(host, contentPoint, wheelDelta, modifiers);
            if (selfLifetime.expired())
            {
                return childHandled;
            }
            if (childHandled)
            {
                return true;
            }
        }
    }

    if (! _internalScrollbarEnabled)
    {
        return false;
    }

    if (GetScrollableExtent() <= 0.0f)
    {
        return false;
    }

    const float steps          = wheelDelta / static_cast<float>(WHEEL_DELTA);
    const float previousOffset = _scrollOffsetDip;
    _scrollOffsetDip -= steps * _scrollStepDip;
    ClampScrollOffset();
    RequestInvalidate();
    static_cast<void>(NotifyScrollChanged(previousOffset));
    return true;
}

bool ScrollPanel::OnMouseLeave(ControlHost& host)
{
    if (_innerCapturedChild)
    {
        return true;
    }

    if (_innerHoveredChild)
    {
        Control* const hoveredChild           = _innerHoveredChild;
        const std::weak_ptr<int> selfLifetime = GetLifetimeToken();
        hoveredChild->OnHoverChanged(host, false);
        if (selfLifetime.expired())
        {
            return true;
        }
        _innerHoveredChild = nullptr;
    }
    if (_scrollbarHotPart != HotPart::None)
    {
        _scrollbarHotPart = HotPart::None;
        RequestInvalidate();
    }
    return true;
}

void ScrollPanel::OnCaptureLost(ControlHost& host)
{
    const bool hadDrag = _dragThumb || _innerCapturedChild != nullptr;
    if (_innerCapturedChild)
    {
        Control* const capturedChild          = _innerCapturedChild;
        _innerCapturedChild                   = nullptr;
        const std::weak_ptr<int> selfLifetime = GetLifetimeToken();
        capturedChild->OnCaptureLost(host);
        if (selfLifetime.expired())
        {
            return;
        }
    }

    _dragThumb          = false;
    _dragThumbOffsetDip = 0.0f;
    _scrollbarHotPart   = HotPart::None;
    if (hadDrag)
    {
        Invalidate(host);
    }
}

bool TooltipLayer::SetTooltip(std::wstring text, const D2D1_POINT_2F& originDip)
{
    if (_inspecting)
    {
        return false;
    }
    const bool nextVisible = ! text.empty();
    if (_text == text && TooltipPointsMatch(_originDip, originDip) && IsVisible() == nextVisible && ! _hideScheduled)
    {
        return false;
    }

    _text      = std::move(text);
    _originDip = originDip;
    _pendingText.clear();
    _showScheduled = false;
    _showTickMs    = 0u;
    _hideScheduled = false;
    _hideTickMs    = 0u;
    InvalidateLayoutCache();
    SetVisible(nextVisible);
    return true;
}

bool TooltipLayer::Inspect(std::wstring text, const D2D1_POINT_2F& originDip)
{
    // Replacing an inspection starts at the first line, even for the same value.
    _inspecting = false;
    static_cast<void>(SetTooltip(std::move(text), originDip));
    _scrollOffsetDip    = 0.0f;
    _inspectionDragging = false;
    _inspecting         = HasTooltip();
    return _inspecting;
}

bool TooltipLayer::IsInspecting() const noexcept
{
    return _inspecting;
}

bool TooltipLayer::IsDismissGestureActive() const noexcept
{
    return _dismissGestureActive;
}

void TooltipLayer::ScrollInspection(ControlHost& host, float offsetDip) noexcept
{
    static_cast<void>(EnsureLayoutCache(host));
    const float viewportHeight = (std::max)(0.0f, _layoutCache.bounds.bottom - _layoutCache.bounds.top - 2.0f * kTooltipPaddingYDip);
    const float maximum        = (std::max)(0.0f, _layoutCache.textHeightDip - viewportHeight);
    _scrollOffsetDip           = std::clamp(offsetDip, 0.0f, maximum);
    host.Invalidate();
}

bool TooltipLayer::HandleInspectionKey(ControlHost& host, UINT virtualKey) noexcept
{
    if (! _inspecting)
        return false;
    static_cast<void>(EnsureLayoutCache(host));
    const float page = (std::max)(kTooltipFallbackLineHeightDip, _layoutCache.bounds.bottom - _layoutCache.bounds.top - 2.0f * kTooltipPaddingYDip);
    switch (virtualKey)
    {
        case VK_ESCAPE:
        case VK_F1:
            static_cast<void>(Clear());
            host.Invalidate();
            return true;
        case VK_UP: ScrollInspection(host, _scrollOffsetDip - kTooltipFallbackLineHeightDip); return true;
        case VK_DOWN: ScrollInspection(host, _scrollOffsetDip + kTooltipFallbackLineHeightDip); return true;
        case VK_PRIOR: ScrollInspection(host, _scrollOffsetDip - page); return true;
        case VK_NEXT: ScrollInspection(host, _scrollOffsetDip + page); return true;
        case VK_HOME: ScrollInspection(host, 0.0f); return true;
        case VK_END: ScrollInspection(host, (std::numeric_limits<float>::max)()); return true;
        default: return false;
    }
}

bool TooltipLayer::HandleInspectionPointer(ControlHost& host, UINT message, D2D1_POINT_2F point, float wheelDelta) noexcept
{
    if (_dismissGestureActive)
    {
        if (message == WM_MOUSEMOVE || message == WM_LBUTTONDOWN || message == WM_RBUTTONDOWN || message == WM_LBUTTONDBLCLK || message == WM_RBUTTONDBLCLK ||
            message == WM_MOUSEWHEEL)
        {
            return true;
        }
        if (message == _dismissGestureUpMessage)
        {
            _dismissGestureActive    = false;
            _dismissGestureUpMessage = 0u;
            return true;
        }
        if (message == WM_LBUTTONUP || message == WM_RBUTTONUP)
            return true;
        if (message == WM_CAPTURECHANGED || message == WM_CANCELMODE)
        {
            _dismissGestureActive    = false;
            _dismissGestureUpMessage = 0u;
            return true;
        }
        if (message == WM_MOUSELEAVE)
        {
            // The dismissal press owns capture until its matching release or cancellation. A leave
            // cannot complete the gesture because the eventual up must remain consumed here.
            return true;
        }
        return true;
    }
    if (! _inspecting)
        return false;
    const auto bounds = ComputeBoundsDip(host);
    if (message == WM_LBUTTONDOWN || message == WM_RBUTTONDOWN || message == WM_LBUTTONDBLCLK || message == WM_RBUTTONDBLCLK)
    {
        if (! PointInRect(bounds, point))
        {
            static_cast<void>(Clear());
            _dismissGestureActive    = true;
            _dismissGestureUpMessage = message == WM_RBUTTONDOWN || message == WM_RBUTTONDBLCLK ? WM_RBUTTONUP : WM_LBUTTONUP;
            host.Invalidate();
        }
        else
        {
            _inspectionDragging = message == WM_LBUTTONDOWN || message == WM_LBUTTONDBLCLK;
            _inspectionDragY    = point.y;
        }
    }
    else if (message == WM_MOUSEMOVE && _inspectionDragging)
    {
        ScrollInspection(host, _scrollOffsetDip + _inspectionDragY - point.y);
        _inspectionDragY = point.y;
    }
    else if (message == WM_LBUTTONUP || message == WM_RBUTTONUP || message == WM_CAPTURECHANGED || message == WM_CANCELMODE || message == WM_MOUSELEAVE)
        _inspectionDragging = false;
    else if (message == WM_MOUSEWHEEL)
        ScrollInspection(host, _scrollOffsetDip - wheelDelta / static_cast<float>(WHEEL_DELTA) * 3.0f * kTooltipFallbackLineHeightDip);
    // Keep hover/click dispatch away from the underlying cell while inspecting it.
    return true;
}

bool TooltipLayer::SetTooltipDelayed(std::wstring text, const D2D1_POINT_2F& originDip, uint64_t nowTickMs, uint64_t delayMs)
{
    if (_inspecting)
        return false;
    if (text.empty())
    {
        return Clear();
    }

    if (HasTooltip() && _text == text)
    {
        if (TooltipPointsMatch(_originDip, originDip))
        {
            return false;
        }
        _originDip = originDip;
        InvalidateLayoutCache();
        return true;
    }

    const uint64_t nextShowTickMs = delayMs > (std::numeric_limits<uint64_t>::max)() - nowTickMs ? (std::numeric_limits<uint64_t>::max)() : nowTickMs + delayMs;
    if (_showScheduled && _pendingText == text)
    {
        if (! TooltipPointsMatch(_pendingOriginDip, originDip))
        {
            _pendingOriginDip = originDip;
            return true;
        }
        return false;
    }

    _pendingText      = std::move(text);
    _pendingOriginDip = originDip;
    _showScheduled    = true;
    _showTickMs       = nextShowTickMs;
    _hideScheduled    = false;
    _hideTickMs       = 0u;

    bool changed = true;
    if (IsVisible() || ! _text.empty())
    {
        _text.clear();
        InvalidateLayoutCache();
        SetVisible(false);
    }

    return changed;
}

bool TooltipLayer::BeginHideDelay(uint64_t nowTickMs, uint64_t delayMs) noexcept
{
    if (_inspecting)
        return false;
    if (_showScheduled)
    {
        _pendingText.clear();
        _showScheduled = false;
        _showTickMs    = 0u;
        return true;
    }

    if (_text.empty() || ! IsVisible())
    {
        return false;
    }

    const uint64_t nextHideTickMs = nowTickMs + delayMs;
    if (_hideScheduled && _hideTickMs == nextHideTickMs)
    {
        return false;
    }

    _hideScheduled = true;
    _hideTickMs    = nextHideTickMs;
    return true;
}

bool TooltipLayer::CancelHideDelay() noexcept
{
    if (! _hideScheduled)
    {
        return false;
    }

    _hideScheduled = false;
    _hideTickMs    = 0u;
    return true;
}

bool TooltipLayer::Clear() noexcept
{
    _inspecting              = false;
    _inspectionDragging      = false;
    _dismissGestureActive    = false;
    _dismissGestureUpMessage = 0u;
    _scrollOffsetDip         = 0.0f;
    if (_text.empty() && _pendingText.empty() && ! IsVisible() && ! _showScheduled && ! _hideScheduled)
    {
        return false;
    }

    _text.clear();
    _pendingText.clear();
    InvalidateLayoutCache();
    SetVisible(false);
    _showScheduled = false;
    _showTickMs    = 0u;
    _hideScheduled = false;
    _hideTickMs    = 0u;
    return true;
}

bool TooltipLayer::HasTooltip() const noexcept
{
    return ! _text.empty() && IsVisible();
}

std::wstring_view TooltipLayer::GetTooltipText() const noexcept
{
    return _text;
}

#if DXUI_ENABLE_DIAGNOSTICS
std::wstring_view TooltipLayer::DebugGetPendingTooltipText() const noexcept
{
    return _showScheduled ? std::wstring_view{_pendingText} : std::wstring_view{};
}
#endif

bool TooltipLayer::Tick(ControlHost& host, uint64_t nowTickMs)
{
    if (_showScheduled)
    {
        if (nowTickMs < _showTickMs)
        {
            return true;
        }

        std::wstring text             = std::move(_pendingText);
        const D2D1_POINT_2F originDip = _pendingOriginDip;
        _pendingText.clear();
        _showScheduled                               = false;
        _showTickMs                                  = 0u;
        const bool changed                           = SetTooltip(std::move(text), originDip);
        constexpr uint64_t kTooltipDisplayDurationMs = 5000u;
        _hideScheduled                               = true;
        _hideTickMs = kTooltipDisplayDurationMs > (std::numeric_limits<uint64_t>::max)() - nowTickMs ? (std::numeric_limits<uint64_t>::max)()
                                                                                                     : nowTickMs + kTooltipDisplayDurationMs;
        if (changed)
        {
            Invalidate(host);
        }
        return changed;
    }

    if (! _hideScheduled)
    {
        return false;
    }

    if (nowTickMs < _hideTickMs)
    {
        return true;
    }

    _hideScheduled     = false;
    _hideTickMs        = 0u;
    const bool cleared = Clear();
    if (cleared)
    {
        Invalidate(host);
    }
    return cleared;
}

void TooltipLayer::OnHostDpiChanged(ControlHost& host) noexcept
{
    Control::OnHostDpiChanged(host);
    InvalidateLayoutCache();
}

void TooltipLayer::InvalidateLayoutCache() noexcept
{
    _layoutCache = {};
}

bool TooltipLayer::EnsureLayoutCache(const ControlHost& host) const noexcept
{
    const D2D1_RECT_F clientBounds    = host.GetClientBoundsDip();
    const FlowDirection flowDirection = host.GetRoot() ? host.GetRoot()->GetFlowDirection() : FlowDirection::LeftToRight;
    if (_text.empty() || clientBounds.right <= clientBounds.left || clientBounds.bottom <= clientBounds.top)
    {
        _layoutCache              = {};
        _layoutCache.bounds       = D2D1::RectF(_originDip.x, _originDip.y, _originDip.x, _originDip.y);
        _layoutCache.clientBounds = clientBounds;
        _layoutCache.valid        = true;
        return false;
    }

    if (_layoutCache.valid && TooltipRectsMatch(_layoutCache.clientBounds, clientBounds) && _layoutCache.flowDirection == flowDirection)
    {
        return static_cast<bool>(_layoutCache.layout);
    }

    // Keep both dimensions inside even a viewport smaller than the normal minimum size/margins.
    const float marginX           = (std::min)(kTooltipViewportMarginDip, (clientBounds.right - clientBounds.left) * 0.25f);
    const float marginY           = (std::min)(kTooltipViewportMarginDip, (clientBounds.bottom - clientBounds.top) * 0.25f);
    const float maxOuterWidthDip  = clientBounds.right - clientBounds.left - 2.0f * marginX;
    const float maxOuterHeightDip = clientBounds.bottom - clientBounds.top - 2.0f * marginY;
    const float maxInnerWidthDip  = (std::max)(1.0f, (std::min)(kTooltipMaxWidthDip, maxOuterWidthDip) - (kTooltipPaddingXDip * 2.0f));

    _layoutCache               = {};
    _layoutCache.clientBounds  = clientBounds;
    _layoutCache.flowDirection = flowDirection;
    _layoutCache.layout        = CreateTooltipTextLayout(host, _text, maxInnerWidthDip, kTooltipPreferredTextHeightDip, ResolveReadingDirection(flowDirection));

    D2D1_SIZE_F textSizeDip = D2D1::SizeF(0.0f, 0.0f);
    if (_layoutCache.layout)
    {
        DWRITE_TEXT_METRICS metrics{};
        if (SUCCEEDED(_layoutCache.layout->GetMetrics(&metrics)))
        {
            textSizeDip = D2D1::SizeF(metrics.widthIncludingTrailingWhitespace, metrics.height);
        }
    }

    if (textSizeDip.width <= 0.0f || textSizeDip.height <= 0.0f)
    {
        const float fallbackWidthDip = (std::min)(maxInnerWidthDip, static_cast<float>(_text.size()) * 7.0f);
        textSizeDip                  = D2D1::SizeF(fallbackWidthDip, kTooltipFallbackLineHeightDip);
    }

    const float widthDip =
        (std::min)((std::min)(kTooltipMaxWidthDip, maxOuterWidthDip), (std::max)(kTooltipMinWidthDip, textSizeDip.width + (kTooltipPaddingXDip * 2.0f)));
    const float heightDip      = (std::min)(maxOuterHeightDip, (std::max)(kTooltipMinHeightDip, textSizeDip.height + (kTooltipPaddingYDip * 2.0f)));
    _layoutCache.textHeightDip = textSizeDip.height;
    _scrollOffsetDip = std::clamp(_scrollOffsetDip, 0.0f, (std::max)(0.0f, textSizeDip.height - (std::max)(0.0f, heightDip - 2.0f * kTooltipPaddingYDip)));

    float left = flowDirection == FlowDirection::RightToLeft ? _originDip.x - kTooltipOffsetXDip - widthDip : _originDip.x + kTooltipOffsetXDip;
    float top  = _originDip.y + kTooltipOffsetYDip;
    if (flowDirection == FlowDirection::LeftToRight && (left + widthDip) > (clientBounds.right - marginX))
    {
        left = _originDip.x - kTooltipOffsetXDip - widthDip;
    }
    else if (flowDirection == FlowDirection::RightToLeft && left < (clientBounds.left + marginX))
    {
        left = _originDip.x + kTooltipOffsetXDip;
    }
    if ((top + heightDip) > (clientBounds.bottom - kTooltipViewportMarginDip))
    {
        top = _originDip.y - kTooltipOffsetYDip - heightDip;
    }

    const float minLeft = clientBounds.left + marginX;
    const float maxLeft = (std::max)(minLeft, clientBounds.right - marginX - widthDip);
    const float minTop  = clientBounds.top + marginY;
    const float maxTop  = (std::max)(minTop, clientBounds.bottom - marginY - heightDip);
    left                = std::clamp(left, minLeft, maxLeft);
    top                 = std::clamp(top, minTop, maxTop);

    _layoutCache.bounds = D2D1::RectF(left, top, left + widthDip, top + heightDip);
    _layoutCache.valid  = true;
    return static_cast<bool>(_layoutCache.layout);
}

D2D1_RECT_F TooltipLayer::ComputeBoundsDip(const ControlHost& host) const noexcept
{
    static_cast<void>(EnsureLayoutCache(host));
    return _layoutCache.bounds;
}

#if DXUI_ENABLE_DIAGNOSTICS
D2D1_RECT_F TooltipLayer::DebugGetBoundsDip(const ControlHost& host) const noexcept
{
    return ComputeBoundsDip(host);
}

bool TooltipLayer::DebugIsInspectionFinalGlyphVisible(const ControlHost& host) const noexcept
{
    if (! _inspecting || _text.empty() || ! EnsureLayoutCache(host) || ! _layoutCache.layout || _text.size() > (std::numeric_limits<UINT32>::max)())
    {
        return false;
    }

    FLOAT trailingX = 0.0f;
    FLOAT trailingY = 0.0f;
    DWRITE_HIT_TEST_METRICS lastCluster{};
    if (FAILED(_layoutCache.layout->HitTestTextPosition(static_cast<UINT32>(_text.size() - 1u), TRUE, &trailingX, &trailingY, &lastCluster)))
    {
        return false;
    }
    static_cast<void>(trailingX);
    static_cast<void>(trailingY);

    const D2D1_RECT_F bounds       = _layoutCache.bounds;
    const float paddingY           = (std::min)(kTooltipPaddingYDip, (bounds.bottom - bounds.top) * 0.25f);
    const float textViewportTop    = bounds.top + paddingY;
    const float textViewportBottom = bounds.bottom - paddingY;
    const float finalGlyphTop      = textViewportTop - _scrollOffsetDip + lastCluster.top;
    const float finalGlyphBottom   = finalGlyphTop + lastCluster.height;
    return finalGlyphTop >= textViewportTop && finalGlyphBottom <= textViewportBottom;
}
#endif

void TooltipLayer::Paint(ControlHost& host) const
{
    if (_text.empty())
    {
        return;
    }

    const D2D1_RECT_F bounds       = ComputeBoundsDip(host);
    const TooltipVisualStyle style = ResolveTooltipVisualStyle(host.GetTheme());
    DrawRoundedRect(host, bounds, style.fill, style.border, kTooltipCornerRadiusDip);

    const float paddingX       = (std::min)(kTooltipPaddingXDip, (bounds.right - bounds.left) * 0.25f);
    const float paddingY       = (std::min)(kTooltipPaddingYDip, (bounds.bottom - bounds.top) * 0.25f);
    const D2D1_RECT_F textRect = D2D1::RectF(bounds.left + paddingX, bounds.top + paddingY, bounds.right - paddingX, bounds.bottom - paddingY);
    auto* dc                   = host.GetDeviceContext();
    auto* brush                = host.GetSolidBrush(style.text);
    if (dc && brush)
    {
        if (EnsureLayoutCache(host) && _layoutCache.layout)
        {
            dc->PushAxisAlignedClip(textRect, D2D1_ANTIALIAS_MODE_ALIASED);
            // Clip to the viewport rather than the layout's measurement height: inspection must reach every line.
            dc->DrawTextLayout(
                D2D1::Point2F(textRect.left, textRect.top - _scrollOffsetDip), _layoutCache.layout.get(), brush, D2D1_DRAW_TEXT_OPTIONS_ENABLE_COLOR_FONT);
            dc->PopAxisAlignedClip();
            return;
        }
    }

    DrawCenteredText(host, _text, textRect, FontRole::Small, style.text, DWRITE_TEXT_ALIGNMENT_LEADING, DWRITE_PARAGRAPH_ALIGNMENT_NEAR, true);
}
} // namespace DxUi
