[CmdletBinding()] param(
    [Parameter(Mandatory)][string] $ArtifactRoot,
    [Parameter(Mandatory)][string] $ExpectedCommit,
    [Parameter(Mandatory)][string] $BaselineCommit,
    [Parameter(Mandatory)][string] $OutputPath
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$cases=[Collections.Generic.List[object]]::new()
$files=@(Get-ChildItem -LiteralPath $ArtifactRoot -Recurse -File -Filter '*.json' | Where-Object { $_.Name -match '-[AB]\d{2}\.json$' })
if ($files.Count -eq 0) { throw 'No raw performance reports' }
foreach ($file in $files) {
    $receipt=Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json -AsHashtable
    $isBaseline=$file.Name -match '-A\d{2}\.json$'; $roleCommit=if ($isBaseline) {$BaselineCommit} else {$ExpectedCommit}; if ($receipt.sourceCommit -cne $roleCommit -or (-not [bool]$receipt.sourceDirty) -or $receipt.identityStatus -cne 'verifiable' -or $receipt.identityScope -cne 'full') { throw "Unbound raw receipt: $($file.Name)" }
    foreach ($key in @('harnessIdentity','toolchainIdentity','dependencyIdentity','environmentIdentity','sourceFingerprint','executableSha256','benchmarkSha256')) {
        if ($receipt[$key] -notmatch '^[A-Fa-f0-9]{64}$') { throw "Missing $key" }
    }
    $clock=$receipt.clock
    $frequency=[double]$clock.ticksPerSecond
    if ($clock.name -cne 'std::chrono::steady_clock' -or $clock.implementation -cne 'QueryPerformanceCounter' -or -not [double]::IsFinite($frequency) -or $frequency -le 0 -or [Math]::Truncate($frequency) -ne $frequency -or [bigint]$frequency -gt [bigint][long]::MaxValue -or $clock.nominalPeriodNanoseconds -ne 1 -or [Math]::Abs([double]$clock.tickNanoseconds-1e9/$frequency) -gt 1e-8) { throw "Invalid recorded clock: $($file.Name)" }
    $roundResults=[Collections.Generic.List[object]]::new()
    foreach ($scenario in $receipt.scenarios) {
        if ($scenario.name -notin @('clean','dirty') -or $scenario.rounds.Count -ne 5) { throw 'Incomplete raw scenarios' }
        foreach ($round in $scenario.rounds) {
            $sorted=@{}; $total=0.0
            foreach ($key in @('frame','prepare','composeCpu')) {
                $values=[double[]]@($round.timingSamplesMs[$key])
                if ($values.Length -ne 40) { throw 'Incomplete ordered samples' }
                foreach ($value in $values) {
                    if (-not [double]::IsFinite($value) -or $value -lt 0 -or ($key -ceq 'frame' -and $value -le 0)) { throw 'Invalid timing sample' }
                    if ($key -ceq 'frame') { $total+=$value }
                }
                [Array]::Sort($values); $sorted[$key]=$values
            }
            if (-not [double]::IsFinite($total) -or $total -le 0) { throw 'Invalid aggregate' }
            $expected=@{fps=40000.0/$total;frameP50Ms=$sorted.frame[19];frameP95Ms=$sorted.frame[37];prepareP95Ms=$sorted.prepare[37];composeCpuP95Ms=$sorted.composeCpu[37]}
            foreach ($key in $expected.Keys) {
                if ([Math]::Abs([double]$round[$key]-$expected[$key]) -gt 1e-8*[Math]::Max(1e-9,[Math]::Abs($expected[$key]))) { throw "Raw samples do not reproduce $key" }
            }
            if ($round.composeAllocations -ne 0 -or ($scenario.name -ceq 'clean' -and $round.cppAllocations -ne 0)) { throw 'Allocation budget failed' }
            $roundResults.Add([ordered]@{phase=$scenario.name;fps=$expected.fps;frameP50Ms=$expected.frameP50Ms;frameP95Ms=$expected.frameP95Ms;prepareP95Ms=$expected.prepareP95Ms;composeCpuP95Ms=$expected.composeCpuP95Ms;prepareP95CounterTicks=1e6*$expected.prepareP95Ms/[double]$clock.tickNanoseconds;fivePercentPrepareBandNanoseconds=0.05*1e6*$expected.prepareP95Ms})
        }
    }
    if ($receipt.scenarios.Count -ne 2 -or (@($receipt.scenarios.name | Sort-Object -Unique)).Count -ne 2 -or $receipt.hiddenPreparations -ne 0 -or $receipt.hiddenComposites -ne 0) { throw 'Scenario/hidden budget failed' }
    $cases.Add([ordered]@{sourceCommit=$receipt.sourceCommit;sourceDirty=$receipt.sourceDirty;relativePath=[IO.Path]::GetRelativePath([IO.Path]::GetFullPath($ArtifactRoot),$file.FullName);sha256=(Get-FileHash -LiteralPath $file.FullName).Hash;platform=$receipt.platform;nativeArchitecture=$receipt.nativeArchitecture;configuration=$receipt.configuration;recordedExecutableSha256=$receipt.executableSha256;clock=$clock;rounds=$roundResults.ToArray()})
}
[ordered]@{sourceCommit=$ExpectedCommit;reports=$cases.ToArray();rawTimingSamples=$cases.Count*1200;timingFieldsIndependentlyReproduced=$cases.Count*50;limitations='Recorded CI clock/provenance and raw samples are checked independently. CI binary bytes and a live remote frequency query are absent. Unpaired receipts and sub-tick investigation bands establish no paired performance verdict.'} | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $OutputPath -Encoding utf8
Write-Host "HOSTED_RAW_TIMING_AUDIT_PASS reports=$($cases.Count) samples=$($cases.Count*1200) reproducedFields=$($cases.Count*50)"

