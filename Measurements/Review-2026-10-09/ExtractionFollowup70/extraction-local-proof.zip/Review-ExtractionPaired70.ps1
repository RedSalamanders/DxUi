# Independent receipt-to-verdict audit. Does not import a production comparator or randomization helper.
[CmdletBinding()] param([Parameter(Mandatory)][string] $SummaryPath, [Parameter(Mandatory)][string] $OutputPath)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$summary=Get-Content -LiteralPath $SummaryPath -Raw | ConvertFrom-Json -AsHashtable
if ($summary.studyVersion -ne 3 -or $summary.allocation -cne 'independent-ABBA-BAAB-v1' -or $summary.blocks -ne 12) { throw 'Expected the frozen twelve-block independent protocol' }
$directory=Split-Path -Parent $SummaryPath
$metricNames=@('fps','frameP50Ms','frameP95Ms','prepareP95Ms','composeCpuP95Ms','privateBytes','privatePeakBytes','workingSetBytes','workingSetPeakBytes','surfaceBytes','replacementPeakBytes','cppAllocations','composeAllocations')
$exactNames=@('surfaceBytes','replacementPeakBytes','cppAllocations','composeAllocations')
function Median([double[]] $Values) {
    if (-not $Values.Count) { throw 'Empty median' }
    $sorted=@($Values | Sort-Object); $middle=[int][Math]::Floor($sorted.Count/2.0)
    if ($sorted.Count % 2) { return [double]$sorted[$middle] }
    return ([double]$sorted[$middle-1]+[double]$sorted[$middle])/2.0
}
function Assert-Near([double] $Actual,[double] $Recorded,[string] $Label) {
    if (-not [double]::IsFinite($Actual) -or -not [double]::IsFinite($Recorded) -or [Math]::Abs($Actual-$Recorded) -gt 1e-9*[Math]::Max(1.0,[Math]::Abs($Actual))) { throw "Independent value mismatch: $Label actual=$Actual recorded=$Recorded" }
}
function Exact-AssignmentProbability([double[]] $Effects) {
    # Enumerate by recursively expanding a vector of partial sums, rather than the production bit-mask loop.
    $sums=[double[]]@(0.0)
    foreach ($effect in $Effects) {
        $next=[double[]]::new(2*$sums.Length)
        for ($i=0;$i -lt $sums.Length;$i++) { $next[2*$i]=$sums[$i]+$effect; $next[2*$i+1]=$sums[$i]-$effect }
        $sums=$next
    }
    $observed=[Math]::Abs(($Effects | Measure-Object -Sum).Sum/$Effects.Count); $extreme=0
    foreach ($value in $sums) { if ([Math]::Abs($value/$Effects.Count) -ge $observed-1e-12) { $extreme++ } }
    return [double]$extreme/$sums.Length
}
$random=[Random]::new([int]$summary.seed); $aRun=0;$bRun=0;$position=0
for ($index=0;$index -lt 12;$index++) {
    $order=if ($random.Next(2) -eq 0) {'ABBA'} else {'BAAB'}
    $block=$summary.blockSchedule[$index]
    if ($block.Order -cne $order -or $block.Name -cne ('block-{0:D2}' -f ($index+1))) { throw 'Schedule does not replay its retained independent seed' }
    $expectedA=[Collections.Generic.List[string]]::new();$expectedB=[Collections.Generic.List[string]]::new()
    foreach ($letter in $order.ToCharArray()) {
        $number=if ($letter -ceq 'A') {$aRun++;$aRun} else {$bRun++;$bRun};$step=$summary.steps[$position++]
        $name='{0}{1:D2}' -f $letter,$number;$side=if ($letter -ceq 'A') {'baseline'} else {'candidate'}
        if ($letter -ceq 'A') {$expectedA.Add($name)} else {$expectedB.Add($name)}
        if ($step.Name -cne $name -or $step.Side -cne $side -or $step.Position -ne $position -or $step.Order -cne $order -or $step.Block -cne $block.Name) { throw 'Step identity differs from independently replayed schedule' }
    }
    if (($block.BaselineRuns -join ',') -cne ($expectedA -join ',') -or ($block.CandidateRuns -join ',') -cne ($expectedB -join ',')) { throw 'Block roles differ from independent assignment replay' }
}
if ($summary.steps.Count -ne 48 -or ($summary.steps.Name -join ', ') -cne $summary.order) { throw 'Incomplete literal schedule' }
$results=@(foreach ($scenario in $summary.scenarios) {
    $reports=@{};$identityRows=[Collections.Generic.List[object]]::new();$roundCount=0
    foreach ($attestation in $scenario.judgeComparison.sameReceiptsSha256) {
        $path=Join-Path $directory "$($scenario.scenario)-$($attestation.run).json"
        if ((Get-FileHash -LiteralPath $path).Hash -cne $attestation.sha256) { throw 'Raw report bytes differ from retained judge input' }
        $report=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json -AsHashtable
        if ($report.identityStatus -cne 'verifiable' -or $report.identityScope -cne 'full' -or $report.platform -cne 'x64' -or $report.configuration -cne 'Debug' -or $report.nativeArchitecture -cne 'X64' -or $report.renderer -cne 'WARP' -or $report.hiddenPreparations -ne 0 -or $report.hiddenComposites -ne 0) { throw 'Invalid platform/identity/hidden-work record' }
        if ($reports.ContainsKey($attestation.run)) { throw 'Duplicate report name' };$reports[$attestation.run]=$report;$identityRows.Add($report)
        foreach ($phase in $report.scenarios) { if ($phase.rounds.Count -ne 5) { throw 'Missing raw rounds' };$roundCount+=$phase.rounds.Count; foreach ($round in $phase.rounds) { if ($round.composeAllocations -ne 0 -or ($phase.name -ceq 'clean' -and $round.cppAllocations -ne 0)) { throw 'Composition/clean allocation violation' } } }
    }
    if ($reports.Count -ne 48) { throw 'Expected 48 raw receipts per scenario' }
    foreach ($key in @('fixture','width','height','dpi','controls','modelRows','framesPerRound','roundCount','machine','cpu','os','compiler','warpVersion','warpSha256','powerPolicy','harnessIdentity','toolchainIdentity','dependencyIdentity','environmentIdentity','benchmarkSha256')) {
        $values=@($identityRows | ForEach-Object { [string]$_[$key] } | Select-Object -Unique)
        if ($values.Count -ne 1 -or [string]::IsNullOrWhiteSpace($values[0])) { throw "Incomplete or unequal identity: $key" }
    }
    foreach ($prefix in @('A','B')) {
        foreach ($key in @('sourceCommit','sourceFingerprint','executableSha256')) { if (@($reports.Keys | Where-Object { $_.StartsWith($prefix) } | ForEach-Object {$reports[$_][$key]} | Select-Object -Unique).Count -ne 1) { throw 'Within-role source/executable identity changed' } }
        $side=if ($prefix -ceq 'A') {'baseline'} else {'candidate'}
        if ($reports[$prefix+'01'].sourceCommit -cne $summary[$side].commit -or $reports[$prefix+'01'].sourceFingerprint -cne $summary[$side].sourceFingerprint) { throw 'Report source differs from declared measured role' }
    }
    if ($summary.studyPurpose -ceq 'aa-calibration') { foreach ($key in @('sourceCommit','sourceFingerprint','executableSha256')) { if (@($identityRows | ForEach-Object {$_[$key]} | Select-Object -Unique).Count -ne 1) { throw 'A/A labels did not share exact source/executable' } } }
    $checked=[Collections.Generic.List[object]]::new()
    foreach ($phase in @('clean','dirty')) { foreach ($name in $metricNames) {
        $exact=$name -cin $exactNames; $higher=$name -ceq 'fps'; $band=if ($exact) {0.0} elseif ($name -like '*Bytes') {0.02} else {0.05}
        $aMedians=[Collections.Generic.List[double]]::new();$bMedians=[Collections.Generic.List[double]]::new();$aRaw=[Collections.Generic.List[double]]::new();$bRaw=[Collections.Generic.List[double]]::new();$effects=[Collections.Generic.List[double]]::new()
        foreach ($block in $summary.blockSchedule) {
            $a=@(foreach ($run in $block.BaselineRuns) { $values=@(($reports[$run].scenarios | Where-Object name -ceq $phase).rounds | ForEach-Object { [double]$_[$name] });foreach ($value in $values) {$aRaw.Add($value)}; $median=Median $values; $aMedians.Add($median);$median })
            $b=@(foreach ($run in $block.CandidateRuns) { $values=@(($reports[$run].scenarios | Where-Object name -ceq $phase).rounds | ForEach-Object { [double]$_[$name] });foreach ($value in $values) {$bRaw.Add($value)}; $median=Median $values; $bMedians.Add($median);$median })
            if ($a.Count -ne 2 -or $b.Count -ne 2) { throw 'Invalid two-run block' }
            $ratio=if ($exact) {1.0} else {(($b[0]+$b[1])/2.0)/(($a[0]+$a[1])/2.0)}
            $effects.Add($(if ($exact) {0.0} elseif ($higher) {-[Math]::Log($ratio)} else {[Math]::Log($ratio)}))
        }
        $before=Median $aMedians.ToArray();$after=Median $bMedians.ToArray();$aMax=($aRaw | Measure-Object -Maximum).Maximum;$bMax=($bRaw | Measure-Object -Maximum).Maximum
        $p=if ($exact) {1.0} else {Exact-AssignmentProbability $effects.ToArray()};$mean=($effects | Measure-Object -Average).Average;$ratio=[Math]::Exp($(if ($higher) {-$mean} else {$mean}))
        $medianRise=$exact -and @($bMedians | Where-Object {$_ -gt $before}).Count -gt 0;$peakRise=$exact -and $bMax -gt $aMax
        $record=@($scenario.set.metrics | Where-Object { $_.phase -ceq $phase -and $_.metric -ceq $name });if ($record.Count -ne 1) { throw 'Missing declared outcome' };$record=$record[0]
        foreach ($pair in @(@($before,$record.baselineMedian,'baselineMedian'),@($after,$record.candidateMedian,'candidateMedian'),@($aMax,$record.baselineMaximum,'baselineMaximum'),@($bMax,$record.candidateMaximum,'candidateMaximum'),@($p,$record.pValue,'pValue'),@($mean,$record.meanWorseLogEffect,'meanEffect'),@((($ratio-1.0)*100.0),$record.changePercent,'changePercent'))) {Assert-Near $pair[0] $pair[1] "$phase/$name/$($pair[2])"}
        for ($i=0;$i -lt 12;$i++) {Assert-Near $effects[$i] $record.blockEffects[$i] "$phase/$name/block$i"}
        if ($record.deterministicMedianRise -ne $medianRise -or $record.deterministicPeakRise -ne $peakRise) {throw 'Exact raw/median budget decision mismatch'}
        $checked.Add([ordered]@{phase=$phase;metric=$name;p=$p;record=$record;rawWorse=($(if ($higher) {$ratio -lt 1.0-$band} else {$ratio -gt 1.0+$band}));rawBetter=($(if ($higher) {$ratio -gt 1.0+$band} else {$ratio -lt 1.0-$band}));deterministic=($medianRise -or $peakRise)})
    } }
    if ($checked.Count -ne 26 -or $scenario.set.metrics.Count -ne 26) {throw 'Family differs from 26 declared slots'}
    $ranked=@($checked | Sort-Object { $_['p'] });$maximum=0.0;$rank=0;$flags=[Collections.Generic.List[string]]::new()
    foreach ($metric in $ranked) {
        $maximum=[Math]::Max($maximum,[Math]::Min(1.0,(26-$rank++)*$metric.p));Assert-Near $maximum $metric.record.adjustedPValue 'Holm adjusted p'
        $verdict=if ($metric.deterministic -or ($metric.rawWorse -and $maximum -le 0.05)) {'regressed'} elseif ($metric.rawBetter -and $maximum -le 0.05) {'improved'} else {'within-noise'}
        if ($verdict -cne $metric.record.verdict) {throw 'Final verdict differs from raw independent computation'}
        if ($verdict -cne 'within-noise') {$flags.Add("$($metric.phase)/$($metric.metric): $verdict")}
    }
    [ordered]@{scenario=$scenario.scenario;rawReceiptHashesVerified=48;rawRounds=$roundCount;declaredOutcomesRecomputed=26;timingEnumeration='independent partial-sum expansion; 4096 assignments';flags=$flags.ToArray();setStatus=$scenario.set.status;judgeAgreement=$scenario.judgeComparison.verdictAgreement;exactBudgets='run-median threshold and raw-round maximum independently checked'}
})
[ordered]@{summarySha256=(Get-FileHash -LiteralPath $SummaryPath).Hash;sourceCandidate=$summary.candidateCommit;protocol=$summary.allocation;purpose=$summary.studyPurpose;seed=$summary.seed;results=$results;qualification='Independent computation check only; unqualified policy and manual calibration review remain separate'} | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath $OutputPath -Encoding utf8
Write-Host "Independent raw packet audit passed: $OutputPath"

