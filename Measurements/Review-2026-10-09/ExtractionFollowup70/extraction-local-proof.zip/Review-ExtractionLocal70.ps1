Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Import-Module ./Tools/ScopedTesting.psm1 -Force
$root = [IO.Path]::GetFullPath('.')
$build = Get-ScopedBuildInputIdentity $root x64
$cases = [Collections.Generic.List[object]]::new()
$profiles = [Collections.Generic.List[object]]::new()
foreach ($configuration in @('Debug','Release','ASan Debug')) {
    $artifact = Get-ScopedArtifactIdentity $root x64 $configuration
    $common = Get-ScopedDigest (@($root,'x64',$configuration,'(common)','',$build,$artifact,(Get-ScopedEnvironmentIdentity)) -join "`n")
    $folder = ".build/extraction70-current-$configuration"
    New-Item -ItemType Directory -Path $folder -Force | Out-Null
    $profileKey = $configuration.Replace(' ','')
    $attestationPath = ".build/reports/scoped-tests/x64-$profileKey/build.json"
    $attestation = Get-Content $attestationPath -Raw | ConvertFrom-Json -AsHashtable
    if ($attestation.outcome -cne 'PASSED' -or $attestation.identity -cne (Get-ScopedDigest ($build+"`n"+$artifact))) { throw "Build attestation mismatch: $configuration" }
    Copy-Item -LiteralPath $attestationPath -Destination "$folder/build.json"
    $scopes = if ($configuration -ceq 'Debug') { @('Control') } else { @('Control','EditorControls','Embedded','WindowHost','Accessibility') }
    foreach ($scope in $scopes) {
        $receiptPath = ".build/reports/scoped-tests/x64-$profileKey/$scope.json"
        $reportPath = ".build/reports/$scope-x64-$configuration.json"
        $logPath = ".build/logs/test-$scope-x64-$configuration.log"
        $receipt = Get-Content $receiptPath -Raw | ConvertFrom-Json -AsHashtable
        $report = Get-Content $reportPath -Raw | ConvertFrom-Json -AsHashtable
        $log = Get-Content $logPath -Raw
        $sha = (Get-FileHash -LiteralPath $report.executable).Hash
        if ($receipt.outcome -cne 'PASSED' -or $receipt.identity -cne (Get-ScopedDigest ($common+"`n"+$scope)) -or $report.exitCode -ne 0 -or $report.skips.Count -ne 0 -or $report.sha256 -cne $sha -or $report.ContainsKey('tests')) { throw "Invalid whole scope identity/result: $configuration/$scope" }
        $pass = if ($scope -ceq 'Embedded') { 'PASS \d+ checks;' } else { 'All DxUi tests passed\.' }
        if ($log -notmatch $pass -or $log -match '(?m)^TIMEOUT:|^FAIL ') { throw "Log/result mismatch: $configuration/$scope" }
        if ($scope -ceq 'Control') {
            foreach ($test in @('TestChildAndTabExtractionPreservesReentrantHostTransfer','TestChildAndTabExtractionPreservesReentrantFocusRestoration','TestChildAndTabExtractionPreservesReentrantCaptureRestoration','TestChildAndTabExtractionPreservesFocusChosenDuringCaptureCancellation')) {
                if ($log -notmatch ('\[DONE\] '+[regex]::Escape($test)+'\b')) { throw "New regression did not complete: $configuration/$test" }
            }
        }
        $performance = Get-Content -LiteralPath $report.performanceReport -Raw | ConvertFrom-Json -AsHashtable
        if ($performance.executableSha256 -cne $report.performanceExecutableSha256 -or ($report.performanceScenarios | ConvertTo-Json -Depth 20 -Compress) -cne ($performance.scenarios | ConvertTo-Json -Depth 20 -Compress)) { throw "Performance binding mismatch: $configuration/$scope" }
        Copy-Item -LiteralPath $receiptPath -Destination "$folder/scoped-$scope.json"
        Copy-Item -LiteralPath $reportPath -Destination "$folder/$scope.json"
        Copy-Item -LiteralPath $logPath -Destination "$folder/test-$scope.log"
        Copy-Item -LiteralPath $report.performanceReport -Destination "$folder/performance-$scope.json"
        $cases.Add([ordered]@{configuration=$configuration;scope=$scope;exitCode=0;skips=0;identity=$receipt.identity;actualExecutableSha256=$sha;reportSha256=(Get-FileHash $reportPath).Hash;logSha256=(Get-FileHash $logPath).Hash;performanceSha256=(Get-FileHash $report.performanceReport).Hash})
    }
    $profiles.Add([ordered]@{configuration=$configuration;buildIdentity=$attestation.identity;compiledInputs=$build;artifactIdentity=$artifact;scopes=$scopes})
}
$asan = Get-Content '.build/reports/AddressSanitizer-x64.json' -Raw | ConvertFrom-Json -AsHashtable
$asanLog = '.build/logs/test-AddressSanitizer-x64.log'
if (-not $asan.detected -or $asan.exitCode -eq 0 -or (Get-Content $asanLog -Raw) -notmatch 'AddressSanitizer: heap-use-after-free') { throw 'Sanitizer instrumentation probe failed' }
Copy-Item -LiteralPath '.build/reports/AddressSanitizer-x64.json' -Destination '.build/extraction70-current-ASan Debug/AddressSanitizer.json'
Copy-Item -LiteralPath $asanLog -Destination '.build/extraction70-current-ASan Debug/test-AddressSanitizer.log'
[ordered]@{compiledInputs=$build;profiles=$profiles.ToArray();cases=$cases.ToArray();newScenarioCount=12;asanDetected=$true;qualification='Exact current compiled source/build/artifact/environment identities and whole scopes; focused local iteration, not full six-profile, foreground, physical input or paired performance acceptance.'} | ConvertTo-Json -Depth 8 | Set-Content .build/extraction70-local-independent-audit.json
Write-Host "EXTRACTION_LOCAL_AUDIT_PASS wholeScopes=$($cases.Count) profiles=$($profiles.Count) newScenarios=12 asanDetected=true"
