Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Import-Module ./Tools/PerformanceComparison.psm1 -Force
# Extract only the reviewed fixture constructors; do not run their test harness or reuse its expected failures.
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $PWD 'Tools/tests/Test-PerformanceComparison.ps1'),[ref]$null,[ref]$null)
foreach ($function in $ast.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -in @('New-Receipt','New-ReceiptWithTimingDiagnostics')},$false)) {. ([scriptblock]::Create($function.Extent.Text))}
$valid=New-ReceiptWithTimingDiagnostics
Assert-PerformanceReceipt $valid
$results=@(foreach ($case in @('sum-overflow','above-int64','fractional-frequency')) {
    $receipt=New-ReceiptWithTimingDiagnostics
    if ($case -ceq 'sum-overflow') {
        $round=$receipt.scenarios[0].rounds[0]
        $round.timingSamplesMs.frame=@(1..40 | ForEach-Object {1e308})
        $round.frameP50Ms=1e308; $round.frameP95Ms=1e308; $round.fps=1e-20
        $sum=0.0; foreach ($value in $round.timingSamplesMs.frame) {$sum+=$value}
        if ([double]::IsFinite($sum)) {throw 'The independent malformed-sum witness did not overflow'}
    } elseif ($case -ceq 'above-int64') {
        $receipt.clock.ticksPerSecond=[bigint][long]::MaxValue+1
        $receipt.clock.tickNanoseconds=1e9/[double]$receipt.clock.ticksPerSecond
    } else {
        $receipt.clock.ticksPerSecond=10000000.5
        $receipt.clock.tickNanoseconds=1e9/$receipt.clock.ticksPerSecond
    }
    $rejection=''
    try {Assert-PerformanceReceipt $receipt} catch {$rejection=$_.Exception.Message}
    if (-not $rejection) {throw "Malformed receipt accepted: $case"}
    [ordered]@{case=$case;rejected=$true;reason=$rejection}
})
$source=[IO.File]::ReadAllText((Join-Path $PWD 'Tools/PerformanceComparison.psm1')) -replace "`r`n", "`n"
$sha=[Security.Cryptography.SHA256]::Create()
try {$judgeHash=[Convert]::ToHexString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($source)))} finally {$sha.Dispose()}
$policy=Get-Content Tools/PerformanceAcceptancePolicy.v1.json -Raw | ConvertFrom-Json -AsHashtable
if ($policy.qualified -or $policy.approvedJudgeSha256 -cne $judgeHash) {throw 'Policy self-qualification or incorrect review target'}
$original=Get-Content .build/timing-aggregate-overflow-repro64.json -Raw | ConvertFrom-Json
[ordered]@{originalReproduction=$original;currentParent=(git rev-parse HEAD);normalizedJudgeSha256=$judgeHash;policyQualified=$false;validReceiptAccepted=$true;malformedCases=$results;qualification='Independent validation witness only; no native runtime or performance non-regression claim.'} | ConvertTo-Json -Depth 6 | Set-Content .build/timing-diagnostics-independent-audit64.json
Write-Host 'INDEPENDENT_DIAGNOSTIC_AUDIT_COMPLETE: valid receipt accepted, overflowing sum and invalid counter frequencies rejected, policy remains unqualified.'
