Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Import-Module ./Tools/ScopedTesting.psm1 -Force
$root=[IO.Path]::GetFullPath('.')
$build=Get-ScopedBuildInputIdentity $root x64
$artifact=Get-ScopedArtifactIdentity $root x64 Debug
$common=Get-ScopedDigest (@($root,'x64','Debug','(common)','',$build,$artifact,(Get-ScopedEnvironmentIdentity)) -join "`n")
$attestation=Get-Content .build/reports/scoped-tests/x64-Debug/build.json -Raw | ConvertFrom-Json -AsHashtable
if ($attestation.outcome -cne 'PASSED' -or $attestation.identity -cne (Get-ScopedDigest ($build+"`n"+$artifact))) {throw 'Current build attestation does not bind actual source/dependencies/artifacts'}
$cases=@(foreach ($scope in @('Embedded','WindowHost','InteractiveLease')) {
    $receipt=Get-Content ".build/reports/scoped-tests/x64-Debug/$scope.json" -Raw | ConvertFrom-Json -AsHashtable
    $report=Get-Content ".build/reports/$scope-x64-Debug.json" -Raw | ConvertFrom-Json -AsHashtable
    $sha=(Get-FileHash -LiteralPath $report.executable).Hash
    $log=".build/logs/test-$scope-x64-Debug.log"
    $marker=if ($scope -ceq 'Embedded') {'PASS \d+ checks;'} else {'All DxUi tests passed\.'}
    if ($receipt.outcome -cne 'PASSED' -or $receipt.identity -cne (Get-ScopedDigest ($common+"`n"+$scope)) -or $report.exitCode -ne 0 -or $report.skips.Count -ne 0 -or $report.sha256 -cne $sha -or (Get-Content $log -Raw) -notmatch $marker) {throw "Invalid current whole-scope evidence: $scope"}
    [ordered]@{scope=$scope;identity=$receipt.identity;executableSha256=$sha;reportSha256=(Get-FileHash ".build/reports/$scope-x64-Debug.json").Hash;logSha256=(Get-FileHash $log).Hash;performance=$report.performanceReport}
})
$performancePaths=@($cases.performance | Select-Object -Unique)
if ($performancePaths.Count -ne 1) {throw 'Combined scopes did not share one measurement'}
$performancePath=$performancePaths[0]
$performance=Get-Content -LiteralPath $performancePath -Raw | ConvertFrom-Json -AsHashtable
$actualBenchmarkHash=(Get-FileHash .build/x64/Debug/DxUi.EmbeddedTests.exe).Hash
if ($performance.executableSha256 -cne $actualBenchmarkHash -or -not $performance.sourceDirty -or $performance.identityStatus -cne 'verifiable' -or $performance.identityScope -cne 'full') {throw 'Unbound local benchmark artifact/provenance'}
if ($performance.clock.ticksPerSecond -ne [Diagnostics.Stopwatch]::Frequency -or $performance.clock.nominalPeriodNanoseconds -ne 1 -or [Math]::Abs($performance.clock.tickNanoseconds - 1e9/[double]$performance.clock.ticksPerSecond) -gt 1e-7) {throw 'Local clock diagnostics differ from independently queried current host frequency'}
# Do not import the production receipt validator. Recompute all timing fields from the raw frame-order samples.
$rounds=[Collections.Generic.List[object]]::new()
foreach ($scenario in $performance.scenarios) {
    if ($scenario.rounds.Count -ne 5) {throw 'Missing raw rounds'}
    foreach ($round in $scenario.rounds) {
        $sorted=@{}; $total=0.0
        foreach ($key in @('frame','prepare','composeCpu')) {
            $values=[double[]]@($round.timingSamplesMs[$key])
            if ($values.Length -ne 40) {throw 'Missing ordered timing samples'}
            foreach ($value in $values) {if (-not [double]::IsFinite($value) -or $value -lt 0) {throw 'Invalid raw timing'}}
            if ($key -ceq 'frame') {foreach ($value in $values) {$total+=$value}}
            [Array]::Sort($values); $sorted[$key]=$values
        }
        $expected=@{fps=40000.0/$total;frameP50Ms=$sorted.frame[19];frameP95Ms=$sorted.frame[37];prepareP95Ms=$sorted.prepare[37];composeCpuP95Ms=$sorted.composeCpu[37]}
        foreach ($key in $expected.Keys) {if ([Math]::Abs([double]$round[$key]-$expected[$key]) -gt 1e-8*[Math]::Max(1e-9,[Math]::Abs($expected[$key]))) {throw "Raw timing does not reproduce $key"}}
        if ($round.composeAllocations -ne 0 -or ($scenario.name -ceq 'clean' -and $round.cppAllocations -ne 0)) {throw 'Composition/clean allocation budget failure'}
        $rounds.Add([ordered]@{phase=$scenario.name;fps=$expected.fps;frameP95Ms=$expected.frameP95Ms;prepareP95Ms=$expected.prepareP95Ms;composeCpuP95Ms=$expected.composeCpuP95Ms})
    }
}
if ($performance.hiddenPreparations -ne 0 -or $performance.hiddenComposites -ne 0) {throw 'Hidden work was performed'}
$selfTest=@(& ./.build/x64/Debug/DxUi.InteractiveLease.exe --self-test)
if ($LASTEXITCODE -ne 0 -or @($selfTest | Where-Object {$_ -like 'SKIPPED:*' -or $_ -like 'FAIL*'}).Count) {throw 'Private-desktop lease self-test failed'}
$selfTest | Set-Content .build/logs/production-review-2026-10-10-native-self-test60.log
[ordered]@{buildIdentity=$attestation.identity;compiledInputs=$build;artifactIdentity=$artifact;cases=$cases;performanceSha256=(Get-FileHash -LiteralPath $performancePath).Hash;benchmarkExecutableSha256=$actualBenchmarkHash;clock=$performance.clock;rawTimingSamples=1200;timingFieldsIndependentlyReproduced=50;rounds=$rounds.ToArray();privateLeaseSummary=@($selfTest | Where-Object {$_ -like 'PASS:*'});qualification='Exact-source whole x64 Debug noninteractive scopes and private desktop; unpaired performance is diagnostic and supplies no non-regression verdict.'} | ConvertTo-Json -Depth 6 | Set-Content .build/local-diagnostics-independent-audit60.json
Write-Host 'INDEPENDENT_LOCAL_AUDIT_COMPLETE: exact current source/artifacts, 1200 raw timing samples, 50 timing fields and private desktop verified.'
