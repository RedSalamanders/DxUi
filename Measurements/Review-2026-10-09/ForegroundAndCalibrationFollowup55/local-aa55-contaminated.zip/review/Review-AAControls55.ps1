[CmdletBinding()] param([Parameter(Mandatory)][string] $SummaryPath, [Parameter(Mandatory)][string] $OutputPath)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$summary = Get-Content -LiteralPath $SummaryPath -Raw | ConvertFrom-Json -AsHashtable
$root = Split-Path -Parent $SummaryPath
$metrics = @('fps','frameP50Ms','frameP95Ms','prepareP95Ms','composeCpuP95Ms','privateBytes','privatePeakBytes','workingSetBytes','workingSetPeakBytes','surfaceBytes','replacementPeakBytes','cppAllocations','composeAllocations')
$exact = @('surfaceBytes','replacementPeakBytes','cppAllocations','composeAllocations')
function Median([double[]] $Values) {
    $ordered = @($Values | Sort-Object)
    $middle = [int][Math]::Floor($ordered.Count/2.0)
    if ($ordered.Count % 2) { return [double]$ordered[$middle] }
    return ([double]$ordered[$middle-1] + [double]$ordered[$middle])/2.0
}
$cells = [Collections.Generic.List[object]]::new()
$scenarios = [Collections.Generic.List[object]]::new()
foreach ($scenario in $summary.scenarios) {
    $reports = @{}
    foreach ($run in $summary.steps.Name) { $reports[$run] = Get-Content -LiteralPath (Join-Path $root "$($scenario.scenario)-$run.json") -Raw | ConvertFrom-Json -AsHashtable }
    $counts = @{}
    $unstable = 0
    foreach ($block in $summary.blockSchedule) {
        foreach ($role in @('BaselineRuns','CandidateRuns')) {
            $runs = @($block[$role])
            if ($runs.Count -ne 2) { throw 'A short control needs two same-role runs' }
            $controlUnstable = $false
            foreach ($phase in @('clean','dirty')) {
                $beforePhase = @($reports[$runs[0]].scenarios | Where-Object { $_.name -ceq $phase })[0]
                $afterPhase = @($reports[$runs[1]].scenarios | Where-Object { $_.name -ceq $phase })[0]
                foreach ($metric in $metrics) {
                    $before = Median ([double[]]@($beforePhase.rounds | ForEach-Object { $_[$metric] }))
                    $after = Median ([double[]]@($afterPhase.rounds | ForEach-Object { $_[$metric] }))
                    $band = if ($metric -in $exact) { 0.0 } elseif ($metric -match '^(private|workingSet)') { 2.0 } else { 5.0 }
                    $drift = if ($before -eq 0.0) { if ($after -eq 0.0) { 0.0 } else { [double]::PositiveInfinity } } else { 100.0*($after/$before-1.0) }
                    $excursion = [Math]::Abs($drift) -gt $band
                    $key = "$phase/$metric"
                    if (-not $counts.ContainsKey($key)) { $counts[$key] = [ordered]@{ scenario=$scenario.scenario; phaseMetric=$key; observed=0; excursions=0; band=$band; maxAbsoluteDrift=0.0 } }
                    $counts[$key].observed++
                    if ($excursion) { $counts[$key].excursions++; $controlUnstable=$true }
                    $counts[$key].maxAbsoluteDrift = [Math]::Max($counts[$key].maxAbsoluteDrift,[Math]::Abs($drift))
                }
            }
            if ($controlUnstable) { $unstable++ }
        }
    }
    foreach ($key in $counts.Keys) { $cells.Add($counts[$key]) }
    $recorded = @($scenario.comparisons | Where-Object { $_.name -match '-control$' -and $_.status -ceq 'unstable-control' }).Count
    if ($unstable -ne $recorded) { throw "Independent control count differs for $($scenario.scenario): actual=$unstable recorded=$recorded" }
    $scenarios.Add([ordered]@{scenario=$scenario.scenario;controls=24;unstable=$unstable})
}
$result = [ordered]@{ summarySha256=(Get-FileHash -LiteralPath $SummaryPath).Hash; scenarios=$scenarios.ToArray(); cells=$cells.ToArray(); unstableTimingMemoryCells=@($cells | Where-Object { $_.band -gt 0 -and $_.excursions -gt 0 }).Count; stableExactCells=@($cells | Where-Object { $_.band -eq 0 -and $_.excursions -eq 0 }).Count }
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $OutputPath -Encoding utf8
$scenarios | ForEach-Object { Write-Host "$($_.scenario): $($_.unstable)/$($_.controls) controls unstable" }
Write-Host "Timing/memory cells with excursions=$($result.unstableTimingMemoryCells); stable exact cells=$($result.stableExactCells)"
