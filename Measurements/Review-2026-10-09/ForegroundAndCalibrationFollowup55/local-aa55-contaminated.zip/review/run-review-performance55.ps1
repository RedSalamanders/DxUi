$ErrorActionPreference = 'Stop'
$global:LASTEXITCODE = 0
Set-Location 'Z:\src\DxUi'
$candidate = (git rev-parse HEAD).Trim()
$baseline = 'bea676a1f8418141f61cab9326b9b910e89a14b4'
if (git status --porcelain --untracked-files=normal) { throw 'Performance harness candidate is dirty' }
$processes = @(Get-CimInstance Win32_Process -Filter "Name='cl.exe' OR Name='MSBuild.exe' OR Name='link.exe'" | Where-Object { $_.Name -ne 'MSBuild.exe' -or $_.CommandLine -notmatch '/nodemode:' })
if ($processes.Count) { throw 'A build is running; leave it untouched and choose a quiet measurement window' }
Write-Host "AA_START: one shared candidate revision/executable; 12 blocks; 3 scenarios; $candidate"
& ./performance-paired.ps1 -BaselineRevision $candidate -CandidateRevision $candidate -CalibrationAA -Platform x64 -Configuration Release -Scenario Default,MultilineGrid,MultilineGridDistinct -Blocks 12 -Seed 2026101055 -OutputDirectory .build/review-performance-aa55 *> .build/logs/production-review-2026-10-10-parent-release-AA55.log
if ($LASTEXITCODE) { throw 'Release A/A study failed; inspect retained logs and reports' }
if ((git rev-parse HEAD).Trim() -cne $candidate -or (git status --porcelain --untracked-files=normal)) { throw 'Harness candidate changed during A/A study' }
Write-Host 'AA_RAW_STUDY_COMPLETE: independent review still required'
Write-Host "PAIRED_START: $baseline -> $candidate; 12 blocks; 3 scenarios"
& ./performance-paired.ps1 -BaselineRevision $baseline -CandidateRevision $candidate -Platform x64 -Configuration Release -Scenario Default,MultilineGrid,MultilineGridDistinct -Blocks 12 -Seed 2026101056 -OutputDirectory .build/review-performance-paired55 *> .build/logs/production-review-2026-10-10-parent-release-paired55.log
if ($LASTEXITCODE) { throw 'Release paired study failed; inspect retained logs and reports' }
if ((git rev-parse HEAD).Trim() -cne $candidate -or (git status --porcelain --untracked-files=normal)) { throw 'Harness candidate changed during paired study' }
Write-Host 'PAIRED_RAW_STUDY_COMPLETE: unqualified policy remains policy-review-required'

