$ErrorActionPreference = 'Stop'
$global:LASTEXITCODE = 0
$env:PATH = $PSHOME + ':/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
$linuxCandidate = Join-Path '/tmp' ('DxUi-review-linux-' + [guid]::NewGuid().ToString('N'))
& git clone --no-hardlinks --quiet '/mnt/z/src/DxUi' $linuxCandidate
if ($LASTEXITCODE) { throw 'Linux scratch clone failed' }
Set-Location $linuxCandidate
if (& git status --porcelain) { throw 'Native Linux candidate is dirty' }
Write-Host "Clean committed Linux source: $((& git rev-parse HEAD).Trim())"
Write-Host "Native Linux fixture root: $linuxCandidate"
Write-Host "Linux PowerShell $($PSVersionTable.PSVersion); $([Runtime.InteropServices.RuntimeInformation]::OSDescription)"
& ./validate.ps1
if ($LASTEXITCODE) { throw "Linux portability validation failed: $LASTEXITCODE" }
Write-Host 'LINUX_PORTABILITY_VALIDATION_PASS'
