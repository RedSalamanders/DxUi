Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$destination=[IO.Path]::GetFullPath('Measurements/Review-2026-10-09/IndependentConsumerQualificationFollowup71')
New-Item -ItemType Directory -Path $destination -Force | Out-Null
$manifest=[Collections.Generic.List[string]]::new()
$manifest.Add('Frozen head 65476a8a457b10d1e8b7fd6520a7453d1d4d83a3; actual merge 005618c75b934607a2ec37ce5c6c42abc5a148a3; CI 38014088297. Extraction follow-up 70 changes native code afterward and is not qualified by this packet.')
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile([IO.Path]::GetFullPath('.build/Seal-ReviewFollowup61.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Archive helper parse failure'}
$functions=@($ast.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -in @('Seal-Packet','Get-PacketFiles')},$false))
if($functions.Count -ne 2){throw 'Missing reviewed archive helpers'}
foreach($function in $functions){Invoke-Expression $function.Extent.Text}
function Confirm-Packet([string] $Name,[Collections.IDictionary] $Files) {
    $path=Join-Path $destination $Name
    if(-not (Test-Path -LiteralPath $path)){Seal-Packet $Name $Files;return}
    $archive=[IO.Compression.ZipFile]::OpenRead($path)
    try {
        if($archive.Entries.Count -ne $Files.Count){throw "Existing archive count differs: $Name"}
        foreach($entry in $Files.Keys){
            $stored=$archive.GetEntry($entry);$stream=$stored.Open();$sha=[Security.Cryptography.SHA256]::Create()
            try{$hash=[Convert]::ToHexString($sha.ComputeHash($stream))}finally{$sha.Dispose();$stream.Dispose()}
            $original=Get-Item -LiteralPath $Files[$entry]
            if($stored.Length -ne $original.Length -or $hash -cne (Get-FileHash -LiteralPath $original.FullName).Hash){throw "Existing archive differs: $Name/$entry"}
            $manifest.Add("$Name/$entry $($stored.Length) $hash")
        }
    }finally{$archive.Dispose()}
    $manifest.Add("ARCHIVE $Name entries=$($Files.Count) sha256=$((Get-FileHash -LiteralPath $path).Hash)")
    Write-Host "REVERIFIED $Name $($Files.Count) unchanged entries"
}
Confirm-Packet '65476a8-native-ci.zip' (Get-PacketFiles '.build/ci-38014088297-native')
Confirm-Packet '65476a8-paired-ci.zip' (Get-PacketFiles '.build/ci-38014088297-paired')
$files=[ordered]@{}
foreach($name in @('65476a8-native-independent-audit71.json','65476a8-resources-independent-audit71.json','65476a8-native-timing-independent-audit71.json','65476a8-paired-independent-audit71.json','65476a8-paired-independent-controls71.json','65476a8-paired-timing-independent-audit71.json','65476a8-harness-independent-verification71.json','65476a8-merge-provenance71.json','65476a8-head-provenance71.json','current-validator-frozen-compatibility69.json','Review-NativePacket55.ps1','Review-MenuResources71.ps1','Review-HostedTiming66.ps1','Review-PairedPacket53.ps1','Review-AAControls55.ps1','Review-PairedTiming68.ps1','Review-Harness71.ps1','Seal-Qualification71.ps1')){$files[$name]=".build/$name"}
foreach($name in @('native','resources','native-timing','paired','controls','paired-timing','harness')){$files["logs/$name-audit71.log"]=".build/logs/production-review-2026-10-10-65476a8-$name-audit71.log"}
foreach($name in @('windows-tooling','linux-validation','format','arm64-debug')){$files["logs/ci-${name}69.log"]=".build/logs/production-review-2026-10-10-ci-65476a8-$name"+'69.log'}
Seal-Packet '65476a8-independent-review.zip' $files
$manifest | Set-Content (Join-Path $destination 'archive-manifest.txt') -Encoding utf8
