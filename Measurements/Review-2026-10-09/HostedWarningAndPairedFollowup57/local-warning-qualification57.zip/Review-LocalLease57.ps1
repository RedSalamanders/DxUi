Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Import-Module ./Tools/ScopedTesting.psm1 -Force
$root=[IO.Path]::GetFullPath('.')
$build=Get-ScopedBuildInputIdentity $root x64
$artifact=Get-ScopedArtifactIdentity $root x64 Debug
$common=Get-ScopedDigest (@($root,'x64','Debug','(common)','',$build,$artifact,(Get-ScopedEnvironmentIdentity)) -join "`n")
$attestation=Get-Content .build/reports/scoped-tests/x64-Debug/build.json -Raw | ConvertFrom-Json -AsHashtable
if($attestation.outcome -cne 'PASSED' -or $attestation.identity -cne (Get-ScopedDigest ($build+"`n"+$artifact))) {throw 'Build attestation no longer matches actual source/dependencies/artifacts'}
$cases=@(foreach($scope in @('WindowHost','InteractiveLease')) {
    $receipt=Get-Content ".build/reports/scoped-tests/x64-Debug/$scope.json" -Raw | ConvertFrom-Json -AsHashtable
    $r=Get-Content ".build/reports/$scope-x64-Debug.json" -Raw | ConvertFrom-Json -AsHashtable
    $sha=(Get-FileHash -LiteralPath $r.executable).Hash
    $log=".build/logs/test-$scope-x64-Debug.log"
    if($receipt.outcome -cne 'PASSED' -or $receipt.identity -cne (Get-ScopedDigest ($common+"`n"+$scope)) -or $r.exitCode -ne 0 -or $r.skips.Count -ne 0 -or $r.sha256 -cne $sha -or (Get-Content $log -Raw) -notmatch 'All DxUi tests passed\.') {throw "Invalid current whole-scope evidence: $scope"}
    [pscustomobject]@{scope=$scope;identity=$receipt.identity;sha256=$sha;exit=0;skips=0;reportSha256=(Get-FileHash ".build/reports/$scope-x64-Debug.json").Hash;logSha256=(Get-FileHash $log).Hash}
})
$selfTest=@(& ./.build/x64/Debug/DxUi.InteractiveLease.exe --self-test)
if($LASTEXITCODE -ne 0 -or @($selfTest | Where-Object {$_ -like 'SKIPPED:*' -or $_ -like 'FAIL*'}).Count) {throw 'Fresh private-desktop native lease self-test did not pass'}
$selfTest | Set-Content .build/logs/production-review-2026-10-10-native-self-test57.log
[ordered]@{buildIdentity=$attestation.identity;compiledInputs=$build;artifactIdentity=$artifact;cases=$cases;nativeLeaseSha256=(Get-FileHash .build/x64/Debug/DxUi.InteractiveLease.exe).Hash;selfTestSummary=($selfTest | Where-Object {$_ -like 'PASS:*'});qualification='Current exact-source x64 Debug noninteractive scopes and private-desktop services only; hosted input acceptance remains pending.'} | ConvertTo-Json -Depth 4 | Set-Content .build/local-lease-independent-audit57.json
Write-Host 'Current build/run identities, actual executables and private-desktop native lease independently checked.'
