[CmdletBinding()] param([Parameter(Mandatory)][string] $SummaryPath, [Parameter(Mandatory)][string] $OutputPath)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$s=Get-Content -LiteralPath $SummaryPath -Raw | ConvertFrom-Json -AsHashtable
$root=Split-Path -Parent $SummaryPath
function Median([double[]] $Values) {
    $v=@($Values | Sort-Object); $i=[int][Math]::Floor($v.Count/2.0)
    if($v.Count%2) {return $v[$i]}; return ($v[$i-1]+$v[$i])/2.0
}
$runs=@(foreach($step in $s.steps) {
    $r=Get-Content -LiteralPath (Join-Path $root "MultilineGrid-$($step.Name).json") -Raw | ConvertFrom-Json -AsHashtable
    $phase=$r.scenarios | Where-Object name -CEQ clean
    [pscustomobject]@{name=$step.Name;side=$step.Side;value=(Median @($phase.rounds.prepareP95Ms))}
})
# Weighted selection over tie groups, separate from the base comparator's dynamic program. Doubled ranks keep ties integral.
$groups=@($runs | Group-Object value | Sort-Object {[double]$_.Name})
$states=@{'0,0'=[decimal]1}; $first=1; $candidateRankSum=0
foreach($group in $groups) {
    $m=$group.Count; $rank2=2*$first+$m-1; $first+=$m
    $candidateRankSum+=@($group.Group | Where-Object side -CEQ candidate).Count*$rank2
    $next=@{}
    foreach($key in $states.Keys) {
        $parts=$key.Split(','); $count=[int]$parts[0]; $sum=[int]$parts[1]; $choose=[decimal]1
        for($k=0;$k -le [Math]::Min($m,24-$count);$k++) {
            if($k) {$choose=$choose*($m-$k+1)/$k}
            $newKey="$($count+$k),$($sum+$k*$rank2)"
            if(-not $next.ContainsKey($newKey)) {$next[$newKey]=[decimal]0}
            $next[$newKey]+=$states[$key]*$choose
        }
    }
    $states=$next
}
$total=[decimal]0; $extreme=[decimal]0; $distance=[Math]::Abs($candidateRankSum-1176)
foreach($key in $states.Keys) {
    $parts=$key.Split(','); if([int]$parts[0] -ne 24) {continue}
    $total+=$states[$key]
    if([Math]::Abs([int]$parts[1]-1176) -ge $distance) {$extreme+=$states[$key]}
}
$p=[double]($extreme/$total)
$metric=($s.scenarios | Where-Object scenario -CEQ MultilineGrid).judgeComparison.legacyJudge.metrics | Where-Object { $_.phase -ceq 'clean' -and $_.metric -ceq 'prepareP95Ms' }
if([Math]::Abs($p-$metric.pValue) -gt 1e-12 -or $total -ne 32247603683100 -or $extreme -ne 32596533546) {throw 'Legacy exact inference did not reproduce'}
$migrated=($s.scenarios | Where-Object scenario -CEQ MultilineGrid).judgeComparison.migratedJudge.metrics | Where-Object { $_.phase -ceq 'clean' -and $_.metric -ceq 'prepareP95Ms' }
$audit=[ordered]@{summarySha256=(Get-FileHash -LiteralPath $SummaryPath).Hash;legacyExactU=($candidateRankSum/2.0-300);legacyAssignments=$total;legacyExtreme=$extreme;legacyP=$p;legacyChangePercent=$metric.changePercent;migratedRawP=$migrated.pValue;migratedAdjustedP=$migrated.adjustedPValue;migratedChangePercent=$migrated.changePercent;legacyVerdict=$metric.verdict;migratedVerdict=$migrated.verdict;interpretation='Legacy unpaired exchangeability and per-metric improvement differ from independent paired blocks with a 26-slot Holm family; no accepted improvement or policy qualification.'}
$audit | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $OutputPath
Write-Host 'Legacy tie-group enumeration reproduced the raw packet difference.'
