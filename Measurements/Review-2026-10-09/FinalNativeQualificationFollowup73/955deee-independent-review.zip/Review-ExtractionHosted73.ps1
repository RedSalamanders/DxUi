[CmdletBinding()] param([Parameter(Mandatory)][string] $ArtifactRoot,[Parameter(Mandatory)][string] $NativeAudit,[Parameter(Mandatory)][string] $OutputPath)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$audit=Get-Content -LiteralPath $NativeAudit -Raw|ConvertFrom-Json -AsHashtable
if($audit.profiles.Count -ne 6 -or $audit.consumers.Count -ne 8){throw 'Incomplete six-profile/eight-consumer evidence'}
$names=@('TestChildAndTabExtractionPreservesReentrantHostTransfer','TestChildAndTabExtractionPreservesReentrantFocusRestoration','TestChildAndTabExtractionPreservesReentrantCaptureRestoration','TestChildAndTabExtractionPreservesFocusChosenDuringCaptureCancellation')
$records=@(foreach($profile in $audit.profiles){
    $root=Join-Path $ArtifactRoot "native-$($profile.platform)-$($profile.configuration)"
    $path=Join-Path $root "logs/test-Control-$($profile.platform)-$($profile.configuration).log"
    $log=Get-Content -LiteralPath $path -Raw
    foreach($name in $names){if([regex]::Matches($log,'(?m)^\s*\[DONE\] '+[regex]::Escape($name)+' \(').Count -ne 1){throw "Missing/duplicate extraction completion: $name $path"}}
    if($profile.suites.Count -ne 21){throw 'Incomplete suite inventory'}
    $pass=@($profile.suites|Where-Object passed)
    $fail=@($profile.suites|Where-Object {-not $_.passed})
    if($profile.platform -ceq 'x64'){
        if($pass.Count -ne 21 -or $fail.Count){throw 'x64 native candidate is not fully passing'}
    }else{
        if($pass.Count -ne 19 -or $fail.Count -ne 2){throw 'Unexpected ARM64 native outcome'}
        foreach($item in $fail){
            if($item.suite -notin @('Menu','NativeTextInput') -or $item.exitCode -ne 24 -or $item.lease.state -cne 'unwarned' -or $item.lease.exitCode -ne 23){throw 'ARM64 failure is not the retained warning refusal'}
            foreach($key in @('foreground','focus','cursor')){if($item.lease[$key] -cne 'unchanged'){throw "ARM64 lease changed $key"}}
            if($item.lease.runMovedSomething){throw 'Refused ARM64 lease moved input state'}
            $childPath=Join-Path $root "logs/test-$($item.suite)-$($profile.platform)-$($profile.configuration).hosted.log"
            $child=Get-Content -LiteralPath $childPath -Raw
            if($child -notmatch '^\[LEASE\].*did not run under the foreground lease' -or $child -match '\[BEGIN\]|\[DONE\]|All DxUi tests passed'){throw 'Refused foreground child unexpectedly executed'}
        }
    }
    [ordered]@{platform=$profile.platform;configuration=$profile.configuration;completedFunctions=$names;interactionScenarios=12;passedSuites=$pass.Count;unexecutedForegroundSuites=@($fail|ForEach-Object {$_.suite});controlLogSha256=(Get-FileHash -LiteralPath $path).Hash}
})
[ordered]@{actualMerge=$audit.actualMergeCandidate;nativeReportLogPairs=126;consumerCases=8;records=$records;limitation='This verifies function completion markers and full suite outcomes. ARM64 foreground execution remains absent; it is not a native input pass.'}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath $OutputPath
Write-Host 'HOSTED_EXTRACTION_AUDIT_PASS: twelve scenarios in all six profiles; x64 63 suites; ARM64 57 noninteractive suites; eight consumers.'
