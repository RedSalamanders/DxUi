[CmdletBinding()] param(
    [Parameter(Mandatory)][string] $ArtifactRoot,
    [Parameter(Mandatory)][string] $ExpectedCommit,
    [Parameter(Mandatory)][string] $OutputPath,
    [ValidateSet('x64','ARM64')][string[]] $Platforms=@('x64','ARM64'),
    [ValidateSet('Debug','Release','ASan Debug')][string[]] $Configurations=@('Debug','Release','ASan Debug'),
    [switch] $AllowUnleased
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$suites = @('Foundation','Embedded','Grid','Theme','Control','MenuExitLifetime','NewControls','EditorControls','TextField','MultilineText','ReadOnly','ComboBox','Tree','Tooltip','Rendering','Animation','Accessibility','WindowHost','InteractiveLease','Menu','NativeTextInput')
$profiles = [Collections.Generic.List[object]]::new()
$consumers = [Collections.Generic.List[object]]::new()
foreach ($platform in $Platforms) {
    foreach ($configuration in $Configurations) {
        $root = Join-Path $ArtifactRoot "native-$platform-$configuration"
        $reports = Join-Path $root 'reports'
        $results = [Collections.Generic.List[object]]::new()
        foreach ($suite in $suites) {
            $suffix = if (-not $AllowUnleased -and $suite -in @('Menu','NativeTextInput')) { '.hosted' } else { '' }
            $path = Join-Path $reports "$suite-$platform-$configuration$suffix.json"
            $receipt = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json -AsHashtable
            if ($receipt.suite -cne $suite -or $receipt.platform -cne $platform -or $receipt.configuration -cne $configuration -or $receipt.nativeArchitecture -ine $platform) { throw "Wrong suite/profile identity: $path" }
            if ($receipt.sha256 -notmatch '^[A-Fa-f0-9]{64}$' -or $receipt.ContainsKey('tests')) { throw "Missing artifact identity or filtered suite: $path" }
            $perfPath = Join-Path $reports ([IO.Path]::GetFileName($receipt.performanceReport))
            $perf = Get-Content -LiteralPath $perfPath -Raw | ConvertFrom-Json -AsHashtable
            if ($perf.sourceCommit -cne $ExpectedCommit -or $perf.sourceDirty -or $perf.identityStatus -cne 'verifiable' -or $perf.identityScope -cne 'full') { throw "Unbound or dirty performance source: $path" }
            if ($perf.platform -cne $platform -or $perf.configuration -cne $configuration -or $perf.nativeArchitecture -ine $platform -or $perf.executableSha256 -cne $receipt.performanceExecutableSha256) { throw "Wrong performance profile/artifact: $path" }
            if (($receipt.performanceScenarios | ConvertTo-Json -Depth 20 -Compress) -cne ($perf.scenarios | ConvertTo-Json -Depth 20 -Compress)) { throw "Copied raw rounds differ: $path" }
            foreach ($identity in @('harnessIdentity','toolchainIdentity','dependencyIdentity','environmentIdentity','sourceFingerprint','benchmarkSha256')) { if ($perf[$identity] -notmatch '^[A-Fa-f0-9]{64}$') { throw "Missing $identity in $perfPath" } }
            $logPath = Join-Path $root "logs/test-$suite-$platform-$configuration$suffix.log"
            $log = Get-Content -LiteralPath $logPath -Raw
            $skips = @($log -split '\r?\n' | Where-Object { $_ -match '^SKIPPED:' })
            if (($skips -join "`n") -cne ($receipt.skips -join "`n")) { throw "Receipt/log skip mismatch: $path" }
            if ($receipt.exitCode -eq 0) {
                $end = switch ($suite) {
                    'Foundation' { 'Foundation tests: PASS' }
                    'Embedded' { 'PASS \d+ checks;' }
                    'MenuExitLifetime' { '\[EXIT\] MenuExitLifetime: active menu is dismissed before the process-exit host sweep' }
                    'InteractiveLease' { '\[DONE\] InteractiveLease \(' }
                    default { 'All DxUi tests passed\.' }
                }
                if ($log -notmatch $end -or $log -match '(?m)^TIMEOUT:|^FAIL ') { throw "Success receipt disagrees with child log: $path" }
            }
            $lease = if ($receipt.ContainsKey('lease')) { $receipt.lease } else { $null }
            if (-not $AllowUnleased -and $suite -in @('Menu','NativeTextInput')) {
                if ($null -eq $lease -or $lease.mode -cne 'verified-github-hosted' -or -not $lease.hosted -or $lease.sha256 -notmatch '^[A-Fa-f0-9]{64}$') { throw "Foreground lease identity missing: $path" }
            }
            $leasePassed = $null -eq $lease -or ($lease.state -ceq 'completed' -and $lease.exitCode -eq 0 -and @('foreground','focus','cursor' | Where-Object { $lease[$_] -ceq 'failed' }).Count -eq 0)
            $results.Add([ordered]@{ suite=$suite; exitCode=$receipt.exitCode; skips=$skips.Count; passed=($receipt.exitCode -eq 0 -and $skips.Count -eq 0 -and $leasePassed); reportSha256=(Get-FileHash -LiteralPath $path).Hash; logSha256=(Get-FileHash -LiteralPath $logPath).Hash; recordedExecutableSha256=$receipt.sha256; performanceSha256=(Get-FileHash -LiteralPath $perfPath).Hash; lease=$lease })
        }
        $asan = $null
        if ($configuration -ceq 'ASan Debug') {
            $asanPath = Join-Path $reports "AddressSanitizer-$platform.json"
            $asan = Get-Content -LiteralPath $asanPath -Raw | ConvertFrom-Json -AsHashtable
            $asanLog = Join-Path $root "logs/test-AddressSanitizer-$platform.log"
            if (-not $asan.detected -or $asan.exitCode -eq 0 -or (Get-Content -LiteralPath $asanLog -Raw) -notmatch 'AddressSanitizer: heap-use-after-free') { throw "ASan probe did not prove instrumentation: $asanPath" }
        }
        foreach ($path in @(Get-ChildItem -LiteralPath $reports -Filter 'ExternalConsumer-*.json' -File)) {
            $consumer = Get-Content -LiteralPath $path.FullName -Raw | ConvertFrom-Json -AsHashtable
            if ($consumer.commit -cne $ExpectedCommit -or $consumer.buildIdentity.Identity.commit -cne $ExpectedCommit -or $consumer.buildIdentity.Identity.apiRevision -ne 4 -or $consumer.nativeModuleChecks -ne 12 -or $consumer.negativeChecks -ne 10 -or $consumer.exitCode -ne 0) { throw "Consumer fixture failed source/API/ownership checks: $path" }
            if ($consumer.platform -cne $platform -or $consumer.configuration -cne $configuration -or $consumer.nativeArchitecture -ine $platform) { throw "Wrong consumer profile: $path" }
            $consumers.Add([ordered]@{ platform=$platform; configuration=$configuration; disableStlAnnotations=$consumer.disableStlAnnotations; apiRevision=$consumer.buildIdentity.Identity.apiRevision; nativeModuleChecks=$consumer.nativeModuleChecks; negativeChecks=$consumer.negativeChecks; reportSha256=(Get-FileHash -LiteralPath $path.FullName).Hash })
        }
        $profiles.Add([ordered]@{ platform=$platform; configuration=$configuration; actualMergeCandidate=$ExpectedCommit; passed=(@($results | Where-Object { -not $_.passed }).Count -eq 0); suites=$results.ToArray(); asanDetected=($null -ne $asan -and $asan.detected) })
    }
}
$result = [ordered]@{ actualMergeCandidate=$ExpectedCommit; profiles=$profiles.ToArray(); consumers=$consumers.ToArray(); limitation='Executable bytes are absent from native artifacts; raw report/log hashes and recorded identities were checked, not independently rehashed CI binaries.' }
$result | ConvertTo-Json -Depth 25 | Set-Content -LiteralPath $OutputPath -Encoding utf8
Write-Host "INDEPENDENT_NATIVE_AUDIT_COMPLETE profiles=$($profiles.Count) mainSuites=$($profiles.Count*$suites.Count) consumerCases=$($consumers.Count)"
$profiles | ForEach-Object { Write-Host "$($_.platform) $($_.configuration) passed=$($_.passed) failures=$(@($_.suites | Where-Object { -not $_.passed }).Count)" }

