[CmdletBinding()]
param(
    [string] $SummaryPath = '.build/ci-38017295946-paired/paired/20261010T023231Z-bea676a1f841/reports/summary.json',
    [string] $OutputPath = '.build/955deee-legacy-independent-audit73.json'
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$summaryPath = [IO.Path]::GetFullPath($SummaryPath)
$root = Split-Path -Parent $summaryPath
$s = Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json -AsHashtable
$scenario = @($s.scenarios | Where-Object { $_.scenario -ceq 'Default' })[0]
$expectedLegacy = @($scenario.judgeComparison.legacyJudge.metrics | Where-Object { $_.phase -ceq 'clean' -and $_.metric -ceq 'prepareP95Ms' })[0]
$expectedPaired = @($scenario.set.metrics | Where-Object { $_.phase -ceq 'clean' -and $_.metric -ceq 'prepareP95Ms' })[0]
if ($s.steps.Count -ne 48 -or $scenario.judgeComparison.sameReceiptsSha256.Count -ne 48) { throw 'Expected all 48 Default receipt identities' }
$hashByRun = @{}; foreach ($h in $scenario.judgeComparison.sameReceiptsSha256) { $hashByRun[$h.run] = $h.sha256 }
$rawRuns = @(foreach ($step in $s.steps) {
    $path = Join-Path $root "Default-$($step.Name).json"
    $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
    if ($hash -cne $hashByRun[$step.Name]) { throw "Receipt hash mismatch: $($step.Name)" }
    $r = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json -AsHashtable
    $expectedCommit = if ($step.Side -ceq 'baseline') { $s.baselineCommit } else { $s.candidateCommit }
    if ($r.sourceCommit -cne $expectedCommit) { throw "Commit identity mismatch: $($step.Name)" }
    $summaryRun = $scenario.runs[$step.Name]
    foreach ($field in @('sourceFingerprint','executableSha256','benchmarkSha256')) {
        if ($r[$field] -cne $summaryRun[$field]) { throw "Summary/receipt identity mismatch: $($step.Name)/$field" }
    }
    if ($r.benchmarkSha256 -cne $scenario.runs.A01.benchmarkSha256) { throw 'Benchmark inputs differ between receipts' }
    $clean = @($r.scenarios | Where-Object { $_.name -ceq 'clean' })[0]
    $roundValues = @($clean.rounds | ForEach-Object { [double]$_.prepareP95Ms } | Sort-Object)
    if ($roundValues.Count -ne 5) { throw "Expected five prepareP95 round values: $($step.Name)" }
    $runMedian = $roundValues[2]
    [pscustomobject]@{name=$step.Name; side=$step.Side; block=$step.Block; position=$step.Position; order=$step.Order; value=$runMedian; rounds=$roundValues; sha256=$hash; sourceCommit=$r.sourceCommit; sourceFingerprint=$r.sourceFingerprint; executableSha256=$r.executableSha256; benchmarkSha256=$r.benchmarkSha256; sourceDirty=$r.sourceDirty; clock=$r.clock}
})
if (@($rawRuns | Where-Object side -ceq 'baseline').Count -ne 24 -or @($rawRuns | Where-Object side -ceq 'candidate').Count -ne 24) { throw 'Expected 24 receipts per side' }
function Median([double[]] $Values) { $v=@($Values | Sort-Object); $n=$v.Count; if($n%2){return $v[[int][Math]::Floor($n/2.0)]}; return ($v[$n/2-1]+$v[$n/2])/2.0 }
$base = @($rawRuns | Where-Object side -ceq baseline | ForEach-Object value)
$cand = @($rawRuns | Where-Object side -ceq candidate | ForEach-Object value)
$groups = @($rawRuns | Group-Object value | Sort-Object { [double]$_.Group[0].value })
$states = @{ '0,0' = [decimal]1 }; $first = 1; $candidateRankSum2 = 0
foreach ($group in $groups) {
    $m=$group.Count; $rank2=2*$first+$m-1; $first += $m
    $candidateRankSum2 += @($group.Group | Where-Object side -ceq candidate).Count * $rank2
    $next=@{}
    foreach($key in $states.Keys) {
        $parts=$key.Split(','); $count=[int]$parts[0]; $sum=[int]$parts[1]; $choose=[decimal]1
        for($k=0; $k -le [Math]::Min($m,24-$count); $k++) {
            if($k){$choose=$choose*($m-$k+1)/$k}
            $newKey="$($count+$k),$($sum+$k*$rank2)"
            if(-not $next.ContainsKey($newKey)){$next[$newKey]=[decimal]0}
            $next[$newKey]+=$states[$key]*$choose
        }
    }
    $states=$next
}
$total=[decimal]0; $extreme=[decimal]0; $target=1176; $distance=[Math]::Abs($candidateRankSum2-$target)
foreach($key in $states.Keys){$parts=$key.Split(',');if([int]$parts[0] -ne 24){continue};$total+=$states[$key];if([Math]::Abs([int]$parts[1]-$target) -ge $distance){$extreme+=$states[$key]}}
$p=[double]($extreme/$total); $u=($candidateRankSum2/2.0)-300.0
$baseMedian=Median $base; $candidateMedian=Median $cand; $change=($candidateMedian/$baseMedian-1)*100.0
if ($total -ne [decimal]32247603683100 -or [Math]::Abs($p-[double]$expectedLegacy.pValue) -gt 1e-12 -or [Math]::Abs($u-[double]$expectedLegacy.u) -gt 1e-12 -or $baseMedian -ne $expectedLegacy.baselineMedian -or $candidateMedian -ne $expectedLegacy.candidateMedian -or $expectedLegacy.verdict -cne 'improved') { throw "Independent DP mismatch total=$total p=$p expectedP=$($expectedLegacy.pValue) U=$u expectedU=$($expectedLegacy.u) base=$baseMedian expectedBase=$($expectedLegacy.baselineMedian) candidate=$candidateMedian expectedCandidate=$($expectedLegacy.candidateMedian) verdict=$($expectedLegacy.verdict)" }
$clock = $rawRuns[0].clock
$allPrepareSamples = @(foreach($run in $rawRuns){$path=Join-Path $root "Default-$($run.name).json";$r=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json -AsHashtable;foreach($round in $r.scenarios[0].rounds){foreach($v in $round.timingSamplesMs.prepare){[double]$v}}})
$offTick = @($allPrepareSamples | Where-Object { [Math]::Abs(([double]$_ * 10000)-[Math]::Round([double]$_ * 10000)) -gt 0.00001 }).Count
if ($offTick -ne 0) { throw 'Found prepare samples off the 100 ns QPC tick grid' }
if ([double]$clock.ticksPerSecond -ne 10000000 -or [double]$clock.tickNanoseconds -ne 100 -or [double]$clock.nominalPeriodNanoseconds -ne 1) { throw 'Unexpected recorded clock metadata' }
$out = [ordered]@{
    summarySha256=(Get-FileHash -LiteralPath $summaryPath -Algorithm SHA256).Hash
    scenario='Default'; metric='clean/prepareP95Ms'; receiptCount=$rawRuns.Count; baselineCount=24; candidateCount=24
    sourceIdentity=[ordered]@{baselineCommit=$s.baselineCommit;candidateCommit=$s.candidateCommit;baselineFingerprints=@($rawRuns|Where-Object side -ceq baseline|Select-Object -ExpandProperty sourceFingerprint -Unique);candidateFingerprints=@($rawRuns|Where-Object side -ceq candidate|Select-Object -ExpandProperty sourceFingerprint -Unique);baselineExecutables=@($rawRuns|Where-Object side -ceq baseline|Select-Object -ExpandProperty executableSha256 -Unique);candidateExecutables=@($rawRuns|Where-Object side -ceq candidate|Select-Object -ExpandProperty executableSha256 -Unique);benchmarkHashes=@($rawRuns|Select-Object -ExpandProperty benchmarkSha256 -Unique);allReceiptHashesMatchedSummary=$true}
    rawReplay=[ordered]@{baselineRunMedians=$base;candidateRunMedians=$cand;baselineMedianMs=$baseMedian;candidateMedianMs=$candidateMedian;changePercent=$change;candidateRankSum2=$candidateRankSum2;u=$u;extremeAssignments=$extreme;totalAssignments=$total;pValue=$p;legacyRecordedP=$expectedLegacy.pValue;legacyRecordedVerdict=$expectedLegacy.verdict;legacyBandPercent=$expectedLegacy.noisePercent;legacyBaselineSpreadPercent=$expectedLegacy.baselineSpreadPercent;legacyCandidateSpreadPercent=$expectedLegacy.candidateSpreadPercent}
    pairedJudge=[ordered]@{status=$scenario.set.status;metricMedianBaselineMs=$expectedPaired.baselineMedian;metricMedianCandidateMs=$expectedPaired.candidateMedian;changePercent=$expectedPaired.changePercent;pValue=$expectedPaired.pValue;adjustedPValue=$expectedPaired.adjustedPValue;blockEffects=$expectedPaired.blockEffects;verdict=$expectedPaired.verdict;verdictAgreement=$scenario.judgeComparison.verdictAgreement}
    clock=[ordered]@{name=$clock.name;implementation=$clock.implementation;ticksPerSecond=$clock.ticksPerSecond;tickNanoseconds=$clock.tickNanoseconds;nominalPeriodNanoseconds=$clock.nominalPeriodNanoseconds;roundCount=5;framesPerRound=40;prepareSampleCount=$allPrepareSamples.Count;prepareSamplesOn100nsGrid=($offTick -eq 0)}
    interpretation='The independent tied-rank DP reproduces a legacy clean preparation-time improvement (not regression). Paired Holm judge classifies this metric within-noise. Receipt hashes, source commits/fingerprints, executables and benchmark input hashes match the frozen summary. Quantized 100 ns preparation samples and earlier same-executable control instability limit causal attribution; this result does not establish non-regression or change qualification policy.'
}
$out | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $OutputPath -Encoding utf8
Write-Host "LEGACY_INDEPENDENT_AUDIT_PASS metric=clean/prepareP95Ms U=$u p=$p receipts=$($rawRuns.Count)"

