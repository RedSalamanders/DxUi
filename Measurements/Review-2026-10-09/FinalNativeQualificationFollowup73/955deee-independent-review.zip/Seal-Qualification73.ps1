Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$destination=[IO.Path]::GetFullPath('Measurements/Review-2026-10-09/FinalNativeQualificationFollowup73')
New-Item -ItemType Directory -Path $destination -Force|Out-Null
$manifest=[Collections.Generic.List[string]]::new()
$manifest.Add('Native head 955deeeeeeb78112a1a955b2634564804950c322; actual merge 554f9c929dc1216f1feebe4063dfc5f4190ef530; CI 38017295946. Later prose/evidence does not change compiled inputs; runtime receipts remain bound to this exact candidate.')
$tokens=$null;$errors=$null
$ast=[Management.Automation.Language.Parser]::ParseFile([IO.Path]::GetFullPath('.build/Seal-ReviewFollowup61.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Archive helper parse failure'}
$functions=@($ast.FindAll({param($node) $node -is [Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -in @('Seal-Packet','Get-PacketFiles')},$false))
if($functions.Count -ne 2){throw 'Missing reviewed archive helpers'}
foreach($function in $functions){Invoke-Expression $function.Extent.Text}
Seal-Packet '955deee-native-ci.zip' (Get-PacketFiles '.build/ci-38017295946-native')
Seal-Packet '955deee-paired-ci.zip' (Get-PacketFiles '.build/ci-38017295946-paired')
$files=[ordered]@{}
foreach($name in @('955deee-native-independent-audit73.json','955deee-extraction-hosted-audit73.json','955deee-resources-independent-audit73.json','955deee-native-timing-independent-audit73.json','955deee-paired-independent-audit73.json','955deee-paired-controls-independent-audit73.json','955deee-paired-timing-independent-audit73.json','955deee-legacy-independent-audit73.json','955deee-harness-independent-audit73.json','955deee-gallery-artifact-audit73.json','955deee-merge-provenance72.json','955deee-head-provenance72.json','955deee-jobs73.json','955deee-proof-only-source-attestation73.json','extraction70-committed-source-attestation72.json','extraction70-pe-footprint73.json','prepush-accounting72.json','Review-NativeProfiles73.ps1','Review-ExtractionHosted73.ps1','Review-MenuResources73.ps1','Review-HostedTiming66.ps1','Review-PairedPacket53.ps1','Review-AAControls55.ps1','Review-PairedTiming68.ps1','Review-Harness73.ps1','Review-Legacy73.ps1','Seal-Qualification73.ps1')){$files[$name]=".build/$name"}
foreach($name in @('955deee-paired-compact-outcomes73.json','955deee-tooling-and-consumer-audit73.json')){$files[$name]=".build/$name"}
foreach($name in @('native','resources','native-timing','paired','controls','paired-timing','harness','extraction','legacy')){$files["logs/$name-audit73.log"]=".build/logs/production-review-2026-10-10-955deee-${name}-audit73.log"}
foreach($name in @('windows-tooling','linux-validation','format','arm64-debug','arm64-release','arm64-asan','paired','gate')){$files["logs/ci-${name}73.log"]=".build/logs/production-review-2026-10-10-ci-955deee-${name}73.log"}
foreach($name in @('prepush72-explain','prepush72')){$files["logs/$name.log"]=".build/logs/production-review-2026-10-10-$name.log"}
Seal-Packet '955deee-independent-review.zip' $files
$manifest|Set-Content (Join-Path $destination 'archive-manifest.txt') -Encoding utf8
