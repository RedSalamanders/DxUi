## Paired benchmark: Inconclusive

The study cannot qualify a pass: policy review, missing identity, drifting controls or insufficient evidence leaves the result unresolved. Re-run or complete independent policy review; do not dismiss flagged metrics as noise.

Policy review required: The base policy is not independently qualified; its verdict cannot establish a candidate pass.

This run was started by hand: the job stays green for a finding, and a pull request would fail on it.

| | |
|---|---|
| Baseline | `2b0679294633` |
| Candidate | `2b0679294633` |
| Library inputs | identical, fingerprint `CF33A85A9BE4`: both sides ran the same library code |
| Method | 12 independent paired blocks; seed 490514517; independently drawn ABBA/BAAB; exact sign-flip with Holm correction; x64 Release; 5% timing and 2% memory bands, exact budgets stay exact |
| Runner | runnervmfi6oq; a shared hosted VM, not a controlled quiet desktop |
| Event | manual dispatch on codex/production-review-remediation-2026-10-08 |

### Scenarios

| Scenario | Check | Set verdict | Regressed | Improved | Metrics held by controls | Controls stable |
|---|---|---|---:|---:|---:|---:|
| Default | No regression established | within-noise-budget | 0 | 0 | 8 of 26 | 0 of 24 |
| MultilineGrid | No regression established | within-noise-budget | 0 | 0 | 8 of 26 | 0 of 24 |
| MultilineGridDistinct | No regression established | within-noise-budget | 0 | 0 | 12 of 26 | 0 of 24 |

### Flagged metrics

None: no metric regressed or improved.

<details><summary>Default: all 26 metrics</summary>

| Phase | Metric | Baseline median | Candidate median | Change | Raw p | Holm-adjusted p | Band | Same-binary controls | Baseline raw max | Candidate raw max | Median budget | Peak budget | Outcome |
|---|---|---|---:|---:|---:|---:|---:|---|---:|---:|---|---|---|
| clean | fps | 349.5 | 350.3 | +1.30% | 0.4453 | 1.0000 | 5% | 17.1% max, beyond band | 360.6 | 361.3 | not-applicable | not-applicable | within noise |
| clean | frameP50Ms | 2.8167 | 2.8168 | -1.27% | 0.5493 | 1.0000 | 5% | 20.6% max, beyond band | 3.4138 | 3.3963 | not-applicable | not-applicable | within noise |
| clean | frameP95Ms | 3.0025 | 3.0014 | -0.13% | 0.9346 | 1.0000 | 5% | 18.2% max, beyond band | 5.3977 | 5.2158 | not-applicable | not-applicable | within noise |
| clean | prepareP95Ms | 0.0006 | 0.0006 | +4.34% | 0.5586 | 1.0000 | 5% | 60.0% max, beyond band | 0.0011 | 0.0011 | not-applicable | not-applicable | within noise |
| clean | composeCpuP95Ms | 0.0257 | 0.0259 | -0.38% | 0.8799 | 1.0000 | 5% | 27.4% max, beyond band | 0.0486 | 0.0525 | not-applicable | not-applicable | within noise |
| clean | privateBytes | 23,367,680 | 23,435,264 | +0.21% | 0.0938 | 1.0000 | 2% | 2.2% max, beyond band | 23,699,456 | 23,740,416 | not-applicable | not-applicable | within noise |
| clean | privatePeakBytes | 23,367,680 | 23,443,456 | +0.24% | 0.0591 | 1.0000 | 2% | 2.2% max, beyond band | 24,301,568 | 24,309,760 | not-applicable | not-applicable | within noise |
| clean | workingSetBytes | 36,845,568 | 36,904,960 | -0.13% | 0.3989 | 1.0000 | 2% | 3.6% max, beyond band | 38,187,008 | 37,093,376 | not-applicable | not-applicable | within noise |
| clean | workingSetPeakBytes | 36,868,096 | 36,931,584 | -0.13% | 0.3853 | 1.0000 | 2% | 3.6% max, beyond band | 38,727,680 | 37,687,296 | not-applicable | not-applicable | within noise |
| clean | surfaceBytes | 3,686,400 | 3,686,400 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 3,686,400 | 3,686,400 | within-budget | within-budget | within noise |
| clean | replacementPeakBytes | 3,686,400 | 3,686,400 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 3,686,400 | 3,686,400 | within-budget | within-budget | within noise |
| clean | cppAllocations | 0 | 0 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 0 | 0 | within-budget | within-budget | within noise |
| clean | composeAllocations | 0 | 0 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 0 | 0 | within-budget | within-budget | within noise |
| dirty | fps | 162.6 | 164.4 | +0.93% | 0.6899 | 1.0000 | 5% | 25.4% max, beyond band | 173.5 | 173.5 | not-applicable | not-applicable | within noise |
| dirty | frameP50Ms | 5.946 | 5.9607 | -1.12% | 0.4648 | 1.0000 | 5% | 20.3% max, beyond band | 7.5523 | 7.5853 | not-applicable | not-applicable | within noise |
| dirty | frameP95Ms | 6.8669 | 6.3889 | -6.14% | 0.0952 | 1.0000 | 5% | 30.8% max, beyond band | 12.834 | 9.2135 | not-applicable | not-applicable | within noise |
| dirty | prepareP95Ms | 2.4345 | 2.4071 | -2.19% | 0.5732 | 1.0000 | 5% | 48.4% max, beyond band | 3.8573 | 3.9457 | not-applicable | not-applicable | within noise |
| dirty | composeCpuP95Ms | 0.0145 | 0.0148 | +0.47% | 0.8921 | 1.0000 | 5% | 21.1% max, beyond band | 0.0264 | 0.0268 | not-applicable | not-applicable | within noise |
| dirty | privateBytes | 23,674,880 | 23,687,168 | +0.19% | 0.2642 | 1.0000 | 2% | 2.1% max, beyond band | 24,264,704 | 24,154,112 | not-applicable | not-applicable | within noise |
| dirty | privatePeakBytes | 23,728,128 | 23,771,136 | +0.13% | 0.5557 | 1.0000 | 2% | 2.5% max, beyond band | 24,272,896 | 24,174,592 | not-applicable | not-applicable | within noise |
| dirty | workingSetBytes | 37,220,352 | 37,160,960 | -0.24% | 0.0400 | 1.0000 | 2% | 3.0% max, beyond band | 38,563,840 | 37,433,344 | not-applicable | not-applicable | within noise |
| dirty | workingSetPeakBytes | 37,222,400 | 37,177,344 | -0.24% | 0.0391 | 1.0000 | 2% | 3.0% max, beyond band | 38,572,032 | 37,441,536 | not-applicable | not-applicable | within noise |
| dirty | surfaceBytes | 3,686,400 | 3,686,400 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 3,686,400 | 3,686,400 | within-budget | within-budget | within noise |
| dirty | replacementPeakBytes | 3,686,400 | 3,686,400 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 3,686,400 | 3,686,400 | within-budget | within-budget | within noise |
| dirty | cppAllocations | 2,160 | 2,160 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 2,160 | 2,160 | within-budget | within-budget | within noise |
| dirty | composeAllocations | 0 | 0 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 0 | 0 | within-budget | within-budget | within noise |

</details>

<details><summary>MultilineGrid: all 26 metrics</summary>

| Phase | Metric | Baseline median | Candidate median | Change | Raw p | Holm-adjusted p | Band | Same-binary controls | Baseline raw max | Candidate raw max | Median budget | Peak budget | Outcome |
|---|---|---|---:|---:|---:|---:|---:|---|---:|---:|---|---|---|
| clean | fps | 348.5 | 343.1 | -2.28% | 0.4849 | 1.0000 | 5% | 26.0% max, beyond band | 361.6 | 361.4 | not-applicable | not-applicable | within noise |
| clean | frameP50Ms | 2.8246 | 2.8284 | +2.59% | 0.4092 | 1.0000 | 5% | 17.5% max, beyond band | 3.5087 | 3.6635 | not-applicable | not-applicable | within noise |
| clean | frameP95Ms | 3.1128 | 3.2603 | +0.89% | 0.7920 | 1.0000 | 5% | 39.5% max, beyond band | 6.0427 | 5.7452 | not-applicable | not-applicable | within noise |
| clean | prepareP95Ms | 0.0006 | 0.0006 | +3.44% | 0.7344 | 1.0000 | 5% | 150.0% max, beyond band | 0.0014 | 0.0014 | not-applicable | not-applicable | within noise |
| clean | composeCpuP95Ms | 0.0263 | 0.0256 | +2.03% | 0.6978 | 1.0000 | 5% | 85.3% max, beyond band | 0.0439 | 0.0465 | not-applicable | not-applicable | within noise |
| clean | privateBytes | 28,686,336 | 28,717,056 | +0.02% | 0.9375 | 1.0000 | 2% | 3.5% max, beyond band | 29,921,280 | 29,560,832 | not-applicable | not-applicable | within noise |
| clean | privatePeakBytes | 28,715,008 | 28,755,968 | +0.01% | 0.9756 | 1.0000 | 2% | 3.5% max, beyond band | 32,292,864 | 32,612,352 | not-applicable | not-applicable | within noise |
| clean | workingSetBytes | 41,871,360 | 41,902,080 | -0.11% | 0.5669 | 1.0000 | 2% | 4.3% max, beyond band | 43,634,688 | 42,823,680 | not-applicable | not-applicable | within noise |
| clean | workingSetPeakBytes | 41,902,080 | 41,916,416 | -0.12% | 0.5366 | 1.0000 | 2% | 4.3% max, beyond band | 44,175,360 | 44,056,576 | not-applicable | not-applicable | within noise |
| clean | surfaceBytes | 3,686,400 | 3,686,400 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 3,686,400 | 3,686,400 | within-budget | within-budget | within noise |
| clean | replacementPeakBytes | 3,686,400 | 3,686,400 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 3,686,400 | 3,686,400 | within-budget | within-budget | within noise |
| clean | cppAllocations | 0 | 0 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 0 | 0 | within-budget | within-budget | within noise |
| clean | composeAllocations | 0 | 0 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 0 | 0 | within-budget | within-budget | within noise |
| dirty | fps | 64.5 | 64.4 | -1.05% | 0.6987 | 1.0000 | 5% | 17.1% max, beyond band | 70.0 | 70.9 | not-applicable | not-applicable | within noise |
| dirty | frameP50Ms | 15.0478 | 15.1151 | +0.51% | 0.7749 | 1.0000 | 5% | 11.7% max, beyond band | 18.8401 | 18.2843 | not-applicable | not-applicable | within noise |
| dirty | frameP95Ms | 16.3886 | 17.1798 | +2.03% | 0.5239 | 1.0000 | 5% | 18.0% max, beyond band | 24.9185 | 23.5713 | not-applicable | not-applicable | within noise |
| dirty | prepareP95Ms | 12.7299 | 13.1619 | +2.03% | 0.4829 | 1.0000 | 5% | 16.2% max, beyond band | 18.015 | 16.7999 | not-applicable | not-applicable | within noise |
| dirty | composeCpuP95Ms | 0.0185 | 0.0176 | -5.83% | 0.0713 | 1.0000 | 5% | 156.1% max, beyond band | 0.0864 | 0.0412 | not-applicable | not-applicable | within noise |
| dirty | privateBytes | 29,644,800 | 29,175,808 | -0.97% | 0.3843 | 1.0000 | 2% | 13.0% max, beyond band | 31,182,848 | 31,129,600 | not-applicable | not-applicable | within noise |
| dirty | privatePeakBytes | 30,873,600 | 30,593,024 | -0.67% | 0.1162 | 1.0000 | 2% | 5.4% max, beyond band | 31,875,072 | 31,363,072 | not-applicable | not-applicable | within noise |
| dirty | workingSetBytes | 42,252,288 | 41,961,472 | -0.79% | 0.3477 | 1.0000 | 2% | 7.4% max, beyond band | 44,539,904 | 43,905,024 | not-applicable | not-applicable | within noise |
| dirty | workingSetPeakBytes | 43,085,824 | 42,936,320 | -0.34% | 0.1128 | 1.0000 | 2% | 3.5% max, beyond band | 44,773,376 | 44,216,320 | not-applicable | not-applicable | within noise |
| dirty | surfaceBytes | 3,686,400 | 3,686,400 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 3,686,400 | 3,686,400 | within-budget | within-budget | within noise |
| dirty | replacementPeakBytes | 3,686,400 | 3,686,400 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 3,686,400 | 3,686,400 | within-budget | within-budget | within noise |
| dirty | cppAllocations | 1,080 | 1,080 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 1,080 | 1,080 | within-budget | within-budget | within noise |
| dirty | composeAllocations | 0 | 0 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 0 | 0 | within-budget | within-budget | within noise |

</details>

<details><summary>MultilineGridDistinct: all 26 metrics</summary>

| Phase | Metric | Baseline median | Candidate median | Change | Raw p | Holm-adjusted p | Band | Same-binary controls | Baseline raw max | Candidate raw max | Median budget | Peak budget | Outcome |
|---|---|---|---:|---:|---:|---:|---:|---|---:|---:|---|---|---|
| clean | fps | 299.0 | 299.6 | +1.74% | 0.4150 | 1.0000 | 5% | 20.3% max, beyond band | 360.8 | 361.6 | not-applicable | not-applicable | within noise |
| clean | frameP50Ms | 3.3191 | 3.3173 | -1.11% | 0.5176 | 1.0000 | 5% | 21.0% max, beyond band | 3.8803 | 3.5517 | not-applicable | not-applicable | within noise |
| clean | frameP95Ms | 3.463 | 3.4544 | -2.75% | 0.5786 | 1.0000 | 5% | 40.6% max, beyond band | 6.530 | 6.3614 | not-applicable | not-applicable | within noise |
| clean | prepareP95Ms | 0.0006 | 0.0005 | -8.26% | 0.2734 | 1.0000 | 5% | 66.7% max, beyond band | 0.0012 | 0.0012 | not-applicable | not-applicable | within noise |
| clean | composeCpuP95Ms | 0.027 | 0.0257 | -5.84% | 0.0522 | 1.0000 | 5% | 38.4% max, beyond band | 0.0485 | 0.0347 | not-applicable | not-applicable | within noise |
| clean | privateBytes | 25,268,224 | 25,210,880 | -0.02% | 0.8843 | 1.0000 | 2% | 1.2% max, held | 25,833,472 | 25,575,424 | not-applicable | not-applicable | within noise |
| clean | privatePeakBytes | 25,298,944 | 25,278,464 | -0.03% | 0.8872 | 1.0000 | 2% | 1.8% max, held | 26,230,784 | 26,210,304 | not-applicable | not-applicable | within noise |
| clean | workingSetBytes | 38,674,432 | 38,668,288 | -0.05% | 0.5518 | 1.0000 | 2% | 0.9% max, held | 39,002,112 | 38,883,328 | not-applicable | not-applicable | within noise |
| clean | workingSetPeakBytes | 38,696,960 | 38,690,816 | -0.06% | 0.5259 | 1.0000 | 2% | 0.9% max, held | 39,534,592 | 39,501,824 | not-applicable | not-applicable | within noise |
| clean | surfaceBytes | 3,686,400 | 3,686,400 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 3,686,400 | 3,686,400 | within-budget | within-budget | within noise |
| clean | replacementPeakBytes | 3,686,400 | 3,686,400 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 3,686,400 | 3,686,400 | within-budget | within-budget | within noise |
| clean | cppAllocations | 0 | 0 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 0 | 0 | within-budget | within-budget | within noise |
| clean | composeAllocations | 0 | 0 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 0 | 0 | within-budget | within-budget | within noise |
| dirty | fps | 137.6 | 135.6 | +0.02% | 0.9883 | 1.0000 | 5% | 29.0% max, beyond band | 167.7 | 168.7 | not-applicable | not-applicable | within noise |
| dirty | frameP50Ms | 6.8753 | 6.9141 | +0.12% | 0.9375 | 1.0000 | 5% | 22.0% max, beyond band | 8.353 | 8.6213 | not-applicable | not-applicable | within noise |
| dirty | frameP95Ms | 8.7337 | 8.2083 | -0.99% | 0.7813 | 1.0000 | 5% | 35.7% max, beyond band | 16.8091 | 11.3221 | not-applicable | not-applicable | within noise |
| dirty | prepareP95Ms | 3.4489 | 3.463 | +1.06% | 0.7603 | 1.0000 | 5% | 53.4% max, beyond band | 4.9294 | 5.4541 | not-applicable | not-applicable | within noise |
| dirty | composeCpuP95Ms | 0.0141 | 0.0144 | +1.46% | 0.6450 | 1.0000 | 5% | 39.8% max, beyond band | 0.0272 | 0.0507 | not-applicable | not-applicable | within noise |
| dirty | privateBytes | 25,638,912 | 25,638,912 | +0.19% | 0.2793 | 1.0000 | 2% | 4.1% max, beyond band | 26,103,808 | 26,808,320 | not-applicable | not-applicable | within noise |
| dirty | privatePeakBytes | 25,729,024 | 25,735,168 | +0.15% | 0.0928 | 1.0000 | 2% | 4.4% max, beyond band | 26,152,960 | 26,951,680 | not-applicable | not-applicable | within noise |
| dirty | workingSetBytes | 39,344,128 | 39,268,352 | -0.02% | 0.8896 | 1.0000 | 2% | 2.7% max, beyond band | 39,747,584 | 40,361,984 | not-applicable | not-applicable | within noise |
| dirty | workingSetPeakBytes | 39,344,128 | 39,268,352 | 0.00% | 0.9785 | 1.0000 | 2% | 3.0% max, beyond band | 39,747,584 | 40,415,232 | not-applicable | not-applicable | within noise |
| dirty | surfaceBytes | 3,686,400 | 3,686,400 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 3,686,400 | 3,686,400 | within-budget | within-budget | within noise |
| dirty | replacementPeakBytes | 3,686,400 | 3,686,400 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 3,686,400 | 3,686,400 | within-budget | within-budget | within noise |
| dirty | cppAllocations | 1,080 | 1,080 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 1,080 | 1,080 | within-budget | within-budget | within noise |
| dirty | composeAllocations | 0 | 0 | 0.00% | 1.0000 | 1.0000 | exact | 0.0% max, held | 0 | 0 | within-budget | within-budget | within noise |

</details>

The retained receipts, comparisons and `summary.json` are in the `paired-benchmark-x64-Release` artifact. Migrated timing and memory metrics use the Holm-adjusted p-value and declared band; legacy rows retain their original raw p-value and show no adjusted p-value. Exact-budget rows report median and raw-peak findings separately. `Specs/Core/Core_PerformanceAndResources.md` says what a verdict establishes and what a finding requires.
