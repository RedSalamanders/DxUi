Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root='.build/ci-38007965422-native/native-x64-Release'
$records=@(foreach ($suite in @('MenuResourceScaling','MenuTextLayoutResources')) {
    # Scaling needs a foreground lease; text layout resources is an offscreen nonactivating fixture.
    $suffix=if ($suite -ceq 'MenuResourceScaling') {'.hosted'} else {''}
    $path=Join-Path $root "reports/$suite-x64-Release$suffix.json"
    $report=Get-Content $path -Raw | ConvertFrom-Json -AsHashtable
    $log=Join-Path $root "logs/test-$suite-x64-Release$suffix.log"
    $performancePath=Join-Path $root "reports/$([IO.Path]::GetFileName($report.performanceReport))"
    $performance=Get-Content $performancePath -Raw | ConvertFrom-Json -AsHashtable
    if ($report.exitCode -ne 0 -or $report.skips.Count -ne 0 -or $performance.sourceCommit -cne 'd55feb8d6fda0eefc704ae95ab25f2c960ef399c' -or (Get-Content $log -Raw) -notmatch 'All DxUi tests passed\.') {throw "Invalid resource evidence: $suite"}
    if (($report.performanceScenarios | ConvertTo-Json -Depth 20 -Compress) -cne ($performance.scenarios | ConvertTo-Json -Depth 20 -Compress)) {throw 'Copied resource performance rounds differ'}
    $lease=if ($report.Contains('lease')) {$report.lease} else {$null}
    if ($suffix) {
        if ($null -eq $lease -or $lease.state -cne 'completed' -or $lease.exitCode -ne 0 -or $lease.mode -cne 'verified-github-hosted') {throw 'Missing/failed resource foreground lease'}
        foreach ($key in @('foreground','focus','cursor')) {if ($lease[$key] -ceq 'failed') {throw "Failed resource lease restoration: $key"}}
    } elseif ($null -ne $lease) {throw 'Unexpected input lease for noninteractive text layout resource fixture'}
    [ordered]@{suite=$suite;exitCode=$report.exitCode;skips=$report.skips.Count;lease=$lease;reportSha256=(Get-FileHash $path).Hash;logSha256=(Get-FileHash $log).Hash;performanceSha256=(Get-FileHash $performancePath).Hash}
})
$records | ConvertTo-Json -Depth 8 | Set-Content .build/2b067-resources-independent-audit61.json
Write-Host 'INDEPENDENT_RESOURCE_AUDIT_COMPLETE: scaling lease and noninteractive text layout fixture verified.'
