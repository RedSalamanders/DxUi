param([Parameter(Mandatory)][string] $Root)
$ErrorActionPreference='Stop'
function SetFile([string]$Relative,[string]$Text) {
    [IO.File]::WriteAllText((Join-Path $Root $Relative),$Text,[Text.UTF8Encoding]::new($false))
}
function ReadFile([string]$Relative) { [IO.File]::ReadAllText((Join-Path $Root $Relative)) }
$plan=ReadFile 'Specs/Plans/WIP/PreparedTreeAccessibility_2026-10-06.md'
$plan=$plan.Replace('- [ ] Validate the final current-source','- [x] Validate the final current-source').Replace('- [ ] Complete exact-source x64','- [x] Complete exact-source x64')
$plan=$plan.Replace('- [ ] Review retained results, reconcile capability/documentation claims and merge only a correct, qualified candidate.', '- [x] Independently review retained results and reconcile capability/documentation claims for the authorized library integration. Formal performance-policy approval is explicitly separate from these scoped functional results.')
$marker='Documentation/gallery review:'
$closeout=@'
Status: **LIBRARY IMPLEMENTATION COMPLETE.** Source `8e446386e06d10eaf3035cdd703206e75eaf7ab6`
and its identical PR merge tree pass 122 suite executions across the six x64/ARM64 Debug, Release and ASan Debug
profiles, eight relocated consumer fixtures and both deliberate sanitizer probes. All four native prepared-Tree
cases and four real embedded client cases pass in every profile. Local Debug/ASan affected suites, validators
and formatting also pass. The [current evidence](../../../Measurements/PreparedTreeAccessibility/2026-10-10/README.md)
retains source/product identities, failures, raw reports and the independent audits.

Remaining qualification is transferred explicitly, rather than reported as passed: ARM64 Menu and NativeTextInput
each refused the hosted foreground lease in all three profiles (six unexecuted suites); Q22 in
[ProductionReview](../WIP/ProductionReview_2026-10-05.md) owns formal performance-policy acceptance. Two fresh
12-block, three-scenario paired studies retain 288 reports with zero regression flags under either method and
unchanged exact budgets, but both formal verdicts remain `inconclusive`: the base policy is unqualified and controls
are frequently unstable. RedPrism adoption, charged-source ownership and product activation remain **HOLD** in
the [API-4 consumer register](../WIP/ProductionReview_2026-10-05/api4-consumer-handoffs.md). No consumer migration is closed.

'@
$plan=$plan.Replace($marker,$closeout+"`r`n"+$marker).Replace('## Implementation checklist','## Historical implementation checklist - 2026-10-06')
$plan=[regex]::Replace($plan,'(?m)^Status: \*\*ACTIVE;[^\r\n]+','Historical status: the following source-specific record predates the current library closeout. Its old pending consumer and paired requirements are superseded by the current evidence and explicitly transferred qualification above; no old receipt is requalified.')
$plan=[regex]::Replace($plan,'(?m)^- \[ \] (Complete exact-pin consumer qualification:[^\r\n]+)','- **Transferred consumer HOLD (historically unexecuted):** $1')
$plan=[regex]::Replace($plan,'(?m)^- \[ \] (Run and review matched paired complex-UI[^\r\n]+)','- **Superseded historical obligation (not executed for that source):** $1')
$plan=[regex]::Replace($plan,'(?m)^- \[ \] (Qualify RedPrism[^\r\n]+)','- **Transferred consumer HOLD (historically unexecuted):** $1')
SetFile 'Specs/Plans/Done/PreparedTreeAccessibility_2026-10-06.md' $plan
$oldPath=(Resolve-Path -LiteralPath (Join-Path $Root 'Specs/Plans/WIP/PreparedTreeAccessibility_2026-10-06.md')).Path
if(! $oldPath.StartsWith(([IO.Path]::GetFullPath($Root).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar),[StringComparison]::OrdinalIgnoreCase)){throw 'Plan path outside target checkout'}
Remove-Item -LiteralPath $oldPath
$index=ReadFile 'Specs/Plans/WIP/README.md'
$index=[regex]::Replace($index,'(?m)^- \*\*ACTIVE\*\*: \[Prepared Tree accessibility\][^\r\n]+\r?\n?','')
$index=$index.Replace('`../Done/EmbeddedInteractionLayout_2026-10-06.md`.', '`../Done/EmbeddedInteractionLayout_2026-10-06.md` and`r`n`../Done/PreparedTreeAccessibility_2026-10-06.md`.'.Replace('`r`n',"`r`n"))
SetFile 'Specs/Plans/WIP/README.md' $index.TrimEnd()+"`r`n"
$uia=ReadFile 'Specs/UI/UI_InputAndAccessibility.md'
$uia=$uia.Replace('there is no synchronous delivery fallback. Property/text/'+"`r`n"+'focus events retain their separate event contracts.', 'there is no synchronous delivery fallback. Selection, text and'+"`r`n"+'focus events retain their separate event contracts; embedded control-property transport is described below.')
SetFile 'Specs/UI/UI_InputAndAccessibility.md' $uia
$tree=ReadFile 'Specs/DesignSystem/components/Tree/README.md'
$tree=$tree.Replace('The [library qualification](../../../../Measurements/PreparedTreeAccessibility/2026-10-06/README.md)', 'The [current library evidence](../../../../Measurements/PreparedTreeAccessibility/2026-10-10/README.md)')
$tree=$tree.Replace('The preview is a static HTML rendition styled by `bundle.css` from the tokens; the real control is painted by DxUi.lib with Direct2D. The gallery captures under Assets › Gallery are the authoritative rendering.'+"`r`n`r`n",'')
SetFile 'Specs/DesignSystem/components/Tree/README.md' $tree
$measurements=ReadFile 'Measurements/README.md'
$entry=@'
- [Prepared Tree accessibility finish, 2026-10-10](PreparedTreeAccessibility/2026-10-10/README.md): current-main integration,
  real native/embedded UIA reentry and source retirement, six-profile scoped validation and two fresh paired studies.
  Formal benchmark-policy acceptance and ARM64 foreground qualification remain open; consumer adoption is separate.

'@
$measurements=$measurements.Replace('- [Embedded interaction layout, 2026-10-06]',$entry+"`r`n"+'- [Embedded interaction layout, 2026-10-06]')
SetFile 'Measurements/README.md' $measurements
