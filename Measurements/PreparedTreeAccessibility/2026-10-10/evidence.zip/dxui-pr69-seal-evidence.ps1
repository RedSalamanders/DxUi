param([Parameter(Mandatory)][string] $Source, [Parameter(Mandatory)][string] $Archive, [Parameter(Mandatory)][string] $Manifest)
$ErrorActionPreference = 'Stop'
$sourcePath = (Resolve-Path -LiteralPath $Source).Path
$entries = @(Get-ChildItem -LiteralPath $sourcePath -Recurse -File | ForEach-Object {
    [ordered]@{path=[IO.Path]::GetRelativePath($sourcePath,$_.FullName).Replace('\','/');length=$_.Length;sha256=(Get-FileHash -LiteralPath $_.FullName).Hash}
})
[IO.Compression.ZipFile]::CreateFromDirectory($sourcePath,[IO.Path]::GetFullPath($Archive),[IO.Compression.CompressionLevel]::Optimal,$false)
$zip = [IO.Compression.ZipFile]::OpenRead([IO.Path]::GetFullPath($Archive))
try {
    $files = @($zip.Entries | Where-Object {$_.Name})
    if ($files.Count -ne $entries.Count) { throw 'Archive entry count differs.' }
    foreach ($entry in $entries) {
        $member = $zip.GetEntry($entry.path)
        if (!$member -or $member.Length -ne $entry.length) { throw "Archived length/path differs: $($entry.path)" }
        $stream = $member.Open()
        try { $hash = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream)) }
        finally { $stream.Dispose() }
        if ($hash -cne $entry.sha256) { throw "Archived bytes differ: $($entry.path)" }
    }
} finally { $zip.Dispose() }
$entries | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $Manifest -Encoding utf8NoBOM
[pscustomobject]@{archive=$Archive;entries=$entries.Count;sha256=(Get-FileHash -LiteralPath $Archive).Hash;manifestSha256=(Get-FileHash -LiteralPath $Manifest).Hash} | ConvertTo-Json
