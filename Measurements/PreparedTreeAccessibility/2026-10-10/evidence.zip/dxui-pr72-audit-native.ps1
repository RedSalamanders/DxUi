param(
    [Parameter(Mandatory)][string] $Root,
    [Parameter(Mandatory)][string] $MergeCommit,
    [Parameter(Mandatory)][string] $Fingerprint, [int] $ExpectedProfiles=6
)
$ErrorActionPreference = 'Stop'
Import-Module Z:/src/DxUi/Tools/PerformanceComparison.psm1 -Force
$profiles = @()
foreach ($directory in Get-ChildItem -LiteralPath $Root -Directory -Filter 'native-*') {
    $reportDirectory = Join-Path $directory.FullName 'reports'
    $logDirectory = Join-Path $directory.FullName 'logs'
    $suites = @()
    $consumers = @()
    $probes = @()
    $benchmarks = @()
    foreach ($file in Get-ChildItem -LiteralPath $reportDirectory -File -Filter '*.json') {
        $data = Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json -AsHashtable
        if (!$data.ContainsKey('suite')) { continue }
        if ($data.suite -eq 'ExternalConsumer') {
            if ($data.commit -ne $MergeCommit -or $data.exitCode -ne 0 -or
                $data.nativeModuleChecks -ne 12 -or $data.negativeChecks -ne 10 -or
                $data.buildIdentity.Identity.commit -ne $MergeCommit -or $data.buildIdentity.Identity.apiRevision -ne 4) {
                throw "Consumer provenance/result mismatch: $($file.FullName)"
            }
            $consumers += [ordered]@{ configuration=$data.configuration; platform=$data.platform;
                disableStlAnnotations=$data.disableStlAnnotations; exitCode=$data.exitCode;
                nativeArchitecture=$data.nativeArchitecture; executableSha256=$data.executableSha256;
                librarySha256=$data.librarySha256; receiptSha256=(Get-FileHash -LiteralPath $file.FullName).Hash }
            continue
        }
        $log = Get-ChildItem -LiteralPath $logDirectory -File -Filter "test-$($data.suite)-*.log" | Select-Object -First 1
        if (!$log) { throw "Missing suite log: $($file.FullName)" }
        $body = Get-Content -LiteralPath $log.FullName -Raw
        if ($data.suite -eq 'AddressSanitizer') {
            if (!$data.detected -or $data.exitCode -eq 0 -or $body -notmatch 'AddressSanitizer: heap-use-after-free') {
                throw "Sanitizer did not detect the deliberate probe: $($file.FullName)"
            }
            $probes += [ordered]@{ detected=$data.detected; exitCode=$data.exitCode; receiptSha256=(Get-FileHash -LiteralPath $file.FullName).Hash }
            continue
        }
        if (!$data.ContainsKey('skips') -or $data.skips.Count -ne 0) { throw "Missing/partial suite receipt: $($file.FullName)" }
        $leaseRefusal = $data.platform -eq 'ARM64' -and $data.suite -in 'Menu','NativeTextInput' -and $data.exitCode -eq 24 -and
            $body -match ('\[LEASE\] ' + $data.suite + ' did not run under the foreground lease')
        $passed = switch ($data.suite) {
            'Embedded' { $body -match '(?m)^PASS [0-9]+ checks;' }
            'Foundation' { $body -match 'Foundation tests: PASS' }
            'MenuExitLifetime' { $body -match '\[EXIT\] MenuExitLifetime: active menu is dismissed' }
            default { $body -match 'All DxUi tests passed' }
        }
        if (!$leaseRefusal -and ($data.exitCode -ne 0 -or !$passed)) { throw "Unexpected suite failure: $($file.FullName)" }
        if ($data.ContainsKey('lease') -and !$leaseRefusal) {
            if (!$data.lease.hosted -or $data.lease.mode -ne 'verified-github-hosted' -or $data.lease.state -ne 'completed' -or
                $data.lease.exitCode -ne 0 -or $data.lease.foreground -notin @('restored','unchanged') -or
                $data.lease.focus -notin @('restored','unchanged') -or $data.lease.cursor -notin @('restored','unchanged')) {
                throw "Incomplete foreground restoration: $($file.FullName)"
            }
        }
        $suites += [ordered]@{ suite=$data.suite; exitCode=$data.exitCode; skipCount=$data.skips.Count;
            result=$(if($leaseRefusal){'foreground-not-executed'}else{'pass'}); executableSha256=$data.sha256;
            receiptSha256=(Get-FileHash -LiteralPath $file.FullName).Hash; logSha256=(Get-FileHash -LiteralPath $log.FullName).Hash; lease=$(if($data.ContainsKey('lease')){$data.lease}else{$null}) }
    }
    foreach ($file in Get-ChildItem -LiteralPath $reportDirectory -File -Filter 'Performance-*.json' | Where-Object Name -NotLike '*.comparison.json') {
        $data = Read-PerformanceReceipt $file.FullName
        Assert-PerformanceReceipt $data
        if ($data.sourceCommit -ne $MergeCommit -or $data.sourceFingerprint -ne $Fingerprint) { throw "Benchmark source mismatch: $($file.FullName)" }
        $benchmarks += [ordered]@{ file=$file.Name; sourceCommit=$data.sourceCommit; sourceFingerprint=$data.sourceFingerprint;
            executableSha256=$data.executableSha256; sha256=(Get-FileHash -LiteralPath $file.FullName).Hash }
    }
    $accessibility = Get-ChildItem -LiteralPath $logDirectory -File -Filter 'test-Accessibility-*.log' | Select-Object -First 1
    $rendering = Get-ChildItem -LiteralPath $logDirectory -File -Filter 'test-Rendering-*.log' | Select-Object -First 1
    $completed = @(Select-String -LiteralPath $accessibility.FullName -Pattern '\[DONE\] TestGridUiaPattern' | ForEach-Object {$_.Line.Trim()})
    if ($completed.Count -ne 10 -or !($completed -match 'PreservesAssignmentDuringCachedCellCreation') -or !($completed -match 'PreservesAssignmentDuringRowNavigation')) { throw "Missing current GridPattern cases: $($directory.Name)" }
    $prepared = @(Select-String -LiteralPath $accessibility.FullName -Pattern '\[DONE\] TestPreparedTree' | ForEach-Object {$_.Line.Trim()})
    if ($prepared.Count -ne 4 -or !($prepared -match 'InvalidCountFallsBack') -or !($prepared -match 'CaptureCanRetireItsControl')) { throw "Missing prepared Tree native cases: $($directory.Name)" }
    $embedded = Get-ChildItem -LiteralPath $logDirectory -File -Filter 'test-Embedded-*.log' | Select-Object -First 1
    $clients = @(Select-String -LiteralPath $embedded.FullName -Pattern '^\[PREPARED TREE CLIENT\]' | ForEach-Object {$_.Line.Trim()})
    if ($clients.Count -ne 4 -or @($clients | Where-Object {$_ -notmatch 'notified=1 read=0 invoke=0'}).Count -ne 0 -or
        @($clients | Where-Object {$_ -match 'replacements=1$'}).Count -ne 3 -or
        @($clients | Where-Object {$_ -match 'replacements=0$'}).Count -ne 1) { throw "Missing prepared Tree embedded event/reentry cases: $($directory.Name)" }
    $presentation = @(Select-String -LiteralPath $rendering.FullName -Pattern '\[DONE\] TestAttachedHostFirstPartialPaintPresentsFullAfterCreateAndResize' | ForEach-Object {$_.Line.Trim()})
    if ($presentation.Count -ne 1) { throw "Missing first-presentation case: $($directory.Name)" }
    $expectedConsumers = if ($directory.Name -like '*ASan Debug') { 2 } else { 1 }
    $expectedSuites = if ($directory.Name -eq 'native-x64-Release') { 23 } else { 21 }
    if ($consumers.Count -ne $expectedConsumers -or $suites.Count -ne $expectedSuites -or $benchmarks.Count -eq 0) {
        throw "Incomplete native/consumer profile: $($directory.Name)"
    }
    $profiles += [ordered]@{ profile=$directory.Name; nativeSuites=$suites; consumers=$consumers; sanitizer=$probes;
        benchmarks=$benchmarks; gridCases=$completed; firstPresentation=$presentation; preparedTreeNative=$prepared; preparedTreeEmbedded=$clients }
}
if ($profiles.Count -ne $ExpectedProfiles) { throw 'All six native profiles are required for the audit.' }
$profiles | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $Root 'native-audit.json') -Encoding utf8NoBOM
$profiles | ForEach-Object { [pscustomobject]@{profile=$_.profile;passed=@($_.nativeSuites|Where-Object result -EQ pass).Count;
    foregroundNotExecuted=@($_.nativeSuites|Where-Object result -NE pass).Count;consumers=$_.consumers.Count;benchmarks=$_.benchmarks.Count} } | ConvertTo-Json



