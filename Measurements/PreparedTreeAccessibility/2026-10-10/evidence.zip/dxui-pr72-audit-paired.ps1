param([Parameter(Mandatory)][string] $Root, [Parameter(Mandatory)][string] $CandidateCommit, [Parameter(Mandatory)][string] $CandidateFingerprint)
$ErrorActionPreference = 'Stop'
Import-Module Z:/src/DxUi/Tools/PerformanceComparison.psm1 -Force
$summaryFile = @(Get-ChildItem -LiteralPath $Root -Recurse -File -Filter 'summary.json')
if ($summaryFile.Count -ne 1) { throw 'One complete paired summary is required.' }
$reports = $summaryFile[0].DirectoryName
$summary = Get-Content -LiteralPath $summaryFile[0].FullName -Raw | ConvertFrom-Json -AsHashtable
if ($summary.baseline.commit -ne '60e1cbff8f7a75757e9447073965d09101d9833c' -or
    $summary.candidate.commit -ne $CandidateCommit -or
    $summary.blocks -ne 12 -or $summary.studyVersion -ne 3 -or $summary.scenarios.Count -ne 3) { throw 'Unexpected paired source/protocol.' }
$receipts = 0
$rounds = 0
$timingFields = 0
$audit = @()
foreach ($scenario in $summary.scenarios) {
    $byRun = @{}
    foreach ($record in $scenario.judgeComparison.sameReceiptsSha256) {
        $file = Join-Path $reports "$($scenario.scenario)-$($record.run).json"
        if ((Get-FileHash -LiteralPath $file).Hash -cne $record.sha256) { throw "Changed raw receipt: $file" }
        $data = Read-PerformanceReceipt $file
        Assert-PerformanceReceipt $data
        foreach ($phase in $data.scenarios) {
            foreach ($round in $phase.rounds) {
                $rounds++
                $samples = $round.timingSamplesMs
                $frames = [double[]]$samples.frame.Clone(); [Array]::Sort($frames)
                $preparation = [double[]]$samples.prepare.Clone(); [Array]::Sort($preparation)
                $composition = [double[]]$samples.composeCpu.Clone(); [Array]::Sort($composition)
                $sum = 0.0; foreach ($sample in $samples.frame) { $sum += [double]$sample }
                $values = @{ fps=($samples.frame.Count*1000.0/$sum); frameP50Ms=$frames[19]; frameP95Ms=$frames[37];
                    prepareP95Ms=$preparation[37]; composeCpuP95Ms=$composition[37] }
                foreach ($key in $values.Keys) {
                    if ([Math]::Abs([double]$round[$key] - $values[$key]) -gt [Math]::Max(1e-8,[Math]::Abs($values[$key])*1e-8)) { throw "Raw timing mismatch $file/$key" }
                    $timingFields++
                }
            }
        }
        $byRun[$record.run] = $data
        $receipts++
    }
    if ($byRun.Count -ne 48) { throw 'Each scenario requires 24 receipts per side.' }
    $blocks = @($summary.blockSchedule | ForEach-Object { [ordered]@{
        name=$_.Name; order=$_.Order;
        Baseline=@($_.BaselineRuns | ForEach-Object { $data=$byRun[$_]; if($data.sourceCommit -ne $summary.baseline.commit -or $data.sourceFingerprint -ne 'E6DB772710D1C2050CC2A7B6F3D38AC07F1A21EB84EAB046A209AEFB70591570'){throw 'Baseline identity mismatch'}; $data });
        Candidate=@($_.CandidateRuns | ForEach-Object { $data=$byRun[$_]; if($data.sourceCommit -ne $summary.candidate.commit -or $data.sourceFingerprint -ne $CandidateFingerprint){throw 'Candidate identity mismatch'}; $data })
    } })
    $migrated = Compare-PairedBlockSet -Blocks $blocks -MinimumBlocks 12 -AssignmentProtocol $summary.allocation
    $legacy = Compare-PerformanceSet -Baseline @($blocks|ForEach-Object {$_.Baseline}) -Candidate @($blocks|ForEach-Object {$_.Candidate})
    foreach ($pair in @(@($migrated,$scenario.set),@($legacy,$scenario.judgeComparison.legacyJudge))) {
        if ($pair[0].status -ne $pair[1].status -or $pair[0].metrics.Count -ne 26 -or $pair[1].metrics.Count -ne 26) { throw 'Recomputed judge status/count differs.' }
        foreach ($metric in $pair[0].metrics) {
            $saved = @($pair[1].metrics | Where-Object { $_.phase -eq $metric.phase -and $_.metric -eq $metric.metric })
            if ($saved.Count -ne 1 -or $saved[0].verdict -ne $metric.verdict -or $saved[0].rawRegressed -ne $metric.rawRegressed -or
                $saved[0].rawImproved -ne $metric.rawImproved -or $saved[0].deterministicRise -ne $metric.deterministicRise) { throw 'Recomputed metric decision differs.' }
        }
    }
    $audit += [ordered]@{scenario=$scenario.scenario; migrated=$migrated; legacy=$legacy;
        reportedJudgeAgreement=$scenario.judgeComparison.verdictAgreement;
        comparisonFlags=@($scenario.comparisons | Where-Object status -EQ 'advice-required');
        controls=@($scenario.comparisons | Where-Object name -Like '*control')}
}
if ($receipts -ne 144 -or $rounds -ne 1440 -or $timingFields -ne 7200) { throw 'Incomplete paired raw evidence.' }
$result = [ordered]@{receipts=$receipts;rounds=$rounds;timingFields=$timingFields;seed=$summary.seed;
    acceptancePolicy=$summary.acceptancePolicy;scenarios=$audit;
    qualification='This recomputes recorded evidence; it does not qualify the benchmark acceptance policy.'}
$result | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath (Join-Path $Root 'paired-audit.json') -Encoding utf8NoBOM
$audit | ForEach-Object { [pscustomobject]@{scenario=$_.scenario;migratedStatus=$_.migrated.status;
    migratedFlags=@($_.migrated.metrics|Where-Object verdict -NE 'within-noise').Count;legacyStatus=$_.legacy.status;
    legacyFlags=@($_.legacy.metrics|Where-Object verdict -NE 'within-noise').Count;judgeAgreement=$_.reportedJudgeAgreement;
    unstableControls=@($_.controls|Where-Object status -EQ 'unstable-control').Count} } | ConvertTo-Json

